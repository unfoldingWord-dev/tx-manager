# return #

## Definition: ##

The term "return" means to go back or to give something back.

* To "return to" something means to start doing that activity again. To “return to” a place or person means to bo back to that place or person again.
* When the Israelites returned to their worship of idols, they were starting to worship them again.
* When they returned to Yahweh, they repented and were worshiping Yahweh again.
* To return land or things that were taken or received from someone else means to give that property back to the person it belongs to.

(See also: [turn](../kt/turn.md))

## Bible References: ##