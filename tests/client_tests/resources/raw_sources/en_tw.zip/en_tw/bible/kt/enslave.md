# enslave, in bondage #

## Definition: ##

To "enslave" someone means to force that person to serve a master or a ruling country. To be "enslaved" or "in bondage" means to be under the control of something or someone.

* A person who is enslaved or in bondage must serve others without payment; he is not free to do what he wants.
* To "enslave" also means to take away a person's freedom.
* Another word for "bondage" is "slavery."
* In a figurative way, human beings are "enslaved" to sin until Jesus frees them from its control and power.
* When a person receives new life in Christ, he stops being a slave to sin and becomes a slave to righteousness.

## Translation Suggestions: ##

* The term "enslave" could be translated as "cause to not be free" or "force to serve others" or "put under the control of others."
* The phrase "enslaved to" or "in bondage to" could be translated as "forced to be a slave of" or "forced to serve" or "under the control of."

(See also: [free](../kt/free.md), [righteous](../kt/righteous.md), [servant](../other/servant.md))

## Bible References: ##

* [Galatians 04:3-5](en/tn/gal/help/04/03)
* [Galatians 04:24-25](en/tn/gal/help/04/24)
* [Genesis 15:12-13](en/tn/gen/help/15/12)
* [Jeremiah 30:8-9](en/tn/jer/help/30/08)