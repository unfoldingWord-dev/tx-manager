# sexual immorality, immorality, immoral, fornication #

## Definition: ##

The term "sexual immorality" refers to sexual activity that takes place outside the marriage relationship of a man and a woman. This is against God's plan. Older English Bible versions call this "fornication."

* This term can refer to any kind of sexual activity that is against God's will, including homosexual acts and pornography.
* One type of sexual immorality is adultery, which is sexual activity specifically between a married person and someone who is not that person's spouse.
* Another type of sexual immorality is "prostitution," which involves being paid to have sex with someone.
* This term is also used figuratively to refer to Israel's unfaithfulness to God when they worshiped false gods.

## Translation Suggestions: ##

* The term "sexual immorality" could be translated as "immorality" as long as the correct meaning of the term is understood.
* Other ways to translate this term could include "wrong sexual acts" or "sex outside of marriage."
* This term should be translated in a different way from the term "adultery."
* The translation of this term's figurative uses should retain the literal term if possible since there is a common comparison in the Bible between unfaithfulness to God and unfaithfulness in the sexual relationship.

(See also: [adultery](../kt/adultery.md), [false god](../kt/falsegod.md), [prostitute](../other/prostitute.md), [unfaithful](../kt/unfaithful.md))

## Bible References: ##

* [Acts 15:19-21](en/tn/act/help/15/19)
* [Acts 21:25-26](en/tn/act/help/21/25)
* [Colossians 03:5-8](en/tn/col/help/03/05)
* [Ephesians 05:3-4](en/tn/eph/help/05/03)
* [Genesis 38:24-26](en/tn/gen/help/38/24)
* [Hosea 04:13-14](en/tn/hos/help/04/13)
* [Matthew 05:31-32](en/tn/mat/help/05/31)
* [Matthew 19:7-9](en/tn/mat/help/19/07)