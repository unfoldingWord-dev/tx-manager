# Ahaz #

## Definition: ##

Ahaz was a wicked king who ruled over the kingdom of Judah from 732 BC to 716 BC. This was about 140 years before the time when many people in Israel and Judah were taken as captives to Babylonia.

* While he was ruling Judah, Ahaz had an altar built for worshiping the false gods of the Assyrians, which caused the people to turn away from the one true God, Yahweh.
* King Ahaz was 20 years old when he started to rule over Judah, and he ruled for 16 years.

(Translation suggestions: [How to Translate Names](en/ta-vol1/translate/man/translate-names))

(See also: [Babylon](../other/babylon.md))

## Bible References: ##

* [1 Chronicles 08:35-37](en/tn/1ch/help/08/35)
* [2 Chronicles 28:1-2](en/tn/2ch/help/28/01)
* [2 Kings 16:19-20](en/tn/2ki/help/16/19)
* [Hosea 01:1-2](en/tn/hos/help/01/01)
* [Isaiah 01:1](en/tn/isa/help/01/01)
* [Isaiah 07:3-4](en/tn/isa/help/07/03)
* [Matthew 01:9-11](en/tn/mat/help/01/09)