# Cana #

## Definition: ##

Cana was a village or town in the province of Galilee, located about nine miles north of Nazareth.

* Cana was the hometown of Nathanael, one of the Twelve.
* Jesus attended a wedding feast in Cana and performed his first miracle there when he turned water into wine.
* Some time after that, Jesus came back to Cana and met an official there from Capernaum who requested healing for his son.

(See also: [Capernaum](../other/capernaum.md), [Galilee](../other/galilee.md), [the twelve](../kt/thetwelve.md))

## Bible References: ##

* [John 02:1-2](en/tn/jhn/help/02/01)
* [John 04:46-47](en/tn/jhn/help/04/46)