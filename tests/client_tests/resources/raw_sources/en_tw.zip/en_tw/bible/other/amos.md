# Amos #

## Facts: ##

Amos was an Israelite prophet who lived during the time of King Uzziah of Judah.

* Before being called as a prophet, Amos was originally a shepherd and fig farmer living in the kingdom of Judah.
* Amos prophesied against the prosperous northern kingdom of Israel regarding their unjust treatment of people.

(Translation suggestions: [Translate Names](en/ta-vol1/translate/man/translate-names))

(See also: [fig](../other/fig.md), [Judah](../other/judah.md), [kingdom of Israel](../other/kingdomofisrael.md), [shepherd](../other/shepherd.md), [Uzziah](../other/uzziah.md))

## Bible References: ##

* [Amos 01:1-2](en/tn/amo/help/01/01)