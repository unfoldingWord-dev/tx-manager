# Abner #

## Definition: ##

Abner was a cousin of King Saul in the Old Testament.

* Abner was the chief commander of Saul's army, and introduced young David to Saul after David killed Goliath the giant.
* After King Saul's death, Abner appointed Saul's son Ishbosheth as king in Israel, while David was appointed king in Judah.
* Later, Abner was treacherously killed by David's chief commander, Joab.

(Translation suggestions: [How to Translate Names](en/ta-vol1/translate/man/translate-names))

## Bible References: ##

* [1 Chronicles 26:26-28](en/tn/1ch/help/26/26)
* [1 Kings 02:5-6](en/tn/1ki/help/02/05)
* [1 Kings 02:32-33](en/tn/1ki/help/02/32)
* [1 Samuel 17:55-56](en/tn/1sa/help/17/55)
* [2 Samuel 03:22-23](en/tn/2sa/help/03/22)