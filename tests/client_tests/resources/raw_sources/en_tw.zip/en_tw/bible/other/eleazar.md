# Eleazar #

## Facts: ##

Eleazar was the name of several men in the Bible.
 
* Eleazar was the third son of Moses' brother Aaron. After Aaron died, Eleazar became the high priest in Israel.
* Eleazar was also the name of one of David's "mighty men."
* Another Eleazar was one of Jesus' ancestors.

(Translation suggestions: [How to Translate Names](en/ta-vol1/translate/man/translate-names))

(See also: [Aaron](../other/aaron.md), [high priest](../kt/highpriest.md), [David](../other/david.md), [mighty](../other/mighty.md))

## Bible References: ##

* [1 Chronicles 24:1-3](en/tn/1ch/help/24/01)
* [Judges 20:27-28](en/tn/jdg/help/20/27)
* [Numbers 26:1-2](en/tn/num/help/26/01)
* [Numbers 34:16-18](en/tn/num/help/34/16)