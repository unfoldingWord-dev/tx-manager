# Elam #

## Facts: ##

Elam was a son of Shem and a grandson of Noah.

* The descendants of Elam were called "Elamites," and they lived in a region that was also called "Elam."
* The region of Elam was located southeast of the Tigris River in what is now western Iran.

(Translation suggestions: [How to Translate Names](en/ta-vol1/translate/man/translate-names))

(See also: [Noah](../other/noah.md), [Shem](../other/shem.md))

## Bible References: ##

* [1 Chronicles 01:17-19](en/tn/1ch/help/01/17)
* [Acts 02:8-11](en/tn/act/help/02/08)
* [Ezra 08:4-7](en/tn/ezr/help/08/04)
* [Isaiah 22:5-7](en/tn/isa/help/22/05)