# Absalom #

## Facts: ##

Absalom was the third son of King David. He was known for his handsome appearance and fiery temperament.

* When Absalom's sister Tamar was raped by their half-brother, Amnon, Absalom made a plan to have Amnon killed.
* After the murder of Amnon, Absalom fled to the region of Geshur (where his mother Maacah was from) and stayed there three years. Then King David sent for him to come back to Jerusalem, but did not allow Absalom to come into his presence for two years.
* Absalom turned some of the people against King David and led a revolt against him.
* David's army fought against Absalom and killed him. David was very grieved when this happened.

(Translation suggestions: [How to Translate Names](en/ta-vol1/translate/man/translate-names))

(See also: [Geshur](../other/geshur.md), [Amnon](../other/amnon.md))

## Bible References: ##

* [1 Chronicles 03:1-3](en/tn/1ch/help/03/01)
* [1 Kings 01:5-6](en/tn/1ki/help/01/05)
* [2 Samuel 15:1-2](en/tn/2sa/help/15/01)
* [2 Samuel 17:1-4](en/tn/2sa/help/17/01)
* [2 Samuel 18:18](en/tn/2sa/help/18/18)
* [Psalm 003:1-2](en/tn/psa/help/03/01)