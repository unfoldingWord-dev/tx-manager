# accuse, accusation, accuser #

## Definition: ##

The terms "accuse" and "accusation" refer to blaming someone for doing something wrong. A person who accuses others is an "accuser."

* A false accusation is when a charge against someone is not true, as when Jesus was falsely accused of wrongdoing by the leaders of the Jews.
* In the New Testament book of Revelation, Satan is called "the accuser."

## Bible References: ##

* [Acts 19:38-41](en/tn/act/help/19/38)
* [Hosea 04:4-5](en/tn/hos/help/04/04)
* [Jeremiah 02:9-11](en/tn/jer/help/02/09)
* [Luke 06:6-8](en/tn/luk/help/06/06)
* [Romans 08:33-34](en/tn/rom/help/08/33)