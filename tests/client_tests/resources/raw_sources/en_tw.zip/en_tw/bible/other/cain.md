# Cain #

## Facts: ##

Cain and his younger brother Abel were the first sons of Adam and Eve mentioned in the Bible.

* Cain was a farmer who produced food crops while Abel was a sheep herder.
* Cain killed his brother Abel in a fit of jealousy because God had accepted Abel's sacrifice but had not accepted Cain's sacrifice.
* As punishment, God sent him away from Eden and told him that the land would no longer yield crops for him.
* God put a mark on Cain's forehead as a sign that God would protect him from being killed by other people as he wandered.

(Translation suggestions: [How to Translate Names](en/ta-vol1/translate/man/translate-names))

(See also: [Adam](../other/adam.md), [sacrifice](../other/sacrifice.md))

## Bible References: ##

* [1 John 03:11-12](en/tn/1jn/help/03/11)
* [Genesis 04:1-2](en/tn/gen/help/04/01)
* [Genesis 04:8-9](en/tn/gen/help/04/08)
* [Genesis 04:13-15](en/tn/gen/help/04/13)
* [Hebrews 11:4](en/tn/heb/help/11/04)
* [Jude 01:9-11](en/tn/jud/help/01/09)