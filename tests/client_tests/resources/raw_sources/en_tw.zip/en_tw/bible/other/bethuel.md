# Bethuel #

## Facts: ##

Bethuel was the son of Abraham's brother Nahor.

* Bethuel was the father of Rebekah and Laban.
* There was also a town called Bethuel, which may have been located in southern Judah, not far from the town of Beersheba.

(Translation suggestions: [How to Translate Names](en/ta-vol1/translate/man/translate-names))

(See also: [Beersheba](../other/beersheba.md), [Laban](../other/laban.md), [Nahor](../other/nahor.md), [Rebekah](../other/rebekah.md))

## Bible References: ##

* [1 Chronicles 04:29-31](en/tn/1ch/help/04/29)
* [Genesis 28:1-2](en/tn/gen/help/28/01)