# Dan #

## Facts: ##

Dan was the fifth son of Jacob and was one of the twelve tribes of Israel.The region settled by the tribe of Dan in the northern part of Canaan also was given this name.

* During the time of Abram, there was a city named Dan located west of Jerusalem.
* Years later, during the time the nation of Israel entered the promised land, a different city named Dan was located about 60 miles north of Jerusalem.
* The term "Danites" refers to the descendants of Dan, who were also members of his clan.

(Translation suggestions: [How to Translate Names](en/ta-vol1/translate/man/translate-names))

(See also: [Canaan](../other/canaan.md), [Jerusalem](../other/jerusalem.md), [twelve tribes of Israel](../other/12tribesofisrael.md))

## Bible References: ##

* [1 Chronicles 12:34-35](en/tn/1ch/help/12/34)
* [1 Kings 04:24-25](en/tn/1ki/help/04/24)
* [Exodus 01:1-5](en/tn/exo/help/01/01)
* [Genesis 14:13-14](en/tn/gen/help/14/13)
* [Genesis 30:5-6](en/tn/gen/help/30/05)