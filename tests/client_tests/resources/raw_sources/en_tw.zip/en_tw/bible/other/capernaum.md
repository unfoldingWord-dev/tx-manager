# Capernaum #

## Facts: ##

Capernaum was a fishing village on the northwest shore of the Sea of Galilee.

 * Jesus lived in Capernaum whenever he was teaching in Galilee.
 * Several of his disciples were from Capernaum.
 * Jesus also did many miracles in this city, including bringing a dead girl back to life.
 * Capernaum was one of three cities that Jesus publicly rebuked because their people rejected him and did not believe his message. He warned them that God would punish them for their unbelief.

(Translation suggestions: [How to Translate Names](en/ta-vol1/translate/man/translate-names))

(See also: [Galilee](../other/galilee.md), [Sea of Galilee](../other/seaofgalilee.md))

## Bible References: ##

* [John 02:12](en/tn/jhn/help/02/12)
* [Luke 04:31-32](en/tn/luk/help/04/31)
* [Luke 07:1](en/tn/luk/help/07/01)
* [Mark 01:21-22](en/tn/mrk/help/01/21)
* [Mark 02:1-2](en/tn/mrk/help/02/01)
* [Matthew 04:12-13](en/tn/mat/help/04/12)
* [Matthew 17:24-25](en/tn/mat/help/17/24)