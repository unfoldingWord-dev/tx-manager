# Baasha #

## Facts: ##

Baasha was one of Israel's evil kings, who influenced the Israelites to worship idols.

* Baasha was the third king of Israel and reigned for twenty-four years, during the time when Asa was king of Judah.
* He was a military commander who became king by killing the previous king, Nadab.
* During Baasha's reign there were many wars between the kingdoms of Israel and Judah, especially with King Asa of Judah.
* Baasha's many sins caused God to eventually remove him from office by his death.

(Translation suggestions: [Translate Names](en/ta-vol1/translate/man/translate-names))

(See also: [Asa](../other/asa.md), [idol](../other/idol.md))

## Bible References: ##

* [1 Kings 15:16-17](en/tn/1ki/help/15/16)
* [2 Kings 09:9-10](en/tn/2ki/help/09/09)
* [Jeremiah 41:8-9](en/tn/jer/help/41/08)