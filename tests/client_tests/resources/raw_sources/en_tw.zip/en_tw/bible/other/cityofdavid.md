# city of David #

## Facts: ##

The term "city of David" is another name for both Jerusalem and Bethlehem.

 * Jerusalem is where David lived while he ruled Israel.
 * Bethlehem is where David was born.

(Translation suggestions: [How to Translate Names](en/ta-vol1/translate/man/translate-names))

(See also: [David](../other/david.md), [Bethlehem](../other/bethlehem.md), [Jerusalem](../other/jerusalem.md))

## Bible References: ##

* [1 Kings 08:1-2](en/tn/1ki/help/08/01)
* [2 Samuel 05:6-7](en/tn/2sa/help/05/06)
* [Isaiah 22:8-9](en/tn/isa/help/22/08)
* [Luke 02:4-5](en/tn/luk/help/02/04)
* [Nehemiah 03:14-15](en/tn/neh/help/03/14)