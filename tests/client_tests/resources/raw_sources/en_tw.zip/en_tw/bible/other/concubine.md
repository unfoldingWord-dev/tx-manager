# concubine #

## Definition: ##

A concubine is a woman who is a secondary wife for a man who already has a wife. Usually a concubine is not legally married to the man.

* In the Old Testament, concubines were often female slaves.
* A concubine could be acquired by purchase, through military conquest, or in payment of a debt.
* For a king, having many concubines was a sign of power. 
* The New Testament teaches that the practice of having a concubine is against God's will.

## Bible References: ##

* [2 Samuel 03:6-7](en/tn/2sa/help/03/06)
* [Genesis 22:23-24](en/tn/gen/help/22/23)
* [Genesis 25:5-6](en/tn/gen/help/25/05)
* [Genesis 35:21-22](en/tn/gen/help/35/21)
* [Genesis 36:9-12](en/tn/gen/help/36/09)
* [Judges 19:1-2](en/tn/jdg/help/19/01)