# Ephrathah, Ephrathite #

## Facts: ##

Ephrathah was the name of a city and region in the northern part of Israel. The city of Ephrathah was later called "Bethlehem" or "Ephrathah-Bethlehem."

* Ephrathah was the name of one of Caleb's sons. The city of Ephrathah was probably named after him.
* A person who was from the city of Ephrathah was called an "Ephrathite."
* Boaz, the great-grandfather of David, was an Ephrathite.

(Translation suggestions: [How to Translate Names](en/ta-vol1/translate/man/translate-names))

(See also: [Bethlehem](../other/bethlehem.md), [Boaz](../other/boaz.md), [Caleb](../other/caleb.md), [David](../other/david.md), [Israel](../other/israel.md))

## Bible References: ##