# Eliakim #

## Facts: ##

Eliakim was the name of two men in the Old Testament.

* One man named Eliakim was the manager of the palace under King Hezekiah.
* Another man named Eliakim was a son of King Josiah. He was made king of Judah by the Egyptian pharaoh Necho.
* Necho changed Eliakim's name to Jehoiakim.

(Translation suggestions: [Translate Names](en/ta-vol1/translate/man/translate-names))

(See also: [Hezekiah](../other/hezekiah.md), [Jehoiakim](../other/jehoiakim.md), [Josiah](../other/josiah.md), [Pharaoh](../other/pharaoh.md))

## Bible References: ##

* [2 Kings 18:16-18](en/tn/2ki/help/18/16)
* [2 Kings 18:26-27](en/tn/2ki/help/18/26)
* [2 Kings 18:36-37](en/tn/2ki/help/18/36)
* [2 Kings 23:34-35](en/tn/2ki/help/23/34)