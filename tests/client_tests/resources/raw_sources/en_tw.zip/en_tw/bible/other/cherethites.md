# Cherethites #

## Facts: ##

The Cherethites were a people group who were probably part of the Philistines. Also written as "Kerethites."

* The "Cherethites and Pelethites" were a special group of soldiers from King David's army who were especially devoted to him as his bodyguards.
* Benaiah, son of Jehoiada, a member of David's administrative corps, was the leader of the Cherethites and Pelethites.
* The Cherethites remained with David when he had to flee Jerusalem because of Absalom's revolt.

(Translation suggestions: [Translate Names](en/ta-vol1/translate/man/translate-names))

(See also: [Absalom](../other/absalom.md), [Benaiah](../other/benaiah.md), [David](../other/david.md), [Philistines](../other/philistines.md))

## Bible References: ##

* [Zephaniah 02:4-5](en/tn/zep/help/02/04)