# Beelzebul #

## Facts: ##

Beelzebul is another name for Satan, or the devil. It is also sometimes spelled, "Beelzebub."

 * This name literally means "lord of flies" which means, "ruler over demons." But it is best to translate this term close to the original spelling rather than translate the meaning.
 * It could also be translated as "Beelzebul the devil" to make it clear who is being referred to.
 * This name is related to the name of the false god "Baal-zebub" of Ekron.

(Translation suggestions: [How to Translate Names](en/ta-vol1/translate/man/translate-names))

(See also: [demon](../kt/demon.md), [Ekron](../other/ekron.md), [Satan](../kt/satan.md))

## Bible References: ##

* [Luke 11:14-15](en/tn/luk/help/11/14)
* [Mark 03:20-22](en/tn/mrk/help/03/20)
* [Matthew 10:24-25](en/tn/mat/help/10/24)
* [Matthew 12:24-25](en/tn/mat/help/12/24)