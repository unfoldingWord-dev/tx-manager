# Amnon #

## Facts: ##

Amnon was the oldest son of King David. His mother was King David's wife Ahinoam.

* Amnon raped his half-sister Tamar, who was also Absalom's sister.
* Because of this, Absalom plotted against Amnon and had him killed.

(See also: [David](../other/david.md), [Absalom](../other/absalom.md))

## Bible References: ##

* [1 Chronicles 03:1-3](en/tn/1ch/help/03/01)
* [2 Samuel 13:1-2](en/tn/2sa/help/13/01)
* [2 Samuel 13:7-9](en/tn/2sa/help/13/07)