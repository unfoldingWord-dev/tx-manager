# Delilah #

## Facts: ##

Delilah was a Philistine woman who was loved by Samson, but was not his wife.

* Delilah loved money more than she loved Samson.
* The Philistines bribed Delilah to trick Samson into telling her how he could be made weak. When his strength was gone, the Philistines captured him.

(Translation suggestions: [Translate Names](en/ta-vol1/translate/man/translate-names))

(See also: [bribe](../other/bribe.md), [Philistines](../other/philistines.md), [Samson](../other/samson.md))

## Bible References: ##

* [Judges 16:4-5](en/tn/jdg/help/16/04)
* [Judges 16:6-7](en/tn/jdg/help/16/06)
* [Judges 16:10-12](en/tn/jdg/help/16/10)
* [Judges 16:18-19](en/tn/jdg/help/16/18)