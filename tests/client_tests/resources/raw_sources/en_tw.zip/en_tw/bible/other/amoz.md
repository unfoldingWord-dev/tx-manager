# Amoz #

## Facts: ##

Amoz was the father of the prophet Isaiah.

* The only times he is mentioned in the Bible are when Isaiah is identified as the "son of Amoz."
* This name is different from the name of the prophet Amos and should be spelled differently.

(Translation suggestions: [How to Translate Names](en/ta-vol1/translate/man/translate-names))

(See also: [Amos](../other/amos.md), [Isaiah](../other/isaiah.md))

## Bible References: ##

* [2 Kings 19:1-2](en/tn/2ki/help/19/01)
* [Isaiah 37:1-2](en/tn/isa/help/37/01)
* [Isaiah 37:21-23](en/tn/isa/help/37/21)