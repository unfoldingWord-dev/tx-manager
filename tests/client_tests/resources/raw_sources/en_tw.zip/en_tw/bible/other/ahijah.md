# Ahijah #

## Facts: ##

Ahijah was the name of several different men in the Old Testament. The following are some of these men:

* Ahijah was the name of a priest in the time of Saul.
* A man named Ahijah was a secretary during the reign of King Solomon.
* Ahijah was the name of a prophet from Shiloh who predicted that the nation of Israel would be divided into two kingdoms.
* The father of King Baasha of Israel was also named Ahijah.

(Translation suggestions: [Translate Names](en/ta-vol1/translate/man/translate-names))

(See also: [Baasha](../other/baasha.md), [Shiloh](../other/shiloh.md))

## Bible References: ##

* [1 Kings 15:27-28](en/tn/1ki/help/15/27)
* [1 Kings 21:21-22](en/tn/1ki/help/21/21)
* [1 Samuel 14:18-19](en/tn/1sa/help/14/18)
* [2 Chronicles 10:15](en/tn/2ch/help/10/15)