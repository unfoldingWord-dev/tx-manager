# doom #

## Definition: ##

The term "doom" refers to a judgment of condemnation with no possibility of appeal or escape.

* As the nation of Israel was being taken captive into Babylon, the prophet Ezekiel said, "doom has come upon them."
* Depending on the context, this term could be translated as "disaster" or "punishment" or "hopeless ruin."

## Bible References: ##

* [Ezekiel 07:5-7](en/tn/ezk/help/07/05)
* [Ezekiel 30:8-9](en/tn/ezk/help/30/08)
* [Isaiah 06:4-5](en/tn/isa/help/06/04)
* [Psalms 092:6-7](en/tn/psa/help/92/06)