# Abel  #

## Facts: ##

Abel was Adam and Eve's second son. He was Cain's younger brother.

 * Abel was a shepherd.
 * Abel sacrificed some of his animals as an offering to God.
 * God was pleased with Abel and his offerings.
 * Adam and Eve's firstborn son Cain murdered Abel.

(Translation suggestions: [How to Translate Names](en/ta-vol1/translate/man/translate-names)) 

(See also: [Cain](../other/cain.md), [sacrifice](../other/sacrifice.md), [shepherd](../other/shepherd.md))

## Bible References: ##

* [Genesis 04:1-2](en/tn/gen/help/04/01)
* [Genesis 04:8-9](en/tn/gen/help/04/08)
* [Hebrews 12:22-24](en/tn/heb/help/12/22)
* [Luke 11:49-51](en/tn/luk/help/11/49)
* [Matthew 23:34-36](en/tn/mat/help/23/34)