# Enoch #

## Facts: ##

Enoch was the name of two men in the Old Testament.

* One man named Enoch was descended from Seth. He was the great grandfather of Noah.
* This Enoch had a close relationship with God and when he was 365 years old, God took him to heaven while he was still alive.
* A different man named Enoch was a son of Cain.

(Translation suggestions: [How to Translate Names](en/ta-vol1/translate/man/translate-names))

(See also: [Cain](../other/cain.md), [Seth](../other/seth.md))

## Bible References: ##

* [1 Chronicles 01:1-4](en/tn/1ch/help/01/01)
* [Genesis 05:18-20](en/tn/gen/help/05/18)
* [Genesis 05:21-24](en/tn/gen/help/05/21)
* [Jude 01:14-16](en/tn/jud/help/01/14)
* [Luke 03:36-38](en/tn/luk/help/03/36)