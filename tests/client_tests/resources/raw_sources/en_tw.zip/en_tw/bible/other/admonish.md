# admonish #

## Definition: ##

The term "admonish" means to firmly warn or advise someone.

* Usually "admonish" means to advise someone not to do something.
* In the body of Christ, believers are taught to admonish each other to avoid sin and to live holy lives.
* The word "admonish" could be translated as "encourage not to sin" or "urge someone to not sin."

## Bible References: ##

* [Nehemiah 09:32-34](en/tn/neh/help/09/32)