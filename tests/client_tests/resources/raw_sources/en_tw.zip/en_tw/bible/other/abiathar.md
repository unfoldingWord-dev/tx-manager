# Abiathar  #

## Definition: ##

Abiathar was a high priest for the nation of Israel during the time of King David.

* When King Saul killed the priests, Abiathar escaped and went to David in the wilderness.
* Abiathar and another high priest named Zadok served David faithfully throughout his reign.
* After David's death, Abiathar helped Adonijah try to become king instead of Solomon. 
* Because of this, King Solomon removed Abiathar from the priesthood.
  
  (See also: [Zadok](../other/zadok.md), [Saul (OT)](../other/saul.md), [David](../other/david.md), [Solomon](../other/solomon.md), [Adonijah](../other/adonijah.md))

## Bible References: ##

* [1 Chronicles 27:32-34](en/tn/1ch/help/27/32)
* [1 Kings 01:7-8](en/tn/1ki/help/01/07)
* [1 Kings 02:22-23](en/tn/1ki/help/02/22)
* [2 Samuel 17:15-16](en/tn/2sa/help/17/15)
* [Mark 02:25-26](en/tn/mrk/help/02/25)