# Adonijah #

## Definition: ##

Adonijah was the fourth son of King David.

* Adonijah tried to take over as king of Israel after the deaths of his brothers Absalom and Amnon.
* God, however, had promised that David's son Solomon would be king., so Adonijah's plot was overthrown and Solomon was made king.
* When Adonijah tried a second time to make himself king, Solomon put him to death.

(Translation suggestions: [How to Translate Names](en/ta-vol1/translate/man/translate-names))

(See also: [David](../other/david.md), [Solomon](../other/solomon.md)) 

## Bible References: ##