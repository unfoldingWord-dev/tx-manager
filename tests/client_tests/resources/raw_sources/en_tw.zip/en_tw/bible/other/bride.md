# bride #

## Definition: ##

A bride is the woman in a wedding ceremony who is getting married to her husband, the bridegroom.

* The term "bride" is used as a metaphor for believers in Jesus, the Church.
* Jesus is metaphorically called the "bridegroom" for the Church. (See: [Metaphor](en/ta-vol1/translate/man/figs-metaphor))

(See also: [bridegroom](../other/bridegroom.md), [church](../kt/church.md))

## Bible References: ##

* [Exodus 22:16-17](en/tn/exo/help/22/16)
* [Isaiah 62:5](en/tn/isa/help/62/05)
* [Joel 02:15-16](en/tn/jol/help/02/15)