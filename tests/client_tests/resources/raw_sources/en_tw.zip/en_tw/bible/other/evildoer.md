# evildoer #

## Definition: ##

The term "evildoer" is a general reference to people who do sinful and wicked things.

* It can also be a general word for people who do not obey God.
* This term could be translated using the word for "evil" or "wicked," with the word for "doing" or "making" or "causing" something.

(See also: [evil](../kt/evil.md))

## Bible References: ##

* [1 Peter 02:13-17](en/tn/1pe/help/02/13)
* [Isaiah 09:16-17](en/tn/isa/help/09/16)
* [Luke 13:25-27](en/tn/luk/help/13/25)
* [Malachi 03:13-15](en/tn/mal/help/03/13)
* [Matthew 07:21-23](en/tn/mat/help/07/21)