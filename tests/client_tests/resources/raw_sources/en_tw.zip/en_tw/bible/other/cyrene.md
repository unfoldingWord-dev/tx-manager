# Cyrene #

## Facts: ##

Cyrene was a Greek city on the north coast of Africa on the Mediterranean Sea, directly south of the island of Crete.

* In New Testament times, both Jews and Christians lived in Cyrene.
* Cyrene is probably most well-known in the Bible as the home city of a man named Simon who carried the cross of Jesus.

(Translation suggestions: [How to Translate Names](en/ta-vol1/translate/man/translate-names))

(See also: [Crete](../other/crete.md))

## Bible References: ##

* [Acts 11:19-21](en/tn/act/help/11/19)
* [Matthew 27:32-34](en/tn/mat/help/27/32)