# Crete, Cretan #

## Facts: ##

Crete is an island that is located off the southern coast of Greece. A "Cretan" is someone who lives on this island.

* The apostle Paul traveled to the island of Crete during his missionary journeys.
* Paul left his co-worker Titus on Crete to teach the Christians and to help appoint leaders for the church there.

(Translation suggestions: [How to Translate Names](en/ta-vol1/translate/man/translate-names))

## Bible References: ##

* [Acts 02:8-11](en/tn/act/help/02/08)
* [Acts 27:7-8](en/tn/act/help/27/07)
* [Amos 09:7-8](en/tn/amo/help/09/07)
* [Titus 01:12-13](en/tn/tit/help/01/12)