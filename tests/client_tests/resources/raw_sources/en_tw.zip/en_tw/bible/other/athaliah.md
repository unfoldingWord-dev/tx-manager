# Athaliah #

## Facts: ##

Athaliah was the evil wife of Jehoram king of Judah. She was the granddaughter of the evil King Omri of Israel.

* Athaliah's son Ahaziah became king after Jehoram died.
* When her son Ahaziah died, Athaliah made a plan to kill all the rest of the king's family.
* But Athaliah's young grandson Joash was hidden by his aunt and saved from being killed. After Athaliah had ruled the land for six years, she was killed and Joash became king.

(Translation suggestions: [How to Translate Names](en/ta-vol1/translate/man/translate-names))

(See also: [Ahaziah](../other/ahaziah.md), [Jehoram](../other/jehoram.md), [Joash](../other/joash.md), [Omri](../other/omri.md))

## Bible References: ##

* [2 Chronicles 22:1-3](en/tn/2ch/help/22/01)
* [2 Chronicles 24:6-7](en/tn/2ch/help/24/06)
* [2 Kings 11:1-3](en/tn/2ki/help/11/01)