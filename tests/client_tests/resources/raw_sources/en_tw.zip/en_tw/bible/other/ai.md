# Ai #

## Facts: ##

In Old Testament times, Ai was the name of a Canaanite town located just south of Bethel and about 8 km northwest of Jericho.

* After defeating Jericho, Joshua led the Israelites in an attack of Ai. But they were easily defeated because God was not pleased with them.
* An Israelite named Achan had stolen plunder from Jericho, and God ordered that he and his family be killed. Then God helped the Israelites defeat the people of Ai.

(Translation suggestions: [How to Translate Names](en/ta-vol1/translate/man/translate-names))

(See also: [Bethel](../other/bethel.md), [Jericho](../other/jericho.md))

## Bible References: ##

* [Ezra 02:27-30](en/tn/ezr/help/02/27)
* [Genesis 12:8-9](en/tn/gen/help/12/08)
* [Genesis 13:3-4](en/tn/gen/help/13/03)
* [Joshua 07:2-3](en/tn/jos/help/07/02)
* [Joshua 08:10-12](en/tn/jos/help/08/10)