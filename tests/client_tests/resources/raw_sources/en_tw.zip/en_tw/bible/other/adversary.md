# adversary, enemy #

## Definition: ##

An "adversary" is a person or group who is opposed to someone or something. The term "enemy" has a similar meaning.

 * Your adversary can be a person who tries to oppose you or harm you. 
 * When two nations fight, each can be called an “adversary” of the other.
 * In the Bible, the devil is referred to as an "adversary" and an "enemy."
 * Adversary may be translated as "opponent" or "enemy," but it suggests a tronger form of opposition.

(See also: [Satan](../kt/satan.md))

## Bible References: ##

* [1 Timothy 05:14-16](en/tn/1ti/help/05/14)
* [Isaiah 09:11-12](en/tn/isa/help/09/11)
* [Job 06:21-23](en/tn/job/help/06/21)
* [Lamentations 04:12-13](en/tn/lam/help/04/12)
* [Luke 12:57-59](en/tn/luk/help/12/57)
* [Matthew 13:24-26](en/tn/mat/help/13/24)