# Barabbas #

## Facts: ##

Barabbas was a prisoner in Jerusalem at the time when Jesus was arrested.

* Barabbas was a criminal who had committed crimes of murder and rebellion against the Roman government.
* When Pontius Pilate offered to either release Barabbas or Jesus, the people chose Barabbas.
* So Pilate allowed Barabbas to go free, but condemned Jesus to be killed.

(Translation suggestions: [How to Translate Names](en/ta-vol1/translate/man/translate-names))

(See also: [Pilate](../other/pilate.md), [Rome](../other/rome.md))

## Bible References: ##

* [John 18:38-40](en/tn/jhn/help/18/38)
* [Luke 23:18-19](en/tn/luk/help/23/18)
* [Mark 15:6-8](en/tn/mrk/help/15/06)
* [Matthew 27:15-16](en/tn/mat/help/27/15)