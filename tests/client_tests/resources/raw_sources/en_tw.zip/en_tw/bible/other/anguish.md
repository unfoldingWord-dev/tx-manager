# anguish #

## Definition: ##

The term "anguish" refers to severe pain or distress. 

* Anguish can be physical or emotional pain or distress.
* Often people who are in extreme anguish will show it in their face and behaviors.
* For example, a person in severe pain or anguish might grit his teeth or cry out.
* The term "anguish" could also be translated as "emotional distress" or "deep sorrow" or "severe pain."
 

## Bible References: ##

* [Jeremiah 06:23-24](en/tn/jer/help/06/23)
* [Jeremiah 19:6-9](en/tn/jer/help/19/06)
* [Job 15:22-24](en/tn/job/help/15/22)
* [Luke 16:24](en/tn/luk/help/16/24)
* [Psalms 116:3-4](en/tn/psa/help/116/03)