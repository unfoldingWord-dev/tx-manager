# Asa #

## Facts: ##

Asa was a king who ruled over the kingdom of Judah for forty years, from 913 B.C. to 873 B.c.

* King Asa was a good king who removed many idols of false gods and caused the Israelites to start worshiping Yahweh again.
* Yahweh gave King Asa success in his warfare against other nations.
* Later in his reign, however, King Asa stopped trusting Yahweh and became sick with a disease that eventually killed him.

(Translation suggestions: [Translate Names](en/ta-vol1/translate/man/translate-names))

## Bible References: ##

* [1 Chronicles 09:14-16](en/tn/1ch/help/09/14)
* [1 Kings 15:7-8](en/tn/1ki/help/15/07)
* [2 Chronicles 14:1-4](en/tn/2ch/help/14/01)
* [Jeremiah 41:8-9](en/tn/jer/help/41/08)
* [Matthew 01:7-8](en/tn/mat/help/01/07)