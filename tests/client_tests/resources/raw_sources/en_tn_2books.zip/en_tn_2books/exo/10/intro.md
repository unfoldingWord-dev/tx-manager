# Exodus 10 General Notes #

#### Special concepts in this chapter ####

##### Pharaoh's hard heart #####

Pharaoh's heart is often described as hard in this chapter. This means that his heart was not open or willing to understand Yahweh's instructions. When his heart was hardened, it became less and less receptive to Yahweh.

#### Other possible translation difficulties in this chapter ####

##### Let my people go #####

This is a very important statement. Moses does not ask Pharaoh for permission to "let go" of the Hebrew people. Instead, he is demanding that Pharaoh free the Hebrew people.

## Links: ##

* __[Exodus 10:01 Notes](./01.md)__

__[<<](../09/intro.md) | [>>](../11/intro.md)__
