# Exodus 25 General Notes #

#### Special concepts in this chapter ####

##### The tent of meeting #####
This chapter gives specific instructions regarding the building of a tent where Moses would meet Yahweh and the ark would be stored. This would eventually become the tabernacle. It was to be considered a very holy place. (See: [[rc://en/tw/dict/bible/kt/tabernacle]] and [[rc://en/tw/dict/bible/kt/holy]])

## Links: ##

* __[Exodus 25:01 Notes](./01.md)__

__[<<](../24/intro.md) | [>>](../26/intro.md)__
