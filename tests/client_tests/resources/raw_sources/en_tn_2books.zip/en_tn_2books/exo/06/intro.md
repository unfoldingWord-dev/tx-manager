# Exodus 06 General Notes #

#### Special concepts in this chapter ####

##### Promised Land #####
According to the covenant Yahweh made with Abraham, Egypt is not the home of the Hebrew people. It is the Promised Land in Canaan. The people are to return home to their land. (See: [[rc://en/tw/dict/bible/kt/covenant]] and [[rc://en/tw/dict/bible/kt/promisedland]])

#### Other possible translation difficulties in this chapter ####

##### Let my people go #####

This is a very important statement. Moses does not ask Pharaoh for permission to "let go" of the Hebrew people. Instead, he is demanding that Pharaoh free the Hebrew people.

## Links: ##

* __[Exodus 06:01 Notes](./01.md)__

__[<<](../05/intro.md) | [>>](../07/intro.md)__
