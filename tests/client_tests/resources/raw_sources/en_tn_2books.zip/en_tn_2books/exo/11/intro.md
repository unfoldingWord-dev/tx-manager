# Exodus 11 General Notes #

#### Special concepts in this chapter ####

##### Pharaoh's hard heart #####

Pharaoh's heart is often described as hard in this chapter. This means that his heart was not open or willing to understand Yahweh's instructions. When his heart was hardened, it became less and less receptive to Yahweh.

#### Other possible translation difficulties in this chapter ####

##### Let my people go #####

In the previous chapters, Moses does not ask Pharaoh for permission to "let go" of the Hebrew people. Instead, he demanded that Pharaoh free the Hebrew people. In this chapter, the same wording is used to refer to Pharaoh "allowing" the Hebrew people to leave Egypt.

## Links: ##

* __[Exodus 11:01 Notes](./01.md)__

__[<<](../10/intro.md) | [>>](../12/intro.md)__
