# Exodus 35 General Notes #

#### Special concepts in this chapter ####

##### Sacrifice #####
All of the people offered sacrifices to Yahweh. This was a form of worship and a sign of repentance from making the golden calf idol. (See: [[rc://en/tw/dict/bible/kt/worship]] and [[rc://en/tw/dict/bible/kt/repent]])

## Links: ##

* __[Exodus 35:01 Notes](./01.md)__

__[<<](../34/intro.md) | [>>](../36/intro.md)__
