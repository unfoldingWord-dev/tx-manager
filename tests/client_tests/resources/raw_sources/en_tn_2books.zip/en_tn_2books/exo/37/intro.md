# Exodus 37 General Notes #

#### Special concepts in this chapter ####

##### The ark of the covenant #####
The ark, mentioned in previous chapters, is constructed in this chapter. There are other furnishings of the tabernacle that are also produced in this chapter. (See: [[rc://en/tw/dict/bible/kt/tabernacle]])

## Links: ##

* __[Exodus 37:01 Notes](./01.md)__

__[<<](../36/intro.md) | [>>](../38/intro.md)__
