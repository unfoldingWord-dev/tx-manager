# Exodus 38 General Notes #

#### Special concepts in this chapter ####

##### The altar #####
The altar is constructed in this chapter. There are other furnishings of the tabernacle that are also produced in this chapter. (See: [[rc://en/tw/dict/bible/kt/tabernacle]])

##### Materials #####
The list of materials being used is intended to give the reader an understanding of the scale of the tabernacle. It should fill the reader with awe concerning the power of Yahweh. (See: [[rc://en/ta/man/translate/figs-explicit]])

## Links: ##

* __[Exodus 38:01 Notes](./01.md)__

__[<<](../37/intro.md) | [>>](../39/intro.md)__
