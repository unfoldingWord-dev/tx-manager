# Exodus 33 General Notes #

#### Special concepts in this chapter ####

##### Covenant #####
While the covenants Yahweh made may not be conditioned upon the obedience of Israel, it is clear that their conquering of the Promised Land was conditioned on their obedience to Yahweh. (See: [[rc://en/tw/dict/bible/kt/covenant]] and [[rc://en/tw/dict/bible/kt/promisedland]])

## Links: ##

* __[Exodus 33:01 Notes](./01.md)__

__[<<](../32/intro.md) | [>>](../34/intro.md)__
