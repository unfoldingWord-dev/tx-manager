# Exodus 34 General Notes #

#### Other possible translation difficulties in this chapter ####

##### "He will bring the punishment for the fathers' sin on their children" #####
This phrase does not mean that a child is necessarily punished for the sins of their parents. Many scholars believe that this passage indicates that a parent's sins will have consequences that will affect their children and grandchildren. (See: [[rc://en/tw/dict/bible/kt/sin]])

## Links: ##

* __[Exodus 34:01 Notes](./01.md)__

__[<<](../33/intro.md) | [>>](../35/intro.md)__
