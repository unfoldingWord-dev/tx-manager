# Exodus 39 General Notes #

#### Special concepts in this chapter ####

##### The holy clothing #####
The special, holy clothing mentioned in previous chapters is produced in this chapter to the correct specifications. (See: [[rc://en/tw/dict/bible/kt/holy]])

## Links: ##

* __[Exodus 39:01 Notes](./01.md)__

__[<<](../38/intro.md) | [>>](../40/intro.md)__
