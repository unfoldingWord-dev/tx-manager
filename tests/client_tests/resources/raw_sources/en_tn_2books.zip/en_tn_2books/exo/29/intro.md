# Exodus 29 General Notes #

#### Special concepts in this chapter ####

##### Consecrating priests #####
This chapter records the process of consecrating priests. The priests were to be set apart from the rest of Israel because Yahweh is holy. (See: [[rc://en/tw/dict/bible/kt/consecrate]], [[rc://en/tw/dict/bible/kt/priest]] and [[rc://en/tw/dict/bible/kt/holy]])

#### Other possible translation difficulties in this chapter ####

##### "I will live among the Israelites" #####
As God, Yahweh is everywhere and cannot be limited to a single space. This phrase indicates that he permanently remains within Israel in a special way while they have the ark. 

## Links: ##

* __[Exodus 29:01 Notes](./01.md)__

__[<<](../28/intro.md) | [>>](../30/intro.md)__
