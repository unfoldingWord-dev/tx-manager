# Exodus 30 General Notes #

#### Special concepts in this chapter ####

##### Atonement ##### 
The atonement offered by the priests was very important in the religious life of Israel. In order to offer sacrifices, the priests had to maintain ritual cleanliness by washing themselves. (See: [[rc://en/tw/dict/bible/kt/atonement]], [[rc://en/tw/dict/bible/kt/priest]] and [[rc://en/tw/dict/bible/kt/clean]])

## Links: ##

* __[Exodus 30:01 Notes](./01.md)__

__[<<](../29/intro.md) | [>>](../31/intro.md)__
