# Exodus 02 General Notes #

#### Special concepts in this chapter ####

##### Moses' heritage #####
In the first part of this chapter, Pharaoh's daughter recognizes Moses as being a Hebrew, but in the last part of this chapter, the Midianites believe him to be an Egyptian. 

#### Other possible translation difficulties in this chapter ####

##### Ironic situations #####
While Pharaoh tried to diminish the power of the Israelites by killing all of their baby boys, Yahweh used Pharaoh's own daughter to save Moses. Moses was the one who would ultimately be used by Yahweh to deliver Israel. 

## Links: ##

* __[Exodus 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__
