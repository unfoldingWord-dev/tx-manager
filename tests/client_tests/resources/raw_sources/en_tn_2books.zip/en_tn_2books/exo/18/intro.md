# Exodus 18 General Notes #

#### Special concepts in this chapter ####

##### Leadership lessons #####
Jethro taught Moses an important leadership lesson in this chapter. Many scholars look at this chapter for important leadership lessons. Moses delegated some of his responsibilities to other godly men so that he would not become worn out by all the demands made of him. (See: [[rc://en/tw/dict/bible/kt/godly]])

## Links: ##

* __[Exodus 18:01 Notes](./01.md)__

__[<<](../17/intro.md) | [>>](../19/intro.md)__
