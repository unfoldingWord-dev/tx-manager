# Exodus 28 General Notes #

#### Special concepts in this chapter ####

##### Holy garments #####
Because Yahweh is holy, only the priests could approach him, and when they did they must be wearing specially made clothing. (See: [[rc://en/tw/dict/bible/kt/priest]] and [[rc://en/tw/dict/bible/kt/holy]])

## Links: ##

* __[Exodus 28:01 Notes](./01.md)__

__[<<](../27/intro.md) | [>>](../29/intro.md)__
