# Exodus 20 General Notes #

#### Structure and formatting ####

The instructions recorded in this chapter are commonly known as the "ten commandments." 

#### Special concepts in this chapter ####

##### Covenant #####
Yahweh's covenant faithfulness is now based on the covenant he made with Abraham as well as the covenant he is making with Moses. (See: [[rc://en/tw/dict/bible/kt/covenantfaith]] and [[rc://en/tw/dict/bible/kt/covenant]])

## Links: ##

* __[Exodus 20:01 Notes](./01.md)__

__[<<](../19/intro.md) | [>>](../21/intro.md)__
