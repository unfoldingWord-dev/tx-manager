# Exodus 36 General Notes #

#### Special concepts in this chapter ####

##### Tent of meeting #####
The tent of meeting, or tabernacle, mentioned in previous chapters is constructed in this chapter. (See: [[rc://en/tw/dict/bible/kt/tabernacle]])

## Links: ##

* __[Exodus 36:01 Notes](./01.md)__

__[<<](../35/intro.md) | [>>](../37/intro.md)__
