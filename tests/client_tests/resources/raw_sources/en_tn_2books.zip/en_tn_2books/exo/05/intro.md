# Exodus 05 General Notes #

#### Special concepts in this chapter ####

##### A slave's work #####
The Egyptians were known for making their slaves do a lot of work. They were forced to make a specific number of bricks every day. In this chapter, the were required to not only make these bricks, but also to gather the straw in order to make these bricks. 

#### Other possible translation difficulties in this chapter ####

##### "Let my people go" #####
This is a very important statement. Moses does not ask Pharaoh for permission to "let go" of the Hebrew people. Instead, he is demanding that Pharaoh free the Hebrew people. 

##### Titles #####
The leaders are given different titles in this chapter. The ULB uses "taskmasters" and "foremen." Many cultures will not have these types of titles. Generic expressions like "Egyptian leaders" and "Hebrew leaders" may be necessary.

## Links: ##

* __[Exodus 05:01 Notes](./01.md)__

__[<<](../04/intro.md) | [>>](../06/intro.md)__
