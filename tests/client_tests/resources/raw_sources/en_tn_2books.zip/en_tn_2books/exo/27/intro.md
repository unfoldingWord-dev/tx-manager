# Exodus 27 General Notes #

#### Structure and formatting ####

This chapter is a continuation of the material in the previous chapter.

#### Special concepts in this chapter ####

##### The tent of meeting #####
This chapter gives specific instructions regarding the building of a tent where Moses would meet Yahweh and the ark would be stored. This would eventually become the tabernacle. It was to be considered a very holy place. (See: [[rc://en/tw/dict/bible/kt/tabernacle]] and [[rc://en/tw/dict/bible/kt/holy]])

## Links: ##

* __[Exodus 27:01 Notes](./01.md)__

__[<<](../26/intro.md) | [>>](../28/intro.md)__
