# To whom did Paul address this letter?

Paul addressed this letter to all the people who are set apart in Christ Jesus at Philippi, including the overseers and deacons.

# For what did Paul give thanks to God for the Philippians?

Paul gave thanks to God for the Philippians' fellowship in the gospel from the first day until now.

# Of what was Paul confident regarding the Philippians?

Paul was confident that he who had begun a good work in them would complete it.

# In what had the Philippians been Paul's partners?

In Paul's imprisonment, and in his defense and confirmation of the gospel, the Philippians had been his partner.

# What did Paul pray would increase more and more among the Philippians?

Paul prayed that love would increase more and more among the Philippians.

# With what did Paul desire that the Philippians be filled?

Paul desired that the Philippians be filled with the fruits of righteousness.

# How had Paul's imprisonment advanced the gospel?

Paul's imprisonment for Christ had become widely known, and most of the brothers were now speaking with more boldness.

# How had Paul's imprisonment advanced the gospel?

Paul's imprisonment for Christ had become widely known, and most of the brothers were now speaking with more boldness.

# How had Paul's imprisonment advanced the gospel?

Paul's imprisonment for Christ had become widely known, and most of the brothers were now speaking with more boldness.

# Why were some proclaiming Christ out of selfish and insincere motives?

Some were proclaiming Christ out of selfish and insincere motives thinking they were adding to Paul's affliction in prison.

# What was Paul's reaction to the sincere and insincere preaching of Christ?

Paul rejoiced that, either way, Christ was being proclaimed.

# What did Paul desire to do in life or by death?

Paul desired to bring glory to Christ either in life or by death.

# Paul said that to live is what, and to die is what?

Paul said that to live is Christ, and to die is gain.

# What choices pulled Paul in different directions?

Paul was pulled by the choices of being with Christ in death, or of remaining in the flesh to continue his labor.

# What choices pulled Paul in different directions?

Paul was pulled by the choices of being with Christ in death, or of remaining in the flesh to continue his labor.

# What choices pulled Paul in different directions?

Paul was pulled by the choices of being with Christ in death, or of remaining in the flesh to continue his labor.

# Paul was confident that he would remain with the Philippians for what purpose?

Paul was confident that he would remain with the Philippians for their progress and joy in the faith.

# Whether with the Philippians or away from them, what did Paul want to hear about the Philippians?

Paul wanted to hear that the Philippians stood fast in one spirit, with one soul striving together for the faith of the gospel.

# When the Philippians did not fear those opposing them, of what was that a sign?

When the Philippians did not fear, it was a sign of their opponents' destruction, but of their salvation.

# What two things had been granted to the Philippians by God?

It had been granted to the Philippians that they believe on Christ, but also that they suffer in his behalf.

# What does Paul say the Philippians must do to make his joy full?

The Philippians must be of the same mind, have the same love, and be united in spirit and mind.

# How does Paul say the Philippians should count each other?

The Philippians should count each other better than themselves.

# Whose mind does Paul say we need to have?

Paul says we need to have the mind of Christ Jesus.

# Whose mind does Paul say we need to have?

Paul says we need to have the mind of Christ Jesus. 

# In what form did Christ Jesus exist?

Christ Jesus existed in the form of God.

# What form did Christ Jesus then take?

Christ Jesus then took the form of a servant, in the appearance of a man.

# How did Jesus humble himself?

Jesus humbled himself by obeying to the point of death on the cross.

# What did God then do for Jesus?

God highly exalted Jesus and gave him the name above every name.

# What will every tongue confess?

Every tongue will confess that Jesus Christ is Lord.

# How are the Philippians called to work out their salvation?

The Philippians are to work out their salvation with fear and trembling.

# What does God work in believers to do?

God works in believers both to will and to work for his good pleasure.

# Everything must be done without what?

Everything must be done without complaining and arguing.

# For what purpose is Paul pouring out his life?

Paul is pouring out his life in the sacrifice and service of the Philippian's faith. 

# What attitude does Paul have, which he also calls on the Philippians to have?

Paul rejoices with great joy.

# What attitude does Paul have, which he also calls on the Philippians to have?

Paul rejoices with great joy.

# Why is Timothy a unique helper for Paul?

Timothy is unique because he truly cares for the Philippians and not for his own interests.

# Why is Timothy a unique helper for Paul?

Timothy is unique because he truly cares for the Philippians and not for his own interests.

# Is Paul expecting to see the Philippians?

Yes, Paul expects to see the Philippians soon.

# For what did Epaphroditus almost die?

Epaphroditus almost died doing the work of Christ, serving Paul and supplying Paul's needs.

# For whom does Paul warn the believers to watch out?

Paul warns the believers to watch out for the dogs, the evil workers, and the mutilators.

# Who does Paul say are the true circumcision?

Paul says the true circumcision are those who worship in the Spirit of God, glory in Christ Jesus, and have no confidence in the flesh.

# How does Paul describe his previous conduct in respect to the righteousness of the law?

Paul describes his previous conduct as blameless in respect to the righteousness of the law.

# How does Paul now regard his previous confidence in the flesh?

Paul now counts all his previous confidence in the flesh as worthless because of Christ.

# For what purpose does Paul now consider all the previous things as garbage?

Paul considers all the previous things as garbage so that he may gain Christ.

# What righteousness does Paul now have?

Paul now has the righteousness from God that is through faith in Christ.

# Paul has fellowship with Christ in what?

Paul has the fellowship of Christ's sufferings.

# Although he is not yet complete, what does Paul continue to do?

Paul continues to press on.

# Toward what goal does Paul press on?

Paul presses on toward the goal to win the prize of the upward calling of God in Christ Jesus.

# What does Paul tell the Philippians to do regarding the example of his walk?

Paul tells the Philippians to join and imitate him in his walk.

# What is the destiny of those whose god is their belly and who think about earthly things?

Those whose god is their belly and who think about earthly things are destined for destruction.

# Where does Paul say the citizenship of believers is located?

Paul says the citizenship of believers is in heaven.

# What will Christ do to the bodies of believers when he comes from heaven?

Christ will transform the lowly bodies of believers into bodies formed like his glorious body.

# What does Paul want his beloved friends in Philippi to do?

Paul wants the Philippians to stand firm in the Lord.

# What does Paul wish to see happen with Euodia and Syntyche?

Paul wishes to see Euodia and Syntyche have the same mind in the Lord.

# What does Paul tell the Philippians to always do?

Paul tells them to rejoice in the Lord always.

# Instead of being anxious, what does Paul say to do?

Paul says that instead of being anxious, tell God in prayer what we need, and thank him.

# If we do this, what will guard our hearts and thoughts?

If we do this, the peace of God will guard our hearts and thoughts.

# Upon what kinds of things does Paul say to think?

Paul says to think upon things that are honorable, just, pure, lovely, of good report, excellent, and praiseworthy.

# What have the Philippians now been able to renew?

The Philippians have now been able to renew their concern for Paul.

# What secret has Paul learned about living in different circumstances?

Paul has learned the secret of living contently in both abundance and need.

# What secret has Paul learned about living in different circumstances?

Paul has learned the secret of living contently in both abundance and need.

# By what power can Paul live contently?

Paul can live contently in all circumstances through Christ who strengthens him.

# What does Paul seek for the Philippians in their giving to provide for his needs?

Paul seeks the fruit that increases to the Philippians' account.

# What does Paul seek for the Philippians in their giving to provide for his needs?

Paul seeks the fruit that increases to the Philippians' account.

# What does Paul seek for the Philippians in their giving to provide for his needs?

Paul seeks the fruit that increases to the Philippians' account.

# What does Paul seek for the Philippians in their giving to provide for his needs?

Paul seeks the fruit that increases to the Philippians' account.

# How does God view the gift made by the Philippians for Paul?

God is pleased with the sacrifice that the Philippians have made for Paul.

# What does Paul say God will do for the Philippians?

Paul says that God will supply every need of the Philippians according to his riches in glory in Christ Jesus.

# Paul says that those of which household greet the Philippians?

Those of Caesar's household greet the Philippians. 
