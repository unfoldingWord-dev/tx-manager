# Process Manual

## 1. Getting Started

### <a id="process-manual"/>Introduction to the Process Manual

*This page answers the question: What is the Process Manual?*

*In order to understand this topic, it would be good to read:*

  * [Finding Answers](intro.html#finding-answers)


### Welcome

The Process Manual is a step-by-step guide to help translation teams know what they need to do, from the start of a project to its completion.  This guide will help a translation team from its initial setup to final publishing of translated and checked content. 

### Getting Started

Translation is a complicated task and takes organization and a plan. There are many required steps to take a translation from an idea to completed, checked, distributed, and in use translation. The information in this Process Manual will help you know all of the necessary steps in the translation process.

---

## 2. Setting Up a Translation Team

### <a id="setup-team"/>Setting Up a Translation Team

*This page answers the question: How can I set up a translation team?*

*In order to understand this topic, it would be good to read:*

  * [The Translation Process](translate.html#translate-process)


### Choosing a Team

As you begin selecting a translation and checking team, there are many different types of people and roles that are needed. There are also specific qualifications that are needed for each team.

* [Choosing a Translation Team](translate.html#choose-team) - Describes many of the roles that are needed
* [Translator Qualifications](translate.html#qualifications) - Describes some of the skills needed by the translators
* Remember that everyone on the team needs to sign a statement that they agree with (forms are available at [http://ufw.io/forms/](http://ufw.io/forms/) ): 
    * [Statement of Faith](intro.html#statement-of-faith)
    * [Translation Guidelines](intro.html#translation-guidelines)
    * [Open License](intro.html#open-license)
* Everyone on the team also needs to know the qualities of a good translation (see [The Qualities of a Good Translation](translate.html#guidelines-intro)). 
* The team will also need to know where they can find answers (see [Finding Answers](intro.html#finding-answers)). 

### Translation Decisions

There are many decisions the translation team will have to make, many of them right at the beginning of the project. Included are the following:

* [Choosing What to Translate](translate.html#translation-difficulty) - Choosing what to translate first is another decision to be made
* [Choosing a Source Text](translate.html#translate-source-text) - Choosing a good source text is very important
    * [Copyrights, Licensing, and Source Texts](translate.html#translate-source-licensing) - Copyright issues must be considered when choosing a source text
    * [Source Texts and Version Numbers](translate.html#translate-source-version) - Translating from the latest version of a source text is best
* [Alphabet/Orthography](translate.html#translate-alphabet) - Many languages have alphabet decisions that need to be made
* [Decisions for Writing Your Language](translate.html#writing-decisions) - Writing style, punctuation, translating names, spelling, and other decisions have to be made

*Next we recommend you learn about:*

  * [Choosing a Translation Team](translate.html#choose-team)
  * [Translator Qualifications](translate.html#qualifications)
  * [Choosing a Source Text](translate.html#translate-source-text)
  * [Alphabet/Orthography](translate.html#translate-alphabet)
  * [Decisions for Writing Your Language](translate.html#writing-decisions)
  * [Choosing What to Translate](translate.html#translation-difficulty)

---

## 3. Translating

### <a id="pretranslation-training"/>Training Before Translation Begins

*This page answers the question: What should I know about translation before I start?*

*In order to understand this topic, it would be good to read:*

  * [The Translation Process](translate.html#translate-process)
  * [How to Aim Your Bible Translation](intro.html#translate-why)


### What to Know Before Translation

It is recommended that you consult the [Translation Manual](translate.html#translate-manual) frequently as you translate this content. Before you start translating, we recommend that you start working your way through the Translation Manual at least until you know the difference between a literal translation and a meaning-based translation. Much of the rest of the Translation Manual can be used as a "just-in-time" learning resource.

Some important subjects that must be learned before starting a translation project:

  * [The Qualities of a Good Translation](translate.html#guidelines-intro) - The definition of a good translation
  * [The Translation Process](translate.html#translate-process) - How a good translation is made
    * [Form and Meaning](translate.html#translate-fandm) - The difference between form and meaning
    * [Meaning-Based Translations](translate.html#translate-dynamic) - How to make a meaning-based translation

Some other important topics as you get started include:

  * [Choosing What to Translate](translate.html#translation-difficulty) - Suggestions for where to start translating
  * [First Draft](translate.html#first-draft) - How to make a first draft
  * [Help with Translating](translate.html#translate-help) - Using translation helps

*Next we recommend you learn about:*

  * [Choosing a Translation Team](translate.html#choose-team)
  * [Choosing a Source Text](translate.html#translate-source-text)
  * [Alphabet/Orthography](translate.html#translate-alphabet)
  * [Decisions for Writing Your Language](translate.html#writing-decisions)
  * [Choosing What to Translate](translate.html#translation-difficulty)

---

### <a id="platforms"/>Selecting a Platform

*This page answers the question: What tool can I use to translate?*

*In order to understand this topic, it would be good to read:*

  * [Introduction to the Process Manual](#process-manual)
  * [File Formats](translate.html#file-formats)


### Recommended Platform

The recommended platform for doing translation in the Door43 ecosystem is translationStudio (http://ufw.io/ts/).  This is where the translation and checking teams will do their work.  You may set up translationStudio on Android, Windows, Mac, or Linux devices, (see [Setting up translationStudio](#setup-ts) for more information).

### Other Options

If using translationStudio is not an option for your team, then you may consider using other online or offline tools.  Note that it will be your responsibility to get the content into USFM or Markdown format if you do not use translationStudio (see [File Formats](translate.html#file-formats) for more information).

*Next we recommend you learn about:*

  * [Setting Up translationStudio](#setup-ts)
  * [Training Before Translation Begins](#pretranslation-training)

---

### <a id="setup-ts"/>Setting Up translationStudio

*This page answers the question: How do I set up translationStudio?*

*In order to understand this topic, it would be good to read:*

  * [Selecting a Platform](#platforms)


### Installing tS for Mobile

The mobile (Android) edition of translationStudio is available from the [Google Play Store](https://play.google.com/store/apps/details?id=com.translationstudio.androidapp ) or via direct download from [http://ufw.io/ts/](http://ufw.io/ts/).  If you install from the Play Store, then you will be notified by the Play Store when a new version is available.  Note that you may also side load the installation apk to other devices to share the app.

### Installing tS for Desktop

The latest version of translationStudio for desktop or laptop computers (Windows, Mac, or Linux) is available from [http://ufw.io/ts/](http://ufw.io/ts/).  To install the program, navigate to the "Desktop" section and download the latest release.  Note that you may also copy the installation file to other computers to share the app.

### Using tS

Once installed, both editions of translationStudio are designed to work similarly.  You *do not* need an internet connection to use translationStudio!  First-time use of translationStudio will require an agreement to the [Statement of Faith](intro.html#statement-of-faith), the [Translation Guidelines](intro.html#translation-guidelines), and the [Open License](intro.html#open-license).

After the first-use screen, you will be brought to the Home screen where you can create a new project.  Once your project is created, you may start translating right away.  There are translationHelps built right into the app which you are encouraged to use to gain a better understanding of the source text.  Note that your work is automatically saved.  You may also choose to back up, share, or upload your work at various intervals (use the menu to access these functions).

### After Using tS

  1. We strongly recommend that your translation be checked (see [Training Before Checking Begins](#prechecking-training)).
  1. Once the checking is complete (to any level), you may upload your work from the app (Menu → Upload).
  1. Once uploaded, you can see your work online on Door43 (see [Publishing](#intro-publishing))

---

## 4. Checking

### <a id="prechecking-training"/>Training Before Checking Begins

*This page answers the question: What should I know about checking before I begin?*

*In order to understand this topic, it would be good to read:*

  * [Training Before Translation Begins](#pretranslation-training)


### Before Checking

It is recommended that you consult the [Checking Manual](checking.html#intro-check) frequently as you check this content. Before you start checking, we recommend that you start working your way through the Checking Manual until you understand what is required at each level. As you work through the checking process, you will need to consult the Checking Manual frequently.

*Next we recommend you learn about:*

  * [Introduction to the Checking Manual](checking.html#intro-check)
  * [The Goal of Checking](checking.html#goal-checking)
  * [How to Check](#required-checking)

---

### <a id="required-checking"/>How to Check

*This page answers the question: How do I check a translation?*

*In order to understand this topic, it would be good to read:*

  * [Training Before Checking Begins](#prechecking-training)


### Purpose of Checking Levels

The purpose of the Checking Levels (see [Checking Manual](checking.html#intro-check)) is primarily to help ensure that the translation has been made in accordance with the [Statement of Faith](intro.html#statement-of-faith) and the [Translation Guidelines](intro.html#translation-guidelines). Another reason is to increase the input and ownership of the community that will be using it.

#### Checking Level 1

Checking Level 1 is done primarily by the translation team, with some input from the language community. See [Checking Level One - Affirmation by Translation Team](checking.html#level1). After completing the Level 1 Check, you are encouraged to upload to Door43 (see [Introduction to Publishing](#intro-publishing)) and continue on to Checking Level 2 (see below). 

#### Checking Level 2

Checking Level 2 is done to verify that representative groups from the local language community agree that the translation is a good one (see [Checking Level Two - Affirmation by Community](checking.html#level2)). It is done with a language community check (see [Language Community Check](checking.html#language-community-check)) and a church leader check (see [Church Leader Check](checking.html#church-leader-check)). After completing the Level 2 Check, you are encouraged to upload to Door43 (see [Introduction to Publishing](#intro-publishing)) and continue on to Checking Level 3 (see below), if you so desire. 

#### Checking Level 3

Checking Level 3 is done when leaders of at least two church networks agree that the translation is a good one (see [Checking Level Three - Affirmation by Church Leadership](checking.html#level3)). Be sure you work through the Level 3 Checking Questions (see [Questions for Checking on Level Three](checking.html#level3-questions)) while you complete this checking level. After completing the Level 3 Check, you are encouraged to upload to Door43 (see [Introduction to Publishing](#intro-publishing)). This is the highest checking level. Gateway Languages should also complete the [Source Text Process](#source-text-process)

*Next we recommend you learn about:*

  * [Introduction to Publishing](#intro-publishing)

---

## 5. Publishing

### <a id="intro-publishing"/>Introduction to Publishing

*This page answers the question: What is publishing?*

*In order to understand this topic, it would be good to read:*

  * [Training Before Checking Begins](#prechecking-training)


### Publishing Overview

Once a work has been uploaded to Door43, it is automatically available online under your user account.  This is referred to as self-publishing.  You will have access to a web version of your project at [http://door43.org/u/user_name/project_name](http://door43.org/u/user_name/project_name) (where user_name is your username and project_name is your translation project).  The translationStudio app will give you the correct link when you upload.  You can also browse all works on [http://door43.org](http://door43.org).

From your Door43 project page you can:

* See the web version of your project with default formatting
* Download documents of your project (like a PDF)
* Get the links to the source files (USFM or Markdown) for your project
* Interact with others about your project

---

### <a id="source-text_process"/>Source Text Process

## 6. Distributing

### <a id="intro-share"/>Introduction to Distribution

*This page answers the question: How can I distribute content?*

*In order to understand this topic, it would be good to read:*

  * [Introduction to Publishing](#intro-publishing)


### Distribution Overview

Content is worthless unless it is disseminated and used. One advantage of using the Door43 translation and publishing platform is that it provides multiple, simple ways of distributing content.

### Open License

The biggest factor that encourages distribution of content is the [Open License](intro.html#open-license) that is used for all content on Door43. This license gives everybody the freedom they need to:

  * **Share** — copy and redistribute the material in any medium or format
  * **Adapt** — remix, transform, and build upon the material 

for any purpose, even commercially.

Under the terms of the license.

*Next we recommend you learn about:*

  * [How to Share Content](#share-content)

---

### <a id="share-content"/>How to Share Content

*This page answers the question: How can I share content?*

*In order to understand this topic, it would be good to read:*

  * [Introduction to Distribution](#intro-share)


### Sharing Content from tS

Sharing content that is in translationStudio is easy.  For offine sharing, use the Backup feature from the tS menu.  For online sharing, use the Upload feature from the tS menu.

### Sharing Content on Door43

If you upload your work from translationStudio, then it automatically appears on the Internet on Door43.  All of your uploaded content will appear under your user account.  For example, if your username is *test_user* then you may find all your work at [http://door43.org/u/test_user/](http://door43.org/u/test_user/).  You can share your work with others online by giving them the link to the projects you have uploaded.

### Sharing Content Offline

You may also generate and download documents from your project pages on Door43.  Once you have these downloaded, you can transfer them to others however you would like, including printing and distributing hard copies.

---

