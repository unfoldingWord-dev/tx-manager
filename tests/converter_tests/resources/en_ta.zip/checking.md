# Checking Manual

## Introduction to Checking

### <a id="intro-check"/>Introduction to the Checking Manual

*This page answers the question: What is the Checking Manual?*

*In order to understand this topic, it would be good to read:*

  * [Introduction to Translation Manual](translate.html#translate-manual)


### Translation Checking Manual

This manual describes how to check translated biblical content for accuracy, clarity, and naturalness.

#### Volume One

Volume One contains instructions for checking the translation that the translation team will use to check each other's work. If they follow these instructions, they will complete checking level one. Volume One also contains instructions for the translation team to use for checking the translation with the language community for clarity and naturalness, and for church leaders to use when they check the translation for accuracy. If they follow these instructions, they will complete checking level two. This volume also contains instructions for the leaders of church networks to use for checking the translation for accuracy at level three.

#### Volume Two

Volume Two contains further instructions for checking the translation that the leaders of church networks can use to check the translation. Because many leaders of church networks do not speak the language of the translation, Volume Two also contains instructions for creating a back translation, which allows people to check a translation in a language that they do not speak.

*Next we recommend you learn about:*

  * [Introduction to Translation Checking](#intro-checking)

---

### <a id="intro-checking"/>Introduction to Translation Checking

*This page answers the question: Why do we do translation checking?*

*In order to understand this topic, it would be good to read:*

  * [Introduction to the Checking Manual](#intro-check)


### Translation Checking

#### Introduction

As part of the translation process, it is necessary that several people check the translation to make sure that it is clearly communicating the message that it should communicate. A beginning translator who was told to check his translation once said, "But I speak my native language perfectly. The translation is for that language. What more is needed?" What he said was true, but there are two more things to keep in mind. 

One thing is that he may not have understood the source text correctly, and so someone who knows what it should say might be able to correct the translation. This could be because he did not correctly understand a phrase or expression in the source language. In this case, someone else who understands the source language well can correct the translation. 

Or it could be that he did not understand something about what the Bible meant to communicate at a certain place. In this case, someone who knows the Bible well, such as a Bible teacher or a Bible translation checker, can correct the translation. 

The other thing is that, although the translator may know very well what the text should say, the way he translated it might mean something else to a different person. That is, another person might think that the translation is talking about something other than what the translator intended, or the person hearing or reading the translation might not understand what the translator was trying to say. That is why it is always necessary to check what someone else understands from the translation so that we can make it more accurate and more clear. 

This is a guide to the process of checking, in the form of a scale with three levels.

This checking scale helps to show the extent to which the accuracy and clarity of a translation have been verified. These checking levels have been developed by the unfoldingWord network (see [https://unfoldingword.org](https://unfoldingword.org) ), the same group that manages Door43 with the help of many volunteers, and they are used to indicate the checking level of all biblical content on Door43.

#### The Checking Levels

There are three checking levels: 

  * [Checking Level One - Affirmation by Translation Team](#level1) 
  * [Checking Level Two - Affirmation by Community](#level2)
  * [Checking Level Three - Affirmation by Church Leadership](#level3). 

Any translation that has not yet been checked to Level One is considered to have not been checked and is assigned no checking status.

The purpose of having several Checking Levels is to make translated materials quickly available to the church, while also allowing the content to continue to be checked and corroborated in an open environment. At all times, the degree to which its accuracy has been checked will be clearly indicated. We believe this will result in a faster checking process, allow broad church participation and ownership, and produce better translations.

Credits: Quotation used by permission, © 2013, SIL International, Sharing Our Native Culture, p. 69.

*Next we recommend you learn about:*

  * [Introduction to the Checking Levels](#intro-levels)

---

### <a id="intro-levels"/>Introduction to the Checking Levels

*This page answers the question: How do the checking levels work?*

*In order to understand this topic, it would be good to read:*

  * [Introduction to Translation Checking](#intro-checking)


### How Checking Levels Work

Here are some important tips to remember when working with Checking Levels:

  * Only translations that have reached Checking Level One or higher will be made available on the unfoldingWord website and the unfoldingWord mobile app. (see [http://ufw.io/content/](http://ufw.io/content/))
  * Only translations that have reached Checking Level Three will be approved as source texts for other translations.
  * When a checking level has been completed and all appropriate edits have been made to the translation on door43, the checkers will inform unfoldingWord of the details of the check, including who did the checking and their title or qualifications as a translation checker. unfoldingWord will then harvest a copy of what is on door43, digitally publish a static copy of it on the unfoldingWord website (see [https://unfoldingword.org](https://unfoldingword.org) ) and make it available on the unfoldingWord mobile app. A print-ready PDF will also be produced and made available for download. It will continue to be possible to change the checked version on door43, allowing for future checking and editing.
  * For *Open Bible Stories* projects: Only *Open Bible Stories* translations that have been made from version 3.0 or higher of the English source text are eligible to be checked to Level One (or higher). Translations made from versions before 3.0 must be updated before proceeding with Checking Levels. (see [Source Texts and Version Numbers](translate.html#translate-source-version))

### The Checking Levels

The strategy for quality assurance of unfoldingWord content, including *Open Bible Stories*, is described briefly here and in detail at [http://ufw.io/qa/](http://ufw.io/qa/).

The three-level checking scale we use is dependent on the unfoldingWord [Translation Guidelines](intro.html#translation-guidelines). All translated content is compared against the theology of the Statement of Faith and against the procedures and methodologies of the Translation Guidelines. With these documents forming the foundation, these are the three levels of checking used in the unfoldingWord project:

  * [Checking Level One - Affirmation by Translation Team](#level1)
  * [Checking Level Two - Affirmation by Community](#level2)
  * [Checking Level Three - Affirmation by Church Leadership](#level3)

### Checking the Checkers

The process and checking framework described in this document depends on an ongoing process of checking and revising content, as determined by the Church that uses the content. Feedback loops are encouraged (and modeled in translation software, where feasible) with a view to maximizing input from the greatest number of users of the content. The translations of the content are made available on the translation platform (see [http://door43.org](http://door43.org) ), which is designed to make it easy for users to collaboratively create content that increases in quality over time.

*Next we recommend you learn about:*

  * [Introduction to the Checking Levels](#intro-levels)
  * [Checking Level One - Affirmation by Translation Team](#level1)
  * [Source Texts and Version Numbers](translate.html#translate-source-version)

---

### <a id="goal-checking"/>The Goal of Checking

*This page answers the question: What is the Goal of Checking?*

*In order to understand this topic, it would be good to read:*

  * [Introduction to the Checking Levels](#intro-levels)


### Why Check?

The goal of checking is to help the translation team produce a translation that is accurate, natural, clear, and accepted by the church. The translation team also wants to achieve this goal. This might seem easy, but it is actually very difficult to do, and takes many people and many, many revisions to the translation to achieve. For this reason, the checkers play a very important role in helping the translation team to produce a translation that is accurate, natural, clear, and accepted by the church. 

#### Accurate

The checkers who are pastors, church leaders, and leaders of church networks will help the translation team produce a translation that is accurate. They will do this by comparing the translation with the source language and, when possible, also with the original languages of the Bible. (For more information about accurate translations, see [Create Accurate Translations](translate.html#guidelines-accurate).)

#### Clear

The checkers who are members of the language community will help the translation team produce a translation that is clear. They will do this by listening to the translation and pointing out to them the places where the translation is confusing or does not make sense to them. Then the translation team can fix those places so that they are clear.  (For more information about clear translations, see [Create Clear Translations](translate.html#guidelines-clear).)

#### Natural

The checkers who are members of the language community will also help the translation team produce a translation that is natural. They will do this by listening to the translation and pointing out to them the places where the translation sounds strange and does not sound like the way that someone who speaks their language would say it. Then the translation team can fix those places so that they are natural.  (For more information about natural translations, see [Create Natural Translations](translate.html#guidelines-natural).)

#### Church-approved

The checkers who are members of a church in the language community will help the translation team produce a translation that is approved and accepted by the church in that community. They will do this by working together with members and leaders of other churches from the language community. When members and leaders that represent the churches of a language community work together and agree that the translation is good, then it will be accepted and used by the churches in that community. (For more information about translations that are approved by the church, see [Create Church-Approved Translations](translate.html#guidelines-church-approved).)

*Next we recommend you learn about:*

  * [Introduction to Translation Checking](#intro-checking)
  * [Checking Authority and Process](#authority-process)

---

## Types of Checks

### <a id="self-check"/>Self Check

*This page answers the question: How do I check my first draft?*

*In order to understand this topic, it would be good to read:*

  * [Checking Level One - Affirmation by Translation Team](#level1)


### How to do a Self-Check

  * If you have followed the guidelines for making a [First Draft](translate.html#first-draft) translation, then you made your first translation of a passage by studying the source text, and then you wrote it down while you were not looking at the source text. After you have translated a passage in this way, do a self-check by looking again at the source text and comparing it to your translation. Make sure that it says all the parts of the message of the source text and does not leave out anything. If some part of the message was missing, put it in your translation at the point where it fits best in your language.
  * If you are translating the Bible, compare your translation with other translations of the same Bible passage. If one of those makes you think of a better way to say something, then revise your translation in that way. If one of those helps you to understand something better than you did before, then change your translation so that it communicates the meaning better.
  * After these steps, read your translation out loud to yourself. Fix anything that does not sound like it is the way that someone from your community would say it. Sometimes parts of sentences need to be put in a different order.

*Next we recommend you learn about:*

  * [Peer Check](#peer-check)

---

### <a id="peer-check"/>Peer Check

*This page answers the question: How can others help me check my work?*

*In order to understand this topic, it would be good to read:*

  * [Checking Level One - Affirmation by Translation Team](#level1)
  * [Self Check](#self-check)


### How to do a Peer Check

   * Give your translation to a member of the translation team who did not work on this passage. Have that person go through all of the same steps of the Self Check, making note of any places that need fixing.
   * Review the translation together and fix those places.
   * Read the revised translation out loud to this person and fix anything that does not sound like it is the way that someone from your community would say it.

*Next we recommend you learn about:*

  * [translationWord Check](#important-term-check)

---

### <a id="important-term-check"/>translationWord Check

*This page answers the question: How can I check for the important words in my translation?*

*In order to understand this topic, it would be good to read:*

  * [Checking Level One - Affirmation by Translation Team](#level1)
  * [Peer Check](#peer-check)


### How to do a translationWord Check

  * Make a list of the translationWords in the story or Bible passage that you translate, along with the term that you choose for it in the target language. It is best if you can do this on a chart so that you can list the source word or phrase in one column and the target word or phrase in another column. Further columns could list equivalent terms in other languages and the references where these terms occur in the Bible. Make sure that everyone translating Bible books that use these terms has access to the chart so that you can all use the same words or phrases in your translation.
  * Use the list of words and definitions in the translationWords section of Door43 or translationStudio to help you to make a list of these words and to understand what they mean.
  * Each time the translationWord occurs in the source text, make sure that the term you have chosen for the translation still makes sense in that context. If it does not, discuss the problem with others on the translation team and try to find a solution together. You may need to use a different term, or you may need to use more than one term for the different contexts, or you may need to find another way to communicate the translationWord that includes all of the meanings, such as using a longer phrase.
  * When you have decided that you need to use different target language words or phrases to translate one source language translationWord in different contexts, then make a new line on the chart for each different way that you are translating the source translationWord. Repeat the source term in the source column, and put the new translation in the next column, under the first translation. Share this chart with everyone on the translation team so that they can choose the right translation for the source translationWord in the context that they are translating.

*Next we recommend you learn about:*

  * [Accuracy Check](#accuracy-check)

---

### <a id="accuracy-check"/>Accuracy Check

*This page answers the question: How can I do an accuracy check?*

*In order to understand this topic, it would be good to read:*

  * [Checking Level One - Affirmation by Translation Team](#level1)
  * [Create Accurate Translations](translate.html#guidelines-accurate)
  * [translationWord Check](#important-term-check)


### Checking the Translation for Accuracy

The purpose of this section is to make sure that the new translation is accurate. In other words, when compared with the source translation, does the new translation communicate the same meaning (not necessarily with the same wording or the exact order)? 

#### Level One

The people who do the Level One accuracy check can be members of the translation team, but they should <u>not</u> be the same people who translated the story or Bible passage that they are checking. They can also be members of the community who are not part of the translation team. They should be speakers of the language of the translation, be respected in the community, and, if possible, know the Bible well in the language of wider communication. The purpose of this step is to make sure that the translation accurately communicates the meaning of the original story or Bible passage. The checkers will be helping the translation team think about the best way to translate the meaning of the story or Bible passage in their own language. There can be one person who checks a story or Bible passage, or more than one. Having more than one person checking a story or passage can be helpful, because often different checkers will notice different things. 

#### Levels Two and Three

The people who do the Level Two or Level Three accuracy check should not be members of the translation team. They should be church leaders who speak the language of the translation and who know the Bible well in the source language. It is true that the language community members who do the [Language Community Check](#language-community-check) *must not* look at the source text while they check the translation for naturalness and clarity. But for accuracy testing, the accuracy checkers *must* look at the source text so that they can compare it with the new translation.

#### All Levels

The people doing the checking should follow these steps:

1. Each of the checkers should read the translation (or listen to the recording) by himself, comparing it to the original Bible passage or story in the language of wider communication. It can be helpful for the translator to read the translation out loud to the checker while the checker follows along looking at the source Bible or Bibles. As the checker reads (or listens to) the translation and compares it to the source, he should keep in mind these general questions:

  * Does the translation add anything to the original meaning? (The original meaning also includes [Implicit Information](translate.html#figs-explicit).)
  * Is there any part of the meaning that is left out of the translation?
  * Has the translation changed the meaning in any way?

1. The checker should make notes where he thinks there might be a problem or something to be improved. Each checker will discuss these notes with the translation team.

1. After the checkers have checked a Bible Story or chapter individually, they should all meet with the translator or translation team and review the story or Bible passage together. As they come to the places where each checker made note of a problem or question, the checkers can ask their questions or make suggestions for improvement. As the checkers and the translation team discuss the questions and suggestions, they might think of other questions or new ways of saying things. This is good. As the checkers and the translation team work together, God will help them discover the best way to communicate the meaning of the story or Bible passage. 

1. After the checkers and the translation team have decided what they need to change, the translation team will revise the translation. 

1. After the translation team revises the translation, they should read it out loud to each other or to other members of the language community to make sure that it still sounds natural in their language. 

1. The translator (or team) makes a note of any Bible passages that are still difficult to understand, and where they would like additional help from other Bible checkers. These notes will be used by the church leaders and checkers in levels two and three, so that they can help the translators understand the meaning and communicate it more clearly. 

##### Additional Questions

These questions can also be helpful for finding anything that might be inaccurate in the translation:

  * Was everything that was mentioned in the source language translation also mentioned in the flow of the new (local) translation? 
  * Did the meaning of the new translation follow the message (not necessarily the wording) of the source translation? (Sometimes if the arrangement of words or the order of ideas is different than in the source translation, it sounds better that way and is still accurate.)
  * Were the people introduced in each story doing the same things as those mentioned in the source language translation? (Was it easy to see who was doing the events of the new translation when it was compared to the source language?)
  * Are there translationWords used in the new translation that do not match your understanding of the words in the source version? Think about things like this: How do your people talk about a priest (one who sacrifices to God) or a temple (the sacrifice place of the Jews) without using a word borrowed from the source language?
  * Are the phrases used in the new translation helpful in understanding the more difficult phrases of the source translation? (Are the phrases of the new translation put together in a way that brings better understanding and still fit with the meaning of the source language translation?)
  * Another way to determine if the text is accurate is to ask comprehension questions about the translation, such as, "who did what, when, where, how, and why." There are questions that have already been prepared to help with this. (To view the translationQuestions go to [http://ufw.io/tq/](http://ufw.io/tq/).) The answers to those questions should be the same as the answers to those questions about the source language translation. If they are not, there is a problem in the translation.

*Next we recommend you learn about:*

  * [Checking Level Two - Affirmation by Community](#level2)
  * [Language Community Check](#language-community-check)
  * [Church Leader Check](#church-leader-check)
  * [Other Methods](#other-methods)
  * [Create Accurate Translations](translate.html#guidelines-accurate)

---

### <a id="language-community-check"/>Language Community Check

*This page answers the question: How can the language community help me check my work?*

*In order to understand this topic, it would be good to read:*

  * [Checking Level Two - Affirmation by Community](#level2)


### Language Community Check

After you, the translation team, have performed the checks listed under Level One, you are ready to take the translation to the community so that you can check to see if it communicates the message clearly and naturally to them in the target language. 

For this check you will read a section of the translation to members of the language community. Before you read the translation, tell the people listening that you want them to stop you if they hear something that is not natural in their language. (For more information on how to check a translation for naturalness, see [Natural Translation](#natural).)

There are a set of questions and answers for each *Open Bible Story* and for each chapter of the Bible that you can use to test the translation to make sure that it is communicating clearly. (See [http://ufw.io/tq/](http://ufw.io/tq/) for the questions.)

To use these questions, follow these steps:

1. Read the passage of the translation to one or more members of the language community who will answer the questions. These members of the language community must be people who have not been involved in the translation before. In other words, the community members who are asked the questions should not already know the answers to the questions from working on the translation or from previous knowledge of the Bible. We want them to be able to answer the questions only from hearing or reading the translation of the story or Bible passage. This is how we will know if the translation is communicating clearly or not. For this same reason, it is important that the community members not look at a Bible while they are answering these questions.

2. Ask the community members some of the questions for that passage, one question at a time. It is not necessary to use all of the questions for each story or chapter if it seems that the community members are understanding the translation well. 

3. After each question, a member of the language community will answer the question. If the person only answers with a "yes" or a "no," then the questioner should ask a further question so that he can be sure that the translation is communicating well. A further question could be something like, "How do you know that?" or "What part of the translation tells you that?"

4. Write down the answer that the person gives. If the person's answer is similar to the suggested answer that has been provided for the question, then the translation of the story is clearly communicating the right information at that point. The answer does not have to be exactly the same as the suggested answer to be a right answer, but it should give basically the same information. Sometimes the suggested answer is very long. If the person answers with only part of the suggested answer, that is also a right answer. 

5. If the answer is unexpected or very different than the suggested answer, or if the person cannot answer the question, then the translation team will need to revise the part of the translation that communicates that information so that it communicates the information more clearly.

6. After the translation team has revised the translation of the passage, then ask other members of the language community the same questions, that is, ask other speakers of the language who have not been involved in checking the same passage before. If they answer the questions correctly, then the translation is now communicating well.

7. Repeat this process with each story or Bible chapter until members of the language community can answer the questions well, showing that the translation is communicating the right information clearly. The translation is ready for the church check of level 2 when language community members who have not heard the translation before can answer the questions correctly.

8. Go to the Community Evaluation page and answer the questions there. (see [Language Community Evaluation Questions](#community-evaluation))

*Next we recommend you learn about:*

  * [Natural Translation](#natural)
  * [Other Methods](#other-methods)
  * [Decisions for Writing Your Language](translate.html#writing-decisions)
  * [Language Community Evaluation Questions](#community-evaluation)

---

### <a id="church-leader-check"/>Church Leader Check

*This page answers the question: How can the church leaders help improve the translation?*

*In order to understand this topic, it would be good to read:*

  * [Checking Level Two - Affirmation by Community](#level2)


### How to do a Church Leader Check

After the translation has been checked by community members for clarity, it will be checked by a group of church leaders for accuracy. This group must consist of at least three church leaders who are native speakers of the target language, and who understand well one of the languages in which the source text is available. They should not be related to, or otherwise closely connected with, the translation team. Usually these reviewers will be pastors. These church leaders should represent the different church networks in the language community. We recommend that the group includes church leaders from three different church networks, if the community has that many.

These reviewers should follow these steps:

  1. Read the [Translation Guidelines](intro.html#translation-guidelines) to make sure that the translation is in agreement with both of those as they review the translation.
  1. Answer the questions about the translator or translation team that are located at [Translator Qualifications](translate.html#qualifications).
  1. Verify that the translation has been done in a style that is acceptable to the intended audience by asking the questions at [Acceptable Style](#acceptable).
  1. Verify that the translation accurately communicates the meaning of the source text by following the guidelines at [Accuracy Check](#accuracy-check).
  1. Verify that the translation is complete by following the guidelines at [Complete Translation](#complete).
  1. After you have reviewed several chapters or one book of the Bible, meet with the translation team and ask about each problem. Discuss with the translation team how they might adjust the translation in order to fix the problems. Make plans to meet again with the translation team at a later time, after they have had time to adjust the translation and test it with the community.
  1. Meet again with the translation team to verify that they have fixed the problems.
  1. Affirm that the translation is good. See [Level 2 Affirmation](#good) to do that on the Level Two Affirmation page.

*Next we recommend you learn about:*

  * [Accuracy Check](#accuracy-check)
  * [Accurate Translation](#accurate)
  * [Level 2 Affirmation](#good)

---

### <a id="other-methods"/>Other Methods

*This page answers the question: What are some other methods that I can use to check the translation?*

*In order to understand this topic, it would be good to read:*

  * [Language Community Check](#language-community-check)


### Other Checking Methods

As well as asking questions, there are other checking methods that you may also use to ensure that the translation is easy to read and sounds natural to the listeners. Here are some other methods that you may like to try:

  * **Retell Method**:  You, the translator or tester, can read a few verses and ask someone else to retell what was said. This helps to check the clarity and naturalness of the translation and offers alternate ways of saying the same thing. 

  * **Reading Method**: Someone other than you, the translator or tester, should read a portion of the translation while you take notes where the pauses and mistakes occur. This will show how easy or how difficult it is to read and understand the translation. Look at the places in the translation where the reader paused or made mistakes and consider what part of the translation was difficult. You may need to revise the translation at those points so that it is easier to read and understand.

  * **Offer Alternate translations**: In areas where you are not sure of the best way to express a word or phrase, ask other people for an alternative translation or offer a choice between two translations and see which alternative translation people think is the most clear. 

  * **Reviewer Input**: Let others whom you respect read your translation. Ask them to take notes and tell you where it might be improved. Look for better word choices, natural expressions, and even spelling adjustments. 

  * **Discussion Groups**: Ask people to read the translation aloud in a group of people and allow them and others to ask questions for clarification. Pay attention to the words they use, since alternate words and expressions come up when someone is trying to make sense of a difficult point, and these alternate words and expressions might be better than the ones in the translation. Pay attention to the places where people do not understand the translation, and work to make those places clearer.

*Next we recommend you learn about:*

  * [Decisions for Writing Your Language](translate.html#writing-decisions)
  * [Language Community Evaluation Questions](#community-evaluation)

---

## What to Check For

### <a id="accurate"/>Accurate Translation

*This page answers the question: Is the translation accurate?*

*In order to understand this topic, it would be good to read:*

  * [Appropriate Alphabet](#alphabet)
  * [Church Leader Check](#church-leader-check)


### An Accurate Translation

It is very important to make sure that the new translation is accurate. Those who have been chosen to check the translation for accuracy have the responsibility to make sure that it communicates the same meaning as the original writer intended and expected to communicate.  

For instructions on how to do this, go to [Accuracy Check](#accuracy-check), and follow the steps in the section under the heading "All Levels."

*Next we recommend you learn about:*

  * [Complete Translation](#complete)
  * [Accuracy Check](#accuracy-check)
  * [Create Accurate Translations](translate.html#guidelines-accurate)

---

### <a id="clear"/>Clear Translation

*This page answers the question: How can I tell if the translation is clear?*

*In order to understand this topic, it would be good to read:*

  * [Checking Level Two - Affirmation by Community](#level2)


### A Clear Translation

Ask yourself questions like the following as you read the translation to see if the translated message is clear. For this section of testing, do not compare the new translation with the source language translation. If there is a problem at any place, make a note of it so that you can discuss the problem with the translation team at a later time. 

  1. Do the words and phrases of the translation make the message understandable? (Are the words confusing, or do they tell you plainly what the translator means?)
  1. Do your community members use the words and expressions found in the translation, or has the translator borrowed many words from the national language? (Is this the way your people talk when they want to say important things in your language?)
  1. Can you read the text easily and understand what the writer might say next? (Is the translator using a good style of telling the story? Is he telling things in a way that makes sense, so that each section fits with what came before and what comes after?)

Additional help: 

  * One way to determine if the text is clear is to read a few verses at a time out loud and ask someone listening to retell the story after each section. If the person can easily restate your message, then the writing is clear. 
  * If there is a place where the translation is not clear, make a note of that so that you can discuss it with the translation team.

*Next we recommend you learn about:*

  * [Acceptable Style](#acceptable)
  * [Natural Translation](#natural)
  * [Create Clear Translations](translate.html#guidelines-clear)
  * [Language Community Check](#language-community-check)

---

### <a id="natural"/>Natural Translation

*This page answers the question: Is the translation natural?*

*In order to understand this topic, it would be good to read:*

  * [Appropriate Alphabet](#alphabet)
  * [Checking Level Two - Affirmation by Community](#level2)
  * [Clear Translation](#clear)


### A Natural Translation

To translate the Bible so that it is NATURAL means that: 

The translation should sound like it was written by a member of the target language community—not by a foreigner.

To check a translation for naturalness, it is not helpful to compare it to the source language. During this check for naturalness, no one should look at the source language Bible. People will look at the source language Bible again for other checks, such as the check for accuracy, but not during this check.

To check a translation for naturalness, you or another member of the language community must read it out loud. You can read it to one other person who speaks the target language or to a group of people. Before you start reading, tell the people listening that you want them to stop you when they hear something that does not sound like the way someone from your language community would say it. When someone stops you, then you can discuss together how someone would say that same thing in a more natural way.

It is helpful to think about a situation in your village in which people would talk about the same kind of thing that the translation is talking about. Imagine people that you know talking about that thing, and then say it out loud in that way. If others agree that that is a good and natural way to say it, then write it that way in the translation.

*Next we recommend you learn about:*

  * [Acceptable Style](#acceptable)
  * [Create Natural Translations](translate.html#guidelines-natural)
  * [Language Community Check](#language-community-check)

---

### <a id="acceptable"/>Acceptable Style

*This page answers the question: Did the translation team use an acceptable style?*

*In order to understand this topic, it would be good to read:*

  * [Clear Translation](#clear)
  * [Natural Translation](#natural)
  * [Church Leader Check](#church-leader-check)


### Translation in an Acceptable Style

As you read the new translation, ask yourself these questions. These are questions that will help determine whether or not the translation has been done in a style that is acceptable to the language community: 

  1. Is the translation written in a way that can be understood easily by both young and old members of the language community? (Whenever someone speaks, they can change their choice of words for either a younger or an older audience. Is this translation done using words that communicate well to both young and old people?
  1. Is the style of this translation more formal or informal? (Is the manner of speaking the way that the local community prefers, or should it be more or less formal?)
  1. Does the translation use too many words that were borrowed from another language, or are these words acceptable to the language community? 
  1. Did the writer use an appropriate form of the language acceptable to the wider language community? (Is the writer familiar with the dialects of your language found throughout the area? Did the writer use a form of the language that all of the language community understands well, or did he use a form that is used in only a small area?

If there is a place where the translation uses language in the wrong style, make a note of that so that you can discuss it with the translation team.

*Next we recommend you learn about:*

  * [Appropriate Alphabet](#alphabet)
  * [Complete Translation](#complete)

---

### <a id="complete"/>Complete Translation

*This page answers the question: Is the translation complete?*

*In order to understand this topic, it would be good to read:*

  * [Accurate Translation](#accurate)


### A Complete Translation

The purpose of this section is to make sure that the translation is complete. In this section, the new translation must be compared to the source translation. As you compare the two translations, ask yourself these questions: 

  1. Is the translation missing any of its parts? In other words, does the translation include all the events of the book that was translated?
  1. Does the translation include all the verses of the book that was translated? (When you look at the verse numbering of the source language translation, are all of the verses included in the target language translation?) Sometimes there are differences in verse numbering between translations. For example, in some translations some verses are grouped together or sometimes certain verses are put in footnotes. Even though there may be these kinds of differences between the source translation and the target translation, the target translation is still considered to be complete.
  1. Are there places in the translation where something seems to be left out, or there seems to be a different message than is found in the source language translation? (The wording and the order can be different, but the language that the translator used should give the same message as the source language translation.)

If there is a place where the translation is not complete, make a note of that so that you can discuss it with the translation team.

*Next we recommend you learn about:*

  * [Self-Assessment Rubric](#self-assessment)
  * [Level 2 Affirmation](#good)

---

### <a id="self-assessment"/>Self-Assessment Rubric

*This page answers the question: How can I objectively assess the quality of the translation?*

*In order to understand this topic, it would be good to read:*

  * [Complete Translation](#complete)
  * [Church Leader Check](#church-leader-check)
  * [Checking Level Three - Affirmation by Church Leadership](#level3)


### Self-assessment of Translation Quality

The objective of this section is to describe a process by which the Church can reliably determine for themselves the quality of a translation. This following assessment is intended to suggest some of the most important techniques for checking a translation, rather than to describe every conceivable check that could be employed. Ultimately, the decision of what checks are used, when, and by whom should be made by the Church.

#### How to Use the Assessment

This assessment method employs two types of statements. Some are "yes/no" statements where a negative response indicates a problem that must be resolved. Other sections use an equally-weighted method that provides translation teams and checkers with statements about the translation. Each statement should be scored by the person doing the check (beginning with the translation team) on a scale of 0-2:

**0** - disagree

**1** - agree somewhat

**2** - strongly agree

At the end of the review, the total value of all responses in a section should be added up and, if the responses accurately reflect the state of the translation, this value will provide the reviewer with an approximation of the probability that the translated chapter is of excellent quality. The rubric is designed to be simple and provide the reviewer with an objective method to assess where the work needs improvement. *For example, if the translation scores relatively well in "Accuracy" but quite poorly in "Naturalness" and "Clarity," then the translation team needs to do more community checking.*

The rubric is intended to be used for each chapter of translated biblical content. The translation team should do an assessment of each chapter after they finish their other checks, and then the level 2 church checkers should do it again, and then the level 3 checkers should also assess the translation with this checklist. As more detailed and extensive checking of the chapter is performed by the Church at each level, the points for the chapter should be updated from each of the first four sections (overview, naturalness, clarity, accuracy), allowing the church and community to see how the translation is improving. 

#### The Self-Assessment

The process is divided into five parts: the **overview** (information about the translation itself), **naturalness**, **clarity**, **accuracy**, and **Church approval**.

##### 1. Overview

*Circle either "no" or "yes" for each statement below.* 

**no | yes** This translation is a meaning-based translation that attempts to communicate the meaning of the original text in ways that are natural, clear, and accurate in the target language.

**no | yes** Those involved in checking the translation are first-language speakers of the target language.

**no | yes** The translation of this chapter is in agreement with the Statement of Faith.

**no | yes** The translation of this chapter has been done in accordance with the Translation Guidelines.

##### 2. Naturalness: "this is *my* language"

*Circle either "0" or "1" or "2" for each statement below.* 

This section can be strengthened through doing more community checking. (See [Language Community Check](#language-community-check))

**0 1 2** Those who speak this language and have heard this chapter agree that it is translated using the correct form of the language.

**0 1 2** Those who speak this language agree that the key words used in this chapter are acceptable and correct for this culture.

**0 1 2** The illustrations or stories in this chapter are easy for people who speak this language to understand.

**0 1 2** Those who speak this language agree that the sentence structure and order of the text in this chapter is natural and flows correctly.

**0 1 2** The review of the translation of this chapter for naturalness included community members who have not been directly involved in creating the translation of this chapter.

**0 1 2** The review of the translation of this chapter for naturalness included both believers and non-believers, or at least believers who are relatively unfamiliar with the Bible so that they do not know what the text is supposed to say before they hear it.

**0 1 2** The review of the translation of this chapter for naturalness included speakers of the language from many different age groups.

**0 1 2** The review of the translation of this chapter for naturalness included both men and women.

##### 3. Clarity: "the meaning is clear"

*Circle either "0" or "1" or "2" for each statement below.*  

This section can be strengthened through doing more community checking. (See [Language Community Check](#language-community-check))

**0 1 2** This chapter is translated using language that native speakers of the language agree is easy to understand.

**0 1 2** Speakers of this language agree that the translations of names, places, and verb tenses are all correct in this chapter.

**0 1 2** Figures of speech in this chapter make sense for people in this culture.

**0 1 2** Speakers of this language agree that the way this chapter is structured does not distract from the meaning.

**0 1 2** The review of the translation of this chapter for clarity included community members who have not been directly involved in creating the translation of this chapter.

**0 1 2** The review of the translation of this chapter for clarity included both believers and non-believers, or at least believers who are relatively unfamiliar with the Bible so that they do not know what the text is supposed to say before they hear it.

**0 1 2** The review of the translation of this chapter for clarity included speakers of the language from many different age groups.

**0 1 2** The review of the translation of this chapter for clarity included both men and women.

##### 4. Accuracy: "the translation communicates what the original source text communicated"

*Circle either "0" or "1" or "2" for each statement below.* 

This section can be strengthened through doing more accuracy checking. (See [Accuracy Check](#accuracy-check))

**0 1 2** A complete list of all important words in the source text for this chapter has been used to help ensure all terms are present in the translation.

**0 1 2** All important words are translated correctly in this chapter.

**0 1 2** All important words are translated consistently in this chapter, as well as in other places where the important words appear.

**0 1 2** Exegetical resources have been used for the entire chapter to identify and resolve potential translation challenges, including the Notes and translationWords.

**0 1 2** Historical details in the source text (like names, places, and events) have been preserved in the translation.

**0 1 2** The meaning of each figure of speech in the translated chapter has been compared and aligned to the intent of the original.

**0 1 2** The translation has been tested with native speakers who were not involved in creating the translation and they agree that the translation accurately communicates the intended meaning of the source text.

**0 1 2** The translation of this chapter has been compared against at least two source texts.

**0 1 2** All questions or disagreements about any of the meaning in this chapter have been resolved.

**0 1 2** The translation of this chapter has been compared against the original texts (Hebrew, Greek, Aramaic) to check for correct lexical definitions and intent of the original texts.

##### 5. Church approval: "the naturalness, clarity, and accuracy of the translation is approved by the Church that speaks that language"

*Circle either "0" or "1" or "2" for each statement below.* 

**no | yes** Church leaders who have checked this translation are native speakers of the target language, and include someone who understands well one of the languages in which the source text is available.

**no | yes** People from the language community, both men and women, old and young, have reviewed the translation of this chapter and agree that it is natural and clear. *(Note: this addresses the first part of the community check for Level 2.)* 

**no | yes** Church leaders from at least two different church networks have reviewed the translation of this chapter and agree that it is accurate. *(This addresses the final aspect of Level 2, the Church check).* 

**no | yes** The leadership or their delegates of at least two different church networks have reviewed the translation of this chapter and endorse it as a faithful translation of this chapter of the Bible in this language. *(This addresses Level 3.)*

*Next we recommend you learn about:*

  * [Level 2 Affirmation](#good)
  * [Accuracy Check](#accuracy-check)
  * [Language Community Check](#language-community-check)
  * [Accurate Translation](#accurate)
  * [Clear Translation](#clear)
  * [Natural Translation](#natural)
  * [Questions for Checking on Level Three](#level3-questions)
  * [Level 3 Approval](#level3-approval)

---

## Defining Church Authority

### <a id="authority-process"/>Checking Authority and Process

*This page answers the question: What is the difference between the authority to check a Bible translation and the process for checking?*

*In order to understand this topic, it would be good to read:*

  * [The Goal of Checking](#goal-checking)


### Explanation

The Church in each people group has the authority to decide for themselves what is and what is not a good quality translation of the Bible in their language. Authority to check and approve a Bible translation (which is constant) is separate from capacity, or the ability to carry out the process of checking a Bible translation (which can be increased). The authority for determining quality belongs to the Church, independent of their current ability, experience, or access to resources that facilitate the checking of Bible translations. So while the church in a language group has the authority to check and approve their own Bible translation, the unfoldingWord tools, including these modules of translationAcademy, are designed to ensure that the church also has the capacity to check the quality of their Bible translation using an excellent process. 

This model proposes a three-tiered approach to affirming the quality of a translation, designed to reflect three general levels of Church authority within a people group:

  * [Authority Level 1](#authority-level1): Determined by the Church-based translation team
  * [Authority Level 2](#authority-level2): Determined by the agreement of pastors/elders who are members of different Church networks in the language group, and tested with the language community
  * [Authority Level 3](#authority-level3): Determined by the leadership of Church networks with a presence in the people group that speaks the language

The process for checking a translation will be described in the modules under the heading "Checking Process."

*Next we recommend you learn about:*

  * [Authority Level 1](#authority-level1)
  * [Checking Level One - Affirmation by Translation Team](#level1)

---

### <a id="authority-level1"/>Authority Level 1

*This page answers the question: What is authority level 1?*

*In order to understand this topic, it would be good to read:*

  * [Checking Authority and Process](#authority-process)


### Authority Level 1: Affirmation by Translation Team

The intent of this level is to affirm the agreement of the translation team with standard Christian doctrine, as well as with the guidelines for ensuring the accuracy of the translation itself. Content published at this level promotes the broadest reach of the content as an active project, with an open invitation (implied or direct) to members of the language community to suggest improvements to the translation.

To achieve this level, the translation team asserts that the [Statement of Faith](intro.html#statement-of-faith) is an accurate reflection of their own beliefs and that the translated content is also in harmony with it.

The translator (or team) asserts that the translation has been done in accordance with the [Translation Guidelines](intro.html#translation-guidelines) and that they have made use of available exegetical and translation checking resources in the translation process, including the translationNotes and translationWords.

*Next we recommend you learn about:*

  * [Authority Level 2](#authority-level2)
  * [Checking Level One - Affirmation by Translation Team](#level1)

---

### <a id="authority-level2"/>Authority Level 2

*This page answers the question: What is authority level 2?*

*In order to understand this topic, it would be good to read:*

  * [Authority Level 1](#authority-level1)


### Authority Level 2: Affirmation by Community

The intent of this level is two-fold: 

1. to affirm the effectiveness of the form of the language used in the translation, as determined by representatives of the language community 
2. to affirm the accuracy of the translation, as determined by pastors or leaders from the local churches that will use it 

At this level, the model implements the concept of a "testimony of two or three witnesses" in the checking process.

To achieve this level, the translation team will submit the translation to members of the language community that will use the translation. The language community will review the translation for **clarity** and **naturalness**. 

The translation team will then submit the translation to church leaders from the language community that will use the translation. These church leaders will review the translation for **accuracy** by checking it against the source texts, the exegetical resources, the [Statement of Faith](intro.html#statement-of-faith), and the [Translation Guidelines](intro.html#translation-guidelines).

The translation team will edit the translation based on these reviews so that the language community affirms that it is natural and clear, and so that the church leaders affirm that it is accurate.

*Next we recommend you learn about:*

  * [Authority Level 3](#authority-level3)

---

### <a id="authority-level3"/>Authority Level 3

*This page answers the question: What is authority level 3?*

*In order to understand this topic, it would be good to read:*

  * [Authority Level 2](#authority-level2)


### Authority Level 3: Affirmation by Church Leadership

The intent of this level is to affirm that the translation agrees with the intent of the original texts and with the sound doctrine of the Church historic and universal. 

To achieve this level, the translation team will submit the translation for review by the highest leadership of the Church that speaks the language. It is best if these leaders represent as many of the major groups of churches that exist in the language community as possible. Level 3 is thus achieved by the mutual agreement of the leadership of multiple church networks.

The translation team will edit the translation so that the leadership of these church networks affirm that it is an accurate translation and will be accepted by their church fellowships.

Level 3 is completed when the translation has been thoroughly checked and approved by the leadership (or their delegates) of at least two church networks that have personnel that are familiar with translation principles and are trained in biblical languages and content.

*Next we recommend you learn about:*

  * [Checking Level Three - Affirmation by Church Leadership](#level3)
  * [Checking Level One - Affirmation by Translation Team](#level1)

---

## Checking Process

### <a id="level1"/>Checking Level One - Affirmation by Translation Team

*This page answers the question: How do I do a level one check?*

*In order to understand this topic, it would be good to read:*

  * [Introduction to the Checking Levels](#intro-levels)


### Checking Level One – Translation Team Check

Level One checking will be done primarily by the translation team, with some help from others in the language community. The translator or translation team should check their translation before they translate very many stories or chapters of the Bible, so that they can correct mistakes as early as possible in the translation process. Many of the steps in this process will need to be done several times before the translation is finished.

For the purposes of the unfoldingWord project, translations of Bible texts and biblical content are able to be published after they reach Checking Level One. This enables the broadest reach of the content as an active project, with an open invitation to others in the language community (implied or direct) to help improve the translation. 

### Steps for checking under Level One:

These are the steps that the translation team must follow in order to achieve Checking Level One:

  1. **Contact.**  Make contact with at least one element of the unfoldingWord network, notifying unfoldingWord that you intend to begin translation. To get information about how to do that, see [Finding Answers](intro.html#finding-answers)
  1. **Review.**  Review the [Translation Guidelines](intro.html#translation-guidelines).
  1. **Agree.**  Agree that the Statement of Faith is an accurate reflection of your own beliefs and that you intend to translate the content in harmony with it and also in accordance with the Translation Guidelines by signing the form. (see [http://ufw.io/forms/](http://ufw.io/forms/))
  1. **Draft.**  Make a draft translation of some portions of the text. For instructions on how to make a draft translation, see [First Draft](translate.html#first-draft)
  1. **Self Check**. For instructions on how to do a Self Check of your draft translation, see [Self Check](#self-check).
  1. **Peer Check**. For instructions on how to do a Peer Check of your draft translation, see [Peer Check](#peer-check).
  1. **translationWord Check**. For instructions on how to do an translationWord Check of your draft translation, see [translationWord Check](#important-term-check).
  1. **Accuracy Check**. For instructions on how to do an Accuracy Check of your draft translation, see [Accuracy Check](#accuracy-check).
  1. **Affirmation**. Affirm that you, as a translation team or individual, have made full use of the translationNotes, the definitions of translationWords, and the other exegetical and translation checking resources in the translation process, and that you have followed the steps for checking under Level One. 

(For instructions on how to affirm completion of Level One, see [Level 1 Affirmation](#level1-affirm).)

*Next we recommend you learn about:*

  * [Statement of Faith](intro.html#statement-of-faith)
  * [Translation Guidelines](intro.html#translation-guidelines)
  * [Accuracy Check](#accuracy-check)

---

#### <a id="level1-affirm"/>Level 1 Affirmation

*This page answers the question: How do I affirm that I have finished level 1 checking?*

*In order to understand this topic, it would be good to read:*

  * [Statement of Faith](intro.html#statement-of-faith)
  * [Translation Guidelines](intro.html#translation-guidelines)
  * [Checking Level One - Affirmation by Translation Team](#level1)
  * [Accuracy Check](#accuracy-check)


### Proper Documentation for Level 1 Affirmation

We, the members of the translation team, affirm that we have completed the steps below for level 1 checking:

  * Initial study of the text, using: 
    * The translationNotes 
    * The definitions of translationWords
  * Individual blind drafting
  * Individual self check
  * Peer check
  * Key word check as a team
  * Verse-by-verse accuracy check as a team
  * Final editing, including everything learned from the earlier editing sessions, the translationNotes, and the definitions of translationWords

Names of translation team members:

  * Name or pseudonym: 
  * Name or pseudonym: 
  * Name or pseudonym: 
  * Name or pseudonym: 
  * Name or pseudonym: 
  * Name or pseudonym:

*Next we recommend you learn about:*

  * [Checking Level Two - Affirmation by Community](#level2)

---

### <a id="level2"/>Checking Level Two - Affirmation by Community

*This page answers the question: How do I do a level 2 check?*

*In order to understand this topic, it would be good to read:*

  * [Introduction to the Checking Levels](#intro-levels)
  * [Accuracy Check](#accuracy-check)


### Checking Level Two - External Check

The purpose of Level Two checking is to verify that representative groups from the local language community agree that the translation is a good one.

Level Two checking will be done in two ways:

  1. **Language Community Check**. The translation will be checked by members of the language community to make sure that it is clear, natural, and understandable. For the steps to follow to do the Language Community Check, see [Language Community Check](#language-community-check).
  1. **Church Leader Check**. The translation will be checked by a group of church leaders from the language community to make sure that it is accurate. For the steps to follow to do the Church Leader Check, see [Church Leader Check](#church-leader-check).

Once this has been done, this work needs to be affirmed (see [Level 2 Affirmation](#good)).

*Next we recommend you learn about:*

  * [Language Community Check](#language-community-check)
  * [Church Leader Check](#church-leader-check)
  * [Self-Assessment Rubric](#self-assessment)
  * [Level 2 Affirmation](#good)

---

#### <a id="community-evaluation"/>Language Community Evaluation Questions

*This page answers the question: How can I show that the community approves the translation?*

*In order to understand this topic, it would be good to read:*

  * [Language Community Check](#language-community-check)
  * [Other Methods](#other-methods)
  * [Decisions for Writing Your Language](translate.html#writing-decisions)


We, the members of the translation team, affirm that we have checked the translation with members of the language community. 

  * We have checked the translation with old people and young people, and with men and women.
  * We used the translationQuestions when we checked the translation with the community.
  * We corrected the translation to make it clearer and easier to understand in the places where the community members did not understand it well.

Please also answer the following questions. The answers to these questions will help those in the wider Christian community know that the target language community finds the translation to be clear, accurate, and natural. 

  * List a few passages where the community feedback was helpful. How did you change these passages to make them clearer?
<br>
<br>
<br>

  * Write an explanation for some of the Important Terms, explaining how they are equal to terms used in the source language. This will help the checkers understand why you chose these terms.
<br>
<br>
<br>

  * Does the community verify that there is a good flow to the language when the passages are read out loud? (Does the language sound like the writer was a person from your own community?)
<br>
<br>
<br>

The community leaders might want to add their own information to this or make a summary statement about how acceptable this translation is to the local community. This can be included as part of the Level Two Community Check Evaluation information. The wider church leadership will have access to this information, and it will help them validate the translation as approved by the local Christian community when they do the Level Two Church Check and also Level Three Checking.

*Next we recommend you learn about:*

  * [Church Leader Check](#church-leader-check)
  * [Self-Assessment Rubric](#self-assessment)

---

#### <a id="good"/>Level 2 Affirmation

*This page answers the question: How can church leaders affirm that the translation is good?*

*In order to understand this topic, it would be good to read:*

  * [Complete Translation](#complete)


### Proper Documentation for Level Two Affirmation

We, as church leaders in our language community, affirm the following: 

  1. The translation conforms to the Statement of Faith and Translation Guidelines.
  1. The translation is accurate and clear in the target language.
  1. The translation uses an acceptable style of the language.
  1. The translation uses an appropriate alphabet and system of spelling.
  1. The community approves of the translation.
  1. The community evaluation form has been completed.

If there are any remaining problems, make a note of them here for the attention of the Level Three Checkers. 

Names and positions of the level 2 checkers:

  * Name:
    * Position:
  * Name:
    * Position:
  * Name:
    * Position:
  * Name:
    * Position:
  * Name:
    * Position:
  * Name:
    * Position:

*Next we recommend you learn about:*

  * [Self-Assessment Rubric](#self-assessment)
  * [Checking Level Three - Affirmation by Church Leadership](#level3)

---

### <a id="level3"/>Checking Level Three - Affirmation by Church Leadership

*This page answers the question: How do I do a level 3 check?*

*In order to understand this topic, it would be good to read:*

  * [Introduction to the Checking Levels](#intro-levels)
  * [Checking Level Two - Affirmation by Community](#level2)
  * [Accuracy Check](#accuracy-check)


### Checking Level Three - Authenticated Check

Level Three checking will be done by groups or organizations that are recognized by the churches in a language community. The leaders from these groups will verify that they approve of the distribution and use of the translation among the people affiliated with them. This approval is not required for distribution of the translation, but rather serves to validate it.

Those who do Level Three checking need to be other than the people who did Level Two checking.

The intent of this level is to affirm the alignment of the translation with the intent of the original texts and the sound doctrine of the Church historic and universal, through the review and affirmation by the leadership of the Church that speaks the language. Level 3 is thus achieved by the mutual agreement of the leadership of multiple church networks. The Church networks should be representative of the churches in the language community. Those checking the translation should be first-language speakers of the language, and those signing off on the check are those in leadership roles in the Church networks. A leader of a Church network who is also a first-language speaker of the language of the translation could both check the translation and sign off on its quality. 

Level 3 is completed when the translation has been thoroughly checked and approved by the leadership (or their delegates) of at least two church networks that have personnel trained in biblical languages and content.

To proceed with Level Three checking, go to [Questions for Checking on Level Three](#level3-questions).

*Next we recommend you learn about:*

  * [Questions for Checking on Level Three](#level3-questions)
  * [Self-Assessment Rubric](#self-assessment)

---

#### <a id="level3-questions"/>Questions for Checking on Level Three

*This page answers the question: What do I look for in a level 3 check?*

*In order to understand this topic, it would be good to read:*

  * [Checking Level Three - Affirmation by Church Leadership](#level3)


### Questions for Level Three

These are the questions for the Level Three checkers to keep in mind as they read the new translation.

You can answer these questions after you read portions of the translation or as you come across problems in the text. If you answer "no" to any of these questions in the first group, please explain in more detail, include the specific passage that you feel is not right, and give your recommendation for how the translation team should correct it.

Keep in mind that the goal of the translation team is to express the meaning of the source text in a natural and clear way in the target language. This means that they may have needed to change the order of some clauses and that they had to represent many single words in the source language with multiple words in the target language. These things are not considered to be problems in Other Language (OL) translations. The only times that translators should avoid making these changes is for Gateway Language (GL) translations of the ULB and UDB. The purpose of the ULB is to show the OL translator how the original biblical languages expressed the meaning, and the purpose of the UDB is to express that same meaning in simple, clear forms, even though it might be more natural to use an idiom in the OL. GL translators need to remember those guidelines. But for OL translations, the goal is always to be natural and clear.

Also keep in mind that the translators may have included information that the original audience would have understood from the original message, but that the original author did not state explicitly. When this information is necessary for the target audience to understand the text, it is good to include it explicitly. For more about this, see [Implicit and Explicit Information](translate.html#figs-explicit).

  1. Does the translation conform to the Statement of Faith and Translation Guidelines?
  1. Did the translation team show a good understanding of the source language as well as the target language and culture?
  1. Does the language community affirm that the translation speaks in a clear and natural way in their language?
  1. Which of the following translation styles did the translators appear to follow?
      1. word-by-word translation, staying very close to the form of the source translation
      1. phrase by phrase translation, using natural language phrase structures
      1. meaning-focused translation, aiming for a freedom of local language expression
  1. Do the community leaders feel that the style that the translators followed (as identified in question 4) is appropriate for the community?
  1. Do the community leaders feel that the dialect that the translators used is the best one to communicate to the wider language community? For example, have the translators used expressions, phrase connectors, and spellings that will be recognized by most people in the language community?
  1. As you read the translation, think about cultural issues in the local community that might make some passages in the book difficult to translate. Has the translation team translated these passages in a way that makes the message of the source text clear, and avoids any misunderstanding that people might have because of the cultural issue?
  1. In these difficult passages, do the community leaders feel that the translator has used language that communicates the same message that is in the source text?
  1. In your judgment, does the translation communicate the same message as the source text? If any part of the translation causes you to answer "no," please answer the second group of questions below.

If you answer "yes" to any of the questions in this second group, please explain in more detail so that the translation team can know what the specific problem is, what part of the text needs correction, and how you would like them to correct it.

  1. Are there any doctrinal errors in the translation?
  1. Did you find any areas of the translation that seem to contradict the national language translation or the important matters of faith found in your Christian community?
  1. Did the translation team add extra information or ideas that were not part of the message in the source text? (Remember, the original message also includes [Implicit Information](translate.html#figs-explicit).)
  1. Did the translation team leave out information or ideas that were part of the message in the source text?

If there were problems with the translation, make plans to meet with the translation team and resolve these problems. After you meet with them, the translation team may need to check their revised translation with the community leaders to make sure that it still communicates well, and then meet with you again. 

When you are ready to approve the translation, go here: [Level 3 Approval](#level3-approval).

*Next we recommend you learn about:*

  * [Accuracy Check](#accuracy-check)
  * [Level 3 Approval](#level3-approval)
  * [Self-Assessment Rubric](#self-assessment)

---

#### <a id="level3-approval"/>Level 3 Approval

*This page answers the question: How can I affirm a Level 3 approval of the translation?*

*In order to understand this topic, it would be good to read:*

  * [Checking Level Three - Affirmation by Church Leadership](#level3)
  * [Questions for Checking on Level Three](#level3-questions)
  * [Self-Assessment Rubric](#self-assessment)


### Proper Documentation for Level Three Affirmation

I, as a representative of the *<u>fill in name of church network or Bible translation organization</u>* Church Network or Bible translation organization serving the *<u>fill in the name of the language community</u>* language community, approve of the translation, and affirm the following:

  1. The translation conforms to the Statement of Faith and Translation Guidelines.
  1. The translation is accurate and clear in the target language.
  1. The translation uses an acceptable style of the language.
  1. The community approves of the translation.

If any problems remain unresolved after meeting with the translation team a second time, please make note of them here.

Signed: *<u>sign here</u>*

Position: *<u>fill in your position here</u>*

For Gateway Languages, you will need to follow the [Source Text Process](process.html#source-text-process) so that your translation can become a source text.

---

## <a id="vol2-intro"/>Introduction to Translation Checking - Part 2

*This page answers the question: Why should I check someone else's translation?*

*In order to understand this topic, it would be good to read:*

  * [Church Leader Check](#church-leader-check)
  * [Checking Level Three - Affirmation by Church Leadership](#level3)


The translation team will do a lot of checking of their own translation, as we saw in Translation Manual Volume One. Those checks bring their work up to checking Level One. Then they need to have their work checked by others in order to meet the requirements of Level Two and Level Three. 

For Level Two and Level Three, the translation team needs to bring their work to members of the language community and to the church leaders. This is necessary because the translation team is very close to and involved in their work, and so they sometimes do not see mistakes that others can see more easily. Other speakers of the language can suggest better ways of saying things that the translation team may not have thought of. Sometimes the translation team makes the translation sound strange because they are following the words of the source language too closely. Other speakers of the language can help them fix that. Also, the translation team may lack some of the expertise or knowledge of the Bible that others have, and so there may be some mistakes that others can correct for them. For these reasons, people that are not part of the translation team need to check the translation.

Checking Manual Volume One contains guidelines for how the translation team can do a check with members of the language community and also some guidelines for church leaders. This volume contains guidelines that the church leaders can use to guide them in checking the translation for both Level Two and Level Three.

*Next we recommend you learn about:*

  * [Steps in Checking a Translation](#vol2-steps)

---

## <a id="vol2-steps"/>Steps in Checking a Translation

*This page answers the question: What are the steps I should follow to check someone else's translation?*

*In order to understand this topic, it would be good to read:*

  * [Introduction to Translation Checking - Part 2](#vol2-intro)


### Steps in Checking a Translation

#### Before Checking

  1. Find out ahead of time which set of stories or which Bible passage you will be checking.
  1. Read the passage in several versions in any languages you understand, including the original languages, if possible.
  1. Read the passage in the ULB and UDB, and read the Notes and translationWords.
  1. Make note of any parts that you think might be difficult to translate.
  1. Research these passages in translation helps and commentaries, making notes about what you discover.

#### While Checking

  1. **Ask Questions**. When you see something that you think might be a problem in the translation, do not make a statement to the translator that there is a problem in the translation. If you do not speak the target language, then you do not know if there is a problem or not. You only suspect that there could be a problem. Even if you do speak the target language, it is more polite to ask a question than to make a statement that something is wrong. You could ask something like, "What would you think about saying it this way?" and then suggest an alternative way to translate it. Then together you can discuss the different translation ideas, and you can give reasons why you think one translation alternative might be better than another. Then, after considering the alternatives, the translator or translation team must decide which way is best. 
  1. **Explore the target language and culture**.  The questions that you ask will be to discover what the phrase means in the target language. The best questions are the ones that help the translator to think about what the phrase means and how it is used. Useful questions are, "In what situations is this phrase used in your language?" or "Who usually says things like this, and why do they say it?" It is also useful to help the translator to think about what a person from his village would say if in the same situation as the person in the Bible. 
  1. **Teach the translator**. After you explore the meaning of a phrase in the target language and culture, you can tell the translator what the phrase means in the source language and culture. Then together you can decide if the phrase in the translation or the phrase he has just thought of has that same meaning or not.

#### Checking the Translation Directly

If you speak the target language, then you can read or hear the translation and ask the translation team about it directly. 

#### Using a Written Back Translation

If you do not speak the target language, you will need to work from a back translation in a language that you do understand. This can be written separately from the translation, or it can be written as an interlinear, that is, with a line of back translation written under each line of the translation. It is easier to compare the translation to the back translation when they are written as an interlinear, and it is easier to read a back translation that is written separately. Each method has its own strength. The person who makes the back translation should be someone who was not involved in making the translation.

  1. If possible, review the back translation in written form before meeting with the translator or translation team face-to-face. This will give you time to think about the passage and to do further research on questions that arise because of what the back translation says. It will also save a lot of time when you meet with the translation team, because there will be a lot of text that you do not need to talk about because you read it in the back translation and it did not have problems. When you meet together, you will be much more productive because you can spend all of your time on the problem areas.
  1. As you work through the back translation, make notes of questions that you want to ask the translator, either for clarification or to help the translator think about possible problems with the translation. 
  1. Ask the translator for a copy of the translation (if it is not interlinear), so that you can compare the translation with the back translation and make note of the connectors that the target language uses and other features that might not be visible in the back translation. Looking at the translation can also help to identify places where the back translation might not accurately represent the translation. For example, where the same words are used in the translation but they are different in the back translation. In this case, it is good to ask the translator why the back translation is different, and if it needs to be corrected. 
  1. If you cannot review the back translation before meeting with the translator, then work through it with the translator, discussing questions and problems as you work together. Often, as the back translation is compared to the translation, the translator will also discover problems with the translation.

#### Using an Oral Back Translation

If there is no written back translation, then have someone who knows the target language and also a language that you understand make an oral back translation for you. This should be a person who was not involved in making the translation. As you listen to the oral back translation, make notes of words or phrases that seem to communicate the wrong meaning or that present other problems. The person should translate the passage in short segments, pausing in between each segment so that you can ask your questions after you hear each segment. 

#### After Checking

Some questions will need to be set aside for later, after the checking session. Be sure to plan a time to meet again to discuss the answers to these questions. These will be:

  1. Questions that you or someone else will need to research, usually something about the biblical text that you will need to find out, such as more exact meanings of biblical words or phrases, or the relationship between biblical people or the nature of biblical places.
  1. Questions to ask other speakers of the target language. These would be to make sure that certain phrases are communicating correctly, or to research the cultural background of certain terms in the target language. These are questions that the translation team may need to ask of people when they return to their community.

### Key Words

Make sure that the translation team is keeping a list of the translationWords (important terms) from the Bible passages that they are translating, along with the term in the target language that they have decided to use for each of these important terms. You and the translation team will probably need to add to this list and modify the terms from the target language as you progress through the translation of the Bible. Use the list of translationWords to alert you when there are Key Words in the passage that you are translating. Whenever there is a Key Word in the Bible, make sure that the translation uses the term or phrase that has been chosen for that Key Word, and also make sure that it makes sense each time. If it does not make sense, then you will need to discuss why it makes sense in some places but not in others. Then you may need to modify or change the chosen term, or decide to use more than one term in the target language to fit different ways that the Key Word is used. One useful way to do this is to keep track of each important term on a spreadsheet, with columns for the source language term, the target language term, alternative terms and the Bible passages where you are using each term. We hope that this feature will be in future versions of translationStudio.

*Next we recommend you learn about:*

  * [Back Translation](#vol2-backtranslation)

---

### <a id="vol2-backtranslation"/>Back Translation

*This page answers the question: What is a back translation?*

*In order to understand this topic, it would be good to read:*

  * [Steps in Checking a Translation](#vol2-steps)


### What is a back translation?

A back translation is a translation of the biblical text from the local target language back into the language of wider communication. It is called a "back translation" because it is a translation in the opposite direction than what was done to create the local target language translation.

A back translation is not done in a completely normal style, however, because it does not have naturalness as a goal in the language of the translation (in this case, the language of wider communication). Instead, its goal is to represent the words and expressions of the local language translation in a literal way, while also using the grammar and word order of the language of wider communication. In this way, the translation checker can most clearly see the meaning of the words in the target language text, and can also understand the back translation well and read it more quickly and easily.

*Next we recommend you learn about:*

  * [The Purpose of the Back Translation](#vol2-backtranslation-purpose)

---

#### <a id="vol2-backtranslation-purpose"/>The Purpose of the Back Translation

*This page answers the question: Why is a back translation necessary?*

*In order to understand this topic, it would be good to read:*

  * [Back Translation](#vol2-backtranslation)


### Why is a back translation necessary?

The purpose of a back translation is to allow a consultant or checker of biblical material who does not understand the target language to be able to see what is in the target language translation, even though he or she does not understand the target language. Therefore, the language of the back translation needs to be a language that both the person doing the back translation (the back translator) and the checker understand well.  Often this means that the back translator will need to translate the target language text back into the same language of wider communication that was used for the source text. 

Some people might consider this to be unnecessary, since the biblical text already exists in the source language. But remember the purpose of the back translation: it is to allow the checker to see what is in the target language translation. Just reading the original source language text does not allow the checker to see what is in the target language translation. Therefore, the back translator must make a new translation back into the language of wider communication that is based only on the target language translation. For this reason, the back translator *cannot* look at the source language text when doing his back translation, but *only* at the target language text. In this way, the checker can identify any problems that might exist in the target language translation and work with the translator to fix those problems. 

The back translation can also be very useful in improving the target language translation even before the checker uses it to check the translation. When the translation team reads the back translation, they can see how the back translator has understood their translation. Sometimes, the back translator has understood their translation in a different way than they intended to communicate. In those cases, they can change their translation so that it communicates more clearly the meaning that they intended. When the translation team is able to use the back translation in this way before they give it to the checker, they can make many improvements to their translation. When they do this, the checker can do his checking much more rapidly, because the translation team was able to correct many of the problems in the translation before meeting with the checker.

*Next we recommend you learn about:*

  * [The Back Translator](#vol2-backtranslation-who)

---

#### <a id="vol2-backtranslation-who"/>The Back Translator

*This page answers the question: Who should do the back translation?*

*In order to understand this topic, it would be good to read:*

  * [The Purpose of the Back Translation](#vol2-backtranslation-purpose)


### Who should do the back translation?

To do a good back translation, the person must have three qualifications.

  1. The person who makes the back translation should be someone who is a mother-tongue speaker of the local target language and who also speaks the language of wider communication well. 
  1. This person must also be someone who was not involved in making the local target language translation that he is back translating. The reason for this is that someone who made the local target language translation knows what he intended the translation to mean, and will put that meaning in the back translation with the result that it looks the same as the source translation. But it is possible that a speaker of the local target language who did not work on the local target language translation will understand the translation differently, or will not understand parts of it at all. The checker wants to know what these other meanings are that other speakers of the local target language will understand from the translation so that he can work with the translation team to make those places communicate the right meaning more clearly.
  1. The person who does the back translation should also be someone who does not know the Bible well. The reason for this is that the back translator must give only the meaning that he understands from looking at the target language translation, not from knowledge that he might have from reading the Bible in another language.

*Next we recommend you learn about:*

  * [Kinds of Back Translations](#vol2-backtranslation-kinds)

---

#### <a id="vol2-backtranslation-kinds"/>Kinds of Back Translations

*This page answers the question: What kinds of back translations are there?*

*In order to understand this topic, it would be good to read:*

  * [The Back Translator](#vol2-backtranslation-who)


### What kinds of back translations are there?

#### Oral

An oral back translation is one that the back translator speaks to the translation checker in the language of wider communication as he reads or hears the translation in the target language. He will usually do this one sentence at a time, or two sentences at a time if they are short. When the translation checker hears something that may be a problem, he will stop the person doing the oral back translation so that he can ask a question about it. One or more members of the translation team should also be present so that they can answer questions about the translation.

An advantage of the oral back translation is that the back translator is immediately accessible to the translation checker and can answer the translation checker's questions about the back translation. A disadvantage of the oral back translation is that the back translator has very little time to think about the best way to back translate the translation and he may not express the meaning of the translation in the best way. This may make it necessary for the translation checker to ask more questions than if the back translation were expressed in a better way. Another disadvantage is that the checker also has very little time to evaluate the back translation. He only has a few seconds to think about one sentence before hearing another. Because of this, he may not catch all of the problems that he would catch if he had more time to think about each sentence.

#### Written

There are two types of written back translations. The differences between the two will be discussed in the next module. A written back translation has several advantages over an oral back translation. First, when a back translation is written, the translation team can read it to see if there are any places where the back translator has misunderstood their translation. If the back translator misunderstood the translation, then other readers or hearers of the translation certainly will misunderstand it also, and so the translation team will need to revise their translation at those points. 

Second, when the back translation is written, the translation checker can read the back translation before meeting with the translation team and take time to research any question that arises from the back translation. Even when the translation checker does not need to research a problem, the written back translation allows him more time to think about the translation. He can identify and address more of the problems in the translation and sometimes come to better solutions to the problems because he has more time to think about each one than when he has only a few seconds to think about each sentence. 

Third, when the back translation is written, the translation checker can also prepare his questions in written form before meeting with the translation team. If there is time before their meeting and if they have a way to communicate, the checker can send his written questions to the translation team so that they can read them and change the parts of the translation that the checker thought to be problems. This helps the translation team and the checker to be able to review much more of the biblical material when they meet together, because they were able to fix many of the problems in the translation before their meeting. During the meeting, they can concentrate on the problems that remain. These are usually places where the translation team has not understood the checker's question or where the checker has not understood something about the target language and so thinks that there is a problem where there is not. In that case, during the meeting time the translation team can explain to the checker what it is that he has not understood. 

Even if there is not time for the checker to send his questions to the translation team before their meeting, they will still be able to review more material at the meeting than they would have been able to review otherwise because the checker has already read the back translation and has already prepared his questions. Because he has had this previous preparation time, he and the translation team can use their meeting time to discuss only the problem areas of the translation rather than reading through the entire translation at a slow pace, as is required when making an oral back translation. 

Fourth, the written back translation relieves the strain on the translation checker from having to concentrate for many hours at a time on hearing and understanding an oral translation as it is spoken to him. If the checker and translation team are meeting in a noisy environment, the difficulty of making sure that he hears every word correctly can be quite exhausting for the checker. The mental strain of concentration increases the likelihood that the checker will miss some problems with the result that they remain uncorrected in the biblical text. For these reasons, we recommend the use of a written back translation whenever possible.

*Next we recommend you learn about:*

  * [Kinds of Written Back Translations](#vol2-backtranslation-written)

---

#### <a id="vol2-backtranslation-written"/>Kinds of Written Back Translations

*This page answers the question: What kinds of written back translations are there?*

*In order to understand this topic, it would be good to read:*

  * [Kinds of Back Translations](#vol2-backtranslation-kinds)


There are two kinds of written back translations.

### Interlinear Back Translation

An interlinear back translation is one in which the back translator puts a translation for each word of the target language translation underneath that word. This results in a text in which each line of the target language translation is followed by a line in the language of wider communication. The advantage of this kind of back translation is that the checker can easily see how the translation team is translating each word of the target language. He can more easily see the range of meaning of each target language word and can compare how it is used in different contexts. The disadvantage of this kind of back translation is that the line of text in the language of wider communication is made up of translations of individual words. This makes the text difficult to read and understand, and may create more questions and misunderstandings in the mind of the translation checker than the other method of back translation. This is the same reason we do not recommend the word-for-word method for translation of the Bible!

### Free Back Translation

A free back translation is one in which the back translator makes a translation in the language of wider communication in a separate space from the target language translation. The disadvantage of this method is that the back translation is not related as closely to the target language translation. The back translator can overcome this disadvantage when back translating the Bible, however, by including the verse numbers with the back translation. By referring to the verse numbers in both translations, the translation checker can keep track of which part of the back translation represents which part of the target language translation. The advantage of this method is that the back translation can use the grammar and word order of the language of wider communication, and so it is much easier for the translation checker to read and understand. Even while using the grammar and word order of the language of wider communication, however, the back translator should remember to translate the words in a literal way. We recommend that the back translator use the method of free back translation.

*Next we recommend you learn about:*

  * [Guidelines for Creating a Good Back Translation](#vol2-backtranslation-guidelines)

---

#### <a id="vol2-backtranslation-guidelines"/>Guidelines for Creating a Good Back Translation

*This page answers the question: What are the guidelines for creating a good back translation?*

*In order to understand this topic, it would be good to read:*

  * [Kinds of Written Back Translations](#vol2-backtranslation-written)


### 1. Show the Target Language Usage for Words and Clauses

#### a. Use the meaning of the word in context

If a word has only one basic meaning, then the back translator should use a word in the language of wider communication that represents that basic meaning throughout the back translation. If, however, a word in the target language has more than one meaning, so that the meaning changes depending on the context that it is in, then the back translator should use the word or phrase in the language of wider communication that best represents the way that the word was used in that context. In order to avoid confusion for the translation checker, the back translator can put the other meaning in parentheses the first time that he uses the word in a different way, so that the translation checker can see and understand that this word has more than one meaning. For example, he might write, "come (go)" if the target language word was translated as "go" earlier in the back translation but in the new context it is better translated as "come." 

If the target language translation uses an idiom, it is most helpful to the translation checker if the back translator translates the idiom literally (according to the meaning of the words), but then also includes the meaning of the idiom in parentheses. In that way, the translation checker can see that the target language translation uses an idiom in that place, and also see what it means. For example, a back translator might translate an idiom such as, "he kicked the bucket (he died)." If the idiom occurs more than once or twice, the back translator does not need to continue to explain it each time, but can either just translate it literally or just translate the meaning. 

#### b. Keep parts of speech the same

In the back translation, the back translator should represent the parts of speech of the target language with the same parts of speech in the language of wider communication. This means that the back translator should translate nouns with nouns, verbs with verbs, and modifiers with modifiers. This will help the translation checker to see how the target language works. 

#### c. Keep clause types the same

In the back translation, the back translator should represent each clause of the target language with the same type of clause in the language of wider communication. For example, if the target language clause uses a command, then the back translation should also use a command, rather than a suggestion or request. Or if the target language clause uses a rhetorical question, then the back translation should also use a question, rather than a statement or other expression. 

#### d. Keep punctuation the same

The back translator should use the same punctuation in the back translation as there is in the target language translation. For example, wherever there is a comma in the target language translation, the back translator should also put a comma in the back translation. Periods, exclamation points, quote marks, and all punctuation need to be at the same place in both translations. In that way, the translation checker can more easily see which parts of the back translation represent which parts of the target language translation. When making a back translation of the Bible, it is also very important to make sure that all chapter and verse numbers are in the right places in the back translation.

#### e. Express the full meaning of complex words

Sometimes words in the target language will be more complex than words in the language of wider communication. In this case, the back translator will need to represent the target language word with a longer phrase in the language of wider communication. This is necessary so that the translation checker can see as much of the meaning as possible. For example, to translate one word in the target language it might be necessary to use a phrase in the language of wider communication such as, "go up," or "be lying down."   Also, many languages have words that contain more information than the equivalent words in the language of wider communication. In this case, it is most helpful if the back translator includes that additional information in parentheses, such as "we (inclusive)," or "you (feminine, plural)." 

### 2. Use the Language of Wider Communication Style for Sentence and Logical Structure

The back translation should use the sentence structure that is natural for the language of wider communication, not the structure that is used in the target language. This means that the back translation should use the word order that is natural for the language of wider communication, not the word order that is used in the target language. The back translation should also use the way of relating phrases to each other and the way of indicating logical relations, such as cause or purpose, that are natural for the language of wider communication. This will make the back translation easier to read and understand for the translation checker. This will also speed up the process of checking the back translation.

*Next we recommend you learn about:*

  * [Types of Things to Check](#vol2-things-to-check)

---

### <a id="vol2-things-to-check"/>Types of Things to Check

*This page answers the question: What types of things should I check?*

*In order to understand this topic, it would be good to read:*

  * [Steps in Checking a Translation](#vol2-steps)


### Types of things to check


  1. Ask about anything that does not seem right to you, so that the translation team can explain it. If it also does not seem right to them, they can adjust the translation. In general:
    1. Check for anything that appears to be added, that was not a part of the meaning of the source text. (Remember, the original meaning also includes [Implicit Information](translate.html#figs-explicit).)
    1. Check for anything that appears to be missing, that was a part of the meaning of the source text but was not included in the translation.
    1. Check for any meaning that appears to be different than the meaning of the source text.
  1. Check to make sure that the main point or the theme of the passage is clear. Ask the translation team to summarize what the passage is saying or teaching. If they choose a minor point as the primary one, they might need to adjust the way that they translated the passage.
  1. Check that the different parts of the passage are connected in the right way – that the reasons, additions, results, conclusions, etc. in the Bible passage are marked with the proper connectors in the target language.
  1. Check for the consistency of the translationWords, as explained in the last section of "Steps in Checking a Translation." Ask how each term is used in the culture – who uses the terms, and on what occasions. Also ask what other terms are similar and what the differences are between the similar terms. This helps the translator to see if some terms might have unwanted meanings, and to see which term might be better, or if they might need to use different terms in different contexts.
  1. Check figures of speech. Where there is a figure of speech in the Bible text, see how it has been translated and make sure it communicates the same meaning. Where there is a figure of speech in the translation, check to make sure it communicates the same meaning as in the Bible text. 
  1. Check to see how abstract ideas were translated, such as love, forgiveness, joy, etc. Many of these are also Key Words.
  1. Check the translation of things or practices that might be unknown in the target culture. Showing the translation team pictures of these things and explaining to them what they are is very helpful.
  1. Discuss the words about the spirit world and how they are understood in the target culture. Make sure that the ones used in the translation communicate the right thing.
  1. Check anything that you think might be especially difficult to understand or translate in the passage.

After checking all of these things and making corrections, have the translation team read the passage out loud again to each other or to other members of their community to make sure that everything still flows in a natural way and uses the right connectors. If a correction made something sound unnatural, they will need to make additional adjustments to the translation. This process of testing and revision should repeat until the translation communicates clearly and naturally in the target language.

*Next we recommend you learn about:*

  * [How to Do a Formatting Check](#formatting)

---

### <a id="formatting"/>How to Do a Formatting Check

*This page answers the question: What do I need to do so that the translation looks right?*

*In order to understand this topic, it would be good to read:*

  * [Types of Things to Check](#vol2-things-to-check)


There are checks that you can do before, during, and after translation of a book of the Bible that will make the translation go much easier, look good, and be as easy to read as possible. The modules in this section give more information about the following topics.

### Before Translating

The translation team should make decisions about the following issues before you start to translate.

  1. Alphabet (see [Appropriate Alphabet](#alphabet))
  1. Spelling (see [Consistent Spelling](#spelling))
  1. Punctuation (see [Consistent Punctuation](#punctuation))

### While Translating

After you have translated several chapters, the translation team may need to revise some of these decisions to take care of problems that they discovered while translating. You can also do consistency checks in ParaTExt at this time to see if there are more decisions that you need to make about spelling and punctuation. 

### After Finishing a Book

After finishing a book, you can check to make sure that all the verses are there, and you can decide on section headings. It is also helpful to write down ideas for section headings as you translate.

  1. Versification (see [Complete Versification](#verses))
  1. Section Headings (see [Section Headings](#headings))

*Next we recommend you learn about:*

  * [Appropriate Alphabet](#alphabet)
  * [Consistent Spelling](#spelling)
  * [Consistent Punctuation](#punctuation)

---

#### <a id="alphabet"/>Appropriate Alphabet

*This page answers the question: Does the translation use an appropriate alphabet?*

*In order to understand this topic, it would be good to read:*

  * [Acceptable Style](#acceptable)
  * [Alphabet/Orthography](translate.html#translate-alphabet)


### The Alphabet for the Translation

As you read the translation, ask yourself these questions about the way words are spelled. These questions will help to determine if an appropriate alphabet has been chosen to represent the sounds of the language and if words have been written in a consistent way so that the translation will be easy to read. 

  1. Is the alphabet suitable to represent the sounds of the language of the new translation? (Are there any sounds that make a difference in meaning but have to use the same symbol as another sound? Does this make the words hard to read? Can additional marks be used to adjust these letters and show the differences?)
  1. Is the spelling used in the book consistent? (Are there rules that the writer should follow to show how words change in different situations? Can they be described so others will know how to read and write the language easily?)
  1. Has the translator used expressions, phrases, connectors, and spellings that will be recognized by most of the language community?

If there is something about the alphabet or spelling that is not right, make a note of that so that you can discuss it with the translation team.

---

#### <a id="spelling"/>Consistent Spelling

*This page answers the question: Are words in the translation spelled consistently?*

*In order to understand this topic, it would be good to read:*

  * [Introduction to Translation Checking - Part 2](#vol2-intro)
  * [Acceptable Style](#acceptable)
  * [Alphabet/Orthography](translate.html#translate-alphabet)
  * [Appropriate Alphabet](#alphabet)


In order for the reader to be able to read and understand the translation easily, it is important that you spell words consistently. This can be difficult if there is not a tradition of writing or spelling in the target language. Several people working on different parts of a translation also makes this difficult.  For that reason, it is important for the translation team to meet together before they start translating to talk about how they plan to spell words. 

Discuss the words that are difficult to spell as a team. If the words have sounds in them that are difficult to represent, then you may need to make a change in the writing system that you are using (see [Alphabet/Orthography](translate.html#translate-alphabet)). If the sounds in the words can be represented in different ways, then the team will need to agree on how to spell them. Make a list of the agreed upon spellings of these words in alphabetical order. Make sure that each member of the team has a copy of the list, to consult when translating. Add to the list as you come across more difficult words, but make sure everyone has the current list. It may be helpful to use a spreadsheet to maintain your spelling list.

The names of people and places in the Bible can be difficult to spell because many of them are unknown in target languages. Be sure to include these in your spelling list.

Computers can be a great help for checking spelling. If you are working on a Gateway Language, a word processor may have a dictionary already available. If you are translating into an Other Language, you can use the find and replace feature to fix misspelled words. ParaTExt also has a spell check feature which will find all variant spellings of words. It will present these to you and then you can choose which spellings you have decided to use.

*Next we recommend you learn about:*

  * [Consistent Punctuation](#punctuation)

---

#### <a id="punctuation"/>Consistent Punctuation

*This page answers the question: Does the translation use consistent punctuation?*

*In order to understand this topic, it would be good to read:*

  * [Consistent Spelling](#spelling)
  * [Alphabet/Orthography](translate.html#translate-alphabet)
  * [Appropriate Alphabet](#alphabet)


"Punctuation" refers to the marks that indicate how a sentence is to be read or understood. Examples include the indicators of pauses such as the comma or period and the quotation marks that surround the exact words of a speaker. In order for the reader to be able to read and understand the translation correctly, it is important that you use punctuation consistently. 

Before translating, the translation team will need to decide on the methods of punctuation that you will use in the translation. It may be easiest to adopt the method of punctuation that the national language uses, or that a national language Bible or related language Bible uses. Once the team decides on a method, make sure that everyone follows it. It may be helpful to distribute a guide sheet to each of the team members with examples on it of the correct way to use the different punctuation marks. 

Even with the guide sheet, it is common for translators to make mistakes in punctuation. Because of this, after a book has been translated, we recommend importing it into ParaTExt. You can enter the rules for punctuation in the target language into ParaTExt, then run the different punctuation checks that it has. ParaTExt will list all of the places where it finds punctuation errors and show them to you. You can then review these places and see if there is an error there or not. If there is an error, you can fix the error. After running these punctuation checks, you can be confident that your translation is using punctuation correctly.

*Next we recommend you learn about:*

  * [Complete Versification](#verses)

---

#### <a id="verses"/>Complete Versification

*This page answers the question: Are any verses missing in the translation?*

*In order to understand this topic, it would be good to read:*

  * [Consistent Spelling](#spelling)
  * [Consistent Punctuation](#punctuation)
  * [Appropriate Alphabet](#alphabet)


It is important that your target language translation include all of the verses that are there in the source language Bible. We do not want some verses to be missing by mistake. But remember that there can be good reasons why some Bibles have certain verses that other Bibles do not have. 

### Reasons for Missing Verses

  1. **Textual Variants** - There are some verses that many Bible scholars do not believe were original to the Bible, but were added later. Therefore the translators of some Bibles chose to not include those verses, or included them only as footnotes. (For more information about this, see [Textual Variants](translate.html#translate-textvariants).) Your translation team will need to decide whether you will include these verses or not.
  1. **Different Numbering** - Some Bibles use a different system of verse numbering than other Bibles. (For more information about this, see [Chapter and Verse Numbers](translate.html#translate-chapverse).) Your translation team will need to decide which system to use.
  1. **Verse Bridges** - In some translations of the Bible, the contents of two or more verses are rearranged so that the order of information is more logical or easier to understand. When that happens, the verse numbers are combined, such as 4-5 or 4-6. The UDB does this sometimes, and on rare occasions, also the ULB. Because not all of the verse numbers appear or they do not appear where you expect them to be, it might look like some verses are missing. But the contents of those verses are there. (For more information about this, see [Verse Bridges](translate.html#translate-versebridge).) Your translation team will need to decide whether to use verse bridges or not.

### Checking for Missing Verses

In order to check your translation for missing verses, after a book has been translated, import the translation into ParaTExt. Then run the check for "chapter/verse numbers." ParaTExt will give you a list of everywhere in that book that it finds verses missing. You can then look at each of those places and decide if the verse is missing on purpose because of one of the three reasons above, or if it is missing by mistake and you need to go back and translate that verse.

*Next we recommend you learn about:*

  * [Section Headings](#headings)

---

#### <a id="headings"/>Section Headings

*This page answers the question: What kind of section headings should we use?*

*In order to understand this topic, it would be good to read:*

  * [Acceptable Style](#acceptable)
  * [Consistent Punctuation](#punctuation)
  * [Complete Versification](#verses)


### Decisions about Section Headings

One of the decisions that the translation team will have to make is whether or not to use section headings. Section headings are like titles to each section of the Bible that begins a new topic. The section heading lets people know what that section is about. Some Bible translations use them, and others do not. You may want to follow the practice of the Bible in the national language that most people use. You will also want to find out what the language community prefers.

Using section headings requires more work, because you will have to either write or translate each one, in addition to the text of the Bible. It will also make your translation of the Bible longer. But section headings can be very helpful to your readers. Section headings make it much easier to find where the Bible talks about different things. If a person is looking for something in particular, he can just read the section headings until he finds one that introduces the topic that he wants to read about. Then he can read that section.

If you have decided to use section headings, then you will need to decide which kind to use. Again, you will want to find out which kind of section heading the language community prefers, and you may also choose to follow the style of the national language.  Be sure to use a kind of section heading that the people will understand is not part of the text that it introduces. The section heading is not a part of scripture; it is just a guide to the different parts of scripture. You might be able to make this clear by putting a space before and after the section heading and using a different font (style of letters), or a different size of letters. See how the Bible in the national language does this, and test different methods with the language community.

### Kinds of Section Headings

There are many different kinds of section headings. Here are some different kinds, with examples of how each one would look for Mark 2:1-12: 

  * Summary statement: "By healing a paralyzed man, Jesus demonstrated his authority to forgive sins as well as to heal." This tries to summarize the main point of the section, and so it gives the most information in a full sentence.
  * Explanatory comment: "Jesus heals a paralyzed man." This is also a full sentence, but gives just enough information to remind the reader which section follows.
  * Topical reference: "Cure of a paralytic." This tries to be very short, only giving a label of a few words. This might save space, but it is probably only useful for people who already know the Bible well.
  * Question: "Does Jesus have authority to heal and forgive sins?" This one creates a question that the information in the section answers. People who have a lot of questions about the Bible may find this especially helpful.
  * "About" comment: "About Jesus healing a paralyzed man." This one makes it explicit that it is trying to tell you what the section is about. This may be the one that makes it easiest to see that the heading is not a part of the words of scripture.

As you can see, it is possible to make many different kinds of section headings, but they all have the same purpose. They all give the reader information about the main topic of the section of the Bible that follows. Some are shorter, and some are longer. Some give just a little information, and some give more. You may want to experiment with the different kinds, and ask people which kind they think is most helpful for them.

*Next we recommend you learn about:*

  * [Language Community Evaluation Questions](#community-evaluation)

---

