# <a id="tw-section-kt"/>Key Terms

## <a id="tw-term-kt-abomination"/>abomination, abominations, abominable

### Definition:

The term "abomination" is used to refer to something that causes disgust or extreme dislike.

* The Egyptians considered the Hebrew people to be an "abomination." This means that the Egyptians disliked the Hebrews and didn't want to associate with them or be near them.
* Some of the things that the Bible calls "an abomination to Yahweh" include lying, pride, sacrificing humans, worship of idols, murder, and sexual sins such as adultery and homosexual acts.
* In teaching his disciples about the end times, Jesus referred to a prophecy by the prophet Daniel about an "abomination of desolation" that would be set up as a rebellion against God, defiling his place of worship.

### Translation Suggestions:

* The term "abomination" could also be translated by "something God hates" or "something disgusting" or "disgusting practice" or "very evil action."
* Depending on the context, ways to translate the phrase "is an abomination to" could include "is greatly hated by" or "is disgusting to" or "is totally unacceptable to" or "causes deep disgust."
* The phrase "abomination of desolation" could be translated as "defiling object that causes people to be greatly harmed" or "disgusting thing that causes great sorrow."

(See also: [adultery](#adultery), [desecrate](other.html#desecrate), [desolate](other.html#desolate), [false god](#falsegod), [sacrifice](other.html#sacrifice))

### Bible References:

* [Ezra 09:1-2](https://git.door43.org/Door43/en_tn/src/master/ezr/09/01.md)
* [Genesis 46:33-34](https://git.door43.org/Door43/en_tn/src/master/gen/46/33.md)
* [Isaiah 01:12-13](https://git.door43.org/Door43/en_tn/src/master/isa/01/12.md)
* [Matthew 24:15-18](https://git.door43.org/Door43/en_tn/src/master/mat/24/15.md)
* [Proverbs 26:24-26](https://git.door43.org/Door43/en_tn/src/master/pro/26/24.md)

### Word Data:

* Strong's: H887, H6292, H8251, H8262, H8263, H8441, G946


## <a id="tw-term-kt-adoption"/>adoption, adopt, adopted

### Definition:

The terms "adopt" and "adoption" refer to the process of someone legally becoming the child of people who are not his biological parents.

* The Bible uses "adoption" and "adopt" in a figurative way to describe how God causes people to be part of his family, making them his spiritual sons and daughters.
* As adopted children, God makes believers to be co-heirs with Jesus Christ, giving them all of the privileges of sons and daughters of God.

### Translation Suggestions:

* This term could be translated with a term that the language of translation uses to describe this special parent-child relationship. Make sure it is understood that this has a figurative or spiritual meaning.
* The phrase "experience adoption as sons" could be translated as "be adopted by God as his children" or "become God's (spiritual) children."
* To "wait for the adoption of sons" could be translated as "look forward to becoming God's children" or "wait expectantly for God to receive as children."
* The phrase "adopt them" could be translated as "receive them as his own children" or "make them his own (spiritual) children."

(See also: [heir](other.html#heir), [inherit](#inherit), [spirit](#spirit))

### Bible References:

* [Ephesians 01:5-6](https://git.door43.org/Door43/en_tn/src/master/eph/01/05.md)
* [Galatians 04:3-5](https://git.door43.org/Door43/en_tn/src/master/gal/04/03.md)
* [Romans 08:14-15](https://git.door43.org/Door43/en_tn/src/master/rom/08/14.md)
* [Romans 08:23-25](https://git.door43.org/Door43/en_tn/src/master/rom/08/23.md)
* [Romans 09:3-5](https://git.door43.org/Door43/en_tn/src/master/rom/09/03.md)

### Word Data:

* Strong's: G5206


## <a id="tw-term-kt-adultery"/>adultery, adulterous, adulterer, adulteress, adulterers, adulteresses

### Definition:

The term "adultery" refers to a sin that occurs when a married person has sexual relations with someone who is not that person's spouse. Both of them are guilty of adultery. The term "adulterous" describes this kind of behavior or any person who commits this sin.

* The term "adulterer" refers generally to any person who commits adultery.
* Sometimes the term "adulteress" is used to specify that it was a woman who committed adultery.
* Adultery breaks the promises that a husband and wife made to each other in their covenant of marriage.
* God commanded the Israelites to not commit adultery.
* The term "adulterous" is often used in a figurative sense to describe the people of Israel as being unfaithful to God, especially when they worshiped false gods.

### Translation Suggestions:

* If the target language does not have one word that means "adultery," this term could be translated with a phrase such as "having sexual relations with someone else's wife" or "being intimate with another person's spouse."
* Some languages may have an indirect way of talking about adultery, such as "sleeping with someone else's spouse" or "being unfaithful to one's wife." (See: [euphemism](https://git.door43.org/Door43/en_man/src/master/translate/figs-euphemism/01.md))
* When "adulterous" is used in a figurative sense, it is best to translate it literally in order to communicate God's view of his disobedient people as being compared to an unfaithful spouse. If this does not communicate accurately in the target language, the figurative use of "adulterous" could be translated as "unfaithful" or "immoral" or "like an unfaithful spouse." 

(See also: [commit](other.html#commit), [covenant](#covenant), [sexual immorality](other.html#fornication), [sleep with](other.html#sex), [faithful](#faithful))

### Bible References:

* [Exodus 20:12-14](https://git.door43.org/Door43/en_tn/src/master/exo/20/12.md)
* [Hosea 04:1-2](https://git.door43.org/Door43/en_tn/src/master/hos/04/01.md)
* [Luke 16:18](https://git.door43.org/Door43/en_tn/src/master/luk/16/18.md)
* [Matthew 05:27-28](https://git.door43.org/Door43/en_tn/src/master/mat/05/27.md)
* [Matthew 12:38-40](https://git.door43.org/Door43/en_tn/src/master/mat/12/38.md)
* [Revelation 02:22-23](https://git.door43.org/Door43/en_tn/src/master/rev/02/22.md)

### Examples from the Bible stories:

* __[13:06](https://git.door43.org/Door43/en_tn/src/master/obs/13/06.md)__ "Do not commit __adultery__."
* __[28:02](https://git.door43.org/Door43/en_tn/src/master/obs/28/02.md)__ Do not commit __adultery__.
* __[34:07](https://git.door43.org/Door43/en_tn/src/master/obs/34/07.md)__ "The religious leader prayed like this, 'Thank you, God, that I am not a sinner like other men-such as robbers, unjust men, __adulterers__, or even like that tax collector.'"


### Word Data:

* Strong's: H5003, H5004, G3428, G3429, G3430, G3431, G3432


## <a id="tw-term-kt-almighty"/>Almighty

### Facts:

The term "Almighty" literally means "all-powerful"; in the Bible, it always refers to God.

* The titles "the Almighty" or "the Almighty One" refer to God and reveal that he has complete power and authority over everything.
* This term is also used to describe God in the titles "Almighty God" and "God Almighty" and "Lord Almighty" and "Lord God Almighty."

### Translation Suggestions:

* This term could also be translated as "All-powerful" or "Completely Powerful One" or "God, who is completely powerful."
* Ways to translate the phrase "Lord God Almighty" could include "God, the Powerful Ruler" or "Powerful Sovereign God" or "Mighty God who is Master over everything."

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [God](#god), [lord](#lord), [power](#power))

### Bible References:

* [Exodus 06:2-5](https://git.door43.org/Door43/en_tn/src/master/exo/06/02.md)
* [Genesis 17:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/17/01.md)
* [Genesis 35:11-13](https://git.door43.org/Door43/en_tn/src/master/gen/35/11.md)
* [Job 08:1-3](https://git.door43.org/Door43/en_tn/src/master/job/08/01.md)
* [Numbers 24:15-16](https://git.door43.org/Door43/en_tn/src/master/num/24/15.md)
* [Revelation 01:7-8](https://git.door43.org/Door43/en_tn/src/master/rev/01/07.md)
* [Ruth 01:19-21](https://git.door43.org/Door43/en_tn/src/master/rut/01/19.md)

### Word Data:

* Strong's: H7706, G3841


## <a id="tw-term-kt-altar"/>altar, altars

### Definition:

An altar was a raised structure on which the Israelites burned animals and grains as offerings to God.

* During Bible times, simple altars were often made by forming a mound of packed-down dirt or by carefully placing large stones to form a stable pile.
* Some special box-shaped altars were made of wood overlaid with metals such as gold, brass, or bronze.
* Other people groups living near the Israelites also built altars to offer sacrifices to their gods.

(See also: [altar of incense](other.html#altarofincense), [false god](#falsegod), [grain offering](other.html#grainoffering), [sacrifice](other.html#sacrifice))

### Bible References:

* [Genesis 08:20-22](https://git.door43.org/Door43/en_tn/src/master/gen/08/20.md)
* [Genesis 22:9-10](https://git.door43.org/Door43/en_tn/src/master/gen/22/09.md)
* [James 02:21-24](https://git.door43.org/Door43/en_tn/src/master/jas/02/21.md)
* [Luke 11:49-51](https://git.door43.org/Door43/en_tn/src/master/luk/11/49.md)
* [Matthew 05:23-24](https://git.door43.org/Door43/en_tn/src/master/mat/05/23.md)
* [Matthew 23:18-19](https://git.door43.org/Door43/en_tn/src/master/mat/23/18.md)

### Examples from the Bible stories:

* __[03:14](https://git.door43.org/Door43/en_tn/src/master/obs/03/14.md)__ After Noah got off the boat, he built an __altar__  and sacrificed some of each kind of animal which could be used for a sacrifice.
* __[05:08](https://git.door43.org/Door43/en_tn/src/master/obs/05/08.md)__ When they reached the place of sacrifice, Abraham tied up his son Isaac and laid him on an __altar__.
* __[13:09](https://git.door43.org/Door43/en_tn/src/master/obs/13/09.md)__ A priest would kill the animal and burn it on the __altar__.
* __[16:06](https://git.door43.org/Door43/en_tn/src/master/obs/16/06.md)__ He (Gideon) built a new altar dedicated to God near where the __altar__  to the idol used to be and made a sacrifice to God on it.


### Word Data:

* Strong's: H741, H2025, H4056, H4196, G1041, G2379


## <a id="tw-term-kt-amen"/>amen, truly

### Definition:

The term "amen" is a word used to emphasize or call attention to what a person has said. It is often used at the end of a prayer. Sometimes it is translated as "truly."

* When used at the end of a prayer, "amen" communicates agreement with the prayer or expresses a desire that the prayer be fulfilled.
* In his teaching, Jesus used "amen" to emphasize the truth of what he said. He often followed that by "and I say to you" to introduce another teaching that related to the previous teaching.
* When Jesus uses "amen" this way, some English versions (and the ULB) translate this as "verily" or  "truly."
* Another word meaning "truly" is sometimes translated as "surely" or "certainly" and is also used to emphasize what the speaker is saying.

### Translation Suggestions:

* Consider whether the target language has a special word or phrase that is used to emphasize something that has been said.
* When used at the end of a prayer or to confirm something, "amen" could be translated as "let it be so" or "may this happen" or "that is true."
* When Jesus says, "truly I tell you," this could also be translated as "Yes, I tell you sincerely" or "That is true, and I also tell you."
* The phrase "truly, truly I tell you" could be translated as "I tell you this very sincerely" or "I tell you this very earnestly" or "what I am telling you is true."
* 
(See also: [fulfill](#fulfill), [true](#true))

### Bible References:

* [Deuteronomy 27:15](https://git.door43.org/Door43/en_tn/src/master/deu/27/15.md)
* [John 05:19-20](https://git.door43.org/Door43/en_tn/src/master/jhn/05/19.md)
* [Jude 01:24-25](https://git.door43.org/Door43/en_tn/src/master/jud/01/24.md)
* [Matthew 26:33-35](https://git.door43.org/Door43/en_tn/src/master/mat/26/33.md)
* [Philemon 01:23-25](https://git.door43.org/Door43/en_tn/src/master/phm/01/23.md)
* [Revelation 22:20-21](https://git.door43.org/Door43/en_tn/src/master/rev/22/20.md)

### Word Data:

* Strong's: H543, G281


## <a id="tw-term-kt-angel"/>angel, angels, archangel

### Definition:

An angel is a powerful spirit being whom God created. Angels exist to serve God by doing whatever he tells them to do. The term "archangel" refers to the angel who rules or leads all the other angels.

* The word "angel" literally means "messenger."
* The term "archangel" literally means "chief messenger." The only angel referred to in the Bible as an "archangel" is Michael.
* In the Bible, angels gave messages to people from God. These messages included instructions about what God wanted the people to do.
* Angels also told people about events that were going to happen in the future or events that had already happened.
* Angels have God's authority as his representatives and sometimes in the Bible they spoke as if God himself was speaking.
* Other ways that angels serve God are by protecting and strengthening people.
* A special phrase, "angel of Yahweh," has more than one possible meaning: 1) It may mean "angel who represents Yahweh" or "messenger who serves Yahweh." 2) It may refer to Yahweh himself, who looked like an angel as he talked to a person. Either one of these meanings would explain the angel's use of "I" as if Yahweh himself was talking.

### Translation Suggestions:

* Ways to translate "angel" could include "messenger from God" or "God's heavenly servant" or "God's spirit messenger."
* The term "archangel" could be translated as "chief angel" or "head ruling angel" or "leader of the angels."
* Also consider how these terms are translated in a national language or another local language.
* The phrase "angel of Yahweh" should be translated using the words for "angel" and "Yahweh." This will allow for different interpretations of that phrase. Possible translations could include "angel from Yahweh" or "angel sent by Yahweh" or "Yahweh, who looked like an angel."

(See also: [How to Translate Unknowns](https://git.door43.org/Door43/en_man/src/master/translate/translate-unknown/01.md))

(See also: [chief](other.html#chief), [head](other.html#head), [messenger](other.html#messenger), [Michael](names.html#michael), [ruler](other.html#ruler), [servant](other.html#servant))

### Bible References:

* [2 Samuel 24:15-16](https://git.door43.org/Door43/en_tn/src/master/2sa/24/15.md)
* [Acts 10:3-6](https://git.door43.org/Door43/en_tn/src/master/act/10/03.md)
* [Acts 12:22-23](https://git.door43.org/Door43/en_tn/src/master/act/12/22.md)
* [Colossians 02:18-19](https://git.door43.org/Door43/en_tn/src/master/col/02/18.md)
* [Genesis 48:14-16](https://git.door43.org/Door43/en_tn/src/master/gen/48/14.md)
* [Luke 02:13-14](https://git.door43.org/Door43/en_tn/src/master/luk/02/13.md)
* [Mark 08:38](https://git.door43.org/Door43/en_tn/src/master/mrk/08/38.md)
* [Matthew 13:49-50](https://git.door43.org/Door43/en_tn/src/master/mat/13/49.md)
* [Revelation 01:19-20](https://git.door43.org/Door43/en_tn/src/master/rev/01/19.md)
* [Zechariah 01:7-9](https://git.door43.org/Door43/en_tn/src/master/zec/01/07.md)

### Examples from the Bible stories:

* __[02:12](https://git.door43.org/Door43/en_tn/src/master/obs/02/12.md)__ God placed large, powerful __angels__  at the entrance to the garden to keep anyone from eating the fruit of the tree of life.
* __[22:03](https://git.door43.org/Door43/en_tn/src/master/obs/22/03.md)__ The __angel__  responded to Zechariah,"I was sent by God to bring you this good news."
* __[23:06](https://git.door43.org/Door43/en_tn/src/master/obs/23/06.md)__ Suddenly, a shining __angel__  appeared to them (the shepherds), and they were terrified. The __angel__  said, "Do not be afraid, because I have some good news for you."
* __[23:07](https://git.door43.org/Door43/en_tn/src/master/obs/23/07.md)__ Suddenly, the skies were filled with __angels__  praising Godâ€¦
* __[25:08](https://git.door43.org/Door43/en_tn/src/master/obs/25/08.md)__ Then __angels__  came and took care of Jesus.
* __[38:12](https://git.door43.org/Door43/en_tn/src/master/obs/38/12.md)__ Jesus was very troubled and his sweat was like drops of blood. God sent an __angel__  to strengthen him.
* __[38:15](https://git.door43.org/Door43/en_tn/src/master/obs/38/15.md)__ "I could ask the Father for an army of __angels__  to defend me."


### Word Data:

* Strong's: H47, H430, H4397, H4398, H8136, G32, G743, G2465


## <a id="tw-term-kt-anoint"/>anoint, anointed, anointing

### Definition:

The term "anoint" means to rub or pour oil on a person or object. Sometimes the oil was mixed with spices, giving it a sweet, perfumed smell. The term is also used figuratively to refer to the Holy Spirit choosing and empowering someone.

* In the Old Testament, priests, kings, and prophets were anointed with oil to set them apart for special service to God.
* Objects such as altars or the tabernacle were also anointed with oil to show that they were to be used to worship and glorify God.
* In the New Testament, sick people were anointed with oil for their healing.
* The New Testament records two times that Jesus was anointed with perfumed oil by a woman, as an act of worship. One time Jesus commented that in doing this she was preparing him for his future burial.
* After Jesus died, his friends prepared his body for burial by anointing it with oils and spices.
* The titles "Messiah" (Hebrew) and "Christ" (Greek) mean "the Anointed (One)."
* Jesus the Messiah is the one who was chosen and anointed as a Prophet, High Priest, and King.

### Translation Suggestions:

* Depending on the context, the term "anoint" could be translated as "pour oil on" or "put oil on" or "consecrate by pouring perfumed oil on."
* To "be anointed" could be translated as "be consecrated with oil." or "be appointed" or "be consecrated."
* In some contexts the term "anoint" could be translated as "appoint."
* A phrase like "the anointed priest," could be translated as "the priest who was consecrated with oil" or "the priest who was set apart by the pouring on of oil."

(See also: [Christ](#christ), [consecrate](#consecrate), [high priest](#highpriest), [King of the Jews](#kingofthejews), [priest](#priest), [prophet](#prophet)  )

### Bible References:

* [1 John 02:20-21](https://git.door43.org/Door43/en_tn/src/master/1jn/02/20.md)
* [1 John 02:27-29](https://git.door43.org/Door43/en_tn/src/master/1jn/02/27.md)
* [1 Samuel 16:2-3](https://git.door43.org/Door43/en_tn/src/master/1sa/16/02.md)
* [Acts 04:27-28](https://git.door43.org/Door43/en_tn/src/master/act/04/27.md)
* [Amos 06:5-6](https://git.door43.org/Door43/en_tn/src/master/amo/06/05.md)
* [Exodus 29:5-7](https://git.door43.org/Door43/en_tn/src/master/exo/29/05.md)
* [James 05:13-15](https://git.door43.org/Door43/en_tn/src/master/jas/05/13.md)


### Word Data:

* Strong's: H47, H430, H1101, H1878, H3323, H4397, H4398, H4473, H4886, H4888, H4899, H5480, H8136, G32, G218, G743, G1472, G2025, G3462, G5545, G5548


## <a id="tw-term-kt-antichrist"/>antichrist, antichrists

### Definition:

The term "antichrist" refers to a person or teaching that is against Jesus Christ and his work. There are many antichrists in the world.

* The apostle John wrote that a person is the antichrist if he deceives people by saying that Jesus is not the Messiah or if he denies that Jesus is both God and human.
* The Bible also teaches that there is a general spirit of antichrist in the world which opposes Jesus' work.
* The New Testament book of Revelation explains that there will be a man called "the antichrist" who will be revealed in the end times. This man will attempt to destroy God's people, but he will be defeated by Jesus.

### Translation Suggestions:

* Other ways to translate this term could include a word or phrase that means "Christ-opposer" or "enemy of Christ" or "person who is against Christ."
* The phrase "spirit of the antichrist" could also be translated as "spirit that is against Christ" or "(someone) teaching lies about Christ" or "attitude of believing lies about Christ" or "spirit that teaches lies about Christ."
* Also consider how this term is translated in a Bible translation in a local or national language. (See: [How to Translate Unknowns](https://git.door43.org/Door43/en_man/src/master/translate/translate-unknown/01.md))

(See also: [Christ](#christ), [reveal](#reveal), [tribulation](other.html#tribulation))

### Bible References:


* [1 John 02:18-19](https://git.door43.org/Door43/en_tn/src/master/1jn/02/18.md)
* [1 John 04:1-3](https://git.door43.org/Door43/en_tn/src/master/1jn/04/01.md)
* [2 John 01:7-8](https://git.door43.org/Door43/en_tn/src/master/2jn/01/07.md)


### Word Data:

* Strong's: G500


## <a id="tw-term-kt-apostle"/>apostle, apostles, apostleship

### Definition:

The "apostles" were men sent by Jesus to preach about God and his kingdom. The term "apostleship" refers to the position and authority of those who were chosen as apostles.

* The word "apostle" means "someone who is sent out for a special purpose." The apostle has the same authority as the one who sent him.
* Jesus' twelve closest disciples became the first apostles. Other men, such as Paul and James, also became apostles.
* By God's power, the apostles were able to boldly preach the gospel and heal people, and were able to force demons to come out of people.

### Translation Suggestions:

* The word "apostle" can also be translated with a word or phrase that means "someone who is sent out" or "sent-out one" or "person who is called to go out and preach God's message to people."
* It is important to translate the terms "apostle" and "disciple" in different ways.
* Also consider how this term was translated in a Bible translation in a local or national language. (See [How to Translate Unknowns](https://git.door43.org/Door43/en_man/src/master/translate/translate-unknown/01.md))

(See also: [authority](#authority), [disciple](#disciple), [James (son of Zebedee)](names.html#jamessonofzebedee), [Paul](names.html#paul), [the twelve](#thetwelve))

### Bible References:

* [Jude 01:17-19](https://git.door43.org/Door43/en_tn/src/master/jud/01/17.md)
* [Luke 09:12-14](https://git.door43.org/Door43/en_tn/src/master/luk/09/12.md)

### Examples from the Bible stories:

* __[26:10](https://git.door43.org/Door43/en_tn/src/master/obs/26/10.md)__ Then Jesus chose twelve men who were called his __apostles__. The __apostles__  traveled with Jesus and learned from him.
* __[30:01](https://git.door43.org/Door43/en_tn/src/master/obs/30/01.md)__ Jesus sent his __apostles__  to preach and to teach people in many different villages.
* __[38:02](https://git.door43.org/Door43/en_tn/src/master/obs/38/02.md)__ Judas was one of Jesus' __apostles__. He was in charge of the __apostles'__  money bag, but he loved money and often stole from the bag.
* __[43:13](https://git.door43.org/Door43/en_tn/src/master/obs/43/13.md)__ The disciples devoted themselves to the __apostles'__  teaching, fellowship, eating together, and prayer.
* __[46:08](https://git.door43.org/Door43/en_tn/src/master/obs/46/08.md)__ Then a believer named Barnabas took Saul to the __apostles__  and told them how Saul had preached boldly in Damascus.


### Word Data:

* Strong's: G651, G652, G2491, G5376, G5570


## <a id="tw-term-kt-appoint"/>appoint, appoints, appointed

### Definition:

The terms "appoint" and "appointed" refer to choosing someone to fulfill a specific task or role.

* To "be appointed" can also refer to being "chosen" to receive something, as in "appointed to eternal life." That people were "appointed to eternal life" means they were chosen to receive eterna life.
* The phrase "appointed time" refers to God's "chosen time" or "planned time" for something to happen.
* The word "appoint" may also mean to "command" or "assign" someone to do something.
 
### Translation Suggestions:

* Depending on the context, ways to translate "appoint" could include "choose" or "assign" or "formally choose" or "designate." 
* The term "appointed" could be translated as "assigned" or "planned" or "specifically chose."
* The phrase "be appointed" could also be translated as "be chosen."

### Bible References:

* [1 Samuel 08:10-12](https://git.door43.org/Door43/en_tn/src/master/1sa/08/10.md)
* [Acts 03:19-20](https://git.door43.org/Door43/en_tn/src/master/act/03/19.md)
* [Acts 06:2-4](https://git.door43.org/Door43/en_tn/src/master/act/06/02.md)
* [Acts 13:48-49](https://git.door43.org/Door43/en_tn/src/master/act/13/48.md)
* [Genesis 41:33-34](https://git.door43.org/Door43/en_tn/src/master/gen/41/33.md)
* [Numbers 03:9-10](https://git.door43.org/Door43/en_tn/src/master/num/03/09.md)


### Word Data:

* Strong's: H561, H977, H2163, H2296, H2706, H2708, H2710, H3198, H3245, H3259, H3677, H3983, H4150, H4151, H4152, H4487, H4662, H5324, H5344, H5414, H5567, H5975, H6310, H6485, H6565, H6635, H6680, H6923, H6942, H6966, H7760, H7896, G322, G606, G1299, G1303, G1935, G2525, G2749, G4287, G4384, G4929, G5021, G5087


## <a id="tw-term-kt-ark"/>ark

### Definition:

The term "ark" literally refers to a rectangular wooden box that is made to hold or protect something. An ark can be large or small, depending on what it is being used for.

* In the English Bible, the word "ark" is first used to refer to the very large, rectangular, wooden boat that Noah built to escape the worldwide flood. The ark had a flat bottom, a roof, and walls.
* Ways to translate this term could include "very large boat" or "barge" or "cargo ship" or "large, box-shaped boat."
* The Hebrew word that is used to refer to this huge boat is the same word used for the basket or box that held baby Moses when his mother put him in the Nile River to hide him. In that case it is usually translated as "basket."
* In the phrase "ark of the covenant," a different Hebrew word is used for "ark." This could be translated as "box" or "chest" or "container."
* When choosing a term to translate "ark," it is important in each context to consider what size it is and what it is being used for.

(See also: [ark of the covenant](#arkofthecovenant), [basket](other.html#basket))

### Bible References:

* [1 Peter 03:18-20](https://git.door43.org/Door43/en_tn/src/master/1pe/03/18.md)
* [Exodus 16:33-36](https://git.door43.org/Door43/en_tn/src/master/exo/16/33.md)
* [Exodus 30:5-6](https://git.door43.org/Door43/en_tn/src/master/exo/30/05.md)
* [Genesis 08:4-5](https://git.door43.org/Door43/en_tn/src/master/gen/08/04.md)
* [Luke 17:25-27](https://git.door43.org/Door43/en_tn/src/master/luk/17/25.md)
* [Matthew 24:37-39](https://git.door43.org/Door43/en_tn/src/master/mat/24/37.md)

### Word Data:

* Strong's: H727, H8392, G2787


## <a id="tw-term-kt-arkofthecovenant"/>ark of the covenant, ark of Yahweh

### Definition:

These terms refer to a special wooden chest, overlaid with gold, that contained the two stone tablets on which the Ten Commandments were written. It also contained Aaron's staff and a jar of manna.

* The term "ark" here could be translated as "box" or "chest" or "container."
* The objects in this chest reminded the Israelites of God's covenant with them.
* The ark of the covenant was located in the "most holy place."
* God's presence was above the ark of the covenant in the most holy place of the tabernacle, where he spoke to Moses on behalf of the Israelites.
* During the time that the ark of the covenant was in the most holy place of the temple, the high priest was the only one who could approach the ark, once a year on the Day of Atonement.
* Many English versions translate the term "covenant decrees" literally as "testimony." This refers to the fact that the Ten Commandments were a testimony or witness to God's covenant with his people. It is also translated as "covenant law."

(See also: [ark](#ark), [covenant](#covenant), [atonement](#atonement), [holy place](#holyplace), [testimony](#testimony))

### Bible References:

* [1 Samuel 06:14-15](https://git.door43.org/Door43/en_tn/src/master/1sa/06/14.md)
* [Exodus 25:10-11](https://git.door43.org/Door43/en_tn/src/master/exo/25/10.md)
* [Hebrews 09:3-5](https://git.door43.org/Door43/en_tn/src/master/heb/09/03.md)
* [Judges 20:27-28](https://git.door43.org/Door43/en_tn/src/master/jdg/20/27.md)
* [Numbers 07:89](https://git.door43.org/Door43/en_tn/src/master/num/07/89.md)
* [Revelation 11:19](https://git.door43.org/Door43/en_tn/src/master/rev/11/19.md)


### Word Data:

* Strong's: H727, H1285, H3068


## <a id="tw-term-kt-atonement"/>atonement, atone, atones, atoned

### Definition:

The terms "atone" and "atonement" refer to how God provided a sacrifice to pay for people's sins and to appease his wrath for sin.

* In Old Testament times, God allowed temporary atonement to be made for the sins of the Israelites by the offering of a blood sacrifice, which involved killing an animal.
* As recorded in the New Testament, Christ's death on the cross is the only true and permanent atonement for sin.
* When Jesus died, he took the punishment that people deserve because of their sin. He paid the atonement price with his sacrificial death.

### Translation Suggestions:

* The term "atone" could be translated by a word or phrase that means "pay for" or "provide payment for" or "cause someone's sins to be forgiven" or "make amends for a crime."
* Ways to translate "atonement" could include "payment" or "sacrifice to pay for sin" or "providing the means of forgiveness."
* Make sure the translation of this term does not refer to payment of money.

(See also: [atonement lid](#atonementlid), [forgive](#forgive), [propitiation](#propitiation), [reconcile](#reconcile), [redeem](#redeem))

### Bible References:

* [Ezekiel 43:25-27](https://git.door43.org/Door43/en_tn/src/master/ezk/43/25.md)
* [Ezekiel 45:18-20](https://git.door43.org/Door43/en_tn/src/master/ezk/45/18.md)
* [Leviticus 04:20-21](https://git.door43.org/Door43/en_tn/src/master/lev/04/20.md)
* [Numbers 05:8-10](https://git.door43.org/Door43/en_tn/src/master/num/05/08.md)
* [Numbers 28:19-22](https://git.door43.org/Door43/en_tn/src/master/num/28/19.md)


### Word Data:

* Strong's: H3722, H3725, G2643


## <a id="tw-term-kt-atonementlid"/>atonement lid

### Definition:

The "atonement lid" was a slab of gold that was used to cover the top of the ark of the covenant. In many English translations, it is also referred to as an "atonement cover."

* The atonement lid was about 115 centimeters in length and 70 centimeters in width.
* Above the atonement lid were two gold cherubim with their wings touching.
* Yahweh said that he would meet with the Israelites above the atonement lid, under the outstretched wings of the cherubim. Only the high priest was permitted to meet with Yahweh in this way, as the representative of the people.
* Sometimes this atonement lid has been referred to as a "mercy seat" because it communicates God's mercy in coming down to redeem sinful human beings.

### Translation Suggestions:

* Other ways to translate this term could include "ark covering where God promises to redeem" or "place where God atones" or "lid of ark where God forgives and restores."
* Can also mean "place of propitiation."
* Compare this term with how you translated "atonement," "propitiation," and "redemption."

(See also: [ark of the covenant](#arkofthecovenant), [atonement](#atonement), [cherubim](other.html#cherubim), [propitiation](#propitiation), [redeem](#redeem))

### Bible References:

* [Exodus 25:15-18](https://git.door43.org/Door43/en_tn/src/master/exo/25/15.md)
* [Exodus 30:5-6](https://git.door43.org/Door43/en_tn/src/master/exo/30/05.md)
* [Exodus 40:17-20](https://git.door43.org/Door43/en_tn/src/master/exo/40/17.md)
* [Leviticus 16:1-2](https://git.door43.org/Door43/en_tn/src/master/lev/16/01.md)
* [Numbers 07:89](https://git.door43.org/Door43/en_tn/src/master/num/07/89.md)

### Word Data:

* Strong's: H3727, G2435


## <a id="tw-term-kt-authority"/>authority, authorities

### Definition:

The term "authority" refers to the power of influence and control that someone has over someone else.

 * Kings and other governing rulers have authority over the people they are ruling.
 * The word "authorities" can refer to people, governments, or organizations that have authority over others. 
 * The word "authorities" can also refer to spirit beings who have power over people who have not submitted themselves to God’s authority.
 * Masters have authority over their servants or slaves. Parents have authority over their children.
 * Governments have the authority or right to make laws that govern their citizens.

### Translation Suggestions:

 * The term "authority" can also be translated as "control" or "right" or "qualifications."
 * Sometimes "authority" is used with the meaning of "power."
 * When "authorities" is used to refer to people or organizations who rule people, it could also be translated as "leaders" or "rulers" or "powers."
 * The phrase "by his own authority" could also be translated as, "with his own right to lead" or "based on his own qualifications."
 * The expression, "under authority" could be translated as, "responsible to obey" or "having to obey others' commands."

(See also: [citizen](other.html#citizen), [command](#command), [obey](other.html#obey), [power](#power), [ruler](other.html#ruler))

### Bible References:

* [Colossians 02:10-12](https://git.door43.org/Door43/en_tn/src/master/col/02/10.md)
* [Esther 09:29](https://git.door43.org/Door43/en_tn/src/master/est/09/29.md)
* [Genesis 41:35-36](https://git.door43.org/Door43/en_tn/src/master/gen/41/35.md)
* [Jonah 03:6-7](https://git.door43.org/Door43/en_tn/src/master/jon/03/06.md)
* [Luke 12:4-5](https://git.door43.org/Door43/en_tn/src/master/luk/12/04.md)
* [Luke 20:1-2](https://git.door43.org/Door43/en_tn/src/master/luk/20/01.md)
* [Mark 01:21-22](https://git.door43.org/Door43/en_tn/src/master/mrk/01/21.md)
* [Matthew 08:8-10](https://git.door43.org/Door43/en_tn/src/master/mat/08/08.md)
* [Matthew 28:18-19](https://git.door43.org/Door43/en_tn/src/master/mat/28/18.md)
* [Titus 03:1-2](https://git.door43.org/Door43/en_tn/src/master/tit/03/01.md)


### Word Data:

* Strong's: H8633, G831, G1413, G1849, G1850, G2003, G2715, G5247


## <a id="tw-term-kt-baptize"/>baptize, baptized, baptism

### Definition:

In the New Testament, the terms "baptize" and "baptism" usually refer to ritually bathing a Christian with water to show that he has been cleansed from sin and has been united with Christ.

* Besides water baptism, the Bible talks about being "baptized with the Holy Spirit" and "baptized with fire."
* The term "baptism" is also used in the Bible to refer to going through great suffering.

### Translation Suggestions:

* Christians have different views about how a person should be baptized with water. It is probably best to translate this term in a general way that allows for different ways of applying the water.
* Depending on the context, the term "baptize" could be translated as "purify," "pour out on," "plunge (or dip) into," "wash," or "spiritually cleanse." For example, "baptize you with water" could be translated as, "plunge you into water."
* The term "baptism" could be translated as "purification," "a pouring out," "a dipping," "a cleansing," or "a spiritual washing."
* When it refers to suffering, "baptism" could also be translated as "a time of terrible suffering" or "a cleansing through severe suffering."
* Also consider how this term is translated in a Bible translation in a local or national language.

(See also: [How to Translate Unknowns](https://git.door43.org/Door43/en_man/src/master/translate/translate-unknown/01.md))

(See also: [John (the Baptist)](names.html#johnthebaptist), [repent](#repent), [Holy Spirit](#holyspirit))

### Bible References:

* [Acts 02:37-39](https://git.door43.org/Door43/en_tn/src/master/act/02/37.md)
* [Acts 08:36-38](https://git.door43.org/Door43/en_tn/src/master/act/08/36.md)
* [Acts 09:17-19](https://git.door43.org/Door43/en_tn/src/master/act/09/17.md)
* [Acts 10:46-48](https://git.door43.org/Door43/en_tn/src/master/act/10/46.md)
* [Luke 03:15-16](https://git.door43.org/Door43/en_tn/src/master/luk/03/15.md)
* [Matthew 03:13-15](https://git.door43.org/Door43/en_tn/src/master/mat/03/13.md)
* [Matthew 28:18-19](https://git.door43.org/Door43/en_tn/src/master/mat/28/18.md)

### Examples from the Bible stories:

* __[24:03](https://git.door43.org/Door43/en_tn/src/master/obs/24/03.md)__ When people heard John's message, many of them repented from their sins, and John __baptized__  them. Many religious leaders also came to be __baptized__  by John, but they did not repent or confess their sins.
* __[24:06](https://git.door43.org/Door43/en_tn/src/master/obs/24/06.md)__ The next day, Jesus came to be __baptized__  by John.
* __[24:07](https://git.door43.org/Door43/en_tn/src/master/obs/24/07.md)__ John said to Jesus, "I am not worthy to __baptize__  you. You should __baptize__  me instead."
* __[42:10](https://git.door43.org/Door43/en_tn/src/master/obs/42/10.md)__ So go, make disciples of all people groups by __baptizing__  them in the name of the Father, the Son, and the Holy Spirit and by teaching them to obey everything I have commanded you."
* __[43:11](https://git.door43.org/Door43/en_tn/src/master/obs/43/11.md)__ Peter answered them, "Every one of you should repent and be __baptized__  in the name of Jesus Christ so that God will forgive your sins."
* __[43:12](https://git.door43.org/Door43/en_tn/src/master/obs/43/12.md)__ About 3,000 people believed what Peter said and became disciples of Jesus. They were __baptized__  and became part of the church at Jerusalem.
* __[45:11](https://git.door43.org/Door43/en_tn/src/master/obs/45/11.md)__ As Philip and the Ethiopian traveled, they came to some water. The Ethiopian said, "Look! There is some water! May I be __baptized__?"
* __[46:05](https://git.door43.org/Door43/en_tn/src/master/obs/46/05.md)__ Saul immediately was able to see again, and Ananias __baptized__  him.
* __[49:14](https://git.door43.org/Door43/en_tn/src/master/obs/49/14.md)__ Jesus invites you to believe in him and be __baptized__.


### Word Data:

* Strong's: G907


## <a id="tw-term-kt-believe"/>believe, believes, believed, believer, belief, unbeliever, unbelievers, unbelief

### Definition:

The terms "believe" and "believe in" are closely related, but have slightly different meanings:

### 1. believe

* To believe something is to accept or trust that it is true.
* To believe someone is to acknowledge that what that person has said is true.

### 2. believe in

* To "believe in" someone means to "trust in" that person.  It means to trust that the person is who he says he is, that he always speaks the truth, and that he will do what he has promised to do.
* When a person truly believes in something, he will act in such a way that shows that belief.
* The phrase "have faith in" usually has the same meaning as "believe in."
* To "believe in Jesus" means to believe that he is the Son of God, that he is God himself who also became human and who died as a sacrifice to pay for our sins. It means to trust him as Savior and live in a way that honors him.

In the Bible, the term "believer" refers to someone who believes in and relies on Jesus Christ as Savior.

* The term "believer" literally means "person who believes."
* The term "Christian" eventually came to be the main title for believers because it indicates that they believe in Christ and obey his teachings.

The term "unbelief" refers to not believing something or someone.

* In the Bible, "unbelief" refers to not believing in or not trusting in Jesus as one's Savior.
* A person who does not believe in Jesus is called an "unbeliever."

### Translation Suggestions:

* To "believe" could be translated as to "know to be true" or "know to be right."
* To "believe in" could be translated as "trust completely" or "trust and obey" or "completely rely on and follow."

* Some translations may prefer to say "believer in Jesus" or "believer in Christ."
* This term could also be translated by a word or phrase that means "person who trusts in Jesus" or "someone who knows Jesus and lives for him."
* Other ways to translate "believer" could be "follower of Jesus" or "person who knows and obeys Jesus."
* The term "believer" is a general term for any believer in Christ, while "disciple" and "apostle" were used more specifically for people who knew Jesus while he was alive. It is best to translate these terms in different ways, in order to keep them distinct.

* Other ways to translate "unbelief" could include "lack of faith" or "not believing."
* The term "unbeliever" could be translated as "person who does not believe in Jesus" or "someone who does not trust in Jesus as Savior."

(See also: [believe](#believe), [apostle](#apostle), [Christian](#christian), [disciple](#disciple), [faith](#faith), [trust](#trust))

### Bible References:

* [Genesis 15:6-8](https://git.door43.org/Door43/en_tn/src/master/gen/15/06.md)
* [Genesis 45:24-26](https://git.door43.org/Door43/en_tn/src/master/gen/45/24.md)
* [Job 09:16-18](https://git.door43.org/Door43/en_tn/src/master/job/09/16.md)
* [Habakkuk 01:5-7](https://git.door43.org/Door43/en_tn/src/master/hab/01/05.md)
* [Mark 06:4-6](https://git.door43.org/Door43/en_tn/src/master/mrk/06/04.md)
* [Mark 01:14-15](https://git.door43.org/Door43/en_tn/src/master/mrk/01/14.md)
* [Luke 09:41-42](https://git.door43.org/Door43/en_tn/src/master/luk/09/41.md)
* [John 01:12-13](https://git.door43.org/Door43/en_tn/src/master/jhn/01/12.md)
* [Acts 06:5-6](https://git.door43.org/Door43/en_tn/src/master/act/06/05.md)
* [Acts 09:40-43](https://git.door43.org/Door43/en_tn/src/master/act/09/40.md)
* [Acts 28:23-24](https://git.door43.org/Door43/en_tn/src/master/act/28/23.md)
* [Romans 03:3-4](https://git.door43.org/Door43/en_tn/src/master/rom/03/03.md)
* [1 Corinthians 06:1-3](https://git.door43.org/Door43/en_tn/src/master/1co/06/01.md)
* [1 Corinthians 09:3-6](https://git.door43.org/Door43/en_tn/src/master/1co/09/03.md)
* [2 Corinthians 06:14-16](https://git.door43.org/Door43/en_tn/src/master/2co/06/14.md)
* [Hebrews 03:12-13](https://git.door43.org/Door43/en_tn/src/master/heb/03/12.md)
* [1 John 03:23-24](https://git.door43.org/Door43/en_tn/src/master/1jn/03/23.md)

### Examples from the Bible stories:

* __[03:04](https://git.door43.org/Door43/en_tn/src/master/obs/03/04.md)__ Noah warned the people about the coming flood and told them to turn to God, but they did not __believe__  him.
* __[04:08](https://git.door43.org/Door43/en_tn/src/master/obs/04/08.md)__ Abram __believed__  God's promise. God declared that Abram was righteous because he __believed__  God's promise.
* __[11:02](https://git.door43.org/Door43/en_tn/src/master/obs/11/02.md)__ God provided a way to save the firstborn of anyone who __believed in__  him.
* __[11:06](https://git.door43.org/Door43/en_tn/src/master/obs/11/06.md)__ But the Egyptians did not __believe__  God or obey his commands.
* __[37:05](https://git.door43.org/Door43/en_tn/src/master/obs/37/05.md)__ Jesus replied, "I am the Resurrection and the Life. Whoever __believes in__  me will live, even though he dies. Everyone who __believes in__  me will never die. Do you __believe__  this?"
* __[43:01](https://git.door43.org/Door43/en_tn/src/master/obs/43/01.md)__ After Jesus returned to heaven, the disciples stayed in Jerusalem as Jesus had commanded them to do. The __believers__  there constantly gathered together to pray.
* __[43:03](https://git.door43.org/Door43/en_tn/src/master/obs/43/03.md)__ While the __believers__  were all together, suddenly the house where they were was filled with a sound like a strong wind. Then something that looked like flames of fire appeared over the heads of all the __believers__.
* __[43:13](https://git.door43.org/Door43/en_tn/src/master/obs/43/13.md)__ Every day, more people became __believers__.
* __[46:06](https://git.door43.org/Door43/en_tn/src/master/obs/46/06.md)__ That day many people in Jerusalem started persecuting the followers of Jesus, so the __believers__  fled to other places. But in spite of this, they preached about Jesus everywhere they went.
* __[46:01](https://git.door43.org/Door43/en_tn/src/master/obs/46/01.md)__ Saul was the young man who guarded the robes of the men who killed Stephen. He did not believe in Jesus, so he persecuted the __believers__.
* __[46:09](https://git.door43.org/Door43/en_tn/src/master/obs/46/09.md)__ Some __believers__  who fled from the persecution in Jerusalem went far away to the city of Antioch and preached about Jesusâ€¦It was at Antioch that __believers__  in Jesus were first called "Christians."
* __[47:14](https://git.door43.org/Door43/en_tn/src/master/obs/47/14.md)__ They also wrote many letters to encourage and teach the __believers__  in the churches.


### Word Data:

* Strong's: H539, H540, G543, G544, G569, G570, G571, G3982, G4100, G4102, G4103, G4135


## <a id="tw-term-kt-beloved"/>beloved

### Definition:

The term "beloved" is an expression of affection that describes someone who is loved and dear to someone else.

* The term "beloved" literally means "loved (one)" or "(who is) loved."
* God refers to Jesus as his "beloved Son."
* In their letters to Christian churches, the apostles frequently address their fellow believers as "beloved."

### Translation Suggestions:

* This term could also be translated as "loved" or "loved one" or "well-loved," or "very dear."
* In the context of talking about a close friend, this could be translated as "my dear friend" or "my close friend." In English it is natural to say "my dear friend, Paul" or "Paul, who is my dear friend." Other languages may find it more natural to order this in a different way.
* Note that the word "beloved" comes from the word for God's love, which is unconditional, unselfish, and sacrificial.

(See also: [love](#love))

### Bible References:

* [1 Corinthians 04:14-16](https://git.door43.org/Door43/en_tn/src/master/1co/04/14.md)
* [1 John 03:1-3](https://git.door43.org/Door43/en_tn/src/master/1jn/03/01.md)
* [1 John 04:7-8](https://git.door43.org/Door43/en_tn/src/master/1jn/04/07.md)
* [Mark 01:9-11](https://git.door43.org/Door43/en_tn/src/master/mrk/01/09.md)
* [Mark 12:6-7](https://git.door43.org/Door43/en_tn/src/master/mrk/12/06.md)
* [Revelation 20:9-10](https://git.door43.org/Door43/en_tn/src/master/rev/20/09.md)
* [Romans 16:6-8](https://git.door43.org/Door43/en_tn/src/master/rom/16/06.md)
* [Song of Solomon 01:12-14](https://git.door43.org/Door43/en_tn/src/master/sng/01/12.md)

### Word Data:

* Strong's: H157, H1730, H2532, H3033, H3039, H4261, G25, G27, G5207


## <a id="tw-term-kt-birthright"/>birthright

### Definition:

The term "birthright" in the Bible refers to the honor, family name, and physical wealth that was normally given to the firstborn son in a family.

* The birthright of the firstborn son included a double portion of the father's inheritance.
* A king's firstborn son was normally given the birthright to rule after his father died.
* Esau sold his birthright to his younger brother Jacob. Because of this, Jacob inherited the blessing of the firstborn instead of Esau.
* The birthright also included the honor of having the family descendants traced through the firstborn son's line.

### Translation Suggestions:

* Possible ways to translate "birthright" could include, "rights and wealth of the firstborn son" or "family honor" or "privilege and inheritance of the firstborn." 
  

(See also: [firstborn](other.html#firstborn), [inherit](#inherit), [descendant](other.html#descendant))

### Bible References:

* [1 Chronicles 05:1-3](https://git.door43.org/Door43/en_tn/src/master/1ch/05/01.md)
* [Genesis 25:31-34](https://git.door43.org/Door43/en_tn/src/master/gen/25/31.md)
* [Genesis 43:32-34](https://git.door43.org/Door43/en_tn/src/master/gen/43/32.md)
* [Hebrews 12:14-17](https://git.door43.org/Door43/en_tn/src/master/heb/12/14.md)

### Word Data:

* Strong's: H1062, G4415


## <a id="tw-term-kt-blameless"/>blameless

### Definition:

The term "blameless" literally means "without blame." It is used to refer to a person who obeys God wholeheartedly, but it does not mean that the person is sinless.

* Abraham and Noah were considered blameless before God.
* A person who has a reputation for being "blameless" behaves in a way that honors God.
* According to one verse, a person who is blameless is "one who fears God and turns away from evil."

### Translation Suggestions:

* This could also be translated as "with no fault to his character" or "completely obedient to God" or "avoiding sin" or "keeping away from evil."

### Bible References:

* [1 Thessalonians 02:10-12](https://git.door43.org/Door43/en_tn/src/master/1th/02/10.md)
* [1 Thessalonians 03:11-13](https://git.door43.org/Door43/en_tn/src/master/1th/03/11.md)
* [2 Peter 03:14-16](https://git.door43.org/Door43/en_tn/src/master/2pe/03/14.md)
* [Colossians 01:21-23](https://git.door43.org/Door43/en_tn/src/master/col/01/21.md)
* [Genesis 17:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/17/01.md)
* [Philippians 02:14-16](https://git.door43.org/Door43/en_tn/src/master/php/02/14.md)
* [Philippians 03:6-7](https://git.door43.org/Door43/en_tn/src/master/php/03/06.md)

### Word Data:

* Strong's: H5352, H5355, G273, G274, G298, G338, G410, G423


## <a id="tw-term-kt-blasphemy"/>blasphemy, blaspheme, blasphemed, blasphemous, blasphemies

### Definition:

In the Bible, the term "blasphemy" refers to speaking in a way that shows a deep disrespect for God or people. To "blaspheme" someone is to speak against that person so that others think something false or bad about him.

* Most often, to blaspheme God means to slander or insult him by saying things that are not true about him or by behaving in an immoral way that dishonors him.
* It is blasphemy for a human being to claim to be God or to claim that there is a God other than the one true God.
* Some English versions translate this term as "slander" when it refers to blaspheming people.

### Translation Suggestions:

* To "blaspheme" can be translated as to "say evil things against" or to "dishonor God" or to "slander."
* Ways to translate "blasphemy" could include "speaking wrongly about others" or "slander" or "spreading false rumors."

(See also: [dishonor](other.html#dishonor), [slander](other.html#slander))

### Bible References:

* [1 Timothy 01:12-14](https://git.door43.org/Door43/en_tn/src/master/1ti/01/12.md)
* [Acts 06:10-11](https://git.door43.org/Door43/en_tn/src/master/act/06/10.md)
* [Acts 26:9-11](https://git.door43.org/Door43/en_tn/src/master/act/26/09.md)
* [James 02:5-7](https://git.door43.org/Door43/en_tn/src/master/jas/02/05.md)
* [John 10:32-33](https://git.door43.org/Door43/en_tn/src/master/jhn/10/32.md)
* [Luke 12:8-10](https://git.door43.org/Door43/en_tn/src/master/luk/12/08.md)
* [Mark 14:63-65](https://git.door43.org/Door43/en_tn/src/master/mrk/14/63.md)
* [Matthew 12:31-32](https://git.door43.org/Door43/en_tn/src/master/mat/12/31.md)
* [Matthew 26:65-66](https://git.door43.org/Door43/en_tn/src/master/mat/26/65.md)
* [Psalms 074:9-11](https://git.door43.org/Door43/en_tn/src/master/psa/074/009.md)


### Word Data:

* Strong's: H1288, H1442, H2778, H5006, H5007, H5344, G987, G988, G989


## <a id="tw-term-kt-bless"/>bless, blessed, blessing

### Definition:

To "bless" someone or something means to cause good and beneficial things to happen to the person or thing that is being blessed.

* Blessing someone also means expressing a desire for positive and beneficial things to happen to that person.
* In Bible times, a father would often pronounce a formal blessing on his children.
* When people "bless" God or express a desire that God be blessed, this means they are praising him.
* The term "bless" is sometimes used for consecrating food before it is eaten, or for thanking and praising God for the food.


### Translation Suggestions:

* To "bless" could also be translated as to "provide abundantly for" or to "be very kind and favorable toward."
* "God has brought great blessing to" could be translated as "God has given many good things to" or "God has provided abundantly for" or "God has caused many good things to happen to".
* "He is blessed" could be translated as "he will greatly benefit" or "he will experience good things" or "God will cause him to flourish."
* "Blessed is the person who" could be translated as "How good it is for the person who."
* Expressions like "blessed be the Lord" could be translated as "May the Lord be praised" or "Praise the Lord" or "I praise the Lord."
* In the context of blessing food, this could be translated as "thanked God for the food" or "praised God for giving them food" or "consecrated the food by praising God for it."

(See also: [praise](other.html#praise))

### Bible References:

* [1 Corinthians 10:14-17](https://git.door43.org/Door43/en_tn/src/master/1co/10/14.md)
* [Acts 13:32-34](https://git.door43.org/Door43/en_tn/src/master/act/13/32.md)
* [Ephesians 01:3-4](https://git.door43.org/Door43/en_tn/src/master/eph/01/03.md)
* [Genesis 14:19-20](https://git.door43.org/Door43/en_tn/src/master/gen/14/19.md)
* [Isaiah 44:3-4](https://git.door43.org/Door43/en_tn/src/master/isa/44/03.md)
* [James 01:22-25](https://git.door43.org/Door43/en_tn/src/master/jas/01/22.md)
* [Luke 06:20-21](https://git.door43.org/Door43/en_tn/src/master/luk/06/20.md)
* [Matthew 26:26](https://git.door43.org/Door43/en_tn/src/master/mat/26/26.md)
* [Nehemiah 09:5-6](https://git.door43.org/Door43/en_tn/src/master/neh/09/05.md)
* [Romans 04:9-10](https://git.door43.org/Door43/en_tn/src/master/rom/04/09.md)

### Examples from the Bible stories:

* __[01:07](https://git.door43.org/Door43/en_tn/src/master/obs/01/07.md)__ God saw that it was good and he __blessed__  them.
* __[01:15](https://git.door43.org/Door43/en_tn/src/master/obs/01/15.md)__ God made Adam and Eve in his own image. He __blessed__  them and told them, "Have many children and grandchildren and fill the earth."
* __[01:16](https://git.door43.org/Door43/en_tn/src/master/obs/01/16.md)__ So God rested from all he had been doing. He __blessed__  the seventh day and made it holy, because on this day he rested from his work.
* __[04:04](https://git.door43.org/Door43/en_tn/src/master/obs/04/04.md)__ "I will make your name great. I will __bless__  those who __bless__  you and curse those who curse you. All families on earth will be __blessed__  because of you."
* __[04:07](https://git.door43.org/Door43/en_tn/src/master/obs/04/07.md)__ Melchizedek __blessed__  Abram and said, "May God Most High who owns heaven and earth __bless__  Abram."
* __[07:03](https://git.door43.org/Door43/en_tn/src/master/obs/07/03.md)__ Isaac wanted to give his __blessing__  to Esau.
* __[08:05](https://git.door43.org/Door43/en_tn/src/master/obs/08/05.md)__ Even in prison, Joseph remained faithful to God, and God __blessed__  him.

### Word Data:

* Strong's: H833, H835, H1288, H1289, H1293, G1757, G2127, G2128, G2129, G3106, G3107, G3108, G6050


## <a id="tw-term-kt-blood"/>blood

### Definition:

The term "blood" refers to the red liquid that comes out of a person's skin when there is an injury or wound. Blood brings life-giving nutrients to a person's entire body.

* Blood symbolizes life and when it is shed or poured out, it symbolizes the loss of life, or death.
* When people made sacrifices to God, they killed an animal and poured its blood on the altar. This symbolized the sacrifice of the animal's life to pay for people's sins.
* Through his death on the cross, Jesus' blood symbolically cleanses people from their sins and pays for the punishment they deserve for those sins.
* The expression "flesh and blood" refers to human beings.
* The expression "own flesh and blood" refers to people who are biologically related.

### Translation Suggestions:

* This term should be translated with the term that is used for blood in the target language.
* The expression "flesh and blood" could be translated as "people" or "human beings."
* Depending on the context, the expression "my own flesh and blood" could be translated as "my own family" or "my own relatives" or "my own people."
* If there is an expression in the target language that is used with this meaning, that expression could be used to translate "flesh and blood."

(See also: [flesh](#flesh))

### Bible References:

* [1 John 01:5-7](https://git.door43.org/Door43/en_tn/src/master/1jn/01/05.md)
* [1 Samuel 14:31-32](https://git.door43.org/Door43/en_tn/src/master/1sa/14/31.md)
* [Acts 02:20-21](https://git.door43.org/Door43/en_tn/src/master/act/02/20.md)
* [Acts 05:26-28](https://git.door43.org/Door43/en_tn/src/master/act/05/26.md)
* [Colossians 01:18-20](https://git.door43.org/Door43/en_tn/src/master/col/01/18.md)
* [Galatians 01:15-17](https://git.door43.org/Door43/en_tn/src/master/gal/01/15.md)
* [Genesis 04:10-12](https://git.door43.org/Door43/en_tn/src/master/gen/04/10.md)
* [Psalms 016:4](https://git.door43.org/Door43/en_tn/src/master/psa/016/004.md)
* [Psalms 105:28-30](https://git.door43.org/Door43/en_tn/src/master/psa/105/028.md)

### Examples from the Bible stories:

* __[08:03](https://git.door43.org/Door43/en_tn/src/master/obs/08/03.md)__ Before Joseph's brothers returned home, they tore Joseph's robe and dipped it in goat's __blood__.
* __[10:03](https://git.door43.org/Door43/en_tn/src/master/obs/10/03.md)__ God turned the Nile River into __blood__, but Pharaoh still would not let the Israelites go.
* __[11:05](https://git.door43.org/Door43/en_tn/src/master/obs/11/05.md)__ All the houses of the Israelites had __blood__  around the doors, so God passed over those houses and everyone inside was safe. They were saved because of the lamb's __blood__.
* __[13:09](https://git.door43.org/Door43/en_tn/src/master/obs/13/09.md)__ The __blood__  of the animal that was sacrificed covered the person's sin and made that person clean in God's sight.
* __[38:05](https://git.door43.org/Door43/en_tn/src/master/obs/38/05.md)__ Then Jesus took a cup and said, "Drink this. It is my __blood__  of the New Covenant that is poured out for the forgiveness of sins.
* __[48:10](https://git.door43.org/Door43/en_tn/src/master/obs/48/10.md)__ When anyone believes in Jesus, the __blood__  of Jesus takes away that person's sin, and God's punishment passes over him.

### Word Data:

* Strong's: H1818, H5332, G129, G130, G131, G1420


## <a id="tw-term-kt-boast"/>boast, boasts, boastful

### Definition:

The term "boast" means to talk proudly about something or someone. Often it means to brag about oneself.

* Someone who is "boastful" talks about himself in a proud way.
* God rebuked the Israelites for "boasting in" their idols. They arrogantly worshiped false gods instead of the true God.
* The Bible also talks about people boasting in such things as their wealth, their strength, their fruitful fields, and their laws. This means that they were proud about these things and did not acknowledge that God is the one who provided these things.
* God urged the Israelites to instead "boast" or be proud about the fact that they know him.
* The apostle Paul also talks about boasting in the Lord, which means being glad and thankful to God for all he has done for them.

### Translation Suggestions:

* Other ways to translate "boast" could include "brag" or "talk proudly" or "be proud."
* The term "boastful" could be translated by a word or phrase that means "full of prideful talk" or "prideful" or "talking proudly about oneself."
* In the context of boasting in or about knowing God, this could be translated as "take pride in" or "exalt in" or "be very glad about" or "give thanks to God about."
* Some languages have two words for "pride": one that is negative, with the meaning of being arrogant, and the other that is positive, with the meaning of taking pride in one's work, family, or country.

### Translation Suggestions:

(See also: [proud](other.html#proud))

### Bible References:

* [1 Kings 20:11-12](https://git.door43.org/Door43/en_tn/src/master/1ki/20/11.md)
* [2 Timothy 03:1-4](https://git.door43.org/Door43/en_tn/src/master/2ti/03/01.md)
* [James 03:13-14](https://git.door43.org/Door43/en_tn/src/master/jas/03/13.md)
* [James 04:15-17](https://git.door43.org/Door43/en_tn/src/master/jas/04/15.md)
* [Psalms 044:7-8](https://git.door43.org/Door43/en_tn/src/master/psa/044/007.md)


### Word Data:

* Strong's: H1984, H3235, H6286, G212, G213, G2620, G2744, G2745, G2746, G3166


## <a id="tw-term-kt-body"/>body, bodies

### Definition:

The term "body" literally refers to the physical body of a person or animal. This term is also used figuratively to refer to an object or  whole group that has individual members.

* Often the term "body" refers to a dead person or animal. Sometimes this is referred to as a "dead body" or a "corpse."
* When Jesus said to the disciples at his last Passover meal, "This (bread) is my body," he was referring to his physical body that would be "broken" (killed) to pay for their sins.
* In the Bible, Christians as a group are referred to as the "body of Christ."
* Just as a physical body has many parts, the "body of Christ" has many individual members.
* Each individual believer has a special function in the body of Christ to help the whole group work together to serve God and bring him glory.
* Jesus is also referred to as the "head" (leader) of the "body" of his believers. Just as a person's head tells his body what to do, so Jesus is the one who guides and directs Christians as members of his "body."

### Translation Suggestions:

* The best way to translate this term would be with the word that is most commonly used to refer to a physical body in the project language. Make sure that the word used is not an offensive term.
* When referring collectively to believers, for some languages it may be more natural and accurate to say "spiritual body of Christ."
* When Jesus says, "This is my body," it is best to translate this literally, with a note to explain it if needed.
* Some languages may have a separate word when referring to a dead body, such as "corpse" for a person or "carcass" for an animal. Make sure the word used to translate this makes sense in the context and is acceptable.

(See also: [head](other.html#head), [spirit](#spirit))

### Bible References:

* [1 Chronicles 10:11-12](https://git.door43.org/Door43/en_tn/src/master/1ch/10/11.md)
* [1 Corinthians 05:3-5](https://git.door43.org/Door43/en_tn/src/master/1co/05/03.md)
* [Ephesians 04:4-6](https://git.door43.org/Door43/en_tn/src/master/eph/04/04.md)
* [Judges 14:7-9](https://git.door43.org/Door43/en_tn/src/master/jdg/14/07.md)
* [Numbers 06:6-8](https://git.door43.org/Door43/en_tn/src/master/num/06/06.md)
* [Psalm 031:8-9](https://git.door43.org/Door43/en_tn/src/master/psa/031/008.md)
* [Romans 12:4-5](https://git.door43.org/Door43/en_tn/src/master/rom/12/04.md)


### Word Data:

* Strong's: H990, H1320, H1460, H1465, H1472, H1480, H1655, H3409, H4191, H5038, H5085, H5315, H6106, H6297, H7607, G4430, G4954, G4983, G5559


## <a id="tw-term-kt-bond"/>bind, bond, bound

### Definition:

The term "bind" means to tie something or fasten it securely. Something that is tied or joined together is called a "bond." The term "bound" is the past tense of this term.

* To be "bound" means to have something tied or wrapped around something else.
* In a figurative sense, a person can be "bound" to a vow, which means he is "required to fulfill" what he promised to do.
* The term "bonds" refers to anything that binds, confines, or imprisons someone. It usually refers to physical chains, fetters or ropes that keep a person from being free to move.
* In Bible times, bonds such as ropes or chains were used to attach prisoners to the wall or floor of a stone prison.
* The term "bind" can also be used to talk about wrapping cloth around a wound to help it heal.
* A dead person would be "bound" with cloth in preparation for burial.
* The term "bond" is used figuratively to refer to something, such as sin, that controls or enslaves someone.
* A bond can also be a close relationship between people in which they support each other emotionally, spiritually and physically. This applies to the bond of marriage.
* For example, a husband and wife are "bound" or tied to each other. It is a bond that God does not want broken.

### Translation Suggestions:

* The term "bind" could also be translated as "tie" or "tie up" or "wrap (around)."
* Figuratively, it could be translated as to "restrain" or to "prevent" or to "keep from (something)."
* A special use of "bind" in Matthew 16 and 18 means "forbid" or "not permit."
* The term "bonds" could be translated as "chains" or "ropes" or "shackles."
* Figuratively the term "bond" could be translated as "knot" or "connection" or "close relationship."
* The phrase "bond of peace" means "being in harmony, which brings people in closer relationship to each other" or "the tying together that peace brings."
* To "bind up" could be translated as "wrap around" or "put a bandage on."
* To "bind" oneself with a vow could be translated as "promise to fulfill a vow" or "commit to fulfill a vow."
* Depending on the context, the term "bound" could also be translated as "tied" or "tied up" or "chained" or "obligated (to fulfill)" or "required to do."

(See also: [fulfill](#fulfill), [peace](other.html#peace), [prison](other.html#prison), [servant](other.html#servant), [vow](#vow))

### Bible References:

* [Leviticus 08:6-7](https://git.door43.org/Door43/en_tn/src/master/lev/08/06.md)

### Word Data:

* Strong's: H247, H481, H519, H615, H631, H632, H640, H1366, H1367, H1379, H2280, H2706, H3256, H3533, H3729, H4147, H4148, H4205, H4562, H5650, H5656, H5659, H6029, H6123, H6616, H6696, H6872, H6887, H7194, H7405, H7573, H7576, H8198, H8244, H8379, G254, G331, G332, G1195, G1196, G1198, G1199, G1210, G1397, G1398, G1401, G1402, G2611, G2615, G3734, G3784, G3814, G4019, G4029, G4385, G4886, G4887, G5265


## <a id="tw-term-kt-bornagain"/>born again, born of God, new birth

### Definition:

The term "born again" was first used by Jesus to describe what it means for God to change a person from being dead spiritually to being alive spiritually. The terms "born of God" and "born of the Spirit" also refer to a person being given new spiritual life.

* All humans are born spiritually dead and are given a "new birth" when they accept Jesus Christ as their Savior.
* At the moment of the spiritual new birth, God's Holy Spirit begins to live in the new believer and empowers him to produce good spiritual fruit in his life.
* It is God's work to cause a person to be born again and become his child.

### Translation Suggestions:

* Other ways to translate "born again" could include "born anew" or "born spiritually."
* It is best to translate this term literally and use the normal word in the language that would be used for being born.
* The term "new birth" might be translated as "spiritual birth."
* The phrase "born of God" could be translated as "caused by God to have new life like a newborn baby" or "given new life by God."
* In the same way, "born of the Spirit" could be translated as "given new life by the Holy Spirit" or "empowered by the Holy Spirit to become God's child" or "caused by the Spirit to have new life like a newborn baby."

(See also: [Holy Spirit](#holyspirit), [save](#save))

### Bible References:

* [1 John 03:9-10](https://git.door43.org/Door43/en_tn/src/master/1jn/03/09.md)
* [1 Peter 01:3-5](https://git.door43.org/Door43/en_tn/src/master/1pe/01/03.md)
* [1 Peter 01:22-23](https://git.door43.org/Door43/en_tn/src/master/1pe/01/22.md)
* [John 03:3-4](https://git.door43.org/Door43/en_tn/src/master/jhn/03/03.md)
* [John 03:7-8](https://git.door43.org/Door43/en_tn/src/master/jhn/03/07.md)
* [Titus 03:4-5](https://git.door43.org/Door43/en_tn/src/master/tit/03/04.md)

### Word Data:

* Strong's: G313, G509, G1080, G3824


## <a id="tw-term-kt-brother"/>brother, brothers

### Definition:

The term "brother" usually refers to a male person who shares at least one biological parent with another person.

* In the Old Testament, the term "brothers" is also used as a general reference to relatives, such as members of the same tribe, clan, or people group.
* In the New Testament, the apostles often used "brothers" to refer to fellow Christians, including both men and women, since all believers in Christ are members of one spiritual family, with God as their heavenly Father.
* A few times in the New Testament, the apostles used the term "sister" when referring specifically to a fellow Christian who was a woman, or to emphasize that both men and women are being included. For example, James emphasizes that he is talking about all believers when he refers to "a brother or sister who is in need of food or clothing."

### Translation Suggestions:

* It is best to translate this term with the literal word that is used in the target language to refer to a natural or biological brother, unless this would give wrong meaning.
* In the Old Testament especially, when "brothers" is used very generally to refer to members of the same family, clan, or people group, possible translations could include "relatives" or "clan members" or "fellow Israelites."
* In the context of referring to a fellow believer in Christ, this term could be translated as "brother in Christ" or "spiritual brother."
* If both males and females are being referred to and "brother" would give a wrong meaning, then a more general kinship term could be used that would include both males and females.
* Other ways to translate this term so that it refers to both male and female believers could be "fellow believers" or "Christian brothers and sisters."
* Make sure to check the context to determine whether only men are being referred to, or whether both men and women are included.

(See also: [apostle](#apostle), [God the Father](#godthefather), [sister](other.html#sister), [spirit](#spirit))

### Bible References:

* [Acts 07:26-28](https://git.door43.org/Door43/en_tn/src/master/act/07/26.md)
* [Genesis 29:9-10](https://git.door43.org/Door43/en_tn/src/master/gen/29/09.md)
* [Leviticus 19:17-18](https://git.door43.org/Door43/en_tn/src/master/lev/19/17.md)
* [Nehemiah 03:1-2](https://git.door43.org/Door43/en_tn/src/master/neh/03/01.md)
* [Philippians 04:21-23](https://git.door43.org/Door43/en_tn/src/master/php/04/21.md)
* [Revelation 01:9-11](https://git.door43.org/Door43/en_tn/src/master/rev/01/09.md)


### Word Data:

* Strong's: H251, H252, H264, H1730, H2992, H2993, H2994, H7453, G80, G81, G2385, G2455, G2500, G4613, G5360, G5569


## <a id="tw-term-kt-call"/>call, calls, calling, called

### Definition:

The terms "call" and "call out" literally means to say something loudly to someone who is not nearby. There are also several figurative meanings.

* To "call out" to someone means to shout or speak loudly to someone far away. It can also mean to ask someone for help, especially God.
* Often in the Bible, "call" has a meaning of "summon" or "command to come" or "request to come."
* God calls people to come to him and be his people. This is their "calling."
* The term "called" is used in the Bible to mean that God has appointed or chosen people to be his children, to be his servants and proclaimers of his message of salvation through Jesus.
* This term is also used in the context of calling someone a name. For example, "He is called John," means, "He is named John" or "His name is John."
* To be "called by the name of" means that someone is given the name of someone else. God says that he has called his people by his name.
* A different expression, "I have called you by name" means that God knows a person's name personally and has specifically chosen him.

### Translation Suggestions:

* The term "call" could be translated by a word that means "summon," which includes the idea of being intentional or purposeful in calling.
* The expression "call out to you" could be translated as "ask you for help" or "pray to you urgently."
* When the Bible says that God has "called" us to be his servants, this could be translated as, "specially chose us" or "appointed us" to be his servants.
* "You must call his name" can also be translated as, "you must name him."
* "His name is called" could also be translated as, "his name is" or "he is named."
* To "call out" could be translated as, "say loudly" or "shout" or "say with a loud voice." Make sure the translation of this does not sound like the person is angry.
* The expression "your calling" could be translated as "your purpose" or "God's purpose for you" or "God's special work for you."
* To "call on the name of the Lord" could be translated as "seek the Lord and depend on him" or "trust in the Lord and obey him."
* To "call for" something could be translated by "demand" or "ask for" or "command."
* The expression "you are called by my name" could be translated as, "I have given you my name, showing that you belong to me."
* When God says,  "I have called you by name," this could be translated as, "I know your name and have chosen you."

(See also: [pray](#pray))

### Bible References:

* [1 Kings 18:22-24](https://git.door43.org/Door43/en_tn/src/master/1ki/18/22.md)
* [1 Thessalonians 04:7-8](https://git.door43.org/Door43/en_tn/src/master/1th/04/07.md)
* [2 Timothy 01:8-11](https://git.door43.org/Door43/en_tn/src/master/2ti/01/08.md)
* [Ephesians 04:1-3](https://git.door43.org/Door43/en_tn/src/master/eph/04/01.md)
* [Galatians 01:15-17](https://git.door43.org/Door43/en_tn/src/master/gal/01/15.md)
* [Matthew 02:13-15](https://git.door43.org/Door43/en_tn/src/master/mat/02/13.md)
* [Philippians 03:12-14](https://git.door43.org/Door43/en_tn/src/master/php/03/12.md)

{{tag>publish ktlink }


### Word Data:

* Strong's: H559, H2199, H4744, H6817, H7121, H7123, G154, G363, G1458, G1528, G1941, G1951, G2028, G2046, G2564, G2821, G2822, G2840, G2919, G3004, G3106, G3333, G3343, G3603, G3686, G3687, G4316, G4341, G4377, G4779, G4867, G5455, G5537, G5581


## <a id="tw-term-kt-centurion"/>centurion, centurions

### Definition:

A centurion was a Roman army officer who had a group of 100 soldiers under his command.

* This could also be translated with a term that means, "leader of a hundred men" or "army leader" or "officer in charge of a hundred."
* One Roman centurion came to Jesus to request healing for his servant.
* The centurion in charge of Jesus' crucifixion was amazed when he witnessed how Jesus died.
* God sent a centurion to Peter so that Peter could explain to him the good news about Jesus.

(See also: [Rome](names.html#rome))

### Bible References:

* [Acts 10:1-2](https://git.door43.org/Door43/en_tn/src/master/act/10/01.md)
* [Acts 27:1-2](https://git.door43.org/Door43/en_tn/src/master/act/27/01.md)
* [Acts 27:42-44](https://git.door43.org/Door43/en_tn/src/master/act/27/42.md)
* [Luke 07:2-5](https://git.door43.org/Door43/en_tn/src/master/luk/07/02.md)
* [Luke 23:46-47](https://git.door43.org/Door43/en_tn/src/master/luk/23/46.md)
* [Mark 15:39-41](https://git.door43.org/Door43/en_tn/src/master/mrk/15/39.md)
* [Matthew 08:5-7](https://git.door43.org/Door43/en_tn/src/master/mat/08/05.md)
* [Matthew 27:54-56](https://git.door43.org/Door43/en_tn/src/master/mat/27/54.md)

### Word Data:

* Strong's: G1543, G2760


## <a id="tw-term-kt-children"/>children, child

### Definition:

In the Bible, the term "child" is often used to generally refer to someone who is young in age, including an infant. The term "children" is the plural form and it also has several figurative uses.

* In the Bible, disciples or followers are sometimes called "children."
* Often the term "children" is used to refer to a person's descendants.
* The phrase "children of" can refer to being characterized by something. Some examples of this would be:
   * children of the light 
   * children of obedience 
   * children of the devil 
* This term can also refer to people who are like spiritual children. For example, "children of God" refers to people who belong to God through faith in Jesus.

### Translation Suggestions:

* The term "children" could be translated as "descendants" when it is referring to a person's great-grandchildren or great-great-grandchildren, etc.
* Depending on the context, "children of" could be translated as, "people who have the characteristics of" or "people who behave like."
* If possible, the phrase, "children of God" should be translated literally since an important biblical theme is that God is our heavenly Father. A possible translation alternate would be, "people who belong to God" or "God's spiritual children."
* When Jesus calls his disciples "children," this could also be translated as, "dear friends" or "my beloved disciples."
* When Paul and John refer to believers in Jesus as "children," this could also be translated as "dear fellow believers."
* The phrase, "children of the promise" could be translated as, "people who have received what God promised them."

(See also: [descendant](other.html#descendant), [promise](#promise), [son](#son), [spirit](#spirit), [believe](#believe), [beloved](#beloved))

### Bible References:

* [1 John 02:27-29](https://git.door43.org/Door43/en_tn/src/master/1jn/02/27.md)
* [3 John 01:1-4](https://git.door43.org/Door43/en_tn/src/master/3jn/01/01.md)
* [Galatians 04:19-20](https://git.door43.org/Door43/en_tn/src/master/gal/04/19.md)
* [Genesis 45:9-11](https://git.door43.org/Door43/en_tn/src/master/gen/45/09.md)
* [Joshua 08:34-35](https://git.door43.org/Door43/en_tn/src/master/jos/08/34.md)
* [Nehemiah 05:4-5](https://git.door43.org/Door43/en_tn/src/master/neh/05/04.md)


### Word Data:

* Strong's: H1069, H1121, H1123, H1129, H1323, H1397, H1580, H2029, H2030, H2056, H2138, H2145, H2233, H2945, H3173, H3205, H3206, H3208, H3211, H3243, H3490, H4392, H5271, H5288, H5290, H5759, H5764, H5768, H5953, H6185, H7908, H7909, H7921, G730, G815, G1025, G1064, G1471, G3439, G3515, G3516, G3808, G3812, G3813, G3816, G5040, G5041, G5042, G5043, G5044, G5206, G5207, G5388


## <a id="tw-term-kt-christ"/>Christ, Messiah

### Facts:

The terms "Messiah" and "Christ" mean "Anointed One" and refer to Jesus, God's Son.

* Both "Messiah" and "Christ" are used in the New Testament to refer to God's Son, whom God the Father appointed to rule as king over his people, and to save them from sin and death.
* In the Old Testament, the prophets wrote prophecies about the Messiah hundreds of years before he came to earth.
* Often a word meaning "anointed (one)" is used in the Old Testament to refer to the Messiah who would come.
* Jesus fulfilled many of these prophecies and did many miraculous works that proves he is the Messiah; the rest of these prophecies will be fulfilled when he returns.
* The word "Christ" is often used as a title, as in "the Christ" and "Christ Jesus."
* "Christ" also came to be used as part of his name, as in "Jesus Christ."

### Translation Suggestions:

* This term could be translated using its meaning, "the Anointed One" or "God's Anointed Savior."
* Many languages use a transliterated word that looks or sounds like "Christ" or "Messiah." (See: [How to Translate Unknowns](https://git.door43.org/Door43/en_man/src/master/translate/translate-unknown/01.md))
* The transliterated word could be followed by the definition of the term as in, "Christ, the Anointed One."
* Be consistent in how this is translated throughout the Bible so that it is clear that the same term is being referred to.
* Make sure the translations of "Messiah" and "Christ" work well in contexts where both terms occur in the same verse (such as John 1:41).

(See also: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Son of God](#sonofgod), [David](names.html#david), [Jesus](#jesus), [anoint](#anoint))

### Bible References:

* [1 John 05:1-3](https://git.door43.org/Door43/en_tn/src/master/1jn/05/01.md)
* [Acts 02:34-36](https://git.door43.org/Door43/en_tn/src/master/act/02/34.md)
* [Acts 05:40-42](https://git.door43.org/Door43/en_tn/src/master/act/05/40.md)
* [John 01:40-42](https://git.door43.org/Door43/en_tn/src/master/jhn/01/40.md)
* [John 03:27-28](https://git.door43.org/Door43/en_tn/src/master/jhn/03/27.md)
* [John 04:25-26](https://git.door43.org/Door43/en_tn/src/master/jhn/04/25.md)
* [Luke 02:10-12](https://git.door43.org/Door43/en_tn/src/master/luk/02/10.md)
* [Matthew 01:15-17](https://git.door43.org/Door43/en_tn/src/master/mat/01/15.md)

### Examples from the Bible stories:

* __[17:07](https://git.door43.org/Door43/en_tn/src/master/obs/17/07.md)__ The __Messiah__  was God's Chosen One who would save the people of the world from sin.
* __[17:08](https://git.door43.org/Door43/en_tn/src/master/obs/17/08.md)__ As it happened, the Israelites would have to wait a long time before the __Messiah__  came, almost 1,000 years.
* __[21:01](https://git.door43.org/Door43/en_tn/src/master/obs/21/01.md)__ From the very beginning, God planned to send the __Messiah__.
* __[21:04](https://git.door43.org/Door43/en_tn/src/master/obs/21/04.md)__ God promised King David that the __Messiah__  would be one of David's own descendants.
* __[21:05](https://git.door43.org/Door43/en_tn/src/master/obs/21/05.md)__ The __Messiah__  would start the New Covenant.
* __[21:06](https://git.door43.org/Door43/en_tn/src/master/obs/21/06.md)__ God's prophets also said that the __Messiah__  would be a prophet, a priest, and a king.
* __[21:09](https://git.door43.org/Door43/en_tn/src/master/obs/21/09.md)__ The prophet Isaiah prophesied that the __Messiah__  would be born from a virgin.
* __[43:07](https://git.door43.org/Door43/en_tn/src/master/obs/43/07.md)__ "But God raised him to life again to fulfill the prophecy which says, 'You will not let your __Holy One__  rot in the grave.'"
* __[43:09](https://git.door43.org/Door43/en_tn/src/master/obs/43/09.md)__ "But know for certain that God has caused Jesus to become both Lord and __Messiah__!"
* __[43:11](https://git.door43.org/Door43/en_tn/src/master/obs/43/11.md)__ Peter answered them, "Every one of you should repent and be baptized in the name of Jesus __Christ__  so that God will forgive your sins."
* __[46:06](https://git.door43.org/Door43/en_tn/src/master/obs/46/06.md)__ Saul reasoned with the Jews, proving that Jesus was the __Messiah__.

### Word Data:

* Strong's: H4899, G3323, G5547


## <a id="tw-term-kt-christian"/>Christian

### Definition:

Some time after Jesus went back to heaven, people made up the name "Christian" which means, "follower of Christ."

* It was in the city of Antioch where Jesus' followers were first called "Christians."
* A Christian is a person who believes that Jesus is the Son of God, and who trusts Jesus to save him from his sins.
* In our modern times, often the term "Christian" is used for someone who identifies with the Christian religion, but who is not really following Jesus. This is not the meaning of "Christian" in the Bible.
* Because the term "Christian" in the Bible always refers to someone who truly believes in Jesus, a Christian is also called a "believer."

### Translation Suggestions:

* This term could be translated as "Christ-follower" or "follower of Christ" or perhaps something like, "Christ-person."
* Make sure that the translation of this term is translated differently than terms used for disciple or apostle.
* Be careful to translate this term with a word that can refer to everyone who believes in Jesus, not just certain groups.
* Also consider how this term is translated in a Bible translation in a local or national language. (See: [How to Translate Unknowns](https://git.door43.org/Door43/en_man/src/master/translate/translate-unknown/01.md))

(See also: [Antioch](names.html#antioch), [Christ](#christ), [church](#church), [disciple](#disciple), [believe](#believe), [Jesus](#jesus), [Son of God](#sonofgod))

### Bible References:

* [1 Corinthians 06:7-8](https://git.door43.org/Door43/en_tn/src/master/1co/06/07.md)
* [1 Peter 04:15-16](https://git.door43.org/Door43/en_tn/src/master/1pe/04/15.md)
* [Acts 11:25-26](https://git.door43.org/Door43/en_tn/src/master/act/11/25.md)
* [Acts 26:27-29](https://git.door43.org/Door43/en_tn/src/master/act/26/27.md)

### Examples from the Bible stories:

* __[46:09](https://git.door43.org/Door43/en_tn/src/master/obs/46/09.md)__ It was at Antioch that believers in Jesus were first called "__Christians__."
* __[47:14](https://git.door43.org/Door43/en_tn/src/master/obs/47/14.md)__ ] Paul and other __Christian__  leaders traveled to many cities, preaching and teaching people the good news about Jesus.
* __[49:15](https://git.door43.org/Door43/en_tn/src/master/obs/49/15.md)__ If you believe in Jesus and what he has done for you, you are a __Christian__!
* __[49:16](https://git.door43.org/Door43/en_tn/src/master/obs/49/16.md)__ If you are a __Christian__, God has forgiven your sins because of what Jesus did.
* __[49:17](https://git.door43.org/Door43/en_tn/src/master/obs/49/17.md)__ Even though you are a __Christian__, you will still be tempted to sin.
* __[50:03](https://git.door43.org/Door43/en_tn/src/master/obs/50/03.md)__ Before he returned to heaven, Jesus told __Christians__  to proclaim the good news to people who have never heard it.
* __[50:11](https://git.door43.org/Door43/en_tn/src/master/obs/50/11.md)__ When Jesus returns, every __Christian__  who has died will rise from the dead and meet him in the sky.

### Word Data:

* Strong's: G5546


## <a id="tw-term-kt-church"/>church, churches, Church

### Definition:

In the New Testament, the term "church" refers to a local group of believers in Jesus who regularly met together to pray and hear God's word preached. The term "the Church" often refers to all Christians.

* This term literally refers to a "called out" assembly or congregation of people who meet together for a special purpose.
* When this term is used to refer to all believers everywhere in the whole body of Christ, some Bible translations capitalize the first letter ("Church") to distinguish it from the local church.
* Often the believers in a particular city would meet together in someone's home. These local churches were given the name of the city such as the "church at Ephesus."
* In the Bible, "church" does not refer to a building.

### Translation Suggestions:

* The term "church" could be translated as a "gathering together" or "assembly" or "congregation" or "ones who meet together."
* The word or phrase that is used to translate this term should also be able to refer to all believers, not just one small group.
* Make sure that the translation of "church" does not just refer to a building.
* The term used to translate "assembly" in the Old Testament could also be used to translate this term.
* Also consider how it is translated in a local or national Bible translation. (See: [How to Translate Unknowns](https://git.door43.org/Door43/en_man/src/master/translate/translate-unknown/01.md).)

(See also: [assembly](other.html#assembly), [believe](#believe), [Christian](#christian))

### Bible References:

* [1 Corinthians 05:11-13](https://git.door43.org/Door43/en_tn/src/master/1co/05/11.md)
* [1 Thessalonians 02:14-16](https://git.door43.org/Door43/en_tn/src/master/1th/02/14.md)
* [1 Timothy 03:4-5](https://git.door43.org/Door43/en_tn/src/master/1ti/03/04.md)
* [Acts 09:31-32](https://git.door43.org/Door43/en_tn/src/master/act/09/31.md)
* [Acts 14:23-26](https://git.door43.org/Door43/en_tn/src/master/act/14/23.md)
* [Acts 15:39-41](https://git.door43.org/Door43/en_tn/src/master/act/15/39.md)
* [Colossians 04:15-17](https://git.door43.org/Door43/en_tn/src/master/col/04/15.md)
* [Ephesians 05:22-24](https://git.door43.org/Door43/en_tn/src/master/eph/05/22.md)
* [Matthew 16:17-18](https://git.door43.org/Door43/en_tn/src/master/mat/16/17.md)
* [Philippians 04:14-17](https://git.door43.org/Door43/en_tn/src/master/php/04/14.md)

### Examples from the Bible stories:

* __[43:12](https://git.door43.org/Door43/en_tn/src/master/obs/43/12.md)__ About 3,000 people believed what Peter said and became disciples of Jesus. They were baptized and became part of the __church__  at Jerusalem.
* __[46:09](https://git.door43.org/Door43/en_tn/src/master/obs/46/09.md)__ Most of the people in Antioch were not Jews, but for the first time, very many of them also became believers. Barnabas and Saul went there to teach these new believers more about Jesus and to strengthen the __church__.
* __[46:10](https://git.door43.org/Door43/en_tn/src/master/obs/46/10.md)__ So the __church__  in Antioch prayed for Barnabas and Saul and placed their hands on them. Then they sent them off to preach the good news of Jesus in many other places.
* __[47:13](https://git.door43.org/Door43/en_tn/src/master/obs/47/13.md)__ The good news of Jesus kept spreading, and the __Church__  kept growing.
* __[50:01](https://git.door43.org/Door43/en_tn/src/master/obs/50/01.md)__ For almost 2,000 years, more and more people around the world have been hearing the good news about Jesus the Messiah. The __Church__  has been growing.


### Word Data:

* Strong's: G1577


## <a id="tw-term-kt-circumcise"/>circumcise, circumcised, circumcision, uncircumcised, uncircumcision

### Definition:

The term "circumcise" means to cut off the foreskin of a man or male child. A circumcision ceremony may be performed in connection with this.

* God commanded Abraham to circumcise every male among his family and servants as a sign of God's covenant with them.
* God also commanded Abraham's descendants to continue to do this for every baby boy born into their households.
* The phrase, "circumcision of the heart" refers figuratively to the "cutting away" or removal of sin from a person.
* In a spiritual sense, "the circumcised" refers to people whom God has purified from sin through the blood of Jesus and who are his people.
* The term "uncircumcised" refers to those who have not been circumcised physically. It can also refer figuratively to those who have not been circumcised spiritually, who do not have a relationship with God.

The terms "uncircumcised" and "uncircumcision" refer to a male who has not been physically circumcised. These terms are also used figuratively.

* Egypt was a nation that also required circumcision. So when God talks about Egypt being defeated by the "uncircumcised," he is referring to people whom the Egyptians despised for not being circumcised.
* The Bible refers to people who have an "uncircumcised heart" or who are "uncircumcised in heart." This a figurative way of saying that these people are not God's people, and are stubbornly disobedient to him.

* If a word for circumcision is used or known in the language, "uncircumcised" could be translated as "not circumcised."
* The expression "the uncircumcision" could be translated as "people who are not circumcised" or "people who do not belong to God," depending on the context.
* Other ways to translate figurative senses of this term could include "not God's people" or "rebellious like those who don't belong to God" or "people who have no sign of belonging to God."
* The expression "uncircumcised in heart" could be translated as "stubbornly rebellious" or "refusing to believe." However, if possible it is best to keep the expression or a similar one since spiritual circumcision is an important concept.

### Translation Suggestions:

* If the culture of the target language performs circumcisions on males, the word used to refer to this should be used for this term.
* Other ways to translate this term would be, "cut around" or "cut in a circle" or "cut off the foreskin."
* In cultures where circumcision is not known, it may be necessary to explain it in a footnote or glossary.
* Make sure the term used to translate this does not refer to females. It may be necessary to translate this with a word or phrase that includes the meaning of "male."

(See also: [How to Translate Unknowns](https://git.door43.org/Door43/en_man/src/master/translate/translate-unknown/01.md))

(See also: [Abraham](names.html#abraham), [covenant](#covenant))

### Bible References:

* [Genesis 17:9-11](https://git.door43.org/Door43/en_tn/src/master/gen/17/09.md)
* [Genesis 17:12-14](https://git.door43.org/Door43/en_tn/src/master/gen/17/12.md)
* [Exodus 12:47-48](https://git.door43.org/Door43/en_tn/src/master/exo/12/47.md)
* [Leviticus 26:40-42](https://git.door43.org/Door43/en_tn/src/master/lev/26/40.md)
* [Joshua 05:2-3](https://git.door43.org/Door43/en_tn/src/master/jos/05/02.md)
* [Judges 15:17-18](https://git.door43.org/Door43/en_tn/src/master/jdg/15/17.md)
* [2 Samuel 01:17-20](https://git.door43.org/Door43/en_tn/src/master/2sa/01/17.md)
* [Jeremiah 09:25-26](https://git.door43.org/Door43/en_tn/src/master/jer/09/25.md)
* [Ezekiel 32:24-25](https://git.door43.org/Door43/en_tn/src/master/ezk/32/24.md)
* [Acts 10:44-45](https://git.door43.org/Door43/en_tn/src/master/act/10/44.md)
* [Acts 11:1-3](https://git.door43.org/Door43/en_tn/src/master/act/11/01.md)
* [Acts 15:1-2](https://git.door43.org/Door43/en_tn/src/master/act/15/01.md)
* [Acts 11:1-3](https://git.door43.org/Door43/en_tn/src/master/act/11/01.md)
* [Romans 02:25-27](https://git.door43.org/Door43/en_tn/src/master/rom/02/25.md)
* [Galatians 05:3-4](https://git.door43.org/Door43/en_tn/src/master/gal/05/03.md)
* [Ephesians 02:11-12](https://git.door43.org/Door43/en_tn/src/master/eph/02/11.md)
* [Philippians 03:1-3](https://git.door43.org/Door43/en_tn/src/master/php/03/01.md)
* [Colossians 02:10-12](https://git.door43.org/Door43/en_tn/src/master/col/02/10.md)
* [Colossians 02:13-15](https://git.door43.org/Door43/en_tn/src/master/col/02/13.md)

### Examples from the Bible stories:

* __[05:03](https://git.door43.org/Door43/en_tn/src/master/obs/05/03.md)__ "You must __circumcise__  every male in your family."
* __[05:05](https://git.door43.org/Door43/en_tn/src/master/obs/05/05.md)__ That day Abraham __circumcised__  all the males in his household.


### Word Data:

* Strong's: H4135, H4139, H5243, H6188, H6189, H6190, G203, G564, G1986, G4059, G4061


## <a id="tw-term-kt-clean"/>clean, cleans, cleaned, cleanse, cleansed, cleansing, wash, washing, washed, washes, unclean

### Definition:

The term "clean" literally means to not have any dirt or stain. In the Bible, it is often used figuratively to mean, "pure," "holy," or "free from sin."

* "Cleanse" is the process of making something "clean." It could also be translated as "wash" or "purify."
* In the Old Testament, God told the Israelites which animals he had specified as ritually "clean" and which ones were "unclean." Only the clean animals were permitted to be used for eating or for sacrifice. In this context, the term "clean" means that the animal was acceptable to God for use as a sacrifice.
* A person who had certain skin diseases would be unclean until the skin was healed enough to no longer be contagious. Instructions for cleansing the skin had to be obeyed in order for that person to be declared "clean" again.
* Sometimes "clean" is used figuratively to refer to moral purity.

In the Bible, the term "unclean" is used figuratively to refer to things that God declared to be unfit for his people to touch, eat, or sacrifice.
 
* God gave the Israelites instructions about which animals were "clean" and which ones were "unclean." The unclean animals were not permitted to be used for eating or for sacrifice.	 
* People with certain skin diseases were said to be "unclean" until they were healed.	 
* If the Israelites touched something "unclean," they themselves would be considered unclean for a certain period of time.	 
* Obeying God's commands about not touching or eating unclean things kept the Israelites set apart for God's service.	 
* This physical and ritual uncleanness was also symbolic of moral uncleanness.	 
* In another figurative sense, an "unclean spirit" refers to an evil spirit.

### Translation Suggestions:

* This term could be translated with the common word for "clean" or "pure" (in the sense of being not dirty).
* Other ways to translate this could include, "ritually clean" or "acceptable to God."
* "Cleanse" could be translated by "wash" or "purify."
* Make sure that the words used for "clean" and "cleanse" can also be understood in a figurative sense.

* The term "unclean" could also be translated as "not clean" or "unfit in God's eyes" or "physically unclean" or "defiled."
* When referring to a demon as an unclean spirit, "unclean" could be translated as "evil" or "defiled."
* The translation of this term should allow for spiritual uncleanness. It should be able to refer to anything that God declared as unfit for touching, eating, or sacrifice.

(See also: [defile](other.html#defile), [demon](#demon), [holy](#holy), [sacrifice](other.html#sacrifice))

### Bible References:

* [Genesis 07:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/07/01.md)
* [Genesis 07:8-10](https://git.door43.org/Door43/en_tn/src/master/gen/07/08.md)
* [Deuteronomy 12:15-16](https://git.door43.org/Door43/en_tn/src/master/deu/12/15.md)
* [Psalms 051:7-9](https://git.door43.org/Door43/en_tn/src/master/psa/051/007.md)
* [Proverbs 20:29-30](https://git.door43.org/Door43/en_tn/src/master/pro/20/29.md)
* [Ezekiel 24:13](https://git.door43.org/Door43/en_tn/src/master/ezk/24/13.md)
* [Matthew 23:27-28](https://git.door43.org/Door43/en_tn/src/master/mat/23/27.md)
* [Luke 05:12-13](https://git.door43.org/Door43/en_tn/src/master/luk/05/12.md)
* [Acts 08:6-8](https://git.door43.org/Door43/en_tn/src/master/act/08/06.md)
* [Acts 10:27-29](https://git.door43.org/Door43/en_tn/src/master/act/10/27.md)
* [Colossians 03:5-8](https://git.door43.org/Door43/en_tn/src/master/col/03/05.md)
* [1 Thessalonians 04:7-8](https://git.door43.org/Door43/en_tn/src/master/1th/04/07.md)
* [James 04:8-10](https://git.door43.org/Door43/en_tn/src/master/jas/04/08.md)

### Word Data:

* Strong's: H1249, H1252, H1305, H2134, H2135, H2141, H2398, H2548, H2834, H2889, H2890, H2891, H2893, H2930, H2931, H2932, H3001, H3722, H5079, H5352, H5355, H5356, H6172, H6565, H6663, H6945, H7137, H8552, H8562, G167, G169, G2511, G2512, G2513, G2839, G2840, G3394, G3689


## <a id="tw-term-kt-command"/>command, commands, commanded, commandment, commandments

### Definition:

The term to "command" means to order someone to do something. A "command" or "commandment" is what the person was ordered to do.

* Although these terms have basically the same meaning, "commandment" often refers to certain commands of God which are more formal and permanent, such as the "Ten Commandments."
* A command can be positive ("Honor your parents") or negative ("Do not steal").
* To "take command" means to "take control" or "take charge" of something or someone.

### Translation Suggestions

* It is best to translate this term differently from the term, "law." Also compare with the definitions of "decree" and "statute."
* Some translators may prefer to translate "command" and "commandment" with the same word in their language.
* Others may prefer to use a special word for commandment that refers to lasting, formal commands that God has made.

(See [decree](other.html#decree), [statute](other.html#statute), [law](other.html#law), [Ten Commandments](other.html#tencommandments))

### Bible References:

* [Luke 01:5-7](https://git.door43.org/Door43/en_tn/src/master/luk/01/05.md)
* [Matthew 01:24-25](https://git.door43.org/Door43/en_tn/src/master/mat/01/24.md)
* [Matthew 22:37-38](https://git.door43.org/Door43/en_tn/src/master/mat/22/37.md)
* [Matthew 28:20](https://git.door43.org/Door43/en_tn/src/master/mat/28/20.md)
* [Numbers 01:17-19](https://git.door43.org/Door43/en_tn/src/master/num/01/17.md)
* [Romans 07:7-8](https://git.door43.org/Door43/en_tn/src/master/rom/07/07.md)


### Word Data:

* Strong's: H559, H560, H565, H1696, H1697, H1881, H2706, H2708, H2710, H2941, H2942, H2951, H3027, H3982, H3983, H4406, H4662, H4687, H4929, H4931, H4941, H5057, H5713, H5749, H6213, H6310, H6346, H6490, H6673, H6680, H7101, H7218, H7227, H7262, H7761, H7970, H8269, G1263, G1291, G1296, G1297, G1299, G1690, G1778, G1781, G1785, G2003, G2004, G2008, G2036, G2753, G3056, G3726, G3852, G3853, G4367, G4483, G4487, G5506


## <a id="tw-term-kt-compassion"/>compassion, compassionate

### Definition:

The term "compassion" refers to a feeling of concern for people, especially for those who are suffering. A "compassionate" person cares about other people and helps them.

* The word "compassion" usually includes caring about people in need, as well as taking action to help them.  
* The Bible says that God is compassionate, that is, he is full of love and mercy.
* In Paul's letter to the Colossians, he tells them to "clothe themselves with compassion." He is instructing them to care about people and to actively help others who are in need.
  
### Translation Suggestions:

* The literal meaning of "compassion" is "bowels of mercy." This is an expression that means "mercy" or  "pity." Other languages may have their own expression that means this.
* Ways of translating "compassion" could include, "a deep caring for" or "helpful mercy."
* The term "compassionate" could also be translated as, "caring and helpful" or "deeply loving and merciful."

### Bible References:

* [Daniel 01:8-10](https://git.door43.org/Door43/en_tn/src/master/dan/01/08.md)
* [Hosea 13:14](https://git.door43.org/Door43/en_tn/src/master/hos/13/14.md)
* [James 05:9-11](https://git.door43.org/Door43/en_tn/src/master/jas/05/09.md)
* [Jonah 04:1-3](https://git.door43.org/Door43/en_tn/src/master/jon/04/01.md)
* [Mark 01:40-42](https://git.door43.org/Door43/en_tn/src/master/mrk/01/40.md)
* [Romans 09:14-16](https://git.door43.org/Door43/en_tn/src/master/rom/09/14.md)

### Word Data:

* Strong's: H2550, H7349, H7355, H7356, G1653, G3356, G3627, G4697, G4834, G4835


## <a id="tw-term-kt-condemn"/>condemn, condemns, condemned, condemnation

### Definition:

The terms "condemn" and "condemnation" refer to judging someone for doing something wrong.

* Often the word "condemn" includes punishing that person for what they did wrong.
* Sometimes "condemn" means to falsely accuse someone or to judge someone harshly.
* The term "condemnation" refers to the act of condemning or accusing someone.

### Translation Suggestions:

* Depending on the context, this term could be translated as "harshly judge" or "criticize falsely."
* The phrase "condemn him" could be translated as,"judge that he is guilty" or "state that he must be punished for his sin."
* The term "condemnation" could be translated as, "harsh judging" or "declaring to be guilty" or "punishment of guilt."

(See also: [judge](#judge), [punish](other.html#punish))

### Bible References:

* [1 John 03:19-22](https://git.door43.org/Door43/en_tn/src/master/1jn/03/19.md)
* [Job 09:27-29](https://git.door43.org/Door43/en_tn/src/master/job/09/27.md)
* [John 05:24](https://git.door43.org/Door43/en_tn/src/master/jhn/05/24.md)
* [Luke 06:37](https://git.door43.org/Door43/en_tn/src/master/luk/06/37.md)
* [Matthew 12:7-8](https://git.door43.org/Door43/en_tn/src/master/mat/12/07.md)
* [Proverbs 17:15-16](https://git.door43.org/Door43/en_tn/src/master/pro/17/15.md)
* [Psalms 034:21-22](https://git.door43.org/Door43/en_tn/src/master/psa/034/021.md)
* [Romans 05:16-17](https://git.door43.org/Door43/en_tn/src/master/rom/05/16.md)


### Word Data:

* Strong's: H6064, H7034, H7561, H8199, G176, G843, G2607, G2613, G2631, G2632, G2633, G2917, G2919, G2920, G5272, G6048


## <a id="tw-term-kt-confess"/>confess, confessed, confesses, confession

### Definition:

To confess means to admit or assert that something is true. A "confession" is a statement or admission that something is true. 

* The term "confess" can refer to boldly stating the truth about God. It can also refer to admitting that we have sinned.
* The Bible says that if people confess their sins to God, he will forgive them.
* James the apostle wrote in his letter that when believers confess their sins to each other, this brings spiritual healing.
* The apostle Paul wrote to the Philippians that someday everyone will confess or declare that Jesus is Lord.
* Paul also said that if people confess that Jesus is Lord and believe that God raised him from the dead, they will be saved.

### Translation Suggestions:

* Depending on the context, ways to translate "confess" could include, "admit" or "testify" or "declare" or "acknowledge" or "affirm."
* Different ways to translate "confession" could be, "declaration" or "testimony" or "statement about what we believe" or "admitting sin."

(See also: [faith](#faith), [testimony](#testimony))

### Bible References:

* [1 John 01:8-10](https://git.door43.org/Door43/en_tn/src/master/1jn/01/08.md)
* [2 John 01:7-8](https://git.door43.org/Door43/en_tn/src/master/2jn/01/07.md)
* [James 05:16-18](https://git.door43.org/Door43/en_tn/src/master/jas/05/16.md)
* [Leviticus 05:5-6](https://git.door43.org/Door43/en_tn/src/master/lev/05/05.md)
* [Matthew 03:4-6](https://git.door43.org/Door43/en_tn/src/master/mat/03/04.md)
* [Nehemiah 01:6-7](https://git.door43.org/Door43/en_tn/src/master/neh/01/06.md)
* [Philippians 02:9-11](https://git.door43.org/Door43/en_tn/src/master/php/02/09.md)
* [Psalms 038:17-18](https://git.door43.org/Door43/en_tn/src/master/psa/038/017.md)


### Word Data:

* Strong's: H3034, H8426, G1843, G3670, G3671


## <a id="tw-term-kt-conscience"/>conscience, consciences

### Definition:

The conscience is the part of a person's thinking through which God makes him aware that he is doing something sinful.

* God gave people a conscience to help them know the difference between what is right and what is wrong.
* A person who obeys God is said to have a "pure" or "clear" or "clean" conscience.
* If a person has a "clear conscience" it means that he is not hiding any sin.
* If someone ignores their conscience and no longer feels guilty when he sins, this means his conscience is no longer sensitive to what is wrong. The Bible calls this a "seared" conscience, one that is "branded" as if with a hot iron. Such a conscience is also called "insensitive" and "polluted."
* Possible ways to translate this term could include, "inner moral guide" or "moral thinking."

### Bible References:

* [1 Timothy 01:18-20](https://git.door43.org/Door43/en_tn/src/master/1ti/01/18.md)
* [1 Timothy 03:8-10](https://git.door43.org/Door43/en_tn/src/master/1ti/03/08.md)
* [2 Corinthians 05:11-12](https://git.door43.org/Door43/en_tn/src/master/2co/05/11.md)
* [2 Timothy 01:3-5](https://git.door43.org/Door43/en_tn/src/master/2ti/01/03.md)
* [Romans 09:1-2](https://git.door43.org/Door43/en_tn/src/master/rom/09/01.md)
* [Titus 01:15-16](https://git.door43.org/Door43/en_tn/src/master/tit/01/15.md)


### Word Data:

* Strong's: G4893


## <a id="tw-term-kt-consecrate"/>consecrate, consecrated, consecration

### Definition:

To consecrate means to dedicate something or someone to serve God. The person or object that is consecrated is considered holy and set apart for God.

* The meaning of this term is similar to "sanctify" or to "make holy," but with the added meaning of formally setting apart someone for service to God.
* Things that were consecrated to God included animals to be sacrificed, the altar of burnt offering, and the tabernacle.
* People who were consecrated to God included the priests, the people of Israel, and the oldest male child.
* Sometimes the word "consecrate" has a meaning that is similar to "purify," especially when it pertains to preparing people or things for God's service so that they will be cleansed and acceptable to him.

### Translation Suggestions:

* Ways to translate "consecrate" could include, "set apart for God's service" or "purify for service to God."
* Also consider how the terms "holy" and "sanctify" are translated.

(See also: [holy](#holy), [pure](#purify), [sanctify](#sanctify))

### Bible References:

* [1 Timothy 04:3-5](https://git.door43.org/Door43/en_tn/src/master/1ti/04/03.md)
* [2 Chronicles 13:8-9](https://git.door43.org/Door43/en_tn/src/master/2ch/13/08.md)
* [Ezekiel 44:19](https://git.door43.org/Door43/en_tn/src/master/ezk/44/19.md)


### Word Data:

* Strong's: H2763, H3027, H4390, H4394, H5144, H5145, H6942, H6944, G1457, G5048


## <a id="tw-term-kt-cornerstone"/>cornerstone, cornerstones

### Definition:

The term "cornerstone" refers to a large stone that has been specially cut and placed in the corner of the foundation of a building. 

* All the other stones of the building are measured and placed in relation to the cornerstone.
* It is very important for the strength and stability of the whole structure.
* In the New Testament, the Assembly of believers is metaphorically compared to a building which has Jesus Christ as its "cornerstone."
* In the same way that the cornerstone of a building supports and determines the position of the whole building, so Jesus Christ is the cornerstone on which the Assembly of believers is founded and supported.

### Translation Suggestions:

* The term "cornerstone" could also be translated as "main building stone" or "foundation stone."
* Consider whether the target language has a term for a part of a building's foundation that is the main support. If so, this term could be used.
* Another way to translate this would be, "a foundation stone used for the corner of a building."
* It is important to keep the fact that this is a large stone, used as a solid and secure building material. If stones are not used for constructing buildings, there may be another word that could be used that means "large stone" (such as "boulder")  but it should also have the idea of being well-formed and made to fit.

### Bible References:

* [Acts 04:11-12](https://git.door43.org/Door43/en_tn/src/master/act/04/11.md)
* [Ephesians 02:19-22](https://git.door43.org/Door43/en_tn/src/master/eph/02/19.md)
* [Matthew 21:42](https://git.door43.org/Door43/en_tn/src/master/mat/21/42.md)
* [Psalms 118:22-23](https://git.door43.org/Door43/en_tn/src/master/psa/118/022.md)


### Word Data:

* Strong's: H68, H6438, H7218, G204, G1137, G2776, G3037


## <a id="tw-term-kt-covenant"/>covenant, covenants, new covenant

### Definition:

A covenant is a formal, binding agreement between two parties that one or both parties must fulfill.

* This agreement can be between individuals, between groups of people, or between God and people.
* When people make a covenant with each other, they promise that they will do something, and they must do it.
* Examples of human covenants include marriage covenants, business agreements, and treaties between countries.
* Throughout the Bible, God made several different covenants with his people.
* In some of the covenants, God promised to fulfill his part without conditions. For example, when God established his covenant with mankind promising to never destroy the earth again with a worldwide flood, this promise had no conditions for people to fulfill.
* In other covenants, God promised to fulfill his part only if the people obeyed him and fulfilled their part of the covenant.

The term "new covenant" refers to the commitment or agreement God made with his people through the sacrifice of his Son, Jesus. 

* God's "new covenant" was explained in the part of the Bible called the "New Testament."
* This new covenant is in contrast to the "old" or "former" covenant that God had made with the Israelites in Old Testament times.
* The new covenant is better than the old one because it is based on the sacrifice of Jesus, which completely atoned for people's sins forever. The sacrifices made under the old covenant did not do this.
* God writes the new covenant on the hearts those who become believers in Jesus. This causes them to want to obey God and to begin to live holy lives.
* The new covenant will be completely fulfilled in the end times when God establishes his reign on earth. Everything will once again be very good, as it was when God first created the world.

### Translation Suggestions:

* Depending on the context, ways to translate this term could include, "binding agreement" or "formal commitment" or "pledge" or "contract."
* Some languages may have different words for covenant depending on whether one party or both parties have made a promise they must keep. If the covenant is one-sided, it could be translated as "promise" or "pledge."
* Make sure the translation of this term does not sound like people proposed the covenant. In all cases of covenants between God and people, it was God who initiated the covenant.

* The term "new covenant" could be translated as "new formal agreement" or "new pact" or "new contract."
* The word "new" in these expressions has the meaning of "fresh" or "new kind of" or "another."

(See also: [covenant](#covenant), [promise](#promise))

### Bible References:

* [Genesis 09:11-13](https://git.door43.org/Door43/en_tn/src/master/gen/09/11.md)
* [Genesis 17:7-8](https://git.door43.org/Door43/en_tn/src/master/gen/17/07.md)
* [Genesis 31:43-44](https://git.door43.org/Door43/en_tn/src/master/gen/31/43.md)
* [Exodus 34:10-11](https://git.door43.org/Door43/en_tn/src/master/exo/34/10.md)
* [Joshua 24:24-26](https://git.door43.org/Door43/en_tn/src/master/jos/24/24.md)
* [2 Samuel 23:5](https://git.door43.org/Door43/en_tn/src/master/2sa/23/05.md)
* [2 Kings 18:11-12](https://git.door43.org/Door43/en_tn/src/master/2ki/18/11.md)
* [Mark 14:22-25](https://git.door43.org/Door43/en_tn/src/master/mrk/14/22.md)
* [Luke 01:72-75](https://git.door43.org/Door43/en_tn/src/master/luk/01/72.md)
* [Luke 22:19-20](https://git.door43.org/Door43/en_tn/src/master/luk/22/19.md)
* [Acts 07:6-8](https://git.door43.org/Door43/en_tn/src/master/act/07/06.md)
* [1 Corinthians 11:25-26](https://git.door43.org/Door43/en_tn/src/master/1co/11/25.md)
* [2 Corinthians 03:4-6](https://git.door43.org/Door43/en_tn/src/master/2co/03/04.md)
* [Galatians 03:17-18](https://git.door43.org/Door43/en_tn/src/master/gal/03/17.md)
* [Hebrews 12:22-24](https://git.door43.org/Door43/en_tn/src/master/heb/12/22.md)

### Examples from the Bible stories:

* __[04:09](https://git.door43.org/Door43/en_tn/src/master/obs/04/09.md)__ Then God made a __covenant__  with Abram. A __covenant__  is an agreement between two parties.
* __[05:04](https://git.door43.org/Door43/en_tn/src/master/obs/05/04.md)__ "I will make Ishmael a great nation, too, but my __covenant__  will be with Isaac."
* __[06:04](https://git.door43.org/Door43/en_tn/src/master/obs/06/04.md)__ After a long time, Abraham died and all of the promises that God had made to him in the __covenant__  were passed on to Isaac.
* __[07:10](https://git.door43.org/Door43/en_tn/src/master/obs/07/10.md)__ The __covenant__  promises God had promised to Abraham and then to Isaac now passed on to Jacob."
* __[13:02](https://git.door43.org/Door43/en_tn/src/master/obs/13/02.md)__ God said to Moses and the people of Israel, "If you will obey my voice and keep my __covenant__, you will be my prized possession, a kingdom of priests, and a holy nation."
* __[13:04](https://git.door43.org/Door43/en_tn/src/master/obs/13/04.md)__ Then God gave them the __covenant__  and said, "I am Yahweh, your God, who saved you from slavery in Egypt. Do not worship other gods."
* __[15:13](https://git.door43.org/Door43/en_tn/src/master/obs/15/13.md)__ Then Joshua reminded the people of their obligation to obey the __covenant__  that God had made with the Israelites at Sinai.
* __[21:05](https://git.door43.org/Door43/en_tn/src/master/obs/21/05.md)__ Through the prophet Jeremiah, God promised that he would make a __New Covenant__, but not like the covenant God made with Israel at Sinai. In the __New Covenant__, God would write his law on the people's hearts, the people would know God personally, they would be his people, and God would forgive their sins. The Messiah would start the __New Covenant__.
* __[21:14](https://git.door43.org/Door43/en_tn/src/master/obs/21/14.md)__ Through the Messiah's death and resurrection, God would accomplish his plan to save sinners and start the __New Covenant__.
* __[38:05](https://git.door43.org/Door43/en_tn/src/master/obs/38/05.md)__ Then Jesus took a cup and said, "Drink this. It is my blood of the __New Covenant__  that is poured out for the forgiveness of sins. Do this to remember me every time you drink it."
* __[48:11](https://git.door43.org/Door43/en_tn/src/master/obs/48/11.md)__ But God has now made a __New Covenant__  that is available to everyone. Because of this __New Covenant__, anyone from any people group can become part of God's people by believing in Jesus.

### Word Data:

* Strong's: H1285, H2319, H3772, G802, G1242, G4934


## <a id="tw-term-kt-covenantfaith"/>covenant faithfulness, covenant loyalty, loving kindness, unfailing love

### Definition:

This term is used to describe God's commitment to fulfill the promises that he made to his people.

* God made promises to the Israelites in formal agreements called "covenants."
* The "covenant faithfulness" or "covenant loyalty" of Yahweh refers to the fact that he keeps his promises to his people. 
* God's faithfulness to keep his covenant promises is an expression of his grace toward his people. 
* The term "loyalty" is another word that refers to being committed and dependable, to do and say what has been promised, and what will benefit someone else.

### Translation Suggestions:

* The way this term is translated will also depend on how the terms "covenant" and "faithfulness" are translated.
* Other ways to translate this term could include, "faithful love" or "loyal, committed love" or "loving dependability."

(See also: [covenant](#covenant), [faithful](#faithful), [grace](#grace), [Israel](#israel), [people of God](#peopleofgod), [promise](#promise))

### Bible References:

* [Ezra 03:10-11](https://git.door43.org/Door43/en_tn/src/master/ezr/03/10.md)
* [Numbers 14:17-19](https://git.door43.org/Door43/en_tn/src/master/num/14/17.md)

### Word Data:

* Strong's: H2617


## <a id="tw-term-kt-cross"/>cross

### Definition:

In Bible times, a cross was an upright wooden post stuck into the ground, with a horizontal wooden beam attached to it near the top.

* During the time of the Roman Empire, the Roman government would execute criminals by tying or nailing them to a cross and leaving them there to die.
* Jesus was falsely accused of crimes he did not commit and the Romans put him to death on a cross.
* Note that this is a completely different word from the verb "cross" that means to go over to the other side of something, such as a river or lake.

### Translation Suggestions:

* This term could be translated using a term in the target language that refers to the shape of a cross.
* Consider describing the cross as something on which people were killed, using phrases such as "execution post" or "tree of death."
* Also consider how this word is translated in a Bible translation in a local or national language. (See: [How to Translate Unknowns](https://git.door43.org/Door43/en_man/src/master/translate/translate-unknown/01.md))

(See also: [crucify](#crucify), [Rome](names.html#rome))

### Bible References:

* [1 Corinthians 01:17](https://git.door43.org/Door43/en_tn/src/master/1co/01/17.md)
* [Colossians 02:13-15](https://git.door43.org/Door43/en_tn/src/master/col/02/13.md)
* [Galatians 06:11-13](https://git.door43.org/Door43/en_tn/src/master/gal/06/11.md)
* [John 19:17-18](https://git.door43.org/Door43/en_tn/src/master/jhn/19/17.md)
* [Luke 09:23-25](https://git.door43.org/Door43/en_tn/src/master/luk/09/23.md)
* [Luke 23:26](https://git.door43.org/Door43/en_tn/src/master/luk/23/26.md)
* [Matthew 10:37-39](https://git.door43.org/Door43/en_tn/src/master/mat/10/37.md)
* [Philippians 02:5-8](https://git.door43.org/Door43/en_tn/src/master/php/02/05.md)

### Examples from the Bible stories:

* __[40:01](https://git.door43.org/Door43/en_tn/src/master/obs/40/01.md)__ After the soldiers mocked Jesus, they led him away to crucify him. They made him carry the __cross__  on which he would die.
* __[40:02](https://git.door43.org/Door43/en_tn/src/master/obs/40/02.md)__ The soldiers brought Jesus to a place called "the Skull" and nailed his arms and feet to the __cross__.
* __[40:05](https://git.door43.org/Door43/en_tn/src/master/obs/40/05.md)__ The Jewish leaders and the other people in the crowd mocked Jesus. They said to him, "If you are the Son of God, come down from the __cross__  and save yourself! Then we will believe you."
* __[49:10](https://git.door43.org/Door43/en_tn/src/master/obs/49/10.md)__ When Jesus died on the __cross__, he received your punishment.
* __[49:12](https://git.door43.org/Door43/en_tn/src/master/obs/49/12.md)__ You must believe that Jesus is the Son of God, that he died on the __cross__  instead of you, and that God raised him to life again.

### Word Data:

* Strong's: G4716


## <a id="tw-term-kt-crucify"/>crucify, crucified

### Definition:

The term "crucify" means to execute someone by attaching him to a cross and leaving him there to suffer and die in great pain.
 
* The victim was either tied to the cross or nailed to it. Crucified people died from blood loss or from suffocation.
* The ancient Roman Empire frequently used this method of execution to punish and kill people who were terrible criminals or who had rebelled against the authority of their government.
* The Jewish religious leaders asked the Roman governor to order his soldiers to crucify Jesus. The soldiers nailed Jesus to a cross. He suffered there for six hours, and then died.

### Translation Suggestions:

* The term "crucify" could be translated as, "kill on a cross" or "execute by nailing to a cross."

(See also: [cross](#cross), [Rome](names.html#rome))

### Bible References:

* [Acts 02:22-24](https://git.door43.org/Door43/en_tn/src/master/act/02/22.md)
* [Galatians 02:20-21](https://git.door43.org/Door43/en_tn/src/master/gal/02/20.md)
* [Luke 23:20-22](https://git.door43.org/Door43/en_tn/src/master/luk/23/20.md)
* [Luke 23:33-34](https://git.door43.org/Door43/en_tn/src/master/luk/23/33.md)
* [Matthew 20:17-19](https://git.door43.org/Door43/en_tn/src/master/mat/20/17.md)
* [Matthew 27:23-24](https://git.door43.org/Door43/en_tn/src/master/mat/27/23.md)

### Examples from the Bible stories:

  __*[39:11](https://git.door43.org/Door43/en_tn/src/master/obs/39/11.md)__ But the Jewish leaders and the crowd shouted, "__Crucify__ him (Jesus)!"
  __*[39:12](https://git.door43.org/Door43/en_tn/src/master/obs/39/12.md)__ Pilate became afraid that the crowd would begin to riot, so he ordered his soldiers to __crucify__ Jesus.played a major role in the crucifixion of Jesus Christ.
  __*[40:01](https://git.door43.org/Door43/en_tn/src/master/obs/40/01.md)__  After the soldiers mocked Jesus, they led him away to __crucify__ him. They made him carry the cross on which he would die.
  __*[40:04](https://git.door43.org/Door43/en_tn/src/master/obs/40/04.md)__ Jesus was __crucified__ between two robbers.
  __*[43:06](https://git.door43.org/Door43/en_tn/src/master/obs/43/06.md)__ "Men of Israel, Jesus was a man who did many mighty signs and wonders by the power of God, as you have seen and already know. But you __crucified__ him!" 
  __*[43:09](https://git.door43.org/Door43/en_tn/src/master/obs/43/09.md)__ "You __crucified__ this man, Jesus."
  __*[44:08](https://git.door43.org/Door43/en_tn/src/master/obs/44/08.md)__ Peter answered them, "This man stands before you healed by the power of Jesus the Messiah. You __crucified__ Jesus, but God raised him to life again!"


### Word Data:

* Strong's: G388, G4362, G4717, G4957


## <a id="tw-term-kt-curse"/>curse, cursed, curses, cursing

### Definition:

The term "curse" means to cause negative things to happen to the person or thing that is being cursed.

* A curse can be a statement that harm will happen to someone or something.
* To curse someone can also be an expression of desire that bad things will happen to them.
* It can also refer to the punishment or other negative things that someone causes to happen to someone.

### Translation Suggestions:

* This term could be translated as "cause bad things to happen to" or "declare that something bad will happen to" or "swear to cause evil things to happen to."
* In the context of God sending curses on his disobedient people, it could be translated as, "punish by allowing bad things to happen."
* The term "cursed" when used to describe people could be translated as, "(this person) will experience much trouble."
* The phrase "cursed be" could be translated as, "May (this person) experience great difficulties."
* The phrase, "Cursed is the ground" could be translated as, "The soil will not be very fertile."
* "Cursed be the day I was born" could also be translated as, "I am so miserable it would have been better not to be born."
* However, if the target language has the phrase "cursed be" and it has the same meaning, then it is good to keep the same phrase.

(See also: [bless](#bless))

### Bible References:

* [1 Samuel 14:24-26](https://git.door43.org/Door43/en_tn/src/master/1sa/14/24.md)
* [2 Peter 02:12-14](https://git.door43.org/Door43/en_tn/src/master/2pe/02/12.md)
* [Galatians 03:10-12](https://git.door43.org/Door43/en_tn/src/master/gal/03/10.md)
* [Galatians 03:13-14](https://git.door43.org/Door43/en_tn/src/master/gal/03/13.md)
* [Genesis 03:14-15](https://git.door43.org/Door43/en_tn/src/master/gen/03/14.md)
* [Genesis 03:17-19](https://git.door43.org/Door43/en_tn/src/master/gen/03/17.md)
* [James 03:9-10](https://git.door43.org/Door43/en_tn/src/master/jas/03/09.md)
* [Numbers 22:5-6](https://git.door43.org/Door43/en_tn/src/master/num/22/05.md)
* [Psalms 109:28-29](https://git.door43.org/Door43/en_tn/src/master/psa/109/028.md)

### Examples from the Bible stories:

* __[02:09](https://git.door43.org/Door43/en_tn/src/master/obs/02/09.md)__ God said to the snake, "You are __cursed__!"
* __[02:11](https://git.door43.org/Door43/en_tn/src/master/obs/02/11.md)__ "Now the ground is __cursed__, and you will need to work hard to grow food."
* __[04:04](https://git.door43.org/Door43/en_tn/src/master/obs/04/04.md)__ "I will bless those who bless you and __curse__  those who __curse__  you."
* __[39:07](https://git.door43.org/Door43/en_tn/src/master/obs/39/07.md)__ Then Peter vowed, saying, "May God __curse__  me if I know this man!"
* __[50:16](https://git.door43.org/Door43/en_tn/src/master/obs/50/16.md)__ Because Adam and Eve disobeyed God and brought sin into this world, God __cursed__  it and decided to destroy it.


### Word Data:

* Strong's: H422, H423, H779, H1288, H2763, H2764, H3994, H5344, H6895, H7043, H7045, H7621, H8381, G331, G332, G685, G1944, G2551, G2652, G2653, G2671, G2672, G6035


## <a id="tw-term-kt-daughterofzion"/>daughter of Zion

### Definition:

"Daughter of Zion" is a figurative way of referring to the people of Israel. It is usually used in prophecies.

* In the Old Testament, "Zion" is often used as another name for the city of Jerusalem.
* Both "Zion" and "Jerusalem" are also used to refer to Israel.
* The term "Daughter" is a term of endearment or affection. It is a metaphor for the patience and care that God has for his people. 

### Translation Suggestions:

* Ways to translate this could include "my daughter Israel, from Zion" or "people from Zion, who are like a daughter to me" or "Zion, my dear people Israel."
* It is best to keep the term "Zion" in this expression since it is used many times in the Bible. A note could be included in the translation to explain its figurative meaning and prophetic use.
* It is also better to keep the term "Daughter" in the translation of this expression, as long as it is understood correctly.

(See also: [Jerusalem](names.html#jerusalem), [prophet](#prophet), [Zion](#zion))

### Bible References:

* [Jeremiah 06:1-3](https://git.door43.org/Door43/en_tn/src/master/jer/06/01.md)
* [John 12:14-15](https://git.door43.org/Door43/en_tn/src/master/jhn/12/14.md)
* [Matthew 21:4-5](https://git.door43.org/Door43/en_tn/src/master/mat/21/04.md)


### Word Data:

* Strong's: H1323, H6726


## <a id="tw-term-kt-dayofthelord"/>day of the Lord, day of Yahweh

### Description:

The Old Testament term "day of Yahweh" is used to refer to a specific time(s) when God would punish people for their sin. 

* The New Testament term "day of the Lord" usually refers to the day or time when the Lord Jesus will come back to judge people at the end of time.
* This final, future time of judgment and resurrection is also sometimes referred to as the "last day." This time will begin when the Lord Jesus comes back to judge sinners and will permanently establish his rule.
* The word "day" in these phrases may sometimes refer to a literal day or it may refer to a "time" or "occasion" that is longer than a day.
* Sometimes the punishment is referred to as a "pouring out of God's wrath" upon those who do not believe.

 
### Translation Suggestions:

* Depending on the context, other ways to translate "day of Yahweh" could include "time of Yahweh" or "time when Yahweh will punish his enemies" or "time of Yahweh's wrath."
* Other ways to translate "day of the Lord" could include "time of the Lord's judgment" or "time when the Lord Jesus will return to judge people."

(See also: [day](other.html#biblicaltimeday), [judgment day](#judgmentday), [Lord](#lord), [resurrection](#resurrection), [Yahweh](#yahweh))

### Bible References:

* [1 Corinthians 05:3-5](https://git.door43.org/Door43/en_tn/src/master/1co/05/03.md)
* [1 Thessalonians 05:1-3](https://git.door43.org/Door43/en_tn/src/master/1th/05/01.md)
* [2 Peter 03:10](https://git.door43.org/Door43/en_tn/src/master/2pe/03/10.md)
* [2 Thessalonians 02:1-2](https://git.door43.org/Door43/en_tn/src/master/2th/02/01.md)
* [Acts 02:20-21](https://git.door43.org/Door43/en_tn/src/master/act/02/20.md)
* [Philippians 01:9-11](https://git.door43.org/Door43/en_tn/src/master/php/01/09.md)

### Word Data:

* Strong's: H3068, H3117, G2250, G2962


## <a id="tw-term-kt-deacon"/>deacon, deacons

### Definition:

A deacon is a person who serves in the local church, helping fellow believers with practical needs, such as food or money.

* The word "deacon" is taken directly from a Greek word meaning "servant" or "minister."
* From the time of the early Christians, being a deacon has been a well-defined role and ministry in the Church body.
* For example, in the New Testament, deacons would make sure that whatever money or food that the believers shared would be distributed fairly to the widows among them.
* The term "deacon" could also be translated as "church minister" or "church worker" or "church servant," or some other phrase that shows that the person has been formally appointed to do specific tasks that benefit the local Christian community.

(See also: [minister](#minister), [servant](other.html#servant))

### Bible References:

* [1 Timothy 03:8-10](https://git.door43.org/Door43/en_tn/src/master/1ti/03/08.md)
* [1 Timothy 03:11-13](https://git.door43.org/Door43/en_tn/src/master/1ti/03/11.md)
* [Philippians 01:1-2](https://git.door43.org/Door43/en_tn/src/master/php/01/01.md)


### Word Data:

* Strong's: G1249


## <a id="tw-term-kt-demon"/>demon, evil spirit, unclean spirit

### Definition:

All these terms refer to demons, which are spirit beings that oppose God's will.

* God created angels to serve him. When the devil rebelled against God, some of the angels also rebelled and were thrown out of heaven. It is believed that demons and evil spirits are these "fallen angels."
* Sometimes these demons are called "unclean spirits." The term "unclean" means "impure" or "evil" or "unholy."
* Because demons serve the devil, they do evil things. Sometimes they live inside people and control them.
* Demons are more powerful than human beings, but not as powerful as God.

### Translation Suggestions:

* The term "demon" could also be translated as "evil spirit."
* The term "unclean spirit" could also be translated as "impure spirit" or "corrupt spirit" or "evil spirit."
* Make sure that the word or phrase used to translate this term is different from the term used to refer to the devil.
* Also consider how the term "demon" is translated in a local or national language. (See: [How to Translate Unknowns](https://git.door43.org/Door43/en_man/src/master/translate/translate-unknown/01.md))

(See also: [demon-possessed](#demonpossessed), [Satan](#satan), [false god](#falsegod), [false god](#falsegod), [angel](#angel), [evil](#evil), [clean](#clean))

### Bible References:

* [James 02:18-20](https://git.door43.org/Door43/en_tn/src/master/jas/02/18.md)
* [James 03:15-18](https://git.door43.org/Door43/en_tn/src/master/jas/03/15.md)
* [Luke 04:35-37](https://git.door43.org/Door43/en_tn/src/master/luk/04/35.md)
* [Mark 03:20-22](https://git.door43.org/Door43/en_tn/src/master/mrk/03/20.md)
* [Matthew 04:23-25](https://git.door43.org/Door43/en_tn/src/master/mat/04/23.md)

### Examples from the Bible stories:

* __[26:09](https://git.door43.org/Door43/en_tn/src/master/obs/26/09.md)__ Many people who had __demons__  in them were brought to Jesus. When Jesus commanded them, the __demons__  came out of the people, and often shouted, "You are the Son of God!"
* __[32:08](https://git.door43.org/Door43/en_tn/src/master/obs/32/08.md)__ The __demons__  came out of the man and entered the pigs.
* __[47:05](https://git.door43.org/Door43/en_tn/src/master/obs/47/05.md)__ Finally one day when the slave girl started yelling, Paul turned to her and said to the __demon__  that was in her, "In the name of Jesus, come out of her." Right away the __demon__  left her.
* __[49:02](https://git.door43.org/Door43/en_tn/src/master/obs/49/02.md)__ He (Jesus) walked on water, calmed storms, healed many sick people, drove out __demons__, raised the dead to life, and turned five loaves of bread and two small fish into enough food for over 5,000 people.

### Word Data:

* Strong's: H2932, H7307, H7451, H7700, G169, G1139, G1140, G1141, G1142, G4190, G4151, G4152, G4189


## <a id="tw-term-kt-demonpossessed"/>demon-possessed

### Definition:

A person who is demon-possessed has a demon or evil spirit that controls what he does and thinks.

 * Often a demon-possessed person will hurt himself or other people because the demon causes him to do that.
 * Jesus healed demon-possessed people by commanding the demons to come out of them. This is often called "casting out" demons.

### Translation Suggestions:

 * Other ways to translate this term could include "demon-controlled" or "controlled by an evil spirit" or "having an evil spirit living inside."

(See also: [demon](#demon))

### Bible References:

* [Mark 01:32-34](https://git.door43.org/Door43/en_tn/src/master/mrk/01/32.md)
* [Matthew 04:23-25](https://git.door43.org/Door43/en_tn/src/master/mat/04/23.md)
* [Matthew 08:16-17](https://git.door43.org/Door43/en_tn/src/master/mat/08/16.md)
* [Matthew 08:33-34](https://git.door43.org/Door43/en_tn/src/master/mat/08/33.md)

### Examples from the Bible stories:

 * __[26:09](https://git.door43.org/Door43/en_tn/src/master/obs/26/09.md)__ Many people who had __demons in them__  were brought to Jesus.
 * __[32:02](https://git.door43.org/Door43/en_tn/src/master/obs/32/02.md)__ When they reached the other side of the lake, a __demon-possessed__  man came running up to Jesus.
 * __[32:06](https://git.door43.org/Door43/en_tn/src/master/obs/32/06.md)__ The man __with the demon__  cried out in a loud voice, "What do you want with me, Jesus, Son of the Most High God? Please do not torture me!"
 * __[32:09](https://git.door43.org/Door43/en_tn/src/master/obs/32/09.md)__ The people from the town came and saw the man who used to __have the demons__.
 * __[47:03](https://git.door43.org/Door43/en_tn/src/master/obs/47/03.md)__ Every day as they (Paul and Silas) walked there, a slave girl __possessed by a demon__ followed them.

### Word Data:

* Strong's: G1139


## <a id="tw-term-kt-disciple"/>disciple, disciples

### Definition:

The term "disciple" refers to a person who spends much time with a teacher, learning from that teacher's character and teaching.

* The people who followed Jesus around, listening to his teachings and obeying them, were called his "disciples."
* John the Baptist also had disciples.
* During Jesus' ministry, there were many disciples who followed him and heard his teachings.
* Jesus chose twelve disciples to be his closest followers; these men became known as his "apostles."
* Jesus' twelve apostles continued to be known as his "disciples" or "the twelve."
* Just before Jesus went up to heaven, he commanded his disciples to teach other people about how to become Jesus' disciples, too.
* Anyone who believes in Jesus and obeys his teachings is called a disciple of Jesus.

### Translation Suggestions:

* The term "disciple" could be translated by a word or phrase that means "follower" or "student" or "pupil" or "learner."
* Make sure that the translation of this term does not refer only to a student who learns in a classroom.
* The translation of this term should also be different from the translation of "apostle."

(See also: [apostle](#apostle), [believe](#believe), [Jesus](#jesus), [John (the Baptist)](names.html#johnthebaptist), [the twelve](#thetwelve))

### Bible References:

* [Acts 06:1](https://git.door43.org/Door43/en_tn/src/master/act/06/01.md)
* [Acts 09:26-27](https://git.door43.org/Door43/en_tn/src/master/act/09/26.md)
* [Acts 11:25-26](https://git.door43.org/Door43/en_tn/src/master/act/11/25.md)
* [Acts 14:21-22](https://git.door43.org/Door43/en_tn/src/master/act/14/21.md)
* [John 13:23-25](https://git.door43.org/Door43/en_tn/src/master/jhn/13/23.md)
* [Luke 06:39-40](https://git.door43.org/Door43/en_tn/src/master/luk/06/39.md)
* [Matthew 11:1-3](https://git.door43.org/Door43/en_tn/src/master/mat/11/01.md)
* [Matthew 26:33-35](https://git.door43.org/Door43/en_tn/src/master/mat/26/33.md)
* [Matthew 27:62-64](https://git.door43.org/Door43/en_tn/src/master/mat/27/62.md)

### Examples from the Bible stories:

  __*[30:08](https://git.door43.org/Door43/en_tn/src/master/obs/30/08.md)__ He (Jesus) gave the pieces to his __disciples__ to give to the people. The __disciples__ kept passing out the food, and it never ran out!
  __*[38:01](https://git.door43.org/Door43/en_tn/src/master/obs/38/01.md)__ About three years after Jesus first began preaching and teaching publicly, Jesus told his __disciples__ that he wanted to celebrate this Passover with them in Jerusalem, and that he would be killed there.
  __*[38:11](https://git.door43.org/Door43/en_tn/src/master/obs/38/11.md)__ Then Jesus went with his __disciples__ to a place called Gethsemane. Jesus told his __disciples__ to pray that they would not enter into temptation.
  __*[42:10](https://git.door43.org/Door43/en_tn/src/master/obs/42/10.md)__ Jesus said to his __disciples__, "All authority in heaven and on earth has been given to me. So go, make __disciples__ of all people groups by baptizing them in the name of the Father, the Son, and the Holy Spirit, and by teaching them to obey everything I have commanded you."


### Word Data:

* Strong's: H3928, G3100, G3101, G3102


## <a id="tw-term-kt-discipline"/>discipline, disciplines, disciplined, self-discipline

### Definition:

The term "discipline" refers to training people to obey a set of guidelines for moral behavior.

* Parents discipline their children by providing moral guidance and direction for them and teaching them to obey.
* Similarly, God disciplines his children to help them produce healthy spiritual fruit in their lives, such as joy, love, and patience.
* Discipline involves instruction regarding how to live to please God, as well as punishment for behavior that is against God's will.
* Self-discipline is the process of applying moral and spiritual principles to one's own life.

### Translation Suggestions:

 * Depending on the context, "discipline" could be translated as "train and instruct" or "morally guide" or "punish for wrongdoing."
 * The noun "discipline" could be translated as "moral training" or "punishment" or "moral correction" or "moral guidance and instruction."

### Bible References:

* [Ephesians 06:4](https://git.door43.org/Door43/en_tn/src/master/eph/06/04.md)
* [Hebrews 12:4-6](https://git.door43.org/Door43/en_tn/src/master/heb/12/04.md)
* [Proverbs 19:17-18](https://git.door43.org/Door43/en_tn/src/master/pro/19/17.md)
* [Proverbs 23:13-14](https://git.door43.org/Door43/en_tn/src/master/pro/23/13.md)


### Word Data:

* Strong's: H4148


## <a id="tw-term-kt-divine"/>divine

### Definition:

The term "divine" refers to anything pertaining to God.

* Some ways this term is used include "divine authority," "divine judgment," "divine nature," "divine power," and "divine glory."
* In one passage in the Bible, the term "divine" is used to describe something about a false deity.

### Translation Suggestions:

* Ways to translate the term "divine" could include "God's" or "from God" or "pertaining to God" or "characterized by God."
* For example, "divine authority" could be translated as "God's authority" or "authority that comes from God."
* The phrase "divine glory" could be translated as "God's glory" or "the glory that God has" or "glory that comes from God."
* Some translations may prefer to use a different word when describing something that pertains to a false god.

(See also: [authority](#authority), [false god](#falsegod), [glory](#glory), [God](#god), [judge](#judge), [power](#power))

### Bible References:

* [2 Corinthians 10:3-4](https://git.door43.org/Door43/en_tn/src/master/2co/10/03.md)
* [2 Peter 01:3-4](https://git.door43.org/Door43/en_tn/src/master/2pe/01/03.md)
* [Romans 01:20-21](https://git.door43.org/Door43/en_tn/src/master/rom/01/20.md)

### Word Data:

* Strong's: G2304, G2999


## <a id="tw-term-kt-dominion"/>dominion

### Definition:

The term "dominion" refers to power, control, or authority over people, animals, or land.

* Jesus Christ is said to have dominion over all the earth, as prophet, priest, and king.
* Satan's dominion has been defeated forever by Jesus Christ's death on the cross.
* At creation, God said that man is to have dominion over fish, birds, and all creatures on the earth.

### Translation Suggestions:

* Depending on the context, other ways to translate this term could include "authority" or "power" or "control."
* The phrase "have dominion over" could be translated as "rule over" or "manage."

(See also: [authority](#authority), [power](#power))

### Bible References:

* [1 Peter 05:10-11](https://git.door43.org/Door43/en_tn/src/master/1pe/05/10.md)
* [Colossians 01:13-14](https://git.door43.org/Door43/en_tn/src/master/col/01/13.md)
* [Jude 01:24-25](https://git.door43.org/Door43/en_tn/src/master/jud/01/24.md)

### Word Data:

* Strong's: H1166, H4474, H4475, H4896, H4910, H4915, H7287, H7300, H7980, H7985, G2634, G2904, G2961, G2963


## <a id="tw-term-kt-elect"/>chosen one, chosen ones, choose, chosen people, Chosen One, elect

### Definition:

The term "the elect" literally means "chosen ones" or "chosen people" and refers to those whom God has appointed or selected to be his people. "Chosen One" or "Chosen One of God" is a title that refers to Jesus, who is the chosen Messiah.

* The term "choose" means to select something or someone or to decide something. It is often used to refer to God appointing people to belong to him and to serve him.
* To be "chosen" means to be "selected" or "appointed" to be or do something.
* God chose people to be holy, to be set apart by him for the purpose of bearing good spiritual fruit. That is why they are called "the chosen (ones) or "the elect."
* The term "chosen one" is sometimes used in the Bible to refer to certain people such as Moses and King David whom God had appointed as leaders over his people. It is also used to refer to the nation of Israel as God's chosen people.
* The phrase "the elect" is an older term that literally means "the chosen ones" or "the chosen people." This phrase in the original language is plural when referring to believers in Christ.
* In older English Bible versions, the term "elect" is used in both the Old and New Testaments to translate the word for "chosen one(s)." More modern versions use "elect" only in the New Testament, to refer to people who have been saved by God through faith in Jesus. Elsewhere in the Bible text, they translate this word more literally as "chosen ones."

### Translation Suggestions:

* It is best to translate "elect" with a word or phrase that means "chosen ones" or "chosen people." This could also be translated as "people whom God chose" or "the ones God appointed to be his people."
* The phrase "who were chosen" could also be translated as "who were appointed" or "who were selected" or "whom God chose."
* "I chose you" could be translated as "I appointed you" or "I selected you."
* In reference to Jesus, "Chosen One" could also be translated as "God's chosen One" or "God's specially appointed Messiah" or "the One God appointed (to save people)."

(See also: [appoint](#appoint), [Christ](#christ))

### Bible References:

* [2 John 01:1-3](https://git.door43.org/Door43/en_tn/src/master/2jn/01/01.md)
* [Colossians 03:12-14](https://git.door43.org/Door43/en_tn/src/master/col/03/12.md)
* [Ephesians 01:3-4](https://git.door43.org/Door43/en_tn/src/master/eph/01/03.md)
* [Isaiah 65:22-23](https://git.door43.org/Door43/en_tn/src/master/isa/65/22.md)
* [Luke 18:6-8](https://git.door43.org/Door43/en_tn/src/master/luk/18/06.md)
* [Matthew 24:19-22](https://git.door43.org/Door43/en_tn/src/master/mat/24/19.md)
* [Romans 08:33-34](https://git.door43.org/Door43/en_tn/src/master/rom/08/33.md)


### Word Data:

* Strong's: H970, H972, H977, H1254, H1262, H1305, H4005, H6901, G138, G140, G1586, G1588, G1589, G1951, G4400, G4401, G4758, G4899, G5500


## <a id="tw-term-kt-ephod"/>ephod

### Definition:

An ephod was an apron-like garment worn by the Israelite priests. It had two parts, front and back, that were joined together at the shoulders and tied around the waist with a cloth belt.

* One kind of ephod was made of plain linen and was worn by the ordinary priests.
* The ephod worn by the high priest was specially embroidered with gold, blue, purple, and red yarn.
* The breastpiece of the high priest was attached to the front of the ephod. Behind the breastpiece were stored the Urim and Thummim, which were stones used for asking God what his will was in certain matters.
* The judge Gideon foolishly made an ephod out of gold and it became something that the Israelites worshiped as an idol.

(See also: [priest](#priest))

### Bible References:

* [1 Samuel 02:18-19](https://git.door43.org/Door43/en_tn/src/master/1sa/02/18.md)
* [Exodus 28:4-5](https://git.door43.org/Door43/en_tn/src/master/exo/28/04.md)
* [Hosea 03:4-5](https://git.door43.org/Door43/en_tn/src/master/hos/03/04.md)
* [Judges 08:27-28](https://git.door43.org/Door43/en_tn/src/master/jdg/08/27.md)
* [Leviticus 08:6-7](https://git.door43.org/Door43/en_tn/src/master/lev/08/06.md)

### Word Data:

* Strong's: H641, H642, H646


## <a id="tw-term-kt-eternity"/>eternity, everlasting, eternal, forever

### Definition:

The terms "everlasting" and "eternal" have very similar meanings and refer to something that will always exist or that lasts forever.

* The term "eternity" refers to a state of being that has no beginning or end. It can also refer to life that never ends.
* After this present life on earth, humans will spend eternity either in heaven with God or in hell apart from God.
* The terms "eternal life" and "everlasting life" are used in the New Testament to refer to living forever with God in heaven.
* The phrase "forever and ever" has the idea of time that never ends and expresses what eternity or eternal life is like.

The term "forever" refers to never-ending time. Sometimes it is used figuratively to mean "a very long time."

* The term "forever and ever" emphasizes that something will always happen or exist.
* The phrase "forever and ever" is a way of expressing what eternity or eternal life is. It also has the idea of time that never ends.
* God said that David's throne would last "forever." This is referred to the fact that David's descendant Jesus will reign as king forever. 

### Translation Suggestions:

* Other ways to translate "eternal" or "everlasting" could include"unending" or "never stopping" or "always continuing."
* The terms "eternal life" and "everlasting life" could also be translated as "life that never ends" or "life that continues without stopping" or "the raising up of our bodies to live forever."
* Depending on the context, different ways to translate "eternity" could include "existing outside of time" or "unending life" or "life in heaven."
* Also consider how this word is translated in a Bible translation in a local or national language. (See: [How to Translate Unknowns](https://git.door43.org/Door43/en_man/src/master/translate/translate-unknown/01.md))

* "Forever" could also be translated by "always" or "never ending."
* The phrase "will last forever" could also be translated as "always exist" or "will never stop" or "will always continue."
* The emphatic phrase "forever and ever" could also be translated as "for always and always" or "not ever ending" or "which never, ever ends."
* David's throne lasting forever could be translated as "David's descendant will reign forever" or "a descendant of David will always be reigning."

(See also: [David](names.html#david), [reign](other.html#reign), [life](#life))

### Bible References:

* [Genesis 17:7-8](https://git.door43.org/Door43/en_tn/src/master/gen/17/07.md)
* [Genesis 48:3-4](https://git.door43.org/Door43/en_tn/src/master/gen/48/03.md)
* [Exodus 15:17-18](https://git.door43.org/Door43/en_tn/src/master/exo/15/17.md)
* [2 Samuel 03:28-30](https://git.door43.org/Door43/en_tn/src/master/2sa/03/28.md)
* [1 Kings 02:32-33](https://git.door43.org/Door43/en_tn/src/master/1ki/02/32.md)
* [Job 04:20-21](https://git.door43.org/Door43/en_tn/src/master/job/04/20.md)
* [Psalms 021:3-4](https://git.door43.org/Door43/en_tn/src/master/psa/021/003.md)
* [Isaiah 09:6-7](https://git.door43.org/Door43/en_tn/src/master/isa/09/06.md)
* [Isaiah 40:27-28](https://git.door43.org/Door43/en_tn/src/master/isa/40/27.md)
* [Daniel 07:17-18](https://git.door43.org/Door43/en_tn/src/master/dan/07/17.md)
* [Luke 18:18-21](https://git.door43.org/Door43/en_tn/src/master/luk/18/18.md)
* [Acts 13:46-47](https://git.door43.org/Door43/en_tn/src/master/act/13/46.md)
* [Romans 05:20-21](https://git.door43.org/Door43/en_tn/src/master/rom/05/20.md)
* [Hebrews 06:19-20](https://git.door43.org/Door43/en_tn/src/master/heb/06/19.md)
* [Hebrews 10:11-14](https://git.door43.org/Door43/en_tn/src/master/heb/10/11.md)
* [1 John 01:1-2](https://git.door43.org/Door43/en_tn/src/master/1jn/01/01.md)
* [1 John 05:11-12](https://git.door43.org/Door43/en_tn/src/master/1jn/05/11.md)
* [Revelation 01:4-6](https://git.door43.org/Door43/en_tn/src/master/rev/01/04.md)
* [Revelation 22:3-5](https://git.door43.org/Door43/en_tn/src/master/rev/22/03.md)

### Examples from the Bible stories:

* __[27:01](https://git.door43.org/Door43/en_tn/src/master/obs/27/01.md)__ One day, an expert in the Jewish law came to Jesus to test him, saying, "Teacher, what must I do to inherit __eternal life__?"
* __[28:01](https://git.door43.org/Door43/en_tn/src/master/obs/28/01.md)__ One day, a rich young ruler came up to Jesus and asked him, "Good Teacher, what must I do to have __eternal life__?" Jesus said to him, "Why do you ask me about what is good? There is only One who is good, and that is God. But if you want to have __eternal life__, obey God's laws."
* __[28:10](https://git.door43.org/Door43/en_tn/src/master/obs/28/10.md)__ Jesus answered, "Everyone who has left houses, brothers, sisters, father, mother, children, or property for my name's sake, will receive 100 times more and will also receive __eternal life__."

### Word Data:

* Strong's: H3117, H4481, H5331, H5703, H5705, H5769, H5865, H5957, H6924, G126, G165, G166, G1336


## <a id="tw-term-kt-eunuch"/>eunuch, eunuchs

### Definition:

Usually the term "eunuch" refers to a man who has been castrated. The term later became a general term to refer to any government official, even those without the deformity.

* Jesus said that some eunuchs were born that way, perhaps because of damaged sex organs or because of not being able to function sexually. Others chose to live like eunuchs in a celibate lifestyle.
* In ancient times, eunuchs were often kings' servants who were set as guards over the women's quarters.
* Some eunuchs were important government officials, such as the Ethiopian eunuch who met the apostle Philip in the desert.

(See also: [Philip](names.html#philip))

### Bible References:

* [Acts 08:26-28](https://git.door43.org/Door43/en_tn/src/master/act/08/26.md)
* [Acts 08:36-38](https://git.door43.org/Door43/en_tn/src/master/act/08/36.md)
* [Acts 08:39-40](https://git.door43.org/Door43/en_tn/src/master/act/08/39.md)
* [Isaiah 39:7-8](https://git.door43.org/Door43/en_tn/src/master/isa/39/07.md)
* [Jeremiah 34:17-19](https://git.door43.org/Door43/en_tn/src/master/jer/34/17.md)
* [Matthew 19:10-12](https://git.door43.org/Door43/en_tn/src/master/mat/19/10.md)


### Word Data:

* Strong's: H5631, G2134, G2135

## <a id="tw-term-kt-evangelism"/>evangelist, evangelists

### Definition:

An "evangelist" is a person who tells other people the good news about Jesus Christ.

* The literal meaning of "evangelist" is "someone who preaches the good news."
* Jesus sent his apostles out to spread the good news about how to be part of God's kingdom through trusting in Jesus and his sacrifice for sin.
* All Christians are exhorted to share this good news.
* Some Christians are given a special spiritual gift to effectively tell the gospel to others. These people are said to have the gift of evangelism and are called "evangelists."

### Translation Suggestions:

* The term "evangelist" could be translated as "someone who preaches the good news" or "teacher of the good news" or "person who proclaims the good news (about Jesus)" or "good news proclaimer."

(See also: [good news](#goodnews), [spirit](#spirit), [gift](#gift))

### Bible References:

* [2 Timothy 04:3-5](https://git.door43.org/Door43/en_tn/src/master/2ti/04/03.md)
* [Ephesians 04:11-13](https://git.door43.org/Door43/en_tn/src/master/eph/04/11.md)


### Word Data:

* Strong's: G2099


## <a id="tw-term-kt-evil"/>evil, wicked, wickedness

### Definition:

The terms "evil" and "wicked" both refer to anything that is opposed to God's holy character and will.

* While "evil" may describe a person's character, "wicked" may refer more to a person's behavior. However, both terms are very similar in meaning.
* The term "wickedness" refers to the state of being that exists when people do wicked things.
* The results of evil are clearly shown in how people mistreat others by killing, stealing, slandering and being cruel and unkind.

### Translation Suggestions:

* Depending on the context, the terms "evil" and "wicked" can be translated as "bad" or "sinful" or "immoral."
* Other ways to translate these could include "not good" or "not righteous" or "not moral."
* Make sure the words or phrases that are used to translate these terms fit the context that is natural in the target language.

(See also: [disobey](other.html#disobey), [sin](#sin), [good](#good), [righteous](#righteous), [demon](#demon))

### Bible References:

* [1 Samuel 24:10-11](https://git.door43.org/Door43/en_tn/src/master/1sa/24/10.md)
* [1 Timothy 06:9-10](https://git.door43.org/Door43/en_tn/src/master/1ti/06/09.md)
* [3 John 01:9-10](https://git.door43.org/Door43/en_tn/src/master/3jn/01/09.md)
* [Genesis 02:15-17](https://git.door43.org/Door43/en_tn/src/master/gen/02/15.md)
* [Genesis 06:5-6](https://git.door43.org/Door43/en_tn/src/master/gen/06/05.md)
* [Job 01:1-3](https://git.door43.org/Door43/en_tn/src/master/job/01/01.md)
* [Job 08:19-20](https://git.door43.org/Door43/en_tn/src/master/job/08/19.md)
* [Judges 09:55-57](https://git.door43.org/Door43/en_tn/src/master/jdg/09/55.md)
* [Luke 06:22-23](https://git.door43.org/Door43/en_tn/src/master/luk/06/22.md)
* [Matthew 07:11-12](https://git.door43.org/Door43/en_tn/src/master/mat/07/11.md)
* [Proverbs 03:7-8](https://git.door43.org/Door43/en_tn/src/master/pro/03/07.md)
* [Psalms 022:16-17](https://git.door43.org/Door43/en_tn/src/master/psa/022/016.md)

### Examples from the Bible stories:

* __[02:04](https://git.door43.org/Door43/en_tn/src/master/obs/02/04.md)__ "God just knows that as soon as you eat it, you will be like God and will understand good and __evil__  like he does."
* __[03:01](https://git.door43.org/Door43/en_tn/src/master/obs/03/01.md)__ After a long time, many people were living in the world. They had become very __wicked__  and violent.
* __[03:02](https://git.door43.org/Door43/en_tn/src/master/obs/03/02.md)__ But Noah found favor with God. He was a righteous man living among __wicked__  people.
* __[04:02](https://git.door43.org/Door43/en_tn/src/master/obs/04/02.md)__ God saw that if they all kept working together to do __evil__, they could do many more sinful things.
* __[08:12](https://git.door43.org/Door43/en_tn/src/master/obs/08/12.md)__ "You tried to do __evil__  when you sold me as a slave, but God used the __evil__  for good!"
* __[14:02](https://git.door43.org/Door43/en_tn/src/master/obs/14/02.md)__ They (Canaanites) worshiped false gods and did many __evil__  things.
* __[17:01](https://git.door43.org/Door43/en_tn/src/master/obs/17/01.md)__ But then he (Saul) became a __wicked__  man who did not obey God, so God chose a different man who would one day be king in his place.
* __[18:11](https://git.door43.org/Door43/en_tn/src/master/obs/18/11.md)__ In the new kingdom of Israel, all the kings were __evil__.
* __[29:08](https://git.door43.org/Door43/en_tn/src/master/obs/29/08.md)__ The king was so angry that he threw the __wicked__  servant into prison until he could pay back all of his debt.
* __[45:02](https://git.door43.org/Door43/en_tn/src/master/obs/45/02.md)__ They said, "We heard him (Stephen) speak __evil__  things about Moses and God!"
* __[50:17](https://git.door43.org/Door43/en_tn/src/master/obs/50/17.md)__ He (Jesus) will wipe away every tear and there will be no more suffering, sadness, crying, __evil__, pain, or death.

### Word Data:

* Strong's: H205, H605, H1100, H1681, H1942, H2154, H2162, H2617, H3415, H4209, H4849, H5753, H5766, H5767, H5999, H6001, H6090, H7451, H7455, H7489, H7561, H7562, H7563, H7564, G92, G113, G459, G932, G987, G988, G1426, G2549, G2551, G2554, G2555, G2556, G2557, G2559, G2560, G2635, G2636, G4151, G4189, G4190, G4191, G5337


## <a id="tw-term-kt-exalt"/>exalt, exalted, exalts, exaltation

### Definition:

To exalt is to highly praise and honor someone. It can also mean to put someone in a high position.

* In the Bible, the term "exalt" is most often used for exalting God.
* When a person exalts himself, it means he is thinking about himself in a proud or arrogant way.

### Translation Suggestions:

* Ways to translate "exalt" could include "highly praise" or "honor greatly" or "extol" or "speak highly of."
* In some contexts it could be translated by a word or phrase that means "put in a higher position" or "give more honor to" or "talk about proudly."
* "Do not exalt yourself" could also be translated as "Do not think of yourself too highly" or "Do not brag about yourself."
* "Those that exalt themselves" could also be translated as "Those who think proudly about themselves" or "Those who boast about themselves."

(See also: [praise](other.html#praise), [worship](#worship), [glory](#glory), [boast](#boast), [proud](other.html#proud))

### Bible References:

* [1 Peter 05:5-7](https://git.door43.org/Door43/en_tn/src/master/1pe/05/05.md)
* [2 Samuel 22:47-49](https://git.door43.org/Door43/en_tn/src/master/2sa/22/47.md)
* [Acts 05:29-32](https://git.door43.org/Door43/en_tn/src/master/act/05/29.md)
* [Philippians 02:9-11](https://git.door43.org/Door43/en_tn/src/master/php/02/09.md)
* [Psalms 018:46-47](https://git.door43.org/Door43/en_tn/src/master/psa/018/046.md)


### Word Data:

* Strong's: H1361, H4984, H5375, H5549, H5927, H7311, H7426, H7682, G1869, G5229, G5251, G5311, G5312


## <a id="tw-term-kt-exhort"/>exhort, exhortation

### Definition:

The term "exhort" means to strongly encourage and urge someone to do what is right. Such encouragement is called "exhortation."

* The purpose of exhortation is to persuade other people to avoid sin and follow God's will.
* The New Testament teaches Christians to exhort each other in love, not harshly or abruptly.

### Translation Suggestions:

* Depending on the context, "exhort" could also be translated as "strongly urge" or "persuade" or "advise."
* Make sure the translation of this term does not imply that the exhorter is angry. The term should convey strength and seriousness, but should not refer to angry speech.
* In most contexts, the term "exhort" should be translated differently than "encourage," which means to inspire, reassure, or comfort someone.
* Usually this term will also be translated differently from "admonish," which means to warn or correct someone for his wrong behavior.

### Bible References:

* [1 Thessalonians 02:3-4](https://git.door43.org/Door43/en_tn/src/master/1th/02/03.md)
* [1 Thessalonians 02:10-12](https://git.door43.org/Door43/en_tn/src/master/1th/02/10.md)
* [1 Timothy 05:1-2](https://git.door43.org/Door43/en_tn/src/master/1ti/05/01.md)
* [Luke 03:18-20](https://git.door43.org/Door43/en_tn/src/master/luk/03/18.md)

### Word Data:

* Strong's: G3867, G3870, G3874, G4389


## <a id="tw-term-kt-faith"/>faith

### Definition:

In general, the term "faith" refers to a belief, trust or confidence in someone or something.

* To "have faith" in someone is to believe that what he says and does is true and trustworthy.
* To "have faith in Jesus" means to believe all of God's teachings about Jesus. It especially means that people trust in Jesus and his sacrifice to cleanse them from their sin and to rescue them from the punishment they deserve because of their sin.
* True faith or belief in Jesus will cause a person to produce good spiritual fruits or behaviors because the Holy Spirit is living in him.
* Sometimes "faith" refers generally to all the teachings about Jesus, as in the expression "the truths of the faith."
* In contexts such as "keep the faith" or "abandon the faith," the term "faith" refers to the state or condition of believing all the teachings about Jesus.

### Translation Suggestions:

* In some contexts, "faith" can be translated as "belief" or "conviction" or "confidence" or "trust."
* For some languages these terms will be translated using forms of the verb "believe." (See: [abstractnouns](https://git.door43.org/Door43/en_man/src/master/translate/figs-abstractnouns/01.md))
* The expression "keep the faith" could be translated by "keep believing in Jesus" or "continue to believe in Jesus."
* The sentence "they must keep hold of the deep truths of the faith" could be translated by "they must keep believing all the true things about Jesus that they have been taught."
* The expression "my true son in the faith" could be translated by something like "who is like a son to me because I taught him to believe in Jesus" or "my true spiritual son, who believes in Jesus."

(See also: [believe](#believe), [faithful](#faithful))

### Bible References:

* [2 Timothy 04:6-8](https://git.door43.org/Door43/en_tn/src/master/2ti/04/06.md)
* [Acts 06:7](https://git.door43.org/Door43/en_tn/src/master/act/06/07.md)
* [Galatians 02:20-21](https://git.door43.org/Door43/en_tn/src/master/gal/02/20.md)
* [James 02:18-20](https://git.door43.org/Door43/en_tn/src/master/jas/02/18.md)

### Examples from the Bible stories:

* __[05:06](https://git.door43.org/Door43/en_tn/src/master/obs/05/06.md)__ When Isaac was a young man, God tested Abraham's __faith__  by saying, "Take Isaac, your only son, and kill him as a sacrifice to me."
* __[31:07](https://git.door43.org/Door43/en_tn/src/master/obs/31/07.md)__ Then he (Jesus) said to Peter, "You man of little __faith__, why did you doubt?"
* __[32:16](https://git.door43.org/Door43/en_tn/src/master/obs/32/16.md)__ Jesus said to her, "Your __faith__  has healed you. Go in peace."
* __[38:09](https://git.door43.org/Door43/en_tn/src/master/obs/38/09.md)__ Then Jesus said to Peter, "Satan wants to have all of you, but I have prayed for you, Peter, that your __faith__  will not fail.

### Word Data:

* Strong's: H529, H530, G1680, G3640, G4102, G6066


## <a id="tw-term-kt-faithful"/>faithful, faithfulness, unfaithful, unfaithfulness

### Definition:

To be "faithful" to God means to consistently live according to God's teachings. It means to be loyal to him by obeying him.The state or condition of being faithful is "faithfulness."

* A person who is faithful can be trusted to always keep his promises and to always fulfill his responsibilities to other people.
* A faithful person perseveres in doing a task, even when it is long and difficult.
* Faithfulness to God is the consistent practice of doing what God wants us to do.

The term "unfaithful" describes people who do not do what God has commanded them to do. The condition or practice of being unfaithful is "unfaithfulness."

 * The people of Israel were called "unfaithful" when they began to worship idols and when they disobeyed God in other ways.
 * In marriage, someone who commits adultery is "unfaithful" to his or her spouse.
 * God used the term "unfaithfulness" to describe Israel's disobedient behavior. They were not obeying God or honoring him.

### Translation Suggestions:

* In many contexts, "faithful" can be translated as "loyal" or "dedicated" or "dependable."
* In other contexts, "faithful" can be translated by a word or phrase that means "continuing to believe" or "persevering in believing and obeying God."
* Ways that "faithfulness" could be translated could include "persevering in believing" or "loyalty" or "trustworthiness" or "believing and obeying God."

 * Depending on the context, "unfaithful" could be translated as "not faithful" or "unbelieving" or "not obedient" or "not loyal."
 * The phrase "the unfaithful" could be translated as "people who are not faithful (to God)" or "unfaithful people" or "those who disobey God" or "people who rebel against God."
 * The term "unfaithfulness" could be translated as "disobedience" or "disloyalty" or "not believing or obeying."
 * In some languages, the term "unfaithful" is related to the word for "unbelief."

(See also: [adultery](#adultery), [believe](#believe), [disobey](other.html#disobey), [faith](#faith), [believe](#believe))

### Bible References:

* [Genesis 24:49](https://git.door43.org/Door43/en_tn/src/master/gen/24/49.md)
* [Leviticus 26:40-42](https://git.door43.org/Door43/en_tn/src/master/lev/26/40.md)
* [Numbers 12:6-8](https://git.door43.org/Door43/en_tn/src/master/num/12/06.md)
* [Joshua 02:14](https://git.door43.org/Door43/en_tn/src/master/jos/02/14.md)
* [Judges 02:16-17](https://git.door43.org/Door43/en_tn/src/master/jdg/02/16.md)
* [1 Samuel 02:9](https://git.door43.org/Door43/en_tn/src/master/1sa/02/09.md)
* [Psalm 012:1](https://git.door43.org/Door43/en_tn/src/master/psa/012/001.md)
* [Proverbs 11:12-13](https://git.door43.org/Door43/en_tn/src/master/pro/11/12.md)
* [Isaiah 01:26](https://git.door43.org/Door43/en_tn/src/master/isa/01/26.md)
* [Jeremiah 09:7-9](https://git.door43.org/Door43/en_tn/src/master/jer/09/07.md)
* [Hosea 05:5-7](https://git.door43.org/Door43/en_tn/src/master/hos/05/05.md)
* [Luke 12:45-46](https://git.door43.org/Door43/en_tn/src/master/luk/12/45.md)
* [Luke 16:10-12](https://git.door43.org/Door43/en_tn/src/master/luk/16/10.md)
* [Colossians 01:7-8](https://git.door43.org/Door43/en_tn/src/master/col/01/07.md)
* [1 Thessalonians 05:23-24](https://git.door43.org/Door43/en_tn/src/master/1th/05/23.md)
* [3 John 01:5-8](https://git.door43.org/Door43/en_tn/src/master/3jn/01/05.md)

### Examples from the Bible stories:

* __[08:05](https://git.door43.org/Door43/en_tn/src/master/obs/08/05.md)__ Even in prison, Joseph remained __faithful__  to God, and God blessed him.
* __[14:12](https://git.door43.org/Door43/en_tn/src/master/obs/14/12.md)__ Even so, God was still __faithful__  to His promises to Abraham, Isaac, and Jacob.
* __[15:13](https://git.door43.org/Door43/en_tn/src/master/obs/15/13.md)__ The people promised to remain __faithful__  to God and follow his laws.
* __[17:09](https://git.door43.org/Door43/en_tn/src/master/obs/17/09.md)__ David ruled with justice and __faithfulness__  for many years, and God blessed him. However, toward the end of his life he sinned terribly against God.
* __[18:04](https://git.door43.org/Door43/en_tn/src/master/obs/18/04.md)__ God was angry with Solomon and, as a punishment for Solomon's __unfaithfulness__, he promised to divide the nation of Israel into two kingdoms after Solomon's death.
* __[35:12](https://git.door43.org/Door43/en_tn/src/master/obs/35/12.md)__ "The older son said to his father, 'All these years I have worked __faithfully__  for you!"
* __[49:17](https://git.door43.org/Door43/en_tn/src/master/obs/49/17.md)__ But God is __faithful__  and says that if you confess your sins, he will forgive you.
* __[50:04](https://git.door43.org/Door43/en_tn/src/master/obs/50/04.md)__ If you remain __faithful__  to me to the end, then God will save you."

### Word Data:

* Strong's: H529, H530, H539, H540, H571, H898, H2181, H4603, H4604, H4820, G569, G571, G4103


## <a id="tw-term-kt-faithless"/>faithless, faithlessness

### Definition:

The term "faithless" means to not have faith or to not believe. 

* This word is used to describe people who do not believe in God. Their lack of belief is seen by the immoral way they act.
* The prophet Jeremiah accused Israel of being faithless and disobedient to God.
* They worshiped idols and followed other ungodly customs of people groups who did not worship or obey God.

### Translation Suggestions

* Depending on the context, the term "faithless" could be translated as "unfaithful" or "unbelieving" or "disobedient to God" or "not believing."
* The term "faithlessness" could be translated as "unbelief" or "unfaithfulness" or "rebellion against God."

(See also: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [believe](#believe), [faithful](#faithful), [disobey](other.html#disobey))

### Bible References:

* [Ezekiel 43:6-8](https://git.door43.org/Door43/en_tn/src/master/ezk/43/06.md)
* [Ezra 09:1-2](https://git.door43.org/Door43/en_tn/src/master/ezr/09/01.md)
* [Jeremiah 02:18-19](https://git.door43.org/Door43/en_tn/src/master/jer/02/18.md)
* [Proverbs 02:20-22](https://git.door43.org/Door43/en_tn/src/master/pro/02/20.md)
* [Revelation 21:7-8](https://git.door43.org/Door43/en_tn/src/master/rev/21/07.md)

### Word Data:

* Strong's: G571


## <a id="tw-term-kt-falsegod"/>god, false god, gods, goddess, idol, idols, idolater, idolaters, idolatrous, idolatry

### Definition:

A false god is something that people worship instead of the one true God. The term "goddess" refers specifically to a female false god.

* These false gods or goddesses do not exist. Yahweh is the only God.
* People sometimes make objects into idols to worship as symbols of their false gods.
* In the Bible, God's people frequently turned away from obeying him in order to worship false gods.
* Demons often deceive people into believing that the false gods and idols they worship have power.
* Baal, Dagon, and Molech were three of the many false gods that were worshiped by people in Bible times.
* Asherah and Artemis (Diana) were two of the goddesses that ancient peoples worshiped.

An idol is an object that people make so they can worship it. Something is described as "idolatrous" if it involves giving honor to something other than the one true God.

* People make idols to represent the false gods that they worship.
* These false gods do not exist; there is no God besides Yahweh.
* Sometimes demons work through an idol to make it seem like it has power, even though it does not.
* Idols are often made of valuable materials like gold, silver, bronze, or expensive wood.
* An "idolatrous kingdom" means a "kingdom of people who worship idols" or a "kingdom of people who worship earthly things."
* The term "idolatrous figure" is another word for a "carved image" or an "idol."

### Translation Suggestions:

* There may already be a word for "god" or "false god" in the language or in a nearby language.
* The term "idol" could be used to refer to false gods.
* In English, a lower case "g" is used to refer to false gods, and upper case "G" is used to refer to the one true God. Other languages also do that.
* Another option would be to use a completely different word to refer to the false gods.
* Some languages may add a word to specify whether the false god is described as male or female.

(See also: [God](#god), [Asherah](names.html#asherim), [Baal](names.html#baal), [Molech](names.html#molech), [demon](#demon), [image](other.html#image), [kingdom](other.html#kingdom), [worship](#worship))

### Bible References:

* [Genesis 35:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/35/01.md)
* [Exodus 32:1-2](https://git.door43.org/Door43/en_tn/src/master/exo/32/01.md)
* [Psalms 031:5-7](https://git.door43.org/Door43/en_tn/src/master/psa/031/005.md)
* [Psalms 081:8-10](https://git.door43.org/Door43/en_tn/src/master/psa/081/008.md)
* [Isaiah 44:20](https://git.door43.org/Door43/en_tn/src/master/isa/44/20.md)
* [Acts 07:41-42](https://git.door43.org/Door43/en_tn/src/master/act/07/41.md)
* [Acts 07:43](https://git.door43.org/Door43/en_tn/src/master/act/07/43.md)
* [Acts 15:19-21](https://git.door43.org/Door43/en_tn/src/master/act/15/19.md)
* [Acts 19:26-27](https://git.door43.org/Door43/en_tn/src/master/act/19/26.md)
* [Romans 02:21-22](https://git.door43.org/Door43/en_tn/src/master/rom/02/21.md)
* [Galatians 04:8-9](https://git.door43.org/Door43/en_tn/src/master/gal/04/08.md)
* [Galatians 05:19-21](https://git.door43.org/Door43/en_tn/src/master/gal/05/19.md)
* [Colossians 03:5-8](https://git.door43.org/Door43/en_tn/src/master/col/03/05.md)
* [1 Thessalonians 01:8-10](https://git.door43.org/Door43/en_tn/src/master/1th/01/08.md)

### Examples from the Bible stories:

* __[10:02](https://git.door43.org/Door43/en_tn/src/master/obs/10/02.md)__ Through these plagues, God showed Pharaoh that he is more powerful than Pharaoh and all of Egypt's __gods__.
* __[13:04](https://git.door43.org/Door43/en_tn/src/master/obs/13/04.md)__ Then God gave them the covenant and said, "I am Yahweh, your God, who saved you from slavery in Egypt. Do not worship other __gods__."
* __[14:02](https://git.door43.org/Door43/en_tn/src/master/obs/14/02.md)__ They (Canaanites) worshiped false __gods__  and did many evil things.
* __[16:01](https://git.door43.org/Door43/en_tn/src/master/obs/16/01.md)__ The Israelites began to worship the Canaanite __gods__  instead of Yahweh, the true God.
* __[18:13](https://git.door43.org/Door43/en_tn/src/master/obs/18/13.md)__ But most of Judah's kings were evil, corrupt, and they worshiped idols. Some of the kings even sacrificed their children to false __gods__.


### Word Data:

* Strong's: H205, H367, H410, H426, H430, H457, H1322, H1544, H1892, H2553, H3649, H4656, H4906, H5236, H5566, H6089, H6090, H6091, H6456, H6459, H6673, H6736, H6754, H7723, H8163, H8251, H8267, H8441, H8655, G1493, G1494, G1495, G1496, G1497, G2299, G2712


## <a id="tw-term-kt-favor"/>favor, favors, favorable, favoritism

### Definition:

To "favor" is to prefer. When someone favors a person, he regards that person positively and does more to benefit that person than he does to benefit others.

* The term "favoritism" means the attitude of acting favorably toward some people but not others. It means the inclination to pick one person over another or one thing over another because the person or item is preferred. Generally, favoratism is considered unfair.
* Jesus grew up "in favor with" God and men. This means they approved of his character and behavior.
* The expression "find favor"with someone means that someone is approved of by that person.
* When a king shows favor to someone, it often means that he approves of that person's request and grants it.
* A "favor" can also be a gesture or action towards or for another person for their benefit. 

### Translation Suggestions:

* Other ways to translate the term "favor" could include, "blessing" or "benefit." 
* The "favorable year of Yahweh" could be translated as "the year (or time) when Yahweh will bring great blessing."
* The term "favoritism" could be translated as "partiality" or "being prejudiced" or "unjust treatment." This word is related to the word "favorite," which means "the one who is preferred or loved best."

### Bible References:

* [1 Samuel 02:25-26](https://git.door43.org/Door43/en_tn/src/master/1sa/02/25.md)
* [2 Chronicles 19:6-7](https://git.door43.org/Door43/en_tn/src/master/2ch/19/06.md)
* [2 Corinthians 01:11](https://git.door43.org/Door43/en_tn/src/master/2co/01/11.md)
* [Acts 24:26-27](https://git.door43.org/Door43/en_tn/src/master/act/24/26.md)
* [Genesis 41:14-16](https://git.door43.org/Door43/en_tn/src/master/gen/41/14.md)
* [Genesis 47:25-26](https://git.door43.org/Door43/en_tn/src/master/gen/47/25.md)
* [Genesis 50:4-6](https://git.door43.org/Door43/en_tn/src/master/gen/50/04.md)


### Word Data:

* Strong's: H995, H1156, H1293, H1779, H1921, H2580, H2603, H2896, H5278, H5375, H5414, H5869, H5922, H6213, H6437, H6440, H6491, H7521, H7522, H7965, G1184, G3685, G4380, G5485, G5486


## <a id="tw-term-kt-fear"/>fear, fears, afraid

### Definition:

The terms "fear" and "afraid" refer to the unpleasant feeling a person has when there is a threat of harm to himself or others.

* The term "fear" can also refer to a deep respect and awe for a person in authority.
* The phrase "fear of Yahweh," as well as related terms "fear of God" and "fear of the Lord," refer to a deep respect of God and the showing of that respect by obeying him. This fear is motivated by knowing that God is holy and hates sin.
* The Bible teaches that a person who fears Yahweh will become wise.

### Translation Suggestions:

* Depending on the context, to "fear" can be translated as to "be afraid" or to "deeply respect" or to "revere" or to "be in awe of."
* The term "afraid" could be translated as "terrified" or "scared" or "fearful."
* The sentence "The fear of God fell on all of them" could be translated as "Suddenly they all felt a deep awe and respect for God" or "Immediately, they all felt very amazed and revered God deeply" or "Right then, they all felt very afraid of God (because of his great power)."
* The phrase "fear not" could also be translated as "do not be afraid" or "stop being afraid."
* Note that the phrase "fear of Yahweh" does not occur in the New Testament. The phrase "fear of the Lord" or "fear of the Lord God" is used instead.

(See also: [marvel](other.html#amazed), [awe](other.html#awe), [Lord](#lord), [power](#power), [Yahweh](#yahweh))

### Bible References:

* [1 John 04:17-18](https://git.door43.org/Door43/en_tn/src/master/1jn/04/17.md)
* [Acts 02:43-45](https://git.door43.org/Door43/en_tn/src/master/act/02/43.md)
* [Acts 19:15-17](https://git.door43.org/Door43/en_tn/src/master/act/19/15.md)
* [Genesis 50:18-21](https://git.door43.org/Door43/en_tn/src/master/gen/50/18.md)
* [Isaiah 11:3-5](https://git.door43.org/Door43/en_tn/src/master/isa/11/03.md)
* [Job 06:14-17](https://git.door43.org/Door43/en_tn/src/master/job/06/14.md)
* [Jonah 01:8-10](https://git.door43.org/Door43/en_tn/src/master/jon/01/08.md)
* [Luke 12:4-5](https://git.door43.org/Door43/en_tn/src/master/luk/12/04.md)
* [Matthew 10:28-31](https://git.door43.org/Door43/en_tn/src/master/mat/10/28.md)
* [Proverbs 10:24-25](https://git.door43.org/Door43/en_tn/src/master/pro/10/24.md)


### Word Data:

* Strong's: H367, H926, H1204, H1481, H1672, H1674, H1763, H2119, H2296, H2727, H2729, H2730, H2731, H2844, H2849, H2865, H3016, H3025, H3068, H3372, H3373, H3374, H4032, H4034, H4035, H4116, H4172, H6206, H6342, H6343, H6345, H6427, H7264, H7267, H7297, H7374, H7461, H7493, H8175, G870, G1167, G1168, G1169, G1630, G1719, G2124, G2125, G2962, G5398, G5399, G5400, G5401


## <a id="tw-term-kt-fellowship"/>fellowship

### Definition:

In general, the term "fellowship" refers to friendly interactions between members of a group of people who share similar interests and experiences.

* In the Bible, the term "fellowship" usually refers to the unity of believers in Christ.
* Christian fellowship is a shared relationship that believers have with one another through their relationship with Christ and the Holy Spirit.
* The early Christians expressed their fellowship through listening to the teaching of God's Word and praying together, through the sharing of their belongings, and through eating meals together.
* Christians also have fellowship with God through their faith in Jesus and his sacrificial death on the cross which removed the barrier between God and people.

### Translation Suggestions:

* Ways to translate "fellowship" could include "a sharing together" or  "relationship" or "companionship" or "Christian community."

### Bible References:

* [1 John 01:3-4](https://git.door43.org/Door43/en_tn/src/master/1jn/01/03.md)
* [Acts 02:40-42](https://git.door43.org/Door43/en_tn/src/master/act/02/40.md)
* [Philippians 01:3-6](https://git.door43.org/Door43/en_tn/src/master/php/01/03.md)
* [Philippians 02:1-2](https://git.door43.org/Door43/en_tn/src/master/php/02/01.md)
* [Philippians 03:8-11](https://git.door43.org/Door43/en_tn/src/master/php/03/08.md)
* [Psalms 055:12-14](https://git.door43.org/Door43/en_tn/src/master/psa/055/012.md)

### Word Data:

* Strong's: H2266, H8667, G2842, G2844, G3352, G4790


## <a id="tw-term-kt-filled"/>filled with the Holy Spirit

### Definition:

The term "filled with the Holy Spirit" is a figurative expression that, when used to describe a person means the Holy Spirit is empowering that person to do God's will.

* The expression "filled with" is an expression that often means "controlled by."
* People are "filled with the Holy Spirit" when they follow the Holy Spirit's leading and completely rely on him to help them do what God wants.

### Translation Suggestions:

* This term could be translated as "empowered by the Holy Spirit" or "controlled by the Holy Spirit." But it should not sound as though the Holy Spirit is forcing the person to do something.
* A sentence such as "he was filled with the Holy Spirit" could be translated as "he was living fully by the Spirit's power" or "he was completely guided by the Holy Spirit" or "the Holy Spirit was guiding him completely."
* This term is similar in meaning to the expression "live by the Spirit," but "filled with the Holy Spirit" emphasizes the completeness with which a person allows the Holy Spirit to have control or influence over his life. So these two expressions should be translated differently, if possible.

(See also: [Holy Spirit](#holyspirit))

### Bible References:

* [Acts 04:29-31](https://git.door43.org/Door43/en_tn/src/master/act/04/29.md)
* [Acts 05:17-18](https://git.door43.org/Door43/en_tn/src/master/act/05/17.md)
* [Acts 06:8-9](https://git.door43.org/Door43/en_tn/src/master/act/06/08.md)
* [Luke 01:14-15](https://git.door43.org/Door43/en_tn/src/master/luk/01/14.md)
* [Luke 01:39-41](https://git.door43.org/Door43/en_tn/src/master/luk/01/39.md)
* [Luke 04:1-2](https://git.door43.org/Door43/en_tn/src/master/luk/04/01.md)


### Word Data:

* Strong's: G40, G4130, G4137, G4151


## <a id="tw-term-kt-flesh"/>flesh

### Definition:

In the Bible, the term "flesh" literally refers to the soft tissue of the physical body of a human being or animal.

* The Bible also uses the term "flesh" in a figurative way to refer to all human beings or all living creatures.
* In the New Testament, the term "flesh" is used to refer to the sinful nature of human beings. This is often used in contrast to their spiritual nature.
* The expression "own flesh and blood" refers to someone who is biologically related to another person, such as a parent, sibling, child, or grandchild.
* The expression "flesh and blood" can also refer to a person's ancestors or descendants.
* The expression "one flesh" refers to the physical uniting of a man and woman in marriage.

### Translation Suggestions:

* In the context of an animal's body, "flesh" could be translated as "body" or "skin" or "meat."
* When it is used to refer generally to all living creatures, this term could be translated as "living beings" or "everything that is alive."
* When referring in general to all people, this term could be translated as "people" or "human beings" or "everyone who lives."
* The expression "flesh and blood" could also be translated as "relatives" or "family" or "kinfolk" or "family clan." There may be contexts where it could be translated as "ancestors" or "descendants." 
* Some languages may have an expression that is similar in meaning to "flesh and blood."
* The expression "become one flesh" could be translated as "unite sexually" or "become as one body" or "become like one person in body and spirit." The translation of this expression should be checked to make sure it is acceptable in the project language and culture. (See: [euphemism](https://git.door43.org/Door43/en_man/src/master/translate/figs-euphemism/01.md)). It should also be understood that this is figurative, and does not mean that a man and a woman who "become one flesh" literally become one person. 
### Bible References:

* [1 John 02:15-17](https://git.door43.org/Door43/en_tn/src/master/1jn/02/15.md)
* [2 John 01:7-8](https://git.door43.org/Door43/en_tn/src/master/2jn/01/07.md)
* [Ephesians 06:12-13](https://git.door43.org/Door43/en_tn/src/master/eph/06/12.md)
* [Galatians 01:15-17](https://git.door43.org/Door43/en_tn/src/master/gal/01/15.md)
* [Genesis 02:24-25](https://git.door43.org/Door43/en_tn/src/master/gen/02/24.md)
* [John 01:14-15](https://git.door43.org/Door43/en_tn/src/master/jhn/01/14.md)
* [Matthew 16:17-18](https://git.door43.org/Door43/en_tn/src/master/mat/16/17.md)
* [Romans 08:6-8](https://git.door43.org/Door43/en_tn/src/master/rom/08/06.md)

### Word Data:

* Strong's: H829, H1320, H1321, H2878, H3894, H4207, H7607, H7683, G2907, G4559, G4560, G4561


## <a id="tw-term-kt-foolish"/>fool, fools, foolish, folly

### Definition:

The term "fool" refers to a person who often makes wrong choices, especially choosing to disobey. The term "foolish" describes a person or behavior that is not wise.

* In the Bible, the term "fool" usually refers to a person who does not believe or obey God. This is often contrasted to the wise person, who trusts in God and obeys God.
* In the Psalms, David describes a fool as a person who does not believe in God, one who ignores all the evidence of God in his creation.
* The Old Testament book of Proverbs also gives many descriptions of what a fool, or foolish person, is like.
* The term "folly" refers to an action that is not wise because it is against God's will. Often "folly" also includes the meaning of something that is ridiculous or dangerous.

### Translation Suggestions:

* The term "fool" could be translated as "foolish person" or "unwise person" or "senseless person" or "ungodly person."
* Ways to translate "foolish" could include "lacking understanding" or "unwise" or "senseless."

(See also: [wise](#wise))

### Bible References:

* [Ecclesiastes 01:16-18](https://git.door43.org/Door43/en_tn/src/master/ecc/01/16.md)
* [Ephesians 05:15-17](https://git.door43.org/Door43/en_tn/src/master/eph/05/15.md)
* [Galatians 03:1-3](https://git.door43.org/Door43/en_tn/src/master/gal/03/01.md)
* [Genesis 31:26-28](https://git.door43.org/Door43/en_tn/src/master/gen/31/26.md)
* [Matthew 07:26-27](https://git.door43.org/Door43/en_tn/src/master/mat/07/26.md)
* [Matthew 25:7-9](https://git.door43.org/Door43/en_tn/src/master/mat/25/07.md)
* [Proverbs 13:15-16](https://git.door43.org/Door43/en_tn/src/master/pro/13/15.md)
* [Psalms 049:12-13](https://git.door43.org/Door43/en_tn/src/master/psa/049/012.md)


### Word Data:

* Strong's: H191, H196, H200, H1198, H1984, H2973, H3684, H3687, H3688, H3689, H3690, H5034, H5036, H5039, H5528, H5529, H5530, H5531, H6612, H8417, H8602, H8604, G453, G454, G781, G801, G877, G878, G3471, G3472, G3473, G3474, G3912


## <a id="tw-term-kt-forgive"/>forgive, forgives, forgiven, forgiveness, pardon, pardoned

### Definition:

To forgive someone means to not hold a grudge against that person even though they did something hurtful. "Forgiveness" is the act of forgiving someone.

* Forgiving someone often means not punishing that person for something he has done wrong.
* This term can be used figuratively to mean "cancel," as in the expression "forgive a debt."
* When people confess their sins, God forgives them based on Jesus' sacrificial death on the cross.
* Jesus taught his disciples to forgive others as he has forgiven them.

The term "pardon" means to forgive and not punish someone for his sin. 

* This word has the same meaning as "forgive" but may also include the meaning of a formal decision to not punish someone who is guilty.
* In a court of law, a judge can pardon a person found guilty of a crime.
* Even though we are guilty of sin, Jesus Christ pardoned us from being punished in hell, based on his sacrificial death on the cross.

### Translation Suggestions:

* Depending on the context, "forgive" could be translated as "pardon" or "cancel" or "release" or "not hold against" (someone).
* The term "forgiveness" could be translated by a word or phrase that means "practice of not resenting" or "declaring (someone) as not guilty" or "the act of pardoning."
* If the language has a word for a formal decision to forgive, that word could be used to translate "pardon."

(See also: [guilt](#guilt))

### Bible References:

* [Genesis 50:15-17](https://git.door43.org/Door43/en_tn/src/master/gen/50/15.md)
* [Numbers 14:17-19](https://git.door43.org/Door43/en_tn/src/master/num/14/17.md)
* [Deuteronomy 29:20-21](https://git.door43.org/Door43/en_tn/src/master/deu/29/20.md)
* [Joshua 24:19-20](https://git.door43.org/Door43/en_tn/src/master/jos/24/19.md)
* [2 Kings 05:17-19](https://git.door43.org/Door43/en_tn/src/master/2ki/05/17.md)
* [Psalms 025:10-11](https://git.door43.org/Door43/en_tn/src/master/psa/025/010.md)
* [Psalms 025:17-19](https://git.door43.org/Door43/en_tn/src/master/psa/025/017.md)
* [Isaiah 55:6-7](https://git.door43.org/Door43/en_tn/src/master/isa/55/06.md)
* [Isaiah 40:1-2](https://git.door43.org/Door43/en_tn/src/master/isa/40/01.md)
* [Luke 05:20-21](https://git.door43.org/Door43/en_tn/src/master/luk/05/20.md)
* [Acts 08:20-23](https://git.door43.org/Door43/en_tn/src/master/act/08/20.md)
* [Ephesians 04:31-32](https://git.door43.org/Door43/en_tn/src/master/eph/04/31.md)
* [Colossians 03:12-14](https://git.door43.org/Door43/en_tn/src/master/col/03/12.md)
* [1 John 02:12-14](https://git.door43.org/Door43/en_tn/src/master/1jn/02/12.md)

### Examples from the Bible stories:

* __[07:10](https://git.door43.org/Door43/en_tn/src/master/obs/07/10.md)__ But Esau had already __forgiven__  Jacob, and they were happy to see each other again.
* __[13:15](https://git.door43.org/Door43/en_tn/src/master/obs/13/15.md)__ Then Moses climbed the mountain again and prayed that God would __forgive__  the people. God listened to Moses and __forgave__  them.
* __[17:13](https://git.door43.org/Door43/en_tn/src/master/obs/17/13.md)__ David repented of his sin and God __forgave__  him.
* __[21:05](https://git.door43.org/Door43/en_tn/src/master/obs/21/05.md)__ In the New Covenant, God would write his law on the people's hearts, the people would know God personally, they would be his people, and God would __forgive__  their sins.
* __[29:01](https://git.door43.org/Door43/en_tn/src/master/obs/29/01.md)__ One day Peter asked Jesus, "Master, how many times should I __forgive__  my brother when he sins against me?"
* __[29:08](https://git.door43.org/Door43/en_tn/src/master/obs/29/08.md)__ I __forgave__  your debt because you begged me.
* __[38:05](https://git.door43.org/Door43/en_tn/src/master/obs/38/05.md)__ Then Jesus took a cup and said, "Drink this. It is my blood of the New Covenant that is poured out for the __forgiveness__  of sins.


### Word Data:

* H5546, H5547, H3722, H5375, H5545, H5547, H7521, G859, G863, G5483


## <a id="tw-term-kt-forsaken"/>forsake, forsakes, forsaken, forsook

### Definition:

The term "forsake" means to abandon someone or to give up something. Someone who has been "forsaken" has been deserted or abandoned by someone else.

* When people "forsake" God, they are being unfaithful to him by disobeying him.
* When God "forsakes" people, he has stopped helping them and allowed them to experience suffering in order to cause them to turn back to him. 
* This term can also mean to forsake things, such as forsaking, or not following, God's teachings.
* The term "forsaken" can be used in the past tense, as in "he has forsaken you" or as in referring to someone who has "been forsaken."

### Translation Suggestions:

* Other ways to translate this term could include "abandon" or "neglect" or "give up" or "go away from" or "leave behind," depending on the context.
* To "forsake" God's law could be translated "disobey God's law." This could also be translated as "abandon" or "give up on" or "stop obeying" his teachings or his laws.
* The phrase "be forsaken" can be translated as "be abandoned" or "be deserted."
* It more clearer to use different words to translate this term, depending on whether the text describes forsaking a thing or a person.

### Bible References:

* [1 Kings 06:11-13](https://git.door43.org/Door43/en_tn/src/master/1ki/06/11.md)
* [Daniel 11:29-30](https://git.door43.org/Door43/en_tn/src/master/dan/11/29.md)
* [Genesis 24:26-27](https://git.door43.org/Door43/en_tn/src/master/gen/24/26.md)
* [Joshua 24:16-18](https://git.door43.org/Door43/en_tn/src/master/jos/24/16.md)
* [Matthew 27:45-47](https://git.door43.org/Door43/en_tn/src/master/mat/27/45.md)
* [Proverbs 27:9-10](https://git.door43.org/Door43/en_tn/src/master/pro/27/09.md)
* [Psalms 071:17-18](https://git.door43.org/Door43/en_tn/src/master/psa/071/017.md)


### Word Data:

* Strong's: H488, H2308, H5203, H5428, H5800, H5805, H7503, G646, G657, G863, G1459, G2641,


## <a id="tw-term-kt-fulfill"/>fulfill, fulfilled

### Definition:

The term "fulfill" means to complete or accomplish something that was expected.

* When a prophecy is fulfilled, it means that God causes to happen what was predicted in the prophecy.
* If a person fulfills a promise or a vow, it means that he does what he has promised to do.
* To fulfill a responsibility means to do the task that was assigned or required.

### Translation Suggestions:

* Depending on the context, "fulfill" could be translated as "accomplish" or "complete" or "cause to happen" or "obey" or "perform."
* The phrase "has been fulfilled" could also be translated as "has come true" or "has happened" or "has taken place."
* Ways to translate "fulfill," as in "fulfill your ministry," could include "complete" or "perform" or "practice" or "serve other people as God has called you to do."

(See also: [prophet](#prophet), [Christ](#christ), [minister](#minister), [call](#call))

### Bible References:

* [1 Kings 02:26-27](https://git.door43.org/Door43/en_tn/src/master/1ki/02/26.md)
* [Acts 03:17-18](https://git.door43.org/Door43/en_tn/src/master/act/03/17.md)
* [Leviticus 22:17-19](https://git.door43.org/Door43/en_tn/src/master/lev/22/17.md)
* [Luke 04:20-22](https://git.door43.org/Door43/en_tn/src/master/luk/04/20.md)
* [Matthew 01:22-23](https://git.door43.org/Door43/en_tn/src/master/mat/01/22.md)
* [Matthew 05:17-18](https://git.door43.org/Door43/en_tn/src/master/mat/05/17.md)
* [Psalms 116:12-15](https://git.door43.org/Door43/en_tn/src/master/psa/116/012.md)

### Examples from the Bible stories:

* __[24:04](https://git.door43.org/Door43/en_tn/src/master/obs/24/04.md)__ John __fulfilled__  what the prophets said, "See I send my messenger ahead of you, who will prepare your way."
* __[40:03](https://git.door43.org/Door43/en_tn/src/master/obs/40/03.md)__ The soldiers gambled for Jesus' clothing. When they did this, they __fulfilled__  a prophecy that said, "They divided my garments among them, and gambled for my clothing."
* __[42:07](https://git.door43.org/Door43/en_tn/src/master/obs/42/07.md)__ Jesus said, "I told you that everything written about me in God's word must be __fulfilled__."
* __[43:05](https://git.door43.org/Door43/en_tn/src/master/obs/43/05.md)__ "This __fulfills__  the prophecy made by the prophet Joel in which God said, 'In the last days, I will pour out my Spirit.'"
* __[43:07](https://git.door43.org/Door43/en_tn/src/master/obs/43/07.md)__ "This __fulfills__  the prophecy which says, 'You will not let your Holy One rot in the grave.'"
* __[44:05](https://git.door43.org/Door43/en_tn/src/master/obs/44/05.md)__ "Although you did not understand what you were doing, God used your actions to __fulfill__  the prophecies that the Messiah would suffer and die."


### Word Data:

* Strong's: H1214, H5487, G1096, G4138


## <a id="tw-term-kt-gentile"/>Gentile, Gentiles

### Facts:

The term "Gentile" refers to anyone who is not a Jew. Gentiles are people who are not descendants of Jacob.

* In the Bible, the term "uncircumcised" is also used figuratively to refer to Gentiles because many of them did not circumcise their male children as the Israelites did.
* Because God chose the Jews to be his special people, they thought of the Gentiles as outsiders who could never be God's people.
* The Jews were also called "Israelites" or "Hebrews" at different times in history. They referred to anyone else as a "Gentile."
* Gentile could also be translated as "not a Jew" or "non-Jewish" or "not an Israelite" (Old Testament) or "non-Jew.".
* Traditionally, Jews would neither eat with nor associate with Gentiles, which at first caused problems within the early church.

(See also: [Israel](#israel), [Jacob](names.html#jacob), [Jew](#jew))

### Bible References:

* [Acts 09:13-16](https://git.door43.org/Door43/en_tn/src/master/act/09/13.md)
* [Acts 14:5-7](https://git.door43.org/Door43/en_tn/src/master/act/14/05.md)
* [Galatians 02:15-16](https://git.door43.org/Door43/en_tn/src/master/gal/02/15.md)
* [Luke 02:30-32](https://git.door43.org/Door43/en_tn/src/master/luk/02/30.md)
* [Matthew 05:46-48](https://git.door43.org/Door43/en_tn/src/master/mat/05/46.md)
* [Matthew 06:5-7](https://git.door43.org/Door43/en_tn/src/master/mat/06/05.md)
* [Romans 11:25](https://git.door43.org/Door43/en_tn/src/master/rom/11/25.md)


### Word Data:

* Strong's: H1471, G1482, G1484, G1672

## <a id="tw-term-kt-gift"/>gift, gifts

### Definition:

The term "gift" refers to anything that is given or offered to someone. A gift is given without the expectation of getting anything in return

* Money, food, clothing, or other things given to poor people are called "gifts."
* In the Bible, an offering or sacrifice given to God is also called a gift.
* The gift of salvation is something God gives us through faith in Jesus.
* In the New Testament, the term "gifts" is also used to refer to special spiritual abilities that God gives to all Christians for serving other people.

### Translation Suggestions:

* The general term for "gift" could be translated with a word or phrase that means "something that is given."
* In the context of someone having a gift or special ability that comes from God, the term "gift from the Spirit" could be translated as "spiritual ability" or "special ability from the Holy Spirit" or "special spiritual skill that God gave."

(See also: [spirit](#spirit), [Holy Spirit](#holyspirit))

### Bible References:

* [1 Corinthians 12:1-3](https://git.door43.org/Door43/en_tn/src/master/1co/12/01.md)
* [2 Samuel 11:6-8](https://git.door43.org/Door43/en_tn/src/master/2sa/11/06.md)
* [Acts 08:20-23](https://git.door43.org/Door43/en_tn/src/master/act/08/20.md)
* [Acts 10:3-6](https://git.door43.org/Door43/en_tn/src/master/act/10/03.md)
* [Acts 11:17-18](https://git.door43.org/Door43/en_tn/src/master/act/11/17.md)
* [Acts 24:17-19](https://git.door43.org/Door43/en_tn/src/master/act/24/17.md)
* [James 01:17-18](https://git.door43.org/Door43/en_tn/src/master/jas/01/17.md)
* [John 04:9-10](https://git.door43.org/Door43/en_tn/src/master/jhn/04/09.md)
* [Matthew 05:23-24](https://git.door43.org/Door43/en_tn/src/master/mat/05/23.md)
* [Matthew 08:4](https://git.door43.org/Door43/en_tn/src/master/mat/08/04.md)


### Word Data:

* Strong's: H814, H4503, H4864, H4976, H4978, H4979, H4991, H5078, H5083, H5379, H7810, H8641, G334, G1390, G1394, G1431, G1434, G1435, G3311, G5486


## <a id="tw-term-kt-glory"/>glory, glorious, glorify, glorifies

### Definition:

In general, the term "glory" means honor, splendor, and extreme greatness. Anything that has glory is said to be "glorious."

* Sometimes "glory" refers to something of great value and importance. In other contexts it communicates splendor, brightness, or judgment.
* For example, the expression "glory of the shepherds" refers to the lush pastures where their sheep had plenty of grass to eat.
* Glory is especially used to describe God, who is more glorious than anyone or anything in the universe. Everything in his character reveals his glory and his splendor.
* The expression to "glory in" means to boast about or take pride in something.

The term "glorify" means to show or tell how great and important something or someone is. It literally means to "give glory to."

* People can glorify God by telling about the wonderful things he has done.
* They can also glorify God by living in a way that honors him and shows how great and magnificent he is.
* When the Bible says that God glorifies himself, it means that he reveals to people his amazing greatness, often through miracles.
* God the Father will glorify God the Son by revealing to people the Son's perfection, splendor, and greatness.
* Everyone who believes in Christ will be glorified with him. When they are raised to life, they will be changed to reflect his glory and to display his grace to all creation.

### Translation Suggestions:

* Depending on the context, different ways to translate "glory" could include "splendor" or "brightness" or "majesty" or "awesome greatness" or "extreme value."
* The term "glorious" could be translated as  "full of glory" or "extremely valuable" or "brightly shining" or "awesomely majestic."
* The expression "give glory to God" could be translated as "honor God's greatness" or "praise God because of his splendor" or "tell others how great God is."
* The expression "glory in" could also be translated as "praise" or "take pride in" or "boast about" or "take pleasure in."

* "Glorify" could also be translated as "give glory to" or "bring glory to" or "cause to appear great."
* The phrase "glorify God" could also be translated as "praise God" or "talk about God's greatness" or "show how great God is" or "honor God (by obeying him)."
* The term "be glorified" could also be translated as, "be shown to be very great" or "be praised" or "be exalted."

(See also: [exalt](#exalt), [obey](other.html#obey), [praise](other.html#praise))

### Bible References:

* [Exodus 24:16-18](https://git.door43.org/Door43/en_tn/src/master/exo/24/16.md)
* [Numbers 14:9-10](https://git.door43.org/Door43/en_tn/src/master/num/14/09.md)
* [Isaiah 35:1-2](https://git.door43.org/Door43/en_tn/src/master/isa/35/01.md)
* [Luke 18:42-43](https://git.door43.org/Door43/en_tn/src/master/luk/18/42.md)
* [Luke 02:8-9](https://git.door43.org/Door43/en_tn/src/master/luk/02/08.md)
* [John 12:27-29](https://git.door43.org/Door43/en_tn/src/master/jhn/12/27.md)
* [Acts 03:13-14](https://git.door43.org/Door43/en_tn/src/master/act/03/13.md)
* [Acts 07:1-3](https://git.door43.org/Door43/en_tn/src/master/act/07/01.md)
* [Romans 08:16-17](https://git.door43.org/Door43/en_tn/src/master/rom/08/16.md)
* [1 Corinthians 06:19-20](https://git.door43.org/Door43/en_tn/src/master/1co/06/19.md)
* [Philippians 02:14-16](https://git.door43.org/Door43/en_tn/src/master/php/02/14.md)
* [Philippians 04:18-20](https://git.door43.org/Door43/en_tn/src/master/php/04/18.md)
* [Colossians 03:1-4](https://git.door43.org/Door43/en_tn/src/master/col/03/01.md)
* [1 Thessalonians 02:5-6](https://git.door43.org/Door43/en_tn/src/master/1th/02/05.md)
* [James 02:1-4](https://git.door43.org/Door43/en_tn/src/master/jas/02/01.md)
* [1 Peter 04:15-16](https://git.door43.org/Door43/en_tn/src/master/1pe/04/15.md)
* [Revelation 15:3-4](https://git.door43.org/Door43/en_tn/src/master/rev/15/03.md)

### Examples from the Bible stories:

* __[23:07](https://git.door43.org/Door43/en_tn/src/master/obs/23/07.md)__ Suddenly, the skies were filled with angels praising God, saying, "__Glory__  to God in heaven and peace on earth to the people he favors!"
* __[25:06](https://git.door43.org/Door43/en_tn/src/master/obs/25/06.md)__ Then Satan showed Jesus all the kingdoms of the world and all their __glory__  and said, "I will give you all this if you bow down and worship me."
* __[37:01](https://git.door43.org/Door43/en_tn/src/master/obs/37/01.md)__ When Jesus heard this news, he said, "This sickness will not end in death, but it is for the __glory__  of God."
* __[37:08](https://git.door43.org/Door43/en_tn/src/master/obs/37/08.md)__ Jesus responded, "Did I not tell you that you would see God's __glory__  if you believe in me?"

### Word Data:

* Strong's: H117, H142, H155, H215, H1342, H1921, H1922, H1925, H1926, H1935, H1984, H2892, H3367, H3513, H3519, H3520, H6286, H6643, H7623, H8597, G1391, G1392, G1740, G1741, G2620, G2744, G2745, G2746, G2755, G2811, G4888


## <a id="tw-term-kt-god"/>God

### Facts:

In the Bible, the term "God" refers to the eternal being who created the universe out of nothing. God exists as Father, Son, and Holy Spirit. God's personal name is "Yahweh."

* God has always existed; he existed before anything else existed, and he will continue to exist forever.
* He is the only true God and has authority over everything in the universe.
* God is perfectly righteous, infinitely wise, holy, sinless, just, merciful, and loving.
* He is a covenant-keeping God, who always fulfills his promises.
* People were created to worship God and he is the only one they should worship.
* God revealed his name as "Yahweh," which means "he is" or "I am" or "the One who (always) exists."
* The Bible also teaches about false "gods," which are nonliving idols that people wrongly worship.

### Translation Suggestions:

* Ways to translate "God" could include "Deity" or "Creator" or "Supreme Being."
* Other ways to translate "God" could be "Supreme Creator" or "Infinite Sovereign Lord" or "Eternal Supreme Being."
* Consider how God is referred to in a local or national language. There may also already be a word for "God" in the language being translated. If so, it is important to make sure that this word fits the characteristics of the one true God as described above.
* Many languages capitalize the first letter of the word for the one true God, to distinguish it from the word for a false god. 
* Another way to make this distinction would be to use different terms for "God" and "god."
* The phrase "I will be their God and they will be my people" could also be translated as "I, God, will rule over these people and they will worship me."

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [create](other.html#creation), [false god](#falsegod), [God the Father](#godthefather), [Holy Spirit](#holyspirit), [false god](#falsegod), [Son of God](#sonofgod), [Yahweh](#yahweh))

### Bible References:

* [1 John 01:5-7](https://git.door43.org/Door43/en_tn/src/master/1jn/01/05.md)
* [1 Samuel 10:7-8](https://git.door43.org/Door43/en_tn/src/master/1sa/10/07.md)
* [1 Timothy 04:9-10](https://git.door43.org/Door43/en_tn/src/master/1ti/04/09.md)
* [Colossians 01:15-17](https://git.door43.org/Door43/en_tn/src/master/col/01/15.md)
* [Deuteronomy 29:14-16](https://git.door43.org/Door43/en_tn/src/master/deu/29/14.md)
* [Ezra 03:1-2](https://git.door43.org/Door43/en_tn/src/master/ezr/03/01.md)
* [Genesis 01:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/01/01.md)
* [Hosea 04:11-12](https://git.door43.org/Door43/en_tn/src/master/hos/04/11.md)
* [Isaiah 36:6-7](https://git.door43.org/Door43/en_tn/src/master/isa/36/06.md)
* [James 02:18-20](https://git.door43.org/Door43/en_tn/src/master/jas/02/18.md)
* [Jeremiah 05:4-6](https://git.door43.org/Door43/en_tn/src/master/jer/05/04.md)
* [John 01:1-3](https://git.door43.org/Door43/en_tn/src/master/jhn/01/01.md)
* [Joshua 03:9-11](https://git.door43.org/Door43/en_tn/src/master/jos/03/09.md)
* [Lamentations 03:40-43](https://git.door43.org/Door43/en_tn/src/master/lam/03/40.md)
* [Micah 04:4-5](https://git.door43.org/Door43/en_tn/src/master/mic/04/04.md)
* [Philippians 02:5-8](https://git.door43.org/Door43/en_tn/src/master/php/02/05.md)
* [Proverbs 24:11-12](https://git.door43.org/Door43/en_tn/src/master/pro/24/11.md)
* [Psalms 047:8-9](https://git.door43.org/Door43/en_tn/src/master/psa/047/008.md)

### Examples from the Bible stories:

* __[01:01](https://git.door43.org/Door43/en_tn/src/master/obs/01/01.md)__ __God__  created the universe and everything in it in six days.
* __[01:15](https://git.door43.org/Door43/en_tn/src/master/obs/01/15.md)__ __God__  made man and woman in his own image.
* __[05:03](https://git.door43.org/Door43/en_tn/src/master/obs/05/03.md)__ "I am __God__  Almighty. I will make a covenant with you."
* __[09:14](https://git.door43.org/Door43/en_tn/src/master/obs/09/14.md)__ __God__  said, "I AM WHO I AM. Tell them, 'I AM has sent me to you.' Also tell them, 'I am Yahweh, the __God__  of your ancestors Abraham, Isaac, and Jacob. This is my name forever.'"
* __[10:02](https://git.door43.org/Door43/en_tn/src/master/obs/10/02.md)__ Through these plagues, __God__  showed Pharaoh that he is more powerful than Pharaoh and all of Egypt's gods.
* __[16:01](https://git.door43.org/Door43/en_tn/src/master/obs/16/01.md)__ The Israelites began to worship the Canaanite gods instead of Yahweh, the true __God__.
* __[22:07](https://git.door43.org/Door43/en_tn/src/master/obs/22/07.md)__ You, my son, will be called the prophet of the __Most High God__  who will prepare the people to receive the Messiah!"
* __[24:09](https://git.door43.org/Door43/en_tn/src/master/obs/24/09.md)__ There is only one __God__. But John heard __God__  the Father speak, and saw Jesus the Son and the Holy Spirit when he baptized Jesus.
* __[25:07](https://git.door43.org/Door43/en_tn/src/master/obs/25/07.md)__ "Worship only the Lord your __God__  and only serve him."
* __[28:01](https://git.door43.org/Door43/en_tn/src/master/obs/28/01.md)__ "There is only one who is good, and that is __God__."
* __[49:09](https://git.door43.org/Door43/en_tn/src/master/obs/49/09.md)__ But __God__  loved everyone in the world so much that he gave his only Son so that whoever believes in Jesus will not be punished for his sins, but will live with __God__  forever.
* __[50:16](https://git.door43.org/Door43/en_tn/src/master/obs/50/16.md)__ But some day __God__  will create a new heaven and a new earth that will be perfect.

### Word Data:

* Strong's: H136, H305, H410, H426, H430, H433, H2486, H2623, H3068, H3069, H3863, H4136, H6697, G112, G516, G932, G935, G1096, G1140, G2098, G2124, G2128, G2150, G2152, G2153, G2299, G2304, G2305, G2312, G2313, G2314, G2315, G2316, G2317, G2318, G2319, G2320, G3361, G3785, G4151, G5207, G5377, G5463, G5537, G5538


## <a id="tw-term-kt-godly"/>godly, godliness, ungodly, godless, ungodliness, godlessness

### Definition:

The term "godly" is used to describe a person who acts in a way that honors God and shows what God is like. "Godliness" is the character quality of honoring God by doing his will.

* A person who has godly character will show the fruits of the Holy Spirit, such as love, joy, peace, patience, kindness, and self control.
* The quality of godliness shows that a person has the Holy Spirit and is obeying him.

The terms "ungodly" and "godless" describe people who are in rebellion against God. Living in an evil way, without thought of God, is called "ungodliness" or "godlessness."

* The meanings of these words are very similar. However, "godless" and "godlessness" may describe a more extreme condition in which people or nations do not even acknowledge God or his right to rule them.
* God pronounces judgment and wrath on ungodly people, on everyone who rejects him and his ways.

### Translation Suggestions:

* The phrase "the godly" could be translated as "godly people" or "people who obey God." (See: [nominaladj](https://git.door43.org/Door43/en_man/src/master/translate/figs-nominaladj/01.md))
* The adjective "godly" could be translated as "obedient to God" or "righteous" or "pleasing to God." 
* The phrase "in a godly manner" could be translated as "in a way that obeys God" or "with actions and words that please God."
* Ways to translate "godliness" could include "acting in a way that pleases God" or "obeying God" or "living in a righteous manner."

* Depending on the context, the term "ungodly" could be translated as "displeasing to God" or "immoral" or "disobeying God."
* The terms "godless" and "godlessness" literally mean that the people are "without God" or "having no thought of God" or "acting in a way that does not acknowledge God."
* Other ways to translate "ungodliness" or "godlessness" could be "wickedness" or "evil" or "rebellion against God".

(See also [evil](#evil), [honor](#honor), [obey](other.html#obey), [righteous](#righteous), [righteous](#righteous))

### Bible References:

* [Job 27:8-10](https://git.door43.org/Door43/en_tn/src/master/job/27/08.md)
* [Proverbs 11:9-11](https://git.door43.org/Door43/en_tn/src/master/pro/11/09.md)
* [Acts 03:11-12](https://git.door43.org/Door43/en_tn/src/master/act/03/11.md)
* [1 Timothy 01:9-11](https://git.door43.org/Door43/en_tn/src/master/1ti/01/09.md)
* [1 Timothy 04:6-8](https://git.door43.org/Door43/en_tn/src/master/1ti/04/06.md)
* [2 Timothy 03:10-13](https://git.door43.org/Door43/en_tn/src/master/2ti/03/10.md)
* [Hebrews 12:14-17](https://git.door43.org/Door43/en_tn/src/master/heb/12/14.md)
* [Hebrews 11:7](https://git.door43.org/Door43/en_tn/src/master/heb/11/07.md)
* [1 Peter 04:17-19](https://git.door43.org/Door43/en_tn/src/master/1pe/04/17.md)
* [Jude 01:14-16](https://git.door43.org/Door43/en_tn/src/master/jud/01/14.md)

### Word Data:

* Strong's: H430, H1100, H2623, H5760, H7563, G516, G763, G764, G765, G2124, G2150, G2152, G2153, G2316, G2317


## <a id="tw-term-kt-godthefather"/>God the Father, heavenly Father, Father

### Facts:

The terms "God the Father" and "heavenly Father" refer to Yahweh, the one true God. Another term with the same meaning is "Father," used most often when Jesus was referring to him.

* God exists as God the Father, God the Son, and God the Holy Spirit. Each one is fully God, and yet they are only one God. This is a mystery that mere humans cannot fully understand.
* God the Father sent God the Son (Jesus) into the world and he sends the Holy Spirit to his people.
* Anyone who believes in God the Son becomes a child of God the Father, and God the Holy Spirit comes to live in that person. This is another mystery that human beings cannot fully understand.

### Translation Suggestions:

* In translating the phrase "God the Father," it is best to translate "Father" with the same word that the language naturally uses to refer to a human father.
* The term "heavenly Father" could be translated by "Father who lives in heaven" or "Father God who lives in heaven" or "God our Father from heaven."
* Usually "Father" is capitalized when it, refers to God.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [ancestor](other.html#father), [God](#god), [heaven](#heaven), [Holy Spirit](#holyspirit), [Jesus](#jesus), [Son of God](#sonofgod))

### Bible References:

* [1 Corinthians 08:4-6](https://git.door43.org/Door43/en_tn/src/master/1co/08/04.md)
* [1 John 02:1-3](https://git.door43.org/Door43/en_tn/src/master/1jn/02/01.md)
* [1 John 02:22-23](https://git.door43.org/Door43/en_tn/src/master/1jn/02/22.md)
* [1 John 03:1-3](https://git.door43.org/Door43/en_tn/src/master/1jn/03/01.md)
* [Colossians 01:1-3](https://git.door43.org/Door43/en_tn/src/master/col/01/01.md)
* [Ephesians 05:18-21](https://git.door43.org/Door43/en_tn/src/master/eph/05/18.md)
* [Luke 10:22](https://git.door43.org/Door43/en_tn/src/master/luk/10/22.md)
* [Matthew 05:15-16](https://git.door43.org/Door43/en_tn/src/master/mat/05/15.md)
* [Matthew 23:8-10](https://git.door43.org/Door43/en_tn/src/master/mat/23/08.md)

### Examples from the Bible stories:

* __[24:09](https://git.door43.org/Door43/en_tn/src/master/obs/24/09.md)__ There is only one God. But John heard __God the Father__  speak, and saw Jesus the Son and the Holy Spirit when he baptized Jesus.
* __[29:09](https://git.door43.org/Door43/en_tn/src/master/obs/29/09.md)__ Then Jesus said, "This is what my __heavenly Father__  will do to every one of you if you do not forgive your brother from your heart."
* __[37:09](https://git.door43.org/Door43/en_tn/src/master/obs/37/09.md)__ Then Jesus looked up to heaven and said, "__Father__, thank you for hearing me."
* __[40:07](https://git.door43.org/Door43/en_tn/src/master/obs/40/07.md)__ Then Jesus cried out, "It is finished! __Father__, I give my spirit into your hands."
* __[42:10](https://git.door43.org/Door43/en_tn/src/master/obs/42/10.md)__ "So go, make disciples of all people groups by baptizing them in the name of __the Father__, the Son, and the Holy Spirit and by teaching them to obey everything I have commanded you."
* __[43:08](https://git.door43.org/Door43/en_tn/src/master/obs/43/08.md)__ "Jesus is now exalted to the right hand of __God the Father__."
* __[50:10](https://git.door43.org/Door43/en_tn/src/master/obs/50/10.md)__ "Then the righteous ones will shine like the sun in the kingdom of __God their Father__."


### Word Data:

* Strong's: H1, H2, G3962


## <a id="tw-term-kt-good"/>good, goodness

### Definition:

The word "good" has different meanings depending on the context. Many languages will use different words to translate these different meanings.

* In general, something is good if it fits with God's character, purposes, and will.
* Something that is "good" could be pleasing, excellent, helpful, suitable, profitable, or morally right.
* Land that is "good" could be called "fertile" or "productive."
* A "good" crop could be a "plentiful" crop.
* A person can be "good" at what they do if they are skillful at their task or profession, as in, the expression, "a good farmer."
* In the Bible, the general meaning of "good" is often contrasted with "evil."
* The term "goodness" usually refers to being morally good or righteous in thoughts and actions.
* The goodness of God refers to how he blesses people by giving them good and beneficial things. It also can refer to his moral perfection.

### Translation Suggestions:

* The general term for "good" in the target language should be used wherever this general meaning is accurate and natural, especially in contexts where it is contrasted to evil.
* Depending on the context, other ways to translate this term could include "kind" or "excellent" or "pleasing to God" or "righteous" or "morally upright" or "profitable."
* "Good land" could be translated as "fertile land" or "productive land"; a "good crop" could be translated as a "plentiful harvest" or "large amount of crops."
* The phrase "do good to" means to do something that benefits others and could be translated as "be kind to" or "help" or "benefit" someone.
* To "do good on the Sabbath" means to "do things that help others on the Sabbath."
* Depending on the context, ways to translate the term "goodness" could include "blessing" or "kindness" or "moral perfection" or "righteousness" or "purity."

(See also: [evil](#evil), [holy](#holy), [profit](other.html#profit), [righteous](#righteous))

### Bible References:

* [Galatians 05:22-24](https://git.door43.org/Door43/en_tn/src/master/gal/05/22.md)
* [Genesis 01:11-13](https://git.door43.org/Door43/en_tn/src/master/gen/01/11.md)
* [Genesis 02:9-10](https://git.door43.org/Door43/en_tn/src/master/gen/02/09.md)
* [Genesis 02:15-17](https://git.door43.org/Door43/en_tn/src/master/gen/02/15.md)
* [James 03:13-14](https://git.door43.org/Door43/en_tn/src/master/jas/03/13.md)
* [Romans 02:3-4](https://git.door43.org/Door43/en_tn/src/master/rom/02/03.md)

### Examples from the Bible stories:

* __[01:04](https://git.door43.org/Door43/en_tn/src/master/obs/01/04.md)__ God saw that what he had created was __good__.
* __[01:11](https://git.door43.org/Door43/en_tn/src/master/obs/01/11.md)__ God plantedâ€¦the tree of the knowledge of __good__  and evil."
* __[01:12](https://git.door43.org/Door43/en_tn/src/master/obs/01/12.md)__ Then God said, "It is not __good__  for man to be alone."
* __[02:04](https://git.door43.org/Door43/en_tn/src/master/obs/02/04.md)__ "God just knows that as soon as you eat it, you will be like God and will understand __good__  and evil like he does."
* __[08:12](https://git.door43.org/Door43/en_tn/src/master/obs/08/12.md)__ "You tried to do evil when you sold me as a slave, but God used the evil for __good__!"
* __[14:15](https://git.door43.org/Door43/en_tn/src/master/obs/14/15.md)__ Joshua was a __good__  leader because he tTable of Contentsrusted and obeyed God.
* __[18:13](https://git.door43.org/Door43/en_tn/src/master/obs/18/13.md)__ Some of these kings were __good__  men who ruled justly and worshiped God.
* __[28:01](https://git.door43.org/Door43/en_tn/src/master/obs/28/01.md)__ "__Good__  teacher, what must I do to have eternal life?" Jesus said to him, "Why do you call me '__good__?' There is only one who is __good__, and that is God."

### Word Data:

* Strong's: H117, H145, H155, H202, H239, H410, H1580, H1926, H1935, H2532, H2617, H2623, H2869, H2895, H2896, H2898, H3190, H3191, H3276, H3474, H3788, H3966, H4261, H4399, H5232, H5750, H6287, H6643, H6743, H7075, H7368, H7399, H7443, H7999, H8231, H8232, H8233, H8389, H8458, G14, G15, G18, G19, G515, G744, G865, G979, G1380, G2095, G2097, G2106, G2107, G2108, G2109, G2114, G2115, G2133, G2140, G2162, G2163, G2174, G2293, G2565, G2567, G2570, G2573, G2887, G2986, G3140, G3617, G3776, G4147, G4632, G4674, G4851, G5223, G5224, G5358, G5542, G5543, G5544


## <a id="tw-term-kt-goodnews"/>good news, gospel

### Definition:

The term "gospel" literally means "good news" and refers to a message or announcement that tells people something that benefits them and makes them glad.

* In the Bible, this term usually refers to the message about God's salvation for people through Jesus' sacrifice on the cross.
* In most English Bibles, "good news" is usually translated as "gospel" and is also used in phrases such as, the "gospel of Jesus Christ," the "gospel of God" and the "gospel of the kingdom."

### Translation Suggestions:

* Different ways to translate this term could include, "good message" or "good announcement" or "God's message of salvation" or "the good things God teaches about Jesus."
* Depending on the context, ways to translate the phrase, "good news of" could include, "good news/message about" or "good message from" or "the good things God tells us about" or "what God says about how he saves people."

(See also: [kingdom](other.html#kingdom), [sacrifice](other.html#sacrifice), [save](#save))

### Bible References:

* [1 Thessalonians 01:4-5](https://git.door43.org/Door43/en_tn/src/master/1th/01/04.md)
* [Acts 08:25](https://git.door43.org/Door43/en_tn/src/master/act/08/25.md)
* [Colossians 01:21-23](https://git.door43.org/Door43/en_tn/src/master/col/01/21.md)
* [Galatians 01:6-7](https://git.door43.org/Door43/en_tn/src/master/gal/01/06.md)
* [Luke 08:1-3](https://git.door43.org/Door43/en_tn/src/master/luk/08/01.md)
* [Mark 01:14-15](https://git.door43.org/Door43/en_tn/src/master/mrk/01/14.md)
* [Philippians 02:22-24](https://git.door43.org/Door43/en_tn/src/master/php/02/22.md)
* [Romans 01:1-3](https://git.door43.org/Door43/en_tn/src/master/rom/01/01.md)

### Examples from the Bible stories:

* __[23:06](https://git.door43.org/Door43/en_tn/src/master/obs/23/06.md)__ The angel said, "Do not be afraid, because I have some __good news__  for you. The Messiah, the Master, has been born in Bethlehem!"
* __[26:03](https://git.door43.org/Door43/en_tn/src/master/obs/26/03.md)__ Jesus read, "God has given me his Spirit so that I can proclaim __good news__  to the poor, freedom to captives, recovery of sight for the blind, and release to the oppressed. This is the year of the Lord's favor."
* __[45:10](https://git.door43.org/Door43/en_tn/src/master/obs/45/10.md)__ Philip also used other Scriptures to tell him the __good news of Jesus__.
* __[46:10](https://git.door43.org/Door43/en_tn/src/master/obs/46/10.md)__ Then they sent them off to preach the __good news about Jesus__  in many other places.
* __[47:01](https://git.door43.org/Door43/en_tn/src/master/obs/47/01.md)__ One day, Paul and his friend Silas went to the town of Philippi to proclaim the __good news about Jesus__.
* __[47:13](https://git.door43.org/Door43/en_tn/src/master/obs/47/13.md)__ The __good news about Jesus__  kept spreading, and the Church kept growing.
* __[50:01](https://git.door43.org/Door43/en_tn/src/master/obs/50/01.md)__ For almost 2,000 years, more and more people around the world have been hearing the __good news about Jesus__  the Messiah.
* __[50:02](https://git.door43.org/Door43/en_tn/src/master/obs/50/02.md)__ When Jesus was living on earth he said, "My disciples will preach the __good news__  about the kingdom of God to people everywhere in the world, and then the end will come."
* __[50:03](https://git.door43.org/Door43/en_tn/src/master/obs/50/03.md)__ Before he returned to heaven, Jesus told Christians to proclaim the __good news__  to people who have never heard it.

### Word Data:

* Strong's: G2097, G2098, G4283


## <a id="tw-term-kt-grace"/>grace, gracious

### Definition:

The word "grace" refers to help or blessing that is given to someone who has not earned it. The term "gracious" describes someone who shows grace to others.

* God's grace toward sinful human beings is a gift that is freely given.
* The concept of grace also refers to being kind and forgiving to someone who has done wrong or hurtful things.
* The expression to "find grace" is an expression that means to receive help and mercy from God. Often it includes the meaning that God is pleased with someone and helps him.

### Translation Suggestions:

* Other ways that "grace" could be translated include "divine kindness" or "God's favor" or "God's kindness and forgiveness for sinners" or "merciful kindness."
* The term "gracious" could be translated as "full of grace" or "kind" or "merciful" or "mercifully kind."
* The expression "he found grace in the eyes of God" could be translated as "he received mercy from God" or "God mercifully helped him" or "God showed his favor to him" or "God was pleased with him and helped him."

### Bible References:

* [Acts 04:32-33](https://git.door43.org/Door43/en_tn/src/master/act/04/32.md)
* [Acts 06:8-9](https://git.door43.org/Door43/en_tn/src/master/act/06/08.md)
* [Acts 14:3-4](https://git.door43.org/Door43/en_tn/src/master/act/14/03.md)
* [Colossians 04:5-6](https://git.door43.org/Door43/en_tn/src/master/col/04/05.md)
* [Colossians 04:18](https://git.door43.org/Door43/en_tn/src/master/col/04/18.md)
* [Genesis 43:28-29](https://git.door43.org/Door43/en_tn/src/master/gen/43/28.md)
* [James 04:6-7](https://git.door43.org/Door43/en_tn/src/master/jas/04/06.md)
* [John 01:16-18](https://git.door43.org/Door43/en_tn/src/master/jhn/01/16.md)
* [Philippians 04:21-23](https://git.door43.org/Door43/en_tn/src/master/php/04/21.md)
* [Revelation 22:20-21](https://git.door43.org/Door43/en_tn/src/master/rev/22/20.md)

### Word Data:

* Strong's: H2580, H2587, H2589, H2603, H8467, G2143, G5485, G5543


## <a id="tw-term-kt-guilt"/>guilt, guilty

### Definition:

The term "guilt" refers to the fact of having sinned or committed a crime.

* To "be guilty" means to have done something morally wrong, that is, to have disobeyed God.
* The opposite of "guilty" is "innocent."

### Translation Suggestions:

* Some languages might translate "guilt" as "the weight of sin" or "the counting of sins."
* Ways to translate to "be guilty" could include a word or phrase that means, to "be at fault" or "having done something morally wrong" or "having committed a sin."

(See also: [innocent](#innocent), [iniquity](#iniquity), [punish](other.html#punish), [sin](#sin))

### Bible References:

* [Exodus 28:36-38](https://git.door43.org/Door43/en_tn/src/master/exo/28/36.md)
* [Isaiah 06:6-7](https://git.door43.org/Door43/en_tn/src/master/isa/06/06.md)
* [James 02:10-11](https://git.door43.org/Door43/en_tn/src/master/jas/02/10.md)
* [John 19:4-6](https://git.door43.org/Door43/en_tn/src/master/jhn/19/04.md)
* [Jonah 01:14-16](https://git.door43.org/Door43/en_tn/src/master/jon/01/14.md)

### Examples from the Bible stories:

* __[39:02](https://git.door43.org/Door43/en_tn/src/master/obs/39/02.md)__ They brought many witnesses who lied about him (Jesus). However, their statements did not agree with each other, so the Jewish leaders could not prove he was __guilty__  of anything.
* __[39:11](https://git.door43.org/Door43/en_tn/src/master/obs/39/11.md)__ After speaking with Jesus, Pilate went out to the crowd and said, "I find no __guilt__  in this man." But the Jewish leaders and the crowd shouted, "Crucify him!" Pilate replied, "He is not __guilty__." But they shouted even louder. Then Pilate said a third time, "He is not __guilty__!"
* __[40:04](https://git.door43.org/Door43/en_tn/src/master/obs/40/04.md)__ Jesus was crucified between two robbers. One of them mocked Jesus, but the other said, "Don't you fear God? We are __guilty__, but this man is innocent.
* __[49:10](https://git.door43.org/Door43/en_tn/src/master/obs/49/10.md)__ Because of your sin, you are __guilty__  and deserve to die.

### Word Data:

* Strong's: H816, H817, H818, H5352, H5355, G338, G1777, G3784, G5267


## <a id="tw-term-kt-hades"/>Hades, Sheol

### Definition:

The terms "Hades" and "Sheol" are used in the Bible to refer to death and the place where the souls of people go when they die. Their meanings are similar.

* The Hebrew term "Sheol" is often used in the Old Testament to refer generally to the place of death. 
* In the New Testament, the Greek term "Hades" refers to a place for the souls of people who rebelled against God. These souls are referred to as going "down" to Hades. This is sometimes contrasted to going "up" to heaven, where the souls of people who believe in Jesus live.
* The term "Hades" is coupled with the term "death" in the book of Revelation. In the end times, both death and Hades will be thrown into the Lake of Fire, which is hell.

### Translation Suggestions

* The Old Testament term "Sheol" could be translated as "place of the dead" or "place for dead souls." Some translations translate this as "the pit" or "death," depending on the context.
* The New Testament term "Hades" could also be translated as "place for unbelieving dead souls" or "place of torment for the dead" or "place for the souls of unbelieving dead people." 
* Some translations keep the words "Sheol" and "Hades," spelling them to fit the sound patterns of the language of translation. (See: [How to Translate Unknowns](https://git.door43.org/Door43/en_man/src/master/translate/translate-unknown/01.md)).
* A phrase could also be added to each term to explain it, examples of doing this are, "Sheol, place where dead people are" and "Hades, place of death."

(Translation suggestions: [How to Translate Unknowns](https://git.door43.org/Door43/en_man/src/master/translate/translate-unknown/01.md))

(See also: [death](other.html#death), [heaven](#heaven), [hell](#hell), [tomb](other.html#tomb))

### Bible References:

* [Acts 02:29-31](https://git.door43.org/Door43/en_tn/src/master/act/02/29.md)
* [Genesis 44:27-29](https://git.door43.org/Door43/en_tn/src/master/gen/44/27.md)
* [Jonah 02:1-2](https://git.door43.org/Door43/en_tn/src/master/jon/02/01.md)
* [Luke 10:13-15](https://git.door43.org/Door43/en_tn/src/master/luk/10/13.md)
* [Luke 16:22-23](https://git.door43.org/Door43/en_tn/src/master/luk/16/22.md)
* [Matthew 11:23-24](https://git.door43.org/Door43/en_tn/src/master/mat/11/23.md)
* [Matthew 16:17-18](https://git.door43.org/Door43/en_tn/src/master/mat/16/17.md)
* [Revelation 01:17-18](https://git.door43.org/Door43/en_tn/src/master/rev/01/17.md)

### Word Data:

* Strong's: H7585, G86


## <a id="tw-term-kt-heart"/>heart, hearts

### Definition:

In the Bible, the term "heart" is often used figuratively to refer to a person's thoughts, emotions, desires, or will.

* To have a "hard heart" is a common expression that means a person stubbornly refuses to obey God.
* The expressions "with all my heart" or "with my whole heart" mean to do something with no holding back, with complete commitment and willingness.
* The expression "take it to heart" means to treat something seriously and apply it to one's life.
* The term "brokenhearted" describes a person who is very sad. That person has been deeply hurt emotionally.

### Translation Suggestions

* Some languages use a different body part such as "stomach" or "liver" to refer to these ideas.
* Other languages may use one word to express some of these concepts and another word to express others.
* If "heart" or other body part does not have this meaning, some languages may need to express this literally with terms such as "thoughts" or "emotions" or "desires."
* Depending on the context, "with all my heart" or "with my whole heart" could be translated as "with all my energy" or "with complete dedication" or "completely" or "with total commitment."
* The expression "take it to heart" could be translated as "treat it seriously" or "carefully think about it."
* The expression "hard-hearted" could also be translated as "stubbornly rebellious" or "refusing to obey" or "continually disobeying God."
* Ways to translate "brokenhearted" could include "very sad" or "feeling deeply hurt."

(See also: [hard](other.html#hard))

### Bible References:

* [1 John 03:16-18](https://git.door43.org/Door43/en_tn/src/master/1jn/03/16.md)
* [1 Thessalonians 02:3-4](https://git.door43.org/Door43/en_tn/src/master/1th/02/03.md)
* [2 Thessalonians 03:13-15](https://git.door43.org/Door43/en_tn/src/master/2th/03/13.md)
* [Acts 08:20-23](https://git.door43.org/Door43/en_tn/src/master/act/08/20.md)
* [Acts 15:7-9](https://git.door43.org/Door43/en_tn/src/master/act/15/07.md)
* [Luke 08:14-15](https://git.door43.org/Door43/en_tn/src/master/luk/08/14.md)
* [Mark 02:5-7](https://git.door43.org/Door43/en_tn/src/master/mrk/02/05.md)
* [Matthew 05:5-8](https://git.door43.org/Door43/en_tn/src/master/mat/05/05.md)
* [Matthew 22:37-38](https://git.door43.org/Door43/en_tn/src/master/mat/22/37.md)


### Word Data:

* Strong's: H1079, H2436, H2504, H2910, H3519, H3629, H3820, H3821, H3823, H3824, H3825, H3826, H4578, H5315, H5640, H7130, H7307, H7356, H7907, G674, G1282, G1271, G2133, G2588, G2589, G4641, G4698, G5590



## <a id="tw-term-kt-heaven"/>heaven, sky, skies, heavens, heavenly

### Definition:

The term that is translated as "heaven" usually refers to where God lives. The same word can also mean "sky," depending on the context.

* The term "heavens" refers to everything we see above the earth, including the sun, moon, and stars. It also includes the heavenly bodies, such as far-off planets, that we can't directly see from the earth.
* The term "sky" refers to the blue expanse above the earth that has clouds and the air we breathe. Often the sun and moon are also said to be "up in the sky."
* In some contexts in the Bible, the word "heaven" could refer to either the sky or the place where God lives.
* When "heaven" is used figuratively, it is a way of referring to God. For example, when Matthew writes about the "kingdom of heaven" he is referring to the kingdom of God.

### Translation Suggestions:

* When "heaven" is used figuratively, it could be translated as "God."
* For "kingdom of heaven" in the book of Matthew, it is best to keep the word "heaven" since this is distinctive to Matthew's gospel.
* The terms "heavens" or "heavenly bodies" could also be translated as, "sun, moon, and stars" or "all the stars in the universe."
* The phrase, "stars of heaven" could be translated as "stars in the sky" or "stars in the galaxy" or "stars in the universe."

(See also: [kingdom of God](#kingdomofgod))

### Bible References:

* [1 Kings 08:22-24](https://git.door43.org/Door43/en_tn/src/master/1ki/08/22.md)
* [1 Thessalonians 01:8-10](https://git.door43.org/Door43/en_tn/src/master/1th/01/08.md)
* [1 Thessalonians 04:16-18](https://git.door43.org/Door43/en_tn/src/master/1th/04/16.md)
* [Deuteronomy 09:1-2](https://git.door43.org/Door43/en_tn/src/master/deu/09/01.md)
* [Ephesians 06:9](https://git.door43.org/Door43/en_tn/src/master/eph/06/09.md)
* [Genesis 01:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/01/01.md)
* [Genesis 07:11-12](https://git.door43.org/Door43/en_tn/src/master/gen/07/11.md)
* [John 03:12-13](https://git.door43.org/Door43/en_tn/src/master/jhn/03/12.md)
* [John 03:27-28](https://git.door43.org/Door43/en_tn/src/master/jhn/03/27.md)
* [Matthew 05:17-18](https://git.door43.org/Door43/en_tn/src/master/mat/05/17.md)
* [Matthew 05:46-48](https://git.door43.org/Door43/en_tn/src/master/mat/05/46.md)

### Examples from the Bible stories:

* __[04:02](https://git.door43.org/Door43/en_tn/src/master/obs/04/02.md)__ They even began building a tall tower to reach __heaven__.
* __[14:11](https://git.door43.org/Door43/en_tn/src/master/obs/14/11.md)__ He (God) gave them bread from __heaven__, called "manna."
* __[23:07](https://git.door43.org/Door43/en_tn/src/master/obs/23/07.md)__ Suddenly, the skies were filled with angels praising God, saying, "Glory to God in __heaven__  and peace on earth to the people he favors!"
* __[29:09](https://git.door43.org/Door43/en_tn/src/master/obs/29/09.md)__ Then Jesus said, "This is what my __heavenly__  Father will do to every one of you if you do not forgive your brother from your heart."
* __[37:09](https://git.door43.org/Door43/en_tn/src/master/obs/37/09.md)__ Then Jesus looked up to __heaven__  and said, "Father, thank you for hearing me."
* __[42:11](https://git.door43.org/Door43/en_tn/src/master/obs/42/11.md)__ Then Jesus went up to __heaven__, and a cloud hid him from their sight.


### Word Data:

* Strong's: H1534, H6160, H6183, H7834, H8064, H8065, G932, G2032, G3321, G3770, G3771, G3772


## <a id="tw-term-kt-hebrew"/>Hebrew, Hebrews

### Facts:

The "Hebrews" were people who were descended from Abraham through the line of Isaac and Jacob. Abraham is the first person in the Bible to be called a "Hebrew."

* The term "Hebrew" also refers to the language that the Hebrew people spoke. The vast majority of the Old Testament was written in the Hebrew language.
* In different places in the Bible, the Hebrews were also called "Jewish people" or "Israelites." It is best to keep all three terms distinct in the text, as long as it is clear that these terms refer to the same people group.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Israel](#israel), [Jew](#jew), [Jewish leaders](other.html#jewishleaders))

### Bible References:

* [Acts 26:12-14](https://git.door43.org/Door43/en_tn/src/master/act/26/12.md)
* [Genesis 39:13-15](https://git.door43.org/Door43/en_tn/src/master/gen/39/13.md)
* [Genesis 40:14-15](https://git.door43.org/Door43/en_tn/src/master/gen/40/14.md)
* [Genesis 41:12-13](https://git.door43.org/Door43/en_tn/src/master/gen/41/12.md)
* [John 05:1-4](https://git.door43.org/Door43/en_tn/src/master/jhn/05/01.md)
* [John 19:12-13](https://git.door43.org/Door43/en_tn/src/master/jhn/19/12.md)
* [Jonah 01:8-10](https://git.door43.org/Door43/en_tn/src/master/jon/01/08.md)
* [Philippians 03:4-5](https://git.door43.org/Door43/en_tn/src/master/php/03/04.md)


### Word Data:

* Strong's: H5680, G1444, G1445, G1446, G1447

## <a id="tw-term-kt-hell"/>hell, lake of fire

### Definition:

Hell is the final place of unending pain and suffering where God will punish everyone who rebels against him and rejects his plan of saving them through Jesus' sacrifice. It is also referred to as the "lake of fire."

 * Hell is described as a place of fire and severe suffering.
 * Satan and the evil spirits who follow him will be thrown into hell for eternal punishment.
 * People who do not believe in Jesus' sacrifice for their sin and do not trust in him to save them, will be punished forever in hell.
   

### Translation Suggestions:

* These terms should probably be translated differently since they occur in different contexts.
* Some languages cannot use "lake" in the phrase "lake of fire" because it refers to water.
* The term "hell" could be translated as "place of suffering" or "final place of darkness and pain."
* The term "lake of fire" could also be translated as, "sea of fire" or "huge fire (of suffering)" or "field of fire."

(See also: [heaven](#heaven), [death](other.html#death), [Hades](#hades), [abyss](other.html#abyss))

### Bible References:

* [James 03:5-6](https://git.door43.org/Door43/en_tn/src/master/jas/03/05.md)
* [Luke 12:4-5](https://git.door43.org/Door43/en_tn/src/master/luk/12/04.md)
* [Mark 09:42-44](https://git.door43.org/Door43/en_tn/src/master/mrk/09/42.md)
* [Matthew 05:21-22](https://git.door43.org/Door43/en_tn/src/master/mat/05/21.md)
* [Matthew 05:29-30](https://git.door43.org/Door43/en_tn/src/master/mat/05/29.md)
* [Matthew 10:28-31](https://git.door43.org/Door43/en_tn/src/master/mat/10/28.md)
* [Matthew 23:32-33](https://git.door43.org/Door43/en_tn/src/master/mat/23/32.md)
* [Matthew 25:41-43](https://git.door43.org/Door43/en_tn/src/master/mat/25/41.md)
* [Revelation 20:13-15](https://git.door43.org/Door43/en_tn/src/master/rev/20/13.md)

### Examples from the Bible stories:

 * __[50:14](https://git.door43.org/Door43/en_tn/src/master/obs/50/14.md)__ He (God) will throw them into __hell__, where they will weep and grind their teeth in anguish forever. A fire that never goes out will continually burn them, and worms will never stop eating them.
 * __[50:15](https://git.door43.org/Door43/en_tn/src/master/obs/50/15.md)__ He will throw Satan into __hell__ where he will burn forever, along with everyone who chose to follow him rather than to obey God.

### Word Data:

* Strong's: H7585, G86, G439, G440, G1067, G3041, G4442, G4443, G4447, G4448, G5020, G5394, G5457


## <a id="tw-term-kt-highpriest"/>high priest

### Definition:

The term "high priest" refers to a special priest who was appointed to serve for one year as the leader of all the other Israelite priests. 

* The high priest had special responsibilities. He was the only one who was permitted to go into the most holy part of the temple to offer a special sacrifice once a year.
* The Israelites had many priests, but only one high priest at a time.
* When Jesus was being arrested, Caiaphas was the official high priest. Caiphas' father-in-law Annas is also mentioned sometimes because he was a former high priest who probably still had power and authority over the people.

### Translation Suggestions:

* "High priest" could be translated as "supreme priest" or "highest ranking priest."
* Make sure this term is translated differently from the term "chief priest."

(See also: [Annas](names.html#annas), [Caiaphas](names.html#caiaphas), [chief priests](other.html#chiefpriests), [priest](#priest), [temple](#temple))

### Bible References:

* [Acts 05:26-28](https://git.door43.org/Door43/en_tn/src/master/act/05/26.md)
* [Acts 07:1-3](https://git.door43.org/Door43/en_tn/src/master/act/07/01.md)
* [Acts 09:1-2](https://git.door43.org/Door43/en_tn/src/master/act/09/01.md)
* [Exodus 30:10](https://git.door43.org/Door43/en_tn/src/master/exo/30/10.md)
* [Hebrews 06:19-20](https://git.door43.org/Door43/en_tn/src/master/heb/06/19.md)
* [Leviticus 16:32-33](https://git.door43.org/Door43/en_tn/src/master/lev/16/32.md)
* [Luke 03:1-2](https://git.door43.org/Door43/en_tn/src/master/luk/03/01.md)
* [Mark 02:25-26](https://git.door43.org/Door43/en_tn/src/master/mrk/02/25.md)
* [Matthew 26:3-5](https://git.door43.org/Door43/en_tn/src/master/mat/26/03.md)
* [Matthew 26:51-54](https://git.door43.org/Door43/en_tn/src/master/mat/26/51.md)

### Examples from the Bible stories:

* __[13:08](https://git.door43.org/Door43/en_tn/src/master/obs/13/08.md)__ No one could enter the room behind the curtain except the __high priest__, because God lived there.
* __[21:07](https://git.door43.org/Door43/en_tn/src/master/obs/21/07.md)__ The Messiah who would come would be the perfect __high priest__  who would offer himself as a perfect sacrifice to God.
* __[38:03](https://git.door43.org/Door43/en_tn/src/master/obs/38/03.md)__ The Jewish leaders, led by the __high priest__, paid Judas thirty silver coins to betray Jesus.
* __[39:01](https://git.door43.org/Door43/en_tn/src/master/obs/39/01.md)__ The soldiers led Jesus to the house of the __high priest__  in order for the __high priest__  to question him.
* __[39:03](https://git.door43.org/Door43/en_tn/src/master/obs/39/03.md)__ Finally, the __high priest__  looked directly at Jesus and said, "Tell us, are you the Messiah, the Son of the living God?"
* __[44:07](https://git.door43.org/Door43/en_tn/src/master/obs/44/07.md)__ The next day, the Jewish leaders brought Peter and John to the __high priest__  and the other religious leaders.
* __[45:02](https://git.door43.org/Door43/en_tn/src/master/obs/45/02.md)__ So the religious leaders arrested Stephen and brought him to the __high priest__  and the other leaders of the Jews, where more false witnesses lied about Stephen.
* __[46:01](https://git.door43.org/Door43/en_tn/src/master/obs/46/01.md)__ The __high priest__  gave Saul permission to go to the city of Damascus to arrest Christians there and bring them back to Jerusalem.
* __[48:06](https://git.door43.org/Door43/en_tn/src/master/obs/48/06.md)__ Jesus is the Great __High Priest__. Unlike other priests, he offered himself as the only sacrifice that could to take away the sin of all the people in the world. Jesus was the perfect __high priest__  because he took the punishment for every sin that anyone has ever committed.

### Word Data:

* Strong's: H7218, H1419, H3548, G748, G749


## <a id="tw-term-kt-holy"/>holy, holiness, unholy, sacred

### Definition:

The terms "holy" and "holiness" refer to the character of God that is totally set apart and separated from everything that is sinful and imperfect.

* Only God is absolutely holy. He makes people and things holy.
* A person who is holy belongs to God and has been set apart for the purpose of serving God and bringing him glory.
* An object that God has declared to be holy is one that he has set apart for his glory and use, such as an altar that is for the purpose of offering sacrifices to him.
* People cannot approach him unless he allows them to, because he is holy and they are merely human beings, sinful and imperfect.
* In the Old Testament, God set apart the priests as holy for special service to him. They had to be ceremonially cleansed from sin in order to approach God.
* God also set apart as holy certain places and things that belonged to him or in which he revealed himself, such as  his temple.

Literally, the term "unholy" means "not holy." It describes someone or something that does not honor God.

* This word is used to describe someone who dishonors God by rebelling against him.
* A thing that is called "unholy" could be described as being common, profane or unclean. It does not belong to God.

The term "sacred" describes something that relates to worshiping God or to the pagan worship of false gods.

* In the Old Testament, the term "sacred" was oftensed to describe the stone pillars and other objects used in the worship of false gods. This could also be translated as "religious."
* "Sacred songs" and "sacred music" refer to music that was sung or played for God's glory. This could be translated as "music for worshiping Yahweh" or "songs that praise God."
* The phrase "sacred duties" referred to the "religious duties" or "rituals" that a priest performed to lead people in worshiping God. It could also refer to the rituals performed by a pagan priest to worship a false god

### Translation Suggestions:

* Ways to translate "holy" might include "set apart for God" or "belonging to God" or "completely pure" or "perfectly sinless" or "separated from sin."
* To "make holy" is often translated as "sanctify" in English. It could also be translated as "set apart (someone) for God's glory."

* Ways to translate "unholy" could include "not holy" or "not belonging to God" or "not honoring to God" or "not godly."
* In some contexts, "unholy" could be translated as "unclean."

(See also: [Holy Spirit](#holyspirit), [consecrate](#consecrate), [sanctify](#sanctify), [set apart](#setapart))

### Bible References:

* [Genesis 28:20-22](https://git.door43.org/Door43/en_tn/src/master/gen/28/20.md)
* [2 Kings 03:1-3](https://git.door43.org/Door43/en_tn/src/master/2ki/03/01.md)
* [Lamentations 04:1-2](https://git.door43.org/Door43/en_tn/src/master/lam/04/01.md)
* [Ezekiel 20:18-20](https://git.door43.org/Door43/en_tn/src/master/ezk/20/18.md)
* [Matthew 07:6](https://git.door43.org/Door43/en_tn/src/master/mat/07/06.md)
* [Mark 08:38](https://git.door43.org/Door43/en_tn/src/master/mrk/08/38.md)
* [Acts 07:33-34](https://git.door43.org/Door43/en_tn/src/master/act/07/33.md)
* [Acts 11:7-10](https://git.door43.org/Door43/en_tn/src/master/act/11/07.md)
* [Romans 01:1-3](https://git.door43.org/Door43/en_tn/src/master/rom/01/01.md)
* [2 Corinthians 12:3-5](https://git.door43.org/Door43/en_tn/src/master/2co/12/03.md)
* [Colossians 01:21-23](https://git.door43.org/Door43/en_tn/src/master/col/01/21.md)
* [1 Thessalonians 03:11-13](https://git.door43.org/Door43/en_tn/src/master/1th/03/11.md)
* [1 Thessalonians 04:7-8](https://git.door43.org/Door43/en_tn/src/master/1th/04/07.md)
* [2 Timothy 03:14-15](https://git.door43.org/Door43/en_tn/src/master/2ti/03/14.md)

### Examples from the Bible stories:

* __[01:16](https://git.door43.org/Door43/en_tn/src/master/obs/01/16.md)__ He (God) blessed the seventh day and made it __holy__, because on this day he rested from his work.
* __[09:12](https://git.door43.org/Door43/en_tn/src/master/obs/09/12.md)__ "You are standing on __holy__  ground."
* __[13:01](https://git.door43.org/Door43/en_tn/src/master/obs/13/01.md)__ "If you will obey me and keep my covenant, you will be my prized possession, a kingdom of priests, and a __holy__  nation."
* __[13:05](https://git.door43.org/Door43/en_tn/src/master/obs/13/05.md)__ "Always be sure to keep the Sabbath day __holy__."
* __[22:05](https://git.door43.org/Door43/en_tn/src/master/obs/22/05.md)__ "So the baby will be __holy__, the Son of God."
* __[50:02](https://git.door43.org/Door43/en_tn/src/master/obs/50/02.md)__ As we wait for Jesus to return, God wants us to live in a way that is __holy__  and that honors him.

### Word Data:

* Strong's: H430, H2455, H2623, H4676, H4720, H6918, H6922, H6942, H6944, H6948, G37, G38, G39, G40, G41, G42, G462, G1859, G2150, G2412, G2413, G2839, G3741, G3742


## <a id="tw-term-kt-holyone"/>Holy One

### Definition:

The term "Holy One" is a title in the Bible that almost always refers to God.

* In the Old Testament, this title often occurs in the phrase "Holy One of Israel."
* In the New Testament, Jesus is also referred to as the "Holy One."
* The term "holy one" is sometimes used in the Bible to refer to an angel.

### Translation Suggestions:

* The literal term is "the Holy" (with "One" being implied.) Many languages (like English) will translate this with the implied noun included (such as "One" or "God").
* This term could also be translated as "God, who is holy" or "the Set Apart One."
* The phrase "the Holy One of Israel" could be translated as "the Holy God whom Israel worships" or "the Holy One who rules Israel."
* It is best to translate this term using the same word or phrase that is used to translate "holy."

(See also: [holy](#holy), [God](#god))

### Bible References:

* [1 John 02:20-21](https://git.door43.org/Door43/en_tn/src/master/1jn/02/20.md)
* [2 Kings 19:20-22](https://git.door43.org/Door43/en_tn/src/master/2ki/19/20.md)
* [Acts 02:27-28](https://git.door43.org/Door43/en_tn/src/master/act/02/27.md)
* [Acts 03:13-14](https://git.door43.org/Door43/en_tn/src/master/act/03/13.md)
* [Isaiah 05:15-17](https://git.door43.org/Door43/en_tn/src/master/isa/05/15.md)
* [Isaiah 41:14-15](https://git.door43.org/Door43/en_tn/src/master/isa/41/14.md)
* [Luke 04:33-34](https://git.door43.org/Door43/en_tn/src/master/luk/04/33.md)

### Word Data:

* Strong's: H2623, H376, H6918, G40, G3741


## <a id="tw-term-kt-holyplace"/>holy place

### Definition:

In the Bible, the terms "the holy place" and "the most holy place" refer to the two parts of the tabernacle or temple building.

* The "holy place" was the first room, and it contained the altar of incense and the table with the special "bread of the presence" on it.
* The "most holy place" was the second, innermost room, and it contained the ark of the covenant.
* A thick, heavy curtain separated the outer room from the inner room.
* The high priest was the only one who was permitted to go into the most holy place.
* Sometimes "holy place" refers to both the building and courtyard areas of either the temple or tabernacle. It could also refer generally to any place that is set apart for God.

### Translation Suggestions:

* The term "holy place" could also be translated as "room set apart for God" or "special room for meeting God" or "place reserved for God."
* The term "most holy place" could be translated as "room that is the most set apart for God" or "most special room for meeting God."
* Depending on the context, ways to translate the general expression "a holy place" could include "a consecrated place" or "a place that God has set apart" or "a place in the temple complex, which is holy" or "a courtyard of God's holy temple."

(See also: [altar of incense](other.html#altarofincense), [ark of the covenant](#arkofthecovenant), [bread](other.html#bread), [consecrate](#consecrate), [courtyard](other.html#courtyard), [curtain](other.html#curtain), [holy](#holy), [set apart](#setapart), [tabernacle](#tabernacle), [temple](#temple))

### Bible References:

* [1 Kings 06:16-18](https://git.door43.org/Door43/en_tn/src/master/1ki/06/16.md)
* [Acts 06:12-15](https://git.door43.org/Door43/en_tn/src/master/act/06/12.md)
* [Exodus 26:31-33](https://git.door43.org/Door43/en_tn/src/master/exo/26/31.md)
* [Exodus 31:10-11](https://git.door43.org/Door43/en_tn/src/master/exo/31/10.md)
* [Ezekiel 41:1-2](https://git.door43.org/Door43/en_tn/src/master/ezk/41/01.md)
* [Ezra 09:8-9](https://git.door43.org/Door43/en_tn/src/master/ezr/09/08.md)
* [Hebrews 09:1-2](https://git.door43.org/Door43/en_tn/src/master/heb/09/01.md)
* [Leviticus 16:17-19](https://git.door43.org/Door43/en_tn/src/master/lev/16/17.md)
* [Matthew 24:15-18](https://git.door43.org/Door43/en_tn/src/master/mat/24/15.md)
* [Revelation 15:5-6](https://git.door43.org/Door43/en_tn/src/master/rev/15/05.md)


### Word Data:

* Strong's: H1964, H4720, H4725, H5116, H6918, H6944, G39, G40, G3485, G5117


## <a id="tw-term-kt-holyspirit"/>Holy Spirit, Spirit of God, Spirit of the Lord, Spirit

### Facts:

These terms all refer to the Holy Spirit, who is God. The one true God exists eternally as the Father, the Son, and the Holy Spirit.

* The Holy Spirit is also referred to as "the Spirit" and "Spirit of Yahweh" and "Spirit of truth."
* Because the Holy Spirit is God, he is absolutely holy, infinitely pure, and morally perfect in all his nature and in everything he does.
* Along with the Father and the Son, the Holy Spirit was active in creating the world.
* When God's Son, Jesus, returned to heaven, God sent the Holy Spirit to his people to lead them, teach them, comfort them, and enable them to do God's will.
* The Holy Spirit guided Jesus and he guides those who believe in Jesus.

### Translation Suggestions:

* This term could simply be translated with the words used to translate "holy" and "spirit."
* Ways to translate this term could also include "Pure Spirit" or "Spirit who is Holy" or "God the Spirit."

(See also: [holy](#holy), [spirit](#spirit), [God](#god), [Lord](#lord), [God the Father](#godthefather), [Son of God](#sonofgod), [gift](#gift))

### Bible References:

* [1 Samuel 10:9-10](https://git.door43.org/Door43/en_tn/src/master/1sa/10/09.md)
* [1 Thessalonians 04:7-8](https://git.door43.org/Door43/en_tn/src/master/1th/04/07.md)
* [Acts 08:14-17](https://git.door43.org/Door43/en_tn/src/master/act/08/14.md)
* [Galatians 05:25-26](https://git.door43.org/Door43/en_tn/src/master/gal/05/25.md)
* [Genesis 01:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/01/01.md)
* [Isaiah 63:10](https://git.door43.org/Door43/en_tn/src/master/isa/63/10.md)
* [Job 33:4-5](https://git.door43.org/Door43/en_tn/src/master/job/33/04.md)
* [Matthew 12:31-32](https://git.door43.org/Door43/en_tn/src/master/mat/12/31.md)
* [Matthew 28:18-19](https://git.door43.org/Door43/en_tn/src/master/mat/28/18.md)
* [Psalms 051:10-11](https://git.door43.org/Door43/en_tn/src/master/psa/051/010.md)

### Examples from the Bible stories:

* __[01:01](https://git.door43.org/Door43/en_tn/src/master/obs/01/01.md)__ But __God's Spirit__  was there over the water.
* __[24:08](https://git.door43.org/Door43/en_tn/src/master/obs/24/08.md)__ When Jesus came up out of the water after being baptized, __the Spirit of God__  appeared in the form of a dove and came down and rested on him.
* __[26:01](https://git.door43.org/Door43/en_tn/src/master/obs/26/01.md)__ After overcoming Satan's temptations, Jesus returned in the power of __the Holy Spirit__  to the region of Galilee where he lived.
* __[26:03](https://git.door43.org/Door43/en_tn/src/master/obs/26/03.md)__ Jesus read, "God has given me __his Spirit__  so that I can proclaim good news to the poor, freedom to captives, recovery of sight for the blind, and release to the oppressed."
* __[42:10](https://git.door43.org/Door43/en_tn/src/master/obs/42/10.md)__ "So go, make disciples of all people groups by baptizing them in the name of the Father, the Son, and __the Holy Spirit__  and by teaching them to obey everything I have commanded you."
* __[43:03](https://git.door43.org/Door43/en_tn/src/master/obs/43/03.md)__ They were all filled with the __Holy Spirit__  and they began to speak in other languages.
* __[43:08](https://git.door43.org/Door43/en_tn/src/master/obs/43/08.md)__ "And Jesus has sent the __Holy Spirit__  just as he promised he would do. The __Holy Spirit__  is causing the things that you are are now seeing and hearing."
* __[43:11](https://git.door43.org/Door43/en_tn/src/master/obs/43/11.md)__ Peter answered them, "Every one of you should repent and be baptized in the name of Jesus Christ so that God will forgive your sins. Then he will also give you the gift of the __Holy Spirit__."
* __[45:01](https://git.door43.org/Door43/en_tn/src/master/obs/45/01.md)__ He (Stephen) had a good reputation and was full of the __Holy Spirit__  and of wisdom.

### Word Data:

* Strong's: H3068, H6944, H7307, G40, G4151


## <a id="tw-term-kt-honor"/>honor, honors

### Definition:

The terms "honor" and to "honor" refer to giving someone respect, esteem, or reverence.

* Honor is usually given to someone who is of higher status and importance, such as a king or God.
* God instructs Christians to honor others.
* Children are instructed to honor their parents in ways that include respecting them and obeying them.
* The terms "honor" and "glory" are often used together, especially when referring to Jesus. These may be two different ways of referring to the same thing.
* Ways of honoring God include thanking and praising him, and showing him respect by obeying him and living in a way that shows how great he is.

### Translation Suggestions:

* Other ways to translate "honor" could include "respect" or "esteem" or "high regard."
* The term to "honor" could be translated as to "show special respect to" or to "cause to be praised" or to "show high regard for" or to "highly value."
 
(See also: [dishonor](other.html#dishonor), [glory](#glory), [glory](#glory), [praise](other.html#praise))

### Bible References:

* [1 Samuel 02:8](https://git.door43.org/Door43/en_tn/src/master/1sa/02/08.md)
* [Acts 19:15-17](https://git.door43.org/Door43/en_tn/src/master/act/19/15.md)
* [John 04:43-45](https://git.door43.org/Door43/en_tn/src/master/jhn/04/43.md)
* [John 12:25-26](https://git.door43.org/Door43/en_tn/src/master/jhn/12/25.md)
* [Mark 06:4-6](https://git.door43.org/Door43/en_tn/src/master/mrk/06/04.md)
* [Matthew 15:4-6](https://git.door43.org/Door43/en_tn/src/master/mat/15/04.md)


### Word Data:

* Strong's: H1420, H1921, H1922, H1923, H1926, H1927, H1935, H2082, H2142, H3366, H3367, H3368, H3372, H3373, H3374, H3444, H3513, H3519, H3655, H3678, H5081, H5375, H5457, H6213, H6286, H6437, H6942, H6944, H6965, H7236, H7613, H7812, H8597, H8416, G820, G1391, G1392, G1784, G2151, G2570, G3170, G4411, G4586, G5091, G5092, G5093, G5399


## <a id="tw-term-kt-hope"/>hope, hoped, hopes

### Definition:

Hope is strongly desiring something to happen. 
Hope can imply either certainty or uncertainty regarding a future event. 

* In the Bible, the term "hope" also has the meaning of "trust," as in "my hope is in the Lord." It refers to a sure expectation of receiving what God has promised his people. 
* Sometimes the ULB translates the term in the original language as "confidence." This happens mostly in the New Testament in situations where people who believe in Jesus as their Savior have the assurance (or confidence or hope) of receiving what God has promised.
* To have "no hope" means to have no expectation of something good happening. It means that it is actually very certain that it will not happen.

### Translation Suggestions:

* In some contexts, the term to "hope" could also be translated as to "wish" or to "desire" or to "expect."
* The expression "nothing to hope for" could be translated as "nothing to trust in" or "no expectation of anything good"
* To "have no hope" could be translated as "have no expectation of anything good" or "have no security" or "be sure that nothing good will happen."
* The expression "have set your hopes on" could also be translated as "have put your confidence in" or "have been trusting in."
* The phrase "I find hope in your Word" could also be translated as "I am confident that your Word is true" or "Your Word helps me trust in you" or "When I obey your Word, I am certain to be blessed."
* Phrases such as "hope in" God could also be translated a, "trust in God" or "know for sure that God will do what he has promised" or "be certain that God is faithful."

(See also: [bless](#bless), [confidence](other.html#confidence), [good](#good), [obey](other.html#obey), [trust](#trust), [word of God](#wordofgod))

### Bible References:

* [1 Chronicles 29:14-15](https://git.door43.org/Door43/en_tn/src/master/1ch/29/14.md)
* [1 Thessalonians 02:17-20](https://git.door43.org/Door43/en_tn/src/master/1th/02/17.md)
* [Acts 24:14-16](https://git.door43.org/Door43/en_tn/src/master/act/24/14.md)
* [Acts 26:6-8](https://git.door43.org/Door43/en_tn/src/master/act/26/06.md)
* [Acts 27:19-20](https://git.door43.org/Door43/en_tn/src/master/act/27/19.md)
* [Colossians 01:4-6](https://git.door43.org/Door43/en_tn/src/master/col/01/04.md)
* [Job 11:20](https://git.door43.org/Door43/en_tn/src/master/job/11/20.md)

### Word Data:

* Strong's: H982, H983, H986, H2620, H2976, H3175, H3176, H3689, H4009, H4268, H4723, H7663, H7664, H8431, H8615, G91, G560, G1679, G1680, G2070


## <a id="tw-term-kt-houseofgod"/>house of God, Yahweh's house

### Definition:

In the Bible, the phrases "house of God" (God's house) and "house of Yahweh (Yahweh's house) refer to a place where God is worshiped.

* This term is also used more specifically to refer to the tabernacle or the temple.
* Sometimes "God's house" is used to refer to the people of God.

### Translation Suggestions:

* When referring to a place of worship, this term could be translated as "a house for worshiping God" or "a place for worshiping God."
* If it is referring to the temple or tabernacle, this could be translated as "the temple (or tabernacle) where God is worshiped (or "where God is present" or "where God meets with his people.")
* The word "house" may be important to use in the translation in order to communicate that God "dwells" there, that is, his spirit is in that place to meet with his people and to be worshiped by them.

(See also: [people of God](#peopleofgod), [tabernacle](#tabernacle), [temple](#temple))

### Bible References:

* [1 Timothy 03:14-15](https://git.door43.org/Door43/en_tn/src/master/1ti/03/14.md)
* [2 Chronicles 23:8-9](https://git.door43.org/Door43/en_tn/src/master/2ch/23/08.md)
* [Ezra 05:12-13](https://git.door43.org/Door43/en_tn/src/master/ezr/05/12.md)
* [Genesis 28:16-17](https://git.door43.org/Door43/en_tn/src/master/gen/28/16.md)
* [Judges 18:30-31](https://git.door43.org/Door43/en_tn/src/master/jdg/18/30.md)
* [Mark 02:25-26](https://git.door43.org/Door43/en_tn/src/master/mrk/02/25.md)
* [Matthew 12:3-4](https://git.door43.org/Door43/en_tn/src/master/mat/12/03.md)

### Word Data:

* Strong's: H426, H430, H1004, H1005, H3068, G2316, G3624


## <a id="tw-term-kt-humble"/>humble, humbles, humbled, humility

### Definition:

The term "humble" describes a person who does not think of himself as better than others. He is not proud or arrogant. Humility is the quality of being humble.

* To be humble before God means to understand one's weakness and imperfection in comparison with his greatness, wisdom and perfection.
* When a person humbles himself, he puts himself in a position of lower importance.
* Humility is caring about the needs of others more than one's own needs.
* Humility also means serving with a modest attitude when using one's gifts and abilities.
* The phrase "be humble" could be translated as "don't be prideful."
* "Humble yourself before God" could be translated as "Submit your will to God, recognizing his greatness."

(See also: [proud](other.html#proud))

### Bible References:

* [James 01:19-21](https://git.door43.org/Door43/en_tn/src/master/jas/01/19.md)
* [James 03:13-14](https://git.door43.org/Door43/en_tn/src/master/jas/03/13.md)
* [James 04:8-10](https://git.door43.org/Door43/en_tn/src/master/jas/04/08.md)
* [Luke 14:10-11](https://git.door43.org/Door43/en_tn/src/master/luk/14/10.md)
* [Luke 18:13-14](https://git.door43.org/Door43/en_tn/src/master/luk/18/13.md)
* [Matthew 18:4-6](https://git.door43.org/Door43/en_tn/src/master/mat/18/04.md)
* [Matthew 23:11-12](https://git.door43.org/Door43/en_tn/src/master/mat/23/11.md)

### Examples from the Bible stories:

  __*[17:02](https://git.door43.org/Door43/en_tn/src/master/obs/17/02.md)__ David was a __humble__ and righteous man who trusted and obeyed God.
  __*[34:10](https://git.door43.org/Door43/en_tn/src/master/obs/34/10.md)__ "God will __humble__ everyone who is proud, and he will lift up whoever __humbles__ himself."


### Word Data:

* Strong's: H1792, H3665, H6031, H6035, H6038, H6041, H6800, H6819, H7511, H7807, H7812, H8213, H8214, H8215, H8217, H8467, G858, G4236, G4239, G4240, G5011, G5012, G5013, G5391


## <a id="tw-term-kt-hypocrite"/>hypocrite, hypocrites, hypocrisy

### Definition:

The term "hypocrite" refers to a person who does things to appear righteous, but who secretly is acting in evil ways. The term "hypocrisy" refers to the behavior that deceives people into thinking a person is righteous.

* Hypocrites want to be seen doing good things so that people will think that they are good people.
* Often a hypocrite will criticize other people for doing the same sinful things that they themselves do.
* Jesus called the Pharisees hypocrites because although they acted religiously like wearing certain clothes and eating certain foods, they were not kind or fair to people.
* A hypocrite points out faults in other people, but doesn't admit his own faults.

### Translation Suggestions:

* Some languages have an expression like "two-faced" that refers to a hypocrite or a hypocrite's actions.
* Other ways to translate "hypocrite" could include "fraud" or "pretender" or "arrogant, deceitful person."
* The term "hypocrisy" could be translated by, "deception" or "fake actions" or "pretending."

### Bible References:

* [Galatians 02:13-14](https://git.door43.org/Door43/en_tn/src/master/gal/02/13.md)
* [Luke 06:41-42](https://git.door43.org/Door43/en_tn/src/master/luk/06/41.md)
* [Luke 12:54-56](https://git.door43.org/Door43/en_tn/src/master/luk/12/54.md)
* [Luke 13:15-16](https://git.door43.org/Door43/en_tn/src/master/luk/13/15.md)
* [Mark 07:6-7](https://git.door43.org/Door43/en_tn/src/master/mrk/07/06.md)
* [Matthew 06:1-2](https://git.door43.org/Door43/en_tn/src/master/mat/06/01.md)
* [Romans 12:9-10](https://git.door43.org/Door43/en_tn/src/master/rom/12/09.md)


### Word Data:

* Strong's: H120, H2611, H2612, G505, G5272, G5273


## <a id="tw-term-kt-imageofgod"/>image of God, image

### Definition:

The term "image" refers to something that looks like something else or that is like someone in character or essence. The phrase "image of God" is used in different ways, depending on the context.

* At the beginning of time, God created human beings "in his image," that is, "in his likeness." This means that people have certain characteristics that reflect the image of God, such as the ability to feel emotion, the ability to reason and communicate, and a spirit that lives eternally. 
* The Bible teaches that Jesus, God's Son, is "the image of God," that is, he is God himself. Unlike human beings, Jesus was not created. From all eternity God the Son has had all the divine characteristics because he has had the same essence with God the Father.
  
### Translation Suggestions:

* When referring to Jesus, "image of God" could be translated as "exact likeness of God" or "same essence as God" or "same being as God."
* When referring to human beings, "God created them in his image" could be translated with a phrase that means "God created them to be like him" or "God created them with characteristics like his own." 

(See also: [image](other.html#image), [Son of God](#sonofgod), [Son of God](#sonofgod))

### Bible References:

* [2 Corinthians 04:3-4](https://git.door43.org/Door43/en_tn/src/master/2co/04/03.md)
* [Colossians 03:9-11](https://git.door43.org/Door43/en_tn/src/master/col/03/09.md)
* [Genesis 01:26-27](https://git.door43.org/Door43/en_tn/src/master/gen/01/26.md)
* [Genesis 09:5-7](https://git.door43.org/Door43/en_tn/src/master/gen/09/05.md)
* [James 03:9-10](https://git.door43.org/Door43/en_tn/src/master/jas/03/09.md)
* [Romans 08:28-30](https://git.door43.org/Door43/en_tn/src/master/rom/08/28.md)

### Word Data:

* Strong's: H4541, H1544, H2553, H6456, H6459, H6754, H6816, H8403, G504, G179


## <a id="tw-term-kt-inchrist"/>in Christ, in Jesus, in the Lord, in him

### Definition:

The phrase "in Christ" and related terms refer to the state or condition of being in relationship with Jesus Christ through faith in him.

* Other related terms include "in Christ Jesus, in Jesus Christ, in the Lord Jesus, in the Lord Jesus Christ."
* Possible meanings for the term "in Christ" could include "because you belong to Christ" or "through the relationship you have with Christ" or "based on your faith in Christ."
* These related terms all have the same meaning of being in a state of believing in Jesus and being his disciple.
* Note: Sometimes the word "in" belongs with the verb. For example, "share in Christ" means to "share in" the benefits that come from knowing Christ. To "glory in" Christ means to be glad and give praise to God for who Jesus is and what he has done. To "believe in" Christ means to trust him as Savior and know him.

### Translation Suggestions:

* Depending on the context, different ways to translate "in Christ" and "in the Lord" (and related phrases) could include:
   * "who belong to Christ"
   * "because you believe in Christ"
   * "because Christ has saved us"
   * "in service to the Lord"
   * "relying on the Lord"
   * "because of what the Lord has done."
* People who "believe in" Christ or who "have faith in" Christ believe what Jesus taught and are trusting him to save them because of his sacrifice on the cross that paid the penalty for their sins. Some languages may have one word that translates verbs like "believe in" or "share in" or "trust in."

(See also: [Christ](#christ), [Lord](#lord), [Jesus](#jesus), [believe](#believe), [faith](#faith))

### Bible References:

* [1 John 02:4-6](https://git.door43.org/Door43/en_tn/src/master/1jn/02/04.md)
* [2 Corinthians 02:16-17](https://git.door43.org/Door43/en_tn/src/master/2co/02/16.md)
* [2 Timothy 01:1-2](https://git.door43.org/Door43/en_tn/src/master/2ti/01/01.md)
* [Galatians 01:21-24](https://git.door43.org/Door43/en_tn/src/master/gal/01/21.md)
* [Galatians 02:17-19](https://git.door43.org/Door43/en_tn/src/master/gal/02/17.md)
* [Philemon 01:4-7](https://git.door43.org/Door43/en_tn/src/master/phm/01/04.md)
* [Revelation 01:9-11](https://git.door43.org/Door43/en_tn/src/master/rev/01/09.md)
* [Romans 09:1-2](https://git.door43.org/Door43/en_tn/src/master/rom/09/01.md)

### Word Data:

* Strong's: G1519, G2962, G5547


## <a id="tw-term-kt-inherit"/>inherit, inheritance, heritage, heir

### Definition:

The term "inherit" refers to receiving something valuable from a parent or other person because of a special relationship with that person. The "inheritance" is what is received.

* A physical inheritance that is received may be money, land, or other kinds of property.
* A spiritual inheritance is everything that God gives people who trust in Jesus, including blessings in the present life as well as eternal life with him.
* The Bible also calls God's people his inheritance, which means that they belong to him; they are his valued possession.
* God promised Abraham and his descendants that they would inherit the land of Canaan, that it would belong to them forever.
* There is also a figurative or spiritual sense in which people who belong to God are said to "inherit the land." This means that they will prosper and be blessed by God in both physical and spiritual ways.
* In the New Testament, God promises that those who trust in Jesus will "inherit salvation" and "inherit eternal life." It is also expressed as, "inherit the kingdom of God." This is a spiritual inheritance that lasts forever.
* There are other figurative meanings for these terms:
   * The Bible says that wise people will "inherit glory" and righteous people will "inherit good things."
   * To "inherit the promises" means to receive the good things that God has promised to give his people.
   * This term is also used in a negative sense to refer to foolish or disobedient people who "inherit the wind" or "inherit folly." This means they receive the consequences of their sinful actions, including punishment and worthless living.

### Translation Suggestions:

* As always, consider first whether there are already terms in the target language for the concept of an heir or an inheritance, and use those terms.
* Depending on the context, other ways that the term "inherit" could be translated might include "receive" or "possess" or "come into possession of."
* Ways to translate "inheritance" could include "promised gift" or "secure possession."
* When God's people are referred to as his inheritance this could be translated as "valued ones belonging to him."
* The term "heir" could be translated with a word or phrase that means "privileged child who receives the father's possessions" or "person chosen to receive (God's) spiritual possessions or blessings."
* The term "heritage" could be translated as "blessings from God" or "inherited blessings."

(See also: [heir](other.html#heir), [Canaan](names.html#canaan), [Promised Land](#promisedland))

### Bible References:

* [1 Corinthians 06:9-11](https://git.door43.org/Door43/en_tn/src/master/1co/06/09.md)
* [1 Peter 01:3-5](https://git.door43.org/Door43/en_tn/src/master/1pe/01/03.md)
* [2 Samuel 21:2-3](https://git.door43.org/Door43/en_tn/src/master/2sa/21/02.md)
* [Acts 07:4-5](https://git.door43.org/Door43/en_tn/src/master/act/07/04.md)
* [Deuteronomy 20:16-18](https://git.door43.org/Door43/en_tn/src/master/deu/20/16.md)
* [Galatians 05:19-21](https://git.door43.org/Door43/en_tn/src/master/gal/05/19.md)
* [Genesis 15:6-8](https://git.door43.org/Door43/en_tn/src/master/gen/15/06.md)
* [Hebrews 09:13-15](https://git.door43.org/Door43/en_tn/src/master/heb/09/13.md)
* [Jeremiah 02:7-8](https://git.door43.org/Door43/en_tn/src/master/jer/02/07.md)
* [Luke 15:11-12](https://git.door43.org/Door43/en_tn/src/master/luk/15/11.md)
* [Matthew 19:29-30](https://git.door43.org/Door43/en_tn/src/master/mat/19/29.md)
* [Psalm 079:1-3](https://git.door43.org/Door43/en_tn/src/master/psa/079/001.md)

### Examples from the Bible stories:

* __[04:06](https://git.door43.org/Door43/en_tn/src/master/obs/04/06.md)__ When Abram arrived in Canaan God said, "Look all around you. I will give to you and your descendants all the land that you can see as an __inheritance__."
* __[27:01](https://git.door43.org/Door43/en_tn/src/master/obs/27/01.md)__ One day, an expert in the Jewish law came to Jesus to test him, saying, "Teacher, what must I do to __inherit__  eternal life?"
* __[35:03](https://git.door43.org/Door43/en_tn/src/master/obs/35/03.md)__ "There was a man who had two sons. The younger son told his father, 'Father, I want my __inheritance__  now!' So the father divided his property between the two sons."

### Word Data:

* Strong's: H2490, H2506, H3423, H3425, H4181, H5157, H5159, G2816, G2817, G2819, G2820


## <a id="tw-term-kt-iniquity"/>iniquity, iniquities

### Definition:

The term "iniquity" is a word that is very similar in meaning to the term "sin," but may more specifically refer to conscious acts of wrongdoing or great wickedness.

* The word "iniquity" literally means a twisting or distorting (of the law). It refers to major injustice.
* Iniquity could be described as deliberate, harmful actions against other people.
* Other definitions of iniquity include "perversity" and "depravity," which are both words that describe conditions of terrible sin.

### Translation Suggestions:

* The term "iniquity" could be translated as "wickedness" or "perverse actions" or "harmful acts."
* Often, "iniquity" occurs in the same text as the word "sin" and "transgression" so it is important to have different ways of translating these terms.

(See also: [sin](#sin), [transgress](#transgression), [trespass](#trespass))

### Bible References:

* [Daniel 09:12-14](https://git.door43.org/Door43/en_tn/src/master/dan/09/12.md)
* [Exodus 34:5-7](https://git.door43.org/Door43/en_tn/src/master/exo/34/05.md)
* [Genesis 15:14-16](https://git.door43.org/Door43/en_tn/src/master/gen/15/14.md)
* [Genesis 44:16-17](https://git.door43.org/Door43/en_tn/src/master/gen/44/16.md)
* [Habakkuk 02:12-14](https://git.door43.org/Door43/en_tn/src/master/hab/02/12.md)
* [Matthew 13:40-43](https://git.door43.org/Door43/en_tn/src/master/mat/13/40.md)
* [Matthew 23:27-28](https://git.door43.org/Door43/en_tn/src/master/mat/23/27.md)
* [Micah 03:9-11](https://git.door43.org/Door43/en_tn/src/master/mic/03/09.md)


### Word Data:

* Strong's: H205, H1942, H5753, H5758, H5766, H5771, H5932, H5999, H7562, G92, G93, G458, G3892, G4189


## <a id="tw-term-kt-innocent"/>innocent

### Definition:

The term "innocent" means to not be guilty of a crime or other wrongdoing. It can also refer more generally to people who are not involved in evil things.

* A person accused of doing something wrong is innocent if he has not committed that wrong.
* Sometimes the term "innocent" is used to refer to people who have done nothing wrong to deserve the bad treatment they are receiving, as in an enemy army attacking "innocent people."

### Translation Suggestions:

* In most contexts, the term "innocent" can be translated as "not guilty" or "not responsible" or "not to blame" for something.
* When referring in general to innocent people, this term could be translated as "who have done nothing wrong" or "who are not involved in evil."
* The frequently occurring expression "innocent blood" could be translated as "people who did nothing wrong to deserve being killed."
* The expression "shed innocent blood" could be translated as "kill innocent people" or "kill people who did nothing wrong to deserve it."
* In the context of someone being killed, "innocent of the blood of" could be translated as "not guilty for the death of."
* When talking about people not hearing the good news about Jesus but not accepting it, "innocent of the blood of" could be translated as "not responsible for whether they remain spiritually dead or not" or "not responsible for whether they accept this message."
* When Judas said "I have betrayed innocent blood," he was saying "I have betrayed a man who did nothing wrong" or "I have caused the death of a man who was sinless."
* When Pilate said about Jesus "I am innocent of the blood of this innocent man," this could be translated as "I am not responsible for the killing of this man who has done nothing wrong to deserve it."

(See also: [guilt](#guilt))

### Bible References:

* [1 Corinthians 04:3-4](https://git.door43.org/Door43/en_tn/src/master/1co/04/03.md)
* [1 Samuel 19:4-5](https://git.door43.org/Door43/en_tn/src/master/1sa/19/04.md)
* [Acts 20:25-27](https://git.door43.org/Door43/en_tn/src/master/act/20/25.md)
* [Exodus 23:6-9](https://git.door43.org/Door43/en_tn/src/master/exo/23/06.md)
* [Jeremiah 22:17-19](https://git.door43.org/Door43/en_tn/src/master/jer/22/17.md)
* [Job 09:21-24](https://git.door43.org/Door43/en_tn/src/master/job/09/21.md)
* [Romans 16:17-18](https://git.door43.org/Door43/en_tn/src/master/rom/16/17.md)

### Examples from the Bible stories:

* __[08:06](https://git.door43.org/Door43/en_tn/src/master/obs/08/06.md)__ After two years, Joseph was still in prison, even though he was __innocent__.
* __[40:04](https://git.door43.org/Door43/en_tn/src/master/obs/40/04.md)__ One of them mocked Jesus, but the other said, "Do you have no fear of God? We are guilty, but this man is __innocent__."
* __[40:08](https://git.door43.org/Door43/en_tn/src/master/obs/40/08.md)__ When the soldier guarding Jesus saw everything that happened, he said, "Certainly, this man was __innocent__. He was the Son of God."
*

### Word Data:

* Strong's: H2136, H2600, H2643, H5352, H5355, H5356, G121


## <a id="tw-term-kt-intercede"/>intercede, intercededs, intercession

### Definition:

The terms "intercede" and "intercession" refer to making requests to someone on behalf of another person. In the Bible this usually refers to praying for other people.

* The expressions "make intercession for" and "intercede for" mean to make requests to God for the benefit of other people.
* The Bible teaches that the Holy Spirit intercedes for us, that is, he prays to God for us.
* A person intercedes for other people by making requests for them to someone in authority.

### Translation Suggestions:

* Other ways to translate "intercede" could include "plead for" or "urge (someone) to do something (for someone else)."
* The noun "intercessions" could be translated as "appeals" or "requests" or "urgent prayers."
* The phrase "make intercession for" could be translated as "make requests for the benefit of" or "make an appeal on behalf of" or "ask God to help" or "appeal to God to bless (someone)."

(See also: [pray](#pray))

### Bible References:

* [Hebrews 07:25-26](https://git.door43.org/Door43/en_tn/src/master/heb/07/25.md)
* [Isaiah 53:12](https://git.door43.org/Door43/en_tn/src/master/isa/53/12.md)
* [Jeremiah 29:6-7](https://git.door43.org/Door43/en_tn/src/master/jer/29/06.md)
* [Romans 08:26-27](https://git.door43.org/Door43/en_tn/src/master/rom/08/26.md)
* [Romans 08:33-34](https://git.door43.org/Door43/en_tn/src/master/rom/08/33.md)


### Word Data:

* Strong's: H6293, G1783, G1793, G5241


## <a id="tw-term-kt-israel"/>Israel, Israelites

### Facts:

The term "Israel" is the name that God gave to Jacob. It means "he struggles with God."

* The descendants of Jacob became known as the "people of Israel"  or the "nation of Israel" or the "Israelites."
* God formed his covenant with the people of Israel. They were his chosen people.
* The nation of Israel consisted of twelve tribes.
* Soon after King Solomon died, Israel was divided into two kingdoms: the southern kingdom, called "Judah," and the northern kingdom, called "Israel."
* Often the term "Israel" can be translated as "the people of Israel" or "the nation of Israel," depending on the context.

(See also: [Jacob](names.html#jacob), [kingdom of Israel](names.html#kingdomofisrael), [Judah](names.html#kingdomofjudah), [nation](other.html#nation), [twelve tribes of Israel](other.html#12tribesofisrael))

### Bible References:

* [1 Chronicles 10:1-3](https://git.door43.org/Door43/en_tn/src/master/1ch/10/01.md)
* [1 Kings 08:1-2](https://git.door43.org/Door43/en_tn/src/master/1ki/08/01.md)
* [Acts 02:34-36](https://git.door43.org/Door43/en_tn/src/master/act/02/34.md)
* [Acts 07:22-25](https://git.door43.org/Door43/en_tn/src/master/act/07/22.md)
* [Acts 13:23-25](https://git.door43.org/Door43/en_tn/src/master/act/13/23.md)
* [John 01:49-51](https://git.door43.org/Door43/en_tn/src/master/jhn/01/49.md)
* [Luke 24:21](https://git.door43.org/Door43/en_tn/src/master/luk/24/21.md)
* [Mark 12:28-31](https://git.door43.org/Door43/en_tn/src/master/mrk/12/28.md)
* [Matthew 02:4-6](https://git.door43.org/Door43/en_tn/src/master/mat/02/04.md)
* [Matthew 27:9-10](https://git.door43.org/Door43/en_tn/src/master/mat/27/09.md)
* [Philippians 03:4-5](https://git.door43.org/Door43/en_tn/src/master/php/03/04.md)

### Examples from the Bible stories:

  __*[08:15](https://git.door43.org/Door43/en_tn/src/master/obs/08/15.md)__ The descendants of the twelve sons became the twelve tribes of __Israel__.
  __*[09:03](https://git.door43.org/Door43/en_tn/src/master/obs/09/03.md)__ The Egyptians forced the __Israelites__ to build many buildings and even whole cities.
  __*[09:05](https://git.door43.org/Door43/en_tn/src/master/obs/09/05.md)__ A certain __Israelite__ woman gave birth to a baby boy.
  __*[10:01](https://git.door43.org/Door43/en_tn/src/master/obs/10/01.md)__ They said, "This is what the God of __Israel__ says, 'Let my people go!'"
  __*[14:12](https://git.door43.org/Door43/en_tn/src/master/obs/14/12.md)__ But despite all this, the people of __Israel __ complained and grumbled against God and against Moses.
  __*[15:09](https://git.door43.org/Door43/en_tn/src/master/obs/15/09.md)__ God fought for __Israel__ that day. He caused the Amorites to be confused and he sent large hailstones that killed many of the Amorites.
  __*[15:12](https://git.door43.org/Door43/en_tn/src/master/obs/15/12.md)__ After this battle, God gave each tribe of __Israel __ its own section of the Promised Land. Then God gave __Israel__ peace along all its borders.
  __*[16:16](https://git.door43.org/Door43/en_tn/src/master/obs/16/16.md)__ So God punished __Israel __ again for worshiping idols.
  __*[43:06](https://git.door43.org/Door43/en_tn/src/master/obs/43/06.md)__ "Men of __Israel__, Jesus was a man who did many mighty signs and wonders by the power of God, as you have seen and already know."


### Word Data:

* Strong's: H3478, H3479, H3481, H3482, G935, G2474, G2475


## <a id="tw-term-kt-jealous"/>jealous, jealousy

### Definition:

The terms "jealous" and "jealousy" refer to a strong desire to protect the purity of a relationship. They can also refer to a strong desire to keep possession of something or someone.

* These terms are often used to describe the angry feeling that a person has toward a spouse who has been unfaithful in their marriage.
* When used in the Bible, these terms often refer to God's strong desire for his people to remain pure and unstained by sin.
* God is also "jealous" for his name, desiring that it be treated with honor and reverence.
* Another meaning of jealous involves being angry that someone else is successful or more popular. This is close in meaning to the word "envious."

### Translation Suggestions:

* Ways to translate "jealous" could include "strong protective desire" or "possessive desire." 
* The term "jealousy" could be translated as "strong protective feeling" or "possessive feeling."
* When talking about God, make sure the translation of these terms does not give a negative meaning of being resentful of someone else.
* In the context of people's wrong feelings of anger toward toward other people who are more successful, the terms "envious" and "envy" could be used. But these terms should not be used for God.

(See also: [envy](other.html#envy))

### Bible References:

* [2 Corinthians 12:20-21](https://git.door43.org/Door43/en_tn/src/master/2co/12/20.md)
* [Deuteronomy 05:9-10](https://git.door43.org/Door43/en_tn/src/master/deu/05/09.md)
* [Exodus 20:4-6](https://git.door43.org/Door43/en_tn/src/master/exo/20/04.md)
* [Ezekiel 36:4-6](https://git.door43.org/Door43/en_tn/src/master/ezk/36/04.md)
* [Joshua 24:19-20](https://git.door43.org/Door43/en_tn/src/master/jos/24/19.md)
* [Nahum 01:2-3](https://git.door43.org/Door43/en_tn/src/master/nam/01/02.md)
* [Romans 13:13-14](https://git.door43.org/Door43/en_tn/src/master/rom/13/13.md)

### Word Data:

* Strong's: H7065, H7067, H7068, H7072, G2205, G3863


## <a id="tw-term-kt-jesus"/>Jesus, Jesus Christ, Christ Jesus

### Facts:

Jesus is God's Son. The name "Jesus" means "Yahweh saves." The term "Christ" is a title that means "anointed one" and is another word for  Messiah.

* The two names are often combined as "Jesus Christ" or "Christ Jesus." These names emphasize that God's Son is the Messiah, who came to save people from being punished eternally for their sins.
* In a miraculous way, the Holy Spirit caused the eternal Son of God to be born as a human being. His mother was told by an angel to call him "Jesus" because he was destined to save people from their sins.
* Jesus did many miracles that revealed that he is God and that he is the Christ, or the Messiah.

### Translation Suggestions:

* In many languages "Jesus" and "Christ" are spelled in a way that keeps the sounds or spelling as close to the original as possible. For example, "Jesucristo," "Jezus Christus," "Yesus Kristus", and "Hesukristo" are some of the ways that these names are translated into different languages.
* For the term "Christ," some translators may prefer to use only some form of the term "Messiah" throughout.
* Also consider how these names are spelled in a nearby local or national language.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Christ](#christ), [God](#god), [God the Father](#godthefather), [high priest](#highpriest), [kingdom of God](#kingdomofgod), [Mary](names.html#mary), [Savior](#savior), [Son of God](#sonofgod))

### Bible References:

* [1 Corinthians 06:9-11](https://git.door43.org/Door43/en_tn/src/master/1co/06/09.md)
* [1 John 02:1-3](https://git.door43.org/Door43/en_tn/src/master/1jn/02/01.md)
* [1 John 04:15-16](https://git.door43.org/Door43/en_tn/src/master/1jn/04/15.md)
* [1 Timothy 01:1-2](https://git.door43.org/Door43/en_tn/src/master/1ti/01/01.md)
* [2 Peter 01:1-2](https://git.door43.org/Door43/en_tn/src/master/2pe/01/01.md)
* [2 Thessalonians 02:13-15](https://git.door43.org/Door43/en_tn/src/master/2th/02/13.md)
* [2 Timothy 01:8-11](https://git.door43.org/Door43/en_tn/src/master/2ti/01/08.md)
* [Acts 02:22-24](https://git.door43.org/Door43/en_tn/src/master/act/02/22.md)
* [Acts 05:29-32](https://git.door43.org/Door43/en_tn/src/master/act/05/29.md)
* [Acts 10:36-38](https://git.door43.org/Door43/en_tn/src/master/act/10/36.md)
* [Hebrews 09:13-15](https://git.door43.org/Door43/en_tn/src/master/heb/09/13.md)
* [Hebrews 10:19-22](https://git.door43.org/Door43/en_tn/src/master/heb/10/19.md)
* [Luke 24:19-20](https://git.door43.org/Door43/en_tn/src/master/luk/24/19.md)
* [Matthew 01:20-21](https://git.door43.org/Door43/en_tn/src/master/mat/01/20.md)
* [Matthew 04:1-4](https://git.door43.org/Door43/en_tn/src/master/mat/04/01.md)
* [Philippians 02:5-8](https://git.door43.org/Door43/en_tn/src/master/php/02/05.md)
* [Philippians 02:9-11](https://git.door43.org/Door43/en_tn/src/master/php/02/09.md)
* [Philippians 04:21-23](https://git.door43.org/Door43/en_tn/src/master/php/04/21.md)
* [Revelation 01:4-6](https://git.door43.org/Door43/en_tn/src/master/rev/01/04.md)

### Examples from the Bible stories:

* __[22:04](https://git.door43.org/Door43/en_tn/src/master/obs/22/04.md)__ The angel said, "You will become pregnant and give birth to a son. You are to name him __Jesus__  and he will be the Messiah."
* __[23:02](https://git.door43.org/Door43/en_tn/src/master/obs/23/02.md)__ "Name him __Jesus__  (which means, 'Yahweh saves'), because he will save the people from their sins."
* __[24:07](https://git.door43.org/Door43/en_tn/src/master/obs/24/07.md)__ So John baptized him (Jesus), even though __Jesus__  had never sinned.
* __[24:09](https://git.door43.org/Door43/en_tn/src/master/obs/24/09.md)__ There is only one God. But John heard God the Father speak, and saw __Jesus__  the Son and the Holy Spirit when he baptized __Jesus__.
* __[25:08](https://git.door43.org/Door43/en_tn/src/master/obs/25/08.md)__ __Jesus__  did not give in to Satan's temptations, so Satan left him.
* __[26:08](https://git.door43.org/Door43/en_tn/src/master/obs/26/08.md)__ Then __Jesus__  went throughout the region of Galilee, and large crowds came to him. They brought many people who were sick or handicapped, including those who could not see, walk, hear, or speak, and __Jesus__  healed them.
* __[31:03](https://git.door43.org/Door43/en_tn/src/master/obs/31/03.md)__ Then __Jesus__  finished praying and went to the disciples. He walked on top of the water across the lake toward their boat!
* __[38:02](https://git.door43.org/Door43/en_tn/src/master/obs/38/02.md)__ He (Judas) knew that the Jewish leaders denied that __Jesus__  was the Messiah and that they were plotting to kill him.
* __[40:08](https://git.door43.org/Door43/en_tn/src/master/obs/40/08.md)__ Through his death, __Jesus__  opened a way for people to come to God.
* __[42:11](https://git.door43.org/Door43/en_tn/src/master/obs/42/11.md)__ Then __Jesus__  was taken up to heaven, and a cloud hid him from their sight. __Jesus__  sat down at the right hand of God to rule over all things.
* __[50:17](https://git.door43.org/Door43/en_tn/src/master/obs/50/17.md)__ __Jesus__  and his people will live on the new earth, and he will reign forever over everything that exists. He will wipe away every tear and there will be no more suffering, sadness, crying, evil, pain, or death. __Jesus__  will rule his kingdom with peace and justice, and he will be with his people forever.

### Word Data:

* Strong's: G2424, G5547


## <a id="tw-term-kt-jew"/>Jew, Jewish, Jews

### Facts:

Jews are people who are descendants of Abraham's grandson Jacob. The word "Jew" comes from the word "Judah."

* People began to call the Israelites "Jews" after they returned to Judah from their exile in Babylon.
* Jesus the Messiah was Jewish. However, the Jewish religious leaders rejected Jesus and demanded that he be killed.
* Often the phrase "the Jews" refers to the leaders of the Jews, not all the Jewish people. In those contexts, some translations add "leaders of" to make this clear.

(See also: [Abraham](names.html#abraham), [Jacob](names.html#jacob), [Israel](#israel), [Babylon](names.html#babylon), [Jewish leaders](other.html#jewishleaders))

### Bible References:

* [Acts 02:5-7](https://git.door43.org/Door43/en_tn/src/master/act/02/05.md)
* [Acts 10:27-29](https://git.door43.org/Door43/en_tn/src/master/act/10/27.md)
* [Acts 14:5-7](https://git.door43.org/Door43/en_tn/src/master/act/14/05.md)
* [Colossians 03:9-11](https://git.door43.org/Door43/en_tn/src/master/col/03/09.md)
* [John 02:13-14](https://git.door43.org/Door43/en_tn/src/master/jhn/02/13.md)
* [Matthew 28:14-15](https://git.door43.org/Door43/en_tn/src/master/mat/28/14.md)

### Examples from the Bible stories:

* __[20:11](https://git.door43.org/Door43/en_tn/src/master/obs/20/11.md)__ The Israelites were now called __Jews__  and most of them had lived their whole lives in Babylon.
* __[20:12](https://git.door43.org/Door43/en_tn/src/master/obs/20/12.md)__ So, after seventy years in exile, a small group of __Jews__  returned to the city of Jerusalem in Judah.
* __[37:10](https://git.door43.org/Door43/en_tn/src/master/obs/37/10.md)__ Many of the __Jews__  believed in Jesus because of this miracle.
* __[37:11](https://git.door43.org/Door43/en_tn/src/master/obs/37/11.md)__ But the religious leaders of the __Jews__  were jealous, so they gathered together to plan how they could kill Jesus and Lazarus.
* __[40:02](https://git.door43.org/Door43/en_tn/src/master/obs/40/02.md)__ Pilate commanded that they write, "King of the __Jews__" on a sign and put it on the cross above Jesus' head.
* __[46:06](https://git.door43.org/Door43/en_tn/src/master/obs/46/06.md)__ Right away, Saul began preaching to the __Jews__  in Damascus, saying, "Jesus is the Son of God!"

### Word Data:

* Strong's: H3054, H3061, H3062, H3064, H3066, G2450, G2451, G2452, G2453, G2454


## <a id="tw-term-kt-judge"/>judge, judges, judgment, judgments

### Definition:

The terms "judge" and "judgment" often refer to making a decision about whether something  is morally right or wrong.

* The "judgment of God" often refers to his decision to condemn something or someone as sinful.
* God's judgment usually includes punishing people for their sin.
* The term "judge" can also mean "condemn." God instructs his people not to judge each other in this way.
* Another meaning is "arbitrate between" or "judge between," as in deciding which person is right in a dispute between them.
* In some contexts, God's "judgments" are what he has decided is right and just. They are similar to his decrees, laws, or precepts.
* "Judgment" can refer to wise decision-making ability. A person who lacks "judgment" does not have the wisdom to make wise decisions.

### Translation Suggestions:

* Depending on the context, ways to translate to "judge" could include to "decide" or to "condemn" or to "punish" or to "decree."
* The term "judgment" could be translated as "punishment" or "decision" or "verdict" or "decree" or "condemnation."
* In some contexts, the phrase "in the judgment" could also be translated as "on judgment day" or "during the time when God judges people."

(See also: [decree](other.html#decree), [judge](other.html#judgeposition), [judgment day](#judgmentday), [just](#justice), [law](other.html#law), [law](#lawofmoses))

### Bible References:

* [1 John 04:17-18](https://git.door43.org/Door43/en_tn/src/master/1jn/04/17.md)
* [1 Kings 03:7-9](https://git.door43.org/Door43/en_tn/src/master/1ki/03/07.md)
* [Acts 10:42-43](https://git.door43.org/Door43/en_tn/src/master/act/10/42.md)
* [Isaiah 03:13-15](https://git.door43.org/Door43/en_tn/src/master/isa/03/13.md)
* [James 02:1-4](https://git.door43.org/Door43/en_tn/src/master/jas/02/01.md)
* [Luke 06:37](https://git.door43.org/Door43/en_tn/src/master/luk/06/37.md)
* [Micah 03:9-11](https://git.door43.org/Door43/en_tn/src/master/mic/03/09.md)
* [Psalm 054:1-3](https://git.door43.org/Door43/en_tn/src/master/psa/054/001.md)

### Examples from the Bible stories:

* __[19:16](https://git.door43.org/Door43/en_tn/src/master/obs/19/16.md)__ The prophets warned the people that if they did not stop doing evil and start obeying God, then God would __judge__  them as guilty, and he would punish them.
* __[21:08](https://git.door43.org/Door43/en_tn/src/master/obs/21/08.md)__ A king is someone who rules over a kingdom and __judges__  the people. The Messiah would come would be the perfect king who would sit on the throne of his ancestor David. He would reign over the whole world forever, and who would always __judge__  honestly and make the right decisions.
* __[39:04](https://git.door43.org/Door43/en_tn/src/master/obs/39/04.md)__ The high priest tore his clothes in anger and shouted to the other religious leaders, "We do not need any more witnesses! You have heard him say that he is the Son of God. What is your __judgment__?"
* __[50:14](https://git.door43.org/Door43/en_tn/src/master/obs/50/14.md)__ But God will __judge__  everyone who does not believe in Jesus. He will throw them into hell, where they will weep and grind their teeth in anguish forever.


### Word Data:

* Strong's: H148, H430, H1777, H1778, H1779, H1780, H1781, H1782, H2940, H4055, H4941, H6414, H6415, H6416, H6417, H6419, H6485, H8196, H8199, H8201, G144, G350, G968, G1106, G1252, G1341, G1345, G1348, G1349, G2917, G2919, G2920, G2922, G2923, G4232


## <a id="tw-term-kt-judgmentday"/>judgment day

### Definition:

The term"judgment day" refers to a future time when God will judge every person.

* God has made his Son, Jesus Christ, the judge of all people.
* On judgment day, Christ will judge people on the basis of his righteous character.

### Translation Suggestions:

* This term could also be translated as "judgment time" since it could refer to more than one day.
* Other ways to translate this term could include "the end time when God will judge all people."
* Some translations capitalize this term to show that it is the name of a special day or time: "Judgment Day" or "Judgment Time."

(See also: [judge](#judge), [Jesus](#jesus), [heaven](#heaven), [hell](#hell))

### Bible References:

* [Luke 10:10-12](https://git.door43.org/Door43/en_tn/src/master/luk/10/10.md)
* [Luke 11:31](https://git.door43.org/Door43/en_tn/src/master/luk/11/31.md)
* [Luke 11:32](https://git.door43.org/Door43/en_tn/src/master/luk/11/32.md)
* [Matthew 10:14-15](https://git.door43.org/Door43/en_tn/src/master/mat/10/14.md)
* [Matthew 12:36-37](https://git.door43.org/Door43/en_tn/src/master/mat/12/36.md)

### Word Data:

* Strong's: H2962, H3117, H4941, G2250, G2920, G2962


## <a id="tw-term-kt-justice"/>just, justice, unjust, unjustly, injustice, justly, justify, justification

### Definition:

"Just" and "justice" refer to treating people fairly according to God's laws. Human laws that reflect God's standard of right behavior toward others are also just.

* To be "just" is to act in a fair and right way toward others. It also implies honesty and integrity to do what is morally right in God's eyes.
* To act "justly" means to treat people in a way that is right, good, and proper according to God's laws.
* To receive "justice" means to be treated fairly under the law, either being protected by the law or being punished for breaking the law.
* Sometimes the term "just" has the broader meaning of "righteous" or "following God's laws."

The terms "unjust" and "unjustly" refer to treating people in an unfair and often harmful manner.

* An "injustice" is something bad that is done to someone that the person did not deserve. It refers to treating people unfairly.
* Injustice also means that some people are treated badly while others are treated well.
* Someone who is acting in an unjust way is being "partial" or "prejudiced" because he is not treating people equally.

The terms "justify" and "justification" refer to causing a guilty person to be righteous. Only God can truly justify people.

* When God justifies people, he forgives their sins and makes it as though they have no sin. He justifies sinners who repent and trust in Jesus to save them from their sins.
* "Justification" refers to what God does when he forgives a person's sins and declares that person to be righteous in his sight.

### Translation Suggestions:

* Depending on the context, other ways to translate "just" could include "morally right" or "fair."
* The term "justice" could be translated as "fair treatment" or "deserved consequences."
* To "act justly" could be translated as "treat fairly" or "behave in a just way."
* In some contexts, "just" could be translated as "righteous" or "upright."

* Depending on the context, "unjust" could also be translated as "unfair" or "partial" or "unrighteous."
* The phrase "the unjust" could be translated as "the unjust ones" or "unjust people" or "people who treat others unfairly" or "unrighteous people" or "people who disobey God."
* The term "unjustly" could be translated as, "in an unfair manner" or "wrongly" or "unfairly."
* Ways to translate "injustice" could include, "wrong treatment" or "unfair treatment" or "acting unfairly." (See: [abstractnouns](https://git.door43.org/Door43/en_man/src/master/translate/figs-abstractnouns/01.md))

* Other ways to translate "justify" could include "declare (someone) to be righteous" or "cause (someone) to be righteous."
* The term "justification" could be translated as "being declared righteous" or "becoming righteous" or "causing people to be righteous."
* The phrase "resulting in justification" could be translated as "so that God justified many people" or "which resulted in God causing people to be righteous."
* The phrase "for our justification" could be translated as "in order that we could be made righteous by God."

(See also: [forgive](#forgive), [guilt](#guilt), [judge](#judge), [righteous](#righteous), [righteous](#righteous))

### Bible References:

* [Genesis 44:16-17](https://git.door43.org/Door43/en_tn/src/master/gen/44/16.md)
* [1 Chronicles 18:14-17](https://git.door43.org/Door43/en_tn/src/master/1ch/18/14.md)
* [Isaiah 04:3-4](https://git.door43.org/Door43/en_tn/src/master/isa/04/03.md)
* [Jeremiah 22:1-3](https://git.door43.org/Door43/en_tn/src/master/jer/22/01.md)
* [Ezekiel 18:16-17](https://git.door43.org/Door43/en_tn/src/master/ezk/18/16.md)
* [Micah 03:8](https://git.door43.org/Door43/en_tn/src/master/mic/03/08.md)
* [Matthew 05:43-45](https://git.door43.org/Door43/en_tn/src/master/mat/05/43.md)
* [Matthew 11:18-19](https://git.door43.org/Door43/en_tn/src/master/mat/11/18.md)
* [Matthew 23:23-24](https://git.door43.org/Door43/en_tn/src/master/mat/23/23.md)
* [Luke 18:3-5](https://git.door43.org/Door43/en_tn/src/master/luk/18/03.md)
* [Luke 18:6-8](https://git.door43.org/Door43/en_tn/src/master/luk/18/06.md)
* [Luke 18:13-14](https://git.door43.org/Door43/en_tn/src/master/luk/18/13.md)
* [Luke 21:20-22](https://git.door43.org/Door43/en_tn/src/master/luk/21/20.md)
* [Luke 23:39-41](https://git.door43.org/Door43/en_tn/src/master/luk/23/39.md)
* [Acts 13:38-39](https://git.door43.org/Door43/en_tn/src/master/act/13/38.md)
* [Acts 28:3-4](https://git.door43.org/Door43/en_tn/src/master/act/28/03.md)
* [Romans 04:1-3](https://git.door43.org/Door43/en_tn/src/master/rom/04/01.md)
* [Galatians 03:6-9](https://git.door43.org/Door43/en_tn/src/master/gal/03/06.md)
* [Galatians 03:10-12](https://git.door43.org/Door43/en_tn/src/master/gal/03/10.md)
* [Galatians 05:3-4](https://git.door43.org/Door43/en_tn/src/master/gal/05/03.md)
* [Titus 03:6-7](https://git.door43.org/Door43/en_tn/src/master/tit/03/06.md)
* [Hebrews 06:9-10](https://git.door43.org/Door43/en_tn/src/master/heb/06/09.md)
* [James 02:21-24](https://git.door43.org/Door43/en_tn/src/master/jas/02/21.md)
* [Revelation 15:3-4](https://git.door43.org/Door43/en_tn/src/master/rev/15/03.md)

### Examples from the Bible stories:

* __[17:09](https://git.door43.org/Door43/en_tn/src/master/obs/17/09.md)__ David ruled with __justice__  and faithfulness for many years, and God blessed him.
* __[18:13](https://git.door43.org/Door43/en_tn/src/master/obs/18/13.md)__ Some of these kings (of Judah) were good men who ruled __justly__  and worshiped God.
* __[19:16](https://git.door43.org/Door43/en_tn/src/master/obs/19/16.md)__ They (the prophets) all told the people to stop worshiping idols and to start showing __justice__  and mercy to others.
* __[50:17](https://git.door43.org/Door43/en_tn/src/master/obs/50/17.md)__ Jesus will rule his kingdom with peace and __justice__, and he will be with his people forever.

### Word Data:

* Strong's: H205, H2555, H3477, H5765, H5766, H5767, H6662, H6663, H6664, H6666, H8003, H8264, H8636, G91, G93, G94, G1342, G1344, G1345, G1346, G1347, G1738


## <a id="tw-term-kt-kingdomofgod"/>kingdom of God, kingdom of heaven

### Definition:

The terms "kingdom of God" and "kingdom of heaven" both refer to God's rule and authority over his people and over all creation.

* The Jews often used the term "heaven" to refer to God, to avoid saying his name directly. (See: [metonymy](https://git.door43.org/Door43/en_man/src/master/translate/figs-metonymy/01.md)) 
* In the New Testament book that Matthew wrote, he referred to God's kingdom as "the kingdom of heaven," probably because he was writing primarily for a Jewish audience.
* The kingdom of God refers to God ruling people spiritually as well as ruling over the physical world.
* The Old Testament prophets said that God would send the Messiah to rule with righteousness. Jesus, the Son of God, is the Messiah who will rule over God's kingdom forever.

### Translation Suggestions:

* Depending on the context, "kingdom of God" can be translated as "God's rule (as king)" or "when God reigns as king" or "God's rule over everything."
* The term "kingdom of heaven" could also be translated as "God's rule from heaven as king" or "God in heaven reigning" or "heaven's reign" or "heaven ruling over everything." If it is not possible to translate this simply and clearly, the phrase "kingdom of God" could be translated instead.
* Some translators may prefer to capitalize "Heaven" to show that it refers to God. Others may include a note in the text, such as "kingdom of heaven (that is, 'kingdom of God')."
* A footnote at the bottom of the page of a printed Bible may also be used to explain the meaning of "heaven" in this expression.

(See also: [God](#god), [heaven](#heaven), [king](other.html#king), [kingdom](other.html#kingdom), [King of the Jews](#kingofthejews), [reign](other.html#reign))

### Bible References:

* [2 Thessalonians 01:3-5](https://git.door43.org/Door43/en_tn/src/master/2th/01/03.md)
* [Acts 08:12-13](https://git.door43.org/Door43/en_tn/src/master/act/08/12.md)
* [Acts 28:23-24](https://git.door43.org/Door43/en_tn/src/master/act/28/23.md)
* [Colossians 04:10-11](https://git.door43.org/Door43/en_tn/src/master/col/04/10.md)
* [John 03:3-4](https://git.door43.org/Door43/en_tn/src/master/jhn/03/03.md)
* [Luke 07:27-28](https://git.door43.org/Door43/en_tn/src/master/luk/07/27.md)
* [Luke 10:8-9](https://git.door43.org/Door43/en_tn/src/master/luk/10/08.md)
* [Luke 12:31-32](https://git.door43.org/Door43/en_tn/src/master/luk/12/31.md)
* [Matthew 03:1-3](https://git.door43.org/Door43/en_tn/src/master/mat/03/01.md)
* [Matthew 04:17](https://git.door43.org/Door43/en_tn/src/master/mat/04/17.md)
* [Matthew 05:9-10](https://git.door43.org/Door43/en_tn/src/master/mat/05/09.md)
* [Romans 14:16-17](https://git.door43.org/Door43/en_tn/src/master/rom/14/16.md)

### Examples from the Bible stories:

* __[24:02](https://git.door43.org/Door43/en_tn/src/master/obs/24/02.md)__ He (John) preached to them, saying, "Repent, for the __kingdom of God__  is near!"
* __[28:06](https://git.door43.org/Door43/en_tn/src/master/obs/28/06.md)__ Then Jesus said to his disciples, "It is extremely hard for rich people to enter into the __kingdom of God__! Yes, it is easier for a camel to go through the eye of a needle than for a rich man to enter the __kingdom of God__."
* __[29:02](https://git.door43.org/Door43/en_tn/src/master/obs/29/02.md)__ Jesus said, "The __kingdom of God__  is like a king who wanted to settle accounts with his servants."
* __[34:01](https://git.door43.org/Door43/en_tn/src/master/obs/34/01.md)__ Jesus told many other stories about the __kingdom of God__. For example, he said, "The __kingdom of God__  is like a mustard seed that someone planted in his field."
* __[34:03](https://git.door43.org/Door43/en_tn/src/master/obs/34/03.md)__ Jesus told another story, "The __kingdom of God__  is like yeast that a woman mixes into some bread dough until it spreads throughout the dough."
* __[34:04](https://git.door43.org/Door43/en_tn/src/master/obs/34/04.md)__ "The __kingdom of God__  is also like hidden treasure that someone hid in a field.. Another man found the treasure and then buried it again."
* __[34:05](https://git.door43.org/Door43/en_tn/src/master/obs/34/05.md)__ "The __kingdom of God__  is also like a perfect pearl of great value."
* __[42:09](https://git.door43.org/Door43/en_tn/src/master/obs/42/09.md)__ He proved to his disciples in many ways that he was alive, and he taught them about the __kingdom of God__.
* __[49:05](https://git.door43.org/Door43/en_tn/src/master/obs/49/05.md)__ Jesus said that the __kingdom of God__  is more valuable than anything else in the world.
* __[50:02](https://git.door43.org/Door43/en_tn/src/master/obs/50/02.md)__ When Jesus was living on earth he said, "My disciples will preach the good news about the __kingdom of God__  to people everywhere in the world, and then the end will come."

### Word Data:

* Strong's: G932, G2316, G3772


## <a id="tw-term-kt-kingofthejews"/>King of the Jews, king of the Jews

### Definition:

The term "King of the Jews" is a title that refers to Jesus, the Messiah.

* The first time the Bible records this title is when it was used by the wise men who traveled to Bethlehem looking for the baby who was "King of the Jews."
* The angel revealed to Mary that her son, a descendant of King David, would be a king whose reign would last forever.
* Before Jesus was crucified, Roman soldiers mockingly called Jesus "King of the Jews." This title was also written on a piece of wood and nailed to the top of Jesus' cross.
* Jesus truly is the King of the Jews and the king over all creation.

### Translation Suggestions:

* The term "King of the Jews" could also be translated as "king over the Jews" or "king who rules over the Jews" or "supreme ruler of the Jews."
* Check to see how the phrase "king of" is translated in other places in the translation.

(See also: [descendant](other.html#descendant), [Jew](#jew), [Jesus](#jesus), [king](other.html#king), [kingdom](other.html#kingdom), [kingdom of God](#kingdomofgod), [wise men](other.html#wisemen))

### Bible References:

* [Luke 23:3-5](https://git.door43.org/Door43/en_tn/src/master/luk/23/03.md)
* [Luke 23:36-38](https://git.door43.org/Door43/en_tn/src/master/luk/23/36.md)
* [Matthew 02:1-3](https://git.door43.org/Door43/en_tn/src/master/mat/02/01.md)
* [Matthew 27:11-14](https://git.door43.org/Door43/en_tn/src/master/mat/27/11.md)
* [Matthew 27:35-37](https://git.door43.org/Door43/en_tn/src/master/mat/27/35.md)

### Examples from the Bible stories:

* __[23:09](https://git.door43.org/Door43/en_tn/src/master/obs/23/09.md)__ Some time later, wise men from countries far to the east saw an unusual star in the sky. They realized it meant a new __king of the Jews__  was born.
* __[39:09](https://git.door43.org/Door43/en_tn/src/master/obs/39/09.md)__ Pilate asked Jesus, "Are you the __King of the Jews__?"
* __[39:12](https://git.door43.org/Door43/en_tn/src/master/obs/39/12.md)__ The Roman soldiers whipped Jesus and put a royal robe and a crown made of thorns on him. Then they mocked him by saying, "Look, the __King of the Jews__!"
* __[40:02](https://git.door43.org/Door43/en_tn/src/master/obs/40/02.md)__ Pilate commanded that they write, "__King of the Jews__" on a sign and put it on the cross above Jesus' head.


### Word Data:

* Strong's: G935, G2453


## <a id="tw-term-kt-lamb"/>lamb, Lamb of God

### Definition:

The term "lamb" refers to a young sheep. Sheep are four-legged animals with thick, woolly hair, used for sacrifices to God. Jesus is called the "Lamb of God" because he was sacrificed to pay for people's sins.

 * These animals are easily led astray and need protecting. God compares human beings to sheep.
 * God instructed his people to sacrifice physically perfect sheep and lambs to him.
 * Jesus is called the "Lamb of God" who was sacrificed to pay for people's sins. He was a perfect, unblemished sacrifice because he was completely without sin.

### Translation Suggestions:

* If sheep are known in the language area, the name for their young should be used to translate the terms "lamb" and "Lamb of God."
* "Lamb of God" could be translated as "God's (sacrificial) Lamb," or "Lamb sacrificed to God" or "(sacrificial) Lamb from God."
* If sheep are not known, this term could be translated as "a young sheep" with a footnote that describes what sheep are like. The note could also compare sheep and lambs to an animal from that area that lives in herds, that is timid and defenseless, and that often wanders away.
* Also consider how this term is translated in a Bible translation of a nearby local or national language. 

(See: [How to Translate Unknowns](https://git.door43.org/Door43/en_man/src/master/translate/translate-unknown/01.md))

(See also: [sheep](other.html#sheep), [shepherd](other.html#shepherd))

### Bible References:

* [2 Samuel 12:1-3](https://git.door43.org/Door43/en_tn/src/master/2sa/12/01.md)
* [Ezra 08:35-36](https://git.door43.org/Door43/en_tn/src/master/ezr/08/35.md)
* [Isaiah 66:3](https://git.door43.org/Door43/en_tn/src/master/isa/66/03.md)
* [Jeremiah 11:18-20](https://git.door43.org/Door43/en_tn/src/master/jer/11/18.md)
* [John 01:29-31](https://git.door43.org/Door43/en_tn/src/master/jhn/01/29.md)
* [John 01:35-36](https://git.door43.org/Door43/en_tn/src/master/jhn/01/35.md)
* [Leviticus 14:21-23](https://git.door43.org/Door43/en_tn/src/master/lev/14/21.md)
* [Leviticus 17:1-4](https://git.door43.org/Door43/en_tn/src/master/lev/17/01.md)
* [Luke 10:3-4](https://git.door43.org/Door43/en_tn/src/master/luk/10/03.md)
* [Revelation 15:3-4](https://git.door43.org/Door43/en_tn/src/master/rev/15/03.md)

### Examples from the Bible stories:

  __*[05:07](https://git.door43.org/Door43/en_tn/src/master/obs/05/07.md)__ As Abraham and Isaac walked to the place of the sacrifice Isaac asked, "Father, we have wood for the sacrifice, but where is the __lamb__?"
  __*[11:02](https://git.door43.org/Door43/en_tn/src/master/obs/11/02.md)__ God provided a way to save the firstborn son of anyone who believed in him. Each family had to choose a perfect __lamb__ or goat and kill it.
  __*[24:06](https://git.door43.org/Door43/en_tn/src/master/obs/24/06.md)__ The next day, Jesus came to be baptized by John. When John saw him, he said, "Look! There is the __Lamb of God__ who will take away the sin of the world."
  __*[45:08](https://git.door43.org/Door43/en_tn/src/master/obs/45/08.md)__ He read, "They led him like a __lamb__ to be killed, and as a __lamb__ is silent, he did not say a word.
  __*[48:08](https://git.door43.org/Door43/en_tn/src/master/obs/48/08.md)__ When God told Abraham to offer his son, Isaac, as a sacrifice, God provided a __lamb__ for the sacrifice instead of his son, Isaac. We all deserve to die for our sins! But God provided Jesus, the __Lamb__ of God, as a sacrifice to die in our place.
  __*[48:09](https://git.door43.org/Door43/en_tn/src/master/obs/48/09.md)__ When God sent the last plague on Egypt, he told each Israelite family to kill a perfect __lamb__ and spread its blood around the tops and sides of their door frames.

### Word Data:

* Strong's: H7716, G721, G2316


## <a id="tw-term-kt-lament"/>lament, laments, lamentation

### Definition:

The terms "lament" and "lamentation" refer to a strong expression of mourning, sorrow, or grief.

* Sometimes this includes deep regret for sin, or compassion for people who have experienced disaster.
* A lamentation could include moaning, weeping, or wailing.

### Translation Suggestions:

* The term to "lament" could be translated as to "deeply mourn" or to "wail in grief" or to "be sorrowful."
* A "lamentation" (or a "lament") could be translated as "loud wailing and weeping" or "deep sorrow" or "sorrowful sobbing" or "mournful moaning."

### Bible References:

* [Amos 08:9-10](https://git.door43.org/Door43/en_tn/src/master/amo/08/09.md)
* [Ezekiel 32:1-2](https://git.door43.org/Door43/en_tn/src/master/ezk/32/01.md)
* [Jeremiah 22:17-19](https://git.door43.org/Door43/en_tn/src/master/jer/22/17.md)
* [Job 27:15-17](https://git.door43.org/Door43/en_tn/src/master/job/27/15.md)
* [Lamentations 02:5-6](https://git.door43.org/Door43/en_tn/src/master/lam/02/05.md)
* [Lamentations 02:8-9](https://git.door43.org/Door43/en_tn/src/master/lam/02/08.md)
* [Micah 02:3-5](https://git.door43.org/Door43/en_tn/src/master/mic/02/03.md)
* [Psalm 102:1-2](https://git.door43.org/Door43/en_tn/src/master/psa/102/001.md)
* [Zechariah 11:1-3](https://git.door43.org/Door43/en_tn/src/master/zec/11/01.md)


### Word Data:

* Strong's: H56, H421, H578, H592, H1058, H4553, H5091, H5092, H5594, H6088, H6969, H7015, H8567, G2354, G2355, G2870, G2875


## <a id="tw-term-kt-lastday"/>last day, last days, latter days

### Definition:

The term "last days" or "latter days" refers generally to the time period at the end of the current age.

* This time period will have an unknown duration.
* The "last days" are a time of judgment upon those who have turned away from God. 

### Translation Suggestions:

* The term "last days" can also be translated as "final days" or "end times."
* In some contexts, this could be translated as "end of the world" or "when this world ends."

(See also: [day of the Lord](#dayofthelord), [judge](#judge), [turn](other.html#turn), [world](#world))

### Bible References:

* [2 Peter 03:3-4](https://git.door43.org/Door43/en_tn/src/master/2pe/03/03.md)
* [Daniel 10:14-15](https://git.door43.org/Door43/en_tn/src/master/dan/10/14.md)
* [Hebrews 01:1-3](https://git.door43.org/Door43/en_tn/src/master/heb/01/01.md)
* [Isaiah 02:1-2](https://git.door43.org/Door43/en_tn/src/master/isa/02/01.md)
* [James 05:1-3](https://git.door43.org/Door43/en_tn/src/master/jas/05/01.md)
* [Jeremiah 23:19-20](https://git.door43.org/Door43/en_tn/src/master/jer/23/19.md)
* [John 11:24-26](https://git.door43.org/Door43/en_tn/src/master/jhn/11/24.md)
* [Micah 04:1](https://git.door43.org/Door43/en_tn/src/master/mic/04/01.md)

### Word Data:

* Strong's: H319, H3117, G2078, G2250


## <a id="tw-term-kt-lawofmoses"/>law, law of Moses, God's law, law of Yahweh

### Definition:

All these terms refer to the commandments and instructions that God gave Moses for the Israelites to obey. The terms "law" and "God's law" are also used more generally to refer to everything God wants his people to obey.

* Depending on the context, the "law" can refer to:
   * the Ten Commandments that God wrote on stone tablets for the Israelites
   * all the laws given to Moses
   * the first five books of the Old Testament
   * the entire Old Testament (also referred to as "scriptures" in the New Testament).
   * all of God's instructions and will
* The phrase "the law and the prophets" is used in the New Testament to refer to the Hebrew scriptures (or "Old Testament")

### Translation Suggestions:

* These terms could be translated using the plural, "laws," since they refer to many instructions.
* The "law of Moses" could be translated as "the laws that God told Moses to give to the Israelites."
* Depending on the context, "the law of Moses" could also be translated as "the law that God told to Moses" or "God's laws that Moses wrote down" or "the laws that God told Moses to give to the Israelites."
* Ways to translate "the law" or "law of God" or "God's laws" could include "laws from God" or "God's commands" or "laws that God gave" or "everything that God commands" or "all of God's instructions."
* The phrase "law of Yahweh" could also be translated as "Yahweh's laws" or "laws that Yahweh said to obey" or "laws from Yahweh" or "things Yahweh commanded."

(See also: [instruct](other.html#instruct), [Moses](names.html#moses), [Ten Commandments](other.html#tencommandments), [lawful](other.html#lawful), [Yahweh](#yahweh))

### Bible References:

* [Acts 15:5-6](https://git.door43.org/Door43/en_tn/src/master/act/15/05.md)
* [Daniel 09:12-14](https://git.door43.org/Door43/en_tn/src/master/dan/09/12.md)
* [Exodus 28:42-43](https://git.door43.org/Door43/en_tn/src/master/exo/28/42.md)
* [Ezra 07:25-26](https://git.door43.org/Door43/en_tn/src/master/ezr/07/25.md)
* [Galatians 02:15-16](https://git.door43.org/Door43/en_tn/src/master/gal/02/15.md)
* [Luke 24:44](https://git.door43.org/Door43/en_tn/src/master/luk/24/44.md)
* [Matthew 05:17-18](https://git.door43.org/Door43/en_tn/src/master/mat/05/17.md)
* [Nehemiah 10:28-29](https://git.door43.org/Door43/en_tn/src/master/neh/10/28.md)
* [Romans 03:19-20](https://git.door43.org/Door43/en_tn/src/master/rom/03/19.md)

### Examples from the Bible stories:

* __[13:07](https://git.door43.org/Door43/en_tn/src/master/obs/13/07.md)__ God also gave many other __laws__  and rules to follow. If the people obeyed these __laws__, God promised that he would bless and protect them. If they disobeyed them, God would punish them.\\
* __[13:09](https://git.door43.org/Door43/en_tn/src/master/obs/13/09.md)__ Anyone who disobeyed __God's law__  could bring an animal to the altar in front of the Tent of Meeting as a sacrifice to God.\\
* __[15:13](https://git.door43.org/Door43/en_tn/src/master/obs/15/13.md)__ Then Joshua reminded the people of their obligation to obey the covenant that God had made with the Israelites at Sinai. The people promised to remain faithful to God and follow __his laws__.\\
* __[16:01](https://git.door43.org/Door43/en_tn/src/master/obs/16/01.md)__ After Joshua died, the Israelites disobeyed God and did not drive out the rest of the Canaanites or obey __God's laws__.\\
* __[21:05](https://git.door43.org/Door43/en_tn/src/master/obs/21/05.md)__ In the New Covenant, God would write __his law__  on the people's hearts, the people would know God personally, they would be his people, and God would forgive their sins.\\
* __[27:01](https://git.door43.org/Door43/en_tn/src/master/obs/27/01.md)__ Jesus answered, "What is written in __God's law__?"\\
* __[28:01](https://git.door43.org/Door43/en_tn/src/master/obs/28/01.md)__ Jesus said to him, "Why do you call me 'good?' There is only one who is good, and that is God. But if you want to have eternal life, obey __God's laws__."\\

### Word Data:

* Strong's: H430, H1881, H1882, H2706, H2710, H3068, H4687, H4872, H4941, H8451, G2316, G3551, G3565


## <a id="tw-term-kt-life"/>life, live, lived, lives, living, alive

### Definition:

All these terms refer to being physically alive, not dead. They are also used figuratively to refer to being alive spiritually. The following discusses what is meant by "physical life" and "spiritual life."

### 1. Physical life

* Physical life is the presence of the spirit in the body. God breathed life into Adam's body, and he became a living being.
* A "life" can also refer to an individual person as in "a life was saved".
* Sometimes the word "life" refers to the experience of living as in, "his life was enjoyable."
* It can also refer to a person's lifespan, as in the expression, "the end of his life."
* The term "living" may refer to being physically alive, as in "my mother is still living." It may also refer to dwelling somewhere as in, "they were living in the city."
* In the Bible, the concept of "life" is often contrasted with the concept of "death."

### 2. Spiritual life

* A person has spiritual life when he believes in Jesus with God gives that person a transformed life with the Holy Spirit living in him.
* This life is also called "eternal life" to indicate that it does not end.
* The opposite of spiritual life is spiritual death, which means being separated from God and experiencing eternal punishment.

### Translation Suggestions:

* Depending on the context, "life" can be translated as "existence" or "person" or "soul" or "being" or "experience."
* The term "live" could be translated by "dwell" or "reside" or "exist."
* The expression "end of his life" could be translated as "when he stopped living."
* The expression "spared their lives' could be translated as "allowed them to live" or "did not kill them."
* The expression "they risked their lives" could be translated as "they put themselves in danger" or "they did something that could have killed them." 
* When the Bible text talks about being alive spiritually, "life" could be translated as "spiritual life" or "eternal life," depending on the context.
* The concept of "spiritual life" could also be translated as "God making us alive in our spirits" or "new life by God's Spirit" or "being made alive in our inner self."
* Depending on the context, the expression "give life" could also be translated as "cause to live" or "give eternal life" or "cause to live eternally."

(See also: [death](other.html#death), [everlasting](#eternity))

### Bible References:

* [2 Peter 01:3-4](https://git.door43.org/Door43/en_tn/src/master/2pe/01/03.md)
* [Acts 10:42-43](https://git.door43.org/Door43/en_tn/src/master/act/10/42.md)
* [Genesis 02:7-8](https://git.door43.org/Door43/en_tn/src/master/gen/02/07.md)
* [Genesis 07:21-22](https://git.door43.org/Door43/en_tn/src/master/gen/07/21.md)
* [Hebrews 10:19-22](https://git.door43.org/Door43/en_tn/src/master/heb/10/19.md)
* [Jeremiah 44:1-3](https://git.door43.org/Door43/en_tn/src/master/jer/44/01.md)
* [John 01:4-5](https://git.door43.org/Door43/en_tn/src/master/jhn/01/04.md)
* [Judges 02:18-19](https://git.door43.org/Door43/en_tn/src/master/jdg/02/18.md)
* [Luke 12:22-23](https://git.door43.org/Door43/en_tn/src/master/luk/12/22.md)
* [Matthew 07:13-14](https://git.door43.org/Door43/en_tn/src/master/mat/07/13.md)

### Examples from the Bible stories:

* __[01:10](https://git.door43.org/Door43/en_tn/src/master/obs/01/10.md)__ So God took some dirt, formed it into a man, and breathed __life__  into him.
* __[03:01](https://git.door43.org/Door43/en_tn/src/master/obs/03/01.md)__ After a long time, many people were __living __  in the world.
* __[08:13](https://git.door43.org/Door43/en_tn/src/master/obs/08/13.md)__ When Joseph's brothers returned home and told their father, Jacob, that Joseph was still __alive__, he was very happy.
* __[17:09](https://git.door43.org/Door43/en_tn/src/master/obs/17/09.md)__ However, toward the end of his [David's] __life__  he sinned terribly before God.
* __[27:01](https://git.door43.org/Door43/en_tn/src/master/obs/27/01.md)__ One day, an expert in the Jewish law came to Jesus to test him, saying, "Teacher, what must I do to inherit eternal __life__?"
* __[35:05](https://git.door43.org/Door43/en_tn/src/master/obs/35/05.md)__ Jesus replied, "I am the Resurrection and the __Life__."
* __[44:05](https://git.door43.org/Door43/en_tn/src/master/obs/44/05.md)__ "You are the ones who told the Roman governor to kill Jesus. You killed the author of __life__, but God raised him from the dead."

### Word Data:

* Strong's: H1934, H2416, H2417, H2421, H2425, H5315, G198, G222, G227, G806, G590


## <a id="tw-term-kt-lord"/>lord, lords, Lord, master, masters, sir, sirs

### Definition:

The term "lord" refers to someone who has ownership or authority over other people.

* This word is sometimes translated as "master" when addressing Jesus or when referring to someone who owns slaves.
* Some English versions translate this as "sir" in contexts where someone is politely addressing someone of higher status.

When "Lord" is capitalized, it is a title that refers to God. (Note, however, that when it is used as a form of addressing someone or it occurs at the beginning of a sentence it may be capitalized and have the meaning of "sir" or "master.")

* In the Old Testament, this term is also used in expressions such as "Lord God Almighty" or "Lord Yahweh" or "Yahweh our Lord."
* In the New Testament, the apostles used this term in expressions such as "Lord Jesus" and "Lord Jesus Christ," which communicate that Jesus is God.
* The term "Lord" in the New Testament is also used alone as a direct reference to God, especially in quotations from the Old Testament. For example, the Old Testament text has  "Blessed is he who comes in the name of Yahweh" and the New Testament text has "Blessed is he who comes in the name of the Lord."
* In the ULB and UDB, the title "Lord" is only used to translate the actual Hebrew and Greek words that mean "Lord." It is never used as a translation of God's name (Yahweh), as is done in many translations.

* Some languages translate "Lord" as "Master" or "Ruler" or some other term that communicates ownership or supreme rule.
* In the appropriate contexts, many translations capitalize the first letter of this term to make it clear to the reader that this is a title referring to God.
* For places in the New Testament where there is a quote from the Old Testament, the term "Lord God" could be used to make it clear that this is a reference to God.

### Translation Suggestions:

* This term can be translated with the equivalent of "master" when it refers to a person who owns slaves. It can also be used by a servant to address the person he works for.
* When it refers to Jesus, if the context shows that the speaker sees him as a religious teacher, it can be translated with a respectful address for a religious teacher, such as "master." 
* If the person addressing Jesus does not know him, "lord" could be translated with a respectful form of address such as "sir." This translation would also be used for other contexts in which a polite form of address to a man is called for.
* When referring to God the Father or to Jesus, this term is considered a title, written as "Lord" (capitalized) in English.

(See also: [God](#god), [Jesus](#jesus), [ruler](other.html#ruler), [Yahweh](#yahweh))

### Bible References:

* [Genesis 39:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/39/01.md)
* [Joshua 03:9-11](https://git.door43.org/Door43/en_tn/src/master/jos/03/09.md)
* [Psalms 086:15-17](https://git.door43.org/Door43/en_tn/src/master/psa/086/015.md)
* [Jeremiah 27:1-4](https://git.door43.org/Door43/en_tn/src/master/jer/27/01.md)
* [Lamentations 02:1-2](https://git.door43.org/Door43/en_tn/src/master/lam/02/01.md)
* [Ezekiel 18:29-30](https://git.door43.org/Door43/en_tn/src/master/ezk/18/29.md)
* [Daniel 09:9-11](https://git.door43.org/Door43/en_tn/src/master/dan/09/09.md)
* [Daniel 09:17-19](https://git.door43.org/Door43/en_tn/src/master/dan/09/17.md)
* [Malachi 03:1-3](https://git.door43.org/Door43/en_tn/src/master/mal/03/01.md)
* [Matthew 07:21-23](https://git.door43.org/Door43/en_tn/src/master/mat/07/21.md)
* [Luke 01:30-33](https://git.door43.org/Door43/en_tn/src/master/luk/01/30.md)
* [Luke 16:13](https://git.door43.org/Door43/en_tn/src/master/luk/16/13.md)
* [Romans 06:22-23](https://git.door43.org/Door43/en_tn/src/master/rom/06/22.md)
* [Ephesians 06:9](https://git.door43.org/Door43/en_tn/src/master/eph/06/09.md)
* [Philippians 02:9-11](https://git.door43.org/Door43/en_tn/src/master/php/02/09.md)
* [Colossians 03:22-25](https://git.door43.org/Door43/en_tn/src/master/col/03/22.md)
* [Hebrews 12:14-17](https://git.door43.org/Door43/en_tn/src/master/heb/12/14.md)
* [James 02:1-4](https://git.door43.org/Door43/en_tn/src/master/jas/02/01.md)
* [1 Peter 01:3-5](https://git.door43.org/Door43/en_tn/src/master/1pe/01/03.md)
* [Jude 01:5-6](https://git.door43.org/Door43/en_tn/src/master/jud/01/05.md)
* [Revelation 15:3-4](https://git.door43.org/Door43/en_tn/src/master/rev/15/03.md)

### Examples from the Bible stories:

* __[25:05](https://git.door43.org/Door43/en_tn/src/master/obs/25/05.md)__ But Jesus replied to Satan by quoting from the Scriptures. He said, "In God's word, he commands his people, 'Do not test the __Lord__  your God.'"
* __[25:07](https://git.door43.org/Door43/en_tn/src/master/obs/25/07.md)__ Jesus replied, "Get away from me, Satan! In God's word he commands his people, 'Worship only the __Lord__  your God and only serve him.'"
* __[26:03](https://git.door43.org/Door43/en_tn/src/master/obs/26/03.md)__ This is the year of the __Lord's__  favor.
* __[27:02](https://git.door43.org/Door43/en_tn/src/master/obs/27/02.md)__ The law expert replied that God's law says, "Love the __Lord__  your God with all your heart, soul, strength, and mind."
* __[31:05](https://git.door43.org/Door43/en_tn/src/master/obs/31/05.md)__ Then Peter said to Jesus, "__Master__, if it is you, command me to come to you on the water"
* __[43:09](https://git.door43.org/Door43/en_tn/src/master/obs/43/09.md)__ "But know for certain that God has caused Jesus to become both __Lord__  and Messiah!"
* __[47:03](https://git.door43.org/Door43/en_tn/src/master/obs/47/03.md)__ By means of this demon she predicted the future for people, she made a lot of money for her __masters__  as a fortuneteller.
* __[47:11](https://git.door43.org/Door43/en_tn/src/master/obs/47/11.md)__ Paul answered, "Believe in Jesus, the __Master__, and you and your family will be saved."


### Word Data:

* Strong's: H113, H136, H1167, H1376, H4756, H7980, H8323, G203, G634, G962, G1203, G2962


## <a id="tw-term-kt-lordssupper"/>Lord's Supper

### Definition:

The term "Lord's Supper" was used by the apostle Paul to refer to the Passover meal that Jesus ate with his disciples on the night he was arrested by the Jewish leaders. 

* During this meal, Jesus broke the Passover bread into pieces and called it his body, which would soon be beaten and killed.
* He called the cup of wine his blood, which would soon be spilled out as he died as a sacrifice for sin.
* Jesus commanded that as often as his followers shared this meal together, they should remember his death and resurrection.
* In his letter to the Corinthians, the apostle Paul also further established the Lord's Supper as a regular practice for believers in Jesus.
* Churches today often use the term "communion" to refer to the Lord's Supper. The term "Last Supper" is also sometimes used.

### Translation Suggestions:

* This term could also be translated as "the Lord's meal" or "the meal of our Lord Jesus" or "the meal in memory of the Lord Jesus."

(See also: [Passover](#passover))

### Bible References:

* [1 Corinthians 11:20-22](https://git.door43.org/Door43/en_tn/src/master/1co/11/20.md)
* [1 Corinthians 11:25-26](https://git.door43.org/Door43/en_tn/src/master/1co/11/25.md)

### Word Data:

* Strong's: G1173, G2960


## <a id="tw-term-kt-lordyahweh"/>Lord Yahweh, Yahweh God

### Facts:

In the Old Testament, "Lord Yahweh" is frequently used to refer to the one true God.

* The term "Lord" is a divine title and "Yahweh" is God's personal name.
* "Yahweh" is also often combined with the term "God" to form "Yahweh God."

### Translation Suggestions:

* If some form of "Yahweh" is used for the translation of God's personal name, the terms "Lord Yahweh" and "Yahweh God" can be translated literally. Also consider how the term "Lord" is translated in other contexts when referring to God.
* Some languages put titles after the name and would translate this as "Yahweh Lord." Consider what is natural in the project language: should the title "Lord" come before or after "Yahweh"?
* "Yahweh God" could also be rendered as "God who is called Yahweh" or "God who is the Living One" or "I am, who is God."
* If the translation follows the tradition of rendering "Yahweh" as "Lord" or "LORD," the term "Lord Yahweh" could be translated as "Lord God" or "God who is the Lord." Other possible translations could be, "Master LORD" or "God the LORD."
* The term "Lord Yahweh" _should not_ be rendered as "Lord LORD" because readers may not notice the difference in letter size that has traditionally been used to distinguish these two words and it would look very strange.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [God](#god), [lord](#lord), [Lord](#lord), [Yahweh](#yahweh))

### Bible References:

* [1 Corinthians 04:3-4](https://git.door43.org/Door43/en_tn/src/master/1co/04/03.md)
* [2 Samuel 07:21-23](https://git.door43.org/Door43/en_tn/src/master/2sa/07/21.md)
* [Deuteronomy 03:23-25](https://git.door43.org/Door43/en_tn/src/master/deu/03/23.md)
* [Ezekiel 39:25-27](https://git.door43.org/Door43/en_tn/src/master/ezk/39/25.md)
* [Ezekiel 45:18-20](https://git.door43.org/Door43/en_tn/src/master/ezk/45/18.md)
* [Jeremiah 44:26-28](https://git.door43.org/Door43/en_tn/src/master/jer/44/26.md)
* [Judges 06:22-24](https://git.door43.org/Door43/en_tn/src/master/jdg/06/22.md)
* [Micah 01:2-4](https://git.door43.org/Door43/en_tn/src/master/mic/01/02.md)

### Word Data:

* Strong's: H136, H430, H3068, G2316, G2962


## <a id="tw-term-kt-love"/>love, loves, loving, loved

### Definition:

To love another person is to care for that person and do things that will benefit him. There are different meanings for "love"  some languages may express using different words:

1. The kind of love that comes from God is focused on the good of others even when it doesn't benefit oneself. This kind of love cares for others, no matter what they do. God himself is love and is the source of true love.

* Jesus showed this kind of love by sacrificing his life in order to rescue us from sin and death. He also taught his followers to love others sacrificially.
* When people love others with this kind of love, they act in ways that show they are thinking of what will cause the others to thrive. This kind of love especially includes forgiving others.
* In the ULB, the word "love" refers to this kind of sacrificial love, unless a Translation Note indicates a different meaning.

2. Another word in the New Testament refers to brotherly love, or love for a friend or family member.

* This term refers to natural human love between friends or relatives.
* The term can also be used in such contexts as, "They love to sit in the most important seats at a banquet." This means that they "like very much" or "greatly desire" to do that.

3. The word "love" can also refer to romantic love between a man and a woman.

4. In the figurative expression "Jacob I have loved, but Esau I have hated," the term "loved" refers to God's choosing of Jacob to be in a covenant relationship with him. This could also be translated as "chosen." Although Esau was also blessed by God, he wasn't given the privilege of being in the covenant. The term "hated" is used figuratively here to mean "rejected" or "not chosen."

### Translation Suggestions:

* Unless indicated otherwise in a Translation Note, the word "love" in the ULB refers to the kind of sacrificial love that comes from God.
* Some languages may have a special word for the kind of unselfish, sacrificial love that God has. Ways to translate this might include, "devoted, faithful caring" or "care for unselfishly" or "love from God." Make sure that the word used to translate God's love can include giving up one's own interests to benefit others and loving others no matter what they do.
* Sometimes the English word "love" describes the deep caring that people have for friends and family members. Some languages might translate this with a word or phrase that means, "like very much" or "care for" or "have strong affection for."
* In contexts where the word "love" is used to express a strong preference for something, this could be translated by "strongly prefer" or "like very much" or "greatly desire."
* Some languages may also have a separate word that refers to romantic or sexual love between a husband and wife.
* Many languages must express "love" as an action. So for example, they might translate "love is patient, love is kind" as, "when a person loves someone, he is patient with him and kind to him."

(See also: [covenant](#covenant), [death](other.html#death), [sacrifice](other.html#sacrifice), [save](#save), [sin](#sin))

### Bible References:

* [1 Corinthians 13:4-7](https://git.door43.org/Door43/en_tn/src/master/1co/13/04.md)
* [1 John 03:1-3](https://git.door43.org/Door43/en_tn/src/master/1jn/03/01.md)
* [1 Thessalonians 04:9-12](https://git.door43.org/Door43/en_tn/src/master/1th/04/09.md)
* [Galatians 05:22-24](https://git.door43.org/Door43/en_tn/src/master/gal/05/22.md)
* [Genesis 29:15-18](https://git.door43.org/Door43/en_tn/src/master/gen/29/15.md)
* [Isaiah 56:6-7](https://git.door43.org/Door43/en_tn/src/master/isa/56/06.md)
* [Jeremiah 02:1-3](https://git.door43.org/Door43/en_tn/src/master/jer/02/01.md)
* [John 03:16-18](https://git.door43.org/Door43/en_tn/src/master/jhn/03/16.md)
* [Matthew 10:37-39](https://git.door43.org/Door43/en_tn/src/master/mat/10/37.md)
* [Nehemiah 09:32-34](https://git.door43.org/Door43/en_tn/src/master/neh/09/32.md)
* [Philippians 01:9-11](https://git.door43.org/Door43/en_tn/src/master/php/01/09.md)
* [Song of Solomon 01:1-4](https://git.door43.org/Door43/en_tn/src/master/sng/01/01.md)

### Examples from the Bible stories:

* __[27:02](https://git.door43.org/Door43/en_tn/src/master/obs/27/02.md)__ The law expert replied that God's law says, "__Love__  the Lord your God with all your heart, soul, strength, and mind. And __love__  your neighbor as yourself."
* __[33:08](https://git.door43.org/Door43/en_tn/src/master/obs/33/08.md)__ "The thorny ground is a person who hears God's word, but, as time passes, the cares, riches, and pleasures of life choke out his __love__  for God."
* __[36:05](https://git.door43.org/Door43/en_tn/src/master/obs/36/05.md)__ As Peter was talking, a bright cloud came down on top of them and a voice from the cloud said, "This is my Son whom I __love__."
* __[39:10](https://git.door43.org/Door43/en_tn/src/master/obs/39/10.md)__ "Everyone who __loves__  the truth listens to me."
* __[47:01](https://git.door43.org/Door43/en_tn/src/master/obs/47/01.md)__ She (Lydia) __loved__  and worshiped God.
* __[48:01](https://git.door43.org/Door43/en_tn/src/master/obs/48/01.md)__ When God created the world, everything was perfect. There was no sin. Adam and Eve __loved__  each other, and they __loved__  God.
* __[49:03](https://git.door43.org/Door43/en_tn/src/master/obs/49/03.md)__ He (Jesus) taught that you need to __love__  other people the same way you love yourself.
* __[49:04](https://git.door43.org/Door43/en_tn/src/master/obs/49/04.md)__ He (Jesus) also taught that you need to __love__  God more than you __love__  anything else, including your wealth.
* __[49:07](https://git.door43.org/Door43/en_tn/src/master/obs/49/07.md)__ Jesus taught that God __loves__  sinners very much.
* __[49:09](https://git.door43.org/Door43/en_tn/src/master/obs/49/09.md)__ But God __loved__  everyone in the world so much that he gave his only Son so that whoever believes in Jesus will not be punished for his sins, but will live with God forever.
* __[49:13](https://git.door43.org/Door43/en_tn/src/master/obs/49/13.md)__ God __loves__  you and wants you to believe in Jesus so he can have a close relationship with you.


### Word Data:

* Strong's: H157, H158, H159, H160, H2245, H2617, H2836, H3039, H4261, H5689, H5690, H5691, H7355, H7356, H7453, H7474, G25, G26, G5360, G5361, G5362, G5363, G5365, G5367, G5368, G5369, G5377, G5381, G5382, G5383, G5388


## <a id="tw-term-kt-majesty"/>majesty

### Definition:

The term "majesty" refers to greatness and splendor, often in relation to the qualities of a king.

* In the Bible, "majesty" frequently refers to the greatness of God, who is the supreme King over the universe.
* "Your Majesty" is a way of addressing a king.

### Translation Suggestions:

* This term could be translated as "kingly greatness" or "royal splendor."
* "Your Majesty" could be translated as something like "your Highness" or "your Excellency" or using a natural way of addressing a ruler in the target language.

(See also: [king](other.html#king))

### Bible References:

* [2 Peter 01:16-18](https://git.door43.org/Door43/en_tn/src/master/2pe/01/16.md)
* [Daniel 04:36-37](https://git.door43.org/Door43/en_tn/src/master/dan/04/36.md)
* [Isaiah 02:9-11](https://git.door43.org/Door43/en_tn/src/master/isa/02/09.md)
* [Jude 01:24-25](https://git.door43.org/Door43/en_tn/src/master/jud/01/24.md)
* [Micah 05:4-5](https://git.door43.org/Door43/en_tn/src/master/mic/05/04.md)

### Word Data:

* Strong's: H1347, H1348, H1420, H1923, H1926, H1935, H7238, G3168, G3172


## <a id="tw-term-kt-manna"/>manna

### Definition:

Manna was a white, grain-like food that God provided for the Israelites to eat during the 40 years of living in the wilderness after they left Egypt.

* Manna looked like white flakes which appeared each morning on the ground under the dew. It tasted sweet, like honey.
* The Israelites gathered the manna flakes every day except on the Sabbath.
* On the day before the Sabbath, God told the Israelites to gather twice the amount of manna so they wouldn't have to gather it on their day of rest.
* The word "manna" means "what is it?"
* In the Bible, manna is also referred to as "bread from heaven" and "grain from heaven."

### Translation Suggestions

* Other ways to translate this term could include "thin white flakes of food" or "food from heaven."
* Also consider how this term is translated in a Bible translation in a local or national language. (See: [How to Translate Unknowns](https://git.door43.org/Door43/en_man/src/master/translate/translate-unknown/01.md))

(See also: [bread](other.html#bread), [desert](other.html#desert), [grain](other.html#grain), [heaven](#heaven), [Sabbath](#sabbath))

### Bible References:

* [Deuteronomy 08:3](https://git.door43.org/Door43/en_tn/src/master/deu/08/03.md)
* [Exodus 16:26-27](https://git.door43.org/Door43/en_tn/src/master/exo/16/26.md)
* [Hebrews 09:3-5](https://git.door43.org/Door43/en_tn/src/master/heb/09/03.md)
* [John 06:30-31](https://git.door43.org/Door43/en_tn/src/master/jhn/06/30.md)
* [Joshua 05:12](https://git.door43.org/Door43/en_tn/src/master/jos/05/12.md)

### Word Data:

* Strong's: H4478, G3131


## <a id="tw-term-kt-mercy"/>mercy, merciful

### Definition:

The terms "mercy" and "merciful" refer to helping people who are in need, especially when they are in a lowly or humbled condition.

* The term "mercy" can also include the meaning of not punishing people for something they have done wrong.
* A powerful person such as a king is described as "merciful" when he treats people kindly instead of harming them.
* Being merciful also means to forgive someone who has done something wrong against us.
* We show mercy when we help people who are in great need.
* God is merciful to us, and he wants us to be merciful to others.

### Translation Suggestions:

* Depending on the context, "mercy" could be translated as "kindness" or "compassion" or "pity."
* The term "merciful" could be translated as "showing pity" or "being kind to" or "forgiving."
* To "show mercy to" or "have mercy on" could be translated as "treat kindly" or "be compassionate toward."

(See also: [compassion](#compassion), [forgive](#forgive))

### Bible References:

* [1 Peter 01:3-5](https://git.door43.org/Door43/en_tn/src/master/1pe/01/03.md)
* [1 Timothy 01:12-14](https://git.door43.org/Door43/en_tn/src/master/1ti/01/12.md)
* [Daniel 09:17-19](https://git.door43.org/Door43/en_tn/src/master/dan/09/17.md)
* [Exodus 34:5-7](https://git.door43.org/Door43/en_tn/src/master/exo/34/05.md)
* [Genesis 19:16-17](https://git.door43.org/Door43/en_tn/src/master/gen/19/16.md)
* [Hebrews 10:28-29](https://git.door43.org/Door43/en_tn/src/master/heb/10/28.md)
* [James 02:12-13](https://git.door43.org/Door43/en_tn/src/master/jas/02/12.md)
* [Luke 06:35-36](https://git.door43.org/Door43/en_tn/src/master/luk/06/35.md)
* [Matthew 09:27-28](https://git.door43.org/Door43/en_tn/src/master/mat/09/27.md)
* [Philippians 02:25-27](https://git.door43.org/Door43/en_tn/src/master/php/02/25.md)
* [Psalms 041:4-6](https://git.door43.org/Door43/en_tn/src/master/psa/041/004.md)
* [Romans 12:1-2](https://git.door43.org/Door43/en_tn/src/master/rom/12/01.md)

### Examples from the Bible stories:

* __[19:16](https://git.door43.org/Door43/en_tn/src/master/obs/19/16.md)__ They (the prophets) all told the people to stop worshiping idols and to start showing justice and __mercy__  to others.
* __[19:17](https://git.door43.org/Door43/en_tn/src/master/obs/19/17.md)__ He (Jeremiah) sank down into the mud that was in the bottom of the well, but then the king had __mercy__  on him and ordered his servants to pull Jeremiah out of the well before he died.
* __[20:12](https://git.door43.org/Door43/en_tn/src/master/obs/20/12.md)__ The Persian Empire was strong but __merciful__  to the people it conquered.
* __[27:11](https://git.door43.org/Door43/en_tn/src/master/obs/27/11.md)__ Then Jesus asked the law expert, "What do you think? Which one of the three men was a neighbor to the man who was robbed and beaten?" He replied, "The one who was __merciful__  to him."
* __[32:11](https://git.door43.org/Door43/en_tn/src/master/obs/32/11.md)__ But Jesus said to him, "No, I want you to go home and tell your friends and family about everything that God has done for you and how he has had __mercy__  on you."
* __[34:09](https://git.door43.org/Door43/en_tn/src/master/obs/34/09.md)__ "But the tax collector stood far away from the religious ruler, did not even look up to heaven. Instead, he pounded on his chest and prayed, 'God, please be __merciful__  to me because I am a sinner.'"

### Word Data:

* Strong's: H2551, H2603, H2604, H2616, H2617, H2623, H3722, H3727, H4627, H4819, H5503, H5504, H5505, H5506, H6014, H7349, H7355, H7356, H7359, G1653, G1655, G1656, G2433, G2436, G3628, G3629, G3741, G4698


## <a id="tw-term-kt-minister"/>to minister, ministry

### Definition:

In the Bible, the term "ministry" refers to serving others by teaching them about God and caring for their spiritual needs. 

* In the Old Testament, the priests would "minister" to God in the temple by offering sacrifices to him.
* Their "ministry" also included taking care of the temple and offering prayers to God on behalf of the people.
* The job of "ministering" to people can include serving them spiritually by teaching them about God.
* It can also refer to serving people in physical ways, such as caring for the sick and providing food for the poor.

### Translation Suggestions:

* In the context of ministering to people,  to "minister" could also be translated as to "serve" or to "care for" or to "meet the needs of."
* When referring to ministering in the temple, the term "minister" could be translated as "serve God in the temple" or "offer sacrifices to God for the people." 
* In the context of ministering to God, this could be translated as to "serve" or to "work for God."
* The phrase "ministered to" could also be translated as "took care of" or "provided for" or "helped."

(See also: [serve](other.html#serve), [sacrifice](other.html#sacrifice))

### Bible References:

* [2 Samuel 20:23-26](https://git.door43.org/Door43/en_tn/src/master/2sa/20/23.md)
* [Acts 06:2-4](https://git.door43.org/Door43/en_tn/src/master/act/06/02.md)
* [Acts 21:17-19](https://git.door43.org/Door43/en_tn/src/master/act/21/17.md)

### Word Data:

* Strong's: H6399, H8120, H8334, H8335, G1247, G1248, G1249, G2023, G2038, G2418, G3008, G3009, G3010, G3011, G3930, G5256, G5257, G5524


## <a id="tw-term-kt-miracle"/>miracle, miracles, wonder, wonders, sign, signs

### Definition:

A "miracle" is something amazing that is not possible unless God causes it to happen.

* Examples of miracles that Jesus did include calming a storm and healing a blind man.
* Miracles are sometimes called "wonders" because they cause people to be filled with wonder or amazement.
* The term "wonder" can also refer more generally to amazing displays of God's power, such as when he created the heavens and the earth.
* Miracles can also be called "signs" because they are used as indicators or evidence that God is the all-powerful one who has complete authority over the universe.
* Some miracles were God's acts of redemption, such as when he rescued the Israelites from being slaves in Egypt and when he protected Daniel from being hurt by lions.
* Other wonders were God's acts of judgment, such as when he sent a worldwide flood in Noah's time and when he brought terrible plagues on the land of Egypt during the time of Moses.
* Many of God's miracles were the physical healings of sick people or bringing dead people back to life.
* God's power was shown in Jesus when he healed people, calmed storms, walked on water, and raised people from the dead. These were all miracles.
* God also enabled the prophets and the apostles to perform miracles of healing and other things that were only possible through God's power.

### Translation Suggestions:

* Possible translations of "miracles" or "wonders" could include "impossible things that God does" or "powerful works of God" or "amazing acts of God."
* The frequent expression "signs and wonders" could be translated as "proofs and miracles" or "miraculous works that prove God's power" or "amazing miracles that show how great God is."
* Note that this meaning of a miraculous sign is different from a sign that gives proof or evidence for something. The two can be related.

(See also: [power](#power), [prophet](#prophet), [apostle](#apostle), [sign](#sign))

### Bible References:

* [2 Thessalonians 02:8-10](https://git.door43.org/Door43/en_tn/src/master/2th/02/08.md)
* [Acts 04:15-18](https://git.door43.org/Door43/en_tn/src/master/act/04/15.md)
* [Acts 04:21-22](https://git.door43.org/Door43/en_tn/src/master/act/04/21.md)
* [Daniel 04:1-3](https://git.door43.org/Door43/en_tn/src/master/dan/04/01.md)
* [Deuteronomy 13:1-3](https://git.door43.org/Door43/en_tn/src/master/deu/13/01.md)
* [Exodus 03:19-22](https://git.door43.org/Door43/en_tn/src/master/exo/03/19.md)
* [John 02:11](https://git.door43.org/Door43/en_tn/src/master/jhn/02/11.md)
* [Matthew 13:57-58](https://git.door43.org/Door43/en_tn/src/master/mat/13/57.md)

### Examples from the Bible stories:

* __[16:08](https://git.door43.org/Door43/en_tn/src/master/obs/16/08.md)__ Gideon asked God for two __signs__  so he could be sure that God would use him to save Israel.
* __[19:14](https://git.door43.org/Door43/en_tn/src/master/obs/19/14.md)__ God did many __miracles__  through Elisha.
* __[37:10](https://git.door43.org/Door43/en_tn/src/master/obs/37/10.md)__ Many of the Jews believed in Jesus because of this __miracle__.
* __[43:06](https://git.door43.org/Door43/en_tn/src/master/obs/43/06.md)__ "Men of Israel, Jesus was a man who did many mighty __signs__  and __wonders__  by the power of God, as you have seen and already know."
* __[49:02](https://git.door43.org/Door43/en_tn/src/master/obs/49/02.md)__ Jesus did many __miracles__  that prove he is God. He walked on water, calmed storms, healed many sick people, drove out demons, raised the dead to life, and turned five loaves of bread and two small fish into enough food for over 5,000 people.


### Word Data:

* Strong's: H226, H852, H2368, H2858, H4150, H4159, H4864, H5251, H5824, H5953, H6381, H6382, H6383, H6395, H6725, H7560, H7583, H8047, H8074, H8539, H8540,, G880, G1213, G1229, G1411, G1569, G1718, G1770, G1839, G2285, G2296, G2297, G3167, G3902, G4591, G4592, G5059


## <a id="tw-term-kt-mosthigh"/>Most High

### Facts:

The term "Most High" is a title for God. It refers to his greatness or authority.

* The meaning of this term is similar to the meaning of "Sovereign" or "Supreme."
* The word "high" in this title does not refer to physical height or distance. It refers to greatness.

### Translation Suggestions:

* This term can also be translated as "Most High God" or "Most Supreme being" or "God Most High" or "Greatest One" or "Supreme One" or "God, who is Greater than all."
* If a word like "high" is used, make sure it does not refer to being physically high or tall. 

(See also: [God](#god))

### Bible References:

* [Acts 07:47-50](https://git.door43.org/Door43/en_tn/src/master/act/07/47.md)
* [Acts 16:16-18](https://git.door43.org/Door43/en_tn/src/master/act/16/16.md)
* [Daniel 04:17-18](https://git.door43.org/Door43/en_tn/src/master/dan/04/17.md)
* [Deuteronomy 32:7-8](https://git.door43.org/Door43/en_tn/src/master/deu/32/07.md)
* [Genesis 14:17-18](https://git.door43.org/Door43/en_tn/src/master/gen/14/17.md)
* [Hebrews 07:1-3](https://git.door43.org/Door43/en_tn/src/master/heb/07/01.md)
* [Hosea 07:16](https://git.door43.org/Door43/en_tn/src/master/hos/07/16.md)
* [Lamentations 03:34-36](https://git.door43.org/Door43/en_tn/src/master/lam/03/34.md)
* [Luke 01:30-33](https://git.door43.org/Door43/en_tn/src/master/luk/01/30.md)

### Word Data:

* Strong's: H5945, G5310


## <a id="tw-term-kt-myrrh"/>myrrh

### Definition:

Myrrh is an oil or spice that is made from the resin of a myrrh tree that grows in Africa and Asia. It is related to frankincense.

* Myrrh was also used to make incense, perfume, and medicine, and to prepare dead bodies for burial.
* Myrrh was one of the gifts that the learned men gave to Jesus when he was born.
* Jesus was offered wine mixed with myrrh in order to ease the pain when he was crucified.

(See also: [frankincense](other.html#frankincense), [learned men](other.html#learnedmen))

### Bible References:

* [Exodus 30:22-25](https://git.door43.org/Door43/en_tn/src/master/exo/30/22.md)
* [Genesis 37:25-26](https://git.door43.org/Door43/en_tn/src/master/gen/37/25.md)
* [John 11:1-2](https://git.door43.org/Door43/en_tn/src/master/jhn/11/01.md)
* [Mark 15:22-24](https://git.door43.org/Door43/en_tn/src/master/mrk/15/22.md)
* [Matthew 02:11-12](https://git.door43.org/Door43/en_tn/src/master/mat/02/11.md)

### Word Data:

* Strong's: H3910, H4753, G3464, G4666, G4669


## <a id="tw-term-kt-name"/>name, names, named

### Definition:

In the Bible, the word "name" was used in several figurative ways.

* In some contexts, "name" could refer to a person's reputation, as in "let us make a name for ourselves."
* The term "name" could also refer to the memory of something. For example, "cut off the names of the idols" means to destroy those idols so that they are no longer remembered or worshiped.
* Speaking "in the name of God" meant speaking with his power and authority, or as his representative.
* The "name" of someone could refer to the entire person, as in "there is no other name under heaven by which we must be saved." (See: [metonymy](https://git.door43.org/Door43/en_man/src/master/translate/figs-metonymy/01.md))

### Translation Suggestions:

* An expression like "his good name" could be translated as "his good reputation."
* Doing something "in the name of" could be translated as "with the authority of" or "with the permission of" or "as the representative of" that person.
* The expression "make a name for ourselves" could be translated "cause many people to know about us" or "make people think we are very important."
* The expression "call his name" could be translated as "name him" or "give him the name."
* The expression "those who love your name" could be translated as "those who love you."
* The expression "cut off the names of idols" could be translated as "get rid of pagan idols so that they are not even remembered" or  "cause people to stop worshiping false gods" or "completely destroy all idols so that people no longer even think about them."

(See also: [call](#call))

### Bible References:

* [1 John 02:12-14](https://git.door43.org/Door43/en_tn/src/master/1jn/02/12.md)
* [2 Timothy 02:19-21](https://git.door43.org/Door43/en_tn/src/master/2ti/02/19.md)
* [Acts 04:5-7](https://git.door43.org/Door43/en_tn/src/master/act/04/05.md)
* [Acts 04:11-12](https://git.door43.org/Door43/en_tn/src/master/act/04/11.md)
* [Acts 09:26-27](https://git.door43.org/Door43/en_tn/src/master/act/09/26.md)
* [Genesis 12:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/12/01.md)
* [Genesis 35:9-10](https://git.door43.org/Door43/en_tn/src/master/gen/35/09.md)
* [Matthew 18:4-6](https://git.door43.org/Door43/en_tn/src/master/mat/18/04.md)


### Word Data:

* Strong's: H5344, H7121, H7761, H8034, H8036, G2564, G3686, G3687, G5122


## <a id="tw-term-kt-nazirite"/>Nazirite, Nazirites, Nazirite vow

### Facts:

The term "Nazirite" refers to a person who has taken a "Nazirite vow." Mostly men took this vow, but women could also take it.

* A person who took the Nazirite vow agreed to not have any food or drink made from grapes for period that had been agreed upon for the fulfillment of the vow. During this period he was also not to get his hair cut and not go near a dead body.
* When the required length of time had passed, and the vow had been fulfilled, the Nazirite would go to the priest and provide an offering. This would include the cutting and burning of his hair. All other restrictions would also be removed.
* Samson is a well-known man in the Old Testament who was under the Nazirite vow.
* The angel announcing John the Baptist's birth told Zechariah that his son would not drink strong drink, which may indicate that John was under the Nazirite vow.
* According to a passage in the book of Acts the apostle Paul may also have at one time taken this vow, according to one passage in the book of Acts.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [John (the Baptist)](names.html#johnthebaptist), [sacrifice](other.html#sacrifice), [Samson](names.html#samson), [vow](#vow), [Zechariah (OT)](names.html#zechariahot))

### Bible References:

* [Acts 18:18-19](https://git.door43.org/Door43/en_tn/src/master/act/18/18.md)
* [Amos 02:11-12](https://git.door43.org/Door43/en_tn/src/master/amo/02/11.md)
* [Judges 13:3-5](https://git.door43.org/Door43/en_tn/src/master/jdg/13/03.md)
* [Numbers 06:1-4](https://git.door43.org/Door43/en_tn/src/master/num/06/01.md)


### Word Data:

* Strong's: H5139


## <a id="tw-term-kt-parable"/>parable, parables

### Definition:

The term "parable" usually refers to a short story or object lesson that is used to explain or teach a moral truth.

* Jesus used parables to teach his disciples. Although he also told parables to the crowds of people, he did not always explain the parable.
* A parable could be used to reveal truth to his disciples while hiding that truth from people like the Pharisees who did not believe in Jesus.
* The prophet Nathan told David a parable to show the king his terrible sin.
* The story of the Good Samaritan is an example of a parable that is a story. Jesus' comparison of old and new wineskins is an example of a parable that was an object lesson to help the disciples understand Jesus' teachings.

(See also: [Samaria](names.html#samaria))

### Bible References:

* [Luke 05:36](https://git.door43.org/Door43/en_tn/src/master/luk/05/36.md)
* [Luke 06:39-40](https://git.door43.org/Door43/en_tn/src/master/luk/06/39.md)
* [Luke 08:4-6](https://git.door43.org/Door43/en_tn/src/master/luk/08/04.md)
* [Luke 08:9-10](https://git.door43.org/Door43/en_tn/src/master/luk/08/09.md)
* [Mark 04:1-2](https://git.door43.org/Door43/en_tn/src/master/mrk/04/01.md)
* [Matthew 13:3-6](https://git.door43.org/Door43/en_tn/src/master/mat/13/03.md)
* [Matthew 13:10-12](https://git.door43.org/Door43/en_tn/src/master/mat/13/10.md)
* [Matthew 13:13-14](https://git.door43.org/Door43/en_tn/src/master/mat/13/13.md)


### Word Data:

* Strong's: H1819, H4912, G3850, G3942


## <a id="tw-term-kt-passover"/>Passover

### Facts:

The "Passover" is the name of a religious festival that the Jews celebrate every year, to remember how God rescued their ancestors, the Israelites, from slavery in Egypt.

* The name of this festival comes from the fact that God "passed over" the houses of the Israelites and did not kill their sons when he killed the firstborn sons of the Egyptians.
* The Passover celebration includes a special meal of a perfect lamb that they have killed and roasted, as well as bread made without yeast. These foods remind them of the meal that the Israelites ate the night before they escaped from Egypt.
* God told the Israelites to eat this meal every year in order to remember and celebrate how God "passed over" their houses and how he set them free from slavery in Egypt.

### Translation Suggestions:

* The term "Passover" could be translated by combining the words "pass" and "over" or another combination of words that has this meaning.
* It is helpful if the name of this festival has a clear connection to the words used to explain what the angel of the Lord did in passing by the houses of the Israelites and sparing their sons.

### Bible References:

* [1 Corinthians 05:6-8](https://git.door43.org/Door43/en_tn/src/master/1co/05/06.md)
* [2 Chronicles 30:13-15](https://git.door43.org/Door43/en_tn/src/master/2ch/30/13.md)
* [2 Kings 23:21-23](https://git.door43.org/Door43/en_tn/src/master/2ki/23/21.md)
* [Deuteronomy 16:1-2](https://git.door43.org/Door43/en_tn/src/master/deu/16/01.md)
* [Exodus 12:26-28](https://git.door43.org/Door43/en_tn/src/master/exo/12/26.md)
* [Ezra 06:21-22](https://git.door43.org/Door43/en_tn/src/master/ezr/06/21.md)
* [John 13:1-2](https://git.door43.org/Door43/en_tn/src/master/jhn/13/01.md)
* [Joshua 05:10-11](https://git.door43.org/Door43/en_tn/src/master/jos/05/10.md)
* [Leviticus 23:4-6](https://git.door43.org/Door43/en_tn/src/master/lev/23/04.md)
* [Numbers 09:1-3](https://git.door43.org/Door43/en_tn/src/master/num/09/01.md)

### Examples from the Bible stories:

* __[12:14](https://git.door43.org/Door43/en_tn/src/master/obs/12/14.md)__ God commanded the Israelites to remember his victory over the Egyptians and their deliverance from slavery by celebrating the __Passover__  every year.
* __[38:01](https://git.door43.org/Door43/en_tn/src/master/obs/38/01.md)__ Every year, the Jews celebrated the __Passover__. This was a celebration of how God had saved their ancestors from slavery in Egypt many centuries earlier.
* __[38:04](https://git.door43.org/Door43/en_tn/src/master/obs/38/04.md)__ Jesus celebrated the __Passover__  with his disciples.
* __[48:09](https://git.door43.org/Door43/en_tn/src/master/obs/48/09.md)__ When God saw the blood, he passed over their houses and did not kill their firstborn sons. This event is called the __Passover__.
* __[48:10](https://git.door43.org/Door43/en_tn/src/master/obs/48/10.md)__ Jesus is our __Passover__  Lamb. He was perfect and sinless and was killed at the time of the __Passover__  celebration.

### Word Data:

* Strong's: H6453, G3957


## <a id="tw-term-kt-pastor"/>pastor, pastors

### Definition:

The term "pastor" is literally the same word as "shepherd." It is used as a title for someone who is the spiritual leader for a group of believers.

* In English Bible versions, "pastor" only occurs one time, in the book of Ephesians. It is the same word as is translated as "shepherd" elsewhere.
* In some languages, the word for "pastor" is the same as the word for "shepherd."
* It is also the same word as is used to refer to Jesus as the "good Shepherd."

### Translation Suggestions:

* It is best to translate this term with the word for "shepherd" in the project language.
* Other ways to translate this term could include "spiritual shepherd" or "shepherding Christian leader."
 

(See also: [shepherd](other.html#shepherd), [sheep](other.html#sheep))

### Bible References:

* [Ephesians 04:11-13](https://git.door43.org/Door43/en_tn/src/master/eph/04/11.md)


### Word Data:

* Strong's: H7462, G4166


## <a id="tw-term-kt-pentecost"/>Pentecost, Festival of Weeks

### Facts:

The "Festival of Weeks" was a Jewish festival that took place fifty days after Passover. It was later referred to as "Pentecost."

* The Feast of Weeks was seven weeks (fifty days) after the Feast of Firstfruits. In the New Testament times, this festival was called "Pentecost" which has "fifty" as part of its meaning.
* The Festival of Weeks was held to celebrate the beginning of the grain harvest. It was also a time to remember when God first gave the Law to the Israelites on the tablets of stone given to Moses.
* In the New Testament, the Day of Pentecost is especially significant because it was when the believers of Jesus received the Holy Spirit in a new way.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [festival](other.html#festival), [firstfruits](other.html#firstfruit), [harvest](other.html#harvest), [Holy Spirit](#holyspirit), [raise](other.html#raise))

### Bible References:

* [2 Chronicles 08:12-13](https://git.door43.org/Door43/en_tn/src/master/2ch/08/12.md)
* [Acts 02:1-4](https://git.door43.org/Door43/en_tn/src/master/act/02/01.md)
* [Acts 20:15-16](https://git.door43.org/Door43/en_tn/src/master/act/20/15.md)
* [Deuteronomy 16:16-17](https://git.door43.org/Door43/en_tn/src/master/deu/16/16.md)
* [Numbers 28:26-28](https://git.door43.org/Door43/en_tn/src/master/num/28/26.md)

### Word Data:

* Strong's: H2282, H7620, G4005


## <a id="tw-term-kt-peopleofgod"/>people of God, my people

### Definition:

The term "people of God" refers to people whom God has called out from the world to have a special relationship with him.

* When God says "my people" he is talking about the people whom he has chosen and who have a relationship with him.
* God's people are chosen by him and are set apart from the world to live in a way that is pleasing to him. He also calls them his children.
* In the Old Testament, "people of God" refers to the nation of Israel which was chosen by God and set apart from among the other nations of the world to serve and obey him.
* In the New Testament, "people of God" especially refers to all those who believe in Jesus and are called the Church. This includes both Jews and Gentiles.

### Translation Suggestions:

* The term "people of God" could be translated as "God's people" or "the people who worship God" or "people who serve God" or "people who belong to God."
* When God says "my people" other ways to translate it could include "the people I have chosen" or "the people who worship me" or "the people who belong to me."
* Similarly, "your people"  could be translated as "the people who belong to you" or "the people you chose to belong to you."
* Also "his people" could be translated as "the people who belong to him" or "the people God chose to belong to himself."

(See also: [Israel](#israel), [people group](other.html#peoplegroup))

### Bible References:

* [1 Chronicles 11:1-3](https://git.door43.org/Door43/en_tn/src/master/1ch/11/01.md)
* [Acts 07:33-34](https://git.door43.org/Door43/en_tn/src/master/act/07/33.md)
* [Acts 07:51-53](https://git.door43.org/Door43/en_tn/src/master/act/07/51.md)
* [Acts 10:36-38](https://git.door43.org/Door43/en_tn/src/master/act/10/36.md)
* [Daniel 09:24-25](https://git.door43.org/Door43/en_tn/src/master/dan/09/24.md)
* [Isaiah 02:5-6](https://git.door43.org/Door43/en_tn/src/master/isa/02/05.md)
* [Jeremiah 06:20-22](https://git.door43.org/Door43/en_tn/src/master/jer/06/20.md)
* [Joel 03:16-17](https://git.door43.org/Door43/en_tn/src/master/jol/03/16.md)
* [Micah 06:3-5](https://git.door43.org/Door43/en_tn/src/master/mic/06/03.md)
* [Revelation 13:7-8](https://git.door43.org/Door43/en_tn/src/master/rev/13/07.md)

### Word Data:

* Strong's: H430, H5971, G2316, G2992


## <a id="tw-term-kt-perish"/>perish, perished, perishing, perishable

### Definition:

The term "perish" means to die or be destroyed, usually as the result of violence or other disaster. In the Bible, it especially has the meaning of being punished for eternity in hell.

* People who are "perishing" are those who are destined for hell because they have refused to believe in Jesus for their salvation.
* John 3:16 teaches that "perish" means to not live eternally in heaven.

### Translation Suggestions:

* Depending on the context, ways to translate this term could include "die eternally" or "be punished in hell" or "be destroyed."
* Make sure that the translation of "perish" can mean living eternally in hell and does not only mean "cease to exist."

(See also: [death](other.html#death), [everlasting](#eternity))

### Bible References:

* [1 Peter 01:22-23](https://git.door43.org/Door43/en_tn/src/master/1pe/01/22.md)
* [2 Corinthians 02:16-17](https://git.door43.org/Door43/en_tn/src/master/2co/02/16.md)
* [2 Thessalonians 02:8-10](https://git.door43.org/Door43/en_tn/src/master/2th/02/08.md)
* [Jeremiah 18:18-20](https://git.door43.org/Door43/en_tn/src/master/jer/18/18.md)
* [Psalms 049:18-20](https://git.door43.org/Door43/en_tn/src/master/psa/049/018.md)
* [Zechariah 09:5-7](https://git.door43.org/Door43/en_tn/src/master/zec/09/05.md)
* [Zechariah 13:8-9](https://git.door43.org/Door43/en_tn/src/master/zec/13/08.md)


### Word Data:

* Strong's: H6, H7, H8, H1478, H1820, H5486, H5595, H6544, H8045, G599, G622, G684, G853, G1311, G2704, G4881, G5356


## <a id="tw-term-kt-pharisee"/>Pharisee, Pharisees

### Facts:

The Pharisees were an important, powerful group of Jewish religious leaders in Jesus' time.

* Many of them were middle class businessmen and some of them were also priests.
* Of all the Jewish leaders, the Pharisees were the most strict in obeying the Laws of Moses and other Jewish laws and traditions.
* They were very concerned about keeping the Jewish people separated from the influence of the Gentiles around them. The name "Pharisee" comes from the word to "separate."
* The Pharisees believed in life after death; they also believed in the existence of angels and other spiritual beings.
* The Pharisees and Sadducees actively opposed Jesus and the early Christians.

(See also: [council](other.html#council), [Jewish leaders](other.html#jewishleaders), [law](#lawofmoses), [Sadducee](#sadducee))

### Bible References:

* [Acts 26:4-5](https://git.door43.org/Door43/en_tn/src/master/act/26/04.md)
* [John 03:1-2](https://git.door43.org/Door43/en_tn/src/master/jhn/03/01.md)
* [Luke 11:43-44](https://git.door43.org/Door43/en_tn/src/master/luk/11/43.md)
* [Matthew 03:7-9](https://git.door43.org/Door43/en_tn/src/master/mat/03/07.md)
* [Matthew 05:19-20](https://git.door43.org/Door43/en_tn/src/master/mat/05/19.md)
* [Matthew 09:10-11](https://git.door43.org/Door43/en_tn/src/master/mat/09/10.md)
* [Matthew 12:1-2](https://git.door43.org/Door43/en_tn/src/master/mat/12/01.md)
* [Matthew 12:38-40](https://git.door43.org/Door43/en_tn/src/master/mat/12/38.md)
* [Philippians 03:4-5](https://git.door43.org/Door43/en_tn/src/master/php/03/04.md)


### Word Data:

* Strong's: G5330


## <a id="tw-term-kt-power"/>power, powers

### Definition:

The term "power" refers to the ability to do things or make things happen, often using great strength. "Powers" refers to people or spirits who have great ability to cause things to happen.

* The "power of God" refers to God's ability to do everything, especially things that are not possible for people to do.
* God has complete power over everything that he has created.
* God gives his people power to do what he wants, so that when they heal people or do other miracles, they do this by the power of God.
* Because Jesus and the Holy Spirit are also God, they have this same power.

### Translation Suggestions:

* Depending on the context, the term "power" could also be translated as "ability" or "strength" or "energy" or "ability to do miracles" or "control."
* Possible ways to translate the term "powers" could include "powerful beings" or "controlling spirits" or "those who control others."
* An expression like "save us from the power of our enemies" could be translated as "save us from being oppressed by our enemies" or "rescue us from being controlled by our enemies." In this case, "power" has the meaning of using one's strength to control and oppress others.

(See also: [Holy Spirit](#holyspirit), [Jesus](#jesus), [miracle](#miracle))

### Bible References:

* [1 Thessalonians 01:4-5](https://git.door43.org/Door43/en_tn/src/master/1th/01/04.md)
* [Colossians 01:11-12](https://git.door43.org/Door43/en_tn/src/master/col/01/11.md)
* [Genesis 31:29-30](https://git.door43.org/Door43/en_tn/src/master/gen/31/29.md)
* [Jeremiah 18:21-23](https://git.door43.org/Door43/en_tn/src/master/jer/18/21.md)
* [Jude 01:24-25](https://git.door43.org/Door43/en_tn/src/master/jud/01/24.md)
* [Judges 02:18-19](https://git.door43.org/Door43/en_tn/src/master/jdg/02/18.md)
* [Luke 01:16-17](https://git.door43.org/Door43/en_tn/src/master/luk/01/16.md)
* [Luke 04:14-15](https://git.door43.org/Door43/en_tn/src/master/luk/04/14.md)
* [Matthew 26:62-64](https://git.door43.org/Door43/en_tn/src/master/mat/26/62.md)
* [Philippians 03:20-21](https://git.door43.org/Door43/en_tn/src/master/php/03/20.md)
* [Psalm 080:1-3](https://git.door43.org/Door43/en_tn/src/master/psa/080/001.md)

### Examples from the Bible stories:

* __[22:05](https://git.door43.org/Door43/en_tn/src/master/obs/22/05.md)__ The angel explained, "The Holy Spirit will come to you, and the __power__  of God will overshadow you. So the baby will be holy, the Son of God."
* __[26:01](https://git.door43.org/Door43/en_tn/src/master/obs/26/01.md)__ After overcoming Satan's temptations, Jesus returned in the __power__  of the Holy Spirit to the region of Galilee where he lived.
* __[32:15](https://git.door43.org/Door43/en_tn/src/master/obs/32/15.md)__ Immediately Jesus realized that __power__  had gone out from him.
* __[42:11](https://git.door43.org/Door43/en_tn/src/master/obs/42/11.md)__ Forty days after Jesus rose from the dead, he told his disciples, "Stay in Jerusalem until my Father gives you __power__  when the Holy Spirit comes on you."
* __[43:06](https://git.door43.org/Door43/en_tn/src/master/obs/43/06.md)__ "Men of Israel, Jesus was a man who did many mighty signs and wonders by the __power__  of God, as you have seen and already know."
* __[44:08](https://git.door43.org/Door43/en_tn/src/master/obs/44/08.md)__ Peter answered them, "This man stands before you healed by the __power__  of Jesus the Messiah."

### Word Data:

* Strong's: H410, H1369, H2220, H2428, H2429, H2632, H3027, H3028, H3581, H4475, H4910, H5794, H5797, H5808, H6184, H7786, H7980, H7981, H7983, H7989, H8280, H8592, H8633, G1411, G1415, G1756, G1849, G1850, G2478, G2479, G2904, G3168


## <a id="tw-term-kt-pray"/>pray, prayer, prayers, prayed

### Definition:

The terms "pray" and "prayer" refer to talking with God. These terms are used to refer to people trying to talk to a false god.

* People can pray silently, talking to God with their thoughts, or they can pray aloud, speaking to God with their voice. Sometimes prayers are written down, such as when David wrote his prayers in the Book of Psalms.
* Prayer can include asking God for mercy, for help with a problem, and for wisdom in making decisions.
* Often people ask God to heal people who are sick or who need his help in other ways. 
* People also thank and praise God when they are praying to him.
* Praying includes confessing our sins to God and asking him to forgive us.
* Talking to God is sometimes called "communing" with him as our spirit communicates with his spirit, sharing our emotions and enjoying his presence.
* This term could be translated as "talking to God" or "communicating with God." The translation of this term should be able to include praying that is silent.

(See also: [false god](#falsegod), [forgive](#forgive), [praise](other.html#praise))

### Bible References:

* [1 Thessalonians 03:8-10](https://git.door43.org/Door43/en_tn/src/master/1th/03/08.md)
* [Acts 08:24](https://git.door43.org/Door43/en_tn/src/master/act/08/24.md)
* [Acts 14:23-26](https://git.door43.org/Door43/en_tn/src/master/act/14/23.md)
* [Colossians 04:2-4](https://git.door43.org/Door43/en_tn/src/master/col/04/02.md)
* [John 17:9-11](https://git.door43.org/Door43/en_tn/src/master/jhn/17/09.md)
* [Luke 11:1](https://git.door43.org/Door43/en_tn/src/master/luk/11/01.md)
* [Matthew 05:43-45](https://git.door43.org/Door43/en_tn/src/master/mat/05/43.md)
* [Matthew 14:22-24](https://git.door43.org/Door43/en_tn/src/master/mat/14/22.md)

### Examples from the Bible stories:

  __*[06:05](https://git.door43.org/Door43/en_tn/src/master/obs/06/05.md)__  Isaac __prayed__ for Rebekah, and God allowed her to get pregnant with twins.
  __*[13:12](https://git.door43.org/Door43/en_tn/src/master/obs/13/12.md)__  But Moses __prayed__ for them, and God listened to his __prayer__ and did not destroy them.
  __*[19:08](https://git.door43.org/Door43/en_tn/src/master/obs/19/08.md)__  Then the prophets of Baal __prayed__ to Baal, "Hear us, O Baal!"
  __*[21:07](https://git.door43.org/Door43/en_tn/src/master/obs/21/07.md)__  Priests also __prayed__ to God for the people.
  __*[38:11](https://git.door43.org/Door43/en_tn/src/master/obs/38/11.md)__  Jesus told his disciples to __pray__ that they would not enter into temptation.
  __*[43:13](https://git.door43.org/Door43/en_tn/src/master/obs/43/13.md)__ The disciples continually listened to the teaching of the apostles, spent time together, ate together, and __prayed__ with each other.
  __*[49:18](https://git.door43.org/Door43/en_tn/src/master/obs/49/18.md)__  God tells you to __pray__, to study his word, to worship him with other Christians, and to tell others what he has done for you.


### Word Data:

* Strong's: H559, H577, H1156, H2470, H3863, H3908, H4994, H6279, H5315, H5375, H6293, H6419, H6739, H6963, H7121, H7592, H7878, H7879, H7881, H8034, H8605, G154, G1162, G1189, G1783, G2065, G2171, G2172, G3870, G4335, G4336


## <a id="tw-term-kt-predestine"/>predestine, predestined

### Definition:

The terms "predestine" and "predestined" refer to deciding or planning beforehand that something will happen.

* This term especially refers to God predestining people to receive eternal life.
* Sometimes the word "foreordain" is used, which also means to decide beforehand.

### Translation Suggestions:

* The term "predestine" could also be translated as "decide before" or "decide ahead of time."
* The term "predestined" could be translated as "decided long ago" or "planned ahead of time" or "decided beforehand."
* A phrase such as "predestined us" could be translated as "decided long ago that we" or "already decided ahead of time that we."
* Note that the translation of this term should be different from the translation of the term "foreknew."

(See also: [foreknew](other.html#foreordain))

### Bible References:

* [1 Corinthians 02:6-7](https://git.door43.org/Door43/en_tn/src/master/1co/02/06.md)

### Word Data:

* Strong's: G4309


## <a id="tw-term-kt-priest"/>priest, priests, priesthood

### Definition:

In the Bible, a priest was someone who was chosen to offer sacrifices to God on behalf of God's people. The "priesthood" was the name for the office or condition of being a priest.

* In the Old Testament, God chose Aaron and his descendants to be his priests for the people of Israel.
* The "priesthood" was a right and a responsibility that was passed down from father to son in the Levite clan.
* The Israelite priests had the responsibility of offering the people's sacrifices to God, along with other duties in the temple.
* Priests also offered regular prayers to God on behalf of his people and performed other religious rites.
* The priests pronounced formal blessings on people and taught them God's laws.
* In Jesus' time, there were different levels of priests, including the chief priests and the high priest.
* Jesus is our "great high priest" who intercedes for us in God's presence. He offered himself as the ultimate sacrifice for sin. This means that the sacrifices made by human priests are no longer needed.
* In the New Testament, every believer in Jesus is called a "priest" who can come directly to God in prayer to intercede for himself and other people.
* In ancient times, there were also pagan priests who presented offerings to false gods such as Baal.

### Translation Suggestions:

* Depending on the context, the term "priest" could be translated as "sacrifice person" or "God's intermediary" or "sacrificial mediator" or "person God appoints to represent him."
* The translation of "priest" should be different from the translation of "mediator."
* Some translations may prefer to always say something like "Israelite priest" or "Jewish priest" or "Yahweh's priest" or "priest of Baal" to make it clear that this does not refer to a modern-day type of priest.
* The term used to translate "priest" should be different from the terms for "chief priest" and "high priest" and "Levite" and "prophet."

(See also: [Aaron](names.html#aaron), [chief priests](other.html#chiefpriests), [high priest](#highpriest), [mediator](other.html#mediator), [sacrifice](other.html#sacrifice))

### Bible References:

* [2 Chronicles 06:40-42](https://git.door43.org/Door43/en_tn/src/master/2ch/06/40.md)
* [Genesis 14:17-18](https://git.door43.org/Door43/en_tn/src/master/gen/14/17.md)
* [Genesis 47:20-22](https://git.door43.org/Door43/en_tn/src/master/gen/47/20.md)
* [John 01:19-21](https://git.door43.org/Door43/en_tn/src/master/jhn/01/19.md)
* [Luke 10:31-32](https://git.door43.org/Door43/en_tn/src/master/luk/10/31.md)
* [Mark 01:43-44](https://git.door43.org/Door43/en_tn/src/master/mrk/01/43.md)
* [Mark 02:25-26](https://git.door43.org/Door43/en_tn/src/master/mrk/02/25.md)
* [Matthew 08:4](https://git.door43.org/Door43/en_tn/src/master/mat/08/04.md)
* [Matthew 12:3-4](https://git.door43.org/Door43/en_tn/src/master/mat/12/03.md)
* [Micah 03:9-11](https://git.door43.org/Door43/en_tn/src/master/mic/03/09.md)
* [Nehemiah 10:28-29](https://git.door43.org/Door43/en_tn/src/master/neh/10/28.md)
* [Nehemiah 10:34-36](https://git.door43.org/Door43/en_tn/src/master/neh/10/34.md)
* [Revelation 01:4-6](https://git.door43.org/Door43/en_tn/src/master/rev/01/04.md)

### Examples from the Bible stories:

  __*[04:07](https://git.door43.org/Door43/en_tn/src/master/obs/04/07.md)__ "Melchizedek, the __priest__ of God Most High"
  __*[13:09](https://git.door43.org/Door43/en_tn/src/master/obs/13/09.md)__ Anyone who disobeyed God's law could bring an animal to the altar in front of the Tent of Meeting as a sacrifice to God. A __priest__ would kill the animal and burn it on the altar. The blood of the animal that was sacrificed covered the person's sin and made that person clean in God's sight. God chose Moses' brother, Aaron, and Aaron's descendants to be his __priests__.
  __*[19:07](https://git.door43.org/Door43/en_tn/src/master/obs/19/07.md)__ So the __priests__ of Baal prepared a sacrifice but did not light the fire.
  __*[21:07](https://git.door43.org/Door43/en_tn/src/master/obs/21/07.md)__ An Israelite __priest__ was someone who made sacrifices to God on behalf of the people as a substitute for the punishment of their sins. __Priests__ also prayed to God for the people.


### Word Data:

* Strong's: H3547, H3548, H3549, H3550, G748, G749, G2405, G2406, G2407, G2409, G2420


## <a id="tw-term-kt-promise"/>promise, promises, promised

### Definition:

A promise is a pledge to do a certain thing. When someone promises something, it means he is committing to do something.

* The Bible records many promises that God has made for his people.
* Promises are an important part of formal agreements such as covenants.
* A promise is often accompanied by an oath to confirm that it will be done.

### Translation Suggestions:

* The term "promise" could be translated as "commitment" or "assurance" or "guarantee."
* To "promise to do something" could be translated as "assure someone that you will do something" or "commit to doing something."

(See also: [covenant](#covenant), [oath](other.html#oath), [vow](#vow))

### Bible References:

* [Galatians 03:15-16](https://git.door43.org/Door43/en_tn/src/master/gal/03/15.md)
* [Genesis 25:31-34](https://git.door43.org/Door43/en_tn/src/master/gen/25/31.md)
* [Hebrews 11:8-10](https://git.door43.org/Door43/en_tn/src/master/heb/11/08.md)
* [James 01:12-13](https://git.door43.org/Door43/en_tn/src/master/jas/01/12.md)
* [Numbers 30:1-2](https://git.door43.org/Door43/en_tn/src/master/num/30/01.md)

### Examples from the Bible stories:

* __[03:15](https://git.door43.org/Door43/en_tn/src/master/obs/03/15.md)__ God said, "I __promise__  I will never again curse the ground because of the evil things people do, or destroy the world by causing a flood, even though people are sinful from the time they are children."Â�
* __[03:16](https://git.door43.org/Door43/en_tn/src/master/obs/03/16.md)__ God then made the first rainbow as a sign of his __promise__. Every time the rainbow appeared in the sky, God would remember what he __promised__  and so would his people.
* __[04:08](https://git.door43.org/Door43/en_tn/src/master/obs/04/08.md)__ God spoke to Abram and __promised__  again that he would have a son and as many descendants as the stars in the sky. Abram believed God's __promise__.
* __[05:04](https://git.door43.org/Door43/en_tn/src/master/obs/05/04.md)__ "Your wife, Sarai, will have a son—he will be the son of __promise__."
* __[08:15](https://git.door43.org/Door43/en_tn/src/master/obs/08/15.md)__ The covenant __promises__  that God gave to Abraham were passed on to Isaac, then to Jacob, and then to Jacob's twelve sons and their families.
* __[17:14](https://git.door43.org/Door43/en_tn/src/master/obs/17/14.md)__ Though David had been unfaithful to God, God was still faithful to his __promises__.
* __[50:01](https://git.door43.org/Door43/en_tn/src/master/obs/50/01.md)__ Jesus __promised__  he would return at the end of the world. Though he has not yet come back, he will keep his __promise__.

### Word Data:

* Strong's: H559, H562, H1696, H8569, G1843, G1860, G1861, G1862, G3670, G4279


## <a id="tw-term-kt-promisedland"/>Promised Land

### Facts:

The term "Promised Land" only occurs in the Bible stories, not the Bible text. It is an alternate way of referring to the land of Canaan which God had promised to give to Abraham and his descendants.

* When Abram was living in the city of Ur, God commanded him to go live in the land of Canaan. He and his descendants, the Israelites, lived there for many years.
* When a severe famine caused there to be no food in Canaan, the Israelites moved to Egypt.
* Four hundred years later, God rescued the Israelites from slavery in Egypt and brought them back to Canaan again, the land God had promised to give them.

### Translation Suggestions:

* The term "Promised Land" can be translated as the "land that God said he would give to Abraham" or "land that God promised to Abraham" or "land God promised to his people" or "land of Canaan."
* In the Bible text, this term occurs as some form of "the land God promised."

(See also: [Canaan](names.html#canaan), [promise](#promise))

### Bible References:

* [Deuteronomy 08:1-2](https://git.door43.org/Door43/en_tn/src/master/deu/08/01.md)
* [Ezekiel 07:26-27](https://git.door43.org/Door43/en_tn/src/master/ezk/07/26.md)

### Examples from the Bible stories:

* __[12:01](https://git.door43.org/Door43/en_tn/src/master/obs/12/01.md)__ They (Israelites) were no longer slaves, and they were going to the __Promised Land__!
* __[14:01](https://git.door43.org/Door43/en_tn/src/master/obs/14/01.md)__ After God had told the Israelites the laws he wanted them to obey as part of his covenant with them, God began leading them from Mount Sinai toward the __Promised Land__, which was also called Canaan.
* __[14:02](https://git.door43.org/Door43/en_tn/src/master/obs/14/02.md)__ God had promised Abraham, Isaac, and Jacob that he would give the __Promised Land__  to their descendants, but now there were many people groups living there.
* __[14:14](https://git.door43.org/Door43/en_tn/src/master/obs/14/14.md)__ Then God led the people to the edge of the __Promised Land__  again.
* __[15:02](https://git.door43.org/Door43/en_tn/src/master/obs/15/02.md)__ The Israelites had to cross the Jordan River to enter into the __Promised Land__.
* __[15:12](https://git.door43.org/Door43/en_tn/src/master/obs/15/12.md)__ After this battle, God gave each tribe of Israel its own section of the __Promised Land__.
* __[20:09](https://git.door43.org/Door43/en_tn/src/master/obs/20/09.md)__ This period of time when God's people were forced to leave the __Promised Land__  is called the Exile.


### Word Data:

* Strong's: H776, H3068, H3423, H5159, H5414, H7650


## <a id="tw-term-kt-prophet"/>prophet, prophets, prophecy, prophesy, seer, prophetess

### Definition:

A "prophet" is a man who speaks God's messages to people. A woman who does this is called a  "prophetess." 

* Often prophets warned people to turn away from their sins and obey God.
* A "prophecy" is the message that the prophet speaks. To "prophesy" means to speak God's messages.
* Often the message of a prophecy was about something that would happen in the future.
* Many prophecies in the Old Testament have already been fulfilled.
* In the Bible the collection of books written by prophets are sometimes referred to as "the prophets."
* For example the phrase, "the law and the prophets" is a way of referring to all the Hebrew scriptures, which are also known as the "Old Testament."
* An older term for a  prophet was "seer" or "someone who sees."
* Sometimes the term "seer" refers to a false prophet or to someone who practices divination.

### Translation Suggestions:

* The term "prophet" could be translated as "God's spokesman" or "man who speaks for God" or "man who speaks God's messages."
* A "seer" could be translated as, "person who sees visions" or "man who sees the future from God."
* The term "prophetess" could be translated as, "spokeswoman for God" or "woman who speaks for God" or "woman who speaks God's messages."
* Ways to translate "prophecy" could include, "message from God" or "prophet message."
* The term "prophesy" could be translated as "speak words from God" or "tell God's message."
* The figurative expression, "law and the prophets" could also be translated as, "the books of the law and of the prophets" or "everything written about God and his people, including God's laws and what his prophets preached." (See: [synecdoche](https://git.door43.org/Door43/en_man/src/master/translate/figs-synecdoche/01.md))
* When referring to a prophet (or seer) of a false god, it may be necessary to translate this as "false prophet (seer)" or "prophet (seer) of a false god" or "prophet of Baal," for example.
 

(See also: [Baal](names.html#baal), [divination](other.html#divination), [false god](#falsegod), [false prophet](other.html#falseprophet), [fulfill](#fulfill), [law](#lawofmoses), [vision](other.html#vision))

### Bible References:

* [1 Thessalonians 02:14-16](https://git.door43.org/Door43/en_tn/src/master/1th/02/14.md)
* [Acts 03:24-26](https://git.door43.org/Door43/en_tn/src/master/act/03/24.md)
* [John 01:43-45](https://git.door43.org/Door43/en_tn/src/master/jhn/01/43.md)
* [Malachi 04:4-6](https://git.door43.org/Door43/en_tn/src/master/mal/04/04.md)
* [Matthew 01:22-23](https://git.door43.org/Door43/en_tn/src/master/mat/01/22.md)
* [Matthew 02:17-18](https://git.door43.org/Door43/en_tn/src/master/mat/02/17.md)
* [Matthew 05:17-18](https://git.door43.org/Door43/en_tn/src/master/mat/05/17.md)
* [Psalm 051:1-2](https://git.door43.org/Door43/en_tn/src/master/psa/051/001.md)

### Examples from the Bible stories:

* __[12:12](https://git.door43.org/Door43/en_tn/src/master/obs/12/12.md)__ When the Israelites saw that the Egyptians were dead, they trusted in God and believed that Moses was a __prophet__  of God.
* __[17:13](https://git.door43.org/Door43/en_tn/src/master/obs/17/13.md)__ God was very angry about what David had done, so he sent the __prophet__  Nathan to tell David how evil his sin was.
* __[19:01](https://git.door43.org/Door43/en_tn/src/master/obs/19/01.md)__ Throughout the history of the Israelites, God sent them __prophets__. The __prophets__  heard messages from God and then told the people God's messages.
* __[19:06](https://git.door43.org/Door43/en_tn/src/master/obs/19/06.md)__ All the people of the entire kingdom of Israel, including the 450 __prophets__  of Baal, came to Mount Carmel.
* __[19:17](https://git.door43.org/Door43/en_tn/src/master/obs/19/17.md)__ Most of the time, the people did not obey God. They often mistreated the __prophets__  and sometimes even killed them.
* __[21:09](https://git.door43.org/Door43/en_tn/src/master/obs/21/09.md)__ The __prophet__  Isaiah __prophesied__  that the Messiah would be born from a virgin.
* __[43:05](https://git.door43.org/Door43/en_tn/src/master/obs/43/05.md)__ "This fulfills the __prophecy__  made by the __prophet__  Joel in which God said, 'In the last days, I will pour out my Spirit.'"
* __[43:07](https://git.door43.org/Door43/en_tn/src/master/obs/43/07.md)__ "This fulfills the __prophecy__  which says, 'You will not let your Holy One rot in the grave.'"
* __[48:12](https://git.door43.org/Door43/en_tn/src/master/obs/48/12.md)__ Moses was a great __prophet__  who proclaimed the word of God. But Jesus is the greatest __prophet__  of all. He is the Word of God.
*


### Word Data:

* Strong's: H2372, H2374, H4853, H5012, H5013, H5016, H5017, H5029, H5030, H5031, H5197, G2495, G4394, G4395, G4396, G4397, G4398, G5578


## <a id="tw-term-kt-propitiation"/>propitiation

### Definition:

The term "propitiation" refers to a sacrifice that is made to satisfy or fulfill the justice of God and to appease his wrath.

* The offering of the sacrificial blood of Jesus Christ is the propitiation to God for mankind's sins.
* Jesus' death on the cross appeased God's wrath against sin. This provided a way for God to look on people with favor and offer them eternal life.

### Translation Suggestions:

* This term could be translated as "appeasement" or "causing God to forgive sins and grant favor to people."
* The word "atonement" is close in meaning to "propitiation." It is important to compare how these two terms are used.

(See also: [atonement](#atonement), [everlasting](#eternity), [forgive](#forgive), [sacrifice](other.html#sacrifice))

### Bible References:

* [1 John 02:1-3](https://git.door43.org/Door43/en_tn/src/master/1jn/02/01.md)
* [1 John 04:9-10](https://git.door43.org/Door43/en_tn/src/master/1jn/04/09.md)
* [Romans 03:25-26](https://git.door43.org/Door43/en_tn/src/master/rom/03/25.md)

### Word Data:

* Strong's: G2434, G2435


## <a id="tw-term-kt-psalm"/>psalm, psalms

### Definition:

The term "psalm" refers to a sacred song, often in the form of a poem that was written to be sung.

* The Old Testament Book of Psalms has a collection of these songs written by King David and other Israelites such as Moses, Solomon, and Asaph, among others.
* The psalms were used by the nation of Israel in their worship of God.
* Psalms can be used to express joy, faith, and reverence, as well as pain and sorrow.
* In the New Testament, Christians are instructed to sing psalms to God as a way of worshiping him.

(See also: [David](names.html#david), [faith](#faith), [joy](other.html#joy), [Moses](names.html#moses), [holy](#holy))

### Bible References:

* [Acts 13:32-34](https://git.door43.org/Door43/en_tn/src/master/act/13/32.md)
* [Acts 13:35-37](https://git.door43.org/Door43/en_tn/src/master/act/13/35.md)
* [Colossians 03:15-17](https://git.door43.org/Door43/en_tn/src/master/col/03/15.md)
* [Luke 20:41-44](https://git.door43.org/Door43/en_tn/src/master/luk/20/41.md)


### Word Data:

* Strong's: H2158, H2167, H2172, H4210, G5567, G5568


## <a id="tw-term-kt-purify"/>pure, purify, purification

### Definition:

To be "pure" means to have no flaw or to have nothing mixed in that is not supposed to be there. To purify something is to cleanse it and remove anything that contaminates or pollutes it.

* In regard to Old Testament laws, "purify" and "purification" refer mainly to the cleansing from things that make an object or a person ritually unclean, such as disease, body fluids, or childbirth.
* The Old Testament also had laws telling people how to be purified from sin, usually by the sacrifice of an animal. This was only temporary and the sacrifices had to be repeated over and over again.
* In the New Testament, to be purified often refers to being cleansed from sin.
* The only way that people can be completely and permanently purified from sin is through repenting and receiving God's forgiveness, through trusting in Jesus and his sacrifice.

### Translation Suggestions:

* The term "purify" could be translated as "make pure" or "cleanse" or "cleanse from all contamination" or "get rid of all sin."
* A phrase such as "when the time for their purification was over" could be translated as "when they had purified themselves by waiting the required number of days."
* The phrase "provided purification for sins" could be translated as "provided a way for people to be completely cleansed from their sin."
* Other ways to translate "purification" could include "cleansing" or "spiritual washing" or "becoming ritually clean."

(See also: [atonement](#atonement), [clean](#clean), [spirit](#spirit))

### Bible References:

* [1 Timothy 01:5-8](https://git.door43.org/Door43/en_tn/src/master/1ti/01/05.md)
* [Exodus 31:6-9](https://git.door43.org/Door43/en_tn/src/master/exo/31/06.md)
* [Hebrews 09:13-15](https://git.door43.org/Door43/en_tn/src/master/heb/09/13.md)
* [James 04:8-10](https://git.door43.org/Door43/en_tn/src/master/jas/04/08.md)
* [Luke 02:22-24](https://git.door43.org/Door43/en_tn/src/master/luk/02/22.md)
* [Revelation 14:3-5](https://git.door43.org/Door43/en_tn/src/master/rev/14/03.md)


### Word Data:

* Strong's: H1249, H1252, H1253, H1305, H1865, H2134, H2135, H2141, H2212, H2398, H2403, H2561, H2889, H2890, H2891, H2892, H2893, H3795, H3800, H4795, H5343, H5462, H6337, H6884, H6942, H8562, G48, G49, G53, G54, G1506, G2511, G2512, G2513, G2514


## <a id="tw-term-kt-rabbi"/>Rabbi

### Definition:

The term "Rabbi" literally means "my master" or "my teacher."

* It was a title of respect that was used to address a man who was a Jewish religious teacher, especially a teacher of God's laws.
* Both John the Baptist and Jesus were sometimes called "Rabbi" by their disciples.

### Translation Suggestions:

* Ways to translate this term could include "My Master" or "My Teacher" or "Honorable Teacher" or "Religious Teacher." Some languages may capitalize a greeting like this, while others may not.
* The project language may also have a special way that teachers are normally addressed.
* Make sure the translation of this term does not indicate that Jesus was a schoolteacher.
* Also consider how "Rabbi" is translated in a Bible translation in a related language or a national language. 

See: [How to Translate Unknowns](https://git.door43.org/Door43/en_man/src/master/translate/translate-unknown/01.md))

(See also: [teacher](other.html#teacher))

### Bible References:

* [John 01:49-51](https://git.door43.org/Door43/en_tn/src/master/jhn/01/49.md)
* [John 06:24-25](https://git.door43.org/Door43/en_tn/src/master/jhn/06/24.md)
* [Mark 14:43-46](https://git.door43.org/Door43/en_tn/src/master/mrk/14/43.md)
* [Matthew 23:8-10](https://git.door43.org/Door43/en_tn/src/master/mat/23/08.md)

### Word Data:

* Strong's: G4461


## <a id="tw-term-kt-ransom"/>ransom, ransomed

### Definition:

The term "ransom" refers to a sum of money or other payment that is demanded or paid for the release of a person who is held captive.

* As a verb, to "ransom" means to make a payment or to do something self-sacrificially in order to rescue someone who has been captured, enslaved or imprisoned. This meaning of "buy back" is similar to the meaning of "redeem."
* Jesus allowed himself to be killed as a ransom to free sinful people from their enslavement to sin. This act of God buying back his people through paying the penalty of their sin is also called "redemption" in the Bible.

### Translation Suggestions:

* The term to "ransom" could also be translated as to "pay to release" or to "pay a price to free" or to "buy back."
* The phrase to "pay a ransom" could be translated as to "pay the price (of freedom)" or to "pay the penalty (to free people)" or to "make the required payment."
* The noun "ransom" could be translated as "a buying back" or "a penalty paid" or "the price paid" (to free or buy back people or land).
* The terms a "ransom" and a "redemption" have the same meaning in English but are sometimes used slightly differently. Other languages may have only one term for this concept.
* Make sure this is translated differently from "atonement."

(See also: [atonement](#atonement), [redeem](#redeem))

### Bible References:

* [1 Timothy 02:5-7](https://git.door43.org/Door43/en_tn/src/master/1ti/02/05.md)
* [Isaiah 43:2-3](https://git.door43.org/Door43/en_tn/src/master/isa/43/02.md)
* [Job 06:21-23](https://git.door43.org/Door43/en_tn/src/master/job/06/21.md)
* [Leviticus 19:20-22](https://git.door43.org/Door43/en_tn/src/master/lev/19/20.md)
* [Matthew 20:25-28](https://git.door43.org/Door43/en_tn/src/master/mat/20/25.md)
* [Psalms 049:6-8](https://git.door43.org/Door43/en_tn/src/master/psa/049/006.md)


### Word Data:

* Strong's: H1350, H3724, H6299, H6306, G487, G3083


## <a id="tw-term-kt-reconcile"/>reconcile, reconciles, reconciled, reconciliation

### Definition:

To "reconcile" and "reconciliation" refer to "make peace" between people who were formerly enemies of each other. "Reconciliation" is that act of making peace

* In the Bible, this term usually refer to Gods reconciling people to himself through the sacrifice of his Son, Jesus Christ.
* Because of sin, all human beings are God's enemies. But because of his compassionate love, God provided a way for people to be reconciled to him through Jesus.
* Through trusting in Jesus' sacrifice as payment for their sin, people can be forgiven and have peace with God.

### Translation Suggestions:

* The term "reconcile" could be translated as "make peace" or "restore good relations" or "cause to be friends."
* The term "reconciliation" could be translated as "restoring good relations" or "making peace" or "causing peaceful relating."

(See also: [peace](other.html#peace), [sacrifice](other.html#sacrifice))

### Bible References:

* [2 Corinthians 05:18-19](https://git.door43.org/Door43/en_tn/src/master/2co/05/18.md)
* [Colossians 01:18-20](https://git.door43.org/Door43/en_tn/src/master/col/01/18.md)
* [Matthew 05:23-24](https://git.door43.org/Door43/en_tn/src/master/mat/05/23.md)
* [Proverbs 13:17-18](https://git.door43.org/Door43/en_tn/src/master/pro/13/17.md)
* [Romans 05:10-11](https://git.door43.org/Door43/en_tn/src/master/rom/05/10.md)

### Word Data:

* Strong's: H2398 , H3722 , G604 , G1259 , G2433 , G2643, G2644


## <a id="tw-term-kt-redeem"/>redeem, redeems, redemption, redeemer

### Definition:

To "redeem" and "redemption" refer to buy back something or someone that was previously owned or held captive. "Redemption" is the action of doing that. A "redeemer" is someone who redeems something or someone. 

* God gave laws to the Israelites about how to redeem people or things.
* For example, someone could redeem a person who was in slavery by paying the price so that the slave could go free. The word "ransom" also refers to this practice.
* If someone's land had been sold, a relative of that person could "redeem" or "buy back" that land so that it would stay in the family.
* These practices show how God redeems people who are in slavery to sin. When he died on the cross, Jesus paid the full price for people's sins and redeemed all those who trust in him for salvation. People who have been redeemed by God are set free from sin and its punishment.

### Translation Suggestions:

* Depending on the context, the term "redeem" could also be translated as "buy back" or "pay to free (someone)" or "ransom."
* The term "redemption" could be translated as "ransom" or "freedom payment" or "the buying back."
* The words "ransom" and "redeem" have basically the same meaning, so some languages may have only  one term to translate both these terms. The word "ransom," however, can also mean the payment necessary.

(See also: [free](other.html#free), [ransom](#ransom))

### Bible References:

* [Colossians 01:13-14](https://git.door43.org/Door43/en_tn/src/master/col/01/13.md)
* [Ephesians 01:7-8](https://git.door43.org/Door43/en_tn/src/master/eph/01/07.md)
* [Ephesians 05:15-17](https://git.door43.org/Door43/en_tn/src/master/eph/05/15.md)
* [Galatians 03:13-14](https://git.door43.org/Door43/en_tn/src/master/gal/03/13.md)
* [Galatians 04:3-5](https://git.door43.org/Door43/en_tn/src/master/gal/04/03.md)
* [Luke 02:36-38](https://git.door43.org/Door43/en_tn/src/master/luk/02/36.md)
* [Ruth 02:19-20](https://git.door43.org/Door43/en_tn/src/master/rut/02/19.md)


### Word Data:

* Strong's: H1350, H1353, H6299, H6302, H6304, H6306, H6561, H7069, G59, G629, G1805, G3084, G3085


## <a id="tw-term-kt-remnant"/>remnant

### Definition:

The term "remnant" literally refers to people or things that are "remaining" or "left over" from a larger amount or group.

* Often a "remnant" refers to people who survive a life-threatening situation or who remain faithful to God while undergoing persecution.
* Isaiah referred to a group of Jews as being a remnant who would survive attacks from outsiders and live to return to the Promised Land in Canaan.
* Paul talks about there being a "remnant" of people who were chosen by God to receive his grace.
* The term "remnant" implies that there were other people who did not remain faithful or who did not survive or who were not chosen.

### Translation Suggestions:

* A phrase such as "the remnant of this people" could be translated as "the rest of these people" or "the people who remain faithful" or "the people who are left."
* The "whole remnant of people" could be translated by "all the rest of the people" or "the remaining people."

### Bible References:

* [Acts 15:15-18](https://git.door43.org/Door43/en_tn/src/master/act/15/15.md)
* [Amos 09:11-12](https://git.door43.org/Door43/en_tn/src/master/amo/09/11.md)
* [Ezekiel 06:8-10](https://git.door43.org/Door43/en_tn/src/master/ezk/06/08.md)
* [Genesis 45:7-8](https://git.door43.org/Door43/en_tn/src/master/gen/45/07.md)
* [Isaiah 11:10-11](https://git.door43.org/Door43/en_tn/src/master/isa/11/10.md)
* [Micah 04:6-8](https://git.door43.org/Door43/en_tn/src/master/mic/04/06.md)

### Word Data:

* Strong's: H3498, H3499, H5629, H6413, H7604, H7605, H7611, H8281, H8300, G2640, G3005, G3062


## <a id="tw-term-kt-repent"/>repent, repents, repented, repentance

### Definition:

The terms "repent" and "repentance" refer to turning away from sin and turning back to God.

* To "repent" literally means to "change one's mind."
* In the Bible, "repent" usually means to turn away from a sinful, human way of thinking and acting, and to turn to God's way of thinking and acting.
* When people truly repent of their sins, God forgives them and helps them start obeying him.

### Translation Suggestions:

* The term "repent" can be translated with a word or phrase that means "turn back (to God)" or "turn away from sin and toward God" or "turn toward God, away from sin."
* Often the term "repentance" can be translated using the verb "repent." For example, "God has given repentance to Israel" could be translated as "God has enabled Israel to repent."
* Other ways to translate "repentance" could include "turning away from sin" or "turning to God and away from sin."

(See also: [forgive](#forgive), [sin](#sin), [turn](other.html#turn))

### Bible References:

* [Acts 03:19-20](https://git.door43.org/Door43/en_tn/src/master/act/03/19.md)
* [Luke 03:3](https://git.door43.org/Door43/en_tn/src/master/luk/03/03.md)
* [Luke 03:8](https://git.door43.org/Door43/en_tn/src/master/luk/03/08.md)
* [Luke 05:29-32](https://git.door43.org/Door43/en_tn/src/master/luk/05/29.md)
* [Luke 24:45-47](https://git.door43.org/Door43/en_tn/src/master/luk/24/45.md)
* [Mark 01:14-15](https://git.door43.org/Door43/en_tn/src/master/mrk/01/14.md)
* [Matthew 03:1-3](https://git.door43.org/Door43/en_tn/src/master/mat/03/01.md)
* [Matthew 03:10-12](https://git.door43.org/Door43/en_tn/src/master/mat/03/10.md)
* [Matthew 04:17](https://git.door43.org/Door43/en_tn/src/master/mat/04/17.md)
* [Romans 02:3-4](https://git.door43.org/Door43/en_tn/src/master/rom/02/03.md)

### Examples from the Bible stories:

* __[16:02](https://git.door43.org/Door43/en_tn/src/master/obs/16/02.md)__ After many years of disobeying God and being oppressed by their enemies, the Israelites __repented__  and asked God to rescue them.
* __[17:13](https://git.door43.org/Door43/en_tn/src/master/obs/17/13.md)__ David __repented__  of his sin and God forgave him.
* __[19:18](https://git.door43.org/Door43/en_tn/src/master/obs/19/18.md)__ They (prophets) warned people that God would destroy them if they did not __repent__.
* __[24:02](https://git.door43.org/Door43/en_tn/src/master/obs/24/02.md)__ Many people came out to the wilderness to listen to John. He preached to them, saying, "__Repent__, for the kingdom of God is near!"
* __[42:08](https://git.door43.org/Door43/en_tn/src/master/obs/42/08.md)__ ""It was also written in the scriptures that my disciples will proclaim that everyone should repent in order to __receive__  forgiveness for their sins. "
* __[44:05](https://git.door43.org/Door43/en_tn/src/master/obs/44/05.md)__ "So now, __repent__  and turn to God so that your sins will be washed away."


### Word Data:

* Strong's: H5150, H5162, H5164, G278, G3338, G3340, G3341


## <a id="tw-term-kt-restore"/>restore, restores, restored, restoration

### Definition:

The terms "restore" and "restoration" refer to causing something to return to its original and better condition.

* When a diseased body part is restored, this means it has been "healed."
* A broken relationship that is restored has been "reconciled." God restores sinful people and brings them back to himself.
* If people have been restored to their home country, they have been "brought back" or "returned" to that country.

### Translation Suggestions:

* Depending on the context, ways to translate "restore" could include "renew" or "repay" or "return" or "heal" or "bring back."
* Other expressions for this term could be "make new" or "make like new again."
* When property is "restored," it has been "repaired" or "replaced" or "given back" to its owner.
* Depending on the context, "restoration" could be translated as "renewal" or "healing" or "reconciliation."

### Bible References:

* [2 Kings 05:8-10](https://git.door43.org/Door43/en_tn/src/master/2ki/05/08.md)
* [Acts 03:21-23](https://git.door43.org/Door43/en_tn/src/master/act/03/21.md)
* [Acts 15:15-18](https://git.door43.org/Door43/en_tn/src/master/act/15/15.md)
* [Isaiah 49:5-6](https://git.door43.org/Door43/en_tn/src/master/isa/49/05.md)
* [Jeremiah 15:19-21](https://git.door43.org/Door43/en_tn/src/master/jer/15/19.md)
* [Lamentations 05:19-22](https://git.door43.org/Door43/en_tn/src/master/lam/05/19.md)
* [Leviticus 06:5-7](https://git.door43.org/Door43/en_tn/src/master/lev/06/05.md)
* [Luke 19:8-10](https://git.door43.org/Door43/en_tn/src/master/luk/19/08.md)
* [Matthew 12:13-14](https://git.door43.org/Door43/en_tn/src/master/mat/12/13.md)
* [Psalm 080:1-3](https://git.door43.org/Door43/en_tn/src/master/psa/080/001.md)


### Word Data:

* Strong's: H7725, H7999, H8421, G600, G2675


## <a id="tw-term-kt-resurrection"/>resurrection

### Definition:

The term "resurrection" refers to the act of becoming alive again after having died.

* To resurrect someone means to bring that person back to life again. Only God has the power to do this.
* The word "resurrection" often refers to Jesus' coming back to life after he died.
* When Jesus said, "I am the Resurrection and the Life" he meant that he is the source of resurrection, and the one who causes people to come back to life.

### Translation Suggestions:

* A person's "resurrection" could be translated as his "coming back to life" or his "becoming alive again after being dead."
* The literal meaning of this word is "a rising up" or "the act of being raised (from the dead)." These would be other possible ways to translate this term.

(See also: [life](#life), [death](other.html#death), [raise](other.html#raise))

### Bible References:

* [1 Corinthians 15:12-14](https://git.door43.org/Door43/en_tn/src/master/1co/15/12.md)
* [1 Peter 03:21-22](https://git.door43.org/Door43/en_tn/src/master/1pe/03/21.md)
* [Hebrews 11:35-38](https://git.door43.org/Door43/en_tn/src/master/heb/11/35.md)
* [John 05:28-29](https://git.door43.org/Door43/en_tn/src/master/jhn/05/28.md)
* [Luke 20:27-28](https://git.door43.org/Door43/en_tn/src/master/luk/20/27.md)
* [Luke 20:34-36](https://git.door43.org/Door43/en_tn/src/master/luk/20/34.md)
* [Matthew 22:23-24](https://git.door43.org/Door43/en_tn/src/master/mat/22/23.md)
* [Matthew 22:29-30](https://git.door43.org/Door43/en_tn/src/master/mat/22/29.md)
* [Philippians 03:8-11](https://git.door43.org/Door43/en_tn/src/master/php/03/08.md)

### Examples from the Bible stories:

* __[21:14](https://git.door43.org/Door43/en_tn/src/master/obs/21/14.md)__ Through the Messiah's death and __resurrection__, God would accomplish his plan to save sinners and start the New Covenant.
* __[37:05](https://git.door43.org/Door43/en_tn/src/master/obs/37/05.md)__ Jesus replied, "I am the __Resurrection__  and the Life. Whoever believes in me will live, even though he dies.

### Word Data:

* Strong's: G386, G1454, G1815


## <a id="tw-term-kt-reveal"/>reveal, reveals, revealed, revelation

### Definition:

The term "reveal" means to cause something to be known. A "revelation" is something that has been made known.

* God has revealed himself through everything he has created and through his communication with people by spoken and written messages.
* God also reveals himself through dreams or visions.
* When Paul said that he received the gospel by "revelation from Jesus Christ," he means that Jesus himself explained the gospel to him.
* In the New Testament book "Revelation" is about God revealed events that will happen in the end times. He revealed them to the apostle John through visions.

### Translation Suggestions:

* Other ways to translate "reveal" could include "make known" or "disclose" or "show clearly."
* Depending on the context, possible ways to translate "revelation" could be "communication from God" or "things that God has revealed" or "teachings about God." It is best to keep the meaning of "reveal" in the translation.
* The phrase "where there is no revelation" could be translated as "when God is not revealing himself to people" or "when God is not speaking to people" or "among people whom God has not communicating."

(See also: [good news](#goodnews), [good news](#goodnews), [dream](other.html#dream), [vision](other.html#vision))

### Bible References:

* [Daniel 11:1-2](https://git.door43.org/Door43/en_tn/src/master/dan/11/01.md)
* [Ephesians 03:3-5](https://git.door43.org/Door43/en_tn/src/master/eph/03/03.md)
* [Galatians 01:11-12](https://git.door43.org/Door43/en_tn/src/master/gal/01/11.md)
* [Lamentations 02:13-14](https://git.door43.org/Door43/en_tn/src/master/lam/02/13.md)
* [Matthew 10:26-27](https://git.door43.org/Door43/en_tn/src/master/mat/10/26.md)
* [Philippians 03:15-16](https://git.door43.org/Door43/en_tn/src/master/php/03/15.md)
* [Revelation 01:1-3](https://git.door43.org/Door43/en_tn/src/master/rev/01/01.md)


### Word Data:

* Strong's: H241, H1540, H1541, G601, G602, G5537


## <a id="tw-term-kt-righteous"/>righteous, righteousness, unrighteous, unrighteousness, upright, uprightness

### Definition:

The term "righteousness" refers to God's absolute goodness, justice, faithfulness, and love. Having these qualities makes God "righteous." Because God is righteous, he must condemn sin.

* These terms are also often used to describe a person who obeys God and is morally good. However, because all people have sinned, no one except God is completely righteous.
* Examples of people the Bible who were called "righteous" include Noah, Job, Abraham, Zachariah, and Elisabeth.
* When people trust in Jesus to save them, God cleanses them from their sins and declares them to be righteous because of Jesus' righteousness.

The term "unrighteous" means to be sinful and morally corrupt. "Unrighteousness" refers to sin or the condition of being sinful.

* These terms especially refer to living in a way that disobeys God's teachings and commands.
* Unrighteous people are immoral in their thoughts and actions.
* Sometimes "the unrighteous" refers specifically to people who do not believe in Jesus.

The terms "upright" and "uprightness" refer to acting in a way that follows God's laws.

* The meaning of these words includes the idea of standing up straight and looking directly ahead.
* A person who is "upright" is someone who obeys God's rules and does not do things that are against his will.
* Terms such as "integrity" and "righteous" have similar meanings and are sometimes used in parallelism constructions, such as "integrity and uprightness."  (See: [parallelism](https://git.door43.org/Door43/en_man/src/master/translate/figs-parallelism/01.md))

### Translation Suggestions:

* When it describes God, the term "righteous" could be translated as "perfectly good and just" or "always acting rightly."
* God's "righteousness" could also be translated as "perfect faithfulness and goodness."
* When it describes people who are obedient to God, the term "righteous" could also be translated as "morally good" or "just" or "living a God-pleasing life."
* The phrase "the righteous" could also be translated as "righteous people" or "God-fearing people."
* Depending on the context, "righteousness" could also be translated with a word or phrase that means  "goodness" or "being perfect before God" or "acting in a right way by obeying God" or "doing perfectly good 
* Sometimes "the righteous" was used figuratively and referred to "people who think they are good" or "people who seem to be righteous."

* The term "unrighteous" could simply be translated as "not righteous."
* Depending on the context, other ways to translate this could include "wicked" or "immoral" or "people who rebel against God" or "sinful."
* The phrase "the unrighteous" could be translated as "unrighteous people."
* The term "unrighteousness" could be translated as "sin" or "evil thoughts and actions" or "wickedness."
* If possible, it is best to translate this in a way that shows its relationship to "righteous, righteousness."

* Ways to translate "upright" could include "acting rightly" or "one who acts rightly" or "following God's laws" or "obedient to God" or "behaving in a way that is right."
* The term "uprightness" could be translated as "moral purity" or "good moral conduct" or "rightness."
* The phrase "the upright" could be translated as "people who are upright" or "upright people."

(See also: [evil](#evil), [faithful](#faithful), [good](#good), [holy](#holy), [integrity](other.html#integrity), [just](#justice), [law](other.html#law), [law](#lawofmoses), [obey](other.html#obey), [pure](#purify), [righteous](#righteous), [sin](#sin), [unlawful](other.html#lawful))

### Bible References:

* [Deuteronomy 19:15-16](https://git.door43.org/Door43/en_tn/src/master/deu/19/15.md)
* [Job 01:6-8](https://git.door43.org/Door43/en_tn/src/master/job/01/06.md)
* [Psalms 037:28-30](https://git.door43.org/Door43/en_tn/src/master/psa/037/028.md)
* [Psalms 049:14-15](https://git.door43.org/Door43/en_tn/src/master/psa/049/014.md)
* [Psalms 107:41-43](https://git.door43.org/Door43/en_tn/src/master/psa/107/041.md)
* [Ecclesiastes 12:10-11](https://git.door43.org/Door43/en_tn/src/master/ecc/12/10.md)
* [Isaiah 48:1-2](https://git.door43.org/Door43/en_tn/src/master/isa/48/01.md)
* [Ezekiel 33:12-13](https://git.door43.org/Door43/en_tn/src/master/ezk/33/12.md)
* [Malachi 02:5-7](https://git.door43.org/Door43/en_tn/src/master/mal/02/05.md)
* [Matthew 06:1-2](https://git.door43.org/Door43/en_tn/src/master/mat/06/01.md)
* [Acts 03:13-14](https://git.door43.org/Door43/en_tn/src/master/act/03/13.md)
* [Romans 01:29-31](https://git.door43.org/Door43/en_tn/src/master/rom/01/29.md)
* [1 Corinthians 06:9-11](https://git.door43.org/Door43/en_tn/src/master/1co/06/09.md)
* [Galatians 03:6-9](https://git.door43.org/Door43/en_tn/src/master/gal/03/06.md)
* [Colossians 03:22-25](https://git.door43.org/Door43/en_tn/src/master/col/03/22.md)
* [2 Thessalonians 02:8-10](https://git.door43.org/Door43/en_tn/src/master/2th/02/08.md)
* [2 Timothy 03:16-17](https://git.door43.org/Door43/en_tn/src/master/2ti/03/16.md)
* [1 Peter 03:18-20](https://git.door43.org/Door43/en_tn/src/master/1pe/03/18.md)
* [1 John 01:8-10](https://git.door43.org/Door43/en_tn/src/master/1jn/01/08.md)
* [1 John 05:16-17](https://git.door43.org/Door43/en_tn/src/master/1jn/05/16.md)

### Examples from the Bible stories:

* __[03:02](https://git.door43.org/Door43/en_tn/src/master/obs/03/02.md)__ But Noah found favor with God. He was a __righteous__  man, living among wicked people.
* __[04:08](https://git.door43.org/Door43/en_tn/src/master/obs/04/08.md)__ God declared that Abram was __righteous__  because he believed in God's promise.
* __[17:02](https://git.door43.org/Door43/en_tn/src/master/obs/17/02.md)__ David was a humble and __righteous__  man who trusted and obeyed God.
* __[23:01](https://git.door43.org/Door43/en_tn/src/master/obs/23/01.md)__ Joseph, the man Mary was engaged to, was a __righteous__  man.
* __[50:10](https://git.door43.org/Door43/en_tn/src/master/obs/50/10.md)__ Then the __righteous__  ones will shine like the sun in the kingdom of God their Father."

### Word Data:

* Strong's: H205, H1368, H2555, H3072, H3474, H3476, H3477, H3483, H4334, H4339, H4749, H5228, H5229, H5324, H5765, H5766, H5767, H5977, H6662, H6663, H6664, H6665, H6666, H6968, H8535, H8537, H8549, H8552, G93, G94, G458, G1341, G1342, G1343, G1344, G1345, G1346, G2118, G3716, G3717


## <a id="tw-term-kt-righthand"/>right hand

### Definition:

The figurative expression "right hand" refers to the place of honor or strength on the right side of a ruler or other important individual.

* The right hand is also used as a symbol of power, authority, or strength.
* The Bible describes Jesus as sitting "at the right hand of" God the Father as the head of the body of believers (the Church) and in control as ruler of all creation.
* A person's right hand was used to show special honor when placed on the head of someone being given a blessing (as when the patriarch Jacob blessed Joseph's son Ephraim).
* To "serve at the right hand" of someone means to be the one whose service is especially helpful and important to that person.

### Translation Suggestions:

* Sometimes the term "right hand" literally refers to a person's right hand, as when Roman soldiers put a staff into Jesus' right hand to mock him. This should be translated using the term that the language uses to refer to this hand. 
* Regarding figurative uses, if an expression that includes the term "right hand" does not have the same meaning in the project language, then consider whether that language has a different expression with the same meaning.
* The expression "at the right hand of" could be translated as "on the right side of" or "in the place of honor beside" or "in the position of strength" or "ready to help."
* Ways to translate "with his right hand" could include "with authority" or "using power" or "with his amazing strength."
* The figurative expression "his right hand and his mighty arm" uses two ways of emphasizing God's power and great strength. One way to translate this expression could be "his amazing strength and mighty power." (See: [parallelism](https://git.door43.org/Door43/en_man/src/master/translate/figs-parallelism/01.md))
* The expression "their right hand is falsehood" could be translated as, "even the most honorable thing about them is corrupted by lies" or "their place of honor is corrupted by deception" or "they use lies to make themselves powerful." 

(See also: [accuse](other.html#accuse), [evil](#evil), [honor](#honor), [mighty](other.html#mighty), [punish](other.html#punish), [rebel](other.html#rebel))

### Bible References:

* [Acts 02:32-33](https://git.door43.org/Door43/en_tn/src/master/act/02/32.md)
* [Colossians 03:1-4](https://git.door43.org/Door43/en_tn/src/master/col/03/01.md)
* [Galatians 02:9-10](https://git.door43.org/Door43/en_tn/src/master/gal/02/09.md)
* [Genesis 48:14-16](https://git.door43.org/Door43/en_tn/src/master/gen/48/14.md)
* [Hebrews 10:11-14](https://git.door43.org/Door43/en_tn/src/master/heb/10/11.md)
* [Lamentations 02:3-4](https://git.door43.org/Door43/en_tn/src/master/lam/02/03.md)
* [Matthew 25:31-33](https://git.door43.org/Door43/en_tn/src/master/mat/25/31.md)
* [Matthew 26:62-64](https://git.door43.org/Door43/en_tn/src/master/mat/26/62.md)
* [Psalms 044:3-4](https://git.door43.org/Door43/en_tn/src/master/psa/044/003.md)
* [Revelation 02:1-2](https://git.door43.org/Door43/en_tn/src/master/rev/02/01.md)

### Word Data:

* Strong's: H3225, H3231, H3233, G1188


## <a id="tw-term-kt-sabbath"/>Sabbath

### Definition:

The term "Sabbath" refers to the seventh day of the week, which God commanded the Israelites to set apart as a day of rest and doing no work.

* After God finished creating the world in six days, he rested on the seventh day. In the same way, God commanded the Israelites to set aside the seventh day as a special day to rest and worship him.
* The command to "keep the Sabbath holy" is one of the ten commandments that God wrote on the stone tablets that he gave Moses for the Israelites.
* Following the Jewish system of counting days, the Sabbath begins on Friday at sundown and lasts until Saturday at sundown.
* Sometimes in the Bible the Sabbath is called "Sabbath day" rather than only the Sabbath. 

### Translation Suggestions:

* This could also be translated as "resting day" or "day for resting" or "day of not working" or "God's day of rest."
* Some translations capitalize this term to show that it is a special day, as in "Sabbath Day" or "Resting Day."
* Consider how this term is translated in a local or national language.

(See also: [How to Translate Unknowns](https://git.door43.org/Door43/en_man/src/master/translate/translate-unknown/01.md))

(See also: [rest](other.html#rest))

### Bible References:

* [2 Chronicles 31:2-3](https://git.door43.org/Door43/en_tn/src/master/2ch/31/02.md)
* [Acts 13:26-27](https://git.door43.org/Door43/en_tn/src/master/act/13/26.md)
* [Exodus 31:12-15](https://git.door43.org/Door43/en_tn/src/master/exo/31/12.md)
* [Isaiah 56:6-7](https://git.door43.org/Door43/en_tn/src/master/isa/56/06.md)
* [Lamentations 02:5-6](https://git.door43.org/Door43/en_tn/src/master/lam/02/05.md)
* [Leviticus 19:1-4](https://git.door43.org/Door43/en_tn/src/master/lev/19/01.md)
* [Luke 13:12-14](https://git.door43.org/Door43/en_tn/src/master/luk/13/12.md)
* [Mark 02:27-28](https://git.door43.org/Door43/en_tn/src/master/mrk/02/27.md)
* [Matthew 12:1-2](https://git.door43.org/Door43/en_tn/src/master/mat/12/01.md)
* [Nehemiah 10:32-33](https://git.door43.org/Door43/en_tn/src/master/neh/10/32.md)

### Examples from the Bible stories:

* __[13:05](https://git.door43.org/Door43/en_tn/src/master/obs/13/05.md)__ "Always be sure to keep the __Sabbath day__  holy. That is, do all your work in six days, for the seventh day is a day for you to rest and to honor me."
* __[26:02](https://git.door43.org/Door43/en_tn/src/master/obs/26/02.md)__ Jesus went to the town of Nazareth where he had lived during his childhood. On the __Sabbath__, he went to the place of worship.
* __[41:03](https://git.door43.org/Door43/en_tn/src/master/obs/41/03.md)__ The day after Jesus was buried was a __Sabbath__  day, and the Jews were not permitted to go to the tomb on that day.

### Word Data:

* Strong's: H4868, H7676, H7677, G4315, G4521


## <a id="tw-term-kt-sadducee"/>Sadducee, Sadducees

### Definition:

The Sadducees were a political group of Jewish priests during the time of Jesus Christ. They supported Roman rule and did not believe in the resurrection.

* Many Sadducees were wealthy, upper-class Jews who held powerful leadership positions such as chief priest and high priest.
* The duties of the Sadducees included taking care of the temple complex and priestly tasks such as offering sacrifices.
* The Sadducees and the Pharisees strongly influenced the Roman leaders to crucify Jesus.
* Jesus spoke against these two religious groups because of their selfishness and hypocrisy.


(See also: [chief priests](other.html#chiefpriests), [council](other.html#council), [high priest](#highpriest), [hypocrite](#hypocrite), [Jewish leaders](other.html#jewishleaders), [Pharisee](#pharisee), [priest](#priest))

### Bible References:

* [Acts 04:1-4](https://git.door43.org/Door43/en_tn/src/master/act/04/01.md)
* [Acts 05:17-18](https://git.door43.org/Door43/en_tn/src/master/act/05/17.md)
* [Luke 20:27-28](https://git.door43.org/Door43/en_tn/src/master/luk/20/27.md)
* [Matthew 03:7-9](https://git.door43.org/Door43/en_tn/src/master/mat/03/07.md)
* [Matthew 16:1-2](https://git.door43.org/Door43/en_tn/src/master/mat/16/01.md)


### Word Data:

* Strong's: G4523


## <a id="tw-term-kt-saint"/>saint, saints

### Definition:

The term "saints" literally means "holy ones" and refers to believers in Jesus.

* Later in church history, a person known for his good works was given the title "saint," but that was not how this term was used during New Testament times.
* Believers in Jesus are saints or holy ones, not because of what they have done, but rather because of their faith in the saving work of Jesus Christ. He is the one who makes them holy.

### Translation Suggestions:
* Ways to translate "saints" could include "holy ones" or "holy people" or "holy believers in Jesus" or "set apart ones."
* Be careful not to use a term that refers to people of only one Christian group.


(See also: [holy](#holy))

### Bible References:

* [1 Timothy 05:9-10](https://git.door43.org/Door43/en_tn/src/master/1ti/05/09.md)
* [2 Corinthians 09:12-15](https://git.door43.org/Door43/en_tn/src/master/2co/09/12.md)
* [Revelation 16:4-7](https://git.door43.org/Door43/en_tn/src/master/rev/16/04.md)
* [Revelation 20:9-10](https://git.door43.org/Door43/en_tn/src/master/rev/20/09.md)

### Word Data:

* Strong's: H2623, H6918, H6922, G40


## <a id="tw-term-kt-sanctify"/>sanctify, sanctifies, sanctification

### Definition:

To sanctify is to set apart or to make holy. Sanctification is the process of being made holy.

* In the Old Testament, certain people and things were sanctified, or set apart, for service to God.
* The New Testament teaches that God sanctifies people who believe in Jesus. That is, he makes them holy and sets them apart to serve him.
* Believers in Jesus are also commanded to sanctify themselves to God, to be holy in everything they do.

### Translation Suggestions:
* Depending on the context, the term "sanctify" can be translated as "set apart" or "make holy" or "purify."
* When people sanctify themselves, they purify themselves and dedicate themselves to God's service. Often the word "consecrate" is used in the Bible with this meaning.
* When its meaning is  "consecrate," this term could be translated as "dedicate someone (or something) to God's service."
* Depending on the context, the phrase "your sanctification" could be translated as "making you holy" or "setting you apart (for God)" or "what makes you holy."

(See also: [consecrate](#consecrate), [holy](#holy), [set apart](#setapart))

### Bible References:

* [1 Thessalonians 04:3-6](https://git.door43.org/Door43/en_tn/src/master/1th/04/03.md)
* [2 Thessalonians 02:13-15](https://git.door43.org/Door43/en_tn/src/master/2th/02/13.md)
* [Genesis 02:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/02/01.md)
* [Luke 11:2](https://git.door43.org/Door43/en_tn/src/master/luk/11/02.md)
* [Matthew 06:8-10](https://git.door43.org/Door43/en_tn/src/master/mat/06/08.md)


### Word Data:

* Strong's: H6942, G37, G38


## <a id="tw-term-kt-sanctuary"/>sanctuary

### Definition:

The term "sanctuary" literally means "holy place" and refers to a place that God has made sacred and holy. It also can refer to a place that provides protection and safety.

* In the Old Testament, the term "sanctuary" was often used to refer to the tabernacle or temple building where the "holy place" and "most holy place" were located.
* God referred to the sanctuary as the place where he lived among his people, the Israelites.
* He also called himself a "sanctuary" or safe place for his people where they can find protection.

### Translation Suggestions:

* This term has a basic meaning of "holy place" or "place that is set apart."
* Depending on the context, the term "sanctuary" could be translated as "holy place" or "sacred building" or "God's holy dwelling place" or "holy place of protection" or "sacred place of safety."
* The phrase "shekel of the sanctuary" could be translated as "kind of shekel given for the tabernacle" or "shekel used in paying the tax to take care of the temple."
* Note: Be careful that the translation of this term does not refer to a worship room in a modern-day church.

(See also: [holy](#holy), [Holy Spirit](#holyspirit), [holy](#holy), [set apart](#setapart), [tabernacle](#tabernacle), [tax](other.html#tax), [temple](#temple), )

### Bible References:

* [Amos 07:12-13](https://git.door43.org/Door43/en_tn/src/master/amo/07/12.md)
* [Exodus 25:3-7](https://git.door43.org/Door43/en_tn/src/master/exo/25/03.md)
* [Ezekiel 25:3-5](https://git.door43.org/Door43/en_tn/src/master/ezk/25/03.md)
* [Hebrews 08:1-2](https://git.door43.org/Door43/en_tn/src/master/heb/08/01.md)
* [Luke 11:49-51](https://git.door43.org/Door43/en_tn/src/master/luk/11/49.md)
* [Numbers 18:1-2](https://git.door43.org/Door43/en_tn/src/master/num/18/01.md)
* [Psalms 078:67-69](https://git.door43.org/Door43/en_tn/src/master/psa/078/067.md)

### Word Data:

* Strong's: H4720, H6944, G39


## <a id="tw-term-kt-satan"/>Satan, devil, evil one

### Facts:

Although the devil is a spirit being that God created, he rebelled against God and became God's enemy. The devil is also called "Satan" and "the evil one."

* The devil hates God and all that God created because he wants to take the place of God and be worshiped as God.
* Satan tempts people to rebel against God.
* God sent his Son, Jesus, to rescue people from Satan's control.
* The name "Satan" means "adversary" or "enemy."
* The word "devil" means "accuser."

### Translation Suggestions:

* The word "devil" could also be translated as "the accuser" or "the evil one" or "the king of evil spirits" or "the chief evil spirit."
* "Satan" could be translated as "Opponent" or "Adversary" or some other name that shows that he is the devil.
* These terms should be translated differently from demon and evil spirit.
* Consider how these terms are translated in a local or national language.

(See: [How to Translate Unknowns](https://git.door43.org/Door43/en_man/src/master/translate/translate-unknown/01.md))

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [demon](#demon), [evil](#evil), [kingdom of God](#kingdomofgod), [tempt](#tempt))

### Bible References:

* [1 John 03:7-8](https://git.door43.org/Door43/en_tn/src/master/1jn/03/07.md)
* [1 Thessalonians 02:17-20](https://git.door43.org/Door43/en_tn/src/master/1th/02/17.md)
* [1 Timothy 05:14-16](https://git.door43.org/Door43/en_tn/src/master/1ti/05/14.md)
* [Acts 13:9-10](https://git.door43.org/Door43/en_tn/src/master/act/13/09.md)
* [Job 01:6-8](https://git.door43.org/Door43/en_tn/src/master/job/01/06.md)
* [Mark 08:33-34](https://git.door43.org/Door43/en_tn/src/master/mrk/08/33.md)
* [Zechariah 03:1-3](https://git.door43.org/Door43/en_tn/src/master/zec/03/01.md)

### Examples from the Bible stories:

* __[21:01](https://git.door43.org/Door43/en_tn/src/master/obs/21/01.md)__ The snake who deceived Eve was __Satan__. The promise meant that the Messiah who would come would defeat __Satan__  completely.
* __[25:06](https://git.door43.org/Door43/en_tn/src/master/obs/25/06.md)__ Then __Satan__  showed Jesus all the kingdoms of the world and all their glory and said, "I will give you all this if you bow down and worship me."
* __[25:08](https://git.door43.org/Door43/en_tn/src/master/obs/25/08.md)__ Jesus did not give in to __Satan's__  temptations, so __Satan__  left him.
* __[33:06](https://git.door43.org/Door43/en_tn/src/master/obs/33/06.md)__ So Jesus explained, "The seed is the word of God. The path is a person who hears God's word, but does not understand it, and the __devil__  takes the word from him."
* __[38:07](https://git.door43.org/Door43/en_tn/src/master/obs/38/07.md)__ After Judas took the bread, __Satan__  entered into him.
* __[48:04](https://git.door43.org/Door43/en_tn/src/master/obs/48/04.md)__ God promised that one of Eve's descendants would crush __Satan's__  head, and __Satan__  would wound his heel. This meant that __Satan__  would kill the Messiah, but God would raise him to life again, and then the Messiah will crush the power of __Satan__  forever.
* __[49:15](https://git.door43.org/Door43/en_tn/src/master/obs/49/15.md)__ God has taken you out of __Satan's__  kingdom of darkness and put you into God's kingdom of light.
* __[50:09](https://git.door43.org/Door43/en_tn/src/master/obs/50/09.md)__ "The weeds represent the people who belong to the __evil one__. The enemy who planted the weeds represents the __devil__."
* __[50:10](https://git.door43.org/Door43/en_tn/src/master/obs/50/10.md)__ "When the world ends, the angels will gather together all the people who belong to the __devil__  and throw them into a raging fire, where they will cry and grind their teeth in terrible suffering."
* __[50:15](https://git.door43.org/Door43/en_tn/src/master/obs/50/15.md)__ When Jesus returns, he will completely destroy __Satan__  and his kingdom. He will throw __Satan__  into hell where he will burn forever, along with everyone who chose to follow him rather than to obey God.


### Word Data:

* Strong's: H7700, H7854, H8163, G1139, G1140, G1141, G1142, G1228, G4190, G4566, G4567


## <a id="tw-term-kt-save"/>save, saves, saved, safe, salvation

### Definition:

The term "save" refers to keeping someone from experiencing something bad or harmful. To "be safe" means to be protected from harm or danger.

* In a physical sense, people can be saved or rescued from harm, danger, or death.
* In a spiritual sense, if a person has been "saved," then God, through Jesus' death on the cross, has forgiven him and rescued him from being punished in hell for his sin.
* People can save or rescue people from danger, but only God can save people from being punished eternally for their sins.

The term "salvation" refers to being saved or rescued from evil and danger.

* In the Bible, "salvation" usually refers to the spiritual and eternal deliverance granted by God to those who repent of their sins and believe in Jesus.
* The Bible also talks about God saving or delivering his people from their physical enemies.

### Translation Suggestions:

* Ways to translate "save" could include "deliver" or "keep from harm" or "take out of harm's way" or "keep from dying."
* In the expression "whoever would save his life," the term "save" could also be translated as "preserve" or "protect."
* The term "safe" could be translated as "protected from danger" or "in a place where nothing can harm."

* The term "salvation" could also be translated using words related to "save" or "rescue," as in "God’s saving people (from being punished for their sins)" or "God’s rescuing his people (from their enemies)."
* "God is my salvation" could be translated as "God is the one who saves me."
* "You will draw water from the wells of salvation" could be translated as "You will be refreshed as with water because God is rescuing you."

(See also: [cross](#cross), [deliver](other.html#deliverer), [punish](other.html#punish), [sin](#sin), [Savior](#savior))

### Bible References:

* [Genesis 49:16-18](https://git.door43.org/Door43/en_tn/src/master/gen/49/16.md)
* [Genesis 47:25-26](https://git.door43.org/Door43/en_tn/src/master/gen/47/25.md)
* [Psalms 080:1-3](https://git.door43.org/Door43/en_tn/src/master/psa/080/001.md)
* [Jeremiah 16:19-21](https://git.door43.org/Door43/en_tn/src/master/jer/16/19.md)
* [Micah 06:3-5](https://git.door43.org/Door43/en_tn/src/master/mic/06/03.md)
* [Luke 02:30-32](https://git.door43.org/Door43/en_tn/src/master/luk/02/30.md)
* [Luke 08:36-37](https://git.door43.org/Door43/en_tn/src/master/luk/08/36.md)
* [Acts 04:11-12](https://git.door43.org/Door43/en_tn/src/master/act/04/11.md)
* [Acts 28:28](https://git.door43.org/Door43/en_tn/src/master/act/28/28.md)
* [Acts 02:20-21](https://git.door43.org/Door43/en_tn/src/master/act/02/20.md)
* [Romans 01:16-17](https://git.door43.org/Door43/en_tn/src/master/rom/01/16.md)
* [Romans 10:8-10](https://git.door43.org/Door43/en_tn/src/master/rom/10/08.md)
* [Ephesians 06:17-18](https://git.door43.org/Door43/en_tn/src/master/eph/06/17.md)
* [Philippians 01:28-30](https://git.door43.org/Door43/en_tn/src/master/php/01/28.md)
* [1 Timothy 01:15-17](https://git.door43.org/Door43/en_tn/src/master/1ti/01/15.md)
* [Revelation 19:1-2](https://git.door43.org/Door43/en_tn/src/master/rev/19/01.md)

### Examples from the Bible stories:

* __[09:08](https://git.door43.org/Door43/en_tn/src/master/obs/09/08.md)__ Moses tried to __save__  his fellow Israelite.
* __[11:02](https://git.door43.org/Door43/en_tn/src/master/obs/11/02.md)__ God provided a way to __save__  the firstborn son of anyone who believed in him.
* __[12:05](https://git.door43.org/Door43/en_tn/src/master/obs/12/05.md)__ Moses told the Israelites, "Stop being afraid! God will fight for you today and __save__  you."
* __[12:13](https://git.door43.org/Door43/en_tn/src/master/obs/12/13.md)__ The Israelites sang many songs to celebrate their new freedom and to praise God because he __saved__  them from the Egyptian army.
* __[16:17](https://git.door43.org/Door43/en_tn/src/master/obs/16/17.md)__ This pattern repeated many times: the Israelites would sin, God would punish them, they would repent, and God would send a deliverer to __save__  them.
* __[44:08](https://git.door43.org/Door43/en_tn/src/master/obs/44/08.md)__ "You crucified Jesus, but God raised him to life again! You rejected him, but there is no other way to be __saved__  except through the power of Jesus!"
* __[47:11](https://git.door43.org/Door43/en_tn/src/master/obs/47/11.md)__ The jailer trembled as he came to Paul and Silas and asked, "What must I do to be __saved__?" Paul answered, "Believe in Jesus, the Master, and you and your family will be __saved__."
* __[49:12](https://git.door43.org/Door43/en_tn/src/master/obs/49/12.md)__ Good works cannot __save__  you.
* __[49:13](https://git.door43.org/Door43/en_tn/src/master/obs/49/13.md)__ God will __save__  everyone who believes in Jesus and receives him as their Master. But he will not __save__  anyone who does not believe in him.


### Word Data:

* Strong's: H983, H2421, H3444, H3467, H3468, H4190, H4422, H4931, H6403, H7682, H7951, H7965, H8104, H8668, G803, G804, G806, G1295, G1508, G4982, G4991, G4992, G5198


## <a id="tw-term-kt-savior"/>Savior, savior

### Facts:

The term "savior" refers to a person who saves or rescues others from danger. It can also refer to someone who gives strength to others or provides for them.

* In the Old Testament, God is referred to as Israel's Savior because he often rescued them from their enemies, gave them strength, and provided them with what they needed to live.
* In the New Testament, "Savior" is used as a description or title for Jesus Christ because he saves people from being eternally punished for their sin. He also saves them from being controlled by their sin.

### Translation Suggestions:

* If possible, "Savior" should be translated with a word that is related to the words "save" and "salvation."
* Ways to translate this term could include "the One who saves" or "God, who saves" or "who delivers from danger" or "who rescues from enemies" or "Jesus, the one who rescues (people) from sin."

(See also: [deliver](other.html#deliverer), [Jesus](#jesus), [save](#save), [save](#save))

### Bible References:

* [1 Timothy 04:9-10](https://git.door43.org/Door43/en_tn/src/master/1ti/04/09.md)
* [2 Peter 02:20-22](https://git.door43.org/Door43/en_tn/src/master/2pe/02/20.md)
* [Acts 05:29-32](https://git.door43.org/Door43/en_tn/src/master/act/05/29.md)
* [Isaiah 60:15-16](https://git.door43.org/Door43/en_tn/src/master/isa/60/15.md)
* [Luke 01:46-47](https://git.door43.org/Door43/en_tn/src/master/luk/01/46.md)
* [Psalms 106:19-21](https://git.door43.org/Door43/en_tn/src/master/psa/106/019.md)


### Word Data:

* Strong's: H3467, G4990


## <a id="tw-term-kt-scribe"/>scribe, scribes

### Definition:

Scribes were officials who were responsible for writing or copying important government or religious documents by hand. Another name for a Jewish scribe was "expert in Jewish law."

* Scribes were responsible for copying and preserving the books of the Old Testament.
* They also copied, preserved, and interpreted religious opinions and commentary on the law of God.
* At times, scribes were important government officials.
* Important biblical scribes include Baruch and Ezra.
* In the New Testament, the term translated "scribes" was also translated as "teachers of the Law."
* In the New Testament, scribes were usually part of the religious group called the "Pharisees," and the two groups were frequently mentioned together.


(See also: [law](#lawofmoses), [Pharisee](#pharisee))

### Bible References:

* [Acts 04:5-7](https://git.door43.org/Door43/en_tn/src/master/act/04/05.md)
* [Luke 07:29-30](https://git.door43.org/Door43/en_tn/src/master/luk/07/29.md)
* [Luke 20:45-47](https://git.door43.org/Door43/en_tn/src/master/luk/20/45.md)
* [Mark 01:21-22](https://git.door43.org/Door43/en_tn/src/master/mrk/01/21.md)
* [Mark 02:15-16](https://git.door43.org/Door43/en_tn/src/master/mrk/02/15.md)
* [Matthew 05:19-20](https://git.door43.org/Door43/en_tn/src/master/mat/05/19.md)
* [Matthew 07:28-29](https://git.door43.org/Door43/en_tn/src/master/mat/07/28.md)
* [Matthew 12:38-40](https://git.door43.org/Door43/en_tn/src/master/mat/12/38.md)
* [Matthew 13:51-53](https://git.door43.org/Door43/en_tn/src/master/mat/13/51.md)


### Word Data:

* Strong's: H5608, H5613, H7083, G1122


## <a id="tw-term-kt-setapart"/>set apart

### Definition:

The term "set apart" means separated from something to fulfill a certain purpose. Also, to "set apart" some person or thing means to make it "set apart."

* The Israelites were set apart for service to God.
* The Holy Spirit commanded the Christians at Antioch to set apart Paul and Barnabas for the work God wanted them to do.
* A believer who is "set apart" for service to God is "dedicated to" fulfilling God's will.
* One meaning of the term "holy" is to be set apart as belonging to God and being separated from the sinful ways of the world.
* To "sanctify" someone means to set apart that person for God's service.

### Translation Suggestions:

* Ways to translate to "set apart" could include to "specially select" or to "separate from among you" or to "take aside to do a special task."
* To "be set apart" could be translated as "be separated (from)" or "be specially appointed (for)."

(See also: [holy](#holy), [sanctify](#sanctify), [appoint](#appoint))

### Bible References:

* [Ephesians 03:17-19](https://git.door43.org/Door43/en_tn/src/master/eph/03/17.md)
* [Exodus 31:12-15](https://git.door43.org/Door43/en_tn/src/master/exo/31/12.md)
* [Judges 17:12-13](https://git.door43.org/Door43/en_tn/src/master/jdg/17/12.md)
* [Numbers 03:11-13](https://git.door43.org/Door43/en_tn/src/master/num/03/11.md)
* [Philippians 01:1-2](https://git.door43.org/Door43/en_tn/src/master/php/01/01.md)
* [Romans 01:1-3](https://git.door43.org/Door43/en_tn/src/master/rom/01/01.md)

### Word Data:

* Strong's: H2764, H4390, H5674, H6918, H6942, H6944, G37, G38, G40, G873


## <a id="tw-term-kt-sign"/>sign, signs, proof, reminder

### Definition:

A sign is an object, event, or action that communicates a special meaning.

* "Reminders" are signs that "remind" people by helping them remember something, often something that was promised:
    * The rainbows God creates in the sky are signs to remind people that he has promised he will never again destroy all life with a worldwide flood.
    * God commanded the Israelites to circumcise their sons as a sign of his covenant with them.
* Signs can reveal or point to something:
    * An angel gave shepherds a sign that would help them know which baby in Bethlehem was the newborn Messiah.\
    * Judas kissed Jesus as a sign to the religious leaders that Jesus was the one they should arrest.
* Signs can prove that something is true:
    * The miracles performed by the prophets and apostles were signs that proved they were speaking God's message.
    * The miracles that Jesus performed were signs that proved he was truly the Messiah.

### Translation Suggestions:

* Depending on its context, "sign" could also be translated as "signal" or "symbol" or "mark" or "evidence" or "proof" or "gesture."
* To "make signs with the hands" could also be translated as "motion with the hands" or "gesture with the hands" or "make gestures."
* In some languages, there may be one word for a "sign" that proves something and a different word for a "sign" that is a miracle.

(See also: [miracle](#miracle), [apostle](#apostle), [Christ](#christ), [covenant](#covenant), [circumcise](#circumcise))

### Bible References:

* [Acts 02:18-19](https://git.door43.org/Door43/en_tn/src/master/act/02/18.md)
* [Exodus 04:8-9](https://git.door43.org/Door43/en_tn/src/master/exo/04/08.md)
* [Exodus 31:12-15](https://git.door43.org/Door43/en_tn/src/master/exo/31/12.md)
* [Genesis 01:14-15](https://git.door43.org/Door43/en_tn/src/master/gen/01/14.md)
* [Genesis 09:11-13](https://git.door43.org/Door43/en_tn/src/master/gen/09/11.md)
* [John 02:17-19](https://git.door43.org/Door43/en_tn/src/master/jhn/02/17.md)
* [Luke 02:10-12](https://git.door43.org/Door43/en_tn/src/master/luk/02/10.md)
* [Mark 08:11-13](https://git.door43.org/Door43/en_tn/src/master/mrk/08/11.md)
* [Psalms 089:5-6](https://git.door43.org/Door43/en_tn/src/master/psa/089/005.md)


### Word Data:

* Strong's: H226, H852, H2368, H2858, H4150, H4159, H4864, H5251, H5824, H6161, H6725, H6734, H7560, G364, G880, G1213, G1229, G1718, G1730, G1732, G1770, G3902, G4102, G4591, G4592, G4953, G4973, G5280


## <a id="tw-term-kt-sin"/>sin, sins, sinned, sinful, sinner, sinning

### Definition:

The term "sin" refers to actions, thoughts, and words that are against God's will and laws. Sin can also refer to not doing something that God wants us to do.

* Sin includes anything we do that does not obey or please God, even things that other people don't know about.
* Thoughts and actions that disobey God's will are called "sinful."
* Because Adam sinned, all human beings are born with a "sinful nature," a nature that that controls them and causes them to sin.
* A "sinner" is someone who sins, so every human being is a sinner.
* Sometimes the word "sinners" was used by religious people like the Pharisees to refer to people who didn't keep the law as well as the Pharisees thought they should.
* The term "sinner" was also used for people who were considered to be worse sinners than other people. For example, this label was given to tax collectors and prostitutes.

### Translation Suggestions:

* The term "sin" could be translated with a word or phrase that means "disobedience to God" or "going against God's will" or "evil behavior and thoughts" or "wrongdoing."
* To "sin" could also be translated as to "disobey God" or to "do wrong."
* Depending on the context "sinful" could be translated as  "full of wrongdoing" or "wicked" or "immoral" or "evil" or "rebelling against God."
* Depending on the context the term "sinner" could be translated with a word or phrase that means, "person who sins" or "person who does wrong things" or "person who disobeys God" or "person who disobeys the law."
* The term "sinners" could be translated by a word or phrase that means "very sinful people" or "people considered to be very sinful" or "immoral people."
* Ways to translate "tax collectors and sinners" could include "people who collect money for the government, and other very sinful people" or "very sinful people, including (even) tax collectors."
* In expressions like "slaves to sin" or "ruled by sin," the term "sin" could be translated as "disobedience" or "evil desires and actions."
* Make sure the translation of this term can include sinful behavior and thoughts, even those that other people don't see or know about.
* The term "sin" should be general, and different from the terms for "wickedness" and "evil."

(See also: [disobey](other.html#disobey), [evil](#evil), [flesh](#flesh), [tax collector](other.html#taxcollector))

### Bible References:

* [1 Chronicles 09:1-3](https://git.door43.org/Door43/en_tn/src/master/1ch/09/01.md)
* [1 John 01:8-10](https://git.door43.org/Door43/en_tn/src/master/1jn/01/08.md)
* [1 John 02:1-3](https://git.door43.org/Door43/en_tn/src/master/1jn/02/01.md)
* [2 Samuel 07:12-14](https://git.door43.org/Door43/en_tn/src/master/2sa/07/12.md)
* [Acts 03:19-20](https://git.door43.org/Door43/en_tn/src/master/act/03/19.md)
* [Daniel 09:24-25](https://git.door43.org/Door43/en_tn/src/master/dan/09/24.md)
* [Genesis 04:6-7](https://git.door43.org/Door43/en_tn/src/master/gen/04/06.md)
* [Hebrews 12:1-3](https://git.door43.org/Door43/en_tn/src/master/heb/12/01.md)
* [Isaiah 53:10-11](https://git.door43.org/Door43/en_tn/src/master/isa/53/10.md)
* [Jeremiah 18:21-23](https://git.door43.org/Door43/en_tn/src/master/jer/18/21.md)
* [Leviticus 04:13-15](https://git.door43.org/Door43/en_tn/src/master/lev/04/13.md)
* [Luke 15:17-19](https://git.door43.org/Door43/en_tn/src/master/luk/15/17.md)
* [Matthew 12:31-32](https://git.door43.org/Door43/en_tn/src/master/mat/12/31.md)
* [Romans 06:22-23](https://git.door43.org/Door43/en_tn/src/master/rom/06/22.md)
* [Romans 08:3-5](https://git.door43.org/Door43/en_tn/src/master/rom/08/03.md)

### Examples from the Bible stories:

* __[03:15](https://git.door43.org/Door43/en_tn/src/master/obs/03/15.md)__ God said, "I promise I will never again curse the ground because of the evil things people do, or destroy the world by causing a flood, even though people are __sinful__  from the time they are children."
* __[13:12](https://git.door43.org/Door43/en_tn/src/master/obs/13/12.md)__ God was very angry with them because of their __sin__  and planned to destroy them.
* __[20:01](https://git.door43.org/Door43/en_tn/src/master/obs/20/01.md)__ The kingdoms of Israel and Judah both __sinned__  against God. They broke the covenant that God made with them at Sinai.
* __[21:13](https://git.door43.org/Door43/en_tn/src/master/obs/21/13.md)__ The prophets also said that the Messiah would be perfect, having no __sin__. He would die to receive the punishment for other people's __sin__.
* __[35:01](https://git.door43.org/Door43/en_tn/src/master/obs/35/01.md)__ One day, Jesus was teaching many tax collectors and other __sinners__  who had gathered to hear him.
* __[38:05](https://git.door43.org/Door43/en_tn/src/master/obs/38/05.md)__ Then Jesus took a cup and said, "Drink this. It is my blood of the New Covenant that is poured out for the forgiveness of __sins__.
* __[43:11](https://git.door43.org/Door43/en_tn/src/master/obs/43/11.md)__ Peter answered them, "Every one of you should repent and be baptized in the name of Jesus Christ so that God will forgive your __sins__."
* __[48:08](https://git.door43.org/Door43/en_tn/src/master/obs/48/08.md)__ We all deserve to die for our __sins__!
* __[49:17](https://git.door43.org/Door43/en_tn/src/master/obs/49/17.md)__ Even though you are a Christian, you will still be tempted to __sin__. But God is faithful and says that if you confess your __sins__, he will forgive you. He will give you strength to fight against __sin__.


### Word Data:

* Strong's: H817, H819, H2398, H2399, H2400, H2401, H2402, H2403, H2408, H2409, H5771, H6588, H7683, H7686, G264, G265, G266, G268, G361, G3781, G3900, G4258


## <a id="tw-term-kt-son"/>son, sons

### Definition:

The male offspring of a man and a woman is called their "son" for his entire life.  He is also called a son of that man and a son of that woman. An "adopted son" is a male who has been legally placed into the position of being a son.

* "Son" was often used figuratively in the Bible to refer to any male descendant, such as a grandson or great-grandson.
* The term "son" can also be used as a polite form of address to a boy or man who is younger than the speaker.
* Sometimes "sons of God" was used in the New Testament to refer to believers in Christ.
* God called Israel his "firstborn son." This refers to God's choosing of the nation of Israel to be his special people. It is through them that God's message of redemption and salvation came, with the result that many other people have become his spiritual children.
* The phrase "son of" often has the figurative meaning "person having the characteristics of." Examples of this include "sons of the light," "sons of disobedience," "a son of peace," and "sons of thunder."
* The phrase "son of" is also used to tell who a person's father is. This phrase is used in genealogies and many other places.
* Using "son of" to give the name of the father frequently helps distinguish people who have the same name. For example, "Azariah son of Zadok" and "Azariah son of Nathan" in 1 Kings 4, and "Azariah son of Amaziah" in 2 Kings 15 are three different men.

### Translation Suggestions:

* In most occurrences of this term, it is best to translate "son" by the literal term in the language that is used to refer to a son.
* When translating the term "Son of God," the project language's common term for "son" should be used.
* When used to refer to a descendant rather than a direct son, the term "descendant" could be used, as in referring to Jesus as the "descendant of David" or in genealogies where sometimes "son" referred to a male descendant who was not an actual son.
* Sometimes "sons" can be translated as "children," when both males and females are being referred to. For example, "sons of God" could be translated as "children of God" since this expression also includes girls and women.
* The figurative expression "son of" could also be translated as "someone who has the characteristics of" or "someone who is like" or "someone who has" or "someone who acts like."

(See also: [Azariah](names.html#azariah), [descendant](other.html#descendant), [ancestor](other.html#father), [firstborn](other.html#firstborn), [Son of God](#sonofgod), [sons of God](#sonsofgod))

### Bible References:

* [1 Chronicles 18:14-17](https://git.door43.org/Door43/en_tn/src/master/1ch/18/14.md)
* [1 Kings 13:1-3](https://git.door43.org/Door43/en_tn/src/master/1ki/13/01.md)
* [1 Thessalonians 05:4-7](https://git.door43.org/Door43/en_tn/src/master/1th/05/04.md)
* [Galatians 04:6-7](https://git.door43.org/Door43/en_tn/src/master/gal/04/06.md)
* [Hosea 11:1-2](https://git.door43.org/Door43/en_tn/src/master/hos/11/01.md)
* [Isaiah 09:6-7](https://git.door43.org/Door43/en_tn/src/master/isa/09/06.md)
* [Matthew 03:16-17](https://git.door43.org/Door43/en_tn/src/master/mat/03/16.md)
* [Matthew 05:9-10](https://git.door43.org/Door43/en_tn/src/master/mat/05/09.md)
* [Matthew 08:11-13](https://git.door43.org/Door43/en_tn/src/master/mat/08/11.md)
* [Nehemiah 10:28-29](https://git.door43.org/Door43/en_tn/src/master/neh/10/28.md)

### Examples from the Bible stories:

* __[04:08](https://git.door43.org/Door43/en_tn/src/master/obs/04/08.md)__ God spoke to Abram and promised again that he would have a __son__  and as many descendants as the stars in the sky.
* __[04:09](https://git.door43.org/Door43/en_tn/src/master/obs/04/09.md)__ God said, "I will give you a __son__  from your own body."
* __[05:05](https://git.door43.org/Door43/en_tn/src/master/obs/05/05.md)__ About a year later, when Abraham was 100 years old and Sarah was 90, Sarah gave birth to Abraham's __son__.
* __[05:08](https://git.door43.org/Door43/en_tn/src/master/obs/05/08.md)__ When they reached the place of sacrifice, Abraham tied up his __son__  Isaac and laid him on an altar. He was about to kill his __son__  when God said, "Stop! Do not hurt the boy! Now I know that you fear me because you did not keep your only __son__  from me."
* __[09:07](https://git.door43.org/Door43/en_tn/src/master/obs/09/07.md)__ When she saw the baby, she took him as her own __son__.
* __[11:06](https://git.door43.org/Door43/en_tn/src/master/obs/11/06.md)__ God killed every one of the Egyptians' firstborn __sons__.
* __[18:01](https://git.door43.org/Door43/en_tn/src/master/obs/18/01.md)__ After many years, David died, and his __son__  Solomon began to rule.
* __[26:04](https://git.door43.org/Door43/en_tn/src/master/obs/26/04.md)__ "Is this the __son__  of Joseph?â€š" they said.


### Word Data:

* Strong's: H1060, H1121, H1123, H1248, H3173, H3206, H3211, H4497, H5209, H5220, G3816, G5043, G5207


## <a id="tw-term-kt-sonofgod"/>Son of God, Son

### Facts:

The term "Son of God" refers to Jesus, the Word of God, who came into the world as a human being. He is also often referred to as "the Son."

* The Son of God has the same nature as God the Father, and is fully God.
* God the Father, God the Son, and God the Holy Spirit are all of one essence.
* Unlike human sons, the Son of God has always existed.
* In the beginning, the Son of God was active in creating the world, along with the Father and the Holy Spirit.
Because Jesus is God's Son, he loves and obeys his Father, and his Father loves him.

### Translation Suggestions:

* For the term "Son of God," it is best to translate "Son" with the same word the language would naturally use to refer to a human son.
* Make sure the word used to translate "son" fits with the word used to translate "father" and that these words are the most natural ones used to express a true father-son relationship in the project language.
* Using a capital letter to begin "Son" may help show that this is talking about God.
* The phrase "the Son" is a shortened form of "the Son of God," especially when it occurs in the same context as "the Father."

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Christ](#christ), [ancestor](other.html#father), [God](#god), [God the Father](#godthefather), [Holy Spirit](#holyspirit), [Jesus](#jesus), [son](#son), [sons of God](#sonsofgod))

### Bible References:

* [1 John 04:9-10](https://git.door43.org/Door43/en_tn/src/master/1jn/04/09.md)
* [Acts 09:20-22](https://git.door43.org/Door43/en_tn/src/master/act/09/20.md)
* [Colossians 01:15-17](https://git.door43.org/Door43/en_tn/src/master/col/01/15.md)
* [Galatians 02:20-21](https://git.door43.org/Door43/en_tn/src/master/gal/02/20.md)
* [Hebrews 04:14-16](https://git.door43.org/Door43/en_tn/src/master/heb/04/14.md)
* [John 03:16-18](https://git.door43.org/Door43/en_tn/src/master/jhn/03/16.md)
* [Luke 10:22](https://git.door43.org/Door43/en_tn/src/master/luk/10/22.md)
* [Matthew 11:25-27](https://git.door43.org/Door43/en_tn/src/master/mat/11/25.md)
* [Revelation 02:18-19](https://git.door43.org/Door43/en_tn/src/master/rev/02/18.md)
* [Romans 08:28-30](https://git.door43.org/Door43/en_tn/src/master/rom/08/28.md)

### Examples from the Bible stories:

* __[22:05](https://git.door43.org/Door43/en_tn/src/master/obs/22/05.md)__ The angel explained, "The Holy Spirit will come to you, and the power of God will overshadow you. So the baby will be holy, the __Son of God__."
* __[24:09](https://git.door43.org/Door43/en_tn/src/master/obs/24/09.md)__ God had told John, "The Holy Spirit will come down and rest on someone you baptize. That person is __the Son of God__."
* __[31:08](https://git.door43.org/Door43/en_tn/src/master/obs/31/08.md)__ The disciples were amazed. They worshiped Jesus, saying to him, "Truly, you are __the Son of God__."
* __[37:05](https://git.door43.org/Door43/en_tn/src/master/obs/37/05.md)__ Martha answered, "Yes, Master! I believe you are the Messiah, the __Son of God__."
* __[42:10](https://git.door43.org/Door43/en_tn/src/master/obs/42/10.md)__ So go, make disciples of all people groups by baptizing them in the name of the Father, __the Son__, and the Holy Spirit, and by teaching them to obey everything I have commanded you."
* __[46:06](https://git.door43.org/Door43/en_tn/src/master/obs/46/06.md)__ Right away, Saul began preaching to the Jews in Damascus, saying, "Jesus is the __Son of God__!"
* __[49:09](https://git.door43.org/Door43/en_tn/src/master/obs/49/09.md)__ But God loved everyone in the world so much that he gave his only __Son__  so that whoever believes in Jesus will not be punished for his sins, but will live with God forever.


### Word Data:

* Strong's: H426, H430, H1121, H1247, G2316, G5207


## <a id="tw-term-kt-sonofman"/>Son of Man, son of man

### Definition:

The title "Son of Man" was used by Jesus to refer to himself. He often used this term instead of saying "I" or "me."

* In the Bible, "son of man" could be a way of referring to or addressing a man. It could also mean "human being."
* Throughout the Old Testament book of Ezekiel, God frequently addressed Ezekiel as "son of man." For example he said, "You, son of man, must prophesy."
* The prophet Daniel saw a vision of a "son of man" coming with the clouds, which is a reference to the coming Messiah.
* Jesus also said that the Son of Man will be coming back someday on the clouds.
* These references to the Son of Man coming on the clouds reveal that Jesus the Messiah is God.

### Translation Suggestions:

* When Jesus uses the term "Son of Man" it could be translated as "the One who became a human being" or "the Man from heaven."
* Some translators occasionally include "I" or "me" with this title (as in "I, the Son of Man") to make it clear that Jesus was talking about himself.
* Check to make sure that the translation of this term does not give a wrong meaning (such as referring to an illegitimate son or giving the wrong impression that Jesus was only a human being).
* When used to refer to a person, "son of man" could also be translated as "you, a human being" or "you, man" or "human being" or "man."

(See also: [heaven](#heaven), [son](#son), [Son of God](#sonofgod), [Yahweh](#yahweh))
 

### Bible References:

* [Acts 07:54-56](https://git.door43.org/Door43/en_tn/src/master/act/07/54.md)
* [Daniel 07:13-14](https://git.door43.org/Door43/en_tn/src/master/dan/07/13.md)
* [Ezekiel 43:6-8](https://git.door43.org/Door43/en_tn/src/master/ezk/43/06.md)
* [John 03:12-13](https://git.door43.org/Door43/en_tn/src/master/jhn/03/12.md)
* [Luke 06:3-5](https://git.door43.org/Door43/en_tn/src/master/luk/06/03.md)
* [Mark 02:10-12](https://git.door43.org/Door43/en_tn/src/master/mrk/02/10.md)
* [Matthew 13:36-39](https://git.door43.org/Door43/en_tn/src/master/mat/13/36.md)
* [Psalms 080:17-18](https://git.door43.org/Door43/en_tn/src/master/psa/080/017.md)
* [Revelation 14:14-16](https://git.door43.org/Door43/en_tn/src/master/rev/14/14.md)
{{tag>publish ktlink}

### Word Data:

* Strong's: H120, H606, H1121, H1247, G444, G5207


## <a id="tw-term-kt-sonsofgod"/>sons of God

### Definition:

The term "sons of God" is a figurative expression that has several possible meanings.

* In the New Testament, the term "sons of God" refers to all believers in Jesus and is often translated as "children of God" since it includes both males and females.
* This use of the term speaks of a relationship with God that is like the relationship between a human son and his father, with all the privileges associated with being sons.
* Some people interpret the term "sons of God" that appears in Genesis 6  to mean fallen angels—evil spirits or demons. Others think it may refer to powerful political rulers or to the descendants of Seth.
* In the New Testament, the term "sons of God" refers to all believers in Jesus and is often translated as "children of God" since it includes both males and females.
* This use of the term speaks of a relationship with God that is like the relationship between human sons and their father, with all the privileges associated with being sons.
* The title "Son of God" is a different term: it refers to Jesus, who is God's only Son.

### Translation Suggestions:

* When "sons of God" refers to believers in Jesus, it could be translated as "children of God."
* In Genesis 6:2 and 4 ways to translate "sons of God" could include "angels," "spirit beings," "supernatural creatures," or "demons."
* Also see the link for "son."
 

(See also: [angel](#angel), [demon](#demon), [son](#son), [Son of God](#sonofgod), [ruler](other.html#ruler), [spirit](#spirit))

### Bible References:

* [Genesis 06:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/06/01.md)
* [Genesis 06:4](https://git.door43.org/Door43/en_tn/src/master/gen/06/04.md)
* [Job 01:6-8](https://git.door43.org/Door43/en_tn/src/master/job/01/06.md)
* [Romans 08:14-15](https://git.door43.org/Door43/en_tn/src/master/rom/08/14.md)

### Word Data:

* Strong's: H430, H1121, G2316, G5043, G5207


## <a id="tw-term-kt-soul"/>soul, souls

### Definition:

The soul is the inner, invisible, and eternal part of a person. It refers to the non-physical part of a person.

* The terms "soul" and "spirit" may be two different concepts, or they may be two terms that refer to the same concept.
* When a person dies, his soul leaves his body.
* The word "soul" is sometimes used figuratively to refer to the whole person. For example, "the soul who sins" means "the person who sins" and "my soul is tired" means,"I am tired."

### Translation Suggestions:

* The term "soul" could also be translated as "inner self" or "inner person."
* In some contexts, "my soul" could be translated as "I" or "me."
* Usually the phrase "the soul" can be translated as "the person" or "he" or "him," depending on the context.
* Some languages might only have one word for the concepts "soul" and "spirit."
* In Hebrews 4:12, the figurative phrase "dividing soul and spirit" could mean "deeply discerning or exposing the inner person."

(See also: [spirit](#spirit))

### Bible References:

* [2 Peter 02:7-9](https://git.door43.org/Door43/en_tn/src/master/2pe/02/07.md)
* [Acts 02:27-28](https://git.door43.org/Door43/en_tn/src/master/act/02/27.md)
* [Acts 02:40-42](https://git.door43.org/Door43/en_tn/src/master/act/02/40.md)
* [Genesis 49:5-6](https://git.door43.org/Door43/en_tn/src/master/gen/49/05.md)
* [Isaiah 53:10-11](https://git.door43.org/Door43/en_tn/src/master/isa/53/10.md)
* [James 01:19-21](https://git.door43.org/Door43/en_tn/src/master/jas/01/19.md)
* [Jeremiah 06:16-19](https://git.door43.org/Door43/en_tn/src/master/jer/06/16.md)
* [Jonah 02:7-8](https://git.door43.org/Door43/en_tn/src/master/jon/02/07.md)
* [Luke 01:46-47](https://git.door43.org/Door43/en_tn/src/master/luk/01/46.md)
* [Matthew 22:37-38](https://git.door43.org/Door43/en_tn/src/master/mat/22/37.md)
* [Psalms 019:7-8](https://git.door43.org/Door43/en_tn/src/master/psa/019/007.md)
* [Revelation 20:4](https://git.door43.org/Door43/en_tn/src/master/rev/20/04.md)


### Word Data:

* Strong's: H5082, H5315, H5397, G5590


## <a id="tw-term-kt-spirit"/>spirit, spirits, spiritual

### Definition:

The term "spirit" refers to the non-physical part of people which cannot be seen. When a person dies, his spirit leaves his body. "Spirit" can also refer to an attitude or emotional state.

* The term "spirit" can refer to a being that does not have a physical body, especially an evil spirit.
* A person's spirit is the part of him that can know God and believe in him.
* In general, the term "spiritual" describes anything in the non-physical world.
* In the Bible, it especially refers to anything that relates to God, specifically to the Holy Spirit.
* For example, "spiritual food" refers to God's teachings, which give nourishment to a person's spirit, and "spiritual wisdom" refers to the knowledge and righteous behavior that come from the power of the Holy Spirit.
* God is a spirit and he created other spirit beings, who do not have physical bodies.
* Angels are spirit beings, including those who rebelled against God and became evil spirits.
* The term "spirit of" can also mean "having the characteristics of," such as in "spirit of wisdom" or "in the spirit of Elijah."
* Examples of "spirit" as an attitude or emotion would include "spirit of fear" and "spirit of jealousy."

### Translation Suggestions:

* Depending on the context, some ways to translate "spirit" might include "non-physical being" or "inside part" or "inner being."
* In some contexts, the term "spirit" could be translated as "evil spirit" or "evil spirit being."
* Sometimes the term "spirit" is used to express the feelings of a person, as in "my spirit was grieved in my inmost being." This could also be translated as "I felt grieved in my spirit" or "I felt deeply grieved."
* The phrase "spirit of" could be translated as "character of" or "influence of" or "attitude of" or "thinking (that is) characterized by."
* Depending on the context, "spiritual" could be translated as "non-physical" or "from the Holy Spirit" or "God's" or "part of the non-physical world."
* The figurative expression "spiritual milk" could also be translated as "basic teachings from God" or "God's teachings that nourish the spirit (like milk does)."
* The phrase "spiritual maturity" could be translated as "godly behavior that shows obedience to the Holy Spirit."
* The term "spiritual gift" could be translated as "special ability that the Holy Spirit gives

(See also: [angel](#angel), [demon](#demon), [Holy Spirit](#holyspirit), [soul](#soul))

### Bible References:

* [1 Corinthians 05:3-5](https://git.door43.org/Door43/en_tn/src/master/1co/05/03.md)
* [1 John 04:1-3](https://git.door43.org/Door43/en_tn/src/master/1jn/04/01.md)
* [1 Thessalonians 05:23-24](https://git.door43.org/Door43/en_tn/src/master/1th/05/23.md)
* [Acts 05:9-11](https://git.door43.org/Door43/en_tn/src/master/act/05/09.md)
* [Colossians 01:9-10](https://git.door43.org/Door43/en_tn/src/master/col/01/09.md)
* [Ephesians 04:23-24](https://git.door43.org/Door43/en_tn/src/master/eph/04/23.md)
* [Genesis 07:21-22](https://git.door43.org/Door43/en_tn/src/master/gen/07/21.md)
* [Isaiah 04:3-4](https://git.door43.org/Door43/en_tn/src/master/isa/04/03.md)
* [Mark 01:23-26](https://git.door43.org/Door43/en_tn/src/master/mrk/01/23.md)
* [Matthew 26:39-41](https://git.door43.org/Door43/en_tn/src/master/mat/26/39.md)
* [Philippians 01:25-27](https://git.door43.org/Door43/en_tn/src/master/php/01/25.md)

### Examples from the Bible stories:

* __[13:03](https://git.door43.org/Door43/en_tn/src/master/obs/13/03.md)__ Three days later, after the people had prepared themselves __spiritually__, God came down on top of Mount Sinai with thunder, lightning, smoke, and a loud trumpet blast.
* __[40:07](https://git.door43.org/Door43/en_tn/src/master/obs/40/07.md)__ Then Jesus cried out, "It is finished! Father, I give my __spirit__  into your hands." Then he bowed his head and gave up his __spirit__.
* __[45:05](https://git.door43.org/Door43/en_tn/src/master/obs/45/05.md)__ As Stephen was dying, he cried out, "Jesus, receive my __spirit__."
* __[48:07](https://git.door43.org/Door43/en_tn/src/master/obs/48/07.md)__ All the people groups are blessed through him, because everyone who believes in Jesus is saved from sin, and becomes a __spiritual__  descendant of Abraham.


### Word Data:

* Strong's: H178, H1172, H5397, H7307, H7308, G4151, G4152, G4153, G5326, G5427


## <a id="tw-term-kt-stone"/>stone, stones, stoning

### Definition:

A stone is a small rock. To "stone" someone is to throw stones and larger rocks at that person with the intention of killing him. A "stoning" is an event in which someone was stoned.

* In ancient times, stoning was a common method of executing people as punishment for crimes they had committed.
* God commanded the Israelite leaders to stone people for certain sins, such as adultery.
* In the New Testament, Jesus forgave a woman caught in adultery and stopped people from stoning her.
* Stephen, who was the first person in the Bible to be killed for testifying about Jesus, was stoned to death.
* In the city of Lystra, the apostle Paul was stoned, but he did not die from his wounds.

(See also: [adultery](#adultery), [commit](other.html#commit), [crime](other.html#criminal), [death](other.html#death), [Lystra](names.html#lystra), [testimony](#testimony))

### Bible References:

* [Acts 07:57-58](https://git.door43.org/Door43/en_tn/src/master/act/07/57.md)
* [Acts 07:59-60](https://git.door43.org/Door43/en_tn/src/master/act/07/59.md)
* [Acts 14:5-7](https://git.door43.org/Door43/en_tn/src/master/act/14/05.md)
* [Acts 14:19-20](https://git.door43.org/Door43/en_tn/src/master/act/14/19.md)
* [John 08:4-6](https://git.door43.org/Door43/en_tn/src/master/jhn/08/04.md)
* [Luke 13:34-35](https://git.door43.org/Door43/en_tn/src/master/luk/13/34.md)
* [Luke 20:5-6](https://git.door43.org/Door43/en_tn/src/master/luk/20/05.md)
* [Matthew 23:37-39](https://git.door43.org/Door43/en_tn/src/master/mat/23/37.md)


### Word Data:

* Strong's: H68, H69, H810, H1382, H1496, H1530, H2106, H2672, H2687, H2789, H4676, H4678, H5553, H5601, H5619, H6344, H6443, H6697, H6864, H6872, H7275, H7671, H8068, G2642, G2991, G3034, G3035, G3036, G3037, G4074, G4348, G5586


## <a id="tw-term-kt-synagogue"/>synagogue

### Definition:

A synagogue is a building where Jewish people meet together to worship God.

 * Since ancient times, a synagogue's services have included times of prayer, scripture reading, and teaching about the scriptures.
 * The Jews originally started building synagogues as places to pray and worship God in their own cities, because many of them lived far away from the temple in Jerusalem.
 * Jesus often taught in synagogues and healed people there.
 * The word "synagogue" can be used figuratively to refer to the group of people meeting there. 

(See also: [heal](other.html#heal), [Jerusalem](names.html#jerusalem), [Jew](#jew), [pray](#pray), [temple](#temple), [word of God](#wordofgod), [worship](#worship))

### Bible References:

* [Acts 06:8-9](https://git.door43.org/Door43/en_tn/src/master/act/06/08.md)
* [Acts 14:1-2](https://git.door43.org/Door43/en_tn/src/master/act/14/01.md)
* [Acts 15:19-21](https://git.door43.org/Door43/en_tn/src/master/act/15/19.md)
* [Acts 24:10-13](https://git.door43.org/Door43/en_tn/src/master/act/24/10.md)
* [John 06:57-59](https://git.door43.org/Door43/en_tn/src/master/jhn/06/57.md)
* [Luke 04:14-15](https://git.door43.org/Door43/en_tn/src/master/luk/04/14.md)
* [Matthew 06:1-2](https://git.door43.org/Door43/en_tn/src/master/mat/06/01.md)
* [Matthew 09:35-36](https://git.door43.org/Door43/en_tn/src/master/mat/09/35.md)
* [Matthew 13:54-56](https://git.door43.org/Door43/en_tn/src/master/mat/13/54.md)

### Word Data:

* Strong's: H4150, G656, G752, G4864

## <a id="tw-term-kt-tabernacle"/>tabernacle

### Definition:

The tabernacle was a special tent-like structure where the Israelites worshiped God during the 40 years they traveled around in the desert.

* God had given the Israelites detailed instructions for building this large tent, which had two rooms and was surrounded by an enclosed courtyard.
* Each time the Israelites moved to a different place in the desert to live, the priests would take the tabernacle apart and carry it to their next campsite. Then they would set it up again in the center of their new camp.
* The tabernacle was constructed of wood frames hung with curtains made of cloth, goat hair, and animal skins. The courtyard surrounding it was enclosed with more curtains.
* The two sections of the tabernacle were the Holy Place (where the altar for burning incense was located) and the Most Holy Place (where the ark of the covenant was kept).
* The courtyard of the tabernacle had an altar for burning animal sacrifices and a special washbasin for ritual cleansing.
* The Israelites stopped using the tabernacle when the temple was built in Jerusalem by Solomon.

### Translation Suggestions:

* The word "tabernacle" means "dwelling place." Other ways to translate it could include, "sacred tent" or "tent where God was" or "God's tent."
* Make sure that the translation of this term is different from the translation of "temple."

(See also: [altar](#altar), [altar of incense](other.html#altarofincense), [ark of the covenant](#arkofthecovenant), [temple](#temple), [tent of meeting](other.html#tentofmeeting))

### Bible References:

* [1 Chronicles 21:28-30](https://git.door43.org/Door43/en_tn/src/master/1ch/21/28.md)
* [2 Chronicles 01:2-5](https://git.door43.org/Door43/en_tn/src/master/2ch/01/02.md)
* [Acts 07:43](https://git.door43.org/Door43/en_tn/src/master/act/07/43.md)
* [Acts 07:44-46](https://git.door43.org/Door43/en_tn/src/master/act/07/44.md)
* [Exodus 38:21-23](https://git.door43.org/Door43/en_tn/src/master/exo/38/21.md)
* [Joshua 22:19-20](https://git.door43.org/Door43/en_tn/src/master/jos/22/19.md)
* [Leviticus 10:16-18](https://git.door43.org/Door43/en_tn/src/master/lev/10/16.md)

### Word Data:

* Strong's: H168, H4908, H5520, H5521, H5522, H7900, G4633, G4634, G4636, G4638


## <a id="tw-term-kt-temple"/>temple

### Facts:

The temple was a building surrounded by walled courtyards where the Israelites came to pray and to offer sacrifices to God. It was located on Mount Moriah in the city of Jerusalem.

* Often the term "temple" referred to the whole temple complex, including the courtyards that surrounded the main building. Sometimes it referred only to the building.
* The temple building had two rooms, the Holy Place and the Most Holy Place.
* God referred to the temple as his dwelling place.
* King Solomon built the Temple during his reign. It was supposed to be the permanent place of worship in Jerusalem.
* In the New Testament, the term "temple of the Holy Spirit" is used to refer to believers in Jesus as a group, because the Holy Spirit lives in them.

### Translation Suggestions:

* Usually when the text says that people were "in the temple," it is referring to the courtyards outside the building. This could be translated as "in the temple courtyards" or "in the temple complex."
* Where it refers specifically to the building itself, some translations translate "temple" as "temple building," to make it the reference clear.
* Ways to translate "temple" could include, "God's holy house" or "sacred worship place."
* Often in the Bible, the temple is referred to as "the house of Yahweh" or "the house of God."

(See also: [sacrifice](other.html#sacrifice), [Solomon](names.html#solomon), [Babylon](names.html#babylon), [Holy Spirit](#holyspirit), [tabernacle](#tabernacle), [courtyard](other.html#courtyard), [Zion](#zion), [house](other.html#house))

### Bible References:

* [Acts 03:1-3](https://git.door43.org/Door43/en_tn/src/master/act/03/01.md)
* [Acts 03:7-8](https://git.door43.org/Door43/en_tn/src/master/act/03/07.md)
* [Ezekiel 45:18-20](https://git.door43.org/Door43/en_tn/src/master/ezk/45/18.md)
* [Luke 19:45-46](https://git.door43.org/Door43/en_tn/src/master/luk/19/45.md)
* [Nehemiah 10:28-29](https://git.door43.org/Door43/en_tn/src/master/neh/10/28.md)
* [Psalm 079:1-3](https://git.door43.org/Door43/en_tn/src/master/psa/079/001.md)

### Examples from the Bible stories:

* __[17:06](https://git.door43.org/Door43/en_tn/src/master/obs/17/06.md)__ David wanted to build a __temple__  where all the Israelites could worship God and offer him sacrifices.
* __[18:02](https://git.door43.org/Door43/en_tn/src/master/obs/18/02.md)__ In Jerusalem, Solomon built the __Temple__  for which his father David had planned and gathered materials. Instead of at the Tent of Meeting, people now worshiped God and offered sacrifices to him at the __Temple__. God came and was present in the __Temple__, and he lived there with his people.
* __[20:07](https://git.door43.org/Door43/en_tn/src/master/obs/20/07.md)__ They (Babylonians) captured the city of Jerusalem, destroyed the __Temple__, and took away all the treasures.
* __[20:13](https://git.door43.org/Door43/en_tn/src/master/obs/20/13.md)__ When the people arrived in Jerusalem, they rebuilt the __Temple__  and the wall around the city of the city and the __Temple__.
* __[25:04](https://git.door43.org/Door43/en_tn/src/master/obs/25/04.md)__ Then Satan took Jesus to the highest point on the __Temple__  and said, "If you are the Son of God, throw yourself down, for it is written, 'God will command his angels to carry you so your foot does not hit a stone.'"
* __[40:07](https://git.door43.org/Door43/en_tn/src/master/obs/40/07.md)__ When he died, there was an earthquake and the large curtain that separated the people from the presence of God in the __Temple__  was torn in two, from the top to the bottom.


### Word Data:

* Strong's: H1004, H1964, H1965, H7541, G1493, G2411, G3485


## <a id="tw-term-kt-tempt"/>tempt, temptation

### Definition:

To tempt someone is to try to get that person to do something wrong.

* A temptation is something that causes a person to want to do something wrong.
* People are tempted by their own sinful nature and by other people.
* Satan also tempts people to disobey God and to sin against God by doing wrong things.
* Satan tempted Jesus and tried to get him to do something wrong, but Jesus resisted all of Satan's temptations and never sinned.
* Someone who is "tempting God" is not trying to get him to do something wrong, but rather, is continuing in stubborn disobedience of him to the point that God must respond by punishing him. This is also called "testing God."

### Translation Suggestions:

* The term "tempt" can be translated as, "try to cause to sin" or "entice" or "cause a desire to sin."
* Ways to translate "temptations" could include, "things that tempt" or "things that entice someone to sin" or "things that cause desire to do something wrong.
* To "tempt God" could be translated as to "put God to the test" or to "test God" or to "try God's patience" or to "cause God to have to punish" or to "stubbornly keep disobeying God."

(See also: [disobey](other.html#disobey), [Satan](#satan), [sin](#sin), [test](#test)) 
### Bible References:

* [1 Thessalonians 03:4-5](https://git.door43.org/Door43/en_tn/src/master/1th/03/04.md)
* [Hebrews 04:14-16](https://git.door43.org/Door43/en_tn/src/master/heb/04/14.md)
* [James 01:12-13](https://git.door43.org/Door43/en_tn/src/master/jas/01/12.md)
* [Luke 04:1-2](https://git.door43.org/Door43/en_tn/src/master/luk/04/01.md)
* [Luke 11:3-4](https://git.door43.org/Door43/en_tn/src/master/luk/11/03.md)
* [Matthew 26:39-41](https://git.door43.org/Door43/en_tn/src/master/mat/26/39.md)

### Examples from the Bible stories:

* __[25:01](https://git.door43.org/Door43/en_tn/src/master/obs/25/01.md)__ Then Satan came to Jesus and __tempted__  him to sin.
* __[25:08](https://git.door43.org/Door43/en_tn/src/master/obs/25/08.md)__ Jesus did not give in to Satan's __temptations__, so Satan left him.
* __[38:11](https://git.door43.org/Door43/en_tn/src/master/obs/38/11.md)__ Jesus told his disciples to pray that they would not enter into __temptation__.

### Word Data:

* Strong's: H974, H4531, H5254, G551, G1598, G3985, G3986, G3987


## <a id="tw-term-kt-test"/>test, tests, tested

### Definition:

The term "test" refers to a difficult or painful experience that reveals a person's strengths and weaknesses. 

* God tests people, but he does not tempt them to sin. Satan, however, tempts people to sin.
* God sometimes uses tests to expose people's sin. A test helps a person to turn away from sin and to draw closer to God.
* Gold and other metals are tested with fire to find out how pure and strong they are. This is a picture of how God uses painful circumstances to test his people.
* To "put to the test" can mean, "challenge something or someone to prove its value." 
* In the context of putting God to the test, it means to try to make him do a miracle for us, taking advantage of his mercy.
* Jesus told Satan that it is wrong to put God to the test. He is the almighty, holy God who is above everything and everyone.

### Translation Suggestions:

* The term to "test" could also be translated as, to "challenge" or to "cause to experience difficulties" or to "prove."
* Ways to translate "a test" could be, "a challenge" or "a difficult experience."
* To "put to the test" could be translated as to "test" or to "set up a challenge" or to "force to prove oneself."
* In the context of testing God, this could be translated as, "trying to force God to prove his love."
* In some contexts, when God is not the subject, the term "test" can mean "tempt."

(See also: [tempt](#tempt))

### Bible References:

* [1 John 04:1-3](https://git.door43.org/Door43/en_tn/src/master/1jn/04/01.md)
* [1 Thessalonians 05:19-22](https://git.door43.org/Door43/en_tn/src/master/1th/05/19.md)
* [Acts 15:10-11](https://git.door43.org/Door43/en_tn/src/master/act/15/10.md)
* [Genesis 22:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/22/01.md)
* [Isaiah 07:13-15](https://git.door43.org/Door43/en_tn/src/master/isa/07/13.md)
* [James 01:12-13](https://git.door43.org/Door43/en_tn/src/master/jas/01/12.md)
* [Lamentations 03:40-43](https://git.door43.org/Door43/en_tn/src/master/lam/03/40.md)
* [Malachi 03:10-12](https://git.door43.org/Door43/en_tn/src/master/mal/03/10.md)
* [Philippians 01:9-11](https://git.door43.org/Door43/en_tn/src/master/php/01/09.md)
* [Psalm 026:1-3](https://git.door43.org/Door43/en_tn/src/master/psa/026/001.md)


### Word Data:

* Strong's: H5713, H5715, H5749, H6030, H8584, G1242, G1263, G1303, G1957, G3140, G3141, G3142, G3143, G4303, G4828, G6020


## <a id="tw-term-kt-testimony"/>testimony, testify, witness, witnesses, eyewitness, eyewitnesses

### Definition:

When a person gives "testimony" he makes a statement about something he knows, claiming that the statement is true. To "testify" is to give "testimony."

* Often a person "testifies" about something he has experienced directly.
* A witness who gives "false testimony" does not tell the truth about what happened.
* Sometimes the term "testimony" refers to a prophecy that a prophet has stated.
* In the New Testament, this term was often used to refer to how Jesus' followers testified about the events of Jesus' life, death, and resurrection.

The term "witness" refers to a person who has personally experienced something that happened. Usually a witness is also someone who testifies about what they know is true. The term "eyewitness" emphasizes that the person was actually there and saw what happened.

* To "witness" something means to see it happen.
* At a trial, a witness "gives witness" or "bears witness." This has the same meaning as "testify."
* Witnesses are expected to tell the truth about what they have seen or heard.
* A witness who does not tell the truth about what happened is called a "false witness." He is said to "give false witness" or to "bear false witness."
* The expression "be a witness between" means that something or someone will be evidence that a contract has been made. The witness will make sure each person does what he has promised to do.

### Translation Suggestions:

* The term "testify" or "give testimony" could also be translated as, "tell the facts" or "tell what was seen or heard" or "tell from personal experience" or "give evidence" or "tell what happened."
* Ways to translate "testimony" could include, "report of what happened" or "statement of what is true" or "evidence" or "what has been said" or "prophecy."
* The phrase, "as a testimony to them" could be translated as, to "show them what is true" or to "prove to them what is true."
* The phrase, "as a testimony against them" could be translated as, "which will show them their sin" or "exposing their hypocrisy" or "which will prove that they are wrong."
* To "give false testimony" could be translated as "say false things about" or "state things that are not true."

* The term "witness" or "eyewitness" could be translated with a word or phrase that means "person seeing it" or "the one who saw it happen" or "those who saw and heard (those things)."
* Something that is "a witness" could be translated as "guarantee" or "sign of our promise" or "something that testifies that this is true."
* The phrase "you will be my witnesses" could also be translated as "you will tell other people about me" or "you will teach people the truth that I taught you" or "you will tell people what you have seen me do and heard me teach."
* To "witness to" could be translated as to "tell what was seen" or to "testify" or to "state what happened."
* To "witness" something could be translated as to "see something" or to "experience something happen."

(See also: [ark of the covenant](#arkofthecovenant), [guilt](#guilt), [judge](#judge), [prophet](#prophet), [testimony](#testimony), [true](#true))

### Bible References:

* [Deuteronomy 31:27-29](https://git.door43.org/Door43/en_tn/src/master/deu/31/27.md)
* [Micah 06:3-5](https://git.door43.org/Door43/en_tn/src/master/mic/06/03.md)
* [Matthew 26:59-61](https://git.door43.org/Door43/en_tn/src/master/mat/26/59.md)
* [Mark 01:43-44](https://git.door43.org/Door43/en_tn/src/master/mrk/01/43.md)
* [John 01:6-8](https://git.door43.org/Door43/en_tn/src/master/jhn/01/06.md)
* [John 03:31-33](https://git.door43.org/Door43/en_tn/src/master/jhn/03/31.md)
* [Acts 04:32-33](https://git.door43.org/Door43/en_tn/src/master/act/04/32.md)
* [Acts 07:44-46](https://git.door43.org/Door43/en_tn/src/master/act/07/44.md)
* [Acts 13:30-31](https://git.door43.org/Door43/en_tn/src/master/act/13/30.md)
* [Romans 01:8-10](https://git.door43.org/Door43/en_tn/src/master/rom/01/08.md)
* [1 Thessalonians 02:10-12](https://git.door43.org/Door43/en_tn/src/master/1th/02/10.md)
* [1 Timothy 05:19-20](https://git.door43.org/Door43/en_tn/src/master/1ti/05/19.md)
* [2 Timothy 01:8-11](https://git.door43.org/Door43/en_tn/src/master/2ti/01/08.md)
* [2 Peter 01:16-18](https://git.door43.org/Door43/en_tn/src/master/2pe/01/16.md)
* [1 John 05:6-8](https://git.door43.org/Door43/en_tn/src/master/1jn/05/06.md)
* [3 John 01:11-12](https://git.door43.org/Door43/en_tn/src/master/3jn/01/11.md)
* [Revelation 12:11-12](https://git.door43.org/Door43/en_tn/src/master/rev/12/11.md)

### Examples from the Bible stories:

* __[39:02](https://git.door43.org/Door43/en_tn/src/master/obs/39/02.md)__ Inside the house, the Jewish leaders put Jesus on trial. They brought many __false witnesses__  who lied about him.
* __[39:04](https://git.door43.org/Door43/en_tn/src/master/obs/39/04.md)__ The high priest tore his clothes in anger and shouted, "We do not need any more __witnesses__. You have heard him say that he is the Son of God. What is your judgment?"
* __[42:08](https://git.door43.org/Door43/en_tn/src/master/obs/42/08.md)__ "It was also written in the scriptures that my disciples will proclaim that everyone should repent in order to receive forgiveness for their sins. They will do this starting in Jerusalem, and then go to all people groups everywhere. You are __witnesses__  of these things."
* __[43:07](https://git.door43.org/Door43/en_tn/src/master/obs/43/07.md)__ "We are __witnesses__  to the fact that God raised Jesus to life again."

### Word Data:

* Strong's: H5707, H5713, H5715, H5749, H6030, H8584, G267, G1263, G1957, G2649, G3140, G3141, G3142, G3143, G3144, G4303, G4828, G4901, G5575, G5576, G5577, G6020


## <a id="tw-term-kt-tetrarch"/>tetrarch

### Definition:

The term  "tetrarch" refers to a governing official who ruled over part of the Roman Empire. Each tetrarch was under the authority of the Roman emperor.

* The title "tetrarch" means "one of four joint rulers."
* Starting under the Emperor Diocletian, there were four major divisions of the Roman Empire and each tetrarch ruled one division.
* The kingdom of of Herod "the Great," who was king at the time of the birth of Jesus, was divided into four sections after his death, and ruled by his sons as "tetrarchs," or "rulers of a fourth."
* Each division had one or more smaller parts called "provinces," such as Galilee or Samaria.
* "Herod the tetrarch" is mentioned several times in the New Testament. He is also known as "Herod Antipas."
* The term "tetrarch" could also be translated as "regional governor" or "provincial ruler" or "ruler" or "governor."

(See also: [governor](other.html#governor), [Herod Antipas](names.html#herodantipas), [province](other.html#province), [Rome](names.html#rome), [ruler](other.html#ruler))

### Bible References:

* [Luke 03:1-2](https://git.door43.org/Door43/en_tn/src/master/luk/03/01.md)
* [Luke 09:7-9](https://git.door43.org/Door43/en_tn/src/master/luk/09/07.md)
* [Matthew 14:1-2](https://git.door43.org/Door43/en_tn/src/master/mat/14/01.md)

### Word Data:

* Strong's: G5075, G5076

## <a id="tw-term-kt-thetwelve"/>the twelve, the eleven

### Definition:

The term "the twelve" refers to the twelve men that Jesus chose to be his closest disciples, or apostles. After Judas killed himself, they were called "the eleven."

* Jesus had many other disciples, but the title "the twelve" distinguished those who were apparently closest to Jesus.
* The names of these twelve disciples are listed in Matthew 10, Mark 3, and Luke 6.
* Some time after Jesus had returned to heaven, "the eleven" chose a disciple named Matthias to take Judas' place. Then they were called "the twelve" again.

### Translation Suggestions:

* For many languages it may be clearer or more natural to add the noun and say, "the twelve apostles" or "Jesus' twelve closest disciples."
* "The eleven" could also be translated as "Jesus' eleven remaining disciples."
* Some translations may prefer to use a capital letter to show that it was used as a title, as in "the Twelve" and "the Eleven."

(See also: [apostle](#apostle), [disciple](#disciple))

### Bible References:

* [1 Corinthians 15:5-7](https://git.door43.org/Door43/en_tn/src/master/1co/15/05.md)
* [Acts 06:2-4](https://git.door43.org/Door43/en_tn/src/master/act/06/02.md)
* [Luke 09:1-2](https://git.door43.org/Door43/en_tn/src/master/luk/09/01.md)
* [Luke 18:31-33](https://git.door43.org/Door43/en_tn/src/master/luk/18/31.md)
* [Mark 10:32-34](https://git.door43.org/Door43/en_tn/src/master/mrk/10/32.md)
* [Matthew 10:5-7](https://git.door43.org/Door43/en_tn/src/master/mat/10/05.md)

### Word Data:

* Strong's: G1427, G1733


## <a id="tw-term-kt-transgression"/>transgress, transgresses, transgression

### Definition:

The term "transgression" refers to the breaking of a command, rule, or moral code. To "transgress" is to commit a "transgression."

* Figuratively, to "transgress" can also be described as to "cross a line," that is, to go beyond a limit or boundary that has been set for the good of the person and others.
* The terms "transgression," "sin," "iniquity," and "trespass" all include the meaning of acting against God's will and disobeying his commands.

### Translation Suggestions:
* To "trangress" could be translated as to "sin" or to "disobey" or to "rebel."
* If a verse or passage uses two terms that mean "sin" or "transgress" or "trespass," it is important, if possible, to use different ways to translate these terms. When the Bible uses two or more terms with similar meanings in the same context, usually its purpose is to emphasize what is being said or to show its importance. 

(See: [parallelism](https://git.door43.org/Door43/en_man/src/master/translate/figs-parallelism/01.md))

(See also: [sin](#sin), [trespass](#trespass), [iniquity](#iniquity))

### Bible References:

* [1 Thessalonians 04:3-6](https://git.door43.org/Door43/en_tn/src/master/1th/04/03.md)
* [Daniel 09:24-25](https://git.door43.org/Door43/en_tn/src/master/dan/09/24.md)
* [Galatians 03:19-20](https://git.door43.org/Door43/en_tn/src/master/gal/03/19.md)
* [Galatians 06:1-2](https://git.door43.org/Door43/en_tn/src/master/gal/06/01.md)
* [Numbers 14:17-19](https://git.door43.org/Door43/en_tn/src/master/num/14/17.md)
* [Psalm 032:1-2](https://git.door43.org/Door43/en_tn/src/master/psa/032/001.md)


### Word Data:

* Strong's: H898, H4603, H4604, H6586, H6588, G458, G459, G3845, G3847, G3848, G3928


## <a id="tw-term-kt-trespass"/>trespass, trespasses, trespassed

### Definition:

To "trespass" means to break a law or to violate the rights of another person. A "trespass" is the action of "trespassing."

* A trespass can be a violation of moral or civil law or a sin committed against another person.
* This term is related to the terms "sin," and "transgress," especially as it relates to disobeying God.
* All sins are trespasses against God.

### Translation Suggestions:

* Depending on the context, to "trespass against" could be translated as to "sin against" or to "break the rule."
* Some languages may have an expression like "cross the line" that could be used to translate "trespass."
* Consider how this term fits with the meaning of the surrounding Bible text and compare it to other terms that have a similar meaning, such as "transgress" and "sin."

(See also: [disobey](other.html#disobey), [iniquity](#iniquity), [sin](#sin), [transgress](#transgression))

### Bible References:

* [1 Samuel 25:27-28](https://git.door43.org/Door43/en_tn/src/master/1sa/25/27.md)
* [2 Chronicles 26:16-18](https://git.door43.org/Door43/en_tn/src/master/2ch/26/16.md)
* [Colossians 02:13-15](https://git.door43.org/Door43/en_tn/src/master/col/02/13.md)
* [Ephesians 02:1-3](https://git.door43.org/Door43/en_tn/src/master/eph/02/01.md)
* [Ezekiel 15:7-8](https://git.door43.org/Door43/en_tn/src/master/ezk/15/07.md)
* [Romans 05:16-17](https://git.door43.org/Door43/en_tn/src/master/rom/05/16.md)
* [Romans 05:20-21](https://git.door43.org/Door43/en_tn/src/master/rom/05/20.md)


### Word Data:

* Strong's: H816, H817, H819, H2398, H4603, H4604, H6586, H6588, G264, G3900


## <a id="tw-term-kt-true"/>true, truth, truths

### Definition:

The term "truth" refers to one or more concepts that are facts, events that actually happened, and statements that were actually said. Such concepts are said to be "true."

* True things are real, genuine, actual, rightful, legitimate, and factual.
* The truth is an understanding, belief, fact, or statement that is true.
* To say that a prophecy "came true" or "will come true" mean that it actually happened as predicted or that it will happen that way.
* Truth includes the concept of acting in a way that is reliable and faithful.
* Jesus revealed God's truth in the words that he spoke.
* God's word is truth. It tells about things that actually happened and teaches what is true about God and about everything he has made.


### Translation Suggestions:

* Depending on the context and what is being described, the term "true" could also be translated by "real" or "factual" or "correct" or "right" or "certain" or "genuine."
* Ways to translate the term "truth" could include "what is true" or "fact" or "certainty" or "principle."
* The expression "come true" could also be translated as "actually happen" or "be fulfilled" or "happen as predicted."
* The expression "tell the truth" or "speak the truth" could also be translated as "say what is true" or "tell what really happened" or "say things that are reliable."
* To "accept the truth" could be translated as "believe what is true about God."
* In an expression such as "worship God in spirit and in truth," the expression "in truth" could also be translated by "faithfully obeying what God has taught us."


(See also: [believe](#believe), [faithful](#faithful), [fulfill](#fulfill), [obey](other.html#obey), [prophet](#prophet), [understand](other.html#understand))

### Bible References:

* [1 Corinthians 05:6-8](https://git.door43.org/Door43/en_tn/src/master/1co/05/06.md)
* [1 John 01:5-7](https://git.door43.org/Door43/en_tn/src/master/1jn/01/05.md)
* [1 John 02:7-8](https://git.door43.org/Door43/en_tn/src/master/1jn/02/07.md)
* [3 John 01:5-8](https://git.door43.org/Door43/en_tn/src/master/3jn/01/05.md)
* [Acts 26:24-26](https://git.door43.org/Door43/en_tn/src/master/act/26/24.md)
* [Colossians 01:4-6](https://git.door43.org/Door43/en_tn/src/master/col/01/04.md)
* [Genesis 47:29-31](https://git.door43.org/Door43/en_tn/src/master/gen/47/29.md)
* [James 01:17-18](https://git.door43.org/Door43/en_tn/src/master/jas/01/17.md)
* [James 03:13-14](https://git.door43.org/Door43/en_tn/src/master/jas/03/13.md)
* [James 05:19-20](https://git.door43.org/Door43/en_tn/src/master/jas/05/19.md)
* [Jeremiah 04:1-3](https://git.door43.org/Door43/en_tn/src/master/jer/04/01.md)
* [John 01:9](https://git.door43.org/Door43/en_tn/src/master/jhn/01/09.md)
* [John 01:16-18](https://git.door43.org/Door43/en_tn/src/master/jhn/01/16.md)
* [John 01:49-51](https://git.door43.org/Door43/en_tn/src/master/jhn/01/49.md)
* [John 03:31-33](https://git.door43.org/Door43/en_tn/src/master/jhn/03/31.md)
* [Joshua 07:19-21](https://git.door43.org/Door43/en_tn/src/master/jos/07/19.md)
* [Lamentations 05:19-22](https://git.door43.org/Door43/en_tn/src/master/lam/05/19.md)
* [Matthew 08:8-10](https://git.door43.org/Door43/en_tn/src/master/mat/08/08.md)
* [Matthew 12:15-17](https://git.door43.org/Door43/en_tn/src/master/mat/12/15.md)
* [Psalm 026:1-3](https://git.door43.org/Door43/en_tn/src/master/psa/026/001.md)
* [Revelation 01:19-20](https://git.door43.org/Door43/en_tn/src/master/rev/01/19.md)
* [Revelation 15:3-4](https://git.door43.org/Door43/en_tn/src/master/rev/15/03.md)

### Examples from the Bible stories:

  __*[02:04](https://git.door43.org/Door43/en_tn/src/master/obs/02/04.md)__ The snake responded to the woman, "That is not __true__! You will not die."
  __*[14:06](https://git.door43.org/Door43/en_tn/src/master/obs/14/06.md)__ Immediately Caleb and Joshua, the other two spies, said, "It is __true __ that the people of Canaan are tall and strong, but we can certainly defeat them!"
  __*[16:01](https://git.door43.org/Door43/en_tn/src/master/obs/16/01.md)__ The Israelites began to worship the Canaanite gods instead of Yahweh, the __true __ God.
  __*[31:08](https://git.door43.org/Door43/en_tn/src/master/obs/31/08.md)__ They worshiped Jesus, saying to him, "__Truly__, you are the Son of God." 
  __*[39:10](https://git.door43.org/Door43/en_tn/src/master/obs/39/10.md)__ "I have come to earth to tell the __truth__ about God. Everyone who loves the __truth__ listens to me." Pilate said, "What is __truth__?"


### Word Data:

* Strong's: H199, H389, H403, H529, H530, H543, H544, H551, H571, H935, H3321, H3330, H6237, H6656, H6965, H7187, H7189, G225, G226, G227, G228, G230, G1103, G3303, G3483, G3689, G4103, G4137


## <a id="tw-term-kt-trust"/>trust, trusts, trusted, trustworthy, trustworthiness

### Definition:

To "trust" something or someone is to believe that the thing or person is true or dependable. That belief is also called "trust." A "trustworthy" person is one you can trust to do and say what is right and true, and therefore one who has the quality of "trustworthiness."

* Trust is closely related to faith. If we trust someone, we have faith in that person to do what they promised to do.
* Having trust in someone also means depending on that person.
* To "trust in" Jesus means to believe that he is God, to believe that he died on the cross to pay for our sins, and to rely on him to save us.
* A "trustworthy saying" refers to something that is said that can be counted on to be true.

### Translation Suggestions:

* Ways to translate "trust" could include "believe" or "have faith" or "have confidence" or "depend on."
* The phrase "put your trust in" is very similar in meaning to "trust in."
* The term "trustworthy" could be translated as "dependable" or "reliable" or "can always be trusted."

(See also: [believe](#believe), [confidence](other.html#confidence), [faith](#faith), [faithful](#faithful), [true](#true))

### Bible References:

* [1 Chronicles 09:22-24](https://git.door43.org/Door43/en_tn/src/master/1ch/09/22.md)
* [1 Timothy 04:9-10](https://git.door43.org/Door43/en_tn/src/master/1ti/04/09.md)
* [Hosea 10:12-13](https://git.door43.org/Door43/en_tn/src/master/hos/10/12.md)
* [Isaiah 31:1-2](https://git.door43.org/Door43/en_tn/src/master/isa/31/01.md)
* [Nehemiah 13:12-14](https://git.door43.org/Door43/en_tn/src/master/neh/13/12.md)
* [Psalm 031:5-7](https://git.door43.org/Door43/en_tn/src/master/psa/031/005.md)
* [Titus 03:8](https://git.door43.org/Door43/en_tn/src/master/tit/03/08.md)

### Examples from the Bible stories:

* __[12:12](https://git.door43.org/Door43/en_tn/src/master/obs/12/12.md)__ When the Israelites saw that the Egyptians were dead, they __trusted__  in God and believed that Moses was a prophet of God.
* __[14:15](https://git.door43.org/Door43/en_tn/src/master/obs/14/15.md)__ Joshua was a good leader because he __trusted__  and obeyed God.
* __[17:02](https://git.door43.org/Door43/en_tn/src/master/obs/17/02.md)__ David was a humble and righteous man who __trusted__  and obeyed God.
* __[34:06](https://git.door43.org/Door43/en_tn/src/master/obs/34/06.md)__ Then Jesus told a story about people who __trusted__  in their own good deeds and despised other people.


### Word Data:

* Strong's: H539, H982, H1556, H2620, H2622, H3176, H4009, H4268, H7365, G1679, G3872, G3982, G4006, G4100, G4276


## <a id="tw-term-kt-unleavenedbread"/>unleavened bread

### Definition:

The term "unleavened bread" refers to bread that is made without yeast or other leavening. This kind of bread is flat because it has no leaven to make it rise.

* When God freed the Israelites from slavery in Egypt, he told them to flee Egypt quickly without waiting for their bread to rise. So they ate unleavened bread with their meal. Since then unleavened bread is used in their yearly Passover celebrations to remind them of that time.
* Since leaven sometimes is used as a picture of sin, "unleavened bread" represents the removal of sin from a person's life in order to live in a way that honors God.

### Translation Suggestions:

* Other ways to translate this term could include "bread with no yeast" or "flat bread that did not rise."
* Make sure the translation of this term is consistent with how you translate the term "yeast, leaven."
* In some contexts, the term "unleavened bread" refers to the "Feast of Unleavened Bread" and can be translated that way.

(See also: [bread](other.html#bread), [Egypt](names.html#egypt), [feast](other.html#feast), [Passover](#passover), [servant](other.html#servant), [sin](#sin), [yeast](other.html#yeast))

### Bible References:

* [1 Corinthians 05:6-8](https://git.door43.org/Door43/en_tn/src/master/1co/05/06.md)
* [2 Chronicles 30:13-15](https://git.door43.org/Door43/en_tn/src/master/2ch/30/13.md)
* [Acts 12:3-4](https://git.door43.org/Door43/en_tn/src/master/act/12/03.md)
* [Exodus 23:14-15](https://git.door43.org/Door43/en_tn/src/master/exo/23/14.md)
* [Ezra 06:21-22](https://git.door43.org/Door43/en_tn/src/master/ezr/06/21.md)
* [Genesis 19:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/19/01.md)
* [Judges 06:21](https://git.door43.org/Door43/en_tn/src/master/jdg/06/21.md)
* [Leviticus 08:1-3](https://git.door43.org/Door43/en_tn/src/master/lev/08/01.md)
* [Luke 22:1-2](https://git.door43.org/Door43/en_tn/src/master/luk/22/01.md)

### Word Data:

* Strong's: H4682, G106


## <a id="tw-term-kt-vow"/>vow, vows, vowed

### Definition:

A vow is a promise that a person makes to God. The person promises to do a certain thing in order to specially honor God or to show devotion to him.

* After a person makes a vow, he is obligated to fulfill that vow.
* The Bible teaches that a person may be judged by God if he doesn't keep his vow.
* Sometimes a person may ask God to protect him or provide for him in exchange for making the vow.
* But God is not required to fulfill a request that a person asks for in his vow.

### Translation Suggestions:

* Depending on the context, "vow" could be translated as "solemn promise" or "promise made to God."
* A vow is a special kind of oath that is made to God.

(See also: [promise](#promise), [oath](other.html#oath))

### Bible References:

* [1 Corinthians 07:27-28](https://git.door43.org/Door43/en_tn/src/master/1co/07/27.md)
* [Acts 21:22-24](https://git.door43.org/Door43/en_tn/src/master/act/21/22.md)
* [Genesis 28:20-22](https://git.door43.org/Door43/en_tn/src/master/gen/28/20.md)
* [Genesis 31:12-13](https://git.door43.org/Door43/en_tn/src/master/gen/31/12.md)
* [Jonah 01:14-16](https://git.door43.org/Door43/en_tn/src/master/jon/01/14.md)
* [Jonah 02:9-10](https://git.door43.org/Door43/en_tn/src/master/jon/02/09.md)
* [Proverbs 07:13-15](https://git.door43.org/Door43/en_tn/src/master/pro/07/13.md)


### Word Data:

* Strong's: H5087, H5088, G2171


## <a id="tw-term-kt-willofgod"/>will of God

### Definition:

The "will of God" refers to God's desires and plans.
 
* God's will especially  relates to his interactions with people and how he wants people to respond to him.
* It also refers to his plans or desires for the rest of his creation.
* The term to "will" means to "determine" or to "desire."

### Translation Suggestions:

* The "will of God" could also be translated as "what God desires" or "what God has planned" or "God's purpose" or "what is pleasing to God."

### Bible References:

* [1 John 02:15-17](https://git.door43.org/Door43/en_tn/src/master/1jn/02/15.md)
* [1 Thessalonians 04:3-6](https://git.door43.org/Door43/en_tn/src/master/1th/04/03.md)
* [Colossians 04:12-14](https://git.door43.org/Door43/en_tn/src/master/col/04/12.md)
* [Ephesians 01:1-2](https://git.door43.org/Door43/en_tn/src/master/eph/01/01.md)
* [John 05:30-32](https://git.door43.org/Door43/en_tn/src/master/jhn/05/30.md)
* [Mark 03:33-35](https://git.door43.org/Door43/en_tn/src/master/mrk/03/33.md)
* [Matthew 06:8-10](https://git.door43.org/Door43/en_tn/src/master/mat/06/08.md)
* [Psalms 103:20-22](https://git.door43.org/Door43/en_tn/src/master/psa/103/020.md)

### Word Data:

* Strong's: H6310, H6634, H7522, G1012, G1013, G2307, G2308, G2309, G2596


## <a id="tw-term-kt-wise"/>wise, wisdom

### Definition:

The term "wise" describes someone who understands what is the right and moral thing to do and then does that. "Wisdom" is the understanding and practice of what is true and morally right.

* Being wise includes the ability to make good decisions, especially choosing to do what pleases God.
* In the Bible, the term "worldly wisdom" is a figurative way of referring to what people in this world think is wise, but which is actually foolish.
* People become wise by listening to God and humbly obeying his will.
* A wise person will show the fruits of the Holy Spirit in his life, such as joy, kindness, love, and patience.

### Translation Suggestions:

* Depending on the context, other ways to translate "wise" could include "obedient to God" or "sensible and obedient" or "God-fearing."
* "Wisdom" could be translated by a word or phrase that means "wise living" or "sensible and obedient living" or "good judgment."
* It is best to translate "wise" and "wisdom" in such a way that they are different terms from other key terms like righteous or obedient.

(See also: [obey](other.html#obey), [fruit](other.html#fruit))

### Bible References:

* [Acts 06:2-4](https://git.door43.org/Door43/en_tn/src/master/act/06/02.md)
* [Colossians 03:15-17](https://git.door43.org/Door43/en_tn/src/master/col/03/15.md)
* [Exodus 31:6-9](https://git.door43.org/Door43/en_tn/src/master/exo/31/06.md)
* [Genesis 03:4-6](https://git.door43.org/Door43/en_tn/src/master/gen/03/04.md)
* [Isaiah 19:11-12](https://git.door43.org/Door43/en_tn/src/master/isa/19/11.md)
* [Jeremiah 18:18-20](https://git.door43.org/Door43/en_tn/src/master/jer/18/18.md)
* [Matthew 07:24-25](https://git.door43.org/Door43/en_tn/src/master/mat/07/24.md)

### Examples from the Bible stories:

* __[02:05](https://git.door43.org/Door43/en_tn/src/master/obs/02/05.md)__ She also wanted to be __wise__, so she picked some of the fruit and ate it.
* __[18:01](https://git.door43.org/Door43/en_tn/src/master/obs/18/01.md)__ When Solomon asked for __wisdom__, God was pleased and made him the __wisest__  man in the world.
* __[23:09](https://git.door43.org/Door43/en_tn/src/master/obs/23/09.md)__ Some time later, __wise__  men from countries far to the east saw an unusual star in the sky.
* __[45:01](https://git.door43.org/Door43/en_tn/src/master/obs/45/01.md)__ He (Stephen) had a good reputation and was full of the Holy Spirit and of __wisdom__.

### Word Data:

* Strong's: H998, H1350, H2445, H2449, H2450, H2451, H2452, H2454, H2942, H3820, H3823, H6195, H6493, H6912, H7535, H7919, H7922, H8454, G4678, G4679, G4680, G4920, G5428, G5429, G5430


## <a id="tw-term-kt-woe"/>woe

### Definition:

The term "woe" refers to a feeling of great distress. It also gives a warning that someone will experience severe trouble.

* The expression "woe to" is followed by a warning to people that they will experience suffering as punishment for their sins.
* In several places in the Bible, the word "woe" is repeated, to emphasize an especially terrible judgment.
* A person who says "woe is me" or "woe to me" is expressing sorrow about severe suffering.

### Translation Suggestions:

* Depending on the context, the term "woe" could also be translated as "great sorrow" or "sadness" or "calamity" or "disaster."
* Other ways to translate the expression "Woe to (name of city)" could include, "How terrible it will be for (name of city)" or "The people in (that city) will be severely punished" or "Those people will suffer greatly."
* The expression, "Woe is me!" or "Woe to me!" could be translated as "How sad I am!" or "I am so sad!" or "How terrible this is for me!"
* The expression "Woe to you" could also be translated as "You will suffer terribly" or "You will experience terrible troubles."

### Bible References:

* [Ezekiel 13:17-18](https://git.door43.org/Door43/en_tn/src/master/ezk/13/17.md)
* [Habakkuk 02:12-14](https://git.door43.org/Door43/en_tn/src/master/hab/02/12.md)
* [Isaiah 31:1-2](https://git.door43.org/Door43/en_tn/src/master/isa/31/01.md)
* [Jeremiah 45:1-3](https://git.door43.org/Door43/en_tn/src/master/jer/45/01.md)
* [Jude 01:9-11](https://git.door43.org/Door43/en_tn/src/master/jud/01/09.md)
* [Luke 06:24-25](https://git.door43.org/Door43/en_tn/src/master/luk/06/24.md)
* [Luke 17:1-2](https://git.door43.org/Door43/en_tn/src/master/luk/17/01.md)
* [Matthew 23:23-24](https://git.door43.org/Door43/en_tn/src/master/mat/23/23.md)


### Word Data:

* Strong's: H188, H190, H337, H480, H1929, H1945, H1958, G3759


## <a id="tw-term-kt-wordofgod"/>word of God, words of God, word of Yahweh, word of the Lord, word of truth, scripture, scriptures

### Definition:

In the Bible, the term "word of God" refers to anything that God has communicated to people. This includes spoken and written messages. Jesus is also called "the Word of God."

* The term "scriptures" means "writings." It is only used in the New Testament and refers to the Hebrew scriptures, which is the Old Testament. These writings were God's message that he had told people to write down so that many years in the future people could still read it. 
* The related terms "word of Yahweh" and "word of the Lord" often refer to a specific message from God that was given to a prophet or other person in the Bible.
* Sometimes this term occurs as simply "the word" or "my word" or "your word" (when talking about God's word).
* In the New Testament, Jesus is called "the Word" and "the Word of God." These titles mean that Jesus fully reveals who God is, because he is God himself.

The term "word of truth" is another way of referring to "God's word," which is his message or teaching. It does not refer to just one word.

* God's word of truth includes everything that God has taught people about himself, his creation, and his plan of salvation through Jesus.
* This term emphasizes the fact that what God has told us is true, faithful, and real.

### Translation Suggestions:

* Depending on the context, other ways to translate this term could include "the message of Yahweh" or "God's message" or "the teachings from God."
* It may be more natural in some languages to make this term plural and say "God's words" or "the words of Yahweh."
* The expression "the word of Yahweh came" is often used to introduce something that God told his prophets or his people. This could be translated as "Yahweh spoke this message" or "Yahweh spoke these words."
* The term "scripture" or "scriptures" could be translated as "the writings" or "the written message from God." This term should be translated differently from the translation of the term "word."
* When "word" occurs alone and it refers to God's word, it could be translated as "the message" or "God's word" or "the teachings." Also consider the alternate translations suggested above.
* When the Bible refers to Jesus as "the Word," this term could be translated as "the Message" or "the Truth."

* "Word of truth" could be translated as "God's true message" or "God's word, which is true."
* It is important for the translation of this term to include the meaning of being true.

(See also: [prophet](#prophet), [true](#true), [word](other.html#word), [Yahweh](#yahweh))


### Bible References:

* [Genesis 15:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/15/01.md)
* [1 Kings 13:1-3](https://git.door43.org/Door43/en_tn/src/master/1ki/13/01.md)
* [Jeremiah 36:1-3](https://git.door43.org/Door43/en_tn/src/master/jer/36/01.md)
* [Luke 08:11-13](https://git.door43.org/Door43/en_tn/src/master/luk/08/11.md)
* [John 05:39-40](https://git.door43.org/Door43/en_tn/src/master/jhn/05/39.md)
* [Acts 06:2-4](https://git.door43.org/Door43/en_tn/src/master/act/06/02.md)
* [Acts 12:24-25](https://git.door43.org/Door43/en_tn/src/master/act/12/24.md)
* [Romans 01:1-3](https://git.door43.org/Door43/en_tn/src/master/rom/01/01.md)
* [2 Corinthians 06:4-7](https://git.door43.org/Door43/en_tn/src/master/2co/06/04.md)
* [Ephesians 01:13-14](https://git.door43.org/Door43/en_tn/src/master/eph/01/13.md)
* [2 Timothy 03:16-17](https://git.door43.org/Door43/en_tn/src/master/2ti/03/16.md)
* [James 01:17-18](https://git.door43.org/Door43/en_tn/src/master/jas/01/17.md)
* [James 02:8-9](https://git.door43.org/Door43/en_tn/src/master/jas/02/08.md)

### Examples from the Bible stories:

* __[25:07](https://git.door43.org/Door43/en_tn/src/master/obs/25/07.md)__ In __God's word__  he commands his people, 'Worship only the Lord your God and only serve him.'"
* __[33:06](https://git.door43.org/Door43/en_tn/src/master/obs/33/06.md)__ So Jesus explained, "The seed is the __word of God__.
* __[42:03](https://git.door43.org/Door43/en_tn/src/master/obs/42/03.md)__ Then Jesus explained to them what __God's word__  says about the Messiah.
* __[42:07](https://git.door43.org/Door43/en_tn/src/master/obs/42/07.md)__ Jesus said, "I told you that everything written about me in __God's word__  must be fulfilled." Then he opened their minds so they could understand __God's word__.
* __[45:10](https://git.door43.org/Door43/en_tn/src/master/obs/45/10.md)__ Philip also used other __scriptures__  to tell him the good news of Jesus.
* __[48:12](https://git.door43.org/Door43/en_tn/src/master/obs/48/12.md)__ But Jesus is the greatest prophet of all. He is the __Word of God__.
* __[49:18](https://git.door43.org/Door43/en_tn/src/master/obs/49/18.md)__ God tells you to pray, to study his __word__, to worship him with other Christians, and to tell others what he has done for you.


### Word Data:

* Strong's: H561, H565, H1697, H3068, G3056, G4487


## <a id="tw-term-kt-works"/>works, deeds, work, acts

### Definition:

In the Bible, the terms "works," "deeds," and "acts" are used to refer generally to things that God or people do. 

* The term "work" refers to doing labor or anything that is done to serve other people.
* God's "works" and the "work of his hands" are expressions that refer to all the things he does or has done, including creating the world, saving sinners, providing for the needs of all creation and keeping the entire universe in place. The terms "deeds" and "acts" are also used to refer to God's miracles in expressions such as "mighty acts" or "marvelous deeds."
* The works or deeds that a person does can be either good or evil.
* The Holy Spirit empowers believers to do good works, which are also called "good fruit."
* People are not saved by their good works; they are saved through faith in Jesus.
* A person's "work" can be what he does to earn a living or to serve God. The Bible also refers to God as "working."

### Translation Suggestions:

* Other ways to translate "works" or "deeds" could be "actions" or "things that are done."
* When referring to God's "works" or "deeds" and the "work of his hands," these expressions could also be translated as "miracles" or "mighty acts" or "amazing things he does."
* The expression "the work of God" could be translated as "the things that God is doing" or "the miracles God does" or "the amazing things that God does" or "everything God has accomplished."
* The term "work" can just be the singular of "works" as in "every good work" or "every good deed."
* The term "work" can also have the broader meaning of "service" or "ministry." For example, the expression "your work in the Lord" could also be translated as, "what you do for the Lord."
* The expression "examine your own work" could also be translated as "make sure what you are doing is God's will" or "make sure that what you are doing pleases God."
* The expression "the work of the Holy Spirit" could be translated as "the empowering of the Holy Spirit" or "the ministry of the Holy Spirit" or "the things that the Holy Spirit does."

(See also: [fruit](other.html#fruit), [Holy Spirit](#holyspirit), [miracle](#miracle))

### Bible References:

* [1 John 03:11-12](https://git.door43.org/Door43/en_tn/src/master/1jn/03/11.md)
* [Acts 02:8-11](https://git.door43.org/Door43/en_tn/src/master/act/02/08.md)
* [Daniel 04:36-37](https://git.door43.org/Door43/en_tn/src/master/dan/04/36.md)
* [Exodus 34:10-11](https://git.door43.org/Door43/en_tn/src/master/exo/34/10.md)
* [Galatians 02:15-16](https://git.door43.org/Door43/en_tn/src/master/gal/02/15.md)
* [James 02:14-17](https://git.door43.org/Door43/en_tn/src/master/jas/02/14.md)
* [Matthew 16:27-28](https://git.door43.org/Door43/en_tn/src/master/mat/16/27.md)
* [Micah 02:6-8](https://git.door43.org/Door43/en_tn/src/master/mic/02/06.md)
* [Romans 03:27-28](https://git.door43.org/Door43/en_tn/src/master/rom/03/27.md)
* [Titus 03:4-5](https://git.door43.org/Door43/en_tn/src/master/tit/03/04.md)

### Word Data:

* Strong's: H4566, H4567, H4611, H4659, H5949, G2041


## <a id="tw-term-kt-world"/>world, worldly

### Definition:

The term "world" usually refers to the part of the universe where people live: the earth. The term "worldly" describes the evil values and behaviors of people living in this world.

* In its most general sense, the term "world" refers to the heavens and the earth, as well as everything in them.
* In many contexts, "world" actually means "people in the world."
* Sometimes it is implied that this refers to the evil people on earth or the people who do not obey God.
* The apostles also used "world" to refer to the selfish behaviors and corrupt values of the people living in this world. This can include self-righteous religious practices which are based on human efforts.
* People and things characterized by these values are said to be "worldly."

### Translation Suggestions:

* Depending on the context, "world" could also be translated as "universe" or "people of this world" or "corrupt things in the world" or "evil attitudes of people in the world."
* The phrase "all the world" often means "many people" and refers to the people living in a certain region. For example, "all the world came to Egypt" could be translated as "many people from the surrounding countries came to Egypt" or "people from all the countries surrounding Egypt came there."
* Another way to translate "all the world went to their hometown to be registered in the Roman census" would be "many of the people living in regions ruled by the Roman empire went..."
* Depending on the context, the term "worldly" could be translated as, "evil" or "sinful" or "selfish" or "ungodly" or "corrupt" or "influenced by the corrupt values of people in this world."
* The phrase "saying these things in the world" can be translated as "saying these things to the people of the world."
* In other contexts, "in the world" could also be translated as "living among the people of the world" or "living among ungodly people."

(See also: [corrupt](other.html#corrupt), [heaven](#heaven), [Rome](names.html#rome), [godly](#godly))

### Bible References:

* [1 John 02:15-17](https://git.door43.org/Door43/en_tn/src/master/1jn/02/15.md)
* [1 John 04:4-6](https://git.door43.org/Door43/en_tn/src/master/1jn/04/04.md)
* [1 John 05:4-5](https://git.door43.org/Door43/en_tn/src/master/1jn/05/04.md)
* [John 01:29-31](https://git.door43.org/Door43/en_tn/src/master/jhn/01/29.md)
* [Matthew 13:36-39](https://git.door43.org/Door43/en_tn/src/master/mat/13/36.md)

### Word Data:

* Strong's: H776, H2309, H2465, H5769, H8398, G1093, G2886, G2889, G3625


## <a id="tw-term-kt-worship"/>worship

### Definition:

To "worship" means to honor, praise and obey someone, especially God.

* This term often means literally "bow down" or "prostrate oneself" to humbly honor someone.
* We worship God when we serve and honor him, by praising him and obeying him.
* When the Israelites worshiped God, it often included sacrificing an animal on an altar. 
* Some people worshiped false gods.

### Translation Suggestions:

* The term "worship" could be translated as "bow down to" or "honor and serve" or "honor and obey."
* In some contexts, it could also be translated as "humbly praise" or "give honor and praise."
 
(See also: [sacrifice](other.html#sacrifice), [praise](other.html#praise), [honor](#honor))  

### Bible References:

* [Colossians 02:18-19](https://git.door43.org/Door43/en_tn/src/master/col/02/18.md)
* [Deuteronomy 29:17-19](https://git.door43.org/Door43/en_tn/src/master/deu/29/17.md)
* [Exodus 03:11-12](https://git.door43.org/Door43/en_tn/src/master/exo/03/11.md)
* [Luke 04:5-7](https://git.door43.org/Door43/en_tn/src/master/luk/04/05.md)
* [Matthew 02:1-3](https://git.door43.org/Door43/en_tn/src/master/mat/02/01.md)
* [Matthew 02:7-8](https://git.door43.org/Door43/en_tn/src/master/mat/02/07.md)

### Examples from the Bible stories:

  __*[13:04](https://git.door43.org/Door43/en_tn/src/master/obs/13/04.md)__  Then God gave them the covenant and said, "I am Yahweh, your God, who saved you from slavery in Egypt. Do not __worship__ other gods."
  __*[14:02](https://git.door43.org/Door43/en_tn/src/master/obs/14/02.md)__  The Canaanites did not __worship__ or obey God. They __worshiped__ false gods and did many evil things.
  __*[17:06](https://git.door43.org/Door43/en_tn/src/master/obs/17/06.md)__  David wanted to build a temple where all the Israelites could __worship__ God and offer him sacrifices.
  __*[18:12](https://git.door43.org/Door43/en_tn/src/master/obs/18/12.md)__  All of the kings and most of the people of the kingdom of Israel __worshiped__ idols.
  __*[25:07](https://git.door43.org/Door43/en_tn/src/master/obs/25/07.md)__  Jesus replied, "Get away from me, Satan! In God's word he commands his people, '__Worship__ only the Lord your God and only serve him.'"
  __*[26:02](https://git.door43.org/Door43/en_tn/src/master/obs/26/02.md)__  On the Sabbath, he (Jesus) went to the place of __worship__.
  __*[47:01](https://git.door43.org/Door43/en_tn/src/master/obs/47/01.md)__  There they met a woman named Lydia who was a merchant. She loved and __worshiped__ God.
  __*[49:18](https://git.door43.org/Door43/en_tn/src/master/obs/49/18.md)__  God tells you to pray, to study his word, to __worship__ him with other Christians, and to tell others what he has done for you.

### Word Data:

* Strong's: H5457, H5647, H6087, H7812, G1391, G1479, G2151, G2318, G2323, G2356, G3000, G3511, G4352, G4353, G4573, G4574, G4576


## <a id="tw-term-kt-worthy"/>worthy, worth, unworthy, worthless

### Definition:

The term "worthy" describes someone or something that deserves respect or honor. To "have worth" means to be valuable or important. The term "worthless" means to not have any value.

* Being worthy is related to being valuable or having importance
* To be "unworthy" means to not be deserving of any special notice.
* To not feel worthy means to feel less important than someone else or to not feel deserving of being treated with honor or kindness.
* The term "unworthy" and the term "worthless" have related, but different meanings. To be "unworthy" means to not be deserving of any honor or recognition. To be "worthless" means to not have any purpose or value.

### Translation Suggestions:

* "Worthy" could be translated as "deserving" or "important" or "valuable."
* The word "worth" could be translated as "value" or "importance."
* The phrase to "have worth" could also be translated as to "be valuable" or to "be important."
* The phrase "is worth more than" could be translated as "is more valuable than."
* Depending on the context, the term, "unworthy" could also be translated as "unimportant" or "dishonorable" or "undeserving."
* The term "worthless" could be translated as "with no value" or "with no purpose" or "worth nothing."

(See also: [honor](#honor))

### Bible References:

* [2 Samuel 22:3-4](https://git.door43.org/Door43/en_tn/src/master/2sa/22/03.md)
* [2 Thessalonians 01:11-12](https://git.door43.org/Door43/en_tn/src/master/2th/01/11.md)
* [Acts 13:23-25](https://git.door43.org/Door43/en_tn/src/master/act/13/23.md)
* [Acts 25:25-27](https://git.door43.org/Door43/en_tn/src/master/act/25/25.md)
* [Acts 26:30-32](https://git.door43.org/Door43/en_tn/src/master/act/26/30.md)
* [Colossians 01:9-10](https://git.door43.org/Door43/en_tn/src/master/col/01/09.md)
* [Jeremiah 08:18-19](https://git.door43.org/Door43/en_tn/src/master/jer/08/18.md)
* [Mark 01:7-8](https://git.door43.org/Door43/en_tn/src/master/mrk/01/07.md)
* [Matthew 03:10-12](https://git.door43.org/Door43/en_tn/src/master/mat/03/10.md)
* [Philippians 01:25-27](https://git.door43.org/Door43/en_tn/src/master/php/01/25.md)

### Word Data:

* Strong's: H117, H639, H1929, H3644, H4242, H4373, H4392, H4592, H4941, H6994, H7939, G514, G515, G516, G2425, G2661, G2735


## <a id="tw-term-kt-wrath"/>wrath, fury

### Definition:

Wrath is an intense anger that is sometimes long-lasting. It especially refers to God's righteous judgment of sin and punishment of people who rebel against him.

* In the Bible, "wrath" usually refers to God's anger toward those who sin against him.
* The "wrath of God" can also refer to his judgment and punishment for sin.
* God's wrath is the righteous penalty for those who do not repent of their sin.

### Translation Suggestions:

* Depending on the context, other ways this term could be translated include "intense anger" or "righteous judgment" or "anger."
* When talking about God's wrath, make sure the word or phrase used to translate this term does not refer to a sinful fit of rage. God's wrath is just and holy.

(See also: [judge](#judge), [sin](#sin))

### Bible References:

* [1 Thessalonians 01:8-10](https://git.door43.org/Door43/en_tn/src/master/1th/01/08.md)
* [1 Timothy 02:8-10](https://git.door43.org/Door43/en_tn/src/master/1ti/02/08.md)
* [Luke 03:7](https://git.door43.org/Door43/en_tn/src/master/luk/03/07.md)
* [Luke 21:23-24](https://git.door43.org/Door43/en_tn/src/master/luk/21/23.md)
* [Matthew 03:7-9](https://git.door43.org/Door43/en_tn/src/master/mat/03/07.md)
* [Revelation 14:9-10](https://git.door43.org/Door43/en_tn/src/master/rev/14/09.md)
* [Romans 01:18-19](https://git.door43.org/Door43/en_tn/src/master/rom/01/18.md)
* [Romans 05:8-9](https://git.door43.org/Door43/en_tn/src/master/rom/05/08.md)

### Word Data:

* Strong's: H639, H2197, H2528, H2534, H2740, H3707, H3708, H5678, H7107, H7109, H7110, H7265, H7267, G2372, G3709, G3949, G3950


## <a id="tw-term-kt-yahweh"/>Yahweh

### Facts:

The term "Yahweh" is God's personal name that he revealed when he spoke to Moses at the burning bush. 

* The name "Yahweh" comes from the word that means, to "be" or to "exist."
* Possible meanings of "Yahweh" include, "he is" or "I am" or "the one who causes to be."
* This name reveals that God has always lived and will continue to live forever. It also means that he is always present.
* Following tradition, many Bible versions use the term "LORD" or "the LORD" to represent "Yahweh." This tradition resulted from the fact that historically, the Jewish people became afraid of mispronouncing Yahweh's name and started saying "Lord" every time the term "Yahweh" appeared in the text. Modern Bibles write "LORD" with all capital letters to show respect for God's personal name and to distinguish it from "Lord" which is a different Hebrew word.
* The ULB and UDB texts always translates this term as, "Yahweh," as it literally occurs in the Hebrew text of the Old Testament.
* The term "Yahweh" does not ever occur in the original text of the New Testament; only the Greek term for "Lord" is used, even in quotes from the Old Testament.
* In the Old Testament, when God spoke about himself, he would often use his name instead of a pronoun.
* By adding the pronoun "I" or "me," the ULB indicates to the reader that God is the speaker.

### Translation Suggestions:

* "Yahweh" could be translated by a word or phrase that means "I am" or "living one" or "the one who is" or "he who is alive."
* This term could also be written in a way that is similar to how "Yahweh" is spelled.
* Some church denominations prefer not to use the term "Yahweh" and instead use the traditional rendering, "LORD." An important consideration is that this may be confusing when read aloud because it will sound the same as the title "Lord." Some languages may have an affix or other grammatical marker that could be added to distinguish "LORD" as a name (Yahweh) from "Lord" as a title.
* It is best if possible to keep the name Yahweh where it literally occurs in the text, but some translations may decide to use only a pronoun in some places, to make the text more natural and clear.
* Introduce the quote with something like, "This is what Yahweh says."

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [God](#god), [lord](#lord), [Lord](#lord), [Moses](names.html#moses), [reveal](#reveal))

### Bible References:

* [1 Kings 21:19-20](https://git.door43.org/Door43/en_tn/src/master/1ki/21/19.md)
* [1 Samuel 16:6-7](https://git.door43.org/Door43/en_tn/src/master/1sa/16/06.md)
* [Daniel 09:3-4](https://git.door43.org/Door43/en_tn/src/master/dan/09/03.md)
* [Ezekiel 17:24](https://git.door43.org/Door43/en_tn/src/master/ezk/17/24.md)
* [Genesis 02:4-6](https://git.door43.org/Door43/en_tn/src/master/gen/02/04.md)
* [Genesis 04:3-5](https://git.door43.org/Door43/en_tn/src/master/gen/04/03.md)
* [Genesis 28:12-13](https://git.door43.org/Door43/en_tn/src/master/gen/28/12.md)
* [Hosea 11:12](https://git.door43.org/Door43/en_tn/src/master/hos/11/12.md)
* [Isaiah 10:3-4](https://git.door43.org/Door43/en_tn/src/master/isa/10/03.md)
* [Isaiah 38:7-8](https://git.door43.org/Door43/en_tn/src/master/isa/38/07.md)
* [Job 12:9-10](https://git.door43.org/Door43/en_tn/src/master/job/12/09.md)
* [Joshua 01:8-9](https://git.door43.org/Door43/en_tn/src/master/jos/01/08.md)
* [Lamentations 01:4-5](https://git.door43.org/Door43/en_tn/src/master/lam/01/04.md)
* [Leviticus 25:35-38](https://git.door43.org/Door43/en_tn/src/master/lev/25/35.md)
* [Malachi 03:4-5](https://git.door43.org/Door43/en_tn/src/master/mal/03/04.md)
* [Micah 02:3-5](https://git.door43.org/Door43/en_tn/src/master/mic/02/03.md)
* [Micah 06:3-5](https://git.door43.org/Door43/en_tn/src/master/mic/06/03.md)
* [Numbers 08:9-11](https://git.door43.org/Door43/en_tn/src/master/num/08/09.md)
* [Psalm 124:1-3](https://git.door43.org/Door43/en_tn/src/master/psa/124/001.md)
* [Ruth 01:19-21](https://git.door43.org/Door43/en_tn/src/master/rut/01/19.md)
* [Zechariah 14:5](https://git.door43.org/Door43/en_tn/src/master/zec/14/05.md)

### Examples from the Bible stories:

* __[09:14](https://git.door43.org/Door43/en_tn/src/master/obs/09/14.md)__ God said, "I AM WHO I AM. Tell them, 'I AM has sent me to you.' Also tell them, 'I am __Yahweh__, the God of your ancestors Abraham, Isaac, and Jacob. This is my name forever.'"
* __[13:04](https://git.door43.org/Door43/en_tn/src/master/obs/13/04.md)__ Then God gave them the covenant and said, "I am __Yahweh__, your God, who saved you from slavery in Egypt. Do not worship other gods."
* __[13:05](https://git.door43.org/Door43/en_tn/src/master/obs/13/05.md)__ "Do not make idols or worship them, for I, __Yahweh__, am a jealous God."
* __[16:01](https://git.door43.org/Door43/en_tn/src/master/obs/16/01.md)__ The Israelites began to worship the Canaanite gods instead of __Yahweh__, the true God.
* __[19:10](https://git.door43.org/Door43/en_tn/src/master/obs/19/10.md)__ Then Elijah prayed, "O __Yahweh__, God of Abraham, Isaac, and Jacob, show us today that you are the God of Israel and that I am your servant."

### Word Data:

* Strong's: H3050, H3068, H3069


## <a id="tw-term-kt-yahwehofhosts"/>Yahweh of hosts, God of hosts, host of heaven, host of the heavens, Lord of hosts

### Definition:

The terms "Yahweh of hosts" and "God of hosts" are titles that express God's authority over the thousands of angels who obey him.

* The term "host" or "hosts" is a word that refers to a large number of something, such as an army of people or the massive number of stars. It can also refer to all the many spirit beings, including evil spirits. The context makes it clear what is being referred to.
* Phrases similar to "host of the heavens" refer to all the stars, planets and other heavenly bodies.
* In the New Testament, the phrase, "Lord of hosts" means the same as "Yahweh of hosts" but it cannot be translated that way since the Hebrew word "Yahweh" is not used in the New Testament.

### Translation Suggestions:

* Ways to translate "Yahweh of hosts" could include, "Yahweh, who rules all the angels" or "Yahweh, the ruler over armies of angels" or "Yahweh, the ruler of all creation."
* The phrase "of hosts" in the terms "God of hosts" and "Lord of hosts" would be translated the same way as in the phrase "Yahweh of hosts" above.
* Certain churches do not accept the literal term "Yahweh" and prefer to use the capitalized word, "LORD" instead, following the tradition of many Bible versions. For these churches, a translation of the term "LORD of hosts" would be used in the Old Testament for "Yahweh of hosts."

(See also: [angel](#angel), [authority](#authority), [God](#god), [lord](#lord), [Lord](#lord), [Lord Yahweh](#lordyahweh) [Yahweh](#yahweh))

### Bible References:

* [Zechariah 13:1-2](https://git.door43.org/Door43/en_tn/src/master/zec/13/01.md)


### Word Data:

* Strong's: H430, H3068, H6635


## <a id="tw-term-kt-zealous"/>zeal, zealous

### Definition:

The terms "zeal" and "zealous" refer to being strongly devoted to supporting a person or idea.

* Zeal includes having strong desire and actions that promote a good cause. It is often used to describe someone who faithfully obeys God and teaches others to do that too.
* Being zealous includes putting intense effort into doing something and continuing to persevere in that effort.
* The "zeal of the Lord" or the "zeal of Yahweh" refers to God's strong, persistent actions to bless his people or to see justice done.

### Translation Suggestions:

* To "be zealous" could also be translated by, "be strongly diligent" or "make an intense effort."
* The term "zeal" could also be translated as "energetic devotion" or "eager determination" or "righteous enthusiasm."
* The phrase, "zeal for your house" could be translated, "strongly honoring your temple" or "fervent desire to take care of your house."
### Bible References:

* [1 Corinthians 12:30-31](https://git.door43.org/Door43/en_tn/src/master/1co/12/30.md)
* [1 Kings 19:9-10](https://git.door43.org/Door43/en_tn/src/master/1ki/19/09.md)
* [Acts 22:3-5](https://git.door43.org/Door43/en_tn/src/master/act/22/03.md)
* [Galatians 04:17-18](https://git.door43.org/Door43/en_tn/src/master/gal/04/17.md)
* [Isaiah 63:15-16](https://git.door43.org/Door43/en_tn/src/master/isa/63/15.md)
* [John 02:17-19](https://git.door43.org/Door43/en_tn/src/master/jhn/02/17.md)
* [Philippians 03:6-7](https://git.door43.org/Door43/en_tn/src/master/php/03/06.md)
* [Romans 10:1-3](https://git.door43.org/Door43/en_tn/src/master/rom/10/01.md)

### Word Data:

* Strong's: H7065, H7068, G2205, G2206, G2207, G6041


## <a id="tw-term-kt-zion"/>Zion, Mount Zion

### Definition:

Originally, the term "Zion" or "Mount Zion" referred to a stronghold or fortress that King David captured from the Jebusites. Both these terms became other ways of referring to Jerusalem.

* Mount Zion and Mount Moriah were two of the hills that the city of Jerusalem was located on. Later, "Zion" and "Mount Zion" became used as general terms to refer to both of these mountains and to the city of Jerusalem. Sometimes they also referred to the temple that was located in Jerusalem. (See: [metonymy](https://git.door43.org/Door43/en_man/src/master/translate/figs-metonymy/01.md))
* David named Zion, or Jerusalem, the "City of David." This is different from David's hometown, Bethlehem, which was also called the City of David.
* The term "Zion" is used in other figurative ways, to refer to Israel or to God's spiritual kingdom or to the new, heavenly Jerusalem that God will create.

(See also: [Abraham](names.html#abraham), [David](names.html#david), [Jerusalem](names.html#jerusalem), [Bethlehem](names.html#bethlehem), [Jebusites](names.html#jebusites))

### Bible References:

* [1 Chronicles 11:4-6](https://git.door43.org/Door43/en_tn/src/master/1ch/11/04.md)
* [Amos 01:1-2](https://git.door43.org/Door43/en_tn/src/master/amo/01/01.md)
* [Jeremiah 51:34-35](https://git.door43.org/Door43/en_tn/src/master/jer/51/34.md)
* [Psalm 076:1-3](https://git.door43.org/Door43/en_tn/src/master/psa/076/001.md)
* [Romans 11:26-27](https://git.door43.org/Door43/en_tn/src/master/rom/11/26.md)

### Word Data:

* Strong's: H6726

