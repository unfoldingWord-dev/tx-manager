# Martha #

## Facts: ##

Martha was a woman from Bethany who followed Jesus.

* Martha had a sister named Mary and a brother named Lazarus, who also followed Jesus.
* One time when Jesus was visiting them in their home, Martha was distracted by meal preparation while her sister Mary sat and listened to Jesus teach.
* When Lazarus died, Martha told Jesus that she believed that Jesus is the Christ, the Son of God.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Lazarus](../names/lazarus.md), [Mary (sister of Martha)](../names/marysisterofmartha.md))

## Bible References: ##

* [John 11:1-2](rc://en/tn/help/jhn/11/01)
* [John 12:1-3](rc://en/tn/help/jhn/12/01)
* [Luke 10:38-39](rc://en/tn/help/luk/10/38)

## Word Data:##

* Strong's: G3136
