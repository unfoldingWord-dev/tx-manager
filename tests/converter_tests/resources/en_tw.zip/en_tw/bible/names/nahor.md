# Nahor #

## Facts: ##

Nahor was the name of two relatives of Abraham, his grandfather and his brother.

* Abraham's brother Nahor was the grandfather of Isaac's wife Rebekah.
* The phrase "city of Nahor" could mean  "the city named Nahor" or "the city where Nahor had lived" or "Nahor's city." 

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Abraham](../names/abraham.md), [Rebekah](../names/rebekah.md))

## Bible References: ##

* [1 Chronicles 01:24-27](rc://en/tn/help/1ch/01/24)
* [Genesis 31:51-53](rc://en/tn/help/gen/31/51)
* [Joshua 24:1-2](rc://en/tn/help/jos/24/01)
* [Luke 03:33-35](rc://en/tn/help/luk/03/33)

## Word Data:##

* Strong's: H5152, G3493
