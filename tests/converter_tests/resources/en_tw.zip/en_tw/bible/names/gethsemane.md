# Gethsemane #

## Facts: ##

Gethsemane was a garden of olive trees east of Jerusalem beyond the Kidron valley and near the Mount of Olives.

* The garden of Gethsemane was a place where Jesus and his followers would go to be alone and rest, away from the crowds.
* It was in Gethsemane that Jesus prayed in deep sorrow, before being arrested there by Jewish leaders.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Judas Iscariot](../names/judasiscariot.md), [Kidron Valley](../names/kidronvalley.md), [Mount of Olives](../names/mountofolives.md))

## Bible References: ##

* [Mark 14:32-34](rc://en/tn/help/mrk/14/32)
* [Matthew 26:36-38](rc://en/tn/help/mat/26/36)

## Word Data:##

* Strong's: G1068
