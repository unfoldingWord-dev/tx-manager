# Memphis #

## Definition: ##

Memphis was an ancient capital city in Egypt, along the Nile River.

* Memphis was located in Lower Egypt, just south of the Nile River delta, where the soil was very fertile and crops were plentiful.
* Its fertile soil and important location between Upper and Lower Egypt caused Memphis to become a major city of trade and commerce.

(Translation suggestions: [Translating Names](rc://en/ta/man/translate/translate-names))

(See also: [Egypt](../names/egypt.md), [Nile River](../names/nileriver.md))

## Bible References: ##

* [Hosea 09:5-6](rc://en/tn/help/hos/09/05)

## Word Data:##

* Strong's: H4644, H5297
