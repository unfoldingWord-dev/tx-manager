# Lamech #

## Facts: ##

Lamech was the name of two men mentioned in the book of Genesis.

* The first Lamech mentioned was a descendant of Cain. He boasted to his two wives that he had killed a man for injuring him.
* The second Lamech was a descendant of Seth. He was also the father of Noah.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Cain](../names/cain.md), [Noah](../names/noah.md), [Seth](../names/seth.md))

## Bible References: ##

* [Genesis 04:18-19](rc://en/tn/help/gen/04/18)
* [Genesis 04:23-24](rc://en/tn/help/gen/04/23)
* [Genesis 05:25-27](rc://en/tn/help/gen/05/25)
* [Genesis 05:28-29](rc://en/tn/help/gen/05/28)
* [Genesis 05:30-31](rc://en/tn/help/gen/05/30)
* [Luke 03:36-38](rc://en/tn/help/luk/03/36)

## Word Data:##

* Strong's: H3929, G2984
