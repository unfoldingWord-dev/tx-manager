# Goliath #

## Facts: ##

Goliath was a very tall and very large soldier in the army of the Philistines who was killed by David.

* Goliath was between two and three meters tall. He is often referred to as a giant because of his great size.
* Although Goliath had better weapons and was much bigger than David, God gave David the strength and ability to defeat Goliath.
* The Israelites were declared victorious over the Philistines as a result of David's victory over Goliath.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [David](../names/david.md), [Philistines](../names/philistines.md))

## Bible References: ##

* [1 Chronicles 20:4-5](rc://en/tn/help/1ch/20/04)
* [1 Samuel 17:4-5](rc://en/tn/help/1sa/17/04)
* [1 Samuel 21:8-9](rc://en/tn/help/1sa/21/08)
* [1 Samuel 22:9-10](rc://en/tn/help/1sa/22/09)

## Word Data:##

* Strong's: H1555
