# Kerethites #

## Facts: ##

The Kerethites were a people group who were probably part of the Philistines. Some versions write this name as "Cherethites."

* The "Kerethites and Pelethites" were a special group of soldiers from King David's army who were especially devoted to him as his bodyguards.
* Benaiah, son of Jehoiada, a member of David's administrative corps, was the leader of the Kerethites and Pelethites.
* The Kerethites remained with David when he had to flee Jerusalem because of Absalom's revolt.

(Translation suggestions: [Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Absalom](../names/absalom.md), [Benaiah](../names/benaiah.md), [David](../names/david.md), [Philistines](../names/philistines.md))

## Bible References: ##

* [Zephaniah 02:4-5](rc://en/tn/help/zep/02/04)

## Word Data:##

* Strong's: H3774
