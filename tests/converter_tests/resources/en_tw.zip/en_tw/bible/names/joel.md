# Joel #

## Facts: ##

Joel was a prophet who probably lived during the reign of King Joash of Judah. There were also several other men in the Old Testament named Joel.

* The book of Joel is one of twelve short prophetic books in the last section of the Old Testament.
* The only personal information we have about the prophet Joel is that his father's name was Pethuel.
* In his sermon at Pentecost, the apostle Peter quoted from the book of Joel.
* 

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Joash](../names/joash.md), [Judah](../names/kingdomofjudah.md), [Pentecost](../kt/pentecost.md))

## Bible References: ##

* [1 Chronicles 06:33-35](rc://en/tn/help/1ch/06/33)
* [1 Samuel 08:1-3](rc://en/tn/help/1sa/08/01)
* [Acts 02:16-17](rc://en/tn/help/act/02/16)
* [Ezra 10:41-44](rc://en/tn/help/ezr/10/41)
* [Joel 01:1-3](rc://en/tn/help/jol/01/01)

## Word Data:##

* Strong's: H3100, G2493
