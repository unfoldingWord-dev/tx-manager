# Amos #

## Facts: ##

Amos was an Israelite prophet who lived during the time of King Uzziah of Judah.

* Before being called as a prophet, Amos was originally a shepherd and fig farmer living in the kingdom of Judah.
* Amos prophesied against the prosperous northern kingdom of Israel regarding their unjust treatment of people.

(Translation suggestions: [Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [fig](../other/fig.md), [Judah](../names/judah.md), [kingdom of Israel](../names/kingdomofisrael.md), [shepherd](../other/shepherd.md), [Uzziah](../names/uzziah.md))

## Bible References: ##

* [Amos 01:1-2](rc://en/tn/help/amo/01/01)

## Word Data:##

* Strong's: H5986
