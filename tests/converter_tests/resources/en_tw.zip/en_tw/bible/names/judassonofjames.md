# Judas the son of James #

## Facts: ##

Judas son of James was one of Jesus' twelve apostles. Note that he was not the same man as Judas Iscariot.

* Often in the Bible, men with the same name were distinguished by mentioning whose son they were. Here, Judas was identified as the "son of James."
* Another man named Judas was Jesus' brother. He was also known as "Jude."
* The New Testament book called "Jude" was probably written by Jesus' brother Judas, since the author identified himself as the "brother of James." James was another brother of Jesus.
* It is also possible that the book of Jude was written by Jesus' disciple, Judas, the son of James.

(Translation suggestions: [Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [James (son of Zebedee)](../names/jamessonofzebedee.md), [Judas Iscariot](../names/judasiscariot.md), [son](../kt/son.md), [the twelve](../kt/thetwelve.md))

## Bible References: ##

* [Acts 01:12-14](rc://en/tn/help/act/01/12)
* [Luke 06:14-16](rc://en/tn/help/luk/06/14)

## Word Data:##

* Strong's: G2455
