# translationWords

## <a id="other"/>Other

<a id="12tribesofisrael"/>

### twelve tribes of Israel, twelve tribes of the children of Israel, twelve tribes ###

#### Definition: ####

The term "twelve tribes of Israel" refers to the twelve sons of Jacob and their descendants.

* Jacob was Abraham's grandson. God later changed Jacob's name to Israel.
* These are the names of the tribes: Reuben, Simeon, Levi, Judah, Dan, Naphtali, Gad, Asher, Issachar, Zebulun, Joseph and Benjamin.
* The descendants of Levi did not inherit any land in Canaan because they were a tribe of priests who were set apart to serve God and his people.
* Joseph received a double inheritance of land, which was passed on to his two sons, Ephraim and Manasseh.
*  There are several places in the Bible where the list of the twelve tribes is slightly different. Sometimes Levi, Joseph, or Dan is left out of the list and sometimes Joseph's two sons Ephraim and Manasseh are included in the list.

(See also: [inherit](kt.html#inherit), [Israel](kt.html#israel), [Jacob](names.html#jacob), [priest](kt.html#priest), [tribe](#tribe)) 

#### Bible References: ####

* [Acts 26:6-8](https://git.door43.org/Door43/en_tn/src/master/act/26/06.md)
* [Genesis 49:28-30](https://git.door43.org/Door43/en_tn/src/master/gen/49/28.md)
* [Luke 22:28-30](https://git.door43.org/Door43/en_tn/src/master/luk/22/28.md)
* [Matthew 19:28](https://git.door43.org/Door43/en_tn/src/master/mat/19/28.md)

#### Word Data:####

* Strong's: H3478, H7626, H8147, G1427, G2474, G5443


---

<a id="abyss"/>

### abyss, bottomless pit ###

#### Definition: ####

The term "abyss" refers to a very large, deep hole or chasm that has no bottom.

 * In the Bible, "the abyss" is a place of punishment.
 * For example, when Jesus commanded evil spirits to come out of a man, they begged him not to send them to the abyss.
 * The word "abyss" could also be translated as "bottomless pit" or "deep chasm."
 * This term should be translated differently from "hades," "sheol,"  or "hell."

(See Also: [Hades](kt.html#hades), [hell](kt.html#hell), [punish](#punish))

#### Bible References: ####

* [Luke 08:30-31](https://git.door43.org/Door43/en_tn/src/master/luk/08/30.md)
* [Romans 10:6-7](https://git.door43.org/Door43/en_tn/src/master/rom/10/06.md)

#### Word Data:####

* Strong's: G12, G5421


---

<a id="acacia"/>

### acacia ###

#### Definition: ####

The term "acacia" is the name of a common shrub or tree growing in the land of Canaan in ancient times; it is still plentiful in that region today.

* The orange-brown wood of the acacia tree is very hard and durable, making it a useful material for building things.
* This wood is highly resistant to decay because it is so very dense that it keeps out water, and it has natural preservatives that keep insects from destroying it.
* In the Bible, acacia wood was used to build the tabernacle and the ark of the covenant.

(See also: [How to Translate Unknowns](https://git.door43.org/Door43/en_ta/src/master/translate/translate-unknown.md))

(See also: [ark of the covenant](kt.html#arkofthecovenant), [tabernacle](kt.html#tabernacle))

#### Bible References: ####

* [Deuteronomy 10:3-4](https://git.door43.org/Door43/en_tn/src/master/deu/10/03.md)
* [Exodus 25:3-7](https://git.door43.org/Door43/en_tn/src/master/exo/25/03.md)
* [Exodus 38:6-7](https://git.door43.org/Door43/en_tn/src/master/exo/38/06.md)
* [Isaiah 41:19-20](https://git.door43.org/Door43/en_tn/src/master/isa/41/19.md)

#### Word Data:####

* Strong's: H7848


---

<a id="accuse"/>

### accuse, accuses, accused, accusing, accuser, accusers, accusation, accusations ###

#### Definition: ####

The terms "accuse" and "accusation" refer to blaming someone for doing something wrong. A person who accuses others is an "accuser."

* A false accusation is when a charge against someone is not true, as when Jesus was falsely accused of wrongdoing by the leaders of the Jews.
* In the New Testament book of Revelation, Satan is called "the accuser."

#### Bible References: ####

* [Acts 19:38-41](https://git.door43.org/Door43/en_tn/src/master/act/19/38.md)
* [Hosea 04:4-5](https://git.door43.org/Door43/en_tn/src/master/hos/04/04.md)
* [Jeremiah 02:9-11](https://git.door43.org/Door43/en_tn/src/master/jer/02/09.md)
* [Luke 06:6-8](https://git.door43.org/Door43/en_tn/src/master/luk/06/06.md)
* [Romans 08:33-34](https://git.door43.org/Door43/en_tn/src/master/rom/08/33.md)

#### Word Data:####

* Strong's: H3198, H8799, G1458, G2147, G2596, G2724


---

<a id="acknowledge"/>

### acknowledge, acknowledges, acknowledged, admit, admitted  ###

#### Facts: ####

The term "acknowledge" means to give proper recognition to something or someone.

* To acknowledge God also involves acting in a way that shows that what he says is true.
* People who acknowledge God will show it by obeying him, which brings glory to his name.
* To acknowledge something means to believe that it is true, with actions and words that confirm that. 

#### Translation Suggestions: ####

* In the context of acknowledging that something is true, "acknowledge" could be translated as "admit" or "declare" or "confess to be true" or "believe."
* When referring to acknowledging a person, this term could be translated as "accept" or "recognize the value of" or "tell others that (the person) is faithful."
* In the context of acknowledging God, this could be translated as "believe and obey God" or "declare who God is" or "tell other people about how great God is" or "confess that what God says and does is true."

(See also: [obey](#obey), [glory](kt.html#glory), [save](kt.html#save))

#### Bible References: ####

* [Daniel 11:38-39](https://git.door43.org/Door43/en_tn/src/master/dan/11/38.md)
* [Jeremiah 09:4-6](https://git.door43.org/Door43/en_tn/src/master/jer/09/04.md)
* [Job 34:26-28](https://git.door43.org/Door43/en_tn/src/master/job/34/26.md)
* [Leviticus 22:31-33](https://git.door43.org/Door43/en_tn/src/master/lev/22/31.md)
* [Psalm 029:1-2](https://git.door43.org/Door43/en_tn/src/master/psa/029/001.md)

#### Word Data:####

* Strong's: H3045, H3046, H5046, H5234, H6942, G1492, G1921, G3670


---

<a id="acquit"/>

### acquit, acquits, acquitted ###

#### Definition: ####

The term "acquit" means to formally declare someone to be not guilty of an unlawful or immoral behavior he was accused of.

* This term is sometimes used in the Bible to talk about forgiving sinners.
* Often the context is about wrongly acquitting people who are wicked and rebel against God.
* This could be translated as "declare innocent" or "judge to be not guilty."

(See also: [forgive](kt.html#forgive), [guilt](kt.html#guilt), [sin](kt.html#sin))

#### Bible References: ####

* [Deuteronomy 25:1-2](https://git.door43.org/Door43/en_tn/src/master/deu/25/01.md)
* [Exodus 21:28-30](https://git.door43.org/Door43/en_tn/src/master/exo/21/28.md)
* [Exodus 23:6-9](https://git.door43.org/Door43/en_tn/src/master/exo/23/06.md)
* [Isaiah 05:22-23](https://git.door43.org/Door43/en_tn/src/master/isa/05/22.md)
* [Job 10:12-14](https://git.door43.org/Door43/en_tn/src/master/job/10/12.md)

#### Word Data:####

* Strong's: H3444, H5352, H5355, H6403, H6663


---

<a id="administration"/>

### administration, administrator, administrators, administered, administering ###

#### Facts: ####

The terms "administration" and "administrator" refer to managing or governing of people of a country to help it function in an orderly way.

* Daniel and three other Jewish young men were appointed to be administrators, or government officials, over certain parts of Babylon.
* In the New Testament, administration is" one of the gifts of the Holy Spirit.
* A person who has the spiritual gift of administration is able to lead and govern people as well as supervise the maintenance of buildings and other property.

#### Translation Suggestions ####

* Depending on the context, some ways to translate "administrator" could include "governor" or "organizer" or "manager" or "ruler" or "government official."
* The term "administration" could be translated as "governing" or "management" or "leadership." or "organization."
* Expressions such as "in charge of" or "taking care of" or "keeping order" could possibly be part of the translation of these terms.

(See also: [Babylon](names.html#babylon), [Daniel](names.html#daniel), [gift](kt.html#gift), [governor](#governor), [Hananiah](names.html#hananiah), [Mishael](names.html#mishael), [Azariah](names.html#azariah))

#### Bible References: ####

* [1 Chronicles 18:14-17](https://git.door43.org/Door43/en_tn/src/master/1ch/18/14.md)
* [Daniel 06:1-3](https://git.door43.org/Door43/en_tn/src/master/dan/06/01.md)
* [Esther 09:3-5](https://git.door43.org/Door43/en_tn/src/master/est/09/03.md)

#### Word Data:####

* Strong's: H5532, H5608, H5632, H6213, H7860, G2941


---

<a id="admonish"/>

### admonish ###

#### Definition: ####

The term "admonish" means to firmly warn or advise someone.

* Usually "admonish" means to advise someone not to do something.
* In the body of Christ, believers are taught to admonish each other to avoid sin and to live holy lives.
* The word "admonish" could be translated as "encourage not to sin" or "urge someone to not sin."

#### Bible References: ####

* [Nehemiah 09:32-34](https://git.door43.org/Door43/en_tn/src/master/neh/09/32.md)

#### Word Data:####

* Strong's: H2094, H5749, G3560, G3867, G5537


---

<a id="adversary"/>

### adversary, adversaries, enemy, enemies ###

#### Definition: ####

An "adversary" is a person or group who is opposed to someone or something. The term "enemy" has a similar meaning.

 * Your adversary can be a person who tries to oppose you or harm you. 
 * When two nations fight, each can be called an "adversary" of the other.
 * In the Bible, the devil is referred to as an "adversary" and an "enemy."
 * Adversary may be translated as "opponent" or "enemy," but it suggests a tronger form of opposition.

(See also: [Satan](kt.html#satan))

#### Bible References: ####

* [1 Timothy 05:14-16](https://git.door43.org/Door43/en_tn/src/master/1ti/05/14.md)
* [Isaiah 09:11-12](https://git.door43.org/Door43/en_tn/src/master/isa/09/11.md)
* [Job 06:21-23](https://git.door43.org/Door43/en_tn/src/master/job/06/21.md)
* [Lamentations 04:12-13](https://git.door43.org/Door43/en_tn/src/master/lam/04/12.md)
* [Luke 12:57-59](https://git.door43.org/Door43/en_tn/src/master/luk/12/57.md)
* [Matthew 13:24-26](https://git.door43.org/Door43/en_tn/src/master/mat/13/24.md)

#### Word Data:####

* Strong's: H341, H6146, H6887, H6862, H6965, H7790, H7854, H8130, H8324, G476, G480, G2189, G2190, G4567, G5227


---

<a id="afflict"/>

### afflicted, afflict, afflicted, afflicting, affliction, afflictions ###

#### Definition: ####

The term "afflict" means to cause someone distress or suffering. An "affliction" is the disease, emotional grief, or other disaster that results from this.

* God afflicted his people with sickness or other hardships in order to cause them to repent of their sins and turn back to him.
* God caused afflictions or plagues to come on the people of Egypt because their king refused to obey God.
* To "be afflicted with" means to be suffering some kind of distress, such as a disease, persecution, or emotional grief.

#### Translation Suggestions: ####

* To afflict someone could be translated as "cause someone to experience troubles" or "cause someone to suffer" or "cause suffering to come."
* In certain contexts "afflict" could be translated as "happen to" or "come to" or "bring suffering."
* A phrase like "afflict someone with leprosy" could be translated as "cause someone to be sick with leprosy."
* When a disease or disaster is sent to "afflict" people or animals, this could be translated as "cause suffering to."
* Depending on the context, the term "affliction" could be translated as "calamity" or "sickness" or "suffering" or "great distress."
* The phrase "afflicted with" could also be translated as "suffering from" or "sick with."

(See also: [leprosy](#leprosy), [plague](#plague), [suffer](#suffer))

#### Bible References: ####

* [2 Thessalonians 01:6-8](https://git.door43.org/Door43/en_tn/src/master/2th/01/06.md)
* [Amos 05:12-13](https://git.door43.org/Door43/en_tn/src/master/amo/05/12.md)
* [Colossians 01:24-27](https://git.door43.org/Door43/en_tn/src/master/col/01/24.md)
* [Exodus 22:22-24](https://git.door43.org/Door43/en_tn/src/master/exo/22/22.md)
* [Genesis 12:17-20](https://git.door43.org/Door43/en_tn/src/master/gen/12/17.md)
* [Genesis 15:12-13](https://git.door43.org/Door43/en_tn/src/master/gen/15/12.md)
* [Genesis 29:31-32](https://git.door43.org/Door43/en_tn/src/master/gen/29/31.md)

#### Word Data: ####

* Strong's: H205, H1790, H3013, H3905, H3906, H4157, H4523, H6031, H6039, H6040, H6041, H6862, H6869, H6887, H7451, H7489, H7667, G2346, G2347, G2552, G2553, G2561, G3804, G4777, G4778, G5003


---

<a id="age"/>

### age, ages, aged ###

#### Definition: ####

The term "age" refers to the number of years a person has lived. It also used to refer generally to a time period.

* Other words used to express an extended period of time include "era" and "season."
* Jesus refers to "this age" as the present time when evil, sin, and disobedience fill the earth.
* There will be a future age when righteousness will reign over a new heaven and a new earth.

#### Translation Suggestions: ####

* Depending on the context, the term "age" could also be translated as "era" or "number of years old" or "time period" or "time."
* The phrase "at a very old age" could be translated as "at many years old" or "when he was very old" or "when he had lived a very long time."
* The phrase "this present evil age" means "during this time right now when people are very evil."

#### Bible References: ####

* [1 Chronicles 29:26-28](https://git.door43.org/Door43/en_tn/src/master/1ch/29/26.md)
* [1 Corinthians 02:6-7](https://git.door43.org/Door43/en_tn/src/master/1co/02/06.md)
* [Hebrews 06:4-6](https://git.door43.org/Door43/en_tn/src/master/heb/06/04.md)
* [Job 05:26-27](https://git.door43.org/Door43/en_tn/src/master/job/05/26.md)

#### Word Data:####

* Strong's: H2465, G165, G1074


---

<a id="alarm"/>

### alarm, alarms, alarmed ###

#### Facts: ####

An alarm is something that warns people about something that could harm them.  To "be alarmed" is to be very worried and frightened about something dangerous or threatening.

* King Jehoshapat was alarmed when he heard that the Moabites were planning to attack the kingdom of Judah.
* Jesus told his disciples not to be alarmed when they hear about disasters happening in the last days.
* The expression "sound an alarm" means to give a warning. In ancient times, a person could sound an alarm by making a noise.

#### Translation Suggestions ####

* To "alarm someone" means to "cause someone to worry" or to "worry someone."
* To "be alarmed" could be translated as "be worried" or "be frightened" or "be very concerned."
* The expression "sound an alarm" could be translated by "publicly warn" or "announce that danger is coming" or "blow a trumpet to warn about danger."

(See also: [Jehoshaphat](names.html#jehoshaphat), [Moab](names.html#moab))

#### Bible References: ####

* [Daniel 11:44-45](https://git.door43.org/Door43/en_tn/src/master/dan/11/44.md)
* [Jeremiah 04:19-20](https://git.door43.org/Door43/en_tn/src/master/jer/04/19.md)
* [Numbers 10:9](https://git.door43.org/Door43/en_tn/src/master/num/10/09.md)

#### Word Data:####

* Strong's: H7321, H8643


---

<a id="alms"/>

### alms ###

#### Definition: ####

The term "alms" refers to money, food, or other things that are given to help poor people.

* Often the giving of alms was seen by people as something that their religion required them to do in order to be righteous.
* Jesus said that giving alms should not be done publicly for the purpose of getting other people to notice. 
* This term could be translated as "money" or "gifts to poor people" or "help for the poor."

#### Bible References: ####

* [Acts 03:1-3](https://git.door43.org/Door43/en_tn/src/master/act/03/01.md)
* [Matthew 06:1-2](https://git.door43.org/Door43/en_tn/src/master/mat/06/01.md)
* [Matthew 06:3-4](https://git.door43.org/Door43/en_tn/src/master/mat/06/03.md)

#### Word Data:####

* Strong's: G1654


---

<a id="altarofincense"/>

### altar of incense, incense altar ###

#### Facts: ####

The altar of incense was a piece of furniture on which a priest would burn incense as an offering to God. It was also called the golden altar.

 * The altar of incense was made of wood, and its top and sides were covered with gold. It was about a half meter long, a half meter wide, and one meter tall.
 * At first it was kept in the tabernacle. Then it was kept in the temple. 
 * Every morning and evening a priest would burn incense on it.
 * This can also be translated as "altar for burning incense" or "golden altar" or "incense burner" or "incense table."

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_ta/src/master/translate/translate-names.md))

(See also: [incense](#incense))

#### Bible References: ####

* [Luke 01:11-13](https://git.door43.org/Door43/en_tn/src/master/luk/01/11.md)

#### Word Data:####

* Strong's: H4196, H7004, G2368, G2379


---

<a id="amazed"/>

### amazed, amazement, astonished, marvel, marveled, marveling, marvelous, wonder, wonders ###

#### Definition: ####

All these terms refer to being very surprised because of something extraordinary that happened.

* Some of these words are translations of Greek expressions that mean "struck with amazement" or "standing outside of (oneself)." These expressions show how very surprised or shocked the person was feeling. Other languages might also have ways to express this.
* Usually the event that caused the wonder and amazement was a miracle, something only God could do.
* The meaning of these terms can also include feelings of confusion because what happened was totally unexpected.
* Other ways to translate these words could be "extremely surprised" or "very shocked."
* Related words include "marvelous" (amazing, wonderful), "amazement," and "astonishment."
* In general, these terms are positive and express that the people were happy about what had happened.

(See also: [miracle](kt.html#miracle), [sign](kt.html#sign))

#### Bible References: ####

* [Acts 08:9-11](https://git.door43.org/Door43/en_tn/src/master/act/08/09.md)
* [Acts 09:20-22](https://git.door43.org/Door43/en_tn/src/master/act/09/20.md)
* [Galatians 01:6-7](https://git.door43.org/Door43/en_tn/src/master/gal/01/06.md)
* [Mark 02:10-12](https://git.door43.org/Door43/en_tn/src/master/mrk/02/10.md)
* [Matthew 07:28-29](https://git.door43.org/Door43/en_tn/src/master/mat/07/28.md)
* [Matthew 15:29-31](https://git.door43.org/Door43/en_tn/src/master/mat/15/29.md)
* [Matthew 19:25-27](https://git.door43.org/Door43/en_tn/src/master/mat/19/25.md)

#### Word Data:####

* Strong's: H926, H2865, H3820, H4159, H4923, H5953, H6313, H6381, H6382, H6383, H6395, H7583, H8047, H8074, H8078, H8429, H8539, H8540, H8541, H8653, G639, G1568, G1569, G1605, G1611, G1839, G2284, G2285, G2296, G2297, G2298, G3167, G4023, G4423, G4592, G5059


---

<a id="ambassador"/>

### ambassador, ambassadors, representative, representatives ###

#### Definition: ####

An ambassador is a person who is chosen to officially represent his country in relating to foreign nations. The word is also used in a figurative sense and is sometimes translated more generally as "representative."

* An ambassador or representative gives people messages from the person or government that sent him.
* The more general term "representative" refers to someone who has been given the authority to act and speak on behalf of the person he  is representing.
* The apostle Paul taught that Christians are Christ's "ambassadors" or "representatives" since they represent Christ in this world and teach others his message.
* Depending on the context, this term could be translated as "official representative" or "appointed messenger" or "chosen representative" or "God's appointed representative."
* A "delegation of ambassadors" could be translated as "some official messengers" or "group of appointed representatives" or "official party of people to speak for all people."

(See also: [How to Translate Unknowns](https://git.door43.org/Door43/en_ta/src/master/translate/translate-unknown.md))

(See also: [messenger](#messenger))

#### Bible References: ####

* [Ephesians 06:19-20](https://git.door43.org/Door43/en_tn/src/master/eph/06/19.md)
* [Luke 14:31-33](https://git.door43.org/Door43/en_tn/src/master/luk/14/31.md)
* [Luke 19:13-15](https://git.door43.org/Door43/en_tn/src/master/luk/19/13.md)

#### Word Data:####

* Strong's: H3887, H4135, H4136, H4397, H6735, H6737, G4243


---

<a id="angry"/>

### anger, angered, angry ###

#### Definition: ####

To "be angry" or to "have anger" means to be very displeased, irritated and upset about something or against someone.

* When people get angry, they are often sinful and selfish, but sometimes they have righteous anger against injustice or oppression.
* God's anger (also called "wrath") expresses his strong displeasure regarding sin.
* The phrase "provoke to anger" means "cause to be angry."

(See also: [wrath](kt.html#wrath))

#### Bible References: ####

* [Ephesians 04:25-27](https://git.door43.org/Door43/en_tn/src/master/eph/04/25.md)
* [Exodus 32:9-11](https://git.door43.org/Door43/en_tn/src/master/exo/32/09.md)
* [Isaiah 57:16-17](https://git.door43.org/Door43/en_tn/src/master/isa/57/16.md)
* [John 06:52-53](https://git.door43.org/Door43/en_tn/src/master/jhn/06/52.md)
* [Mark 10:13-14](https://git.door43.org/Door43/en_tn/src/master/mrk/10/13.md)
* [Matthew 26:6-9](https://git.door43.org/Door43/en_tn/src/master/mat/26/06.md)
* [Psalms 018:7-8](https://git.door43.org/Door43/en_tn/src/master/psa/018/007.md)

#### Word Data:####

* Strong's: H599, H639, H1149, H2152, H2194, H2195, H2198, H2534, H2734, H2787, H3179, H3707, H3708, H3824, H4751, H4843, H5674, H5678, H6225, H7107, H7110, H7266, H7307, G23, G1758, G2371, G2372, G3164, G3709, G3710, G3711, G3947, G3949, G5520


---

<a id="anguish"/>

### anguish ###

#### Definition: ####

The term "anguish" refers to severe pain or distress. 

* Anguish can be physical or emotional pain or distress.
* Often people who are in extreme anguish will show it in their face and behaviors.
* For example, a person in severe pain or anguish might grit his teeth or cry out.
* The term "anguish" could also be translated as "emotional distress" or "deep sorrow" or "severe pain."
 

#### Bible References: ####

* [Jeremiah 06:23-24](https://git.door43.org/Door43/en_tn/src/master/jer/06/23.md)
* [Jeremiah 19:6-9](https://git.door43.org/Door43/en_tn/src/master/jer/19/06.md)
* [Job 15:22-24](https://git.door43.org/Door43/en_tn/src/master/job/15/22.md)
* [Luke 16:24](https://git.door43.org/Door43/en_tn/src/master/luk/16/24.md)
* [Psalms 116:3-4](https://git.door43.org/Door43/en_tn/src/master/psa/116/003.md)

#### Word Data:####

* Strong's: H2342, H2479, H3708, H4164, H4689, H4691, H5100, H6695, H6862, H6869, H7267, H7581, G928, G3600, G4928


---

<a id="archer"/>

### archer, archers ###

#### Definition: ####

The term "archer" refers to a man who is skilled at using a bow and arrow as a weapon.

* In the Bible, an archer is usually a soldier who uses a bow and arrow to fight in an army.
* Archers were an important part of the Assyrian military force.
* Some languages might have a term for this, such as "bow-man."

(See also: [Assyria](names.html#assyria))

#### Bible References: ####

* [1 Samuel 31:1-3](https://git.door43.org/Door43/en_tn/src/master/1sa/31/01.md)
* [2 Chronicles 35:23-24](https://git.door43.org/Door43/en_tn/src/master/2ch/35/23.md)
* [Genesis 21:19-21](https://git.door43.org/Door43/en_tn/src/master/gen/21/19.md)
* [Isaiah 21:16-17](https://git.door43.org/Door43/en_tn/src/master/isa/21/16.md)
* [Job 16:13-14](https://git.door43.org/Door43/en_tn/src/master/job/16/13.md)
* [Proverbs 26:9-10](https://git.door43.org/Door43/en_tn/src/master/pro/26/09.md)

#### Word Data:####

* Strong's: H1167, H1869, H2671, H2686, H3384, H7198, H7199, H7228


---

<a id="armor"/>

### armor, armory ###

#### Definition: ####

The term "armor" refers to the equipment a soldier uses to fight in a battle and protect himself from enemy attacks. It is also used in a figurative way to refer to spiritual armor.

* Parts of a soldier's armor include a helmet, a shield, a breastplate, leg coverings, and a sword.
* Using the term figuratively, the apostle Paul compares physical armor to spiritual armor that God gives the believer to help him fight spiritual battles.
* The spiritual armor God gives his people to fight against sin and Satan includes truth, righteousness, the gospel of peace, faith, salvation, and the Holy Spirit.
* This could be translated with a term that means "soldier gear" or "protective battle clothing" or "protective covering" or "weapons."

(See also: [faith](kt.html#faith), [Holy Spirit](kt.html#holyspirit), [peace](#peace), [save](kt.html#save), [spirit](kt.html#spirit))

#### Bible References: ####

* [1 Samuel 31:9-10](https://git.door43.org/Door43/en_tn/src/master/1sa/31/09.md)
* [2 Samuel 20:8](https://git.door43.org/Door43/en_tn/src/master/2sa/20/08.md)
* [Ephesians 06:10-11](https://git.door43.org/Door43/en_tn/src/master/eph/06/10.md)
* [Jeremiah 51:3-4](https://git.door43.org/Door43/en_tn/src/master/jer/51/03.md)
* [Luke 11:21-23](https://git.door43.org/Door43/en_tn/src/master/luk/11/21.md)
* [Nehemiah 04:15-16](https://git.door43.org/Door43/en_tn/src/master/neh/04/15.md)

#### Word Data:####

* Strong's: H2185, H2290, H2488, H3627, H4055, H5402, G3696, G3833


---

<a id="arrogant"/>

### arrogant, arrogantly, arrogance ###

#### Definition: ####

The term "arrogant" means proud, usually in an obvious, outward way.

* An arrogant person will often boast about himself.
* Being arrogant usually includes thinking that other people are not as important or talented as oneself.
* People who do not honor God and who are in rebellion against him are arrogant because they do not acknowledge how great God is.

(See also: [acknowledge](#acknowledge), [boast](kt.html#boast), [proud](#proud))

#### Bible References: ####

* [1 Corinthians 04:17-18](https://git.door43.org/Door43/en_tn/src/master/1co/04/17.md)
* [2 Peter 02:17-19](https://git.door43.org/Door43/en_tn/src/master/2pe/02/17.md)
* [Ezekiel 16:49-50](https://git.door43.org/Door43/en_tn/src/master/ezk/16/49.md)
* [Proverbs 16:5-6](https://git.door43.org/Door43/en_tn/src/master/pro/16/05.md)
* [Psalm 056:1-2](https://git.door43.org/Door43/en_tn/src/master/psa/056/001.md)

#### Word Data:####

* Strong's: H1346, H1347, H6277


---

<a id="ash"/>

### ash, ashes, dust ###

#### Facts: ####

The term "ash" or "ashes" refers to the grey powdery substance that is left behind after wood is burned. It is sometimes used figuratively to refer to something that is worthless or useless.

* In the Bible sometimes the word "dust" is used when speaking about ashes. It can also refer to the fine, loose dirt that can form on dry ground.
* An "ash heap" is a pile of ashes.
* In ancient times, sitting in ashes was a sign of mourning or grieving.
* When grieving, it was the custom to wear rough, scratchy sackcloth and sit in ashes or sprinkle the ashes on the head.
* Putting ashes on the head was also a sign of humiliation or embarrassment.
* Striving for something worthless, is said to be like "feeding on ashes."
* When translating "ashes," use the word in the project language that refers to the burned-up remains after wood has burned.
* Note that an "ash tree" is a completely different term.

(See also: [fire](#fire), [sackcloth](#sackcloth))

#### Bible References: ####

* [1 Kings 20:9-10](https://git.door43.org/Door43/en_tn/src/master/1ki/20/09.md)
* [Jeremiah 06:25-26](https://git.door43.org/Door43/en_tn/src/master/jer/06/25.md)
* [Psalms 102:9-10](https://git.door43.org/Door43/en_tn/src/master/psa/102/009.md)
* [Psalms 113:7-8](https://git.door43.org/Door43/en_tn/src/master/psa/113/007.md)

#### Word Data:####

* Strong's: H80, H665, H666, H766, H1854, H6083, H6368, H7834, G2868, G4700, G5077, G5522


---

<a id="assembly"/>

### assembly, assemblies, assemble, assembled ###

#### Definition: ####

The term "assembly" usually refers to a group of people who come together to discuss problems, give advice, and make decisions.

* An assembly can be a group that is organized in an official and somewhat permanent way, or it can be a group of people who come together temporarily for a specific purpose or occasion.
* In the Old Testament there was a special kind of assembly called a "sacred assembly" in which the people of Israel would gather to worship Yahweh.
* Sometimes the term "assembly" referred to the Israelites in general, as a group.
* A large gathering of enemy soldiers was sometimes also referred to as an "assembly." This could be translated as "army."
* In the New Testament, an assembly of 70 Jewish leaders in major cities such as Jerusalem would meet to judge legal matters and to settle disputes between people. This assembly was known as the "Sanhedrin" or the "Council."

#### Translation Suggestions ####

* Depending on the context, "assembly" could also be translated as "special gathering" or "congregation" or "council" or "army" or "large group."
* When the term "assembly" refers generally to the Israelites as a whole, it could also be translated as "community" or "people of Israel."
* The phrase, "all the assembly" could be translated as "all the people" or "the whole group of Israelites" or "everyone." (See: [hyperbole](https://git.door43.org/Door43/en_ta/src/master/translate/figs-hyperbole.md))

(See also: [council](#council))

#### Bible References: ####

* [1 Kings 08:14-16](https://git.door43.org/Door43/en_tn/src/master/1ki/08/14.md)
* [Acts 07:38-40](https://git.door43.org/Door43/en_tn/src/master/act/07/38.md)
* [Ezra 10:12-13](https://git.door43.org/Door43/en_tn/src/master/ezr/10/12.md)
* [Hebrews 12:22-24](https://git.door43.org/Door43/en_tn/src/master/heb/12/22.md)
* [Leviticus 04:20-21](https://git.door43.org/Door43/en_tn/src/master/lev/04/20.md)
* [Nehemiah 08:1-3](https://git.door43.org/Door43/en_tn/src/master/neh/08/01.md)

#### Word Data: ####

* Strong's: H622, H627, H1413, H1481, H2199, H3259, H4150, H4186, H4744, H5475, H5712, H5789, H6116, H6633, H6908, H6950, H6951, H6952, H7284, G1577, G1997, G3831, G4863, G4864, G4871, G4905


---

<a id="assign"/>

### assign, assigned, assigning, assignment, assignments, reassign ###

#### Facts: ####

The term "assign" or "assigned" refers to appointing someone to do a specific task or designating something to be provided to one or more people.

* The prophet Samuel foretold that King Saul would "assign" the best young men of Israel to serve in the military.
* Moses "assigned" to each of the twelve tribes of Israel a portion of the land of Canaan for them to live on.
* Under the Old Testament law, certain tribes of Israel were assigned to serve as priests, artists, singers and builders.
* Depending on the context, "assign" could be translated as "give" or "appoint" or "choose for the task of."
* The term "assigned" could be translated as "appointed" or "given the task." 

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_ta/src/master/translate/translate-names.md))

(See also: [appoint](kt.html#appoint), [Samuel](names.html#samuel), [Saul (OT)](names.html#saul))

#### Bible References: ####

* [1 Chronicles 06:48](https://git.door43.org/Door43/en_tn/src/master/1ch/06/48.md)
* [Daniel 12:12-13](https://git.door43.org/Door43/en_tn/src/master/dan/12/12.md)
* [Jeremiah 43:11-13](https://git.door43.org/Door43/en_tn/src/master/jer/43/11.md)
* [Joshua 18:1-2](https://git.door43.org/Door43/en_tn/src/master/jos/18/01.md)
* [Numbers 04:27-28](https://git.door43.org/Door43/en_tn/src/master/num/04/27.md)
* [Psalms 078:54-55](https://git.door43.org/Door43/en_tn/src/master/psa/078/054.md)

#### Word Data:####

* Strong's: H2506, H3335, H4487, H4941, H5157, H5307, H5414, H5596, H5975, H6485, H7760, G3307


---

<a id="astray"/>

### astray, go astray, went astray, lead astray, led astray, stray, strayed, strays ###

#### Definition: ####

The terms "stray" and "go astray" mean to disobey God's will. People who are "led astray" have allowed other people or circumstances to influence them to disobey God.

* The word "astray" gives a picture of leaving a clear path or a place of safety to go down a wrong and dangerous path.
* Sheep who leave the pasture of their shepherd have "strayed." God compares sinful people to sheep who have left him and "gone astray."

#### Translation Suggestions: ####

* The phrase "go astray" could be translated as "go away from God" or "take a wrong path away from God's will" or "stop obeying God" or "live in a way that goes away from God."
* To "lead someone astray" could be translated as "cause someone to disobey God" or "influence someone to stop obeying God" or "cause someone to follow you down a wrong path." 

(See also: [disobey](#disobey), [shepherd](#shepherd))

#### Bible References: ####

* [1 John 03:7-8](https://git.door43.org/Door43/en_tn/src/master/1jn/03/07.md)
* [2 Timothy 03:10-13](https://git.door43.org/Door43/en_tn/src/master/2ti/03/10.md)
* [Exodus 23:4-5](https://git.door43.org/Door43/en_tn/src/master/exo/23/04.md)
* [Ezekiel 48:10-12](https://git.door43.org/Door43/en_tn/src/master/ezk/48/10.md)
* [Matthew 18:12-14](https://git.door43.org/Door43/en_tn/src/master/mat/18/12.md)
* [Matthew 24:3-5](https://git.door43.org/Door43/en_tn/src/master/mat/24/03.md)
* [Psalms 058:3-5](https://git.door43.org/Door43/en_tn/src/master/psa/058/003.md)
* [Psalms 119:109-110](https://git.door43.org/Door43/en_tn/src/master/psa/119/109.md)

#### Word Data: ####

* Strong's: H5080, H7683, H7686, H8582, G4105


---

<a id="avenge"/>

### avenge, avenges, avenged, avenging, avenger, revenge, vengeance ###

#### Definition: ####

To "avenge" or "take revenge" or "execute vengeance" is to punish someone in order to pay him back for the harm he did. The act of avenging or taking revenge is "vengeance."

* Usually "avenge" implies an intent to see justice done or to right a wrong,
* When referring to people, the expression "take revenge" or "get revenge" usually involves wanting to get back at the person who did the harm.
* When God "takes vengeance" or "executes vengeance," he is acting in righteousness because he is punishing sin and rebellion.

#### Translation Suggestions: ####

* The expression to "avenge" could also be translated as to "right a wrong" or to "get justice for."
* When referring to human beings, to "take revenge" could be translated as "pay back" or "hurt in order to punish" or "get back at."
* Depending on the context, "vengeance" could be translated as "punishment" or "punishment of sin" or "payment for wrongs done."  If a word meaning "retaliation" is used, this would apply to human beings only.
* When God says, "take my vengeance," this could be translated by "punish them for wrongs done against me" or "cause bad things to happen because they have sinned against me."
* When referring to God's vengeance, make sure it is clear that God is right in his punishment of sin.

(See also: [punish](#punish), [just](kt.html#justice), [righteous](kt.html#righteous))

#### Bible References: ####

* [1 Samuel 24:12-13](https://git.door43.org/Door43/en_tn/src/master/1sa/24/12.md)
* [Ezekiel 25:15-17](https://git.door43.org/Door43/en_tn/src/master/ezk/25/15.md)
* [Isaiah 47:3-5](https://git.door43.org/Door43/en_tn/src/master/isa/47/03.md)
* [Leviticus 19:17-18](https://git.door43.org/Door43/en_tn/src/master/lev/19/17.md)
* [Psalms 018:46-47](https://git.door43.org/Door43/en_tn/src/master/psa/018/046.md)
* [Romans 12:19-21](https://git.door43.org/Door43/en_tn/src/master/rom/12/19.md)

#### Word Data: ####

* Strong's: H1350, H3467, H5358, H5359, H5360, H6544, H6546, H8199, G1349, G1556, G1557, G1558, G2917, G3709


---

<a id="awe"/>

### awe, awesome ###

#### Definition: ####

The term "awe" refers to the sense of amazement and deep respect that comes from seeing something great, powerful, and magnificent.

* The term "awesome" describes someone or something that inspires a feeling of awe.
* The visions of the glory of God seen by the prophet Ezekiel were "awesome" or "awe-inspiring."
* Typical human responses showing awe of God's presence include: fear, bowing or kneeling down, covering the face, and trembling.

(See also: [fear](kt.html#fear), [glory](kt.html#glory))

#### Bible References: ####

* [1 Chronicles 17:19-21](https://git.door43.org/Door43/en_tn/src/master/1ch/17/19.md)
* [Genesis 28:16-17](https://git.door43.org/Door43/en_tn/src/master/gen/28/16.md)
* [Hebrews 12:27-29](https://git.door43.org/Door43/en_tn/src/master/heb/12/27.md)
* [Psalm 022:22-23](https://git.door43.org/Door43/en_tn/src/master/psa/022/022.md)
* [Psalms 147:4-5](https://git.door43.org/Door43/en_tn/src/master/psa/147/004.md)

#### Word Data:####

* Strong's: H366, H1481, H3372, H6206, H7227, G2124


---

<a id="ax"/>

### ax, axes ###

#### Definition: ####

An ax is tool used for cutting or chopping trees or wood. 

 * An ax usually has a long wooden handle with a large metal blade attached to the end.
 * If your culture has a tool that is similar to an ax, the name of that tool could be used to translate "ax."
 * Other ways to translate this term could include "tree-cutting tool" or "wooden tool with blade" or "long-handled wood-chopping tool."
 * In one Old Testament event, the blade of an ax fell into a river, so it is best if the tool that is described has a blade that can come loose from the wooden handle.

#### Bible References: ####

* [1 Kings 06:7-8](https://git.door43.org/Door43/en_tn/src/master/1ki/06/07.md)
* [2 Kings 06:4-5](https://git.door43.org/Door43/en_tn/src/master/2ki/06/04.md)
* [Judges 09:48-49](https://git.door43.org/Door43/en_tn/src/master/jdg/09/48.md)
* [Luke 03:9](https://git.door43.org/Door43/en_tn/src/master/luk/03/09.md)
* [Matthew 03:10-12](https://git.door43.org/Door43/en_tn/src/master/mat/03/10.md)
* [Psalm 035:1-3](https://git.door43.org/Door43/en_tn/src/master/psa/035/001.md)

#### Word Data:####

* Strong's: H1631, H4621, H7134, G513


---

<a id="banquet"/>

### banquet ###

#### Definition: ####

A banquet is large, formal meal that usually includes several food courses.

* In ancient times, kings often served banquet meals to entertain political leaders and other important guests.
* This could also be translated as, "elaborate meal" or "important feast" or "multi-course meal."

#### Bible References: ####

* [Daniel 05:10](https://git.door43.org/Door43/en_tn/src/master/dan/05/10.md)
* [Isaiah 05:11-12](https://git.door43.org/Door43/en_tn/src/master/isa/05/11.md)
* [Jeremiah 16:7-9](https://git.door43.org/Door43/en_tn/src/master/jer/16/07.md)
* [Luke 05:29-32](https://git.door43.org/Door43/en_tn/src/master/luk/05/29.md)
* [Song of Solomon 02:3-4](https://git.door43.org/Door43/en_tn/src/master/sng/02/03.md)

#### Word Data:####

* Strong's: H3739, H4797, H4960, H4961, H8354, G1173, G1403


---

<a id="barley"/>

### barley ###

#### Definition: ####

The term "barley" refers to a kind of grain that is used to make bread.

* The barley plant has a long stalk with a head at the top where the seeds or grains grow.
* Barley does well in warmer weather so it is often harvested in spring or summer.
* When barley is threshed, the edible seeds are separated from the worthless chaff.
* Barley grain is ground up into flour, which is then mixed with water or oil to make bread.
* If barley is not known, this could be translated as "grain called barley" or "barley grain."

(See also: [How to Translate Unknowns](https://git.door43.org/Door43/en_ta/src/master/translate/translate-unknown.md))

(See also: [grain](#grain), [thresh](#thresh), [wheat](#wheat))

#### Bible References: ####

* [1 Chronicles 11:12-14](https://git.door43.org/Door43/en_tn/src/master/1ch/11/12.md)
* [Job 31:38-40](https://git.door43.org/Door43/en_tn/src/master/job/31/38.md)
* [Judges 07:13-14](https://git.door43.org/Door43/en_tn/src/master/jdg/07/13.md)
* [Numbers 05:15](https://git.door43.org/Door43/en_tn/src/master/num/05/15.md)
* [Revelation 06:5-6](https://git.door43.org/Door43/en_tn/src/master/rev/06/05.md)

#### Word Data:####

* Strong's: H8184, G2915, G2916


---

<a id="barren"/>

### barren ###

#### Definition: ####

To be "barren" means to not be fertile or fruitful.

* Soil or land that is barren is not able to produce any plants.
* A woman who is barren is one who is physically unable to conceive or bear a child.

#### Translation Suggestions: ####

* When "barren" is used to refer to land, it could be translated as "not fertile" or "unfruitful" or "without plants."
* When it is referring to a barren woman, it could be translated as "childless" or "not able to bear children" or "unable to conceive a child."

#### Bible References: ####

* [1 Samuel 02:5](https://git.door43.org/Door43/en_tn/src/master/1sa/02/05.md)
* [Galatians 04:26-27](https://git.door43.org/Door43/en_tn/src/master/gal/04/26.md)
* [Genesis 11:29-30](https://git.door43.org/Door43/en_tn/src/master/gen/11/29.md)
* [Job 03:6-7](https://git.door43.org/Door43/en_tn/src/master/job/03/06.md)

#### Word Data: ####

* Strong's: H4420, H6115, H6135, H6723, H7909, H7921, G692, G4723


---

<a id="basket"/>

### basket, baskets, basketfuls ###

#### Definition: ####

The term  "basket" refers to a container made of woven material.

* In biblical times, baskets were probably woven with strong plant materials, such as wood from peeled tree branches or twigs.
* A basket could be coated with a waterproof substance so that it could float.
* When Moses was a baby, his mother made a waterproof basket to put him in and floated it among the reeds of the Nile River.
* The word translated as "basket" in that story is the same word that is translated as "ark" referring to the boat that Noah built. The common meaning of its use in these two contexts may be "floating container."

(See also: [ark](kt.html#ark), [Moses](names.html#moses), [Nile River](names.html#nileriver), [Noah](names.html#noah))

#### Bible References: ####

* [2 Corinthians 11:32-33](https://git.door43.org/Door43/en_tn/src/master/2co/11/32.md)
* [Acts 09:23-25](https://git.door43.org/Door43/en_tn/src/master/act/09/23.md)
* [Amos 08:1-3](https://git.door43.org/Door43/en_tn/src/master/amo/08/01.md)
* [John 06:13-15](https://git.door43.org/Door43/en_tn/src/master/jhn/06/13.md)
* [Judges 06:19-20](https://git.door43.org/Door43/en_tn/src/master/jdg/06/19.md)
* [Matthew 14:19-21](https://git.door43.org/Door43/en_tn/src/master/mat/14/19.md)

#### Word Data:####

* Strong's: H374, H1731, H1736, H2935, H3619, H5536, H7991, G2894, G3426, G4553, G4711


---

<a id="bear"/>

### bear, bears, bearing, bearer ###

#### Facts: ####

The term "bear" literally means "carry" something. There are also many figurative uses of this term.

* When speaking of a woman who will bear a child, this means "give birth to" a child.
* To "bear a burden" means to "experience difficult things." These difficult things could include physical or emotional suffering. 
* A common expression in the Bible is "bear fruit," which means "produce fruit" or "have fruit."
* The expression "bear witness" means "testify" or "report what one has seen or experienced."
* The statement that "a son will not bear the iniquity of his father" means that he "will not be held responsible for" or "will not be punished for" his father's sins.
* In general, this term could be translated as "carry" or "be responsible for" or "produce" or "have" or "endure," depending on the context.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_ta/src/master/translate/translate-names.md))

(See also: [burden](#burden), [Elisha](names.html#elisha), [endure](#endure), [fruit](#fruit), [iniquity](kt.html#iniquity), [report](#report), [sheep](#sheep), [strength](#strength), [testimony](kt.html#testimony), [testimony](kt.html#testimony))

#### Bible References: ####

* [Lamentations 03:25-29](https://git.door43.org/Door43/en_tn/src/master/lam/03/25.md)

#### Word Data:####

* Strong's: H2232, H3201, H3205, H5187, H5375, H5445, H5449, H6030, H6509, H6779, G142, G399, G430, G503, G941, G1080, G1627, G2592, G3114, G3140, G4064, G4160, G4722, G4828, G4901, G5041, G5088, G5297, G5342, G5409, G5576


---

<a id="bearanimal"/>

### bear, bears ###

#### Definition: ####

A bear is a large, four-legged furry animal with dark brown or black hair, with sharp teeth and claws. Bears were common in Israel during Bible times.

* These animals live in forests and mountain areas; they eat fish, insects, and plants.
* In the Old Testament, the bear is used as a symbol of strength.
* While tending sheep, the shepherd David fought a bear and defeated it.
* Two bears came out of the forest and attacked a group of youths who had mocked the prophet Elisha.

(See also: [David](names.html#david), [Elisha](names.html#elisha))

#### Bible References: ####

#### Word Data: ####

* Strong's: H1677, G715


---

<a id="beast"/>

### beast, beasts ###

#### Facts: ####

In the Bible, the term "beast" is often just another way of saying "animal."

* A wild beast is a type of animal that lives freely in the forest or fields and has not been trained by people.
* A domestic beast is an animal that lives with people and is kept for food or for performing work, such as plowing fields. Often the term "livestock" is used to refer to this kind of animal.
* The Old Testament book of Daniel and the New Testament book of Revelation describe visions which have beasts that represent evil powers and authorities that oppose God.  (See: [Metaphor](https://git.door43.org/Door43/en_ta/src/master/translate/figs-metaphor.md))
* Some of these beasts are described as having strange features, such as several heads and many horns. They often have power and authority, indicating that they may represent countries, nations, or other political powers.
* Ways to translate this could include "creature" or "created thing" or "animal" or "wild animal," depending on the context.

(See also: [authority](kt.html#authority), [Daniel](names.html#daniel), [livestock](#livestock), [nation](#nation), [power](kt.html#power), [reveal](kt.html#reveal), [Beelzebul](names.html#beelzebul))

#### Bible References: ####

* [1 Corinthians 15:31-32](https://git.door43.org/Door43/en_tn/src/master/1co/15/31.md)
* [1 Samuel 17:44-45](https://git.door43.org/Door43/en_tn/src/master/1sa/17/44.md)
* [2 Chronicles 25:18-19](https://git.door43.org/Door43/en_tn/src/master/2ch/25/18.md)
* [Jeremiah 16:1-4](https://git.door43.org/Door43/en_tn/src/master/jer/16/01.md)
* [Leviticus 07:21](https://git.door43.org/Door43/en_tn/src/master/lev/07/21.md)
* [Psalms 049:12-13](https://git.door43.org/Door43/en_tn/src/master/psa/049/012.md)

#### Word Data:####

* Strong's: H338, H929, H1165, H2123, H2416, H2423, H2874, H3753, H4806, H7409, G2226, G2341, G2342, G2934, G4968, G5074


---

<a id="beg"/>

### beg, begged, begging, beggar ###

#### Definition: ####

The term "beg" means to urgently ask someone for something. It often refers to asking for money, but it is also commonly used to refer to pleading for something.

 * Often people beg or plead when they strongly need something, but don't know if the other person will give them what they ask for.
 * A "beggar" is someone who regularly sits or stands in a public place to ask people for money.
 * Depending on the context, this term could be translated as, "plead" or "urgently ask" or "demand money" or "regularly ask for money."

(See also: [plead](#plead))

#### Bible References: ####

* [Luke 16:19-21](https://git.door43.org/Door43/en_tn/src/master/luk/16/19.md)
* [Mark 06:56](https://git.door43.org/Door43/en_tn/src/master/mrk/06/56.md)
* [Matthew 14:34-36](https://git.door43.org/Door43/en_tn/src/master/mat/14/34.md)
* [Psalm 045:12-13](https://git.door43.org/Door43/en_tn/src/master/psa/045/012.md)

#### Examples from the Bible stories: ####

  __*[10:04](https://git.door43.org/Door43/en_tn/src/master/obs/10/04.md)__ God sent frogs all over Egypt. Pharaoh __begged__ Moses to take away the frogs.
  __*[29:08](https://git.door43.org/Door43/en_tn/src/master/obs/29/08.md)__ "The king called the servant and said, 'You wicked servant! I forgave your debt because you __begged__ me."
  __*[32:07](https://git.door43.org/Door43/en_tn/src/master/obs/32/07.md)__ The demons __begged__ Jesus, "Please do not send us out of this region!" There was a herd of pigs feeding on a nearby hill. So, the demons __begged__ Jesus, "Please send us into the pigs instead!"
  __*[32:10](https://git.door43.org/Door43/en_tn/src/master/obs/32/10.md)__ The man who used to have the demons __begged__ to go along with Jesus.
  __*[35:11](https://git.door43.org/Door43/en_tn/src/master/obs/35/11.md)__ His father came out and __begged__ him to come and celebrate with them, but he refused."
  __*[44:01](https://git.door43.org/Door43/en_tn/src/master/obs/44/01.md)__ One day, Peter and John were going to the Temple. As they approached the Temple gate, they saw a crippled man who was __begging__ for money.

#### Word Data:####

* Strong's: H34, H7592, G154, G1871, G4319, G4434, G6075


---

<a id="betray"/>

### betray, betrays, betrayed, betraying, betrayer, betrayers ###

#### Definition: ####

The term "betray" means to act in a way that deceives and harms someone. A "betrayer" is a person who betrays a friend who was trusting him.

* Judas was "the betrayer" because he told the Jewish leaders how to capture Jesus.
* The betrayal by Judas was especially evil because he was an apostle of Jesus who received money in exchange for giving the Jewish leaders information that would result in Jesus' unjust death.

#### Translation Suggestions: ####

* Depending on the context, the term "betray" could be translated as "deceive and cause harm to" or "turn over to the enemy" or "treat treacherously."
* The term "betrayer" could be translated as "person who betrays" or "double dealer" or "traitor."

(See also: [Judas Iscariot](names.html#judasiscariot), [Jewish leaders](#jewishleaders), [apostle](kt.html#apostle))

#### Bible References: ####

* [Acts 07:51-53](https://git.door43.org/Door43/en_tn/src/master/act/07/51.md)
* [John 06:64-65](https://git.door43.org/Door43/en_tn/src/master/jhn/06/64.md)
* [John 13:21-22](https://git.door43.org/Door43/en_tn/src/master/jhn/13/21.md)
* [Matthew 10:2-4](https://git.door43.org/Door43/en_tn/src/master/mat/10/02.md)
* [Matthew 26:20-22](https://git.door43.org/Door43/en_tn/src/master/mat/26/20.md)

#### Examples from the Bible stories: ####

* __[21:11](https://git.door43.org/Door43/en_tn/src/master/obs/21/11.md)__ Other prophets foretold that those who killed the Messiah would gamble for his clothes and he would be __betrayed__  by a friend. The prophet Zechariah foretold that the friend would be paid thirty silver coins as payment for __betraying__  the Messiah.
* __[38:02](https://git.door43.org/Door43/en_tn/src/master/obs/38/02.md)__ After Jesus and the disciples arrived in Jerusalem, Judas went to the Jewish leaders and offered to __betray__  Jesus to them in exchange for money.
* __[38:03](https://git.door43.org/Door43/en_tn/src/master/obs/38/03.md)__ The Jewish leaders, led by the high priest, paid Judas thirty silver coins to __betray__  Jesus.
* __[38:06](https://git.door43.org/Door43/en_tn/src/master/obs/38/06.md)__ Then Jesus said to the disciples, "One of you will __betray__  me." â€¦ Jesus said, "The person to whom I give this piece of bread is the __betrayer__."
* __[38:13](https://git.door43.org/Door43/en_tn/src/master/obs/38/13.md)__ When he returned the third time, Jesus said, "Wake up! My __betrayer__  is here."
* __[38:14](https://git.door43.org/Door43/en_tn/src/master/obs/38/14.md)__ Then Jesus said, "Judas, do you __betray__  me with a kiss?"
* __[39:08](https://git.door43.org/Door43/en_tn/src/master/obs/39/08.md)__ Meanwhile, Judas, the __betrayer__, saw that the Jewish leaders had condemned Jesus to die. He became full of sorrow and went away and killed himself.

#### Word Data: ####

* Strong's: H7411, G3860, G4273


---

<a id="biblicaltimeday"/>

### day, days ###

#### Definition: ####

The term "day" literally refers to a period of time lasting 24 hours beginning at sundown. It is also used figuratively.

* For the Israelites and the Jews, a day began at sunset of one day and ended at sunset of the next day.
* Sometimes the term "day" is used figuratively to refer to a longer period of time, such as the "day of Yahweh" or "last days."
* Some languages will use a different expression to translate these figurative uses or will translate "day" nonfiguratively.
* Other translations of "day" could include, "time" or "season" or "occasion" or "event," depending on the context.

(See also: [judgment day](kt.html#judgmentday), [last day](kt.html#lastday))

#### Bible References: ####

* [Acts 20:4-6](https://git.door43.org/Door43/en_tn/src/master/act/20/04.md)
* [Daniel 10:4-6](https://git.door43.org/Door43/en_tn/src/master/dan/10/04.md)
* [Ezra 06:13-15](https://git.door43.org/Door43/en_tn/src/master/ezr/06/13.md)
* [Ezra 06:19-20](https://git.door43.org/Door43/en_tn/src/master/ezr/06/19.md)
* [Matthew 09:14-15](https://git.door43.org/Door43/en_tn/src/master/mat/09/14.md)

#### Word Data:####

* Strong's: H3117, H3118, H6242, G2250


---

<a id="biblicaltimehour"/>

### hour, hours ###

#### Definition: ####

The term "hour" is often used in the Bible to tell what time of day a certain event took place. It is also used figuratively to mean "time" or "moment."

* The Jews counted daylight hours starting at sunrise (around 6 a.m.). For example, "the ninth hour" meant "around three in the afternoon."
* Nighttime hours were counted starting at sunset (around 6 p.m.). For example, "the third hour of the night" meant "around nine in the evening" in our present-day system..
* Since references to time in the Bible will not correspond exactly to the present-day time system, phrases such as "around nine" or "about six o'clock" could be used.    
* Some translations might add phrases like "in the evening" or "in the morning" or "in the afternoon" to make it clear what time of day is being talked about.
* The phrase, "in that hour" could be translated as, "at that time" or "in that moment."
* Referring to Jesus, the expression "his hour had come" could be translated as, "the time had come for him to" or "the appointed time for him had come."

#### Bible References: ####

* [Acts 02:14-15](https://git.door43.org/Door43/en_tn/src/master/act/02/14.md)
* [John 04:51-52](https://git.door43.org/Door43/en_tn/src/master/jhn/04/51.md)
* [Luke 23:44-45](https://git.door43.org/Door43/en_tn/src/master/luk/23/44.md)
* [Matthew 20:3-4](https://git.door43.org/Door43/en_tn/src/master/mat/20/03.md)

#### Word Data:####

* Strong's: H8160, G5610


---

<a id="biblicaltimemonth"/>

### month, months, monthly ###

#### Definition: ####

The term "month" refers to a period of time lasting about four weeks. The number of days in each month varies depending on whether a lunar or solar calendar is used.

* In the lunar calendar, the length of each month is based on the amount of time it takes for the moon to go around the earth, about 29 days. In this system there are 12 or 13 months in a year. Despite the year being 12 or 13 months, the first month is always called the same name even though it may be a different season. 
* The "new moon," or beginning phase of the moon with its sliver of light, marks the beginning of each month in the lunar calendar.
* All the names of months referred to in the Bible are those of the lunar calendar since this was the system used by the Israelites. Modern Jews still use this calendar for religious purposes.
* The modern-day solar calendar is based on how long it takes the earth to go around the sun (about 365 days). In this system, the year is always divided up into 12 months, with the length of each month ranging from 28 to 31 days.

#### Bible References: ####

* [1 Samuel 20:32-34](https://git.door43.org/Door43/en_tn/src/master/1sa/20/32.md)
* [Acts 18:9-11](https://git.door43.org/Door43/en_tn/src/master/act/18/09.md)
* [Hebrews 11:23-26](https://git.door43.org/Door43/en_tn/src/master/heb/11/23.md)
* [Numbers 10:10](https://git.door43.org/Door43/en_tn/src/master/num/10/10.md)

#### Word Data:####

* Strong's: H2320, H3391, H3393, G3376


---

<a id="biblicaltimewatch"/>

### watch (biblical time), watches ###

#### Definition: ####

In biblical times, a "watch" was a period of time at night during which a watchman or guard for a city would be on duty looking out for any danger from an enemy.

* In the Old Testament, the Israelites had three watches which were called "beginning" (sunset to 10 p.m.), "middle" (10 p.m. to 2 a.m.), and "morning" (2 a.m. to sunrise) watches.
* In the New Testament, the Jews followed the Roman system and had four watches, named simply "first" (sunset to 9 p.m.), "second" (9 p.m. to 12 midnight), "third" (12 midnight to 3 a.m.), and "fourth" (3 a.m. to sunrise) watches.
* These could also be translated with more general expressions such as "late evening" or "middle of the night" or "very early in the morning," depending on which watch is being referred to.

(See also: [watch](#watch))

#### Bible References: ####

* [Luke 12:37-38](https://git.door43.org/Door43/en_tn/src/master/luk/12/37.md)
* [Mark 06:48-50](https://git.door43.org/Door43/en_tn/src/master/mrk/06/48.md)
* [Matthew 14:25-27](https://git.door43.org/Door43/en_tn/src/master/mat/14/25.md)
* [Psalms 090:3-4](https://git.door43.org/Door43/en_tn/src/master/psa/090/003.md)

#### Word Data:####

* Strong's: H821, G5438


---

<a id="biblicaltimeweek"/>

### week, weeks ###

#### Definition: ####

The term "week" literally refers to a period of time lasting seven days.

* In the Jewish system of counting time, a week begins at sunset on Saturday and ends at sunset the following Saturday.
* In the Bible, the term "week" is sometimes used figuratively to refer to a group of seven units of time, such as seven years.
* The "Festival of Weeks" is a celebration of harvest that takes place seven weeks after Passover. It is also called "Pentecost."

(See also: [Pentecost](kt.html#pentecost))

#### Bible References: ####

* [Acts 20:7-8](https://git.door43.org/Door43/en_tn/src/master/act/20/07.md)
* [Deuteronomy 16:9-10](https://git.door43.org/Door43/en_tn/src/master/deu/16/09.md)
* [Leviticus 23:15-16](https://git.door43.org/Door43/en_tn/src/master/lev/23/15.md)

#### Word Data:####

* Strong's: H7620, G4521


---

<a id="biblicaltimeyear"/>

### year, years ###

#### Definition: ####

When used literally, the term "year" in the Bible refers to a period of time lasting 354 days. This is according to the lunar calendar system which is based on the time it takes for the moon to go around the earth.

* A year in the modern-day solar calendar lasts 365 days divided into 12 months, based on the amount of time it takes for the earth to travel around the sun.
* In both calendar systems a year has 12 months. But an extra 13th month is sometimes added to the year in the lunar calendar to make up for the fact that a lunar year is 11 days less than a solar year. This helps keep the two calendars more in line with each other.
* In the Bible, the term "year" is also used in a figurative sense to refer to a general time when a special event takes place. Examples of this include, "the year of Yahweh" or "in the year of drought" or "the favorable year of the Lord." In these contexts, "year" could be translated as "time" or "season" or "time period."

(See also: [month](#biblicaltimemonth))

#### Bible References: ####

* [2 Kings 23:31-33](https://git.door43.org/Door43/en_tn/src/master/2ki/23/31.md)
* [Acts 19:8-10](https://git.door43.org/Door43/en_tn/src/master/act/19/08.md)
* [Daniel 08:1-2](https://git.door43.org/Door43/en_tn/src/master/dan/08/01.md)
* [Exodus 12:1-2](https://git.door43.org/Door43/en_tn/src/master/exo/12/01.md)

#### Word Data:####

* Strong's: H3117, H7620, H7657, H8140, H8141, G1763, G2094


---

<a id="blemish"/>

### blemish, blemishes, unblemished ###

#### Facts: ####

The term "blemish" refers to a physical defect or imperfection on an animal or person. It can also refer to spiritual imperfections and faults in people.

* For certain sacrifices, God instructed the Israelites to offer an animal with no blemishes or defects.
* This is a picture of how Jesus Christ was the perfect sacrifice, without any sin.
* Believers in Christ have been cleansed from their sin by his blood and are considered to be without blemish.
* Ways to translate this term could include "defect" or "imperfection" or "sin," depending on the context.

(See also: [believe](kt.html#believe), [clean](kt.html#clean), [sacrifice](#sacrifice), [sin](kt.html#sin))

#### Bible References: ####

* [1 Peter 01:18-19](https://git.door43.org/Door43/en_tn/src/master/1pe/01/18.md)
* [2 Peter 02:12-14](https://git.door43.org/Door43/en_tn/src/master/2pe/02/12.md)
* [Deuteronomy 15:19-21](https://git.door43.org/Door43/en_tn/src/master/deu/15/19.md)
* [Numbers 06:13-15](https://git.door43.org/Door43/en_tn/src/master/num/06/13.md)
* [Song of Solomon 04:6-7](https://git.door43.org/Door43/en_tn/src/master/sng/04/06.md)

#### Word Data:####

* Strong's: H3971, H8400, H8549, G3470


---

<a id="bloodshed"/>

### bloodshed ###

#### Definition: ####

The term "bloodshed" refers to the death of human beings due to murder, war, or some other violent act.

* This term literally means "shedding of blood," which refers to when blood comes out of a person's body from an open wound.
* The term "bloodshed" is often used to refer to widespread killing of people.
* It is also used as a general reference to the sin of murder.

#### Translation Suggestions: ####

* "The bloodshed" could be translated as "the killing of people" or "the many people who were killed."
* "Through bloodshed" could also be translated as, "by killing people."
* "Innocent bloodshed" could be translated as "killing innocent people."
* "Bloodshed follows bloodshed" could be translated as "they keep killing people" or "the killing of people goes on and on" or "they have killed many people and continue to do that" or "people keep killing other people."
* Another figurative use, "bloodshed will pursue you," could be translated as "your people will continue to experience bloodshed" or "your people will keep being killed" or "your people will continue to be at war with other nations and people will keep dying."

(See also: [blood](kt.html#blood) [slaughter](#slaughter))

#### Bible References: ####

* [1 Chronicles 22:6-8](https://git.door43.org/Door43/en_tn/src/master/1ch/22/06.md)
* [Genesis 09:5-7](https://git.door43.org/Door43/en_tn/src/master/gen/09/05.md)
* [Hebrews 09:21-22](https://git.door43.org/Door43/en_tn/src/master/heb/09/21.md)
* [Isaiah 26:20-21](https://git.door43.org/Door43/en_tn/src/master/isa/26/20.md)
* [Matthew 23:29-31](https://git.door43.org/Door43/en_tn/src/master/mat/23/29.md)

#### Word Data:####

* Strong's: H1818, G2210


---

<a id="blotout"/>

### blot out, blots out, blotted out, wipe out, wipes out, wiped out ###

#### Definition: ####

The terms "blot out" and "wipe out" are expressions that mean to completely remove or destroy something or someone.

* These expressions can be used in a positive sense, as when God "blots out" sins by forgiving them and choosing not to remember them.
* It is also often used in a negative sense, as when God "blots out" or "wipes out" a people group, destroying them because of their sin.
* The Bible talks about a person's name being "blotted out" or "wiped out" of God's Book of Life, which means that the person will not receive eternal life.

#### Translation Suggestions: ####

* Depending on the context, these expressions could be translated as "get rid of" or "remove" or "completely destroy" or "completely remove."
* When referring to blotting someone's name out of the Book of Life, this could be translated as "removed from" or "erased."

#### Bible References: ####

* [Deuteronomy 29:20-21](https://git.door43.org/Door43/en_tn/src/master/deu/29/20.md)
* [Exodus 32:30-32](https://git.door43.org/Door43/en_tn/src/master/exo/32/30.md)
* [Genesis 07:23-24](https://git.door43.org/Door43/en_tn/src/master/gen/07/23.md)
* [Psalm 051:1-2](https://git.door43.org/Door43/en_tn/src/master/psa/051/001.md)

#### Word Data: ####

* Strong's: H3971, H4229, G631, G1591, G1813


---

<a id="bold"/>

### bold, boldly, boldness, emboldened ###

#### Definition: ####

These terms all refer to having courage and confidence to speak the truth and do the right thing even when it is difficult or dangerous. 

* A "bold" person is not afraid to say and do what is good and right, including defending people who are being mistreated. This could be translated as "courageous" or "fearless."
* In the New Testament, the disciples continued to "boldly" preach about Christ in public places, in spite of the danger of being put in jail or killed. This could be translated as "confidently" or "with strong courage" or "courageously."
* The "boldness" of these early disciples in speaking the good news of Christ's redeeming death on the cross resulted in the gospel being spread throughout Israel and nearby countries and finally, to the rest of the world. "Boldness" could also be translated as "confident courage."

(See also: [confidence](#confidence), [good news](kt.html#goodnews), [redeem](kt.html#redeem))

#### Bible References: ####

* [1 John 02:27-29](https://git.door43.org/Door43/en_tn/src/master/1jn/02/27.md)
* [1 Thessalonians 02:1-2](https://git.door43.org/Door43/en_tn/src/master/1th/02/01.md)
* [2 Corinthians 03:12-13](https://git.door43.org/Door43/en_tn/src/master/2co/03/12.md)
* [Acts 04:13-14](https://git.door43.org/Door43/en_tn/src/master/act/04/13.md)

#### Word Data:####

* Strong's: H982, H983, H4834, H5797, G662, G2292, G3618, G3954, G3955, G5111, G5112


---

<a id="bookoflife"/>

### Book of Life ###

#### Definition: ####

The term "Book of Life" is used to refer to where God has written the names of all the people whom he has redeemed and given eternal life to.

* Revelation refers to this book as "the Lamb's Book of Life." This could be translated as "the book of life belonging to Jesus, the Lamb of God." The sacrifice of Jesus on the cross paid the penalty for people's sins so that they can have eternal life through faith in him.
* The word for "book" can also mean "scroll" or "letter" or "writing" or "legal document." It may be literal or figurative.

(See also: [everlasting](kt.html#eternity), [lamb](kt.html#lamb), [life](kt.html#life), [sacrifice](#sacrifice), [scroll](#scroll))

#### Bible References: ####

* [Philippians 04:1-3](https://git.door43.org/Door43/en_tn/src/master/php/04/01.md)
* [Psalms 069:28-29](https://git.door43.org/Door43/en_tn/src/master/psa/069/028.md)
* [Revelation 03:5-6](https://git.door43.org/Door43/en_tn/src/master/rev/03/05.md)
* [Revelation 20:11-12](https://git.door43.org/Door43/en_tn/src/master/rev/20/11.md)

#### Word Data:####

* Strong's: H2416, H5612, G976, G2222


---

<a id="bow"/>

### bow, bows, bowed, bowing, bow down, bows down, bowed down, bowing down ###

#### Definition: ####

To bow means to bend over to humbly express respect and honor toward someone. To "bow down" means to bend over or kneel down very low, often with face and hands toward the ground.

* Other expressions include "bow the knee" (meaning to kneel) and "bow the head" (meaning to bend the head forward in humble respect or in sorrow).
* Bowing down can also be a sign of distress or mourning. Someone who is "bowed down" has been brought to a low position of humility.
* Often a person will bow in the presence of someone who is of higher status or greater importance, such as kings and other rulers.
* Bowing down before God is an expression of worship to him.
* In the Bible, people bowed down to Jesus when they realized from his miracles and teaching that he had come from God.
* The Bible says that when Jesus comes back someday, everyone will bow the knee to worship him.

#### Translation Suggestions: ####

* Depending on the context, this term could be translated with a word or phrase that means "bend forward" or "bend the head" or "kneel."
* The term "bow down" could be translated as "kneel down" or "prostrate oneself."
* Some languages will have more than one way of translating this term, depending on the context.

(See also: [humble](kt.html#humble), [worship](kt.html#worship))

#### Bible References: ####

* [2 Kings 05:17-19](https://git.door43.org/Door43/en_tn/src/master/2ki/05/17.md)
* [Exodus 20:4-6](https://git.door43.org/Door43/en_tn/src/master/exo/20/04.md)
* [Genesis 24:26-27](https://git.door43.org/Door43/en_tn/src/master/gen/24/26.md)
* [Genesis 44:14-15](https://git.door43.org/Door43/en_tn/src/master/gen/44/14.md)
* [Isaiah 44:19](https://git.door43.org/Door43/en_tn/src/master/isa/44/19.md)
* [Luke 24:4-5](https://git.door43.org/Door43/en_tn/src/master/luk/24/04.md)
* [Matthew 02:11-12](https://git.door43.org/Door43/en_tn/src/master/mat/02/11.md)
* [Revelation 03:9-11](https://git.door43.org/Door43/en_tn/src/master/rev/03/09.md)

#### Word Data: ####

* Strong's: H86, H3721, H3766, H5186, H5753, H5791, H6915, H7743, H7812, H7817, G1120, G2578, G2827, G4781, G4794


---

<a id="bowweapon"/>

### bow and arrow, bows and arrows ###

#### Definition: ####

This is a type of weapon that consists of shooting arrows from a stringed bow. In Bible times it was used for fighting against enemies and for killing animals for food.

* The bow is made out of wood, bone, metal, or other hard material, such as a deer's antler. It has a curved shape and is strung tightly with a string, cord, or vine.
* An arrow is a thin shaft with a sharp, pointed head on one end. In ancient times, the arrows could be made of a variety of materials such as wood, bone, stone, or metal.
* Bows and arrows are commonly used by hunters and warriors.
* The term "arrow" is also sometimes used figuratively in the Bible to refer to enemy attacks or divine judgment.

#### Bible References: ####

* [Genesis 21:14-16](https://git.door43.org/Door43/en_tn/src/master/gen/21/14.md)
* [Habakkuk 03:9-10](https://git.door43.org/Door43/en_tn/src/master/hab/03/09.md)
* [Job 29:20-22](https://git.door43.org/Door43/en_tn/src/master/job/29/20.md)
* [Lamentations 02:3-4](https://git.door43.org/Door43/en_tn/src/master/lam/02/03.md)
* [Psalms 058:6-8](https://git.door43.org/Door43/en_tn/src/master/psa/058/006.md)

#### Word Data:####

* Strong's: H2671, H7198, G5115


---

<a id="bread"/>

### bread ###

#### Definition: ####

Bread is a food made from flour mixed with water and oil to form a dough. The dough is then shaped into a loaf and baked.

* When the term "loaf" occurs by itself, it means "loaf of bread."
* Bread dough is usually made with something that makes it rise, such as yeast.
* Bread can also be made without yeast so that it does not rise. In the Bible this is called "unleavened bread" and was used for the Jews' passover meal.
* Since bread was the main food for many people in biblical times, this term is also used in the Bible to refer to food in general. (See: [Synecdoche](https://git.door43.org/Door43/en_ta/src/master/translate/figs-synecdoche.md))
* The term "bread of the presence" referred to twelve loaves of bread that were placed on a golden table in the tabernacle or temple building as a sacrifice to God. These loaves represented the twelve tribes of Israel and were only for the priests to eat. This could be translated as "bread showing that God lived among them." 
* The figurative term "bread from heaven" referred to the special white food called "manna" that God provided for the Israelites when they were wandering through the desert.
* Jesus also called himself the "bread that came down from heaven" and the "bread of life."
* When Jesus and his disciples were eating the Passover meal together before his death, he compared the unleavened Passover bread to his body which would be wounded and killed on a cross.
* Many times the term "bread" can be translated more generally as "food."

(See also: [Passover](kt.html#passover), [tabernacle](kt.html#tabernacle), [temple](kt.html#temple), [unleavened bread](kt.html#unleavenedbread), [yeast](#yeast)) 

#### Bible References: ####

* [Acts 02:46-47](https://git.door43.org/Door43/en_tn/src/master/act/02/46.md)
* [Acts 27:33-35](https://git.door43.org/Door43/en_tn/src/master/act/27/33.md)
* [Exodus 16:13-15](https://git.door43.org/Door43/en_tn/src/master/exo/16/13.md)
* [Luke 09:12-14](https://git.door43.org/Door43/en_tn/src/master/luk/09/12.md)
* [Mark 06:37-38](https://git.door43.org/Door43/en_tn/src/master/mrk/06/37.md)
* [Matthew 04:1-4](https://git.door43.org/Door43/en_tn/src/master/mat/04/01.md)
* [Matthew 11:18-19](https://git.door43.org/Door43/en_tn/src/master/mat/11/18.md)

#### Word Data:####

* Strong's: H2557, H3899, H4635, H4682, G106, G740, G4286


---

<a id="breastplate"/>

### breastplate, breastplates, breastpiece ###

#### Definition: ####

The term "breastplate" refers to a piece of armor covering the front of the chest to protect a soldier during battle. The term "breastpiece" refers to a special piece of clothing that the Israelite high priest wore over the front part of his chest.

* A "breastplate" used by a soldier could be made of wood, metal, or animal skin. It was made to prevent arrows, spears, or swords from piercing the chest of the soldier.
* The "breastpiece" worn by the Israelite high priest was made of cloth and had valuable gems attached to it. The priest wore this when he was performing his duties of service to God in the temple.
* Other ways to translate the term "breastplate" could include "metal protective chest covering" or "armor piece protecting the chest."
* The term "breastpiece" could be translated with a word that means "priestly clothing covering the chest" or "priestly garment piece" or "front piece of priest's clothing."

(See also: [armor](#armor), [high priest](kt.html#highpriest), [pierce](#pierce), [priest](kt.html#priest), [temple](kt.html#temple), [warrior](#warrior))

#### Bible References: ####

* [1 Thessalonians 05:8-11](https://git.door43.org/Door43/en_tn/src/master/1th/05/08.md)
* [Exodus 39:14-16](https://git.door43.org/Door43/en_tn/src/master/exo/39/14.md)
* [Isaiah 59:17-18](https://git.door43.org/Door43/en_tn/src/master/isa/59/17.md)
* [Revelation 09:7-9](https://git.door43.org/Door43/en_tn/src/master/rev/09/07.md)

#### Word Data:####

* Strong's: H2833 , H8302, G2382


---

<a id="breath"/>

### breath, breathe, breathes, breathed, breathing ###

#### Definition: ####

In the Bible, the terms "breathe" and "breath" are often used figuratively to refer to giving life or having life. 

* The Bible teaches that God "breathed into" Adam the breath of life. It was at that point that Adam became a living soul.
* When Jesus breathed on the disciples and told them to "receive the Spirit," he was probably literally breathing out air onto them to symbolize the Holy Spirit coming to them.
* Sometimes the terms "breathing" and "breathing out" are used to refer to speaking.
* The figurative expression "breath of God" or "breath of Yahweh" often refers to God's wrath being poured out on rebellious or godless nations. It communicates his power.

#### Translation Suggestions ####

* The expression "breathed his last" is a figurative way of saying "he died." It could also be translated as "he took his last breath" or "he stopped breathing and died" or "he breathed in air one last time."
* Describing the Scriptures as "God-breathed" means that God spoke or inspired the words of the Scriptures which human authors then wrote down. It is probably best, if possible, to translate "God-breathed" somewhat literally since it is difficult to communicate the exact meaning of this.
* If a literal translation of "God-breathed" is not acceptable, other ways to translate this could include "inspired by God" or "authored by God" or "spoken by God." It could also be said that "God breathed out the words of Scripture."
* The expressions "put breath in" or "breathe life into" or "gives breath to" could be translated as "cause to breathe" or "make alive again" or "enable them to live and breathe" or "give life to."
* If possible, it is best to translate "breath of God" with the literal word that is used for "breath" in the language. If God cannot be said to have "breath," this could be translated as "God's power" or "God's speech."
* The expression "catch my breath" or "get my breath" could be translated as "relax in order to breathe more slowly" or "stop running in order to breathe normally."
* The expression "is only a breath" means "lasts a very short time."
* Similarly the expression "man is a single breath" means "people live a very short time" or "the lives of human beings are very short, like a single breath" or "compared to God, the life of a person seems as short as the time it takes to breathe in one breath of air."

(See also: [Adam](names.html#adam), [Paul](names.html#paul), [word of God](kt.html#wordofgod), [life](kt.html#life))

#### Bible References: ####

* [1 Kings 17:17-18](https://git.door43.org/Door43/en_tn/src/master/1ki/17/17.md)
* [Ecclesiastes 08:8-9](https://git.door43.org/Door43/en_tn/src/master/ecc/08/08.md)
* [Job 04:7-9](https://git.door43.org/Door43/en_tn/src/master/job/04/07.md)
* [Revelation 11:10-12](https://git.door43.org/Door43/en_tn/src/master/rev/11/10.md)
* [Revelation 13:15-17](https://git.door43.org/Door43/en_tn/src/master/rev/13/15.md)

#### Word Data: ####

* Strong's: H3307, H5301, H5396, H5397, H7307, H7309, G1709, G1720, G4157


---

<a id="bribe"/>

### bribe, bribes, bribed, bribery ###

#### Definition: ####

To "bribe" means to give someone something of value, such as money, to influence that person to do something dishonest.

* The soldiers who guarded Jesus' empty tomb were bribed with money to lie about what happened.
* Sometimes a government official will be bribed to overlook a crime or to vote a certain way.
* The Bible forbids giving or taking bribes.
* The term, "bribe" could be translated as, "dishonest payment" or "payment for lying" or "price for breaking the rules."
* To "bribe" could be translated with a word or phrase that means, to "pay to influence (someone)" or to "pay to have a dishonest favor done" or to "pay for a favor."

#### Bible References: ####

* [1 Samuel 08:1-3](https://git.door43.org/Door43/en_tn/src/master/1sa/08/01.md)
* [Ecclesiastes 07:7](https://git.door43.org/Door43/en_tn/src/master/ecc/07/07.md)
* [Isaiah 01:23](https://git.door43.org/Door43/en_tn/src/master/isa/01/23.md)
* [Micah 03:9-11](https://git.door43.org/Door43/en_tn/src/master/mic/03/09.md)
* [Proverbs 15:27-28](https://git.door43.org/Door43/en_tn/src/master/pro/15/27.md)

#### Word Data:####

* Strong's: H3724, H4979, H7809, H7810, H7936, H7966, H8641, G5260


---

<a id="bride"/>

### bride, brides, bridal ###

#### Definition: ####

A bride is the woman in a wedding ceremony who is getting married to her husband, the bridegroom.

* The term "bride" is used as a metaphor for believers in Jesus, the Church.
* Jesus is metaphorically called the "bridegroom" for the Church. (See: [Metaphor](https://git.door43.org/Door43/en_ta/src/master/translate/figs-metaphor.md))

(See also: [bridegroom](#bridegroom), [church](kt.html#church))

#### Bible References: ####

* [Exodus 22:16-17](https://git.door43.org/Door43/en_tn/src/master/exo/22/16.md)
* [Isaiah 62:5](https://git.door43.org/Door43/en_tn/src/master/isa/62/05.md)
* [Joel 02:15-16](https://git.door43.org/Door43/en_tn/src/master/jol/02/15.md)

#### Word Data:####

* Strong's: H3618, G3565


---

<a id="bridegroom"/>

### bridegroom, bridegrooms ###

#### Definition: ####

In a marriage ceremony, the bridegroom is the man who will marry the bride.

* In the Jewish culture during Bible times, the ceremony was centered around the bridegroom coming to get his bride.
* In the Bible, Jesus is figuratively called the "Bridegroom" who will someday come for his "Bride," the Church.
* Jesus compared his disciples to the friends of the bridegroom who celebrate while the bridegroom is with them, but who will be sad when he is gone.

(See also: [bride](#bride))

#### Bible References: ####

* [Isaiah 62:5](https://git.door43.org/Door43/en_tn/src/master/isa/62/05.md)
* [Joel 02:15-16](https://git.door43.org/Door43/en_tn/src/master/jol/02/15.md)
* [John 03:29-30](https://git.door43.org/Door43/en_tn/src/master/jhn/03/29.md)
* [Luke 05:33-35](https://git.door43.org/Door43/en_tn/src/master/luk/05/33.md)
* [Mark 02:18-19](https://git.door43.org/Door43/en_tn/src/master/mrk/02/18.md)
* [Mark 02:20-21](https://git.door43.org/Door43/en_tn/src/master/mrk/02/20.md)
* [Matthew 09:14-15](https://git.door43.org/Door43/en_tn/src/master/mat/09/14.md)

#### Word Data:####

* Strong's: H2860, G3566


---

<a id="bronze"/>

### bronze ###

#### Definition: ####

The term "bronze" refers to a kind of metal that is made from melting together the metals, copper and tin. It has a dark brown color, slightly red.

* Bronze resists water corrosion and is a good conductor of heat.
* In ancient times, bronze was used for making tools, weapons, artwork, altars, cooking pots, and soldiers' armor, among other things.
* Many building materials for the tabernacle and temple were made of bronze.
* Idols of false gods were also often made of bronze metal.
* Bronze objects were made by first melting the bronze metal into a liquid and then pouring it into molds. This process was called "casting."

(See also: [How to Translate Unknowns](https://git.door43.org/Door43/en_ta/src/master/translate/translate-unknown.md))

(See also: [armor](#armor), [tabernacle](kt.html#tabernacle), [temple](kt.html#temple))

#### Bible References: ####

* [1 Kings 07:15-17](https://git.door43.org/Door43/en_tn/src/master/1ki/07/15.md)
* [1 Samuel 17:37-38](https://git.door43.org/Door43/en_tn/src/master/1sa/17/37.md)
* [Daniel 02:44-45](https://git.door43.org/Door43/en_tn/src/master/dan/02/44.md)
* [Exodus 25:3-7](https://git.door43.org/Door43/en_tn/src/master/exo/25/03.md)
* [Revelation 01:14-16](https://git.door43.org/Door43/en_tn/src/master/rev/01/14.md)

#### Word Data:####

* Strong's: H5153, H5154, H5174, H5178, G5470, G5474, G5475


---

<a id="burden"/>

### burden, burdens, burdened, burdensome ###

#### Definition: ####

A burden is a heavy load. It literally refers to a physical load such as a work animal would carry. The term "burden" also has several figurative meanings:

* A burden can refer to a difficult duty or important responsibility that a person has to do. He is said to be "bearing" or "carrying" a "heavy burden."
* A cruel leader may put difficult burdens on the people he is ruling, for example by forcing them to pay large amounts of taxes.
* A person who does not want to be a burden to someone does not want to cause that other person any trouble.
* The guilt of a person's sin is a burden to him.
* The "burden of the Lord" is a figurative way of referring to a "message from God" that a prophet must deliver to God's people.
* The term "burden" can be translated by "responsibility" or "duty" or "heavy load" or "message," depending on the context.

#### Bible References: ####

* [2 Thessalonians 03:6-9](https://git.door43.org/Door43/en_tn/src/master/2th/03/06.md)
* [Galatians 06:1-2](https://git.door43.org/Door43/en_tn/src/master/gal/06/01.md)
* [Galatians 06:3-5](https://git.door43.org/Door43/en_tn/src/master/gal/06/03.md)
* [Genesis 49:14-15](https://git.door43.org/Door43/en_tn/src/master/gen/49/14.md)
* [Matthew 11:28-30](https://git.door43.org/Door43/en_tn/src/master/mat/11/28.md)
* [Matthew 23:4-5](https://git.door43.org/Door43/en_tn/src/master/mat/23/04.md)

#### Word Data:####

* Strong's: H92, H3053, H4614, H4853, H4858, H4864, H4942, H5445, H5447, H5448, H5449, H5450, H6006, G4, G916, G922, G1117, G2347, G2599, G2655, G5413


---

<a id="burntoffering"/>

### burnt offering, burnt offerings, offering by fire ###

#### Definition: ####

A "burnt offering" was a type of sacrifice to God that was burnt up by fire on an altar. It was offered to make atonement for the sins of the people. This was also called an "offering by fire."

* Animals used for this offering were usually sheep or goats, but oxen and birds were also used.
* Except for the skin, the entire animal was burned up in this offering. The skin or hide was given to the priest.
* God commanded the Jewish people to offer burnt offerings two times every day.

(See also: [altar](kt.html#altar), [atonement](kt.html#atonement), [ox](#ox), [priest](kt.html#priest), [sacrifice](#sacrifice))

#### Bible References: ####

* [Exodus 40:5-7](https://git.door43.org/Door43/en_tn/src/master/exo/40/05.md)
* [Genesis 08:20-22](https://git.door43.org/Door43/en_tn/src/master/gen/08/20.md)
* [Genesis 22:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/22/01.md)
* [Leviticus 03:3-5](https://git.door43.org/Door43/en_tn/src/master/lev/03/03.md)
* [Mark 12:32-34](https://git.door43.org/Door43/en_tn/src/master/mrk/12/32.md)

#### Word Data:####

* Strong's: H801, H5930, H7133, H8548, G3646


---

<a id="bury"/>

### bury, buries, buried, burying, burial ###

#### Definition: ####

The term "bury" usually refers to putting a dead body into a hole or other burial place. The term "burial" is the act of burying something or can be used to describe a place used to bury something.

* Often people bury a dead body by placing it into a deep hole in the ground and then covering it with dirt.
* Sometimes the dead body is placed in a box-like structure, such as a coffin, before burying it.
* In Bible times, dead people were often buried in a cave or similar place. After Jesus died, his body was wrapped in cloths and placed in a stone tomb that was sealed with a large boulder.
* The terms "burial place" or "burial room" or "burial chamber" or "burial cave" are all ways to refer to a place where a dead body is buried.
* Other things can also be buried, such as when Achan buried silver and other things that he had stolen from Jericho.
* The phrase "buried his face" usually means "covered his face with his hands."
* Sometimes the word "hide" can mean "bury" as when Achan hid things in the ground that he had stolen from Jericho. This meant he buried them in the ground.

(See also:[Jericho](names.html#jericho), [tomb](#tomb))

#### Bible References: ####

* [2 Kings 09:9-10](https://git.door43.org/Door43/en_tn/src/master/2ki/09/09.md)
* [Genesis 35:4-5](https://git.door43.org/Door43/en_tn/src/master/gen/35/04.md)
* [Jeremiah 25:32-33](https://git.door43.org/Door43/en_tn/src/master/jer/25/32.md)
* [Luke 16:22-23](https://git.door43.org/Door43/en_tn/src/master/luk/16/22.md)
* [Matthew 27:6-8](https://git.door43.org/Door43/en_tn/src/master/mat/27/06.md)
* [Psalm 079:1-3](https://git.door43.org/Door43/en_tn/src/master/psa/079/001.md)

#### Word Data:####

* Strong's: H6900, H6912, H6913, G1779, G1780, G2290, G4916, G5027


---

<a id="camel"/>

### camel, camels ###

#### Definition: ####

A camel is a large, four legged animal with one or two humps on its back.
(See also: [How to Translate Unknowns](https://git.door43.org/Door43/en_ta/src/master/translate/translate-unknown.md))

* In Bible times, the camel was the largest animal found in Israel and the surrounding regions.
* The camel was used mainly for carrying people and burdens.
* Some people groups also used camels for food but not the Israelites because God said that camels were unclean and were not to be eaten.
* Camels were valuable because they could move swiftly in the sand and could live without food and water for several weeks at a time.

(See also: [burden](#burden), [clean](kt.html#clean))

#### Bible References: ####

* [1 Chronicles 05:20-22](https://git.door43.org/Door43/en_tn/src/master/1ch/05/20.md)
* [2 Chronicles 09:1-2](https://git.door43.org/Door43/en_tn/src/master/2ch/09/01.md)
* [Exodus 09:1-4](https://git.door43.org/Door43/en_tn/src/master/exo/09/01.md)
* [Mark 10:23-25](https://git.door43.org/Door43/en_tn/src/master/mrk/10/23.md)
* [Matthew 03:4-6](https://git.door43.org/Door43/en_tn/src/master/mat/03/04.md)
* [Matthew 19:23-24](https://git.door43.org/Door43/en_tn/src/master/mat/19/23.md)

#### Word Data:####

* Strong's: H327, H1581, G2574


---

<a id="captive"/>

### captive, captives, captivate, captivated, captivity ###

#### Definition: ####

The terms "captive" and "captivity" refer to capturing people and forcing them to live somewhere they do not want to live, such as in a foreign country.

* The Israelites from the kingdom of Judah were held captive in the kingdom of Babylonia for 70 years.
* Captives are often required to work for the people or nation that captured them.
* Daniel and Nehemiah were Israelite captives who worked for the Babylonian king.
* The expression to "take captive" is another way of talking about capturing someone.
* The expression, "carry you away captive" could also be translated as, "force you to live as captives" or "take you away to another country as prisoners." 
* In a figurative sense, the apostle Paul tells Christians to "take captive" every thought and make it obedient to Christ.
* He also talks about how a person can be "taken captive" by sin, which means he is "controlled by" sin.

#### Translation Suggestions ###

* Depending on the context, to be "held captive" could also be translated by, "not allowed to be free" or "kept in prison" or "forced to live in a foreign country."
* The expression, "led captive" or "taken captive" could be translated as, "captured" or "imprisoned" or "forced to go to a foreign land."
* The term "captives" could also be translated as, "people who were captured" or "enslaved people."
* Depending on the context, "captivity" could also be translated as, "imprisonment" or "exile" or "forced stay in a foreign country."

(See also: [Babylon](names.html#babylon), [exile](#exile), [prison](#prison), [seize](#seize))

#### Bible References: ####

* [2 Corinthians 10:5-6](https://git.door43.org/Door43/en_tn/src/master/2co/10/05.md)
* [Isaiah 20:3-4](https://git.door43.org/Door43/en_tn/src/master/isa/20/03.md)
* [Jeremiah 43:1-3](https://git.door43.org/Door43/en_tn/src/master/jer/43/01.md)
* [Luke 04:18-19](https://git.door43.org/Door43/en_tn/src/master/luk/04/18.md)

#### Word Data:####

* Strong's: H1123, H1473, H1540, H1546, H1547, H2925, H6808, H7617, H7622, H7628, H7633, H7686, H7870, G161, G162, G163, G164, G2221


---

<a id="castout"/>

### cast out, casting out, driving out, throw out, throwing out ###

#### Definition: ####

To "cast out" or "drive out" someone or something means to force that person or thing to go away.

* The term "cast" means the same thing as "throw." To cast a net means to throw the net into the water.
* In a figurative sense, "cast out" or "cast away" someone can mean to reject that person and send him away.

#### Translation Suggestions: ####

* Depending on the context, other ways to translate this could include, "force out" or "send away" or "get rid of."
* To "cast out demons" could be translated as "cause the demons to leave" or "drive the evil spirits out" or "expel the demons" or "command the demon to come out."

(See also: [demon](kt.html#demon), [demon-possessed](kt.html#demonpossessed), [lots](#lots))

#### Bible References: ####

* [Acts 07:17-19](https://git.door43.org/Door43/en_tn/src/master/act/07/17.md)
* [Mark 03:13-16](https://git.door43.org/Door43/en_tn/src/master/mrk/03/13.md)
* [Mark 09:28-29](https://git.door43.org/Door43/en_tn/src/master/mrk/09/28.md)
* [Matthew 07:21-23](https://git.door43.org/Door43/en_tn/src/master/mat/07/21.md)
* [Matthew 09:32-34](https://git.door43.org/Door43/en_tn/src/master/mat/09/32.md)
* [Matthew 12:24-25](https://git.door43.org/Door43/en_tn/src/master/mat/12/24.md)
* [Matthew 17:19-21](https://git.door43.org/Door43/en_tn/src/master/mat/17/19.md)

#### Word Data:####

* Strong's: H1272, H1644, H1920, H3423, H7971, H7993, G1544


---

<a id="caughtup"/>

### caught up, caught up with, catch up with ###

#### Definition: ####

The term "caught up" often refers to God taking a person up to heaven in a sudden, miraculous way.

* The phrase "caught up with" refers to coming up to someone after hurrying to reach him. A term with a similar meaning is "overtake."
* The apostle Paul talked about being "caught up" to the third heaven. This could also be translated as "taken up."
* Paul said that when Christ comes back, Christians will be "caught up" together to meet him in the air.
* The figurative expression, "my sins have caught up with me" could be translated as, "I am receiving the consequences of my sin" or "because of my sin I am suffering" or "my sin is causing me trouble."

(see: [miracle](kt.html#miracle), [overtake](#overtake), [suffer](#suffer), [trouble](#trouble))

#### Bible References: ####

* [2 Corinthians 12:1-2](https://git.door43.org/Door43/en_tn/src/master/2co/12/01.md)
* [Acts 08:39-40](https://git.door43.org/Door43/en_tn/src/master/act/08/39.md)

#### Word Data:####

* Strong's: H1692, G726


---

<a id="cedar"/>

### cedar, cedars, cedarwood ###

#### Definition: ####

The term "cedar" refers to a large fir tree which normally has reddish-brown wood. Like other firs, it has cones and needle-like leaves.

* The Old Testament often mentions cedar trees in connection with Lebanon, where they grew plentifully.
* Cedar wood was used in the construction of the Jerusalem temple.
* It was also used for sacrifices and purification offerings.

(See also: [fir](#fir), [pure](kt.html#purify), [sacrifice](#sacrifice), [temple](kt.html#temple))

#### Bible References: ####

* [1 Chronicles 14:1-2](https://git.door43.org/Door43/en_tn/src/master/1ch/14/01.md)
* [1 Kings 07:1-2](https://git.door43.org/Door43/en_tn/src/master/1ki/07/01.md)
* [Isaiah 02:12-13](https://git.door43.org/Door43/en_tn/src/master/isa/02/12.md)
* [Zechariah 11:1-3](https://git.door43.org/Door43/en_tn/src/master/zec/11/01.md)

#### Word Data:####

* Strong's: H730


---

<a id="census"/>

### census ###

#### Definition: ####

The term "census" refers to a formal counting of the number of people in a nation or empire.

* The Old Testament records different times when God ordered that the men of Israel be counted, such as when the Israelites first left Egypt and then again just before they entered Canaan.
* Often the purpose of a census was in order to know how many people should be paying taxes.
* For example, one time in Exodus the Israelite men were counted so that each one would pay a half shekel for taking care of the temple.
* When Jesus was a baby, the Roman government did a census to count all the people who lived throughout their empire, to require them to pay taxes.

#### Translation Suggestions ####

* Possible ways to translate this term could include, "name counting" or "list of names" or "enrollment."
* The phrase "take a census" could be translated as "register people's names" or "enroll people" or "write down people's names."

(See also: [nation](#nation), [Rome](names.html#rome))

#### Bible References: ####

* [Acts 05:35-37](https://git.door43.org/Door43/en_tn/src/master/act/05/35.md)
* [Exodus 30:11-14](https://git.door43.org/Door43/en_tn/src/master/exo/30/11.md)
* [Exodus 38:24-26](https://git.door43.org/Door43/en_tn/src/master/exo/38/24.md)
* [Luke 02:1-3](https://git.door43.org/Door43/en_tn/src/master/luk/02/01.md)
* [Numbers 04:1-4](https://git.door43.org/Door43/en_tn/src/master/num/04/01.md)

#### Word Data:####

* Strong's: H3789, H5674, H5921, H6485, H7218, G582, G583


---

<a id="chaff"/>

### chaff ###

#### Definition: ####

Chaff is a dry protective covering of a grain seed. The chaff is not good for food so people separate it from the seed and throw it away.

* Often, the chaff is separated from the seed by throwing the heads of grain up into the air. The wind blows the chaff away and the seed falls on the ground. This process is called "winnowing."
* In the Bible, this term is also used figuratively to refer to evil people and evil, worthless things.

(See also: [grain](#grain), [wheat](#wheat), [winnow](#winnow))

#### Bible References: ####

* [Daniel 02:34-35](https://git.door43.org/Door43/en_tn/src/master/dan/02/34.md)
* [Job 21:16-18](https://git.door43.org/Door43/en_tn/src/master/job/21/16.md)
* [Luke 03:17](https://git.door43.org/Door43/en_tn/src/master/luk/03/17.md)
* [Matthew 03:10-12](https://git.door43.org/Door43/en_tn/src/master/mat/03/10.md)

#### Word Data:####

* Strong's: H2842, H4671, H5784, H8401, G892


---

<a id="chariot"/>

### chariot, chariots, charioteers ###

#### Definition: ####

In ancient times, chariots were lightweight, two-wheeled carts that were pulled by horses.

* People would sit or stand in chariots, using them for war or travel.
* In war, an army that had chariots had a great advantage of speed and mobility over an army that did not have chariots.
* The ancient Egyptians and Romans were well-known for their use of horses and chariots.

(See also: [How to Translate Unknowns](https://git.door43.org/Door43/en_ta/src/master/translate/translate-unknown.md))

(See also: [Egypt](names.html#egypt), [Rome](names.html#rome)) 

#### Bible References: ####

* [1 Kings 09:22](https://git.door43.org/Door43/en_tn/src/master/1ki/09/22.md)
* [2 Chronicles 18:28-30](https://git.door43.org/Door43/en_tn/src/master/2ch/18/28.md)
* [Acts 08:29-31](https://git.door43.org/Door43/en_tn/src/master/act/08/29.md)
* [Acts 08:36-38](https://git.door43.org/Door43/en_tn/src/master/act/08/36.md)
* [Daniel 11:40-41](https://git.door43.org/Door43/en_tn/src/master/dan/11/40.md)
* [Exodus 14:23-25](https://git.door43.org/Door43/en_tn/src/master/exo/14/23.md)
* [Genesis 41:42-43](https://git.door43.org/Door43/en_tn/src/master/gen/41/42.md)

#### Examples from the Bible stories: ####

  __*[12:10](https://git.door43.org/Door43/en_tn/src/master/obs/12/10.md)__ So they followed the Israelites onto the path through the sea, but God caused the Egyptians to panic and caused their __chariots__ to get stuck.

#### Word Data:####

* Strong's: H668, H2021, H4817, H4818, H5699, H7393, H7395, H7396, H7398, G716, G4480


---

<a id="cherubim"/>

### cherub, cherubim, cherubs ###

#### Definition: ####

The term "cherub," and its plural form "cherubim," refer to a special type of heavenly being that God created. The Bible describes cherubim as having wings and flames. 

* The cherubim display the glory and power of God and seem to be guardians of sacred things.
* After Adam and Eve sinned, God placed cherubim with flaming swords at the east side of the Garden of Eden so that people could no longer get to the tree of life.
* God commanded the Israelites to carve two cherubim facing each other, with their wings touching, over the atonement lid of the ark of the covenant.
* He also told them to weave pictures of the cherubim into the curtains of the tabernacle.
* In some passages, these creatures are also described as having four faces: of a man, a lion, an ox, and an eagle.
* Cherubim are sometimes thought of as being angels, but the Bible does not clearly state that. 

#### Translation Suggestions: ####

* The term "cherubim" could be translated as "creatures with wings" or "guardians with wings" or "winged spiritual guardians" or "holy, winged guardians."
* A "cherub" should be translated as the singular of cherubim, as in, "creature with wings" or "winged spiritual guardian," for example.
* Make sure that the translation of this term is different from the translation of "angel."
* Also consider how this term is translated or written in a Bible translation in a local or national language. (See: [How to Translate Unknowns](https://git.door43.org/Door43/en_ta/src/master/translate/translate-unknown.md))

(See also: [angel](kt.html#angel))

#### Bible References: ####

* [1 Chronicles 13:5-6](https://git.door43.org/Door43/en_tn/src/master/1ch/13/05.md)
* [1 Kings 06:23-26](https://git.door43.org/Door43/en_tn/src/master/1ki/06/23.md)
* [Exodus 25:15-18](https://git.door43.org/Door43/en_tn/src/master/exo/25/15.md)
* [Ezekiel 09:3-4](https://git.door43.org/Door43/en_tn/src/master/ezk/09/03.md)
* [Genesis 03:22-24](https://git.door43.org/Door43/en_tn/src/master/gen/03/22.md)

#### Word Data:####

* Strong's: H3742, G5502


---

<a id="chief"/>

### chief, chiefs ###

#### Definition: ####

The term "chief" refers to the most powerful or most important leader of a particular group.

* Examples of this include, "chief musician," "chief priest," and "chief tax collector." and "chief ruler."
* It can also be used for the head of a specific family, as in Genesis 36 where certain men are named as "chiefs" of their family clans. In this context, the term "chief" could also be translated as "leader" or "head father."
* When used to describe a noun, this term could be translated as "leading" or "ruling," as in "leading musician" or "ruling priest."

(See also: [chief priests](#chiefpriests), [priest](kt.html#priest), [tax collector](#taxcollector))

#### Bible References: ####

* [Daniel 01:11-13](https://git.door43.org/Door43/en_tn/src/master/dan/01/11.md)
* [Ezekiel 26:15-16](https://git.door43.org/Door43/en_tn/src/master/ezk/26/15.md)
* [Luke 19:1-2](https://git.door43.org/Door43/en_tn/src/master/luk/19/01.md)
* [Psalm 004:1](https://git.door43.org/Door43/en_tn/src/master/psa/004/001.md)

#### Word Data:####

* Strong's: H47, H441, H5057, H5387, H5632, H6496, H7218, H7225, H7227, H7229, H7262, H8269, H8334, G749, G750, G754, G4410, G4413, G5506


---

<a id="chiefpriests"/>

### chief priests ###

#### Definition: ####

The chief priests were important Jewish religious leaders during the time that Jesus lived on earth.

* The chief priests were responsible for everything needed for the worship services at the temple. They were also in charge of the money that was given to the temple.
* They were higher in rank and power than the ordinary priests. Only the high priest had more authority.
* The chief priests were some of Jesus' main enemies and they strongly influenced the Roman leaders to arrest and kill him.

#### Translation Suggestions: ####

* The term "chief priests" could also be translated as "head priests" or "leading priests" or "ruling priests."
* Make sure this term is translated differently from the term "high priest."

(See also: [chief](#chief), [high priest](kt.html#highpriest), [Jewish leaders](#jewishleaders), [priest](kt.html#priest))

#### Bible References: ####

* [Acts 09:13-16](https://git.door43.org/Door43/en_tn/src/master/act/09/13.md)
* [Acts 22:30](https://git.door43.org/Door43/en_tn/src/master/act/22/30.md)
* [Acts 26:12-14](https://git.door43.org/Door43/en_tn/src/master/act/26/12.md)
* [Luke 20:1-2](https://git.door43.org/Door43/en_tn/src/master/luk/20/01.md)
* [Mark 08:31-32](https://git.door43.org/Door43/en_tn/src/master/mrk/08/31.md)
* [Matthew 16:21-23](https://git.door43.org/Door43/en_tn/src/master/mat/16/21.md)
* [Matthew 26:3-5](https://git.door43.org/Door43/en_tn/src/master/mat/26/03.md)
* [Matthew 26:59-61](https://git.door43.org/Door43/en_tn/src/master/mat/26/59.md)
* [Matthew 27:41-42](https://git.door43.org/Door43/en_tn/src/master/mat/27/41.md)

#### Word Data:####

* Strong's: H3548, H7218, G749


---

<a id="chronicles"/>

### chronicles ###

#### Definition: ####

The term "chronicle" refers to a written record of events over a period of time.

* Two Old Testament books are called "First Book of the Chronicles" and "Second Book of the Chronicles."
* The books called "Chronicles" record part of the history of the Israelite people, beginning with a list of people in every generation since Adam.
* The "First Book of the Chronicles" records the end of King Saul's life and the events of King David's reign.
* The "Second Book of the Chronicles" records the reigns of King Solomon and several other kings, including the building of the temple and the separation of the northern kingdom of Israel from the southern kingdom of Judah.
* The end of 2 Chronicles describes the beginning of the Babylonian exile.

(See also: [Babylon](names.html#babylon), [David](names.html#david), [exile](#exile), [kingdom of Israel](names.html#kingdomofisrael), [Judah](names.html#kingdomofjudah), [Solomon](names.html#solomon))

#### Bible References: ####

* [1 Chronicles 27:23-24](https://git.door43.org/Door43/en_tn/src/master/1ch/27/23.md)
* [2 Chronicles 33:18-20](https://git.door43.org/Door43/en_tn/src/master/2ch/33/18.md)
* [Esther 10:1-2](https://git.door43.org/Door43/en_tn/src/master/est/10/01.md)

#### Word Data:####

* Strong's: H1697


---

<a id="citizen"/>

### citizen, citizens, citizenship ###

#### Definition: ####

A citizen is someone who lives in a specific city, country, or kingdom. It especially refers to someone who is recognized officially as being a legal resident of that place.

* Depending on the context, this could also be translated as "inhabitant" or "official resident."
* A citizen could live in a region that is part of a larger kingdom or empire that is governed by a king, emperor, or other ruler. For example, Paul was a citizen of the Roman Empire, which consisted of many different provinces; Paul lived in one of those provinces.
* In a figurative sense, believers in Jesus are called "citizens" of heaven in the sense that they will live there someday. Like a citizen of a country, Christians belong to God's kingdom.

( See: [kingdom](#kingdom), [Paul](names.html#paul), [province](#province), [Rome](names.html#rome))

#### Bible References: ####

* [Acts 21:39-40](https://git.door43.org/Door43/en_tn/src/master/act/21/39.md)
* [Isaiah 03:1-3](https://git.door43.org/Door43/en_tn/src/master/isa/03/01.md)
* [Luke 15:15-16](https://git.door43.org/Door43/en_tn/src/master/luk/15/15.md)
* [Luke 19:13-15](https://git.door43.org/Door43/en_tn/src/master/luk/19/13.md)

#### Word Data:####

* Strong's: H6440, G4175, G4177, G4847


---

<a id="clan"/>

### clan, clans ###

#### Definition: ####

The term "clan" refers to a group of extended family members who come from a common ancestor.

* In the Old Testament, the Israelites were counted according to their clans, or family groups.
* Clans were normally named after their most well-known ancestor.
* Individual people were sometimes referred to by the name of their clan. An example of this is when Moses' father-in-law Jethro is sometimes called by his clan name, Reuel.
* Clan could be translated as "family group" or "extended family" or "relatives."

(See also: [family](#family), [Jethro](names.html#jethro), [tribe](#tribe))

#### Bible References: ####

* [1 Chronicles 06:33-35](https://git.door43.org/Door43/en_tn/src/master/1ch/06/33.md)
* [Genesis 10:2-5](https://git.door43.org/Door43/en_tn/src/master/gen/10/02.md)
* [Genesis 36:15-16](https://git.door43.org/Door43/en_tn/src/master/gen/36/15.md)
* [Genesis 36:29-30](https://git.door43.org/Door43/en_tn/src/master/gen/36/29.md)
* [Genesis 36:40-43](https://git.door43.org/Door43/en_tn/src/master/gen/36/40.md)
* [Joshua 15:20](https://git.door43.org/Door43/en_tn/src/master/jos/15/20.md)
* [Numbers 03:38-39](https://git.door43.org/Door43/en_tn/src/master/num/03/38.md)

#### Word Data:####

* Strong's: H1, H441, H1004, H4940


---

<a id="clothed"/>

### clothe, clothed, clothes, clothing, unclothed ###

#### Definition: ####

When used figuratively in the Bible, "clothed with" means to be endowed or equipped with something. To "clothe" oneself with something means to seek to have a certain character quality.

* In the same way that clothing is external to your body and is visible to all, when you are "clothed" with a certain character quality, others can readily see it. To "clothe yourself with kindness" means to let your actions be so characterized by kindness that it is easily seen by everyone.
* To be "clothed with power from on high" means to have power given to you.
* This term is also used to express negative experiences, such as "clothed with shame" or "clothed with terror."

#### Translation Suggestions: ####

* If possible, it is best to keep the literal figure of speech, "clothe yourselves with." Another way to translate this could be "put on" if this refers to putting on clothes.
* If that does not give the correct meaning, other ways to translate "clothed with" could be "showing" or "manifesting" or "filled with" or "having the quality of."
* The term "clothe yourself with" could also be translated as "cover yourself with" or "behave in a way that shows."

#### Bible References: ####

* [Luke 24:48-49](https://git.door43.org/Door43/en_tn/src/master/luk/24/48.md)

#### Word Data: ####

* Strong's: H899, H1545, H3680, H3736, H3830, H3847, H3848, H4055, H4346, H4374, H5497, H8008, H8071, H8516, G294, G1463, G1562, G1737, G1742, G1746, G1902, G2066, G2439, G2440, G3608, G4016, G4470, G4616, G4683, G4749, G5509, G6005


---

<a id="comfort"/>

### comfort, comforts, comforted, comforting, comforter, comforters, uncomforted ###

#### Definition: ####

The terms "comfort" and "comforter" refer to helping someone who is suffering physical or emotional pain.

* A person who comforts someone is called a "comforter."
* In the Old Testament, the term "comfort" is used to describe how God is kind and loving to his people and helps them when they are suffering.
* In the New Testament, it says that God will comfort his people through the Holy Spirit. Those who receive the comfort are then enabled to give the same comfort to others who are suffering.
* The expression "comforter of Israel" referred to the Messiah who would come to rescue his people.
* Jesus referred to the Holy Spirit as the "Comforter" who helps believers in Jesus.

#### Translation Suggestions: ####

* Depending on the context, "comfort" could also be translated as, "ease the pain of" or "help (someone) overcome grief" or "encourage" or "console."
* A phrase such as "our comfort" could be translated as "our encouragement" or "our consoling of (someone)" or "our help in times of grieving."
* The term "comforter" could be translated as "person who comforts" or "someone who helps ease pain" or "person who encourages."
* When the Holy Spirit is called "the Comforter" this could also be translated as "the Encourager" or "the Helper" or "the One who helps and guides."
* The phrase "comforter of Israel" could be translated as, "the Messiah, who comforts Israel."
* An expression like, "they have no comforter" could also be translated as, "No one has comforted them" or "There is no one to encourage or help them."

(See also: [encourage](#encourage), [Holy Spirit](kt.html#holyspirit))

#### Bible References: ####

* [1 Thessalonians 05:8-11](https://git.door43.org/Door43/en_tn/src/master/1th/05/08.md)
* [2 Corinthians 01:3-4](https://git.door43.org/Door43/en_tn/src/master/2co/01/03.md)
* [2 Samuel 10:1-3](https://git.door43.org/Door43/en_tn/src/master/2sa/10/01.md)
* [Acts 20:11-12](https://git.door43.org/Door43/en_tn/src/master/act/20/11.md)

#### Word Data:####

* Strong's: H2505, H5150, H5162, H5165, H5564, H8575, G302, G2174, G3870, G3874, G3875, G3888, G3890, G3931


---

<a id="commander"/>

### commander, commanders ###

#### Definition: ####

The term "commander" refers to a leader of an army who is responsible for leading and commanding a certain group of soldiers.

* A commander could be in charge of a small group of soldiers or a large group, such as a thousand men.
* This term is also used to refer to Yahweh as the commander of angel armies.
* Other ways to translate "commander" could include, "leader" or "captain" or "officer."
* The term to "command" an army could be translated as to "lead" or to "be in charge of."

(See also: [command](kt.html#command), [ruler](#ruler), [centurion](kt.html#centurion))

#### Bible References: ####

* [1 Chronicles 11:4-6](https://git.door43.org/Door43/en_tn/src/master/1ch/11/04.md)
* [2 Chronicles 11:11-12](https://git.door43.org/Door43/en_tn/src/master/2ch/11/11.md)
* [Daniel 02:14-16](https://git.door43.org/Door43/en_tn/src/master/dan/02/14.md)
* [Mark 06:21-22](https://git.door43.org/Door43/en_tn/src/master/mrk/06/21.md)
* [Proverbs 06:6-8](https://git.door43.org/Door43/en_tn/src/master/pro/06/06.md)

#### Word Data:####

* Strong's: H2710, H2951, H1169, H4929, H5057, H6346, H7101, H7262, H7218, H7227, H7229, H7990, H8269, G5506


---

<a id="commit"/>

### commit, commits, committed, committing, commitment ###

#### Definition: ####

The terms "commit" and "commitment" refers to making a decision or promising to do something. 

* A person who promises to do something is also described as being "committed" to doing it.
* To "commit" to someone a certain task means to assign that task to that person. For example, in 2 Corinthians Paul says that God has "committed" (or "given") to us the ministry of helping people be reconciled to God.
* The terms "commit" and "committed" also often refer to doing a certain wrong action such as "commit a sin" or "commit adultery" or "commit murder."
* The expression "committed to him the task" could also be translated as "gave him the task" or "entrusted to him the task" or "assigned the task to him."
* The term "commitment" could be translated by, "task that was given" or "promise that was made."

(See also: [adultery](kt.html#adultery), [faithful](kt.html#faithful), [promise](kt.html#promise), [sin](kt.html#sin))

#### Bible References: ####

* [1 Chronicles 28:6-7](https://git.door43.org/Door43/en_tn/src/master/1ch/28/06.md)
* [1 Peter 02:21-23](https://git.door43.org/Door43/en_tn/src/master/1pe/02/21.md)
* [Jeremiah 02:12-13](https://git.door43.org/Door43/en_tn/src/master/jer/02/12.md)
* [Matthew 13:40-43](https://git.door43.org/Door43/en_tn/src/master/mat/13/40.md)
* [Psalm 058:1-2](https://git.door43.org/Door43/en_tn/src/master/psa/058/001.md)

#### Word Data:####

* Strong's: H539, H817, H1361, H1497, H1500, H1540, H1556, H2181, H2388, H2398, H2399, H2403, H4560, H4603, H5003, H5753, H5766, H5771, H6213, H6466, H7683, H7760, H7847, G264, G2038, G2716, G3429, G3431, G3860, G3872, G3908, G4102, G4160, G4203


---

<a id="companion"/>

### companion, companions ###

#### Facts: ####

The term "companion" refers to a person who goes with someone else or who is associated with someone else, such as in a friendship or marriage.

* Companions go through experiences together, share meals together, and support and encourage each other.
* Depending on the context, this term could also be translated with a word or phrase that means,  "friend" or "fellow traveler" or "supporting-person who goes with."

#### Bible References: ####

* [Ezekiel 37:15-17](https://git.door43.org/Door43/en_tn/src/master/ezk/37/15.md)
* [Hebrews 01:8-9](https://git.door43.org/Door43/en_tn/src/master/heb/01/08.md)
* [Proverbs 02:16-17](https://git.door43.org/Door43/en_tn/src/master/pro/02/16.md)
* [Psalms 038:11-12](https://git.door43.org/Door43/en_tn/src/master/psa/038/011.md)

#### Word Data:####

* Strong's: H251, H441, H2269, H2270, H2271, H2273, H2278, H3674, H3675, H4828, H7453, H7462, H7464, G2844, G3353, G4791, G4898, G4904


---

<a id="conceive"/>

### conceive, conceives, conceived, conception ###

#### Definition: ####

The terms "conceive" and "conception" usually refer to becoming pregnant with a child. It can also be used for animals that become pregnant.

* The phrase "conceive a child" could be translated as, "become pregnant" or some other term that is an acceptable way of referring to this.
* The related term "conception" could be translated as, "beginning of a pregnancy" or "moment of becoming pregnant."
* These terms can also refer to creating something or thinking of something, such as an idea, a plan, or a task. Ways to translate this could include, "think of" or "plan" or "create," depending on the context.
* Sometimes this term can be used figuratively as in, "when sin is conceived" which means "when sin is first thought of" or "at the very start of a sin" or "when a sin first begins."

(See also: [create](#creation), [womb](#womb))

#### Bible References: ####

* [Genesis 21:1-4](https://git.door43.org/Door43/en_tn/src/master/gen/21/01.md)
* [Hosea 02:4-5](https://git.door43.org/Door43/en_tn/src/master/hos/02/04.md)
* [Job 15:34-35](https://git.door43.org/Door43/en_tn/src/master/job/15/34.md)
* [Luke 01:24-25](https://git.door43.org/Door43/en_tn/src/master/luk/01/24.md)
* [Luke 02:21](https://git.door43.org/Door43/en_tn/src/master/luk/02/21.md)

#### Word Data:####

* Strong's: H2029, H2030, H2032, H2232, H2254, H2803, H3179, G1080, G1722, G2602, G2845, G4815


---

<a id="concubine"/>

### concubine, concubines ###

#### Definition: ####

A concubine is a woman who is a secondary wife for a man who already has a wife. Usually a concubine is not legally married to the man.

* In the Old Testament, concubines were often female slaves.
* A concubine could be acquired by purchase, through military conquest, or in payment of a debt.
* For a king, having many concubines was a sign of power. 
* The New Testament teaches that the practice of having a concubine is against God's will.

#### Bible References: ####

* [2 Samuel 03:6-7](https://git.door43.org/Door43/en_tn/src/master/2sa/03/06.md)
* [Genesis 22:23-24](https://git.door43.org/Door43/en_tn/src/master/gen/22/23.md)
* [Genesis 25:5-6](https://git.door43.org/Door43/en_tn/src/master/gen/25/05.md)
* [Genesis 35:21-22](https://git.door43.org/Door43/en_tn/src/master/gen/35/21.md)
* [Genesis 36:9-12](https://git.door43.org/Door43/en_tn/src/master/gen/36/09.md)
* [Judges 19:1-2](https://git.door43.org/Door43/en_tn/src/master/jdg/19/01.md)

#### Word Data:####

* Strong's: H3904, H6370


---

<a id="confidence"/>

### confidence, confident, confidently ###

#### Definition: ####

The term "confidence" refers to being sure that something is true or certain to happen.

* In the Bible, the term "hope" often means to wait expectantly for something that is sure to happen. The ULB often translates this as "confidence" or "confidence for the future" or "future confidence" especially when it means to be assured of receiving what God has promised to believers in Jesus.
* Often the term "confidence" refers especially to the certainty that believers in Jesus have that they will someday be with God forever in heaven.
* The phrase, "have confidence in God" means to fully expect to receive and experience what God has promised.
* Being "confident" means believing in God's promises and acting with the assurance that God will do what he has said. This term can also have the meaning of acting boldly and courageously.

#### Translation Suggestions: ####

* The term "confident" could be translated as "assured" or "very sure."
* The phrase "be confident" could also be translated as "trust completely" or "be completely sure about" or "know for certain."
* The term "confidently" could also be translated as "boldly" or "with certainty."
* Depending on the context, ways to translate "confidence" could include, "complete assurance" or "sure expectation" or "certainty."

(See also: [believe](kt.html#believe), [believe](kt.html#believe), [bold](#bold), [faithful](kt.html#faithful), [hope](kt.html#hope), [trust](kt.html#trust))

#### Bible References: ####

{{topic>confidence&nocomments}}

#### Word Data: ####

* Strong's: H982, H983, H985, H986, H3689, H3690, H4009, G1340, G2292, G3954, G3982, G4006, G5287


---

<a id="confirm"/>

### confirm, confirms, confirmed, confirmation ###

#### Definition: ####

The terms "confirm" and "confirmation" refer to stating or assuring that something is true or sure or trustworthy.

* In the Old Testament, God tells his people that he will "confirm" his covenant with them. This means he is stating that he will keep the promises he made in that covenant.
* When a king is "confirmed" it means that the decision to make him king has been agreed upon and supported by the people.
* To confirm what someone wrote means to say that what was written is true.
* The "confirmation" of the gospel means teaching people about the good news of Jesus in such a way that it shows that it is true.
* To give an oath "as confirmation" means to solemnly state or swear that something is true or trustworthy.
* Ways to translate "confirm" could include, "state as true" or "prove to be trustworthy" or "agree with" or "assure" or "promise," depending on the context.

(See also: [covenant](kt.html#covenant), [oath](#oath), [trust](kt.html#trust))

#### Bible References: ####

* [1 Chronicles 16:15-18](https://git.door43.org/Door43/en_tn/src/master/1ch/16/15.md)
* [2 Corinthians 01:21-22](https://git.door43.org/Door43/en_tn/src/master/2co/01/21.md)
* [2 Kings 23:3](https://git.door43.org/Door43/en_tn/src/master/2ki/23/03.md)
* [Hebrews 06:16-18](https://git.door43.org/Door43/en_tn/src/master/heb/06/16.md)

#### Word Data:####

* Strong's: H553, H559, H1396, H3045, H3559, H4390, H4672, H5414, H5975, H6213, H6965, G950, G951, G1991, G2964, G3315, G4300, G4972


---

<a id="consume"/>

### consume, consumes, consumed, consuming ###

#### Definition: ####

The term "consume" literally means to use up something. It has several figurative meanings.

* In the Bible, the word "consume" often refers to destroying things or people.
* A fire is said to consume things, which means it destroys them by burning them up.
* God is described as a "consuming fire," which is a description of his anger against sin. His anger results in terrible punishment for sinners who do not repent.
* To consume food means to eat or drink something.
* The phrase, "consume the land" could be translated as "destroy the land."

#### Translation Suggestions ####

* In the context of consuming the land or people, this term could be translated as "destroy."
* When fire is referred to, "consume" could be translated as "burn up."
* The burning bush that Moses saw "was not consumed" which could be translated as, "did not get burned up" or "did not burn up."
* When referring to eating, "consume" could be translated as "eat" or "devour."
* If someone's strength is "consumed," it means his strength is "used up" or "gone."
* The expression, "God is a consuming fire" could be translated as, "God is like a fire that burns things up" or "God is angry against sin and will destroy sinners like a fire."

(See also: [devour](#devour), [wrath](kt.html#wrath))

#### Bible References: ####

* [1 Kings 18:38-40](https://git.door43.org/Door43/en_tn/src/master/1ki/18/38.md)
* [Deuteronomy 07:16](https://git.door43.org/Door43/en_tn/src/master/deu/07/16.md)
* [Jeremiah 03:23-25](https://git.door43.org/Door43/en_tn/src/master/jer/03/23.md)
* [Job 07:8-10](https://git.door43.org/Door43/en_tn/src/master/job/07/08.md)
* [Numbers 11:1-3](https://git.door43.org/Door43/en_tn/src/master/num/11/01.md)

#### Word Data:####

* Strong's: H398, H402, H1086, H1104, H1197, H1497, H1846, H2000, H2628, H3615, H3617, H3631, H3857, H4127, H4529, H4743, H5486, H5487, H5595, H6244, H6789, H7332, H7646, H7829, H8046, H8552, G355, G1159, G2618, G2654, G2719, G5315, G5723


---

<a id="contempt"/>

### contempt, contemptible ###

#### Facts: ####

The term "contempt" refers to a deep disrespect and dishonor that is shown toward something or someone. Something that is greatly dishonorable is called "contemptible."

* A person or behavior that shows open disrespect for God is also called "contemptible" and could be translated as "greatly disrespectful" or "completely dishonorable" or "deserving scorn."
* To "hold in contempt" means to regard someone as having less value or to judge someone as less worthy than oneself.
* The following expressions have a similar meaning:  "have contempt for"  or "show contempt for" or "be in contempt of" or "treat with contempt." These all mean to "strongly disrespect" or "strongly dishonor" something or someone by what is said and done.
* When King David sinned by committing adultery and murder, God said that David had "shown contempt for" God. It means he had greatly disrespected and dishonored God by doing that.

(See also: [dishonor](#dishonor))

#### Bible References: ####

* [Daniel 12:1-2](https://git.door43.org/Door43/en_tn/src/master/dan/12/01.md)
* [Proverbs 15:5-6](https://git.door43.org/Door43/en_tn/src/master/pro/15/05.md)
* [Psalms 031:17-18](https://git.door43.org/Door43/en_tn/src/master/psa/031/017.md)

#### Word Data:####

* Strong's: H936, H937, H959, H963, H1860, H7043, H7589, H5006, G1848


---

<a id="corrupt"/>

### corrupt, corrupts, corrupted, corrupting, corruption, corruptly ###

#### Definition: ####

The terms "corrupt" and "corruption" refer to a state of affairs in which people have become ruined, immoral, or dishonest.

* The term "corrupt" literally means to be "bent" or "broken" morally.
* A person who is corrupt has turned away from truth and is doing things that are dishonest or immoral.
* To corrupt someone means to influence that person to do dishonest and immoral things.

#### Translation Suggestions: ####

* The term to "corrupt" could be translated as to "influence to do evil" or to "cause to be immoral."
* A corrupt person could be described as a person "who has become immoral" or "who practices evil."
* This term could also be translated as "bad" or "immoral" or "evil."
* The term "corruption" could be translated as "the practice of evil" or "evil" or "immorality."

(See also: [evil](kt.html#evil))

#### Bible References: ####

* [Ezekiel 20:42-44](https://git.door43.org/Door43/en_tn/src/master/ezk/20/42.md)
* [Galatians 06:6-8](https://git.door43.org/Door43/en_tn/src/master/gal/06/06.md)
* [Genesis 06:11-12](https://git.door43.org/Door43/en_tn/src/master/gen/06/11.md)
* [Matthew 12:33-35](https://git.door43.org/Door43/en_tn/src/master/mat/12/33.md)
* [Psalm 014:1](https://git.door43.org/Door43/en_tn/src/master/psa/014/001.md)

#### Word Data: ####

* Strong's: H1097, H1605, H2254, H2610, H4167, H4743, H4889, H4893, H7843, H7844, H7845, G853, G862, G1311, G1312, G2585, G2704, G4550, G4595, G5349, G5351, G5356


---

<a id="council"/>

### council, councils ###

#### Definition: ####

A council is a group of people who meet to discuss, give advice, and make decisions about important matters.

* A council is usually organized in an official and somewhat permanent way for a specific purpose, such as making decisions about legal matters.
* The "Jewish Council" in Jerusalem, also known as the "Sanhedrin," had 70 members, which included Jewish leaders such as chief priests, elders, scribes, Pharisees, and Sadducees who met regularly to decide matters of Jewish law. It was this council of religious leaders who put Jesus on trial and decided that he should be killed.
* There were also smaller Jewish councils in other cities.
* The apostle Paul was brought before a Roman council when he was arrested for teaching the gospel.
* Depending on the context, the word "council" could also be translated as "legal assembly" or "political assembly."
* To be "in council" means to be in a special meeting to decide something.
* Note that this is a different word than "counsel," which means, "wise advice."

(See also: [assembly](#assembly), [counsel](#counselor), [Pharisee](kt.html#pharisee), [law](kt.html#lawofmoses), [priest](kt.html#priest), [Sadducee](kt.html#sadducee), [scribe](kt.html#scribe))

#### Bible References: ####

* [Acts 07:57-58](https://git.door43.org/Door43/en_tn/src/master/act/07/57.md)
* [Acts 24:20-21](https://git.door43.org/Door43/en_tn/src/master/act/24/20.md)
* [John 03:1-2](https://git.door43.org/Door43/en_tn/src/master/jhn/03/01.md)
* [Luke 22:66-68](https://git.door43.org/Door43/en_tn/src/master/luk/22/66.md)
* [Mark 13:9-10](https://git.door43.org/Door43/en_tn/src/master/mrk/13/09.md)
* [Matthew 05:21-22](https://git.door43.org/Door43/en_tn/src/master/mat/05/21.md)
* [Matthew 26:59-61](https://git.door43.org/Door43/en_tn/src/master/mat/26/59.md)

#### Word Data:####

* Strong's: H4186, H5475, H7277, G1010, G4824, G4892


---

<a id="counselor"/>

### advice, advise, advised, advisor, advisors, counsel, counselor, counselors, counsels ###

#### Definition: ####

The terms "counsel" and "advice" have the same meaning and refer to helping someone decide wisely about what to do in a certain situation. A wise "counselor" or "advisor" is someone who gives advice or counsel that will help a person make right choices.

* Kings often have official advisors or counselors to help them decide important matters that affect the people they are ruling.
* Sometimes the advice or counsel that is given is not good. Evil advisors may urge a king to take action or make a decree that will harm him or his people.
* Depending on the context, "advice" or "counsel"  could also be translated as "help in deciding" or "warnings" or "exhortations" or "guidance."
* The action, to "counsel" could be translated as to "advise" or to "make suggestions" or to "exhort."
* Note that "counsel" is a different word than "council," which refers to a group of people.

(See also: [exhort](kt.html#exhort), [Holy Spirit](kt.html#holyspirit), [wise](kt.html#wise))

#### Bible References: ####

#### Word Data:####

* Strong's: H1697, H1847, H1875, H1884, H1907, H2940, H3245, H3272, H3289, H3982, H4156, H4431, H5475, H5779, H5843, H6440, H6963, H6098, H7592, H8458, G1010, G1011, G1012, G1106, G4823, G4824, G4825


---

<a id="courage"/>

### courage, courageous, encourage, encouragement, take courage, discourage, discouraged, discouragement, discouraging ###

#### Facts: ####

The term "courage" refers to boldly facing or doing something that is difficult, frightening, or dangerous. 

* The term, "courageous" describes someone who shows courage, who does the right thing even when feeling afraid or pressured to give up.
* A person shows courage when he faces emotional or physical pain with strength and perseverance.
* The expression "take courage" means, "don't be afraid" or "be assured that things will turn out well."
* When Joshua was preparing to go into the dangerous land of Canaan, Moses exhorted him to be "strong and courageous." 
* The term "courageous" could also be translated as "brave" or "unafraid" or "bold."
* Depending on the context, to "have courage" could also be translated as, "be emotionally strong" or "be confident" or "stand firm."
* To "speak with courage" could be translated as, "speak boldly" or "speak without being afraid" or "speak confidently."

The terms "encourage" and encouragement" refer to saying and doing things to cause someone to have comfort, hope, confidence, and courage.

* A similar term is "exhort," which means to urge someone to reject an activity that is wrong and to instead do things that are good and right.
* The apostle Paul and other New Testament writers taught Christians to encourage one another to love and serve others.

The term "discourage" refers to saying and doing things that cause people to lose hope, confidence, and courage and so to have less desire to keep working hard to do what they know they should do.

#### Translation Suggestions ####

* Depending on the context, ways to translate "encourage" could include "urge" or "comfort" or "say kind things" or "help and support."
* The phrase "give words of encouragement" means "say things that cause other people to feel loved, accepted, and empowered."

(See also: [confidence](#confidence), [exhort](kt.html#exhort), [fear](kt.html#fear), [strength](#strength))

#### Bible References: ####

* [Deuteronomy 01:37-38](https://git.door43.org/Door43/en_tn/src/master/deu/01/37.md)
* [2 Kings 18:19-21](https://git.door43.org/Door43/en_tn/src/master/2ki/18/19.md)
* [1 Chronicles 17:25-27](https://git.door43.org/Door43/en_tn/src/master/1ch/17/25.md)
* [Matthew 09:20-22](https://git.door43.org/Door43/en_tn/src/master/mat/09/20.md)
* [1 Corinthians 14:1-4](https://git.door43.org/Door43/en_tn/src/master/1co/14/01.md)
* [2 Corinthians 07:13-14](https://git.door43.org/Door43/en_tn/src/master/2co/07/13.md)
* [Acts 05:12-13](https://git.door43.org/Door43/en_tn/src/master/act/05/12.md)
* [Acts 16:40](https://git.door43.org/Door43/en_tn/src/master/act/16/40.md)
* [Hebrews 03:12-13](https://git.door43.org/Door43/en_tn/src/master/heb/03/12.md)
* [Hebrews 13:5-6](https://git.door43.org/Door43/en_tn/src/master/heb/13/05.md)

#### Word Data:####

* Strong's: H533, H553, H1368, H2388, H2388, H2428, H3820, H3824, H7307, G2114, G2115, G2174, G2292, G2293, G2294, G3870, G3874, G3954, G4389, G4837, G5111


---

<a id="courtyard"/>

### court, courts, courtyard, courtyards ###

#### Definition: ####

The terms "courtyard" and "court" refer to an enclosed area that is open to the sky and surrounded by walls. The term "court" also refers to a place where judges decide legal and criminal matters.

* The tabernacle was surrounded by one courtyard which was enclosed by walls made of thick, cloth curtains. 
* The temple complex had three inner courtyards: one for the priests, one for Jewish men, and one for Jewish women.
* These inner courtyards were surrounded by a low stone wall that separated them from an outer courtyard where Gentiles were permitted to worship.
* The courtyard of a house was an open area in the middle of the house.
* The phrase "king's court" can refer to his palace or to a place in his palace where he makes judgments.
* The expression, "courts of Yahweh" is a figurative way of referring to Yahweh's dwelling place or to the place where people go to worship Yahweh.

#### Translation Suggestions: ####
 
* The term "courtyard" could be translated as "enclosed space" or "walled-in land" or "temple grounds" or "temple enclosure."
* Sometimes the term "temple" may need to be translated as "temple courtyards" or "temple complex" so that it is clear that the courtyards are being referred to, not the temple building.
* The expression, "courts of Yahweh" could be translated as, "place where Yahweh lives" or "place where Yahweh is worshiped."
* The term used for a king's court could also be used to refer to Yahweh's court.

(See also: [Gentile](kt.html#gentile), [judge](#judgeposition), [king](#king), [tabernacle](kt.html#tabernacle), [temple](kt.html#temple))

#### Bible References: ####

* [2 Kings 20:4-5](https://git.door43.org/Door43/en_tn/src/master/2ki/20/04.md)
* [Exodus 27:9-10](https://git.door43.org/Door43/en_tn/src/master/exo/27/09.md)
* [Jeremiah 19:14-15](https://git.door43.org/Door43/en_tn/src/master/jer/19/14.md)
* [Luke 22:54-55](https://git.door43.org/Door43/en_tn/src/master/luk/22/54.md)
* [Matthew 26:69-70](https://git.door43.org/Door43/en_tn/src/master/mat/26/69.md)
* [Numbers 03:24-26](https://git.door43.org/Door43/en_tn/src/master/num/03/24.md)
* [Psalms 065:4](https://git.door43.org/Door43/en_tn/src/master/psa/065/004.md)

#### Word Data:####

* Strong's: H1004, H1508, H2691, H5835, H6503, H7339, G833, G933, G2681, G4259


---

<a id="cow"/>

### cow, cows, bull, bulls, calf, calves, cattle, heifer, ox, oxen ###

#### Definition: ####

The terms "cow," "bull," "heifer," "ox," and "cattle" all refer to a kind of large, four-legged bovine animal that eats grass.

* The female of this kind of animal is called a "cow," the male is a "bull," and their offspring is a "calf."
* In the Bible, cattle were among the "clean" animals that the people could eat and use for sacrifice. They were primarily raised for their meat and milk.

A "heifer" is an adult female cow that has not yet given birth to a calf.

An "ox" is a type of cattle that is specifically trained to do agricultural work. The plural of this term is "oxen." Usually oxen are male and have been castrated.

* Throughout the Bible, oxen were depicted as animals tied together by a yoke to pull a cart or a plow.
* Having oxen work together under a yoke was such a common occurrence in the Bible that the phrase to "be under a yoke" became a metaphor for hard work and labor.
*  A bull is also a male type of cattle, but it has not been castrated and has not been trained as a work animal.

(See also: [How to Translate Unknowns](https://git.door43.org/Door43/en_ta/src/master/translate/translate-unknown.md))

(See also: [yoke](#yoke))

#### Bible References: ####

* [Genesis 15:9-11](https://git.door43.org/Door43/en_tn/src/master/gen/15/09.md)
* [Exodus 24:5-6](https://git.door43.org/Door43/en_tn/src/master/exo/24/05.md)
* [Numbers 19:1-2](https://git.door43.org/Door43/en_tn/src/master/num/19/01.md)
* [Deuteronomy 21:3-4](https://git.door43.org/Door43/en_tn/src/master/deu/21/03.md)
* [1 Samuel 01:24-25](https://git.door43.org/Door43/en_tn/src/master/1sa/01/24.md)
* [1 Samuel 15:1-3](https://git.door43.org/Door43/en_tn/src/master/1sa/15/01.md)
* [1 Samuel 16:2-3](https://git.door43.org/Door43/en_tn/src/master/1sa/16/02.md)
* [1 Kings 01:9-10](https://git.door43.org/Door43/en_tn/src/master/1ki/01/09.md)
* [2 Chronicles 11:13-15](https://git.door43.org/Door43/en_tn/src/master/2ch/11/13.md)
* [2 Chronicles 15:10-11](https://git.door43.org/Door43/en_tn/src/master/2ch/15/10.md)
* [Matthew 22:4](https://git.door43.org/Door43/en_tn/src/master/mat/22/04.md)
* [Luke 13:15-16](https://git.door43.org/Door43/en_tn/src/master/luk/13/15.md)
* [Luke 14:4-6](https://git.door43.org/Door43/en_tn/src/master/luk/14/04.md)
* [Hebrews 09:13-15](https://git.door43.org/Door43/en_tn/src/master/heb/09/13.md)

#### Word Data:####

* Strong's: H47, H441, H504, H929, H1165, H1241, H1241, H1241, H4399, H4735, H4806, H5695, H5697, H5697, H6499, H6499, H6510, H6510, H6629, H7214, H7716, H7794, H7794, H7921, H8377, H8377, H8450, H8450, G1016, G1151, G2353, G2934, G3447, G3448, G4165, G5022, G5022


---

<a id="creation"/>

### create, creates, created, creation, creator ###

#### Definition: ####

The term "create" means to make something or to cause something to be. Whatever is created is called a "creation." God is called the "Creator" because he caused everything in the entire universe to come into existence.

* When this term is used to refer to God creating the world, it means he made it out of nothing.
* When human beings "create" something, it means they made it out of things that already existed.
* Sometimes "create" is used in a figurative way to describe something abstract, such as creating peace, or creating a pure heart in someone.
* The term "creation" can refer to the very beginning of the world when God first created everything. It can also be used to refer generally to everything that God created. Sometimes the word "creation" refers more specifically to just the people in the world.

#### Translation Suggestions: ####

* Some languages may have to directly say that God created the world "out of nothing" to make sure this meaning is clear.
* The phrase, "since the creation of the world" means, "since the time when God created the world."
* A similar phrase, "at the beginning of creation" could be translated as, "when God created the world at the beginning of time," or "when the world was first created."
* To preach the good news to "all creation" means to preach the good news to "all people everywhere on earth."
* The phrase "Let all creation rejoice" means "Let everything that God created rejoice."
* Depending on the context, "create" could be translated as "make" or "cause to be" or "make out of nothing."
* The term "the Creator" could be translated as "the One who created everything" or "God, who made the whole world."
* Phrases like "your Creator" could be translated as "God, who created you."

(See also: [God](kt.html#god), [good news](kt.html#goodnews), [world](kt.html#world))

#### Bible References: ####
se, "since the creation of the world" means, "since the time when God created the world was created.

* [1 Corinthians 11:9-10](https://git.door43.org/Door43/en_tn/src/master/1co/11/09.md)
* [1 Peter 04:17-19](https://git.door43.org/Door43/en_tn/src/master/1pe/04/17.md)
* [Colossians 01:15-17](https://git.door43.org/Door43/en_tn/src/master/col/01/15.md)
* [Galatians 06:14-16](https://git.door43.org/Door43/en_tn/src/master/gal/06/14.md)
* [Genesis 01:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/01/01.md)
* [Genesis 14:19-20](https://git.door43.org/Door43/en_tn/src/master/gen/14/19.md)

#### Word Data:####

* Strong's: H3335, H4639, H6213, H6385, H7069, G2041, G2602, G2675, G2936, G2937, G2939, G4160, G5480


---

<a id="creature"/>

### creature, creatures ###

#### Definition: ####

The term "creature" refers to all the living beings that God created, both humans and animals.

* The prophet Ezekiel described seeing "living creatures" in his vision of the glory of God. He did not know what they were, so he gave them this very general label.
* Note that the term "creation" has a different meaning since it includes everything God created, both living and nonliving things (such as land, water, and stars). The term "creature" only includes living things.

#### Translation Suggestions ###

* Depending on the context, "creature" could be translated as, "being" or "living being" or "created being."
* The plural, "creatures" could be translated as "all living things" or "people and animals" or "animals" or "human beings."

(See also: [create](#creation))

#### Bible References: ####

* [Daniel 04:10-12](https://git.door43.org/Door43/en_tn/src/master/dan/04/10.md)
* [Ezekiel 01:7-9](https://git.door43.org/Door43/en_tn/src/master/ezk/01/07.md)
* [Joshua 10:28](https://git.door43.org/Door43/en_tn/src/master/jos/10/28.md)
* [Leviticus 11:46-47](https://git.door43.org/Door43/en_tn/src/master/lev/11/46.md)
* [Revelation 19:3-4](https://git.door43.org/Door43/en_tn/src/master/rev/19/03.md)

#### Word Data:####

* Strong's: H255, H1320, H1321, H1870, H2119, H2416, H4639, H5315, H5971, H7430, H8318, G2226, G2937, G2938


---

<a id="criminal"/>

### crime, crimes, criminal, criminals ###

#### Definition: ####

The term  "crime" usually refers to a sin that involves breaking the law of a country or state. The term "criminal" refers to someone who has committed a crime.

* Types of crimes include such things as killing a person or stealing someone's property.
* A criminal is usually captured and kept in some form of captivity such as a prison.
* In Bible times, some criminals became fugitives, wandering from place to place to escape people who wanted to harm them out of revenge for their crime.

(See also: [thief](#thief))

#### Bible References: ####

* [2 Timothy 02:8-10](https://git.door43.org/Door43/en_tn/src/master/2ti/02/08.md)
* [Hosea 06:8-9](https://git.door43.org/Door43/en_tn/src/master/hos/06/08.md)
* [Job 31:26-28](https://git.door43.org/Door43/en_tn/src/master/job/31/26.md)
* [Luke 23:32](https://git.door43.org/Door43/en_tn/src/master/luk/23/32.md)
* [Matthew 27:23-24](https://git.door43.org/Door43/en_tn/src/master/mat/27/23.md)

#### Word Data:####

* Strong's: H2154, H2400, H4639, H5771, H7563, H7564, G156, G1462, G2556, G2557, G4467


---

<a id="crown"/>

### crown, crowns, crowned ###

#### Definition: ####

A crown is a decorative, circular headpiece worn on the head of rulers such as kings and queens. The term to "crown" means to put a crown on someone's head; figuratively it means, to "honor."

* Crowns are usually made of gold or silver, and are embedded with precious gems such as emeralds and rubies.
* A crown was intended to be a symbol of a king's power and wealth.
* By contrast, the crown made of thorn branches that the Roman soldiers placed on Jesus' head was meant to mock him and hurt him.
* In ancient times, winners of athletic contests would be awarded a crown made out of olive branches. The apostle Paul mentions this crown in his second letter to Timothy.
* Used figuratively, to "crown" means to honor someone. We honor God by obeying him and praising him to others. This is like putting a crown on him and acknowledging that he is King.
* Pauls calls fellow believers his "joy and crown." In this expression, "crown" is used figuratively to mean that Paul has been greatly blessed and honored by how these believers have remained faithful in serving God.
* When used figuratively, "crown" could be translated as "prize" or "honor" or "reward."
* The figurative use of to "crown" could be translated as to "honor" or to "decorate."
* If a person is "crowned" this could be translated as "a crown was put on his head."
* The expression, "he was crowned with glory and honor" could be translated as, "glory and honor were bestowed on him" or "he was given glory and honor" or "he was endowed with glory and honor."

(See also: [glory](kt.html#glory), [king](#king), [olive](#olive))

#### Bible References: ####

* [John 19:1-3](https://git.door43.org/Door43/en_tn/src/master/jhn/19/01.md)
* [Lamentations 05:15-16](https://git.door43.org/Door43/en_tn/src/master/lam/05/15.md)
* [Matthew 27:27-29](https://git.door43.org/Door43/en_tn/src/master/mat/27/27.md)
* [Philippians 04:1-3](https://git.door43.org/Door43/en_tn/src/master/php/04/01.md)
* [Psalms 021:3-4](https://git.door43.org/Door43/en_tn/src/master/psa/021/003.md)
* [Revelation 03:9-11](https://git.door43.org/Door43/en_tn/src/master/rev/03/09.md)

#### Word Data:####

* Strong's: H2213, H3803, H3804, H4502, H5145, H5849, H5850, H6936, G1238, G4735, G4737


---

<a id="cry"/>

### cry, cries, cried, crying, cry out, cries out, cried out, out, outcry, outcries ###

#### Definition: ####

The terms "cry" or "cry out" often mean to say something loudly and urgently. Someone can "cry out" in pain or in distress or in anger.

* The phrase "cry out" also means to shout or call out, often with the intent to ask for help.
* This term could also be translated as "exclaim loudly" or "urgently ask for help," depending on the context.
* An expression such as, "I cry out to you"  could be translated as, "I call to you for help" or "I urgently ask you for help."

(See also: [call](kt.html#call), [plead](#plead))

#### Bible References: ####

* [Job 27:8-10](https://git.door43.org/Door43/en_tn/src/master/job/27/08.md)
* [Mark 05:5-6](https://git.door43.org/Door43/en_tn/src/master/mrk/05/05.md)
* [Mark 06:48-50](https://git.door43.org/Door43/en_tn/src/master/mrk/06/48.md)
* [Psalm 022:1-2](https://git.door43.org/Door43/en_tn/src/master/psa/022/001.md)

#### Word Data:####

* Strong's: H603, H1058, H2199, H2201, H6030, H6463, H6670, H6682, H6817, H6818, H6873, H6963, H7121, H7123, H7321, H7440, H7442, H7723, H7737, H7768, H7769, H7771, H7773, H7775, H8173, H8663, G310, G349, G863, G994, G995, G1916, G2019, G2799, G2805, G2896, G2905, G2906, G2929, G4377, G5455


---

<a id="cupbearer"/>

### cupbearer, cupbearers ###

#### Definition: ####

In Old Testament times, a "cupbearer" was a king's servant who was given the task of bringing the king his cup of wine, usually tasting the wine first to make sure it had not been poisoned.

* The literal meaning of this term is "cup bringer" or "someone who brings the cup."
* A cupbearer was known for being very trustworthy and loyal to his king.
* Because of his trusted position, a cupbearer would often have influence in the decisions the ruler made.
* Nehemiah was the cupbearer for King Artaxerxes of Persia during the time when some of the Israelites were in captivity in Babylon.

(See also: [Artaxerxes](names.html#artaxerxes), [Babylon](names.html#babylon), [captive](#captive), [Persia](names.html#persia), [Pharaoh](names.html#pharaoh))

#### Bible References: ####

* [1 Kings 10:3-5](https://git.door43.org/Door43/en_tn/src/master/1ki/10/03.md)
* [Nehemiah 01:10-11](https://git.door43.org/Door43/en_tn/src/master/neh/01/10.md)

#### Word Data:####

* Strong's: H8248


---

<a id="curtain"/>

### curtain, curtains##

#### Definition:##

In the Bible, the term "curtain" refers to a very thick, heavy piece of material used in the making of the tabernacle and the temple.

* The tabernacle was built using four layers of curtains for the top and sides. These curtain coverings were made of cloth or animal skins.
* Cloth curtains were also used to form a wall surrounding the tabernacle courtyard. These curtains were made out of "linen" which was a kind of cloth made out of the flax plant.
* In both the tabernacle and temple building, a thick cloth curtain hung between the holy place and the most holy place. It was this curtain that was miraculously torn into two parts when Jesus died.

#### Translation Suggestions: ####

* Since modern-day curtains are very different from the curtains used in the Bible, it may be more clear to use a different word or to add words that describe the curtains.
* Depending on the context, ways to translate this term could include, "curtain covering" or "covering" or "piece of thick cloth" or "animal skin covering" or "hanging piece of cloth."

(See also: [holy place](kt.html#holyplace), [tabernacle](kt.html#tabernacle), [temple](kt.html#temple))

#### Bible References: ####

* [Hebrews 10:19-22](https://git.door43.org/Door43/en_tn/src/master/heb/10/19.md)
* [Leviticus 04:16-17](https://git.door43.org/Door43/en_tn/src/master/lev/04/16.md)
* [Luke 23:44-45](https://git.door43.org/Door43/en_tn/src/master/luk/23/44.md)
* [Matthew 27:51-53](https://git.door43.org/Door43/en_tn/src/master/mat/27/51.md)
* [Numbers 04:5-6](https://git.door43.org/Door43/en_tn/src/master/num/04/05.md)

#### Word Data:####

* Strong's: H1852, H3407, H4539, H6532, H7050, G2665


---

<a id="cutoff"/>

### cut off, cuts off, cutting off ###

#### Definition: ####

The expression "be cut off" is an expression that means to be excluded, banished or isolated from the main group. It can also refer to being killed as an act of divine judgment for sin.

* In the Old Testament, disobeying God's commands resulted in being cut off, or separated, from God's people and from his presence.
* God also said he would "cut off" or destroy the non-Israelite nations, because they did not worship or obey him and were enemies of Israel.
* The expression "cut off" is also used to refer to God causing a river to stop flowing.

#### Translation Suggestions: ####

* The expression "be cut off" could be translated as "be banished" or "be sent away" or "be separated from" or "be killed" or "be destroyed."
* Depending on the context, to "cut off" could be translated as, to "destroy" or to "send away" or to "separate from" or to "destroy."
* In the context of flowing waters being cut off, this could be translated as "were stopped" or "were caused to stop flowing" or "were divided."
* The literal meaning of cutting something with a knife should be distinguished from the figurative uses of this term.

#### Bible References: ####

* [Genesis 17:12-14](https://git.door43.org/Door43/en_tn/src/master/gen/17/12.md)
* [Judges 21:6-7](https://git.door43.org/Door43/en_tn/src/master/jdg/21/06.md)
* [Proverbs 23:17-18](https://git.door43.org/Door43/en_tn/src/master/pro/23/17.md)

#### Word Data: ####

* Strong's: H1214, H1219, H1438, H1468, H1494, H1504, H1629, H1820, H1824, H1826, H2498, H2686, H3582, H3772, H5243, H5352, H6202, H6789, H6990, H7082, H7088, H7096, H7112, H7113, G609, G851, G1581, G2407, G5257


---

<a id="cypress"/>

### cypress ###

#### Definition: ####

The term "cypress" refers to a kind of fir tree that was plentiful in the regions where people lived in Bible times, especially countries bordering the Mediterranean Sea.

* Cyprus and Lebanon are two places that are specifically mentioned in the Bible as having many cypress trees.
* The wood that Noah used to build the ark may have been cypress.
* Because cypress wood is sturdy and long-lasting, it was used by ancient peoples for building boats and other structures.

(See also: [ark](kt.html#ark), [Cyprus](names.html#cyprus), [fir](#fir), [Lebanon](names.html#lebanon))

#### Bible References: ####

* [Acts 11:19-21](https://git.door43.org/Door43/en_tn/src/master/act/11/19.md)
* [Genesis 06:13-15](https://git.door43.org/Door43/en_tn/src/master/gen/06/13.md)
* [Hosea 14:7-8](https://git.door43.org/Door43/en_tn/src/master/hos/14/07.md)
* [Isaiah 44:14](https://git.door43.org/Door43/en_tn/src/master/isa/44/14.md)
* [Isaiah 60:12-13](https://git.door43.org/Door43/en_tn/src/master/isa/60/12.md)
* [Zechariah 11:1-3](https://git.door43.org/Door43/en_tn/src/master/zec/11/01.md)

#### Word Data:####

* Strong's: H8645


---

<a id="darkness"/>

### darkness ###

#### Definition: ####

The term "darkness" literally means an absence of light. There are also several figurative meanings of this term:

* As a metaphor, "darkness" means "impurity" or "evil" or "spiritual blindness."
* It also refers to anything related to sin and moral corruption.
* The expression "dominion of darkness" refers to all that is evil and ruled by Satan.
* The term "darkness" can also be used as a metaphor for death. (See: [Metaphor](https://git.door43.org/Door43/en_ta/src/master/translate/figs-metaphor.md))
* People who do not know God are said to be "living in darkness," which means they do not understand or practice righteousness.
* God is light (righteousness) and the darkness (evil) cannot overcome that light.
* The place of punishment for those who reject God is sometimes referred to as "outer darkness."

#### Translation Suggestions: ####

* It is best to translate this term literally, with a word in the project language that refers to the absence of light. This could also be a term that refers to the darkness of a room with no light or to the time of day when there is no light.
* For the figurative uses, it is also important to keep the image of darkness in contrast to light, as a way to describe evil and deception in contrast to goodness and truth.
* Depending on the context, other ways to translate this could be, "darkness of night" (as opposed to "light of day") or "not seeing anything, like at night" or "evil, like a dark place".

(See also: [corrupt](#corrupt), [dominion](kt.html#dominion), [kingdom](#kingdom), [light](#light), [redeem](kt.html#redeem), [righteous](kt.html#righteous))

#### Bible References: ####

* [1 John 01:5-7](https://git.door43.org/Door43/en_tn/src/master/1jn/01/05.md)
* [1 John 02:7-8](https://git.door43.org/Door43/en_tn/src/master/1jn/02/07.md)
* [1 Thessalonians 05:4-7](https://git.door43.org/Door43/en_tn/src/master/1th/05/04.md)
* [2 Samuel 22:10-12](https://git.door43.org/Door43/en_tn/src/master/2sa/22/10.md)
* [Colossians 01:13-14](https://git.door43.org/Door43/en_tn/src/master/col/01/13.md)
* [Isaiah 05:29-30](https://git.door43.org/Door43/en_tn/src/master/isa/05/29.md)
* [Jeremiah 13:15-17](https://git.door43.org/Door43/en_tn/src/master/jer/13/15.md)
* [Joshua 24:7](https://git.door43.org/Door43/en_tn/src/master/jos/24/07.md)
* [Matthew 08:11-13](https://git.door43.org/Door43/en_tn/src/master/mat/08/11.md)

#### Word Data: ####

* Strong's: H652, H653, H2816, H2821, H2822, H2825, H3990, H3991, H4285, H5890, H6205, G2217, G4652, G4653, G4655, G4656


---

<a id="death"/>

### die, dies, died, dead, deadly, deadness, death, deaths, deathly ###

#### Definition: ####

This term is used to refer to both physical and spiritual death. Physically, it refers to when the physical body of a person stops living. Spiritually, it refers to sinners being separated from a holy God because of their sin.

#### 1. Physical death ######

* To "die" means to stop living. Death is the end of physical life.
* A person's spirit leaves his body when he dies.
* When Adam and Eve sinned, physical death came into the world.
* The expression "put to death" refers to killing or murdering someone, especially when a king or other ruler gives an order for someone to be killed.

#### 2. Spiritual death ######

* Spiritual death is the separation of a person from God.
* Adam died spiritually when he disobeyed God. His relationship with God was broken. He became ashamed and tried to hide from God.
* Every descendant of Adam is a sinner, and is spiritually dead. God makes us spiritually alive again when we have faith in Jesus Christ.

#### Translation Suggestions: ####

* To translate this term, it is best to use the everyday, natural word or expression in the target language that refers to death.
* In some languages, to "die" may be expressed as to "not live." The term "dead" may be translated as "not alive" or "not having any life" or "not living."
* Many languages use figurative expressions to describe death, such as to "pass away" in English. However, in the Bible it is best to use the most direct term for death that is used in everyday language.
* In the Bible, physical life and death are often compared to spiritual life and death. It is important in a translation to use the same word or phrase for both physical death and spiritual death.
* In some languages it may be more clear to say "spiritual death" when the context requires that meaning. Some translators may also feel it is best to say "physical death" in contexts where it is being contrasted to spiritual death.
* The expression "the dead" is a nominal adjective that refers to people who have died. Some languages will translate this as "dead people" or "people who have died."  (See: [nominal adjective](https://git.door43.org/Door43/en_ta/src/master/translate/figs-nominaladj.md))
* The expression "put to death" could also be translated as "kill" or "murder" or "execute."

(See also: [believe](kt.html#believe), [faith](kt.html#faith), [life](kt.html#life), [spirit](kt.html#spirit))

#### Bible References: ####

* [1 Corinthians 15:20-21](https://git.door43.org/Door43/en_tn/src/master/1co/15/20.md)
* [1 Thessalonians 04:16-18](https://git.door43.org/Door43/en_tn/src/master/1th/04/16.md)
* [Acts 10:42-43](https://git.door43.org/Door43/en_tn/src/master/act/10/42.md)
* [Acts 14:19-20](https://git.door43.org/Door43/en_tn/src/master/act/14/19.md)
* [Colossians 02:13-15](https://git.door43.org/Door43/en_tn/src/master/col/02/13.md)
* [Colossians 02:20-23](https://git.door43.org/Door43/en_tn/src/master/col/02/20.md)
* [Genesis 02:15-17](https://git.door43.org/Door43/en_tn/src/master/gen/02/15.md)
* [Genesis 34:27-29](https://git.door43.org/Door43/en_tn/src/master/gen/34/27.md)
* [Matthew 16:27-28](https://git.door43.org/Door43/en_tn/src/master/mat/16/27.md)
* [Romans 05:10-11](https://git.door43.org/Door43/en_tn/src/master/rom/05/10.md)
* [Romans 05:12-13](https://git.door43.org/Door43/en_tn/src/master/rom/05/12.md)
* [Romans 06:10-11](https://git.door43.org/Door43/en_tn/src/master/rom/06/10.md)

#### Examples from the Bible stories: ####

* __[01:11](https://git.door43.org/Door43/en_tn/src/master/obs/01/11.md)__ God told Adam that he could eat from any tree in the garden except from the tree of the knowledge of good and evil. If he ate from this tree, he would __die__.
* __[02:11](https://git.door43.org/Door43/en_tn/src/master/obs/02/11.md)__ "Then you will __die__, and your body will return to dirt."
* __[07:10](https://git.door43.org/Door43/en_tn/src/master/obs/07/10.md)__ Then Isaac __died__, and Jacob and Esau buried him.
* __[37:05](https://git.door43.org/Door43/en_tn/src/master/obs/37/05.md)__ "Jesus replied, "I am the Resurrection and the Life. Whoever believes in me will live, even though he __dies__. Everyone who believes in me will never __die__."
* __[40:08](https://git.door43.org/Door43/en_tn/src/master/obs/40/08.md)__ Through his __death__, Jesus opened a way for people to come to God.
* __[43:07](https://git.door43.org/Door43/en_tn/src/master/obs/43/07.md)__ "Although Jesus __died__, God raised him from the dead."
* __[48:02](https://git.door43.org/Door43/en_tn/src/master/obs/48/02.md)__ Because they sinned, everyone on earth gets sick and everyone __dies__.
* __[50:17](https://git.door43.org/Door43/en_tn/src/master/obs/50/17.md)__ He (Jesus) will wipe away every tear and there will be no more suffering, sadness, crying, evil, pain, or __death__.
*

#### Word Data:####

* Strong's: H6, H1478, H1826, H1934, H2491, H4191, H4192, H4193, H4194, H4463, H5038, H5315, H6297, H6757, H7496, H7523, H8045, H8546, H8552, G336, G337, G520, G581, G599, G615, G622, G684, G1634, G1935, G2079, G2253, G2286, G2287, G2288, G2289, G2348, G2837, G2966, G3498, G3499, G3500, G4430, G4880, G4881, G5053, G5054



---

<a id="deceive"/>

### deceive, deceives, deceived, deceiving, deceit, deceiver, deceivers, deceitful, deceitfully, deceitfulness, deception, deceptive ###

#### Definition: ####

The term "deceive" means to cause someone to believe something that is not true. The act of deceiving someone is called "deceit."

* Another term "deception" also refers to the act of causing someone to believe something that is not true.
* Someone who causes others to believe something false is a "deceiver." For example, Satan is called a "deceiver." The evil spirits that he controls are also deceivers.
* A person, action, or message that is not truthful can be described as "deceptive."
* The terms "deceit" and "deception" have the same meaning, but there are some small differences in how they are used.
* The descriptive terms "deceitful" and "deceptive" have the same meaning and are used in the same contexts.

#### Translation Suggestions: ####

* Other ways to translate "deceive" could include "lie to" or "cause to have a false belief" or "cause someone to think something that is not true."
* The term "deceived" could also be translated as "caused to think something false" or "lied to" or "tricked" or "fooled" or "misled."
* "Deceiver" could be translated as "liar" or "one who misleads"  or "someone who deceives."
* Depending on the context, the terms "deception" or "deceit" could be translated with a word or phrase that means "falsehood" or  "lying" or "trickery" or "dishonesty."
* The terms "deceptive" or "deceitful" could be translated as "untruthful" or "misleading" or "lying" to describe a person who speaks or acts in a way that causes other people to believe things that are not true.

(See also: [true](kt.html#true))

#### Bible References: ####

* [1 John 01:8-10](https://git.door43.org/Door43/en_tn/src/master/1jn/01/08.md)
* [1 Timothy 02:13-15](https://git.door43.org/Door43/en_tn/src/master/1ti/02/13.md)
* [2 Thessalonians 02:3-4](https://git.door43.org/Door43/en_tn/src/master/2th/02/03.md)
* [Genesis 03:12-13](https://git.door43.org/Door43/en_tn/src/master/gen/03/12.md)
* [Genesis 31:26-28](https://git.door43.org/Door43/en_tn/src/master/gen/31/26.md)
* [Leviticus 19:11-12](https://git.door43.org/Door43/en_tn/src/master/lev/19/11.md)
* [Matthew 27:62-64](https://git.door43.org/Door43/en_tn/src/master/mat/27/62.md)
* [Micah 06:11-12](https://git.door43.org/Door43/en_tn/src/master/mic/06/11.md)

{{tag>publish review}

#### Word Data:####

* Strong's: H898, H2048, H3577, H3584, H4123, H4820, H4860, H5230, H5377, H6121, H6231, H6280, H6601, H7411, H7423, H7683, H7686, H7952, H8267, H8496, H8501, H8582, H8591, H8649, G538, G539, G1386, G1387, G1388, G1389, G1818, G3884, G4105, G4106, G4108, G5422, G5423


---

<a id="declare"/>

### declare, declares, declared, declaring, declaration, declarations ###

#### Definition: ####

The terms "declare" and "declaration" refer to making a formal or public statement, often to emphasize something.

* A "declaration" not only emphasizes the importance of what is being proclaimed, but it also calls attention to the one making the declaration.
* For example, in the Old Testament, a message from God is often preceded by "the declaration of Yahweh" or "this is what Yahweh declares." This expression emphasizes that it is Yahweh himself who is saying this. The fact that the message comes from Yahweh shows how important that message is.

#### Translation Suggestions: ####

* Depending on the context, "declare" could also be translated as "proclaim" or "publicly state" or "strongly say" or "emphatically state."
* The term "declaration" could also be translated as "statement" or "proclamation."
* The phrase "this is Yahweh's declaration" could be translated as "this is what Yahweh declares" or "this is what Yahweh says." 

(See also: [proclaim](#proclaim))

#### Bible References: ####

* [1 Chronicles 16:23-24](https://git.door43.org/Door43/en_tn/src/master/1ch/16/23.md)
* [1 Corinthians 15:31-32](https://git.door43.org/Door43/en_tn/src/master/1co/15/31.md)
* [1 Samuel 24:17-18](https://git.door43.org/Door43/en_tn/src/master/1sa/24/17.md)
* [Amos 02:15-16](https://git.door43.org/Door43/en_tn/src/master/amo/02/15.md)
* [Ezekiel 05:11-12](https://git.door43.org/Door43/en_tn/src/master/ezk/05/11.md)
* [Matthew 07:21-23](https://git.door43.org/Door43/en_tn/src/master/mat/07/21.md)

#### Word Data:####

* Strong's: H262, H559, H560, H816, H874, H952, H1696, H3045, H4853, H5002, H5042, H5046, H5608, H6567, H6575, H7121, H7561, H7878, H8085, G312, G394, G518, G669, G1107, G1213, G1229, G1335, G1344, G1555, G1718, G1732, G1834, G2097, G2511, G2605, G2607, G3140, G3670, G3724, G3822, G3853, G3870, G3955, G5319, G5419


---

<a id="decree"/>

### decree, decrees, decreed ###

#### Definition: ####

A decree is a proclamation or law that is publicly declared to all the people.

* God's laws are also called decrees, statutes, or commandments.
* Like laws and commands, decrees  must be obeyed.
* An example of a decree by a human ruler was the proclamation by Caesar Augustus that everyone living in the Roman Empire must go back to their hometown in order to be counted in a census.
* To decree something means to give an order that must be obeyed. This could be translated as to "order" or to "command" or to "formally require" or to "publicly make a law."
* Something that is "decreed" to happen means that this "will definitely happen" or "has been decided upon and will not be changed" or "declared absolutely that this will happen."

(See also: [command](kt.html#command), [declare](#declare), [law](#law), [proclaim](#proclaim))

#### Bible References: ####

* [1 Chronicles 15:13-15](https://git.door43.org/Door43/en_tn/src/master/1ch/15/13.md)
* [1 Kings 08:57-58](https://git.door43.org/Door43/en_tn/src/master/1ki/08/57.md)
* [Acts 17:5-7](https://git.door43.org/Door43/en_tn/src/master/act/17/05.md)
* [Daniel 02:12-13](https://git.door43.org/Door43/en_tn/src/master/dan/02/12.md)
* [Esther 01:21-22](https://git.door43.org/Door43/en_tn/src/master/est/01/21.md)
* [Luke 02:1-3](https://git.door43.org/Door43/en_tn/src/master/luk/02/01.md)

#### Word Data:####

* Strong's: H559, H633, H1697, H5715, H1504, H1510, H1881, H1882, H1696, H2706, H2708, H2710, H2711, H2782, H2852, H2940, H2941, H2942, H3791, H3982, H4055, H4406, H4941, H5407, H5713, H6599, H6680, H7010, H8421, G1378


---

<a id="dedicate"/>

### dedicate, dedicates, dedicated, dedication ###

#### Definition: ####

To dedicate is to set apart or commit something for a special purpose or function.

* David dedicated his gold and silver to the Lord.
* Often the word "dedication" refers to a formal event or ceremony to set apart something for a special purpose.
* The dedication of the altar included offering a sacrifice to God.
* Nehemiah led the Israelites in a dedication of Jerusalem's repaired walls with a renewed promise to serve only Yahweh and to take care of his city. This event included giving thanks to God with musical instruments and singing.
* The term "dedicate" could also be translated as "specially assign a special purpose" or "commit something to be used for a specific use" or "commit someone to do a special task."

(See also: [commit](#commit))

#### Bible References: ####

* [1 Chronicles 15:11-12](https://git.door43.org/Door43/en_tn/src/master/1ch/15/11.md)
* [1 Corinthians 06:9-11](https://git.door43.org/Door43/en_tn/src/master/1co/06/09.md)
* [1 Kings 07:51](https://git.door43.org/Door43/en_tn/src/master/1ki/07/51.md)
* [1 Timothy 04:3-5](https://git.door43.org/Door43/en_tn/src/master/1ti/04/03.md)
* [2 Chronicles 02:4-5](https://git.door43.org/Door43/en_tn/src/master/2ch/02/04.md)
* [John 17:18-19](https://git.door43.org/Door43/en_tn/src/master/jhn/17/18.md)
* [Luke 02:22-24](https://git.door43.org/Door43/en_tn/src/master/luk/02/22.md)

#### Word Data:####

* Strong's: H2596, H2597, H2598, H2764, H4394, H6942, H6944, G1456, G1457


---

<a id="deer"/>

### deer, doe, does, fawns, roebuck, roebucks ###

#### Definition: ####

A deer is a large, graceful, four-legged animal that lives in forests or on mountains. The male animal has large horns or antlers on its head.

* The term "doe" refers to a female deer and a "fawn" is the name of a baby deer.
* The term "buck" refers to a male deer.
* A "roebuck" is the male of the specific variety called "roedeer."
* Deer have strong, thin legs that help them jump high and run fast.
* Their feet have split hooves which help them walk or climb easily on most any terrain.

(See also: [How to Translate Unknowns](https://git.door43.org/Door43/en_ta/src/master/translate/translate-unknown.md))

#### Bible References: ####

* [2 Samuel 22:34-35](https://git.door43.org/Door43/en_tn/src/master/2sa/22/34.md)
* [Genesis 49:19-21](https://git.door43.org/Door43/en_tn/src/master/gen/49/19.md)
* [Job 39:1-2](https://git.door43.org/Door43/en_tn/src/master/job/39/01.md)
* [Psalms 018:33-34](https://git.door43.org/Door43/en_tn/src/master/psa/018/033.md)
* [Song of Solomon 02:7](https://git.door43.org/Door43/en_tn/src/master/sng/02/07.md)

#### Word Data:####

* Strong's: H354, H355, H365, H3180, H3280, H6643, H6646


---

<a id="defile"/>

### defile, defiles, defiled, defiling, be defiled, are defiled, was defiled, were defiled ###

#### Definition: ####

The terms "defile" and "be defiled" refer to becoming polluted or dirty. Something can be defiled in a physical, moral, or ritual sense.

* God warned the Israelites to not defile themselves by eating or touching things that he had declared as "unclean" and "unholy."
* Certain things such as dead bodies and contagious diseases were declared by God to be unclean and would defile a person if they touched them.
* God commanded the Israelites to avoid sexual sins. These would defile them and make them unacceptable to God.
* There were also certain kinds of bodily processes that defiled a person temporarily until he could become ritually pure again.
* In the New Testament, Jesus taught that sinful thoughts and actions are what truly defile a person.

#### Translation Suggestions: ####

* The term "defile" can also be translated as "cause to be unclean" or "cause to be unrighteous" or "cause to be ritually unacceptable."
* To "be defiled" could be translated as "become unclean" or "be caused to be morally unacceptable (to God)" or "become ritually unacceptable."

(See also: [clean](kt.html#clean), [clean](kt.html#clean))

#### Bible References: ####

* [2 Kings 23:8-9](https://git.door43.org/Door43/en_tn/src/master/2ki/23/08.md)
* [Exodus 20:24-26](https://git.door43.org/Door43/en_tn/src/master/exo/20/24.md)
* [Genesis 34:27-29](https://git.door43.org/Door43/en_tn/src/master/gen/34/27.md)
* [Genesis 49:3-4](https://git.door43.org/Door43/en_tn/src/master/gen/49/03.md)
* [Isaiah 43:27-28](https://git.door43.org/Door43/en_tn/src/master/isa/43/27.md)
* [Leviticus 11:43-45](https://git.door43.org/Door43/en_tn/src/master/lev/11/43.md)
* [Mark 07:14-16](https://git.door43.org/Door43/en_tn/src/master/mrk/07/14.md)
* [Matthew 15:10-11](https://git.door43.org/Door43/en_tn/src/master/mat/15/10.md)

#### Word Data:####

* Strong's: H1351, H1352, H1602, H2490, H2491, H2610, H2930, H2931, H2933, H2936, H5953, G733, G2839, G2840, G3392, G3435, G4696, G5351


---

<a id="delight"/>

### delight, delights, delighted, delightful ###

#### Definition: ####

A "delight" is something that pleases someone greatly or causes much joy. 

* To "delight in" something means to "take joy in" or "be happy about" it.
* When something is very agreeable or pleasing it is called "delightful."
* If a persons delight is in something it means that he enjoys it very much.
* The expression "my delight is in the law of Yahweh" could be translated as "the law of Yahweh gives me great joy" or "I love to obey the laws of Yahweh" or "I am happy when I obey Yahweh's commands."
* The phrases "take no delight in" and "have no delight in" could be translated as "not at all pleased by" or "not happy about."
* The  phrase "delight himself in" means "he enjoys doing" something or "he is very happy about" something or someone.
* The term "delights" refers to things that a person enjoys. This could be translated as "pleasures" or "things that give joy."
* An expression such as "I delight to do your will" could also be translated as "I enjoy doing your will" or "I am very happy when I obey you."

#### Bible References: ####

* [Proverbs 08:30-31](https://git.door43.org/Door43/en_tn/src/master/pro/08/30.md)
* [Psalm 001:1-2](https://git.door43.org/Door43/en_tn/src/master/psa/001/001.md)
* [Psalms 119:69-70](https://git.door43.org/Door43/en_tn/src/master/psa/119/069.md)
* [Song of Solomon 01:1-4](https://git.door43.org/Door43/en_tn/src/master/sng/01/01.md)

#### Word Data:####

* Strong's: H1523, H2530, H2531, H2532, H2654, H2655, H2656, H2836, H4574, H5276, H5727, H5730, H6026, H6027, H7306, H7381, H7521, H7522, H8057, H8173, H8191, H8588, H8597


---

<a id="deliverer"/>

### deliver, delivers, delivered, delivering, deliverer, deliverance ###

#### Definition: ####

To "deliver" someone means to rescue that person. The term  "deliverer" refers to someone who rescues or frees people from slavery, oppression, or other dangers. The term "deliverance" refers to what happens when someone rescues or frees people from slavery, oppression, or other dangers.

* In the Old Testament, God appointed deliverers to protect the Israelites by leading them in battle against other people groups who came to attack them.
* These deliverers were also called "judges" and the Old Testament book of Judges records the time in history when these judges were governing Israel.
* God is also called a "deliverer." Throughout the history of Israel, he delivered or rescued his people from their enemies.
* The term "deliver over to" or "deliver up to" has a very different meaning of handing someone over to an enemy, such as when Judas delivered Jesus over to the Jewish leaders.

#### Translation Suggestions: ####

* In the context of helping people escape from their enemies, the term "deliver" can be translated as "rescue" or "liberate" or "save."
* When it means to deliver someone over to the enemy, "deliver over" can be translated as "betray to" or "hand over" or "give over."
* The word "deliverer" can also be translated as "rescuer" or "liberator."
* When the term "deliverer" refers to the judges who led Israel, it could also be translated as "governor" or "judge" or "leader."

(See also: [judge](kt.html#judge), [save](kt.html#save))

#### Bible References: ####

* [2 Corinthians 01:8-10](https://git.door43.org/Door43/en_tn/src/master/2co/01/08.md)
* [Acts 07:35-37](https://git.door43.org/Door43/en_tn/src/master/act/07/35.md)
* [Galatians 01:3-5](https://git.door43.org/Door43/en_tn/src/master/gal/01/03.md)
* [Judges 10:10-12](https://git.door43.org/Door43/en_tn/src/master/jdg/10/10.md)

#### Examples from the Bible stories: ####

* __[16:03](https://git.door43.org/Door43/en_tn/src/master/obs/16/03.md)__ Then God provided a __deliverer__  who rescued them from their enemies and brought peace to the land.
* __[16:16](https://git.door43.org/Door43/en_tn/src/master/obs/16/16.md)__ They (Israel) finally asked God for help again, and God sent them another __deliverer__.
* __[16:17](https://git.door43.org/Door43/en_tn/src/master/obs/16/17.md)__ Over many years, God sent many __deliverers__  who saved the Israelites from their enemies.

#### Word Data:####

* Strong's: H579, H1350, H2020, H2502, H3052, H3205, H3444, H3467, H4042, H4422, H4560, H4672, H5337, H5338, H5414, H5462, H6299, H6308, H6403, H6405, H6413, H6475, H6487, H6561, H7725, H7804, H8000, H8199, H8668, G325, G525, G629, G859, G1080, G1325, G1560, G1659, G1807, G1929, G2673, G3086, G3860, G4506, G4991, G5088, G5483


---

<a id="descendant"/>

### descend, descends, descended, descending, descendant, descendants ###

#### Definition: ####

A "descendant" is someone who is a direct blood relative of someone else further back in history.

* For example, Abraham was a descendant of Noah.
* A person's descendants are his children, grandchildren, great-great-grandchildren, and so on. Jacob's descendants were the twelve tribes of Israel.
* The phrase "descended from" is another way of saying "a descendant of" as in "Abraham was descended from Noah." This could also be translated as "from the family line of." 

(See also: [Abraham](names.html#abraham), [ancestor](#father), [Jacob](names.html#jacob), [Noah](names.html#noah), [twelve tribes of Israel](#12tribesofisrael))

#### Bible References: ####

* [1 Kings 09:4-5](https://git.door43.org/Door43/en_tn/src/master/1ki/09/04.md)
* [Acts 13:23-25](https://git.door43.org/Door43/en_tn/src/master/act/13/23.md)
* [Deuteronomy 02:20-22](https://git.door43.org/Door43/en_tn/src/master/deu/02/20.md)
* [Genesis 10:1](https://git.door43.org/Door43/en_tn/src/master/gen/10/01.md)
* [Genesis 28:12-13](https://git.door43.org/Door43/en_tn/src/master/gen/28/12.md)

#### Examples from the Bible stories: ####

  __*[02:09](https://git.door43.org/Door43/en_tn/src/master/obs/02/09.md)__ "The woman's __descendant__ will crush your head, and you will wound his heel."
  __*[04:09](https://git.door43.org/Door43/en_tn/src/master/obs/04/09.md)__ "I give the land of Canaan to your __descendants__."
  __*[05:10](https://git.door43.org/Door43/en_tn/src/master/obs/05/10.md)__ "Your __descendants__ will be more than the stars in the sky."
  __*[17:07](https://git.door43.org/Door43/en_tn/src/master/obs/17/07.md)__ "Someone from your family will always rule as king over Israel, and the Messiah will be one of your __descendants__!"
  __*[18:13](https://git.door43.org/Door43/en_tn/src/master/obs/18/13.md)__ The kings of Judah were __descendants__ of David.
  __*[21:04](https://git.door43.org/Door43/en_tn/src/master/obs/21/04.md)__ God promised King David that the Messiah would be one of David's own __descendants__.
  __*[48:13](https://git.door43.org/Door43/en_tn/src/master/obs/48/13.md)__ God promised David that the Messiah would be one of his __descendants__. Jesus, the Messiah, was that special __descendant__ of David.

#### Word Data:####

* Strong's: H319, H1004, H1121, H1323, H1755, H2232, H2233, H3205, H3211, H3318, H3409, H4294, H5220, H6849, H7611, H8435, G1074, G1085, G4690


---

<a id="desecrate"/>

### desecrate, desecrated, desecrating ###

#### Definition: ####

The term "desecrate" means to damage or contaminate a sacred place or object in such a way that it is unacceptable for use in worship.

* Often desecrating something involves showing great disrespect for it.
* For example, pagan kings desecrated special dishes from God's temple by using them for parties at their palace.
* Bones from dead people were used by enemies to desecrate the altar in God's temple.
* This term could be translated as "cause to be unholy" or "dishonor by making impure" or "disrespectfully profane" or "cause to be impure."

(See also: [altar](kt.html#altar), [defile](#defile), [dishonor](#dishonor), [profane](#profane), [pure](kt.html#purify), [temple](kt.html#temple), [holy](kt.html#holy))

#### Bible References: ####

* [Acts 24:4-6](https://git.door43.org/Door43/en_tn/src/master/act/24/04.md)
* [Isaiah 30:22](https://git.door43.org/Door43/en_tn/src/master/isa/30/22.md)
* [Psalms 074:7-8](https://git.door43.org/Door43/en_tn/src/master/psa/074/007.md)
* [Psalms 089:38-40](https://git.door43.org/Door43/en_tn/src/master/psa/089/038.md)

#### Word Data:####

* Strong's: H2490, H2610, H2930, G953


---

<a id="desert"/>

### desert, deserts, deserted, deserting, wilderness, wildernesses ###

#### Definition: ####

A desert, or wilderness, is a dry, barren place where very few plants and trees can grow.

* A desert is a land area with a dry climate and few plants or animals.
* Because of the harsh conditions, very few people can live in the desert, so it is also referred to as "wilderness."
* "Wilderness" conveys the meaning of being remote, desolate and isolated from people.
* This word can also be translated as "deserted place" or "remote place" or "uninhabited place."

#### Bible References: ####

* [Acts 13:16-18](https://git.door43.org/Door43/en_tn/src/master/act/13/16.md)
* [Acts 21:37-38](https://git.door43.org/Door43/en_tn/src/master/act/21/37.md)
* [Exodus 04:27-28](https://git.door43.org/Door43/en_tn/src/master/exo/04/27.md)
* [Genesis 37:21-22](https://git.door43.org/Door43/en_tn/src/master/gen/37/21.md)
* [John 03:14-15](https://git.door43.org/Door43/en_tn/src/master/jhn/03/14.md)
* [Luke 01:80](https://git.door43.org/Door43/en_tn/src/master/luk/01/80.md)
* [Luke 09:12-14](https://git.door43.org/Door43/en_tn/src/master/luk/09/12.md)
* [Mark 01:1-3](https://git.door43.org/Door43/en_tn/src/master/mrk/01/01.md)
* [Matthew 04:1-4](https://git.door43.org/Door43/en_tn/src/master/mat/04/01.md)
* [Matthew 11:7-8](https://git.door43.org/Door43/en_tn/src/master/mat/11/07.md)

#### Word Data:####

* Strong's: H776, H2723, H3293, H3452, H4057, H6160, H6723, H6728, H6921, H8047, H8414, G2047, G2048


---

<a id="desolate"/>

### desolate, desolation, desolations ###

#### Definition: ####

The terms "desolate" and "desolation" refer to destroying an inhabited region so that it becomes uninhabited.

* When referring to a person, the term "desolate" describes a condition of ruin, loneliness, and grief.
* The term "desolation" is the state or condition of being desolated.
* If a field where crops are growing is made desolate, it means that something has destroyed the crops, such as insects or an invading army.
* A "desolate region" refers to an area of land where few people live because few crops or other vegetation grow there.
* A "desolate land" or "wilderness" was often where outcasts (such as lepers) and dangerous animals lived.
* If a city is "made desolate" it means that its buildings and goods have been destroyed or stolen, and its people have been killed or captured. The city becomes "empty" and "ruined." This is similar to the meaning of "devastate" or "devastated," but with more emphasis on the emptiness.
* Depending on the context, this term could be translated as "ruined" or "destroyed" or "laid waste" or "lonely and outcast" or "deserted." 

(See also: [desert](#desert), [devastate](#devastated), [ruin](#ruin), [waste](#waste))

#### Bible References: ####

* [2 Kings 22:17-19](https://git.door43.org/Door43/en_tn/src/master/2ki/22/17.md)
* [Acts 01:20](https://git.door43.org/Door43/en_tn/src/master/act/01/20.md)
* [Daniel 09:17-19](https://git.door43.org/Door43/en_tn/src/master/dan/09/17.md)
* [Lamentations 03:9-11](https://git.door43.org/Door43/en_tn/src/master/lam/03/09.md)
* [Luke 11:16-17](https://git.door43.org/Door43/en_tn/src/master/luk/11/16.md)
* [Matthew 12:24-25](https://git.door43.org/Door43/en_tn/src/master/mat/12/24.md)

#### Word Data:####

* Strong's: H490, H816, H820, H910, H1327, H1565, H2717, H2720, H2721, H2723, H3173, H3341, H3456, H3582, H4875, H4876, H4923, H5352, H5800, H7582, H7612, H7701, H7722, H8047, H8074, H8076, H8077, G2048, G2049, G2050, G3443


---

<a id="destiny"/>

### destine, destined, destiny, predestined ###

#### Definition: ####

The term "destiny" refers to what will happen to people in the future. If someone is "destined" to do something, it means that what that person will do in the future has been decided by God.

* When God "destines" a nation for wrath, this means that he has decided or chosen to punish that nation because of their sin.
* Judas was "destined" for destruction, which means that God had decided that Judas would be destroyed because of his rebellion.
* Every person has a final, eternal destiny, either in heaven or in hell.
* When the writer of Ecclesiastes says that everyone's destiny is the same, he means that all people eventually die.

#### Translation Suggestions: ####

* The phrase "destine you for wrath" could also be translated as "decided that you will be punished" or "determined that you will experience my wrath."
* The figurative expression "they are destined for the sword" could be translated as "God has decided that they will be destroyed by enemies who will kill them with swords" or "God has determined that their enemies will kill them with swords."
* The phrase "you are destined for" could be translated using a phrase like "God has decided that you will be."
* Depending on the context, "destiny" could be translated as "final end" or "what will happen in the end" or "what God has decided will happen."

(See also: [captive](#captive), [everlasting](kt.html#eternity), [heaven](kt.html#heaven), [hell](kt.html#hell), [John (the Baptist)](names.html#johnthebaptist), [repent](kt.html#repent))

#### Bible References: ####

* [1 Thessalonians 05:8-11](https://git.door43.org/Door43/en_tn/src/master/1th/05/08.md)
* [Ecclesiastes 02:13-14](https://git.door43.org/Door43/en_tn/src/master/ecc/02/13.md)
* [Hebrews 09:27-28](https://git.door43.org/Door43/en_tn/src/master/heb/09/27.md)
* [Philippians 03:17-19](https://git.door43.org/Door43/en_tn/src/master/php/03/17.md)
* [Psalms 009:17-18](https://git.door43.org/Door43/en_tn/src/master/psa/009/017.md)

#### Word Data:####

* Strong's: H2506, H4150, H4487, H4745, H6256, H4507, G5056, G5087


---

<a id="destroyer"/>

### destroy, destroys, destroyed, destroyer, destroyers, destroying ###

#### Definition: ####

The term "destroyer" literally means "person who destroys."

* This term is often used in the Old Testament as a general reference to anyone who destroys other people, such as an invading army.
* When God sent the angel to kill all the firstborn males in Egypt, that angel was referred to as "the destroyer of the firstborn." This could be translated as "the one (or angel) who killed the firstborn males."
* In the book of Revelation about the end times, Satan or some other evil spirit is called "the Destroyer." He is the "one who destroys" because his purpose is to destroy and ruin everything God created.

(See also: [angel](kt.html#angel), [Egypt](names.html#egypt), [firstborn](#firstborn), [Passover](kt.html#passover))

#### Bible References: ####

* [Exodus 12:23](https://git.door43.org/Door43/en_tn/src/master/exo/12/23.md)
* [Hebrews 11:27-28](https://git.door43.org/Door43/en_tn/src/master/heb/11/27.md)
* [Jeremiah 06:25-26](https://git.door43.org/Door43/en_tn/src/master/jer/06/25.md)
* [Judges 16:23-24](https://git.door43.org/Door43/en_tn/src/master/jdg/16/23.md)

#### Word Data:####

* Strong's: H2717, H7843, H7703, G3645


---

<a id="detestable"/>

### detest, detested, detestable ###

#### Facts: ####

The term "detestable" describes something that should be disliked and rejected. To "detest" something means to strongly dislike it. 

* Often the Bible talks about detesting evil. This means to hate evil and reject it.
* God used the word "detestable" to describe the evil practices of those who worshiped false gods.
* The Israelites were commanded to "detest" the sinful, immoral acts that some of the neighboring people groups practiced.
* God called all wrong sexual acts "detestable."
* Divination, sorcery, and child sacrifice were all "detestable" to God.
* The term "detest" could be translated as "strongly reject" or "hate" or "regard as very evil."
* The term "detestable" could also be translated as "horribly evil" or "disgusting" or "deserving rejection."
* When applied to the righteous being "detestable to" the wicked, this could be translated as "considered very undesirable to" or "distasteful to" or "rejected by."
* God told the Israelites to "detest" certain kinds of animals that God had declared to be "unclean" and not suitable for food. This could also be translated as "strongly dislike" or "reject" or "regard as unacceptable."
(See also: [divination](#divination), [clean](kt.html#clean))

#### Bible References: ####

* [Genesis 43:32-34](https://git.door43.org/Door43/en_tn/src/master/gen/43/32.md)
* [Jeremiah 07:29-30](https://git.door43.org/Door43/en_tn/src/master/jer/07/29.md)
* [Leviticus 11:9-10](https://git.door43.org/Door43/en_tn/src/master/lev/11/09.md)
* [Luke 16:14-15](https://git.door43.org/Door43/en_tn/src/master/luk/16/14.md)
* [Revelation 17:3-5](https://git.door43.org/Door43/en_tn/src/master/rev/17/03.md)

#### Word Data:####

* Strong's: H1602, H6973, H8130, H8251, H8262, H8263, H8441, H8581, G946, G947, G948, G4767, G5723, G3404


---

<a id="devastated"/>

### devastate, devastated, devastating, devastation, devastations ###

#### Definition: ####

The term "devastated" or "devastation" refers to having one's property or land ruined or destroyed. It also often includes destroying or capturing the people living on that land.

* This refers to a very severe and complete destruction. 
* For example, the city of Sodom was devastated by God as punishment for the sins of the people living there.
* The term "devastation" can also include causing great emotional grief resulting from the punishment or destruction.

#### Translation Suggestions ####

* The term "devastate" could be translated as "completely destroy" or "completely ruin."
* Depending on the context, "devastation" could be translated as "complete destruction" or "total ruin" or "overwhelming grief" or "disaster."

#### Bible References: ####

* [Daniel 08:24-25](https://git.door43.org/Door43/en_tn/src/master/dan/08/24.md)
* [Jeremiah 04:13-15](https://git.door43.org/Door43/en_tn/src/master/jer/04/13.md)
* [Numbers 21:29-30](https://git.door43.org/Door43/en_tn/src/master/num/21/29.md)
* [Zephaniah 01:12-13](https://git.door43.org/Door43/en_tn/src/master/zep/01/12.md)

#### Word Data:####

* Strong's: H1110, H1238, H2721, H1826, H3615, H3772, H7701, H7703, H7722, H7843, H8074, H8077


---

<a id="devour"/>

### devour, devours, devoured, devouring ###

#### Definition: ####

The term "devour" means to eat or consume in an aggressive manner.

* Using this word in a figurative sense, Paul warned believers to not devour one another, meaning to not attack or destroy each other with words or actions (Galatians 5:15).
* Also in a figurative sense, the term "devour" is often used with a meaning of "completely destroy" as when talking about nations devouring each other or a fire devouring buildings and people.
* This term could also be translated as "completely consume" or "totally destroy."

#### Bible References: ####

* [1 Peter 05:8-9](https://git.door43.org/Door43/en_tn/src/master/1pe/05/08.md)
* [Amos 01:9-10](https://git.door43.org/Door43/en_tn/src/master/amo/01/09.md)
* [Exodus 24:16-18](https://git.door43.org/Door43/en_tn/src/master/exo/24/16.md)
* [Ezekiel 16:20-22](https://git.door43.org/Door43/en_tn/src/master/ezk/16/20.md)
* [Luke 15:28-30](https://git.door43.org/Door43/en_tn/src/master/luk/15/28.md)
* [Matthew 23:13-15](https://git.door43.org/Door43/en_tn/src/master/mat/23/13.md)
* [Psalms 021:9-10](https://git.door43.org/Door43/en_tn/src/master/psa/021/009.md)

#### Word Data:####

* Strong's: H398, H399, H400, H402, H1104, H1105, H3216, H3615, H3857, H3898, H7462, H7602, G2068, G2666, G2719, G5315


---

<a id="discernment"/>

### discern, discerned, discerning, discernment ###

#### Definition: ####

The term "discern" means to be able to understand something, especially being able to know whether something is right or wrong.

* The term "discernment" refers to understanding and deciding wisely about a certain matter.
* It means to have wisdom and good judgment.

#### Translation Suggestions: ####

* Depending on the context, "discern" could also be translated as "understand" or "know the difference between" or "distinguish good and evil" or "judge rightly about" or "perceive right from wrong."
* "Discernment" could be translated as "understanding" or "ability to distinguish good and evil."

(See also: [judge](kt.html#judge), [wise](kt.html#wise))

#### Bible References: ####

* [1 Kings 03:7-9](https://git.door43.org/Door43/en_tn/src/master/1ki/03/07.md)
* [Genesis 41:33-34](https://git.door43.org/Door43/en_tn/src/master/gen/41/33.md)
* [Proverbs 01:4-6](https://git.door43.org/Door43/en_tn/src/master/pro/01/04.md)
* [Psalms 019:11-12](https://git.door43.org/Door43/en_tn/src/master/psa/019/011.md)

#### Word Data:####

* Strong's: H995, H1781, H2940, H4209, H5234, H8085, G350, G1252, G1253, G1381, G2924


---

<a id="disgrace"/>

### disgrace, disgraces, disgraced, disgraceful ###

#### Facts: ####

The term "disgrace" refers to a loss of honor and respect.

* When a person does something sinful, it can cause him to be in a state of disgrace or dishonor.
* The term "disgraceful" is used to describe a sinful act or the person who did it.
* Sometimes a person who is doing good things is treated in a way that causes him disgrace or shame.
* For example, when Jesus was killed on a cross, this was a disgraceful way to die. Jesus had done nothing wrong to deserve this disgrace.
* Ways to translate "disgrace" could include "shame" or "dishonor."
* Ways to translate "disgraceful" could include "shameful" or dishonoring."

(See also: [dishonor](#dishonor), [honor](kt.html#honor), [shame](#shame))

#### Bible References: ####

* [1 Timothy 03:6-7](https://git.door43.org/Door43/en_tn/src/master/1ti/03/06.md)
* [Genesis 34:6-7](https://git.door43.org/Door43/en_tn/src/master/gen/34/06.md)
* [Hebrews 11:23-26](https://git.door43.org/Door43/en_tn/src/master/heb/11/23.md)
* [Lamentations 02:1-2](https://git.door43.org/Door43/en_tn/src/master/lam/02/01.md)
* [Psalms 022:6-8](https://git.door43.org/Door43/en_tn/src/master/psa/022/006.md)

#### Word Data:####

* Strong's: H954, H1984, H2490, H2617, H2659, H2781, H2865, H3637, H3971, H5007, H5034, H5039, H6031, H7036, G149, G819, G3680, G3856


---

<a id="dishonor"/>

### dishonor, dishonors, dishonored, dishonorable ###

#### Definition: ####

The term "dishonor" means to do something that is disrespectful to someone. This can also cause that person shame or disgrace.

* The term "dishonorable" describes an action that is shameful or that causes someone to be dishonored.
* Sometimes "dishonorable" is used to refer to objects that are not useful for anything important.
* Children are commanded to honor and obey their parents. When children disobey, they dishonor their parents. They are treating their parents in a way that does not honor them.
* The Israelites dishonored Yahweh when they worshiped false gods and practiced immoral behavior.
* The Jews dishonored Jesus by saying that he was possessed by a demon.
* This could be translated as to "not honor" or to "treat with no respect."
* The noun "dishonor" could be translated as "disrespect" or "loss of honor."
* Depending on the context, "dishonorable" could also be translated as "not honorable" or "shameful" or "not worthwhile" or "not valuable."

(See also: [disgrace](#disgrace), [honor](kt.html#honor))

#### Bible References: ####

* [1 Corinthians 04:10-11](https://git.door43.org/Door43/en_tn/src/master/1co/04/10.md)
* [1 Samuel 20:32-34](https://git.door43.org/Door43/en_tn/src/master/1sa/20/32.md)
* [2 Corinthians 06:8-10](https://git.door43.org/Door43/en_tn/src/master/2co/06/08.md)
* [Ezekiel 22:6-9](https://git.door43.org/Door43/en_tn/src/master/ezk/22/06.md)
* [John 08:48-49](https://git.door43.org/Door43/en_tn/src/master/jhn/08/48.md)
* [Leviticus 18:6-8](https://git.door43.org/Door43/en_tn/src/master/lev/18/06.md)

#### Word Data:####

* Strong's: H1540, H2490, H2781, H3637, H3639, H5006, H5034, H6172, H6173, H7034, H7036, H7043, G818, G819, G820, G987, G2617


---

<a id="disobey"/>

### disobey, disobeys, disobeyed, disobedience, disobedient ###

#### Definition: ####

The term "disobey" means to not obey what someone in authority has commanded or instructed. A person who does this is being "disobedient."

* A person who does something he was told not to do is disobeying.
* To disobey also means to refuse to do something that was commanded.
* The term "disobedient" is also used to describe the character of someone who habitually disobeys or rebels. It means that they are sinful or wicked.
* The term "disobedience" means "the act of not obeying" or "behavior that is against what God wants."
* A "disobedient people" could be translated by "people who keep on disobeying" or "people who do not do what God commands."

(See also: [authority](kt.html#authority), [evil](kt.html#evil), [sin](kt.html#sin), [obey](#obey))

#### Bible References: ####

* [1 Kings 13:20-22](https://git.door43.org/Door43/en_tn/src/master/1ki/13/20.md)
* [Acts 26:19-21](https://git.door43.org/Door43/en_tn/src/master/act/26/19.md)
* [Colossians 03:5-8](https://git.door43.org/Door43/en_tn/src/master/col/03/05.md)
* [Luke 01:16-17](https://git.door43.org/Door43/en_tn/src/master/luk/01/16.md)
* [Luke 06:49](https://git.door43.org/Door43/en_tn/src/master/luk/06/49.md)
* [Psalms 089:30-32](https://git.door43.org/Door43/en_tn/src/master/psa/089/030.md)

#### Examples from the Bible stories: ####

* __[02:11](https://git.door43.org/Door43/en_tn/src/master/obs/02/11.md)__ God said to the man, "You listened to your wife and __disobeyed__  me."
* __[13:07](https://git.door43.org/Door43/en_tn/src/master/obs/13/07.md)__ If the people obeyed these laws, God promised that he would bless and protect them. If they __disobeyed__  them, God would punish them.
* __[16:02](https://git.door43.org/Door43/en_tn/src/master/obs/16/02.md)__ Because the Israelites kept __disobeying__  God, he punished them by allowing their enemies to defeat them.
* __[35:12](https://git.door43.org/Door43/en_tn/src/master/obs/35/12.md)__ "The older son said to his father, 'All these years I have worked faithfully for you! I never __disobeyed__  you, and still you did not give me one small goat so I could celebrate with my friends.'"

#### Word Data:####

* Strong's: H4784, H5674, G506, G543, G544, G545, G3847, G3876


---

<a id="disperse"/>

### disperse, dispersion ###

#### Definition: ####

The terms "disperse" and  "dispersion" refer to the scattering of people or things into many different directions.

* In the Old Testament, God talks about "dispersing" people, causing them to have to separate and live in different places apart from each other. He did this to punish them for their sin. Perhaps being dispersed would help them repent and start worshiping God again.
* The term "dispersion" is used in the New Testament to refer to Christians who had to leave their homes and move to many different locations to escape persecution.
* The phrase "the dispersion" could be translated as "believers in many different places" or "the people who moved away to live in different nations."
* The term "disperse" could be translated as "send away into many different places" or "scatter abroad" or "cause to move away to live in different countries."
  

(See also: [believe](kt.html#believe), [persecute](#persecute))

#### Bible References: ####

* [1 Peter 01:1-2](https://git.door43.org/Door43/en_tn/src/master/1pe/01/01.md)
* [Ezekiel 12:14-16](https://git.door43.org/Door43/en_tn/src/master/ezk/12/14.md)
* [Ezekiel 30:22-24](https://git.door43.org/Door43/en_tn/src/master/ezk/30/22.md)
* [Psalms 018:13-14](https://git.door43.org/Door43/en_tn/src/master/psa/018/013.md)

#### Word Data:####

* Strong's: H2219, H4127, H5310, H6327, H6340, H6504, H8600, G1287, G1290, G4650


---

<a id="divination"/>

### divination, diviner, soothsaying, soothsayer ###

#### Definition: ####

The terms "divination" and "soothsaying" refer to the practice of trying to get information from spirits in the supernatural world. A person who does this is sometimes called a "diviner" or "soothsayer."

* In Old Testament times, God commanded the Israelites to not practice divination or soothsaying.
* God did permit his people to seek information from him using the Urim and Thummim, which were stones that he had designated to be used by the high priest for that purpose. But he did not allow his people to seek information through the help of evil spirits.
* Pagan diviners used different methods of trying to find out information from the spirit world. Sometimes they would examine the inside parts of a dead animal or throw animal bones on the ground, looking for patterns that they would interpret as messages from their false gods.
* In the New Testament, Jesus and the apostles also rejected divination, sorcery, witchcraft, and magic. All these practices involve using the power of evil spirits and are condemned by God.

(See also: [apostle](kt.html#apostle), [false god](kt.html#falsegod), [magic](#magic), [sorcery](#sorcery))

#### Bible References: ####

* [1 Samuel 06:1-2](https://git.door43.org/Door43/en_tn/src/master/1sa/06/01.md)
* [Acts 16:16-18](https://git.door43.org/Door43/en_tn/src/master/act/16/16.md)
* [Ezekiel 12:24-25](https://git.door43.org/Door43/en_tn/src/master/ezk/12/24.md)
* [Genesis 44:3-5](https://git.door43.org/Door43/en_tn/src/master/gen/44/03.md)
* [Jeremiah 27:9-11](https://git.door43.org/Door43/en_tn/src/master/jer/27/09.md)

#### Word Data:####

* Strong's: H1870, H4738, H5172, H6049, H7080, H7081, G4436


---

<a id="divorce"/>

### divorce ###

#### Definition: ####

A divorce is the legal act of ending a marriage. The term to "divorce" means to formally and legally separate from one's spouse in order to end the marriage.

* The literal meaning of the term to "divorce" is to "send away" or to "formally separate from." Other languages may have similar expressions to refer to divorce.
* A "certificate of divorce" could be translated as a "paper stating that the marriage has ended."

#### Bible References: ####

* [1 Chronicles 08:8-11](https://git.door43.org/Door43/en_tn/src/master/1ch/08/08.md)
* [Leviticus 21:7-9](https://git.door43.org/Door43/en_tn/src/master/lev/21/07.md)
* [Luke 16:18](https://git.door43.org/Door43/en_tn/src/master/luk/16/18.md)
* [Mark 10:1-4](https://git.door43.org/Door43/en_tn/src/master/mrk/10/01.md)
* [Matthew 05:31-32](https://git.door43.org/Door43/en_tn/src/master/mat/05/31.md)
* [Matthew 19:3-4](https://git.door43.org/Door43/en_tn/src/master/mat/19/03.md)

#### Word Data:####

* Strong's: H1644, H3748, H5493, H7971, G630, G647, G863


---

<a id="doctrine"/>

### doctrine ###

#### Definition: ####

The word "doctrine" literally means "teaching." It usually refers to religious teaching.

* In the context of Christian teachings, "doctrine" refers to all teachings about God – Father, Son and Holy Spirit – including all his character qualities and everything he has done.
* It also refers to everything God teaches Christians about how to live holy lives that bring glory to him.
* The word "doctrine" is sometimes also used to refer to false or worldly religious teachings that come from human beings. The context makes the meaning clear.
* This term could also be translated as "teaching."

(See also: [teach](#teach))

#### Bible References: ####

* [1 Timothy 01:3-4](https://git.door43.org/Door43/en_tn/src/master/1ti/01/03.md)
* [2 Timothy 03:16-17](https://git.door43.org/Door43/en_tn/src/master/2ti/03/16.md)
* [Mark 07:6-7](https://git.door43.org/Door43/en_tn/src/master/mrk/07/06.md)
* [Matthew 15:7-9](https://git.door43.org/Door43/en_tn/src/master/mat/15/07.md)

#### Word Data:####

* Strong's: H3948, H4148, H8052, G1319, G1322, G2085


---

<a id="donkey"/>

### donkey, mule ###

#### Definition: ####

A donkey is a four-legged work animal, similar to a horse, but smaller and with longer ears.

* A mule is the sterile offspring of a male donkey and a female horse.
* Mules are very strong animals and so they are valuable work animals.
* Both donkeys and mules are used for carrying burdens and people when traveling.
* In Bible times, kings would ride a donkey in times of peace, rather than a horse, which was used for times of war.
* Jesus rode into Jerusalem on a young donkey a week before he was crucified there.

(See also: [How to Translate Unknowns](https://git.door43.org/Door43/en_ta/src/master/translate/translate-unknown.md))

#### Bible References: ####

* [1 Kings 01:32-34](https://git.door43.org/Door43/en_tn/src/master/1ki/01/32.md)
* [1 Samuel 09:3-4](https://git.door43.org/Door43/en_tn/src/master/1sa/09/03.md)
* [2 Kings 04:21-22](https://git.door43.org/Door43/en_tn/src/master/2ki/04/21.md)
* [Deuteronomy 05:12-14](https://git.door43.org/Door43/en_tn/src/master/deu/05/12.md)
* [Luke 13:15-16](https://git.door43.org/Door43/en_tn/src/master/luk/13/15.md)
* [Matthew 21:1-3](https://git.door43.org/Door43/en_tn/src/master/mat/21/01.md)

#### Word Data:####

* Strong's: H860, H2543, H3222, H5895, H6167, H6501, H6505, H6506, H7409, G3678, G3688, G5268


---

<a id="doom"/>

### doom ###

#### Definition: ####

The term "doom" refers to a judgment of condemnation with no possibility of appeal or escape.

* As the nation of Israel was being taken captive into Babylon, the prophet Ezekiel said, "doom has come upon them."
* Depending on the context, this term could be translated as "disaster" or "punishment" or "hopeless ruin."

#### Bible References: ####

* [Ezekiel 07:5-7](https://git.door43.org/Door43/en_tn/src/master/ezk/07/05.md)
* [Ezekiel 30:8-9](https://git.door43.org/Door43/en_tn/src/master/ezk/30/08.md)
* [Isaiah 06:4-5](https://git.door43.org/Door43/en_tn/src/master/isa/06/04.md)
* [Psalms 092:6-7](https://git.door43.org/Door43/en_tn/src/master/psa/092/006.md)

#### Word Data:####

* Strong's: H1820, H3117, H6256, H6843, H8045


---

<a id="doorpost"/>

### doorpost ###

#### Definition: ####

The "doorpost" is a vertical beam on either side of a door, which supports the top of the door frame.

* Just before God helped the Israelites escape from Egypt, he instructed them to kill a lamb and put its blood on their doorposts.
* In the Old Testament, a slave who desired to serve his master the rest of his life would place his ear on the doorpost of his master's house to have a nail hammered through his ear into the doorpost.
* This could also be translated as "wooden post on either side of a door" or "sides of a wooden doorframe" or "wood beams on the sides of a doorway."

(See also: [Egypt](names.html#egypt), [Passover](kt.html#passover))

#### Bible References: ####

* [1 Kings 06:31-32](https://git.door43.org/Door43/en_tn/src/master/1ki/06/31.md)
* [Deuteronomy 11:20-21](https://git.door43.org/Door43/en_tn/src/master/deu/11/20.md)
* [Exodus 12:5-8](https://git.door43.org/Door43/en_tn/src/master/exo/12/05.md)
* [Isaiah 57:7-8](https://git.door43.org/Door43/en_tn/src/master/isa/57/07.md)

#### Word Data:####

* Strong's: H352, H4201


---

<a id="dove"/>

### dove, pigeon ###

#### Definition: ####

Doves and pigeons are two kinds of small, gray-brown birds that look similar. A dove is often thought of as being lighter in color, almost white.

* Some languages have two different names for them, while others use the same name for both.
* Doves and pigeons were used in sacrifices to God, especially for people who could not afford to buy a larger animal.
* A dove brought the leaf of an olive tree to Noah when the flood waters were going down.
* Doves sometimes symbolize purity, innocence, or peace.
* If doves or pigeons are not known in the language area where the translation is being done, this term could be translated as "a small grayish brown bird called a dove" or "a small gray or brown bird, similar to a (name of local bird)".
* If both a dove and a pigeon are referred to in the same verse, it is best to use two different words for these birds, if possible.

(See also: [How to Translate Unknowns](https://git.door43.org/Door43/en_ta/src/master/translate/translate-unknown.md))

(See also: [olive](#olive), [innocent](kt.html#innocent), [pure](kt.html#purify))

#### Bible References: ####

* [Genesis 08:8-9](https://git.door43.org/Door43/en_tn/src/master/gen/08/08.md)
* [Luke 02:22-24](https://git.door43.org/Door43/en_tn/src/master/luk/02/22.md)
* [Mark 01:9-11](https://git.door43.org/Door43/en_tn/src/master/mrk/01/09.md)
* [Matthew 03:16-17](https://git.door43.org/Door43/en_tn/src/master/mat/03/16.md)
* [Matthew 21:12-14](https://git.door43.org/Door43/en_tn/src/master/mat/21/12.md)

#### Word Data:####

* Strong's: H1469, H1686, H3123, H8449, G4058


---

<a id="dream"/>

### dream ###

#### Definition: ####

A dream is something that people see or experience in their minds while they are sleeping.

 * Dreams often seem like they are really happening, but they are not.
 * Sometimes God causes people to dream about something so they can learn from it. He may also speak directly to people in their dreams.
 * In the Bible, God gave special dreams to certain people to give them a message, often about something that would happen in the future.
 * A dream is different from a vision. Dreams happen while a person is asleep, but visions usually happen when a person is awake.

(See also: [vision](#vision))

#### Bible References: ####

* [Acts 02:16-17](https://git.door43.org/Door43/en_tn/src/master/act/02/16.md)
* [Daniel 01:17-18](https://git.door43.org/Door43/en_tn/src/master/dan/01/17.md)
* [Daniel 02:1-2](https://git.door43.org/Door43/en_tn/src/master/dan/02/01.md)
* [Genesis 37:5-6](https://git.door43.org/Door43/en_tn/src/master/gen/37/05.md)
* [Genesis 40:4-5](https://git.door43.org/Door43/en_tn/src/master/gen/40/04.md)
* [Matthew 02:13-15](https://git.door43.org/Door43/en_tn/src/master/mat/02/13.md)
* [Matthew 02:19-21](https://git.door43.org/Door43/en_tn/src/master/mat/02/19.md)

#### Examples from the Bible stories: ####

  __*[08:02](https://git.door43.org/Door43/en_tn/src/master/obs/08/02.md)__ Joseph's brothers hated him because their father loved him most and because Joseph had __dreamed__ that he would be their ruler.
  __*[08:06](https://git.door43.org/Door43/en_tn/src/master/obs/08/06.md)__ One night, the Pharaoh, which is what the Egyptians called their kings, had two __dreams__ that disturbed him greatly. None of his advisors could tell him the meaning of the __dreams__.
  __*[08:07](https://git.door43.org/Door43/en_tn/src/master/obs/08/07.md)__ God had given Joseph the ability to interpret __dreams__, so Pharaoh had Joseph brought to him from the prison. Joseph interpreted the __dreams__ for him and said, "God is going to send seven years of plentiful harvests followed by seven years of famine."
  __*[16:11](https://git.door43.org/Door43/en_tn/src/master/obs/16/11.md)__ So that night, Gideon went down to the camp and heard a Midianite soldier telling his friend about something he had __dreamed__. The man's friend said, "This __dream__ means that Gideon's army will defeat the Midianite army!"
  __*[23:01](https://git.door43.org/Door43/en_tn/src/master/obs/23/01.md)__ He (Joseph) did not want to shame her (Mary), so he planned to quietly divorce her. Before he could do that, an angel came and spoke to him in a __dream__.

#### Word Data:####

* Strong's: H1957, H2472, H2492, H2493, G1797, G1798, G3677


---

<a id="drinkoffering"/>

### drink offering ###

#### Definition: ####

A drink offering was a sacrifice to God that involved pouring wine on an altar. It was often offered together with a burnt offering and a grain offering.

* Paul refers to his life as being poured out like a drink offering. This means that he was totally dedicated to serving God and telling people about Jesus, even though he knew he would suffer and probably be killed because of that.
* Jesus' death on the cross was the ultimate drink offering, as his blood was poured out on the cross for our sins.

#### Translation Suggestions: ####

* Another way to translate this term could be "offering of grape wine."
* When Paul says he is being "poured out like an offering" this could also be translated as "I am completely committed to teaching God's message to people, just like an offering of wine is poured out completely on the altar."

(See also: [burnt offering](#burntoffering), [grain offering](#grainoffering))

#### Bible References: ####

* [Exodus 25:28-30](https://git.door43.org/Door43/en_tn/src/master/exo/25/28.md)
* [Ezekiel 45:16-17](https://git.door43.org/Door43/en_tn/src/master/ezk/45/16.md)
* [Genesis 35:14-15](https://git.door43.org/Door43/en_tn/src/master/gen/35/14.md)
* [Jeremiah 07:16-18](https://git.door43.org/Door43/en_tn/src/master/jer/07/16.md)
* [Numbers 05:15](https://git.door43.org/Door43/en_tn/src/master/num/05/15.md)

#### Word Data:####

* Strong's: H5257, H5261, H5262


---

<a id="drunk"/>

### drunk, drunkard ###

#### Facts: ####

The term "drunk" means to be intoxicated from drinking too much of an alcoholic beverage.

* A "drunkard" is a person who is often drunk. This kind of person could also be referred to as an "alcoholic."
* The Bible tells believers not to be drunk with alcoholic drinks, but to be controlled by God's Holy Spirit.
* The Bible teaches that drunkenness is unwise and influences a person to sin in other ways.
* Other ways to translate "drunk" could include "inebriated" or "intoxicated" or "having too much alcohol" or "filled with fermented drink."

(See also: [wine](#wine))

#### Bible References: ####

* [1 Corinthians 05:11-13](https://git.door43.org/Door43/en_tn/src/master/1co/05/11.md)
* [1 Samuel 25:36](https://git.door43.org/Door43/en_tn/src/master/1sa/25/36.md)
* [Jeremiah 13:12-14](https://git.door43.org/Door43/en_tn/src/master/jer/13/12.md)
* [Luke 07:33-35](https://git.door43.org/Door43/en_tn/src/master/luk/07/33.md)
* [Luke 21:34-35](https://git.door43.org/Door43/en_tn/src/master/luk/21/34.md)
* [Proverbs 23:19-21](https://git.door43.org/Door43/en_tn/src/master/pro/23/19.md)

#### Word Data:####

* Strong's: H5433, H5435, H7301, H7302, H7910, H7937, H7941, H7943, H8354, H8358, G3178, G3182, G3183, G3184, G3630, G3632


---

<a id="dung"/>

### dung, manure ###

#### Definition: ####

The term "dung" refers to human or animal solid waste, and is also called feces or excrement. When used as fertilizer for enriching the soil, it is called "manure."

* These terms can also be used figuratively to refer to something that is worthless or not important.
* Dried animal dung is often used for fuel.
* The expression "be like dung on the face of the earth" could be translated as "be scattered like worthless dung over the land."
* The "Dung Gate" in the South Wall of Jerusalem was probably the gate where garbage and trash were taken out of the city.

(See also: [gate](#gate))

#### Bible References: ####

* [1 Kings 14:9-10](https://git.door43.org/Door43/en_tn/src/master/1ki/14/09.md)
* [2 Kings 06:24-26](https://git.door43.org/Door43/en_tn/src/master/2ki/06/24.md)
* [Isaiah 25:9-10](https://git.door43.org/Door43/en_tn/src/master/isa/25/09.md)
* [Jeremiah 08:1-3](https://git.door43.org/Door43/en_tn/src/master/jer/08/01.md)

#### Word Data:####

* Strong's: H830, H1119, H1557, H1561, H1686, H1828, H6569, H6675, G906, G4657


---

<a id="eagle"/>

### eagle, eagles ###

#### Definition: ####

An eagle is a very large, powerful bird of prey that eats small animals such as fish, mice, snakes, and chickens.

* The Bible compares the speed and strength of an army to how fast and suddenly an eagle swoops down to catch its prey.
* Isaiah states that those who trust in the Lord will soar as an eagle does. This is figurative language used to describe the freedom and strength that comes from trusting and obeying God.
* In the book of Daniel, King Nebuchadnezzar's hair length was compared to the length of an eagle's feathers, which can be more than 50 centimeters long.

(See also: [Daniel](names.html#daniel), [free](#free), [Nebuchadnezzar](names.html#nebuchadnezzar), [power](kt.html#power))

(See also: [How to Translate Unknowns](https://git.door43.org/Door43/en_ta/src/master/translate/translate-unknown.md))

#### Bible References: ####

* [2 Samuel 01:23-24](https://git.door43.org/Door43/en_tn/src/master/2sa/01/23.md)
* [Daniel 07:4-5](https://git.door43.org/Door43/en_tn/src/master/dan/07/04.md)
* [Jeremiah 04:13-15](https://git.door43.org/Door43/en_tn/src/master/jer/04/13.md)
* [Leviticus 11:13-16](https://git.door43.org/Door43/en_tn/src/master/lev/11/13.md)
* [Revelation 04:7-8](https://git.door43.org/Door43/en_tn/src/master/rev/04/07.md)

#### Word Data:####

* Strong's: H5403, H5404, H7360, G105


---

<a id="earth"/>

### earth, earthen, earthly ###

#### Definition: ####

The term "earth" refers to the world that human beings live on, along with all other forms of life.

* "Earth" can also refer to the ground or soil that covers the land.
* This term is often used figuratively to refer to the people who live on the earth. (See: [metonymy](https://git.door43.org/Door43/en_ta/src/master/translate/figs-metonymy.md))
* The expressions "let the earth be glad" and "he will judge the earth" are examples of figurative uses of this term.
* The term "earthly" usually refers to physical things in contrast to spiritual things.

#### Translation Suggestions: ####

* This term can be translated by the word or phrase that the local language or nearby national languages use to refer to the planet earth on which we live.
* Depending on the context, "earth" could also be translated as "world" or "land" or "dirt" or "soil."
* When used figuratively, "earth" could be translated as "people on the earth" or "people living on earth" or "everything on earth."
* Ways to translate "earthly" could include "physical" or "things of this earth" or "visible."

(See also: [spirit](kt.html#spirit), [world](kt.html#world))

#### Bible References: ####

* [1 Kings 01:38-40](https://git.door43.org/Door43/en_tn/src/master/1ki/01/38.md)
* [2 Chronicles 02:11-12](https://git.door43.org/Door43/en_tn/src/master/2ch/02/11.md)
* [Daniel 04:35](https://git.door43.org/Door43/en_tn/src/master/dan/04/35.md)
* [Luke 12:51-53](https://git.door43.org/Door43/en_tn/src/master/luk/12/51.md)
* [Matthew 06:8-10](https://git.door43.org/Door43/en_tn/src/master/mat/06/08.md)
* [Matthew 11:25-27](https://git.door43.org/Door43/en_tn/src/master/mat/11/25.md)
* [Zechariah 06:5-6](https://git.door43.org/Door43/en_tn/src/master/zec/06/05.md)

#### Word Data:####

* Strong's: H127, H772, H776, H778, H2789, H3007, H3335, H6083, H7494, G1093, G1919, G2709, G2886, G3625, G3749, G4578, G5517


---

<a id="elder"/>

### elder, elders ###

#### Definition: ####

Elders are spiritually mature men who have responsibilities of spiritual and practical leadership among God's people.

* The term "elder" came from the fact that elders were originally older men who, because of their age and experience, had greater wisdom.
* In the Old Testament, the elders helped lead the Israelites in matters of social justice and the Law of Moses.
* In the New Testament, Jewish elders continued to be leaders in their communities and also were judges for the people.
* In the early Christian churches, Christian elders gave spiritual leadership to the local assemblies of believers.
* Elders in these churches included young men who were spiritually mature.
* This term could be translated as "older men" or "spiritually mature men leading the church."

#### Bible References: ####

* [1 Chronicles 11:1-3](https://git.door43.org/Door43/en_tn/src/master/1ch/11/01.md)
* [1 Timothy 03:1-3](https://git.door43.org/Door43/en_tn/src/master/1ti/03/01.md)
* [1 Timothy 04:14-16](https://git.door43.org/Door43/en_tn/src/master/1ti/04/14.md)
* [Acts 05:19-21](https://git.door43.org/Door43/en_tn/src/master/act/05/19.md)
* [Acts 14:23-26](https://git.door43.org/Door43/en_tn/src/master/act/14/23.md)
* [Mark 11:27-28](https://git.door43.org/Door43/en_tn/src/master/mrk/11/27.md)
* [Matthew 21:23-24](https://git.door43.org/Door43/en_tn/src/master/mat/21/23.md)

#### Word Data:####

* Strong's: H1419, H2205, H7868, G1087, G3187, G4244, G4245, G4850


---

<a id="endure"/>

### endure, endures, endured, enduring, endurance###

#### Definition: ####

The term "endure" means to last a long time or to bear something difficult with patience.

* It also means to stand firm when times of testing come, without giving up.
* The term "endurance" can mean "patience" or "bearing up under a trial" or "persevering when being persecuted."
* The encouragement to Christians to "endure to the end" is telling them to obey Jesus, even if this causes them to suffer.
* To "endure suffering" can also mean to "experience suffering."

#### Translation Suggestions: ####

* Ways to translate the term "endure" could include "persevere" or "keep believing" or "continue to do what God wants you to do" or "stand firm."
* In some contexts, to "endure" could be translated as to "experience" or to "go through."
* With the meaning of lasting for a long time, the term "endure" could also be tranlsated as "last" or "continue." The phrase "will not endure" could be translated as "will not last" or "will not continue to survive."
* Ways to translate "endurance" could include "perseverance" or "continuing to believe" or "remaining faithful."

(See also: [persevere](#perseverance))

#### Bible References: ####

* [2 Timothy 02:11-13](https://git.door43.org/Door43/en_tn/src/master/2ti/02/11.md)
* [James 01:1-3](https://git.door43.org/Door43/en_tn/src/master/jas/01/01.md)
* [James 01:12-13](https://git.door43.org/Door43/en_tn/src/master/jas/01/12.md)
* [Luke 21:16-19](https://git.door43.org/Door43/en_tn/src/master/luk/21/16.md)
* [Matthew 13:20-21](https://git.door43.org/Door43/en_tn/src/master/mat/13/20.md)
* [Revelation 01:9-11](https://git.door43.org/Door43/en_tn/src/master/rev/01/09.md)
* [Romans 05:3-5](https://git.door43.org/Door43/en_tn/src/master/rom/05/03.md)

#### Word Data:####

* Strong's: H386, H3201, H3557, H3885, H5331, H5375, H5975, G430, G907, G1526, G2005, G2076, G2553, G2594, G3114, G3306, G4722, G5278, G5281, G5297, G5342


---

<a id="enslave"/>

### enslave, enslaves, enslaved, bond, bondage, bonds, bound ###

#### Definition: ####

To "enslave" someone means to force that person to serve a master or a ruling country. To be "enslaved" or "in bondage" means to be under the control of something or someone.

* A person who is enslaved or in bondage must serve others without payment; he is not free to do what he wants.
* To "enslave" also means to take away a person's freedom.
* Another word for "bondage" is "slavery."
* In a figurative way, human beings are "enslaved" to sin until Jesus frees them from its control and power.
* When a person receives new life in Christ, he stops being a slave to sin and becomes a slave to righteousness.

#### Translation Suggestions: ####

* The term "enslave" could be translated as "cause to not be free" or "force to serve others" or "put under the control of others."
* The phrase "enslaved to" or "in bondage to" could be translated as "forced to be a slave of" or "forced to serve" or "under the control of."

(See also: [free](#free), [righteous](kt.html#righteous), [servant](#servant))

#### Bible References: ####

* [Galatians 04:3-5](https://git.door43.org/Door43/en_tn/src/master/gal/04/03.md)
* [Galatians 04:24-25](https://git.door43.org/Door43/en_tn/src/master/gal/04/24.md)
* [Genesis 15:12-13](https://git.door43.org/Door43/en_tn/src/master/gen/15/12.md)
* [Jeremiah 30:8-9](https://git.door43.org/Door43/en_tn/src/master/jer/30/08.md)

#### Word Data:####

* Strong's: H3533, H5647, G1398, G1402, G2615


---

<a id="envy"/>

### envy, covet ###

#### Definition: ####

The term "envy" refers to being jealous of someone because of what that person possesses or because of that person's admirable qualities. The term "covet" means to strongly desire to have something.
* Envy is normally a negative feeling of resentment because of another person's success, good fortune, or possessions.
* Coveting is a strong desire to have someone else's property, or even someone else's spouse.
(See also: [jealous](kt.html#jealous))

#### Bible References: ####

* [1 Corinthians 13:4-7](https://git.door43.org/Door43/en_tn/src/master/1co/13/04.md)
* [1 Peter 02:1-3](https://git.door43.org/Door43/en_tn/src/master/1pe/02/01.md)
* [Exodus 20:15-17](https://git.door43.org/Door43/en_tn/src/master/exo/20/15.md)
* [Mark 07:20-23](https://git.door43.org/Door43/en_tn/src/master/mrk/07/20.md)
* [Proverbs 03:31-32](https://git.door43.org/Door43/en_tn/src/master/pro/03/31.md)
* [Romans 01:29-31](https://git.door43.org/Door43/en_tn/src/master/rom/01/29.md)

#### Word Data:####

* Strong's: H183, H1214, H1215, H2530, H3415, H5869, H7065, H7068, G866, G1937, G2205, G2206, G3713, G3788, G4123, G4124, G4190, G5354, G5355, G5366


---

<a id="evildoer"/>

### evildoer, evildoers, evildoing ###

#### Definition: ####

The term "evildoer" is a general reference to people who do sinful and wicked things.

* It can also be a general word for people who do not obey God.
* This term could be translated using the word for "evil" or "wicked," with the word for "doing" or "making" or "causing" something.

(See also: [evil](kt.html#evil))

#### Bible References: ####

* [1 Peter 02:13-17](https://git.door43.org/Door43/en_tn/src/master/1pe/02/13.md)
* [Isaiah 09:16-17](https://git.door43.org/Door43/en_tn/src/master/isa/09/16.md)
* [Luke 13:25-27](https://git.door43.org/Door43/en_tn/src/master/luk/13/25.md)
* [Malachi 03:13-15](https://git.door43.org/Door43/en_tn/src/master/mal/03/13.md)
* [Matthew 07:21-23](https://git.door43.org/Door43/en_tn/src/master/mat/07/21.md)

#### Word Data:####

* Strong's: H205, H6213, H6466, H7451, H7489, G93, G458, G2038, G2040 , G2555


---

<a id="exile"/>

### exile, exiles, exiled ###

#### Definition: ####

The term "exile" refers to people being forced to live somewhere away from their home country.

* People are usually sent into exile for punishment or for political reasons.
* A conquered people may be taken into exile to the country of the conquering army, in order to work for them.
* The "Babylonian exile" (or "the exile") is a period in Bible history when many Jewish citizens of the region of Judah were taken from their homes and forced to live in Babylon. It lasted 70 years.
* The phrase "the exiles" refers to people who are living in exile, away from their home country.

#### Translation Suggestions: ####

* The term to "exile" could also be translated as to "send away" or to "force out" or to "banish."
* The term "the exile" could be translated with a word or phrase that means "the sent away time" or "the time of banishment" or "the time of forced absence" or "banishment."
* Ways to translate "the exiles" could include "the exiled people" or "the people who were banished" or "the people exiled to Babylon."

(See also: [Babylon](names.html#babylon), [Judah](names.html#kingdomofjudah))

#### Bible References: ####

* [2 Kings 24:13-14](https://git.door43.org/Door43/en_tn/src/master/2ki/24/13.md)
* [Daniel 02:25-26](https://git.door43.org/Door43/en_tn/src/master/dan/02/25.md)
* [Ezekiel 01:1-3](https://git.door43.org/Door43/en_tn/src/master/ezk/01/01.md)
* [Isaiah 20:3-4](https://git.door43.org/Door43/en_tn/src/master/isa/20/03.md)
* [Jeremiah 29:1-3](https://git.door43.org/Door43/en_tn/src/master/jer/29/01.md)

#### Word Data:####

* Strong's: H1123, H1473, H1540, H1541, H1546, H1547, H3212, H3318, H5080, H6808, H7617, H7622, H8689, G3927


---

<a id="exult"/>

### exult, exults, exulting, exultant ###

#### Definition: ####

The terms "exult" and "exultant" refer to being very happy because of a success or special blessing.

* To "exult" includes a feeling of celebrating something wonderful.
* A person can exult in God's goodness.
* The term "exultant" can also include being arrogant in one's feeling of gladness about success or prosperity.
* The term "exult" could also be translated as "celebrate joyfully" or "praise with great joy."
* Depending on the context, the term "exultant" could be translated as "praising triumphantly" or "celebrating with self praise" or "arrogant."

(See also: [arrogant](#arrogant), [joy](#joy), [praise](#praise), [rejoice](#joy))

#### Bible References: ####

* [1 Samuel 02:1](https://git.door43.org/Door43/en_tn/src/master/1sa/02/01.md)
* [Isaiah 13:1-3](https://git.door43.org/Door43/en_tn/src/master/isa/13/01.md)
* [Job 06:10-11](https://git.door43.org/Door43/en_tn/src/master/job/06/10.md)
* [Psalm 068:1-3](https://git.door43.org/Door43/en_tn/src/master/psa/068/001.md)
* [Zephaniah 02:15](https://git.door43.org/Door43/en_tn/src/master/zep/02/15.md)

#### Word Data:####

* Strong's: H5539, H5947, H5970


---

<a id="face"/>

### face, faces, faced, facing, facial, facedown ###

#### Definition: ####

The word "face" literally refers to the front part of a person's head. This term also has several figurative meanings.

* The expression "your face" is often a figurative way of saying "you." Similarly, the expression "my face" often means "I" or "me."
* In a physical sense, to "face" someone or something means to look in the direction of that person or thing.
* To "face each other" means to "look directly at each other."
* Being "face to face" means that two people are seeing each other in person, at a close distance.
* When Jesus "steadfastly set his face to go to Jerusalem," it means that he very firmly decided to go.
* To "set one's face against" people or a city means to firmly decide to no longer support, or to reject that city or person.
* The expression "face of the land" refers to the surface of the earth and often is a general reference to the whole earth. For example, a "famine covering the face of the earth" refers to a widespread famine affecting many people living on earth.
* The figurative expression "do not hide your face from your people" means "do not reject your people"  or "do not desert your people" or "do not stop taking care of your people." 

#### Translation Suggestions: ####

* If possible, it is best to keep the expression or use an expression in the project language that has a similar meaning. 
* The term to "face" could be translated as to "turn toward" or to "look at directly" or to "look at the face of."
* The expression "face to face" could be translated as "up close" or "right in front of" or "in the presence of."
* Depending on the context, the expression "before his face" could be translated as "ahead of him" or "in front of him" or "before him" or "in his presence."
* The expression "set his face toward" could be translated as "began traveling toward" or "firmly made up his mind to go to."
* The expression "hide his face from" could be translated as "turn away from" or "stop helping or protecting" or "reject." 
* To "set his face against" a city or people could be translated as "look at with anger and condemn" or "refuse to accept" or "decide to reject" or "condemn and reject" or "pass judgment on."
* The expression "say it to their face" could be translated as "say it to them directly" or "say it to them in their presence" or "say it to them in person."
* The expression "on the face of the land" could also be translated as "throughout the land" or "over the whole earth" or "living throughout the earth."

#### Bible References: ####

* [Deuteronomy 05:4-6](https://git.door43.org/Door43/en_tn/src/master/deu/05/04.md)
* [Genesis 33:9-11](https://git.door43.org/Door43/en_tn/src/master/gen/33/09.md)

#### Word Data:####

* Strong's: H600, H639, H5869, H6440, H8389, G3799, G4383, G4750


---

<a id="falseprophet"/>

### false prophet, false prophets ###

#### Definition: ####

A false prophet is a person who wrongly claims that his message comes from God.

* The prophecies of false prophets are not usually fulfilled. That is, they do not come true.
* False prophets teach messages that partially or totally contradict what the Bible says.
* This term could also be translated as "person who falsely claims to be God's spokesman" or "someone who falsely claims to speak God's words."
* The New Testament teaches that in the end times there will be many false prophets who will try to deceive people into thinking that they come from God.

(See also: [fulfill](kt.html#fulfill), [prophet](kt.html#prophet), [true](kt.html#true))

#### Bible References: ####

* [1 John 04:1-3](https://git.door43.org/Door43/en_tn/src/master/1jn/04/01.md)
* [2 Peter 02:1-3](https://git.door43.org/Door43/en_tn/src/master/2pe/02/01.md)
* [Acts 13:6-8](https://git.door43.org/Door43/en_tn/src/master/act/13/06.md)
* [Luke 06:26](https://git.door43.org/Door43/en_tn/src/master/luk/06/26.md)
* [Matthew 07:15-17](https://git.door43.org/Door43/en_tn/src/master/mat/07/15.md)
* [Matthew 24:23-25](https://git.door43.org/Door43/en_tn/src/master/mat/24/23.md)

#### Word Data:####

* Strong's: G5578


---

<a id="falsewitness"/>

### corrupt witness, false report, false testimony, false witness, false witnesses ###

#### Definition: ####

The terms "false witness" and "corrupt witness" refer to a person who says untrue things about a person or an event, usually in a formal setting such as a court.
 
* A "false testimony" or "false report" is the actual lie that is told.
* To "bear false witness" means to lie or give a false report about something.
* The Bible gives several accounts in which false witnesses were hired to lie about someone in order to have that person punished or killed.

#### Translation Suggestions: ####

* To "bear false witness" or "give a false testimony" could be translated as "testify falsely" or "give a false report about someone" or "speak falsely against someone" or "lie."
* When "false witness" refers to a person, it could be translated as "person who lies" or "one who testifies falsely" or "someone who says things that are not true."

(See also: [testimony](kt.html#testimony), [true](kt.html#true))

#### Bible References: ####

* [Deuteronomy 19:17-19](https://git.door43.org/Door43/en_tn/src/master/deu/19/17.md)
* [Exodus 20:15-17](https://git.door43.org/Door43/en_tn/src/master/exo/20/15.md)
* [Matthew 15:18-20](https://git.door43.org/Door43/en_tn/src/master/mat/15/18.md)
* [Matthew 19:18-19](https://git.door43.org/Door43/en_tn/src/master/mat/19/18.md)
* [Proverbs 14:5-6](https://git.door43.org/Door43/en_tn/src/master/pro/14/05.md)
* [Psalms 027:11-12](https://git.door43.org/Door43/en_tn/src/master/psa/027/011.md)

#### Word Data:####

* Strong's: H5707, H6030, H7650, H8267, G1965, G3144, G5571, G5575, G5576, G5577


---

<a id="family"/>

### family, families ###

#### Definition: ####

The term "family" refers to a group of people who are related by blood and usually includes a father, mother, and their children. It often also includes other relatives such as grandparents, grandchildren, uncles and aunts.

* The Hebrew family was a religious community passing on traditions through worship and instruction.
* Usually the father was the major authority of the family.
* Family could also include servants, concubines, and even foreigners.
* Some languages may have a broader word such as "clan" or "household" that would fit better in contexts where more than just parents and children are being referred to.
* The term "family" is also used to refer to people who are related spiritually, such as people who are part of God's family because they believe in Jesus.

(See also: [clan](#clan), [ancestor](#father), [house](#house))

#### Bible References: ####

* [1 Kings 08:1-2](https://git.door43.org/Door43/en_tn/src/master/1ki/08/01.md)
* [1 Samuel 18:17-18](https://git.door43.org/Door43/en_tn/src/master/1sa/18/17.md)
* [Exodus 01:20-22](https://git.door43.org/Door43/en_tn/src/master/exo/01/20.md)
* [Joshua 02:12-13](https://git.door43.org/Door43/en_tn/src/master/jos/02/12.md)
* [Luke 02:4-5](https://git.door43.org/Door43/en_tn/src/master/luk/02/04.md)

#### Word Data:####

* Strong's: H1, H251, H272, H504, H1004, H1121, H2233, H2859, H2945, H3187, H4138, H4940, H5387, H5712, G1085, G3614, G3624, G3965


---

<a id="famine"/>

### famine, famines ###

#### Definition: ####

The term "famine" refers to an extreme lack of food throughout a country or region, usually due to not enough rain.

* Food crops can fail from natural causes such as lack of rain, crop disease, or insects.
* Food shortages can also be caused by people, such as enemies who detroy crops.
* In the Bible, God often caused famine as a way to punish nations when they sinned against him.
* In Amos 8:11 the term "famine" is used figuratively to refer to a time when God punished his people by not speaking to them. This could be translated with the word for "famine" in your language, or with a phrase such as "extreme lack" or "severe deprivation."

#### Bible References: ####

* [1 Chronicles 21:11-12](https://git.door43.org/Door43/en_tn/src/master/1ch/21/11.md)
* [Acts 07:11-13](https://git.door43.org/Door43/en_tn/src/master/act/07/11.md)
* [Genesis 12:10-13](https://git.door43.org/Door43/en_tn/src/master/gen/12/10.md)
* [Genesis 45:4-6](https://git.door43.org/Door43/en_tn/src/master/gen/45/04.md)
* [Jeremiah 11:21-23](https://git.door43.org/Door43/en_tn/src/master/jer/11/21.md)
* [Luke 04:25-27](https://git.door43.org/Door43/en_tn/src/master/luk/04/25.md)
* [Matthew 24:6-8](https://git.door43.org/Door43/en_tn/src/master/mat/24/06.md)

#### Word Data:####

* Strong's: H3720, H7458, H7459, G3042


---

<a id="fast"/>

### fast, fasts, fasted, fasting, fastings ###

#### Definition: ####

The term to "fast" means to stop eating food for a period of time, such as for a day or more. Sometimes it also includes not drinking.

* Fasting can help people to focus on God and pray without being distracted by preparing food and eating.
* Jesus condemned the Jewish religious leaders for fasting for the wrong reasons. They fasted so that others would think they were righteous.
* Sometimes people fast because they are very sad or grieved about something.
* The verb to "fast" can also be translated as to "refrain from eating" or to "not eat."
* The noun "fast" could be translated as "time of not eating" or "time of abstaining from food."

(See also: [Jewish leaders](#jewishleaders))

#### Bible References: ####

* [1 Kings 21:8-10](https://git.door43.org/Door43/en_tn/src/master/1ki/21/08.md)
* [2 Chronicles 20:3-4](https://git.door43.org/Door43/en_tn/src/master/2ch/20/03.md)
* [Acts 13:1-3](https://git.door43.org/Door43/en_tn/src/master/act/13/01.md)
* [Jonah 03:4-5](https://git.door43.org/Door43/en_tn/src/master/jon/03/04.md)
* [Luke 05:33-35](https://git.door43.org/Door43/en_tn/src/master/luk/05/33.md)
* [Mark 02:18-19](https://git.door43.org/Door43/en_tn/src/master/mrk/02/18.md)
* [Matthew 06:16-18](https://git.door43.org/Door43/en_tn/src/master/mat/06/16.md)
* [Matthew 09:14-15](https://git.door43.org/Door43/en_tn/src/master/mat/09/14.md)

#### Examples from the Bible stories: ####

* __[25:01](https://git.door43.org/Door43/en_tn/src/master/obs/25/01.md)__ Immediately after Jesus was baptized, the Holy Spirit led him out into the wilderness, where he __fasted__  for forty days and forty nights.
* __[34:08](https://git.door43.org/Door43/en_tn/src/master/obs/34/08.md)__ "'For example, I __fast__  two times every week and I give you ten percent of all the money and goods that I receive.'"
* __[46:10](https://git.door43.org/Door43/en_tn/src/master/obs/46/10.md)__ One day, while the Christians at Antioch were __fasting__  and praying, the Holy Spirit said to them, "Set apart for me Barnabas and Saul to do the work I have called them to do."

#### Word Data:####

* Strong's: H2908, H5144, H6684, H6685, G777, G3521, G3522, G3523


---

<a id="father"/>

### ancestor, ancestors, father, fathers, fathered, fathering, forefather, forefathers, grandfather ###

#### Definition: ####

When used literally, the term "father" refers to a person's male parent. There are also several figurative uses of this term.

* The terms "father" and "forefather" are often used to refer to the male ancestors of a certain person or people group. This could also be translated a "ancestor" or "ancestral father."
* The expression "the father of" can figuratively refer to a person who is the leader a group of related people or the source of something. For example, in Genesis 4 "the father of all who live in tents" could mean, "the first clan leader of the first people who ever lived in tents."
* The apostle Paul figuratively called himself the "father" of those he had helped to become Christians through sharing the gospel with them. 

#### Translation Suggestions ####

* When talking about a father and his literal son, this term should be translated using the usual term to refer to a father in the language.
* "God the Father" should also be translated using the usual, common word for "father."
* When referring to forefathers, this term could be translated as "ancestors" or "ancestral fathers."
* When Paul refers to himself figuratively as a father to believers in Christ, this could be translated as "spiritual father" or "father in Christ."
* Sometimes the word "father" can be translated as "clan leader."
* The phrase "father of all lies" could be translated as "source of all lies" or "the one from whom all lies come."

(See also: [God the Father](kt.html#godthefather), [son](kt.html#son), [Son of God](kt.html#sonofgod))

#### Bible References: ####

* [Acts 07:1-3](https://git.door43.org/Door43/en_tn/src/master/act/07/01.md)
* [Acts 07:31-32](https://git.door43.org/Door43/en_tn/src/master/act/07/31.md)
* [Acts 07:44-46](https://git.door43.org/Door43/en_tn/src/master/act/07/44.md)
* [Acts 22:3-5](https://git.door43.org/Door43/en_tn/src/master/act/22/03.md)
* [Genesis 31:29-30](https://git.door43.org/Door43/en_tn/src/master/gen/31/29.md)
* [Genesis 31:41-42](https://git.door43.org/Door43/en_tn/src/master/gen/31/41.md)
* [Genesis 31:51-53](https://git.door43.org/Door43/en_tn/src/master/gen/31/51.md)
* [Hebrews 07:4-6](https://git.door43.org/Door43/en_tn/src/master/heb/07/04.md)
* [John 04:11-12](https://git.door43.org/Door43/en_tn/src/master/jhn/04/11.md)
* [Joshua 24:3-4](https://git.door43.org/Door43/en_tn/src/master/jos/24/03.md)
* [Malachi 03:6-7](https://git.door43.org/Door43/en_tn/src/master/mal/03/06.md)
* [Mark 10:7-9](https://git.door43.org/Door43/en_tn/src/master/mrk/10/07.md)
* [Matthew 01:7-8](https://git.door43.org/Door43/en_tn/src/master/mat/01/07.md)
* [Matthew 03:7-9](https://git.door43.org/Door43/en_tn/src/master/mat/03/07.md)
* [Matthew 10:21-23](https://git.door43.org/Door43/en_tn/src/master/mat/10/21.md)
* [Matthew 18:12-14](https://git.door43.org/Door43/en_tn/src/master/mat/18/12.md)
* [Romans 04:11-12](https://git.door43.org/Door43/en_tn/src/master/rom/04/11.md)

#### Word Data:####

* Strong's: H1, H2, H25, H369, H539, H1121, H1730, H1733, H2524, H3205, H3490, H4940, H5971, H7223, G256, G540, G1080, G2495, G3737, G3962, G3964, G3966, G3967, G3970, G3971, G3995, G4245, G4269, G4613


---

<a id="feast"/>

### feast, feasts, feasting ###

#### Definition: ####

The term "feast" refers to an event where a group of people eat a very large meal together, often for the purpose of celebrating something. The action to "feast" means to eat a large amount of food or to participate in eating a feast together.

* Often there are special kinds of food that are eaten at a certain feast.
* The religious festivals that God commanded the Jews to celebrate usually included having a feast together. For this reason the festivals are often called "feasts."
* In Bible times, kings and other rich and powerful people often gave feasts to entertain their family or friends.
* In the story about the lost son, the father had a special feast prepared to celebrate the return of his son.
* A feast sometimes lasted for several days or more.
* The term to "feast" could also be translated as to "eat lavishly" or to "celebrate by eating lots of food" or to "eat a special, large meal."
* Depending on the context, "feast" could be translated as "celebrating together with a large meal" or "a meal with a lot of food" or "a celebration meal."

(See also: [festival](#festival))

#### Bible References: ####

* [2 Peter 02:12-14](https://git.door43.org/Door43/en_tn/src/master/2pe/02/12.md)
* [Genesis 26:30-31](https://git.door43.org/Door43/en_tn/src/master/gen/26/30.md)
* [Genesis 29:21-22](https://git.door43.org/Door43/en_tn/src/master/gen/29/21.md)
* [Genesis 40:20-23](https://git.door43.org/Door43/en_tn/src/master/gen/40/20.md)
* [Jude 01:12-13](https://git.door43.org/Door43/en_tn/src/master/jud/01/12.md)
* [Luke 02:41-44](https://git.door43.org/Door43/en_tn/src/master/luk/02/41.md)
* [Luke 14:7-9](https://git.door43.org/Door43/en_tn/src/master/luk/14/07.md)
* [Matthew 22:1-3](https://git.door43.org/Door43/en_tn/src/master/mat/22/01.md)

#### Word Data:####

* Strong's: H398, H2077, H2282, H2287, H3899, H3900, H4150, H4580, H4797, H4960, H7646, H8057, H8354, G26, G755, G1062, G1173, G1403, G1456, G1858, G1859, G2165, G3521, G4910


---

<a id="fellowshipoffering"/>

### fellowship offering, fellowship offerings ###

#### Facts: ####

In the Old Testament, the "fellowship offering" was a kind of sacrifice that was offered for different reasons, such as to give thanks to God or to fulfill a vow. 

* This offering required the sacrifice of an animal that could be male or female. This was different from the burnt offering, which required a male animal.
* After giving a portion of the sacrifice to God, the person who brought the fellowship offering shared the meat with the priests and other Israelites.
* There was a meal associated with this offering which included unleavened bread.
* This is sometimes called the "peace offering."

(See also: [burnt offering](#burntoffering), [fulfill](kt.html#fulfill), [grain offering](#grainoffering), [guilt offering](#guiltoffering), [peace offering](#peaceoffering), [priest](kt.html#priest), [sacrifice](#sacrifice), [unleavened bread](kt.html#unleavenedbread), [vow](kt.html#vow))

#### Bible References: ####

* [1 Chronicles 21:25-27](https://git.door43.org/Door43/en_tn/src/master/1ch/21/25.md)
* [2 Chronicles 29:35-36](https://git.door43.org/Door43/en_tn/src/master/2ch/29/35.md)
* [Exodus 24:5-6](https://git.door43.org/Door43/en_tn/src/master/exo/24/05.md)
* [Leviticus 03:3-5](https://git.door43.org/Door43/en_tn/src/master/lev/03/03.md)
* [Numbers 06:13-15](https://git.door43.org/Door43/en_tn/src/master/num/06/13.md)

#### Word Data:####

* Strong's: H8002


---

<a id="festival"/>

### festival, festivals ###

#### Definition: ####

In general, a festival is a celebration held by a community of people.

* The word for "festival" in the Old Testament literally means "appointed time."
* The festivals celebrated by the Israelites were specially appointed times or seasons that God had commanded them to observe.
* In some English translations, the word "feast" is used instead of festival because the celebrations included having a large meal together.
* There were several main festivals that the Israelites celebrated every year:
   * Passover
   * Festival of Unleavened Bread
   * Firstfruits
   * Festival of Weeks (Pentecost)
   * Festival of Trumpets
   * Day of Atonement
   * Festival of Shelters
* The purpose of these festivals was to thank God and to remember the amazing things he had done to rescue, protect, and provide for his people.

(See also: [feast](#feast))

#### Bible References: ####

* [1 Chronicles 23:30-31](https://git.door43.org/Door43/en_tn/src/master/1ch/23/30.md)
* [2 Chronicles 08:12-13](https://git.door43.org/Door43/en_tn/src/master/2ch/08/12.md)
* [Exodus 05:1-2](https://git.door43.org/Door43/en_tn/src/master/exo/05/01.md)
* [John 04:43-45](https://git.door43.org/Door43/en_tn/src/master/jhn/04/43.md)
* [Luke 22:1-2](https://git.door43.org/Door43/en_tn/src/master/luk/22/01.md)

#### Word Data:####

* Strong's: H1974, H2166, H2282, H2287, H6213, H4150, G1456, G1858, G1859


---

<a id="fig"/>

### fig, figs ###

#### Definition: ####

A fig is a small, soft, sweet fruit that grows on trees. When ripe, this fruit can be a variety of colors, including brown, yellow, or purple.

* Fig trees can grow 6 meters in height and their large leaves provide pleasant shade. The fruit is about 3-5 centimeters long.
* Adam and Eve used the leaves from fig trees to make clothing for themselves after they had sinned.
* Figs can be eaten raw, cooked, or dried. People also chop them into small pieces and press them into cakes to eat later.
* In Bible times, figs were important as a source of food and income.
* The presence of fruitful fig trees is frequently mentioned in the Bible as a sign of prosperity.
* Several times Jesus used fig trees as an illustration to teach his disciples spiritual truths.

#### Bible References: ####

* [Habakkuk 03:17](https://git.door43.org/Door43/en_tn/src/master/hab/03/17.md)
* [James 03:11-12](https://git.door43.org/Door43/en_tn/src/master/jas/03/11.md)
* [Luke 13:6-7](https://git.door43.org/Door43/en_tn/src/master/luk/13/06.md)
* [Mark 11:13-14](https://git.door43.org/Door43/en_tn/src/master/mrk/11/13.md)
* [Matthew 07:15-17](https://git.door43.org/Door43/en_tn/src/master/mat/07/15.md)
* [Matthew 21:18-19](https://git.door43.org/Door43/en_tn/src/master/mat/21/18.md)

#### Word Data:####

* Strong's: H1061, H1690, H6291, H8384, G3653, G4808, G4810


---

<a id="fir"/>

### fir, firs ###

#### Definition: ####

A fir tree is a kind of tree that stays green all year and has cones that contain seeds. 

* Fir trees are also referred to as "evergreen" trees.
* In ancient times, the wood of fir trees was used for making musical instruments and for building structures such as boats, houses, and the temple.
* Some examples of fir trees mentioned in the Bible are pine, cedar, cypress, and juniper.

(See also: [How to Translate Unknowns](https://git.door43.org/Door43/en_ta/src/master/translate/translate-unknown.md))

(See also: [cedar](#cedar), [cypress](#cypress))

#### Bible References: ####

* [Ezekiel 27:4-5](https://git.door43.org/Door43/en_tn/src/master/ezk/27/04.md)
* [Isaiah 37:24-25](https://git.door43.org/Door43/en_tn/src/master/isa/37/24.md)
* [Isaiah 41:19-20](https://git.door43.org/Door43/en_tn/src/master/isa/41/19.md)
* [Isaiah 44:14](https://git.door43.org/Door43/en_tn/src/master/isa/44/14.md)
* [Isaiah 60:12-13](https://git.door43.org/Door43/en_tn/src/master/isa/60/12.md)
* [Psalms 104:16-18](https://git.door43.org/Door43/en_tn/src/master/psa/104/016.md)

#### Word Data:####

* Strong's: H766, H1265, H1266


---

<a id="fire"/>

### fire, fires, firebrands, firepans, fireplaces, firepot, firepots ###

#### Definition: ####

Fire is the heat, light, and flames that are produced when something is burned.

* Burning wood by fire turns the wood into ashes.
* The term "fire" is also used figuratively, usually referring to judgment or purification.
* The final judgment of unbelievers is in the fire of hell.
* Fire is used to refine gold and other metals. In the Bible, this process is used to explain how God refines people through difficult things that happen in their lives.
* The phrase "baptize with fire" could also be translated as "cause to experience suffering in order to be purified."

(See also: [pure](kt.html#purify))

#### Bible References: ####

* [1 Kings 16:18-20](https://git.door43.org/Door43/en_tn/src/master/1ki/16/18.md)
* [2 Kings 01:9-10](https://git.door43.org/Door43/en_tn/src/master/2ki/01/09.md)
* [2 Thessalonians 01:6-8](https://git.door43.org/Door43/en_tn/src/master/2th/01/06.md)
* [Acts 07:29-30](https://git.door43.org/Door43/en_tn/src/master/act/07/29.md)
* [John 15:5-7](https://git.door43.org/Door43/en_tn/src/master/jhn/15/05.md)
* [Luke 03:15-16](https://git.door43.org/Door43/en_tn/src/master/luk/03/15.md)
* [Matthew 03:10-12](https://git.door43.org/Door43/en_tn/src/master/mat/03/10.md)
* [Nehemiah 01:3](https://git.door43.org/Door43/en_tn/src/master/neh/01/03.md)

#### Word Data:####

* Strong's: H215, H217, H398, H784, H800, H801, H1197, H1200, H1513, H2734, H3341, H3857, H4071, H4168, H5135, H6315, H8316, G439, G440, G1067, G2741, G4442, G4443, G4447, G4448, G4451, G5394, G5457


---

<a id="firstborn"/>

### firstborn ###

#### Definition: ####

The term "firstborn" refers to an offspring of people or animals that is born first, before the other offspring are born.

* In the Bible, "firstborn" usually refers to the first male offspring that is born.
* In Bible times, the firstborn son was given a place of prominence and twice as much of his family inheritance as the other sons.
* Often it was the firstborn male of an animal that was sacrificed to God.
* This concept can also be used figuratively. For example, the nation of Israel is called God's firstborn son because God gave it special privileges over other nations.
* Jesus, the Son of God is called God's firstborn because of his importance and authority over everyone else.

#### Translation Suggestions: ####

* When "first-born" occurs in the text alone, it could also be translated as "firstborn male" or "firstborn son," since that is what is implied. (See: [Assumed Knowledge and Implicit Information](https://git.door43.org/Door43/en_ta/src/master/translate/figs-explicit.md))
* Other ways to translate this term could include  "the son who was born first" or "the eldest son" or "the number one son."
* When used figuratively to refer to Jesus, this could be translated with a word or phrase that means "the son who has authority over everything" or "the Son who is first in honor."
* Caution: Make sure the translation of this term in reference to Jesus does not imply that he was created.

(See also: [inherit](kt.html#inherit), [sacrifice](#sacrifice), [son](kt.html#son))

#### Bible References: ####

* [Colossians 01:15-17](https://git.door43.org/Door43/en_tn/src/master/col/01/15.md)
* [Genesis 04:3-5](https://git.door43.org/Door43/en_tn/src/master/gen/04/03.md)
* [Genesis 29:26-27](https://git.door43.org/Door43/en_tn/src/master/gen/29/26.md)
* [Genesis 43:32-34](https://git.door43.org/Door43/en_tn/src/master/gen/43/32.md)
* [Luke 02:6-7](https://git.door43.org/Door43/en_tn/src/master/luk/02/06.md)
* [Revelation 01:4-6](https://git.door43.org/Door43/en_tn/src/master/rev/01/04.md)

#### Word Data:####

* Strong's: H1060, H1062, H1067, H1069, G4416, G5207


---

<a id="firstfruit"/>

### firstfruits ###

#### Definition: ####

The term "firstfruits" refers to a portion of the first crop of fruits and vegetables that was reaped during each harvest season.

* The Israelites offered these first fruits to God as a sacrificial offering.
* This term is also used figuratively in the Bible to refer to a firstborn son as being the first fruits of the family. That is, because he was the first son to be born into that family, he was the one who carried on the family name and honor.
* Because Jesus rose from the dead, he is called the "firstfruits" of all believers in him, belivers who have died but who will some day come back to life.
* Believers in Jesus are also called the "firstfruits" of all creation, indicating the special privilege and position of those whom Jesus redeemed and called to be his people.

#### Translation Suggestions: ####

* The literal use of this term could be translated as "first portion (of crops)" or "first part of the harvest."
* If possible, the figurative uses should be translated literally, to allow for different meanings in different contexts. This will also show the correlation between the literal meaning and the figurative uses.

(See also: [firstborn](#firstborn))

#### Bible References: ####

* [2 Chronicles 31:4-5](https://git.door43.org/Door43/en_tn/src/master/2ch/31/04.md)
* [2 Thessalonians 02:13-15](https://git.door43.org/Door43/en_tn/src/master/2th/02/13.md)
* [Exodus 23:16-17](https://git.door43.org/Door43/en_tn/src/master/exo/23/16.md)
* [James 01:17-18](https://git.door43.org/Door43/en_tn/src/master/jas/01/17.md)
* [Jeremiah 02:1-3](https://git.door43.org/Door43/en_tn/src/master/jer/02/01.md)
* [Psalms 105:34-36](https://git.door43.org/Door43/en_tn/src/master/psa/105/034.md)

#### Word Data:####

* Strong's: H1061, H6529, H7225, G536


---

<a id="fisherman"/>

### fishermen, fishers ###

#### Definition: ####
Fishermen are men who catch fish from the water as a means of earning money. In the New Testament, the fishermen used large nets to catch fish. The term "fishers" is another name for fishermen.

* Peter and other apostles worked as fishermen before being called by Jesus.
* Since the land of Israel was near water, the Bible has many references to fish and fishermen.
* This term could be translated with a phrase such as "men who catch fish" or "men who earn money by catching fish."

#### Bible References: ####

* [Ezekiel 47:9-10](https://git.door43.org/Door43/en_tn/src/master/ezk/47/09.md)
* [Isaiah 19:7-8](https://git.door43.org/Door43/en_tn/src/master/isa/19/07.md)
* [Luke 05:1-3](https://git.door43.org/Door43/en_tn/src/master/luk/05/01.md)
* [Matthew 04:18-20](https://git.door43.org/Door43/en_tn/src/master/mat/04/18.md)
* [Matthew 13:47-48](https://git.door43.org/Door43/en_tn/src/master/mat/13/47.md)

#### Word Data:####

* Strong's: H1728, H1771, H2271, G231, G1903


---

<a id="flock"/>

### flocks, flock, flocking, herd, herds ###

#### Definition: ####

In the Bible, "flock" refers to a group of sheep or goats and "herd" refers to a group of cattle, oxen, or pigs.

 * Different languages may have different ways of naming groups of animals or birds.
 * For example, in English the term "herd" can also be used for sheep or goats, but in the Bible text it is not used this way.
 * The term "flock" in English is also used for a group of birds, but it can not be used for pigs, oxen, or cattle.
 * Consider what terms are used in your language to refer to different groups of animals.
 * For verses that refer to "flocks and herds" it may be better to add "of sheep" or "of cattle" for example, if the language does not have different words to refer to different kinds of animal groups.

(See also: [goat](#goat), [ox](#ox), [pig](#pig), [sheep](#sheep), )

#### Bible References: ####

* [1 Kings 10:28-29](https://git.door43.org/Door43/en_tn/src/master/1ki/10/28.md)
* [2 Chronicles 17:10-11](https://git.door43.org/Door43/en_tn/src/master/2ch/17/10.md)
* [Deuteronomy 14:22-23](https://git.door43.org/Door43/en_tn/src/master/deu/14/22.md)
* [Luke 02:8-9](https://git.door43.org/Door43/en_tn/src/master/luk/02/08.md)
* [Matthew 08:30-32](https://git.door43.org/Door43/en_tn/src/master/mat/08/30.md)
* [Matthew 26:30-32](https://git.door43.org/Door43/en_tn/src/master/mat/26/30.md)

#### Word Data:####

* Strong's: H951, H1241, H2835, H4029, H4735, H4830, H5349, H5739, H6251, H6629, H7399, H7462, G34, G4167, G4168


---

<a id="flood"/>

### flood, floods, flooded, flooding, floodwaters ###

#### Definition: ####

The term "flood" literally refers to a large amount of water that completely covers over the land. 

* This term is also used figuratively to refer to an overwhelming amount of something, especially something that happens suddenly.
* In Noah's time, people had become so evil that God caused a worldwide flood to come over the entire surface of the earth, even covering the mountaintops. Everyone who was not in the boat with Noah drowned. All other floods cover a much smaller land area.
* This term can also be an action, as in "the land was flooded by river water."

#### Translation Suggestions: ####

* Ways to translate the literal meaning of "flood" could include "an overflowing of water" or "large amounts of water."
* The figurative comparison "like a flood" could keep the literal term, or a substitute term could be used that refers to something that has a flowing aspect to it, such as a river.
* For the expression "like a flood of water" where water is already mentioned, the word "flood" could be translated as "an overwhelming amount" or "an overflowing."
* This term can be used as a metaphor, as in "do not let the flood sweep over me," which means "do not let these overwhelming disasters happen to me" or "don't let me be devastated by disasters" or "don't let your anger devastate me." (See: [Metaphor](https://git.door43.org/Door43/en_ta/src/master/translate/figs-metaphor.md))
* The figurative expression "I flood my bed with tears" could be translated as "my tears cover my bed with water like a flood."

(See also: [ark](kt.html#ark), [Noah](names.html#noah))

#### Bible References: ####

* [Daniel 11:10](https://git.door43.org/Door43/en_tn/src/master/dan/11/10.md)
* [Genesis 07:6-7](https://git.door43.org/Door43/en_tn/src/master/gen/07/06.md)
* [Luke 06:46-48](https://git.door43.org/Door43/en_tn/src/master/luk/06/46.md)
* [Matthew 07:24-25](https://git.door43.org/Door43/en_tn/src/master/mat/07/24.md)
* [Matthew 07:26-27](https://git.door43.org/Door43/en_tn/src/master/mat/07/26.md)
* [Matthew 24:37-39](https://git.door43.org/Door43/en_tn/src/master/mat/24/37.md)

#### Word Data:####

* Strong's: H216, H2229, H2230, H2975, H3999, H5104, H5140, H5158, H5674, H6556, H7641, H7857, H7858, H8241, G2627, G4132, G4215, G4216


---

<a id="flute"/>

### flute, flutes, pipe, pipes ###

#### Definition: ####

In Bible times, pipes were musical instruments made of bone or wood with holes to allow the sound to come out. A flute was a kind of pipe.

* Most pipes had reeds made out of a kind of thick grass that vibrated as air was blown over it.
* A pipe without any reeds was often called a "flute."
* A shepherd played a pipe to calm his flocks of sheep.
* Pipes and flutes were used for playing sad or joyful music.

(See also: [flock](#flock), [shepherd](#shepherd))

#### Bible References: ####

* [1 Corinthians 14:7-9](https://git.door43.org/Door43/en_tn/src/master/1co/14/07.md)
* [1 Kings 01:38-40](https://git.door43.org/Door43/en_tn/src/master/1ki/01/38.md)
* [Daniel 03:3-5](https://git.door43.org/Door43/en_tn/src/master/dan/03/03.md)
* [Luke 07:31-32](https://git.door43.org/Door43/en_tn/src/master/luk/07/31.md)
* [Matthew 09:23-24](https://git.door43.org/Door43/en_tn/src/master/mat/09/23.md)
* [Matthew 11:16-17](https://git.door43.org/Door43/en_tn/src/master/mat/11/16.md)

#### Word Data:####

* Strong's: H4953, H5748, H2485, H2490, G832, G834, G836


---

<a id="footstool"/>

### footstool ###

#### Definition: ####

The term "footstool" refers to an object which a person puts his feet on, usually to rest them while sitting. This term also has figurative meanings of submission and lower status.

* People in Bible times considered feet to be the least honorable parts of the body. So a "footstool" was of even lower honor because feet were rested on it.
* When God says "I will make my enemies a footstool for my feet" he is declaring power, control, and victory over the people who rebel against him. They will be humbled and conquered to the point of submitting to God's will.
* To "worship at God's footstool" means to bow down in worship before him as he sits on his throne. This again communicates humility and submission to God.
* David refers to the temple as God's "footstool." This could refer to his absolute authority over his people. This could also be picturing God the King on his throne, with his feet resting on his footstool, which represents all that is in submission to him.

#### Bible References: ####

* [Acts 07:47-50](https://git.door43.org/Door43/en_tn/src/master/act/07/47.md)
* [Isaiah 66:1](https://git.door43.org/Door43/en_tn/src/master/isa/66/01.md)
* [Luke 20:41-44](https://git.door43.org/Door43/en_tn/src/master/luk/20/41.md)
* [Matthew 05:33-35](https://git.door43.org/Door43/en_tn/src/master/mat/05/33.md)
* [Matthew 22:43-44](https://git.door43.org/Door43/en_tn/src/master/mat/22/43.md)
* [Psalm 110:1](https://git.door43.org/Door43/en_tn/src/master/psa/110/001.md)

#### Word Data:####

* Strong's: H1916, H3534, H7272, G4228, G5286


---

<a id="foreigner"/>

### alien, alienates, alienated, foreign, foreigner, foreigners ###

#### Definition: ####

The term "foreigner" refers to a person living in a country that is not his own. Another name for a foreigner is an "alien." 

* In the Old Testament, this term especially refers to anyone who came from a different people group than the people he was living among.
* A foreigner is also a person whose language and culture is different from those of a particular region.
* For example, when Naomi and her family moved to Moab, they were foreigners there. When Naomi and her daughter-in-law Ruth later moved to Israel, Ruth was called a "foreigner" there because she was not originally from Israel.
* The apostle Paul told the Ephesians that before they knew Christ, they were "foreigners" to God's covenant.
* Sometimes "foreigner" is translated as "stranger," but it should not refer only to someone who is unfamiliar or unknown.

#### Bible References: ####

* [2 Chronicles 02:17-18](https://git.door43.org/Door43/en_tn/src/master/2ch/02/17.md)
* [Acts 07:29-30](https://git.door43.org/Door43/en_tn/src/master/act/07/29.md)
* [Deuteronomy 01:15-16](https://git.door43.org/Door43/en_tn/src/master/deu/01/15.md)
* [Genesis 15:12-13](https://git.door43.org/Door43/en_tn/src/master/gen/15/12.md)
* [Genesis 17:24-27](https://git.door43.org/Door43/en_tn/src/master/gen/17/24.md)
* [Luke 17:17-19](https://git.door43.org/Door43/en_tn/src/master/luk/17/17.md)
* [Matthew 17:24-25](https://git.door43.org/Door43/en_tn/src/master/mat/17/24.md)

#### Word Data:####

* Strong's: H312, H628, H776, H1471, H1481, H1616, H2114, H3363, H3937, H4033, H5236, H5237, H5361, H6154, H8453, G241, G245, G526, G915, G1854, G3581, G3927, G3941


---

<a id="foreordain"/>

### foreknew, foreknowledge ###

#### Definition: ####

The terms "foreknew" and "foreknowledge" come from the verb "foreknow" which means to know something before it happens. 

* God is not limited by time. He knows everything that happens in the past, present, and future.
* This word is often used in the context of God knowing already who will be saved through receiving Jesus as Savior.

#### Translation Suggestions: ####

* The term "foreknew" could also be translated as, "knew before" or "knew ahead of time" or "knew beforehand" or "already knew."
* The term "foreknowledge" could be translated as, "knowing before" or "knowing ahead of time" or "already knowing" or "knowing in advance."

(See also: [know](#know), [predestine](kt.html#predestine))

#### Bible References: ####

* [Romans 08:28-30](https://git.door43.org/Door43/en_tn/src/master/rom/08/28.md)
* [Romans 11:1-3](https://git.door43.org/Door43/en_tn/src/master/rom/11/01.md)

#### Word Data:####

* Strong's: G4267, G4268


---

<a id="fornication"/>

### sexual immorality, immorality, immoral, fornication ###

#### Definition: ####

The term "sexual immorality" refers to sexual activity that takes place outside the marriage relationship of a man and a woman. This is against God's plan. Older English Bible versions call this "fornication."

* This term can refer to any kind of sexual activity that is against God's will, including homosexual acts and pornography.
* One type of sexual immorality is adultery, which is sexual activity specifically between a married person and someone who is not that person's spouse.
* Another type of sexual immorality is "prostitution," which involves being paid to have sex with someone.
* This term is also used figuratively to refer to Israel's unfaithfulness to God when they worshiped false gods.

#### Translation Suggestions: ####

* The term "sexual immorality" could be translated as "immorality" as long as the correct meaning of the term is understood.
* Other ways to translate this term could include "wrong sexual acts" or "sex outside of marriage."
* This term should be translated in a different way from the term "adultery."
* The translation of this term's figurative uses should retain the literal term if possible since there is a common comparison in the Bible between unfaithfulness to God and unfaithfulness in the sexual relationship.

(See also: [adultery](kt.html#adultery), [false god](kt.html#falsegod), [prostitute](#prostitute), [faithful](kt.html#faithful))

#### Bible References: ####

* [Acts 15:19-21](https://git.door43.org/Door43/en_tn/src/master/act/15/19.md)
* [Acts 21:25-26](https://git.door43.org/Door43/en_tn/src/master/act/21/25.md)
* [Colossians 03:5-8](https://git.door43.org/Door43/en_tn/src/master/col/03/05.md)
* [Ephesians 05:3-4](https://git.door43.org/Door43/en_tn/src/master/eph/05/03.md)
* [Genesis 38:24-26](https://git.door43.org/Door43/en_tn/src/master/gen/38/24.md)
* [Hosea 04:13-14](https://git.door43.org/Door43/en_tn/src/master/hos/04/13.md)
* [Matthew 05:31-32](https://git.door43.org/Door43/en_tn/src/master/mat/05/31.md)
* [Matthew 19:7-9](https://git.door43.org/Door43/en_tn/src/master/mat/19/07.md)

#### Word Data:####

* Strong's: H2181, H8457, G1608, G4202, G4203


---

<a id="foundation"/>

### found, founded, founder, foundation, foundations ###

#### Definition: ####

The verb "found" means build, create, or lay a base for. The phrase "founded on" means supported by or based on. A "foundation" is the base of support on which something is built or created.

* The foundation of a house or building must be strong and dependable in order to support the entire structure.
* The term "foundation" can also refer to the beginning of something or to the time when something was first created.
* In a figurative sense, believers in Christ are compared to a building that is founded on the teachings of the apostles and prophets, with Christ himself being the cornerstone of the building.
* A "foundation stone" was a stone that was laid as part of the foundation. These stones were tested to make sure they were strong enough to support an entire building.

#### Translation Suggestions: ####

* The phrase "before the foundation of the world" could be translated as "before the creation of the world" or "before the time when the world first existed" or "before everything was first created."
* The term "founded on" could be translated as "securely built on" or "firmly based on."
* Depending on the context, "foundation" could be translated as "strong base" or "solid support" or "beginning" or "creation."
(See also: [cornerstone](kt.html#cornerstone), [create](#creation))

#### Bible References: ####

* [1 Kings 06:37-38](https://git.door43.org/Door43/en_tn/src/master/1ki/06/37.md)
* [2 Chronicles 03:1-3](https://git.door43.org/Door43/en_tn/src/master/2ch/03/01.md)
* [Ezekiel 13:13-14](https://git.door43.org/Door43/en_tn/src/master/ezk/13/13.md)
* [Luke 14:28-30](https://git.door43.org/Door43/en_tn/src/master/luk/14/28.md)
* [Matthew 13:34-35](https://git.door43.org/Door43/en_tn/src/master/mat/13/34.md)
* [Matthew 25:34-36](https://git.door43.org/Door43/en_tn/src/master/mat/25/34.md)

#### Word Data:####

* Strong's: H134, H787, H803, H808, H2713, H3245, H3247, H3248, H4143, H4144, H4146, H4328, H4349, H4527, H6884, H8356, G2310, G2311, G2602


---

<a id="fountain"/>

### fountain, fountains, spring, springs, springing ###

#### Definition: ####

The terms "fountain" and "spring" usually refer to a large amount of water that flows out naturally from the ground.

* These words are also used figuratively in the Bible to refer to blessings flowing from God or to refer to something that cleanses and purifies.
* In modern times, a fountain is often a manmade object that has water flowing out of it, such as a drinking fountain. Make sure that the translation of this term refers to a natural source of flowing water.
* Compare the translation of this term with how the term "flood" is translated.

(See also: [flood](#flood))

#### Bible References: ####

* [2 Peter 02:17-19](https://git.door43.org/Door43/en_tn/src/master/2pe/02/17.md)
* [Genesis 07:11-12](https://git.door43.org/Door43/en_tn/src/master/gen/07/11.md)
* [Genesis 08:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/08/01.md)
* [Genesis 24:12-14](https://git.door43.org/Door43/en_tn/src/master/gen/24/12.md)
* [Genesis 24:42-44](https://git.door43.org/Door43/en_tn/src/master/gen/24/42.md)
* [James 03:11-12](https://git.door43.org/Door43/en_tn/src/master/jas/03/11.md)

#### Word Data:####

* Strong's: H794, H953, H1530, H1543, H1876, H3222, H4002, H4161, H4456, H4599, H4726, H5033, H5869, H5927, H6524, H6779, H6780, H7823, H8444, H8666, G242, G305, G393, G985, G1530, G1816, G4077, G4855, G5453


---

<a id="frankincense"/>

### frankincense ###

#### Definition: ####

Frankincense is a fragrant spice made from tree resin. It is used to make perfumes and incense.

* In Bible times, frankincense was an important spice used to prepare dead bodies for burial.
* This spice is also valuable for its healing and calming qualities.
* When learned men came from an eastern country to visit baby Jesus in Bethlehem, frankincense was one of the three gifts they brought him.

(See also: [Bethlehem](names.html#bethlehem), [learned men](#learnedmen))

#### Bible References: ####

* [1 Chronicles 09:28-29](https://git.door43.org/Door43/en_tn/src/master/1ch/09/28.md)
* [Exodus 30:34-36](https://git.door43.org/Door43/en_tn/src/master/exo/30/34.md)
* [Matthew 02:11-12](https://git.door43.org/Door43/en_tn/src/master/mat/02/11.md)
* [Numbers 05:15](https://git.door43.org/Door43/en_tn/src/master/num/05/15.md)

#### Word Data:####

* Strong's: H3828, G3030


---

<a id="free"/>

### free, frees, freed, freeing, freedom, freely, freeman, freewill, liberty ###

#### Definition: ####

The terms "free" or "freedom" refer to not being in slavery, or any other kind of bondage. Another word for "freedom" is "liberty."

* The expression to "set someone free" or to "free someone" means to provide a way for someone to no longer be in slavery or captivity.
* In the Bible, these terms are often used figuratively to refer to how a believer in Jesus is no longer under the power of sin.
* Having "liberty" or "freedom" can also refer to no longer being required to obey the Law of Moses, but instead being free to live by the teachings and guidance of the Holy Spirit.

#### Translation Suggestions: ####

* The term "free" could be translated with a word or phrase that means "not bound" or "not enslaved" or "not in slavery" or "not in bondage."
* The term "freedom" or "liberty" could be translated with a word or phrase that means "the state of being free" or "the condition of not being a slave" or "not being bound."
* The expression to "set free" could be translated as to "cause to be free" or to "rescue from slavery" or to "release from bondage."
* A person who has been "set free" has been "released" or "taken out of" bondage or slavery.

(See also: [bind](kt.html#bond), [enslave](#enslave), [servant](#servant))

#### Bible References: ####

* [Galatians 04:26-27](https://git.door43.org/Door43/en_tn/src/master/gal/04/26.md)
* [Galatians 05:1-2](https://git.door43.org/Door43/en_tn/src/master/gal/05/01.md)
* [Isaiah 61:1](https://git.door43.org/Door43/en_tn/src/master/isa/61/01.md)
* [Leviticus 25:10](https://git.door43.org/Door43/en_tn/src/master/lev/25/10.md)
* [Romans 06:17-18](https://git.door43.org/Door43/en_tn/src/master/rom/06/17.md)

#### Word Data:####

* Strong's: H1865, H2600, H2666, H2668, H2670, H3318, H4800, H5068, H5069, H5071, H5081, H5337, H5352, H5355, H5425, H5674, H5800, H6299, H6362, H7342, H7971, G425, G525, G558, G572, G629, G630, G859, G1344, G1432, G1657, G1658, G1659, G1849, G2010, G3032, G3089, G3955, G4174, G4506, G5483, G5486


---

<a id="freewilloffering"/>

### freewill offering, freewill offerings ###

#### Definition: ####

A freewill offering was a type of sacrifice to God that was not required by the Law of Moses. It was a person's own choice to give this offering.

* If the freewill offering was an animal to be sacrificed, the animal was permitted to have slight defects since it was a voluntary offering.
* The Israelites ate the sacrificed animal as part of a celebration feast.
* When a freewill offering could be given, this was a cause of rejoicing for Israel since it showed that the harvest had been good so that the people had plenty of food.
* The book of Ezra describes a different type of freewill offering that was brought for rebuilding the temple. This offering consisted of gold and silver money, as well as bowls and other objects made of gold and silver.

(See also: [burnt offering](#burntoffering), [Ezra](names.html#ezra), [feast](#feast), [grain offering](#grainoffering), [guilt offering](#guiltoffering), [law](kt.html#lawofmoses), [sin offering](#sinoffering))

#### Bible References: ####

* [1 Chronicles 29:6-7](https://git.door43.org/Door43/en_tn/src/master/1ch/29/06.md)
* [2 Chronicles 35:7-9](https://git.door43.org/Door43/en_tn/src/master/2ch/35/07.md)
* [Deuteronomy 12:17](https://git.door43.org/Door43/en_tn/src/master/deu/12/17.md)
* [Exodus 36:2-4](https://git.door43.org/Door43/en_tn/src/master/exo/36/02.md)
* [Leviticus 07:15-16](https://git.door43.org/Door43/en_tn/src/master/lev/07/15.md)

#### Word Data:####

* Strong's: H5068, H5071


---

<a id="fruit"/>

### fruit, fruits, fruitful, unfruitful ###

#### Definition: ####

The term "fruit" literally refers to the part of a plant that can be eaten. Something that is "fruitful" has a lot of fruit. These terms are also used figuratively in the Bible.

* The Bible often uses "fruit" to refer to a person's actions. Just as fruit on a tree shows what kind of tree it is, in the same way a person's words and actions reveal what his character is like.
* A person can produce good or bad spiritual fruit, but the term "fruitful" always has the positive meaning of producing much good fruit.
* The term "fruitful" is also used figuratively to mean "prosperous." This often refers to having many children and descendants, as well as having plenty of food and other wealth.
* In general, the expression "fruit of" refers to anything that comes from or that is produced by something else. For example, the "fruit of wisdom" refers to the good things that come from being wise.
* The expression "fruit of the land" refers generally to everything that the land produces for people to eat. This includes not only fruits such as grapes or dates, but also vegetables, nuts, and grains.
* The figurative expression "fruit of the Spirit" refers to godly qualities that the Holy Spirit produces in the lives of people who obey him.
* The expression "fruit of the womb" refers to "what the womb produces--"that is children.

#### Translation Suggestions: ####

* It is best to translate this term using the general word for "fruit" that is commonly used in the project language to refer to the edible fruit of a fruit tree. In many languages it may be more natural to use the plural ,"fruits" whenever it refers to more than one fruit.
* Depending on the context, the term "fruitful" could be translated as "producing much spiritual fruit" or "having many children" or "prosperous."
* The expression "fruit of the land" could also be translated as "food that the land produces" or "food crops that are growing in that region."
* When God created animals and people, he commanded them to "be fruitful and multiply," which refers to having many offspring. This could also be translated as "have many offspring" or "have many children and descendants" or "have many children so that you will have many descendants."
* The expression "fruit of the womb" could be translated as "what the womb produces" or "children a women gives birth to" or just "children." When Elizabeth says to Mary "blessed is the fruit of your womb," she means "blessed is the child you will give birth to." The project language may also have a different expression for this.
* Another expression "fruit of the vine," could be translated as "vine fruit" or "grapes."
* Depending on the context, the expression "will be more fruitful" could also be translated as "will produce more fruit" or "will have more children" or "will be prosperous."
* The apostle Paul's expression "fruitful labor" could be translated as "work that brings very good results" or "efforts that result in many people believing in Jesus."
* The "fruit of the Spirit" could also be translated as "works that the Holy Spirit produces" or "words and actions that show that the Holy Spirit is working in someone."

(See also: [descendant](#descendant), [grain](#grain), [grape](#grape), [Holy Spirit](kt.html#holyspirit), [vine](#vine), [womb](#womb))

#### Bible References: ####

* [Galatians 05:22-24](https://git.door43.org/Door43/en_tn/src/master/gal/05/22.md)
* [Genesis 01:11-13](https://git.door43.org/Door43/en_tn/src/master/gen/01/11.md)
* [Luke 08:14-15](https://git.door43.org/Door43/en_tn/src/master/luk/08/14.md)
* [Matthew 03:7-9](https://git.door43.org/Door43/en_tn/src/master/mat/03/07.md)
* [Matthew 07:15-17](https://git.door43.org/Door43/en_tn/src/master/mat/07/15.md)

#### Word Data:####

* Strong's: H3, H4, H1061, H1063, H1069, H2173, H2233, H2981, H3206, H3581, H3759, H3899, H3978, H4022, H4395, H5108, H5208, H6500, H6509, H6529, H7019, H8256, H8393, H8570, G1081, G2590, G2592, G2593, G3703, G5052, G5352, G6013


---

<a id="furnace"/>

### furnace ###

#### Facts: ####

A furnace was a very large oven used for heating objects to a high temperature.

* In ancient times, most furnaces were used for melting metals to make objects such as cooking pots, jewelry, weapons, and idols.
* Furnaces were also used in the making of clay pottery.
* Sometimes a furnace is referred to figuratively to explain that something is very hot.

(See also: [false god](kt.html#falsegod), [image](#image))

#### Bible References: ####

* [1 Kings 08:51-53](https://git.door43.org/Door43/en_tn/src/master/1ki/08/51.md)
* [Genesis 19:26-28](https://git.door43.org/Door43/en_tn/src/master/gen/19/26.md)
* [Proverbs 17:3-4](https://git.door43.org/Door43/en_tn/src/master/pro/17/03.md)
* [Psalms 021:9-10](https://git.door43.org/Door43/en_tn/src/master/psa/021/009.md)
* [Revelation 09:1-2](https://git.door43.org/Door43/en_tn/src/master/rev/09/01.md)

#### Word Data:####

* Strong's: H861, H3536, H3564, H5948, H8574, G2575


---

<a id="gate"/>

### gate, gates, gate bars, gatekeeper, gatekeepers, gateposts, gateway, gateways ###

#### Definition: ####

A "gate" is a hinged barrier at an access point in a fence or wall that surrounds a house or city. The "gate bar" refers to a wooden or metal bar that can be moved into place to lock the gate.

* A city gate could be opened to allow people, animals, and cargo to travel in and out of the city.
* To protect the city, its walls and gates were thick and strong. Gates were closed and locked with a metal or wooden bar to prevent enemy soldiers from entering the city.
* A city gate was often the news and social center of a village. It was also where business transactions occurred and judgments were made, because city walls were thick enough to have gateways that produced cool shade from the hot sun. Citizens found it pleasant to sit in the shade to conduct their business and even to judge legal cases.

#### Translation Suggestions: ####

* Depending on the context, other ways to translate "gate" could be "door" or "wall opening" or "barrier" or "entranceway."
* The phrase "bars of the gate" could be translated as "gate bolts" or "wooden beams to lock the gate" or "metal locking rods of the gate."

#### Bible References: ####

* [Acts 09:23-25](https://git.door43.org/Door43/en_tn/src/master/act/09/23.md)
* [Acts 10:17-18](https://git.door43.org/Door43/en_tn/src/master/act/10/17.md)
* [Deuteronomy 21:18-19](https://git.door43.org/Door43/en_tn/src/master/deu/21/18.md)
* [Genesis 19:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/19/01.md)
* [Genesis 24:59-60](https://git.door43.org/Door43/en_tn/src/master/gen/24/59.md)
* [Matthew 07:13-14](https://git.door43.org/Door43/en_tn/src/master/mat/07/13.md)

#### Word Data:####

* Strong's: H1817, H5592, H6607, H8179, H8651, G2374, G4439, G4440


---

<a id="generation"/>

### generation ###
UNDER REVIEW

#### Definition: ####

The term "generation" refers to a group of people who were all born around the same time period.

 * A generation can also refer to a span of time. In Bible times, a generation was usually considered to be about 40 years.
 * Parents and their children are from two different generations.
 * In the Bible, the term "generation" is also used figuratively to refer generally to people who share common characteristics. 

#### Translation Suggestions ####

 * The phrase "this generation" or "people of this generation" could be translated as "the people living now" or "you people."
 * "This wicked generation" could also be translated as "these wicked people living now."
 * The expression "from generation to generation" or "from one generation to the next" could be translated as "people living now, as well as their children and grandchildren" or "people in every time period" or "people in this time period and future time periods" or "all people and their descendants."
 * "A generation to come will serve him; they will tell the next generation about Yahweh" could also be translated as "Many people in the future will serve Yahweh and will tell their children and grandchildren about him."

(See also: [descendant](#descendant), [evil](kt.html#evil), [ancestor](#father))

#### Bible References: ####

* [Acts 15:19-21](https://git.door43.org/Door43/en_tn/src/master/act/15/19.md)
* [Exodus 03:13-15](https://git.door43.org/Door43/en_tn/src/master/exo/03/13.md)
* [Genesis 15:14-16](https://git.door43.org/Door43/en_tn/src/master/gen/15/14.md)
* [Genesis 17:7-8](https://git.door43.org/Door43/en_tn/src/master/gen/17/07.md)
* [Mark 08:11-13](https://git.door43.org/Door43/en_tn/src/master/mrk/08/11.md)
* [Matthew 11:16-17](https://git.door43.org/Door43/en_tn/src/master/mat/11/16.md)
* [Matthew 23:34-36](https://git.door43.org/Door43/en_tn/src/master/mat/23/34.md)
* [Matthew 24:34-35](https://git.door43.org/Door43/en_tn/src/master/mat/24/34.md)




---

<a id="giant"/>

### giant, giants ###

#### Definition: ####

The word "giant" usually refers to a person who is extremely tall and strong.

* Goliath, a Philistine soldier who fought David, was called a giant because he was a very tall, large, and strong man.
* The Israelite spies who explored the land of Canaan said that the people living there were like giants.

(See also: [Canaan](names.html#canaan), [Goliath](names.html#goliath), [Philistines](names.html#philistines))

#### Bible References: ####

* [Genesis 06:4](https://git.door43.org/Door43/en_tn/src/master/gen/06/04.md)
* [Numbers 13:32-33](https://git.door43.org/Door43/en_tn/src/master/num/13/32.md)

#### Word Data:####

* Strong's: H1368, H5303, H7497


---

<a id="gird"/>

### gird, girded ###

#### Definition: ####

The term "gird" means to fasten something around something else. It often refers to using a belt or sash around the waist to keep a robe or tunic in place. 

* The common biblical phrase, "gird up the loins" refers to tucking the bottom of a garment into a belt to allow a person to move more freely, usually to do work.
* This phrase can also mean "get ready to work" or to be prepared to do something difficult.
* The expression "gird up the loins" could be translated using an expression in the target language that has the same meaning. Or it could be translated figuratively as "prepare yourself for action" or "get yourself ready."
* The term "girded with" could be translated as "encircled by" or wrapped with" or "belted with."

(See also: [loins](#loins))

#### Bible References: ####

* [1 Peter 01:13-14](https://git.door43.org/Door43/en_tn/src/master/1pe/01/13.md)
* [Job 38:1-3](https://git.door43.org/Door43/en_tn/src/master/job/38/01.md)

#### Word Data:####

* Strong's: H247, H640, H2290, H2296, H8151, G328, G1241, G2224, G4024


---

<a id="glean"/>

### glean, gleans, gleaned, gleanings ###

#### Definition: ####

The term "glean" means to go through a field or orchard and pick up whatever grain or fruit the harvesters have left behind.

* God told the Israelites to let the widows, poor people, and foreigners glean the leftover grain in order to provide food for themselves.
* Sometimes the owner of the field would allow the gleaners to go directly behind the harvesters to glean, which enabled them to glean much more of the grain.
* A clear example of how this worked is in the story of Ruth, who was generously allowed to glean among the harvesters in the fields of her relative Boaz.
* Other ways to translate "glean" can be "pick up" or "gather" or "collect."

(See also: [Boaz](names.html#boaz), [grain](#grain), [harvest](#harvest), [Ruth](names.html#ruth))

#### Bible References: ####

* [Deuteronomy 24:21-22](https://git.door43.org/Door43/en_tn/src/master/deu/24/21.md)
* [Isaiah 17:4-5](https://git.door43.org/Door43/en_tn/src/master/isa/17/04.md)
* [Job 24:5-7](https://git.door43.org/Door43/en_tn/src/master/job/24/05.md)
* [Ruth 02:1-2](https://git.door43.org/Door43/en_tn/src/master/rut/02/01.md)
* [Ruth 02:15-16](https://git.door43.org/Door43/en_tn/src/master/rut/02/15.md)

#### Word Data:####

* Strong's: H3950, H3951, H5953, H5955

---

<a id="goat"/>

### goat, goats, goatskins, scapegoat, kids ###

#### Definition: ####

A goat is a medium-sized, four-legged animal which is similar to a sheep and is raised primarily for its milk and meat. A baby goat is called a "kid."

* Like sheep, goats were important animals of sacrifice, especially at Passover.
* Although goats and sheep can be very similar, these are some ways that they are different:
   * Goats have coarse hair; sheep have wool.
   * The tail of a goat stands up; the tail of a sheep hangs down.
   * Sheep usually like to stay with their herd, but goats are more independent and tend to wander away from their herd.
* In Bible times, goats were often the main source of milk in Israel.
* Goat skins were used for tent coverings and to make bags for holding wine.
* In both the Old and New Testaments, the goat was used as a symbol for unrighteous people, perhaps because of its tendency to wander away from the one taking care of it.
* The Israelites also used goats as symbolic sin bearers. When one goat was sacrificed, the priest would lay his hands on a second, live goat, and send it into the desert as a symbol that the animal was bearing the people's sins.

(See also: [flock](#flock), [sacrifice](#sacrifice), [sheep](#sheep), [righteous](kt.html#righteous), [wine](#wine))

#### Bible References: ####

* [Exodus 12:3-4](https://git.door43.org/Door43/en_tn/src/master/exo/12/03.md)
* [Genesis 30:31-32](https://git.door43.org/Door43/en_tn/src/master/gen/30/31.md)
* [Genesis 31:10-11](https://git.door43.org/Door43/en_tn/src/master/gen/31/10.md)
* [Genesis 37:31-33](https://git.door43.org/Door43/en_tn/src/master/gen/37/31.md)
* [Leviticus 03:12-14](https://git.door43.org/Door43/en_tn/src/master/lev/03/12.md)
* [Matthew 25:31-33](https://git.door43.org/Door43/en_tn/src/master/mat/25/31.md)

#### Word Data:####

* Strong's: H689, H1423, H1429, H1601, H3277, H3629, H5795, H5796, H6260, H6629, H6842, H6939, H7716, H8163, H8166, H8495, G122, G2055, G2056, G5131


---

<a id="gold"/>

### gold, golden ###

#### Definition: ####

Gold is a yellow, high quality metal that was used for making jewelry and religious objects. It was the most valuable metal in ancient times.

* In Bible times, many different kinds of objects were made out of solid gold or were covered with a thin layer of gold.
* These objects included earrings and other jewelry, and idols, altars, and other objects used in the tabernacle or temple, such as the ark of the covenant.
* In Old Testament times, gold was used as a means of exchange in buying and selling. It was weighed on a scale to determine its value.
* Later on, gold and other metals such as silver were used to make coins to use in buying and selling
* When referring to something that is not solid gold, but only has a thin covering of gold, the term "golden" or "gold-covered" or "gold-overlaid" could also be used.
* Sometimes an object is described as "gold-colored," which means it has the yellow color of gold, but may not actually be made of gold.

(See also: [altar](kt.html#altar), [ark of the covenant](kt.html#arkofthecovenant), [false god](kt.html#falsegod), [silver](#silver), [tabernacle](kt.html#tabernacle), [temple](kt.html#temple))

#### Bible References: ####

* [1 Peter 01:6-7](https://git.door43.org/Door43/en_tn/src/master/1pe/01/06.md)
* [1 Timothy 02:8-10](https://git.door43.org/Door43/en_tn/src/master/1ti/02/08.md)
* [2 Chronicles 01:14-15](https://git.door43.org/Door43/en_tn/src/master/2ch/01/14.md)
* [Acts 03:4-6](https://git.door43.org/Door43/en_tn/src/master/act/03/04.md)
* [Daniel 02:31-33](https://git.door43.org/Door43/en_tn/src/master/dan/02/31.md)

#### Word Data:####

* Strong's: H1220, H1222, H1722, H2091, H2742, H3800, H4062, H5458, H6884, H6885, G5552, G5553, G5554, G5557


---

<a id="gossip"/>

### gossip, gossips, gossiper ###

#### Definition: ####

The term "gossip" refers to talking to people about someone else's personal affairs, usually in a negative and unproductive way. Often what is talked about has not been confirmed as true.

* The Bible says that spreading negative information about people is wrong. Gossip and slander are examples of this kind of negative speech.
* Gossip is harmful to the person being spoken about because it often hurts someone's relationships with other people.
  

(See also: [slander](#slander))

#### Bible References: ####

* [1 Timothy 05:11-13](https://git.door43.org/Door43/en_tn/src/master/1ti/05/11.md)
* [2 Corinthians 12:20-21](https://git.door43.org/Door43/en_tn/src/master/2co/12/20.md)
* [Leviticus 19:15-16](https://git.door43.org/Door43/en_tn/src/master/lev/19/15.md)
* [Proverbs 16:27-28](https://git.door43.org/Door43/en_tn/src/master/pro/16/27.md)
* [Romans 01:29-31](https://git.door43.org/Door43/en_tn/src/master/rom/01/29.md)

#### Word Data:####

* Strong's: H5372, H7400, G2636, G2637, G5397

---

<a id="governor"/>

### govern, government, governments, governor, governors, proconsul, proconsuls ###

#### Definition: ####

A "governor" is a person who rules over a state, region, or territory. To "govern" means to guide, lead, or manage them.

* The term "proconsul" was a more specific title for a governor who ruled over a Roman province.
* In Bible times, governors were appointed by a king or emperor and were under his authority.
* A "government" consists of all the rulers who govern a certain country or empire. These rulers make laws that guide the behavior of their citizens so that there is peace, safety, and prosperity for all the people of that nation.

#### Translation Suggestions: ####

* The word "governor" can also be translated as "ruler" or "overseer" or "regional leader" or "one who rules over a small territory."
* Depending on the context, the term "govern" could also be translated as, "rule over" or "lead" or "manage" or supervise."
* The term "governor" should be translated differently than the terms for "king" or "emperor", since a governor was a less powerful ruler who was under their authority.
* The term "proconsul" could also be translated as, "Roman governor" or "Roman provincial ruler."

(See also: [authority](kt.html#authority), [king](#king), [power](kt.html#power), [province](#province), [Rome](names.html#rome), [ruler](#ruler))

#### Bible References: ####

* [Acts 07:9-10](https://git.door43.org/Door43/en_tn/src/master/act/07/09.md)
* [Acts 23:22-24](https://git.door43.org/Door43/en_tn/src/master/act/23/22.md)
* [Acts 26:30-32](https://git.door43.org/Door43/en_tn/src/master/act/26/30.md)
* [Mark 13:9-10](https://git.door43.org/Door43/en_tn/src/master/mrk/13/09.md)
* [Matthew 10:16-18](https://git.door43.org/Door43/en_tn/src/master/mat/10/16.md)
* [Matthew 27:1-2](https://git.door43.org/Door43/en_tn/src/master/mat/27/01.md)

#### Word Data:####

* Strong's: H324, H1777, H2142, H2280, H2710, H4951, H5148, H5460, H6346, H6347, H6486, H6664, H7989, H8269, H8660, G445, G446, G746, G1481, G2232, G2233, G2230, G4232


---

<a id="grain"/>

### grain, grains, grainfields ###

#### Definition: ####

The term "grain" usually refers to the seed of a food plant such as wheat, barley, corn, millet, or rice. It can also refer to the whole plant.

* In the Bible, the main grains that are referred to are wheat and barley.
* A head of grain is the part of the plant that holds the grain.
* Note that some older Bible versions use the word "corn" to refer to grain in general. In modern English however, "corn" only refers to one type of grain.

(See also: [head](#head), [wheat](#wheat))

#### Bible References: ####

* [Genesis 42:1-4](https://git.door43.org/Door43/en_tn/src/master/gen/42/01.md)
* [Genesis 42:26-28](https://git.door43.org/Door43/en_tn/src/master/gen/42/26.md)
* [Genesis 43:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/43/01.md)
* [Luke 06:1-2](https://git.door43.org/Door43/en_tn/src/master/luk/06/01.md)
* [Mark 02:23-24](https://git.door43.org/Door43/en_tn/src/master/mrk/02/23.md)
* [Matthew 13:7-9](https://git.door43.org/Door43/en_tn/src/master/mat/13/07.md)
* [Ruth 01:22](https://git.door43.org/Door43/en_tn/src/master/rut/01/22.md)

#### Word Data:####

* Strong's: H1250, H1430, H1715, H2233, H2591, H3759, H3899, H7054, H7383, H7641, H7668, G248, G2590, G3450, G4621, G4719


---

<a id="grainoffering"/>

### grain offering, grain offerings ###

#### Definition: ####

A grain offering was a gift of wheat or barley flour offered to God, often after a burnt offering.

* The grain used for the grain offering had to be finely ground up. Sometimes it was cooked before being offered, but other times it was left uncooked.
* Oil and salt were added to the grain flour, but no yeast or honey was permitted.
* Part of the grain offering was burned up and part of it was eaten by the priests.

(See also: [burnt offering](#burntoffering), [guilt offering](#guiltoffering) , [sacrifice](#sacrifice), [sin offering](#sinoffering))

#### Bible References: ####

* [1 Chronicles 23:27-29](https://git.door43.org/Door43/en_tn/src/master/1ch/23/27.md)
* [Exodus 29:41-42](https://git.door43.org/Door43/en_tn/src/master/exo/29/41.md)
* [Judges 13:19-20](https://git.door43.org/Door43/en_tn/src/master/jdg/13/19.md)
* [Leviticus 02:1-3](https://git.door43.org/Door43/en_tn/src/master/lev/02/01.md)

#### Word Data:####

* Strong's: H4503, H8641


---

<a id="grape"/>

### grape, grapes, grapevine ###

#### Definition: ####

A grape is a small, round, smooth-skinned berry fruit that grows in clusters on vines. The juice of grapes is used in making wine.

 * There are different colors of grapes, such as light green, purple, or red.
 * Individiual grapes can be around one to three centimeters in size.
 * People grow grapes in gardens called vineyards. These normally consist of long rows of vines.
 * Grapes were a very important food during Bible times and having vineyards was a sign of wealth.
 * In order to keep grapes from rotting, people would often dry them. Dried grapes are called "raisins" and they were used to make raisin cakes.
 * Jesus told a parable about a grape vineyard to teach his disciples about God's kingdom.

(See also: [vine](#vine), [vineyard](#vineyard), [wine](#wine))

#### Bible References: ####

* [Deuteronomy 23:24-25](https://git.door43.org/Door43/en_tn/src/master/deu/23/24.md)
* [Hosea 09:10](https://git.door43.org/Door43/en_tn/src/master/hos/09/10.md)
* [Job 15:31-33](https://git.door43.org/Door43/en_tn/src/master/job/15/31.md)
* [Luke 06:43-44](https://git.door43.org/Door43/en_tn/src/master/luk/06/43.md)
* [Matthew 07:15-17](https://git.door43.org/Door43/en_tn/src/master/mat/07/15.md)
* [Matthew 21:33-34](https://git.door43.org/Door43/en_tn/src/master/mat/21/33.md)

#### Word Data:####

* Strong's: H811, H891, H1154, H1155, H1210, H2490, H3196, H5563, H5955, H6025, H6528, G288, G4718



---

<a id="groan"/>

### groan, groans, groaned, groaning, groanings ###

#### Definition: ####

The term to "groan" refers to the uttering of a deep, low sound that is caused by physical or emotional distress. It could also be the sound someone makes without any words.

* A person can groan because of feeling grief.
* Groaning can be caused by feeling a terrible, oppressive burden.
* Other ways to translate "groan" could include, "give a low cry of pain" or "grieve deeply."
* As a noun, this could be translated as, "a low cry of distress" or "a deep murmur of pain."

(See also: [cry](#cry))

#### Bible References: ####

* [2 Corinthians 05:1-3](https://git.door43.org/Door43/en_tn/src/master/2co/05/01.md)
* [Hebrews 13:15-17](https://git.door43.org/Door43/en_tn/src/master/heb/13/15.md)
* [Job 23:1-2](https://git.door43.org/Door43/en_tn/src/master/job/23/01.md)
* [Psalms 032:3-4](https://git.door43.org/Door43/en_tn/src/master/psa/032/003.md)
* [Psalms 102:5-6](https://git.door43.org/Door43/en_tn/src/master/psa/102/005.md)

#### Word Data:####

* Strong's: H584, H585, H602, H603, H1901, H1993, H5008, H5009, H5098, H5594, H7581, G1690, G4726, G4727, G4959


---

<a id="guiltoffering"/>

### guilt offering, guilt offerings ###

#### Definition: ####

A guilt offering was an offering or sacrifice that God required an Israelite to make if he had accidentally did something wrong such as disrespect God or damage another person's property.

* This offering involved the sacrifice of an animal and the payment of a fine, with silver or gold money.
* In addition, the person at fault was responsible to pay for any damage that was done.

(See also: [burnt offering](#burntoffering), [grain offering](#grainoffering), [sacrifice](#sacrifice), [sin offering](#sinoffering))

#### Bible References: ####

* [1 Samuel 06:3-4](https://git.door43.org/Door43/en_tn/src/master/1sa/06/03.md)
* [2 Kings 12:15-16](https://git.door43.org/Door43/en_tn/src/master/2ki/12/15.md)
* [Leviticus 05:5-6](https://git.door43.org/Door43/en_tn/src/master/lev/05/05.md)
* [Numbers 06:12](https://git.door43.org/Door43/en_tn/src/master/num/06/12.md)

#### Word Data:####

* Strong's: H817


---

<a id="hail"/>

### hail, hails, hailstones, hailstorm ###

#### Facts: ####

This term usually refers to lumps of frozen water that fall from the sky. Although spelled the same way in English, a different word, "hail" is used in greeting someone and can mean, "hello" or "greetings to you."

* Hail that comes down from the sky is in the form of balls or chunks of ice called "hailstones."
* Usually hailstones are small (only a few centimeters wide), but sometimes there are hailstones that are as big as 20 centimeters wide and that weigh over a kilogram.
* The book of Revelation in the New Testament describes enormous hailstones weighing 50 kilograms that God will cause to fall on earth when he judges people for their wickedness in the end times.
* The word "hail" that is a formal greeting in older English literally means "rejoice" and could be translated as "Greetings!" or "Hello!" 

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_ta/src/master/translate/translate-names.md))

#### Bible References: ####

* [Matthew 27:27-29](https://git.door43.org/Door43/en_tn/src/master/mat/27/27.md)
* [Matthew 28:8-10](https://git.door43.org/Door43/en_tn/src/master/mat/28/08.md)
* [Psalms 078:47-49](https://git.door43.org/Door43/en_tn/src/master/psa/078/047.md)
* [Psalms 148:7-8](https://git.door43.org/Door43/en_tn/src/master/psa/148/007.md)
* [Revelation 08:6-7](https://git.door43.org/Door43/en_tn/src/master/rev/08/06.md)

#### Word Data:####

* Strong's: H68, H417, H1258, H1259, G5463, G5464


---

<a id="hand"/>

### hand, hands, handed, handing, by the hand of, lay a hand on, lays his hand on, right hand, right hands, from the hand of ###

#### Definition: ####

There are several figurative ways that "hand" is used in the Bible:

* To "hand" something to someone means to put something into that person's hands.
* The term "hand" is often used in reference to God's power and action, such as when God says "Has not my hand made all these things?" (See: [metonymy](https://git.door43.org/Door43/en_ta/src/master/translate/figs-metonymy.md))
* Expressions such as "hand over to" or "deliver into the hands of" refer to causing someone to be under the control or power of someone else.
* Some other figurative uses of "hand" include:
   * To "lay a hand on" means to "harm."
   * To "save from the hand of" means to stop someone from harming someone else.
   * The position of being "on the right hand" means "on the right side" or "to the right."
   * The expression "by the hand of" someone means "by" or "through" the action of that person. For example, "by the hand of the Lord" means that the Lord is the one who caused something to happen.
 
* Placing hands on someone is often done while speaking a blessing over that person.
* The term "laying on of hands" refers to placing a hand on a person in order to dedicate that person to God's service or to pray for healing.
* When Paul says "written by my hand," it means that this part of the letter was physically written down by him, rather than spoken to someone else to write down.

#### Translation Suggestions ####

* These expressions and other figures of speech could be translated using other figurative expressions that have the same meaning. Or the meaning could be translated using direct, literal language (see examples above).
* The expression "handed him the scroll" could also be translated as "gave him the scroll" or "put the scroll in his hand." It was not given to him permanently, but just for the purpose of using it at that time.
* When "hand" refers to the person, such as in "the hand of God did this," it could be translated as "God did this."
* An expression such as "delivered them into the hands of their enemies" or "handed them over to their enemies," could be translated as, "allowed their enemies to conquer them" or "caused them to be captured by their enemies" or "empowered their enemies to gain control over them."
* To "die by the hand of" could be translated as "be killed by."
* The expression "on the right hand of" could be translated as "on the right side of."
* In regard to Jesus being "seated at the right hand of God," if this does not communicate in the language that it refers to a position of high honor and equal authority, a different expression with that meaning could be used. Or a short explanation could be added: "on the right side of God, in the position of highest authority."

(See also: [adversary](#adversary), [bless](kt.html#bless), [captive](#captive), [honor](kt.html#honor), [power](kt.html#power))

#### Bible References: ####

* [Acts 07:22-25](https://git.door43.org/Door43/en_tn/src/master/act/07/22.md)
* [Acts 08:14-17](https://git.door43.org/Door43/en_tn/src/master/act/08/14.md)
* [Acts 11:19-21](https://git.door43.org/Door43/en_tn/src/master/act/11/19.md)
* [Genesis 09:5-7](https://git.door43.org/Door43/en_tn/src/master/gen/09/05.md)
* [Genesis 14:19-20](https://git.door43.org/Door43/en_tn/src/master/gen/14/19.md)
* [John 03:34-36](https://git.door43.org/Door43/en_tn/src/master/jhn/03/34.md)
* [Mark 07:31-32](https://git.door43.org/Door43/en_tn/src/master/mrk/07/31.md)
* [Matthew 06:3-4](https://git.door43.org/Door43/en_tn/src/master/mat/06/03.md)

#### Word Data:####

* Strong's: H405, H2026, H2651, H2947, H2948, H3027, H3028, H3225, H3231, H3233, H3709, H7126, H7138, H8040, H8042, H8168, G710, G1188, G1448, G1451, G1764, G2021, G2092, G2176, G2902, G4084, G4474, G4475, G5495, G5496, G5497


---

<a id="hang"/>

### hang, hangs, hanged, hanging, hangings, hung ###

#### Definition: ####

The term "hang" means to suspend something or someone above the ground.

* Death by hanging typically is done by tying a rope that is tied around a person's neck and sustending him from an elevated object, like a tree limb. Judas killed himself by hanging.
* Although Jesus died while hanging on a wooden cross, there was nothing around his neck: the soldiers suspended him by nailing his hands (or wrists) and his feet to the cross.
* To hang someone always refers to the way of killing someone by hanging them with a rope around their neck.


#### Bible References: ####

* [2 Samuel 17:23](https://git.door43.org/Door43/en_tn/src/master/2sa/17/23.md)
* [Acts 10:39-41](https://git.door43.org/Door43/en_tn/src/master/act/10/39.md)
* [Galatians 03:13-14](https://git.door43.org/Door43/en_tn/src/master/gal/03/13.md)
* [Genesis 40:20-23](https://git.door43.org/Door43/en_tn/src/master/gen/40/20.md)
* [Matthew 27:3-5](https://git.door43.org/Door43/en_tn/src/master/mat/27/03.md)

#### Word Data:####

* Strong's: H2614, H3363, H8518, G519


---

<a id="hard"/>

### hard, harder, hardest, harden, hardens, hardened, hardening, hardness ###

#### Definition: ####

The term "hard" has several different meanings, depending on the context. It usually describes something that is difficult, persistent, or unyielding.

* The expressions "hard heart" or "hard-headed" refer to people who are stubbornly unrepentant. These expressions describe people who persist in disobeying God.
* The figurative expressions "hardness of heart" and "hardness of their hearts" also refer to stubborn disobedience.
* If someone's heart is "hardened" this means that person refuses to obey and remains stubbornly unrepentant.
* When used as an adverb, as in "work hard" or "try hard," it means to do something very strongly and diligently, making an effort to do something very well.

#### Translation Suggestions ####

* The term "hard" could also be translated as "difficult" or "stubborn" or "challenging," depending on the context.
* The terms "hardness" or "hardness of heart" or "hard heart" could be translated as "stubbornness" or "persistent rebellion" or "rebellious attitude" or "stubborn disobedience" or "stubbornly not repenting."
* The term "hardened" could also be translated as "stubbornly unrepentant" or "refusing to obey."
* "Do not harden your heart" could be translated as "do not refuse to repent" or "do not stubbornly keep disobeying."
* Other ways to translate "hard-headed" or "hard-hearted" could include "stubbornly disobedient" or "continuing to disobey" or "refusing to repent" or "always rebelling."
* In expressions such as "work hard" or "try hard," the term "hard" could be translated as "with perseverance" or "diligently."
* The expression "press hard against" could also be translated as "shove with force" or "push strongly against."
* To "oppress people with hard labor" could be translated as "force people to work so hard that they suffer" or "cause people to suffer by forcing them to do very difficult work."
* A different kind of "hard labor" is experienced by a woman who is about to deliver a baby.

(See also: [disobey](#disobey), [evil](kt.html#evil), [heart](kt.html#heart), [labor pains](#laborpains), [stiff-necked](#stiffnecked))

#### Bible References: ####

* [2 Corinthians 11:22-23](https://git.door43.org/Door43/en_tn/src/master/2co/11/22.md)
* [Deuteronomy 15:7-8](https://git.door43.org/Door43/en_tn/src/master/deu/15/07.md)
* [Exodus 14:4-5](https://git.door43.org/Door43/en_tn/src/master/exo/14/04.md)
* [Hebrews 04:6-7](https://git.door43.org/Door43/en_tn/src/master/heb/04/06.md)
* [John 12:39-40](https://git.door43.org/Door43/en_tn/src/master/jhn/12/39.md)
* [Matthew 19:7-9](https://git.door43.org/Door43/en_tn/src/master/mat/19/07.md)

#### Word Data:####

* Strong's: H280, H386, H553, H1692, H2388, H2389, H2420, H2864, H3021, H3332, H3513, H3515, H3966, H4165, H4522, H5450, H5539, H5564, H5646, H5647, H5797, H5810, H5980, H5999, H6089, H6277, H6381, H6635, H7185, H7186, H7188, H7280, H8068, H8307, H8631, G917, G1419, G1421, G1422, G1423, G1425, G2205, G2532, G2553, G2872, G2873, G3425, G3433, G4053, G4183, G4456, G4457, G4641, G4642, G4643, G4645, G4912, G4927


---

<a id="harp"/>

### harp, harps, harpist, harpists ###

#### Definition: ####

A harp is a stringed musical instrument, that usually consists of a large open frame with vertical strings.

* In Bible times, fir wood was used to make harps and other musical instruments.
* Harps were often held in the hands and played while walking.
* In many places in the Bible, harps are mentioned as instruments that were used to praise and worship God. 
* David wrote several psalms which were set to harp music.
* He also played a harp for King Saul, to soothe the king's troubled spirit. 
 

(See also: [David](names.html#david), [fir](#fir), [psalm](kt.html#psalm), [Saul (OT)](names.html#saul))

#### Bible References: ####

* [1 Chronicles 15:16-18](https://git.door43.org/Door43/en_tn/src/master/1ch/15/16.md)
* [Amos 05:23-24](https://git.door43.org/Door43/en_tn/src/master/amo/05/23.md)
* [Daniel 03:3-5](https://git.door43.org/Door43/en_tn/src/master/dan/03/03.md)
* [Psalm 033:1-3](https://git.door43.org/Door43/en_tn/src/master/psa/033/001.md)
* [Revelation 05:8](https://git.door43.org/Door43/en_tn/src/master/rev/05/08.md)

#### Word Data:####

* Strong's: H3658, H5035, H5059, H7030, G2788, G2789, G2790


---

<a id="harvest"/>

### harvest, harvests, harvested, harvesting, harvester, harvesters ###

#### Definition: ####

The term "harvest" refers to the gathering in of ripe fruits or vegetables from the plants on which they were growing.

* The harvest time normally happens at the end of a growing season.
* The Israelites held a "Festival of Harvest" or "Festival of Ingathering" to celebrate the reaping of the food crops. God commanded them to offer the first fruits of these crops as a sacrifice to him.
* In a figurative sense, the word "harvest" can refer to people coming to believe in Jesus or can describe a person's spiritual growth.
* The idea of a harvest of spiritual crops fits with the figurative image of fruits being a picture of godly character qualities.

#### Translation Suggestions: ####

* It is best to translate this term with the word that is commonly used in the language to refer to the harvesting of crops.
* The event of harvesting could be translated as, "time of gathering in" or "crop gathering time" or "fruit picking time."
* The verb to "harvest" could be translated as, to "gather in" or to "pick up" or to "collect."

(See also: [firstfruits](#firstfruit), [festival](#festival))

#### Bible References: ####

* [1 Corinthians 09:9-11](https://git.door43.org/Door43/en_tn/src/master/1co/09/09.md)
* [2 Samuel 21:7-9](https://git.door43.org/Door43/en_tn/src/master/2sa/21/07.md)
* [Galatians 06:9-10](https://git.door43.org/Door43/en_tn/src/master/gal/06/09.md)
* [Isaiah 17:10-11](https://git.door43.org/Door43/en_tn/src/master/isa/17/10.md)
* [James 05:7-8](https://git.door43.org/Door43/en_tn/src/master/jas/05/07.md)
* [Leviticus 19:9-10](https://git.door43.org/Door43/en_tn/src/master/lev/19/09.md)
* [Matthew 09:37-38](https://git.door43.org/Door43/en_tn/src/master/mat/09/37.md)
* [Ruth 01:22](https://git.door43.org/Door43/en_tn/src/master/rut/01/22.md)

#### Word Data:####

* Strong's: H2758, H7105, G2326, G6013


---

<a id="haughty"/>

### haughty ###

#### Definition: ####

The term "haughty" means to be prideful or arrogant. Someone who is "haughty" thinks too highly of himself.

* Often this term describes a proud person who persists in sinning against God.
* Usually a person who is haughty boasts about himself.
* A haughty person is foolish, not wise.
* This term could also be translated as "proud" or "arrogant" or "self-centered."
* The figurative expression "haughty eyes" could also be translated as "proud way of looking" or "looking at others as less important" or "proud person who looks down on others."

(See also: [boast](kt.html#boast), [proud](#proud))

#### Bible References: ####

* [2 Timothy 03:1-4](https://git.door43.org/Door43/en_tn/src/master/2ti/03/01.md)
* [Isaiah 02:17-19](https://git.door43.org/Door43/en_tn/src/master/isa/02/17.md)
* [Proverbs 16:17-18](https://git.door43.org/Door43/en_tn/src/master/pro/16/17.md)
* [Proverbs 21:23-24](https://git.door43.org/Door43/en_tn/src/master/pro/21/23.md)
* [Psalm 131:1](https://git.door43.org/Door43/en_tn/src/master/psa/131/001.md)

#### Word Data:####

* Strong's: H1361, H1363, H1364, H3093, H4791, H7312, G5244


---

<a id="head"/>

### head, heads, forehead, foreheads, baldhead, headfirst, headbands, headscarves, beheaded ###

#### Definition: ####

In the Bible, the word "head" is used with several figurative meanings.

* Often this term is used to refer to being in authority over people, as in "you have made me the head over nations." This could be translated as "You have made me the ruler…" or "You have given me authority over…"
* Jesus is called the "head of the church." Just as a person's head guides and directs the members of its body, so Jesus guides and directs the members of his "body," the Church.
* The New Testament teaches that a husband is the "head" or authority of his wife. He is given the responsibility of leading and guiding his wife and family.
* The expression "no razor will ever touch his head" means" he will never cut or shave his hair."
* The term "head" can also refer to the beginning or source of something, as in the "head of the street."
* The expression "heads of grain" refers to the top parts of a wheat or barley plant that contains the seeds.
* Another figurative use for "head" is when it is used to represent the whole person, as in "this gray head," referring to an elderly person, or as in "the head of Joseph," which refers to Joseph. (See: [synecdoche](https://git.door43.org/Door43/en_ta/src/master/translate/figs-synecdoche.md))
* The expression "let their blood be on his own head" means that the man is responsible for their deaths and will receive the punishment for that.

#### Translation Suggestions ####

* Depending on the context, the term "head" could be translated as "authority" or "the one who leads and directs" or "the one who is responsible for."
* The expression "head of" can refer to the whole person and so this expression could be translated using just the person's name. For example, "the head of Joseph" could simply be translated as "Joseph."
* The expression "will be on his own head" could be translated as "will be on him" or "he will be punished for" or "he will be held responsible for" or "he will be considered guilty for."
* Depending on the context, other ways to translate this term could include "beginning" or "source" or "ruler" or "leader" or "top."

(See also: [grain](#grain))

#### Bible References: ####

* [1 Chronicles 01:51-54](https://git.door43.org/Door43/en_tn/src/master/1ch/01/51.md)
* [1 Kings 08:1-2](https://git.door43.org/Door43/en_tn/src/master/1ki/08/01.md)
* [1 Samuel 09:22](https://git.door43.org/Door43/en_tn/src/master/1sa/09/22.md)
* [Colossians 02:10-12](https://git.door43.org/Door43/en_tn/src/master/col/02/10.md)
* [Colossians 02:18-19](https://git.door43.org/Door43/en_tn/src/master/col/02/18.md)
* [Numbers 01:4-6](https://git.door43.org/Door43/en_tn/src/master/num/01/04.md)

#### Word Data:####

* Strong's: H441, H1270, H1538, H1627, H3852, H4425, H4761, H4763, H5110, H5324, H6285, H6287, H6797, H6915, H6936, H7139, H7144, H7146, H7217, H7226, H7218, H7541, H7636, H7641, H7872, G346, G755, G2775, G2776, G4719


---

<a id="heal"/>

### cure, cured, heal, heals, healed, healing, healings, healer, health, healthy, unhealthy ###

#### Definition: ####

The terms "heal" and "cure" both mean to cause a sick, wounded, or disabled person to be healthy again.

 * A person who is "healed" or "cured" has been "made well" or "made healthy."
 * Healing can happen naturally since God gave our bodies the ability to recover from many kinds of wounds and diseases. Thsi kind of healing usually happens slowly.
 * However, certain conditions, such as being blind or paralyzed, and certain serious diseases, such as leprosy, however do not heal on their own. When people are healed of these things, it is a miracle that usually happens suddenly.
 * For example, Jesus healed many people who were blind or lame or diseased, and they became well right away.
 * The apostles also healed people miraculously, such as when Peter caused a crippled man to immediately be able to walk. 

(See also: [miracle](kt.html#miracle))

#### Bible References: ####

* [Acts 05:14-16](https://git.door43.org/Door43/en_tn/src/master/act/05/14.md)
* [Acts 08:6-8](https://git.door43.org/Door43/en_tn/src/master/act/08/06.md)
* [Luke 05:12-13](https://git.door43.org/Door43/en_tn/src/master/luk/05/12.md)
* [Luke 06:17-19](https://git.door43.org/Door43/en_tn/src/master/luk/06/17.md)
* [Luke 08:43-44](https://git.door43.org/Door43/en_tn/src/master/luk/08/43.md)
* [Matthew 04:23-25](https://git.door43.org/Door43/en_tn/src/master/mat/04/23.md)
* [Matthew 09:35-36](https://git.door43.org/Door43/en_tn/src/master/mat/09/35.md)
* [Matthew 13:15](https://git.door43.org/Door43/en_tn/src/master/mat/13/15.md)

#### Examples from the Bible stories: ####

  __*[19:14](https://git.door43.org/Door43/en_tn/src/master/obs/19/14.md)__ One of the miracles happened to Naaman, an enemy commander, who had a horrible skin disease. He had heard of Elisha so he went and asked Elisha to __heal__ him.
  __*[21:10](https://git.door43.org/Door43/en_tn/src/master/obs/21/10.md)__ He (Isaiah) also predicted that the Messiah would __heal__ sick people and those who could not hear, see, speak, or walk.
  __*[26:06](https://git.door43.org/Door43/en_tn/src/master/obs/26/06.md)__ Jesus continued saying, "And during the time of the prophet Elisha, there were many people in Israel with skin diseases. But Elisha did not __heal__ any of them. He only __healed__ the skin disease of Naaman, a commander of Israel's enemies."
  __*[26:08](https://git.door43.org/Door43/en_tn/src/master/obs/26/08.md)__ They brought many people who were sick or handicapped, including those who could not see, walk, hear, or speak, and Jesus __healed__ them.
  __*[32:14](https://git.door43.org/Door43/en_tn/src/master/obs/32/14.md)__ She had heard that Jesus had __healed__ many sick people and thought, "I'm sure that if I can just touch Jesus' clothes, then I will be __healed__, too!"
  __*[44:03](https://git.door43.org/Door43/en_tn/src/master/obs/44/03.md)__ Immediately, God __healed__ the lame man, and he began to walk and jump around, and to praise God.
  __*[44:08](https://git.door43.org/Door43/en_tn/src/master/obs/44/08.md)__ Peter answered them, "This man stands before you __healed__ by the power of Jesus the Messiah."
  __*[49:02](https://git.door43.org/Door43/en_tn/src/master/obs/49/02.md)__ ] Jesus did many miracles that prove he is God. He walked on water, calmed storms, __healed__ many sick people, drove out demons, raised the dead to life, and turned five loaves of bread and two small fish into enough food for over 5,000 people.

#### Word Data:####

* Strong's: H724, H1369, H1455, H2280, H2421, H2896, H3444, H3545, H4832, H4974, H7495, H7499, H7500, H7725, H7965, H8549, H8585, H8644, H622, G1295, G1743, G2322, G2323, G2386, G2390, G2392, G2511, G3647, G4982, G4991, G5198, G5199


---

<a id="heir"/>

### heir, heirs ###

#### Definition: ####

An "heir" is a person who legally receives property or money that belonged to a person who has died.

* In Bible times, the main heir was the firstborn son, who received most of the property and money of his father.
* The Bible also uses "heir" in a figurative sense to refer to person who as a Christian receives spiritual benefits from God, his spiritual father.
* As God's children, Christians are said to be "joint heirs" with Jesus Christ. This could also be translated as "co-heirs" or "fellow heirs" or "heirs together with."
* The term "heir" could be translated as "person receiving benefits" or whatever expression is used in the language to communicate the meaning of someone who receives property and other things when a parent or other relative dies.
 
(See also: [firstborn](#firstborn), [inherit](kt.html#inherit))

#### Bible References: ####

* [Galatians 04:1-2](https://git.door43.org/Door43/en_tn/src/master/gal/04/01.md)
* [Galatians 04:6-7](https://git.door43.org/Door43/en_tn/src/master/gal/04/06.md)
* [Genesis 15:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/15/01.md)
* [Genesis 21:10-11](https://git.door43.org/Door43/en_tn/src/master/gen/21/10.md)
* [Luke 20:13-14](https://git.door43.org/Door43/en_tn/src/master/luk/20/13.md)
* [Mark 12:6-7](https://git.door43.org/Door43/en_tn/src/master/mrk/12/06.md)
* [Matthew 21:38-39](https://git.door43.org/Door43/en_tn/src/master/mat/21/38.md)

#### Word Data:####

* Strong's: H1121, H3423, G2816, G2818, G2820, G4789


---

<a id="highplaces"/>

### high place, high places ###

#### Definition: ####

The term "high places" refers to the altars and shrines that were used for worshiping idols. They were usually built on higher ground, such as on a hill or mountainside.

* Many of the kings of Israel sinned against God by building altars to false gods on these high places. This led the people to become deeply involved in worshiping idols.
* It often happened that when a God-fearing king started ruling in Israel or Judah, often he would remove the high places or altars in order to stop the worship of these idols.
* However, some of these good kings were careless and did not remove the high places, which resulted in the entire nation of Israel would continue to worship idols.

#### Translation Suggestions: ####

* Other ways to translate this term could include "elevated places for idol worship" or "hilltop idol shrines" or "idol altar mounds."
* Make sure it is clear that this term refers to the idol altars, not just to the high place where those altars were located.

(See also: [altar](kt.html#altar), [false god](kt.html#falsegod), [worship](kt.html#worship))

#### Bible References: ####

* [1 Samuel 09:12-13](https://git.door43.org/Door43/en_tn/src/master/1sa/09/12.md)
* [2 Kings 16:3-4](https://git.door43.org/Door43/en_tn/src/master/2ki/16/03.md)
* [Amos 04:12-13](https://git.door43.org/Door43/en_tn/src/master/amo/04/12.md)
* [Deuteronomy 33:29](https://git.door43.org/Door43/en_tn/src/master/deu/33/29.md)
* [Ezekiel 06:1-3](https://git.door43.org/Door43/en_tn/src/master/ezk/06/01.md)
* [Habakkuk 03:18-19](https://git.door43.org/Door43/en_tn/src/master/hab/03/18.md)

#### Word Data:####

* Strong's: H1116, H1181, H1354, H2073, H4791, H7311, H7413


---

<a id="holycity"/>

### holy city, holy cities ###

#### Definition: ####

In the Bible, the term "holy city" refers to the city of Jerusalem.

* This term is used to refer to the ancient city of Jerusalem as well as the new, heavenly Jerusalem where God will live and reign among his people.
* This term can be translated by combining the terms for "holy" and "city" that have been used in the rest of the translation.

(See also: [heaven](kt.html#heaven), [holy](kt.html#holy), [Jerusalem](names.html#jerusalem))

#### Bible References: ####

* [Matthew 04:5-6](https://git.door43.org/Door43/en_tn/src/master/mat/04/05.md)
* [Matthew 27:51-53](https://git.door43.org/Door43/en_tn/src/master/mat/27/51.md)
* [Revelation 21:1-2](https://git.door43.org/Door43/en_tn/src/master/rev/21/01.md)
* [Revelation 21:9-10](https://git.door43.org/Door43/en_tn/src/master/rev/21/09.md)
* [Revelation 22:18-19](https://git.door43.org/Door43/en_tn/src/master/rev/22/18.md)

#### Word Data:####

* Strong's: H5892, H6944, G40, G4172


---

<a id="honey"/>

### honey, honeycomb ###

#### Definition: ####

"Honey" is the sweet, sticky, edible substance that honeybees make out of flower nectar. Honeycomb is the waxy frame where the bees store honey.

* Depending on the kind, honey can be yellowish or brownish in color.
* Honey can be found in the wild, such as in the hollow of a tree, or wherever bees make a nest. People also raise bees in hives in order to produce honey to eat or sell, but probably the honey mentioned in the Bible was wild honey.
* Three people that the Bible specifically mentions as eating wild honey were Jonathan, Samson, and John the Baptist.
* This term is often used figuratively to describe something that is sweet or very pleasurable. For example, God's words and decrees are said to be "sweeter than honey." (See also: [Simile](https://git.door43.org/Door43/en_ta/src/master/translate/figs-simile.md), [Metaphor](https://git.door43.org/Door43/en_ta/src/master/translate/figs-metaphor.md))
* Sometimes a person's words are described as seeming sweet like honey, but instead result in deceiving and harming others.

(See also: [John (the Baptist)](names.html#johnthebaptist), [Jonathan](names.html#jonathan), [Philistines](names.html#philistines), [Samson](names.html#samson))

#### Bible References: ####

* [1 Kings 14:1-3](https://git.door43.org/Door43/en_tn/src/master/1ki/14/01.md)
* [Deuteronomy 06:3](https://git.door43.org/Door43/en_tn/src/master/deu/06/03.md)
* [Exodus 13:3-5](https://git.door43.org/Door43/en_tn/src/master/exo/13/03.md)
* [Joshua 05:6-7](https://git.door43.org/Door43/en_tn/src/master/jos/05/06.md)
* [Proverbs 05:3-4](https://git.door43.org/Door43/en_tn/src/master/pro/05/03.md)

#### Word Data:####

* Strong's: H1706, H3293, H3295, H5317, H6688, G2781, G3192, G3193


---

<a id="hooves"/>

### hoof, hoofs, hooves ###

#### Facts: ####

These terms refer to the hard material covering the bottom of the feet of certain animals such as camels, cattle, deer, horses, donkeys, pigs, oxen, sheep, and goats.

* An animal's hooves protect its feet when walking.
* Some animals have hooves that are split into two parts and others do not.
* God told the Israelites that animals which had split hooves and chewed a cud were considered clean to eat. This included cattle, sheep, deer, and oxen.
  

(See also: [How to Translate Unknowns](https://git.door43.org/Door43/en_ta/src/master/translate/translate-unknown.md))

(See also: [camel](#camel), [cow](#cow), [donkey](#donkey), [goat](#goat), [ox](#ox), [pig](#pig), [sheep](#sheep))

#### Bible References: ####

* [Deuteronomy 14:6-7](https://git.door43.org/Door43/en_tn/src/master/deu/14/06.md)
* [Ezekiel 26:9-11](https://git.door43.org/Door43/en_tn/src/master/ezk/26/09.md)
* [Leviticus 11:3-4](https://git.door43.org/Door43/en_tn/src/master/lev/11/03.md)
* [Psalms 069:30-31](https://git.door43.org/Door43/en_tn/src/master/psa/069/030.md)

#### Word Data:####

* Strong's: H6119, H6471, H6536, H6541, H7272


---

<a id="horn"/>

### horn, horns, horned ###

#### Facts: ####

Horns are permanent, hard, pointed growths on the heads of many types of animals, including cattle, sheep, goats, and deer.

* The horn of a ram (male sheep) was made into a musical instrument called a "ram's horn" or "shofar," which was blown for special events such as religious festivals.
* God told the Israelites to make a horn-shaped projection on each of the four corners of the incense and brazen altars. Although these projections were called "horns," they were not actually animal horns.
* The term "horn" was sometimes used to refer to a "flask" that was shaped like a horn and was used for holding water or oil. A flask of oil was used for anointing a king, as Samuel did with David.
* This term should be translated with a word that is different from the word that refers to a trumpet.
*  The term "horn" is also used figuratively as a symbol of strength, power, authority, and royalty.

 

(See also: [authority](kt.html#authority), [cow](#cow), [deer](#deer), [goat](#goat), [power](kt.html#power) [royal](#royal), [sheep](#sheep), [trumpet](#trumpet))

#### Bible References: ####

* [1 Chronicles 15:27-28](https://git.door43.org/Door43/en_tn/src/master/1ch/15/27.md)
* [1 Kings 01:38-40](https://git.door43.org/Door43/en_tn/src/master/1ki/01/38.md)
* [2 Samuel 22:3-4](https://git.door43.org/Door43/en_tn/src/master/2sa/22/03.md)
* [Jeremiah 17:1-2](https://git.door43.org/Door43/en_tn/src/master/jer/17/01.md)
* [Psalms 022:20-21](https://git.door43.org/Door43/en_tn/src/master/psa/022/020.md)

#### Word Data:####

* Strong's: H2689, H3104, H7160, H7161, H7162, H7782, G2768


---

<a id="horror"/>

### horror, horrors, horrible, horribly, horrified, horrifying ###

#### Definition: ####

The term "horror" refers to a very intense feeling of fear or terror. The person who is feeling horror is said to be "horrified."

* Horror is more dramatic and intense than ordinary fear.
* Usually when someone is horrified they are also in shock or stunned.

(See also: [fear](kt.html#fear), [terror](#terror))

#### Bible References: ####

* [Deuteronomy 28:36-37](https://git.door43.org/Door43/en_tn/src/master/deu/28/36.md)
* [Ezekiel 23:33-34](https://git.door43.org/Door43/en_tn/src/master/ezk/23/33.md)
* [Jeremiah 02:12-13](https://git.door43.org/Door43/en_tn/src/master/jer/02/12.md)
* [Job 21:4-6](https://git.door43.org/Door43/en_tn/src/master/job/21/04.md)
* [Psalms 055:4-5](https://git.door43.org/Door43/en_tn/src/master/psa/055/004.md)

#### Word Data:####

* Strong's: H367, H1091, H1763, H2152, H2189, H4032, H4923, H5892, H6343, H6427, H7588, H8047, H8074, H8175, H8178, H8186


---

<a id="horse"/>

### horse, horses, warhorse, warhorses, horseback ###

#### Definition: ####

A horse is a large, four-legged animal that in Bible times was mostly used for doing farm work and for transporting people.

* Some horses were used to pull carts or chariots, while others were used to carry individual riders.
* Horses often wear a bit and bridle on their heads so they can be guided.
* In the Bible, horses were considered to be valuable possessions and a measure of wealth, mainly because of their use in war. For example, part of King Solomon's great wealth was the thousands of horses and chariots that he had.
* Animals that are similar to the horse are the donkey and the mule.
  
(See also: [chariot](#chariot), , [donkey](#donkey), [Solomon](names.html#solomon))

#### Bible References: ####

* [1 Chronicles 18:3-4](https://git.door43.org/Door43/en_tn/src/master/1ch/18/03.md)
* [2 Kings 02:11-12](https://git.door43.org/Door43/en_tn/src/master/2ki/02/11.md)
* [Exodus 14:23-25](https://git.door43.org/Door43/en_tn/src/master/exo/14/23.md)
* [Ezekiel 23:5-7](https://git.door43.org/Door43/en_tn/src/master/ezk/23/05.md)
* [Zechariah 06:7-8](https://git.door43.org/Door43/en_tn/src/master/zec/06/07.md)

#### Word Data:####

* Strong's: H47, H5483, H5484, H6571, H7409, G2462


---

<a id="horsemen"/>

### horseman, horsemen ###

#### Definition: ####

In Bible times, the term "horsemen" referred to men who rode horses into battle.

* Warriors who rode in horse-pulled chariots may also have been called "horsemen," though this term usually refers to men who were actually riding on horses.
* The Israelites believed that using horses in battle placed too much emphasis on their own strength rather than on Yahweh, so they did not have many horsemen.
* This term could also be translated as "horse riders" or "men on horses."

(See also: [chariot](#chariot), [horse](#horse))

#### Bible References: ####

* [1 Kings 01:5-6](https://git.door43.org/Door43/en_tn/src/master/1ki/01/05.md)
* [Daniel 11:40-41](https://git.door43.org/Door43/en_tn/src/master/dan/11/40.md)
* [Exodus 14:23-25](https://git.door43.org/Door43/en_tn/src/master/exo/14/23.md)
* [Genesis 50:7-9](https://git.door43.org/Door43/en_tn/src/master/gen/50/07.md)

#### Word Data:####

* Strong's: H6571, H7395, G2460


---

<a id="hour"/>

### hour, hours ###

#### Definition: ####

In addition to being used to refer to when or how long something took place, the term "hour" is also used in several figurative ways:

* Sometimes "hour" refers to a regular, scheduled time to do something, such as the "hour of prayer."
* When the text says that the "hour had come" for Jesus to suffer and be put to death, this means that it was the appointed time for this to happen--the time that God had selected long ago.
* The term "hour" is also used to mean "at that moment" or "right then."
* When the text talks about the "hour" being late, this means that it was late in the day, when the sun would soon be setting.

#### Translation Suggestions: ####

* When used figuratively, the term "hour" can be translated as "time" or "moment" or "appointed time."
* The phrase "in that very hour" or "the same hour" could be translated as "at that moment" or "at that time" or "immediately" or "right then."
* The expression "the hour was late" could be translated as "it was late in the day" or "it would soon be getting dark" or "it was late afternoon."

(See also: [hour](#biblicaltimehour))

#### Bible References: ####

* [1 Corinthians 15:29-30](https://git.door43.org/Door43/en_tn/src/master/1co/15/29.md)
* [Acts 10:30-33](https://git.door43.org/Door43/en_tn/src/master/act/10/30.md)
* [Mark 14:35-36](https://git.door43.org/Door43/en_tn/src/master/mrk/14/35.md)

#### Word Data:####

* Strong's: H8160, G5610


---

<a id="house"/>

### house, houses, housetop, housetops, storehouse, storehouses, housekeepers ###

#### Definition: ####

The term "house" is often used figuratively in the Bible. 

* Sometimes it means "household," referring to the people who live together in one house.
* Often "house" refers to a person's descendants or other relatives. For example, the phrase "house of David" refers to all the descendants of King David.
* The terms "house of God" and "house of Yahweh" refer to the tabernacle or temple. These expressions can also refer generally to where God is or dwells.
* In Hebrews 3, "God's house" is used as a metaphor to refer to God's people or, more generally, to everything pertaining to God.
* The phrase "house of Israel" can refer generally to the entire nation of Israel or more specifically to the tribes of the northern kingdom of Israel.

#### Translation Suggestions ####

* Depending on the context, "house" could be translated as "household" or "people" or "family" or "descendants" or "temple" or "dwelling place."
* The phrase "house of David" could be translated as "clan of David" or "family of David" or "descendants of David." Related expressions could be translated in a similar way.
* Different ways to translate "house of Israel" could include "people of Israel" or "Israel's descendants" or "Israelites."
* The phrase "house of Yahweh" could be translated as "Yahweh's temple" or "place where Yahweh is worshiped" or "place where Yahweh meets with his people" or "where Yahweh dwells."
* "House of God" could be translated in a similar way.

(See also: [David](names.html#david), [descendant](#descendant), [house of God](kt.html#houseofgod), [household](#household), [kingdom of Israel](names.html#kingdomofisrael), [tabernacle](kt.html#tabernacle), [temple](kt.html#temple), [Yahweh](kt.html#yahweh))

#### Bible References: ####

* [Acts 07:41-42](https://git.door43.org/Door43/en_tn/src/master/act/07/41.md)
* [Acts 07:47-50](https://git.door43.org/Door43/en_tn/src/master/act/07/47.md)
* [Genesis 39:3-4](https://git.door43.org/Door43/en_tn/src/master/gen/39/03.md)
* [Genesis 41:39-41](https://git.door43.org/Door43/en_tn/src/master/gen/41/39.md)
* [Luke 08:38-39](https://git.door43.org/Door43/en_tn/src/master/luk/08/38.md)
* [Matthew 10:5-7](https://git.door43.org/Door43/en_tn/src/master/mat/10/05.md)
* [Matthew 15:24-26](https://git.door43.org/Door43/en_tn/src/master/mat/15/24.md)

#### Word Data:####

* Strong's: H1004, H1005, G3609, G3613, G3614, G3624


---

<a id="household"/>

### household, households ###

#### Definition: ####

The term "household" refers to all the people who live together in a house, including family members and all their servants.

* Managing a household would involves directing the servants and also taking care of the property.
* Sometimes "household" can refer figuratively to the whole family line of someone, especially his descendants.

(See also: [house](#house))

#### Bible References: ####

* [Acts 07:9-10](https://git.door43.org/Door43/en_tn/src/master/act/07/09.md)
* [Galatians 06:9-10](https://git.door43.org/Door43/en_tn/src/master/gal/06/09.md)
* [Genesis 07:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/07/01.md)
* [Genesis 34:18-19](https://git.door43.org/Door43/en_tn/src/master/gen/34/18.md)
* [John 04:53-54](https://git.door43.org/Door43/en_tn/src/master/jhn/04/53.md)
* [Matthew 10:24-25](https://git.door43.org/Door43/en_tn/src/master/mat/10/24.md)
* [Matthew 10:34-36](https://git.door43.org/Door43/en_tn/src/master/mat/10/34.md)
* [Philippians 04:21-23](https://git.door43.org/Door43/en_tn/src/master/php/04/21.md)

#### Word Data:####

* Strong's: H1004, H5657, G2322, G3609, G3614, G3615, G3616, G3623, G3624


---

<a id="humiliate"/>

### humiliate, humiliated, humiliation ###

#### Facts: ####

The term "humiliate" means to cause someone to feel shamed or disgraced. This is usually done publicly. The act of shaming someone is called "humiliation." 

* When God in humbling someone it means that he is causing a prideful person to experience failure to help him overcome his pride. This is different from humiliating someone, which is often done in order to hurt that person.
* To "humiliate" could also be translated as to "shame" or to "cause to feel shame" or to "embarrass."
* Depending on the context, ways to translate "humiliation" could include "shame" or "degrading" or "disgrace."

(See also: [disgrace](#disgrace) **·** [humble](kt.html#humble) **·** [shame](#shame))

#### Bible References: ####

* [Deuteronomy 21:13-14](https://git.door43.org/Door43/en_tn/src/master/deu/21/13.md)
* [Ezra 09:5-6](https://git.door43.org/Door43/en_tn/src/master/ezr/09/05.md)
* [Proverbs 25:7-8](https://git.door43.org/Door43/en_tn/src/master/pro/25/07.md)
* [Psalms 006:8-10](https://git.door43.org/Door43/en_tn/src/master/psa/006/008.md)
* [Psalms 123:3-4](https://git.door43.org/Door43/en_tn/src/master/psa/123/003.md)

#### Word Data:####

* Strong's: H937, H954, H1421, H2778, H2781, H3001, H3637, H3639, H6030, H6031, H6256, H7034, H7043, H7511, H7817, H8216, H8213, H8217, H8589, G2617, G5014


---

<a id="image"/>

### image, images, carved image, carved images, cast metal images, figure, figures, carved figure, carved figures, cast metal figure, cast metal figures ###

#### Definition: ####

These terms are all used to refer to idols that have been made for worshiping a false god. In the context of worshiping idols, the term "image" is a shortened form of "carved image."

* A "carved image" or "carved figure" is a wooden object that has been made to look like an animal, person, or thing.
* A "cast metal figure" is an object or statue created by melting metal and pouring it into a mold that is in the shape of an object, animal, or person.
* These wooden and metal objects were used in the worship of false gods.
* The term "image" when referring to an idol could either refer to a wooden or metal idol.

#### Translation Suggestions: ####

* When referring to an idol, the term "image" could also be translated as "statue" or "engraved idol" or "carved religious object."
* It may be more clear in some languages to always use a descriptive word with this term, such as "carved image" or "cast metal figure," even in places where only the term "image" or "figure" is in the original text.
* Make sure it is clear that this term is different than the term used to refer to being in the image of God. 

(See also: [false god](kt.html#falsegod), [God](kt.html#god), [false god](kt.html#falsegod), [image of God](kt.html#imageofgod))

#### Bible References: ####

* [1 Kings 14:9-10](https://git.door43.org/Door43/en_tn/src/master/1ki/14/09.md)
* [Acts 07:43](https://git.door43.org/Door43/en_tn/src/master/act/07/43.md)
* [Isaiah 21:8-9](https://git.door43.org/Door43/en_tn/src/master/isa/21/08.md)
* [Matthew 22:20-22](https://git.door43.org/Door43/en_tn/src/master/mat/22/20.md)
* [Romans 01:22-23](https://git.door43.org/Door43/en_tn/src/master/rom/01/22.md)

#### Word Data:####

* Strong's: H457, H1544, H2553, H4541, H4676, H4853, H4906, H5257, H5262, H5566, H6091, H6456, H6459, H6754, H6755, H6816, H8403, H8544, H8655, G1504, G5179, G5481


---

<a id="imitate"/>

### imitate, imitator, imitators ###

#### Definition: ####

The terms "imitate" and "imitator" refers to copying someone else by acting exactly like that person does.

* Christians are taught to imitate Jesus Christ by obeying God and loving others, just as Jesus did.
* The apostle Paul told the early church to imitate him, just as he imitated Christ.

#### Translation Suggestions: ####

* The term "imitate" could be translated as "do the same things as" or "follow his example."
* The expression "be imitators of God" could be translated as "be people who act like God does" or "be people who do the kinds of things God does."
* "You became imitators of us" could be translated as "You followed our example" or "You are doing the same kinds of godly things that you saw us do."

#### Bible References: ####

* [3 John 01:11-12](https://git.door43.org/Door43/en_tn/src/master/3jn/01/11.md)
* [Matthew 23:1-3](https://git.door43.org/Door43/en_tn/src/master/mat/23/01.md)

#### Word Data:####

* Strong's: H310, H6213, G1096, G2596, G3401, G3402, G4160


---

<a id="incense"/>

### incense, incenses ###

#### Definition: ####

The term "incense" refers to a mixture of fragrant spices that is burned to produce smoke that has a pleasant smell. 

 * God told the Israelites to burn incense as an offering to him.
 * The incense had to be made by mixing equal amounts of five specific spices exactly as God directed. This was a sacred incense, so they were not allowed to use it for any other purpose.
 * The "altar of incense" was a special altar that was only used for burning incense.
 * The incense was offered at least four times a day, at each hour of prayer. It was also offered every time a burnt offering was made.
 * The burning of incense represents prayer and worship rising up to God from his people.
 * Other ways to translate "incense" could include "fragrant spices" or "good-smelling plants."

(See also: [altar of incense](#altarofincense), [burnt offering](#burntoffering), [frankincense](#frankincense))

#### Bible References: ####

* [1 Kings 03:1-3](https://git.door43.org/Door43/en_tn/src/master/1ki/03/01.md)
* [2 Chronicles 13:10-11](https://git.door43.org/Door43/en_tn/src/master/2ch/13/10.md)
* [2 Kings 14:4-5](https://git.door43.org/Door43/en_tn/src/master/2ki/14/04.md)
* [Exodus 25:3-7](https://git.door43.org/Door43/en_tn/src/master/exo/25/03.md)
* [Luke 01:8-10](https://git.door43.org/Door43/en_tn/src/master/luk/01/08.md)

#### Word Data:####

* Strong's: H2553, H3828, H4196, H4289, H5208, H6988, H6999, H7002, H7004, H7381, G2368, G2369, G2370, G2379, G3031


---

<a id="inquire"/>

### inquire, inquires, inquired, inquiries ###

#### Facts: ####

The term "inquire" means to ask someone for information. The expression "inquire of" is often used to refer to asking God for wisdom or help.

* The Old Testament records several instances where people inquired of God.
* The word can also be used of a king or government official making a search through official written records.
* Depending on the context, "inquire" could be translated as "ask" or "ask for information." 
* The expression "inquire of Yahweh" could be translated as "ask Yahweh for guidance" or "ask Yahweh what to do."
* To "inquire after" something could be translated as "ask questions about" or "ask for information about."
* When Yahweh says "I will not be inquired of by you," this could be translated as "I will not allow you to ask me for information" or  "you will not be permitted to seek help from me."

#### Bible References: ####

* [Deuteronomy 19:17-19](https://git.door43.org/Door43/en_tn/src/master/deu/19/17.md)
* [Ezekiel 20:1](https://git.door43.org/Door43/en_tn/src/master/ezk/20/01.md)
* [Ezekiel 20:30-32](https://git.door43.org/Door43/en_tn/src/master/ezk/20/30.md)
* [Ezra 07:14-16](https://git.door43.org/Door43/en_tn/src/master/ezr/07/14.md)
* [Job 10:4-7](https://git.door43.org/Door43/en_tn/src/master/job/10/04.md)

#### Word Data:####

* Strong's: H1240, H1245, H1875, G1830


---

<a id="instruct"/>

### instruct, instructs, instructed, instructing, instruction, instructions, instructors ###

#### Facts: ####

The terms "instruct" and "instruction" refer to giving specific directions about what to do.

* To "give instructions" means to tell someone specifically what he is supposed to do.
* When Jesus gave the disciples the bread and fish to distribute to the people, he gave them specific instructions about how to do it.
* Depending on the context, the term "instruct" could also be translated as "tell" or "direct" or "teach" or "give instructions to."
* The term "instructions" could be translated as "directions" or "explanations" or "what he has told you to do."
* When God gives instructions, this term is sometimes translated as "commands" or "orders."

(See also: [command](kt.html#command), [decree](#decree), [teach](#teach))

#### Bible References: ####

* [Exodus 14:4-5](https://git.door43.org/Door43/en_tn/src/master/exo/14/04.md)
* [Genesis 26:4-5](https://git.door43.org/Door43/en_tn/src/master/gen/26/04.md)
* [Hebrews 11:20-22](https://git.door43.org/Door43/en_tn/src/master/heb/11/20.md)
* [Matthew 10:5-7](https://git.door43.org/Door43/en_tn/src/master/mat/10/05.md)
* [Matthew 11:1-3](https://git.door43.org/Door43/en_tn/src/master/mat/11/01.md)
* [Proverbs 01:28-30](https://git.door43.org/Door43/en_tn/src/master/pro/01/28.md)

#### Word Data:####

* Strong's: H241, H376, H559, H631, H1004, H1696, H1697, H3256, H3289, H3384, H4148, H4156, H4687, H4931, H4941, H5657, H6098, H6310, H6490, H6680, H7919, H8451, H8738, G1256, G1299, G1319, G1321, G1378, G1781, G1785, G2322, G2727, G2753, G3559, G3560, G3614, G3615, G3624, G3811, G3852, G3853, G4264, G4367, G4822


---

<a id="integrity"/>

### integrity ###

#### Definition: ####

The term "integrity" refers to being honest, with strong moral principles and behavior is said to have integrity.

* Having integrity also means choosing to do what is honest and right even when nobody else is watching.
* Certain characters in the Bible, such as Joseph and Daniel, showed integrity when they refused to do evil and chose to obey God.
* The book of Proverbs says that it is better to be poor and have integrity than to be rich and corrupt or dishonest.

#### Translation Suggestions ####

* The term "integrity" could also be translated as "honesty" or "moral uprightness" or "behaving truthfully" or "acting in a trustworthy, honest manner."

(See also: [Daniel](names.html#daniel), [Joseph (OT)](names.html#josephot))

#### Bible References: ####

* [1 Kings 09:4-5](https://git.door43.org/Door43/en_tn/src/master/1ki/09/04.md)
* [Job 02:3](https://git.door43.org/Door43/en_tn/src/master/job/02/03.md)
* [Job 04:4-6](https://git.door43.org/Door43/en_tn/src/master/job/04/04.md)
* [Proverbs 10:8-9](https://git.door43.org/Door43/en_tn/src/master/pro/10/08.md)
* [Psalm 026:1-3](https://git.door43.org/Door43/en_tn/src/master/psa/026/001.md)

#### Word Data:####

* Strong's: H3476, H6664, H6666, H8535, H8537, H8538, H8549, G4587


---

<a id="interpret"/>

### interpret, interprets, interpreted, interpreting, interpretation, interpretations, interpreter ###

#### Facts: ####

The terms "interpret" and "interpretation" refer to understanding and explaining the meaning of something that is not clear.

* Often in the Bible these terms are used in connection with explaining the meaning of dreams or visions.
* When the king of Babylon had some confusing dreams, God helped Daniel to interpret them and to explain their meanings.
* The "interpretation" of the dream is the "explanation" of the meaning of the dream.
* In the Old Testament, God sometimes used dreams to reveal to people what would happen in the future. So the interpretations of those dreams were prophecies.
* The term "interpret" can also refer to figuring out the meaning of other things, such as figuring out what the weather will be like based on how cold or hot it is, how windy it is, and what the sky looks like.
* Ways to translate the term "interpret" could include, "figure out the meaning of" or "explain" or "give the meaning of."
* The term "interpretation" could also be translated as "explanation" or "meaning."

(See also: [Babylon](names.html#babylon), [Daniel](names.html#daniel), [dream](#dream), [prophet](kt.html#prophet), [vision](#vision))

#### Bible References: ####

* [1 Corinthians 12:9-11](https://git.door43.org/Door43/en_tn/src/master/1co/12/09.md)
* [Daniel 04:4-6](https://git.door43.org/Door43/en_tn/src/master/dan/04/04.md)
* [Genesis 40:4-5](https://git.door43.org/Door43/en_tn/src/master/gen/40/04.md)
* [Judges 07:15-16](https://git.door43.org/Door43/en_tn/src/master/jdg/07/15.md)
* [Luke 12:54-56](https://git.door43.org/Door43/en_tn/src/master/luk/12/54.md)

#### Word Data:####

* Strong's: H995, H3887, H6591, H6622, H6623, H7667, H7760, H7922, G1252, G1328, G1329, G1381, G1955, G2058, G3177, G4793


---

<a id="jewishleaders"/>

### Jewish authorities, Jewish leader ###

#### Facts: ####

The term "Jewish leader" or "Jewish authority" refers to religious leaders such as the priests and teachers of God's laws. They also had the authority to make judgments about non-religious matters as well.

* The Jewish leaders were the high priests, chief priests, and scribes (teachers of God's laws).
* Two main groups of Jewish leaders were the Pharisees and Saduccees.
* Seventy Jewish leaders met together in the Jewish Council in Jerusalem to make judgments about matters of law.
* Many Jewish leaders were proud and thought they were righteous. They were jealous of Jesus and wanted to harm him. They claimed to know God but did not obey him.
* Often the phrase "the Jews" referred to the Jewish leaders, especially in contexts where they were angry at Jesus and were trying to trick or harm him.
* These terms could also be translated as "Jewish rulers" or "men who ruled over the Jewish people" or "Jewish religious leaders."

(See also: [Jew](kt.html#jew), [chief priests](#chiefpriests), [council](#council), [high priest](kt.html#highpriest), [Pharisee](kt.html#pharisee), [priest](kt.html#priest), [Sadducee](kt.html#sadducee), [scribe](kt.html#scribe))

#### Bible References: ####

* [Exodus 16:22-23](https://git.door43.org/Door43/en_tn/src/master/exo/16/22.md)
* [John 02:17-19](https://git.door43.org/Door43/en_tn/src/master/jhn/02/17.md)
* [John 05:10-11](https://git.door43.org/Door43/en_tn/src/master/jhn/05/10.md)
* [John 05:16-18](https://git.door43.org/Door43/en_tn/src/master/jhn/05/16.md)
* [Luke 19:47-48](https://git.door43.org/Door43/en_tn/src/master/luk/19/47.md)

#### Examples from the Bible stories: ####

  __*[24:03](https://git.door43.org/Door43/en_tn/src/master/obs/24/03.md)__ Many __religious leaders__ also came to be baptized by John, but they did not repent or confess their sins.
  __*[37:11](https://git.door43.org/Door43/en_tn/src/master/obs/37/11.md)__ But the __religious leaders of the Jews__ were jealous, so they gathered together to plan how they could kill Jesus and Lazarus.
  __*[38:02](https://git.door43.org/Door43/en_tn/src/master/obs/38/02.md)__ He (Judas) knew that the __Jewish leaders__ denied that Jesus was the Messiah and that they were plotting to kill him.
  __*[38:03](https://git.door43.org/Door43/en_tn/src/master/obs/38/03.md)__ The __Jewish leaders__, led by the high priest, paid Judas thirty silver coins to betray Jesus.
  __*[39:05](https://git.door43.org/Door43/en_tn/src/master/obs/39/05.md)__ The __Jewish leaders__ all answered the high priest, "He (Jesus) deserves to die!"
  __*[39:09](https://git.door43.org/Door43/en_tn/src/master/obs/39/09.md)__ Early the next morning, the __Jewish leaders__ brought Jesus to Pilate, the Roman governor.
  __*[39:11](https://git.door43.org/Door43/en_tn/src/master/obs/39/11.md)__ But the __Jewish leaders__ and the crowd shouted, "Crucify him!"
  __*[40:09](https://git.door43.org/Door43/en_tn/src/master/obs/40/09.md)__ Then Joseph and Nicodemus, two __Jewish leaders__ who believed Jesus was the Messiah, asked Pilate for Jesus' body.
  __*[44:07](https://git.door43.org/Door43/en_tn/src/master/obs/44/07.md)__ The next day, the __Jewish leaders__ brought Peter and John to the high priest and the other __religious leaders__.

#### Word Data:####

* Strong's: G2453


---

<a id="joy"/>

### joy, joyful, joyfully, joyfulness, enjoy, enjoys, enjoyed, enjoying, enjoyment, rejoice, rejoices, rejoiced, rejoicing ###

#### Definition: ####

Joy is a feeling of delight or deep satisfaction that comes from God. The related term "joyful" describes a person who feels very glad and is full of deep happiness.

* A person feels joy when he has a deep sense that what he is experiencing is very good.
* God is the one who gives true joy to people.
* Having joy does not depend on pleasant circumstances. God can give people joy even when very difficult things are happening in their lives.
* Sometimes places are described as joyful, such as houses or cities. This means that the people who live there are joyful.

The term "rejoice" means to be full of joy and gladness.

 * This term often refers to being very happy about the good things that God has done.
 * It could be translated as "be very happy" or "be very glad" or "be full of joy."
 * When Mary said "my soul rejoices in God my Savior," she meant "God my Savior has made me very happy" or "I feel so joyful because of what God my Savior has done for me."

#### Translation Suggestions: ####

* The term "joy" could also be translated as "gladness" or "delight" or "great happiness."
* The phrase, "be joyful" could be translated as "rejoice" or "be very glad" or it could be translated "be very happy in God's goodness."
* A person who is joyful could be described as "very happy" or "delighted" or "deeply glad."
* A phrase such as "make a joyful shout" could be translated as "shout in a way that shows you are very happy."
* A "joyful city" or "joyful house" could be translated as "city where joyful people live" or "house full of joyful people" or "city whose people are very happy." (See: [metonymy](https://git.door43.org/Door43/en_ta/src/master/translate/figs-metonymy.md))

#### Bible References: ####

* [Nehemiah 08:9-10](https://git.door43.org/Door43/en_tn/src/master/neh/08/09.md)
* [Psalm 048:1-3](https://git.door43.org/Door43/en_tn/src/master/psa/048/001.md)
* [Isaiah 56:6-7](https://git.door43.org/Door43/en_tn/src/master/isa/56/06.md)
* [Jeremiah 15:15-16](https://git.door43.org/Door43/en_tn/src/master/jer/15/15.md)
* [Matthew 02:9-10](https://git.door43.org/Door43/en_tn/src/master/mat/02/09.md)
* [Luke 15:6-7](https://git.door43.org/Door43/en_tn/src/master/luk/15/06.md)
* [Luke 19:37-38](https://git.door43.org/Door43/en_tn/src/master/luk/19/37.md)
* [John 03:29-30](https://git.door43.org/Door43/en_tn/src/master/jhn/03/29.md)
* [Acts 16:32-34](https://git.door43.org/Door43/en_tn/src/master/act/16/32.md)
* [Romans 05:1-2](https://git.door43.org/Door43/en_tn/src/master/rom/05/01.md)
* [Romans 15:30-32](https://git.door43.org/Door43/en_tn/src/master/rom/15/30.md)
* [Galatians 05:22-24](https://git.door43.org/Door43/en_tn/src/master/gal/05/22.md)
* [Philippians 04:10-13](https://git.door43.org/Door43/en_tn/src/master/php/04/10.md)
* [1 Thessalonians 01:6-7](https://git.door43.org/Door43/en_tn/src/master/1th/01/06.md)
* [1 Thessalonians 05:15-18](https://git.door43.org/Door43/en_tn/src/master/1th/05/15.md)
* [Philemon 01:4-7](https://git.door43.org/Door43/en_tn/src/master/phm/01/04.md)
* [James 01:1-3](https://git.door43.org/Door43/en_tn/src/master/jas/01/01.md)
* [3 John 01:1-4](https://git.door43.org/Door43/en_tn/src/master/3jn/01/01.md)

#### Examples from the Bible stories: ####

* __[33:07](https://git.door43.org/Door43/en_tn/src/master/obs/33/07.md)__ "The rocky ground is a person who hears God's word and accepts it with __joy__."
* __[34:04](https://git.door43.org/Door43/en_tn/src/master/obs/34/04.md)__ "The kingdom of God is also like hidden treasure that someone hid in a field.. Another man found the treasure and then buried it again. He was so filled with __joy__, that he went and sold everything he had and used the money to buy that field."
* __[41:07](https://git.door43.org/Door43/en_tn/src/master/obs/41/07.md)__ The women were full of fear and great __joy__. They ran to tell the disciples the good news.

#### Word Data:####

* Strong's: H1523, H1524, H1525, H1750, H2302, H2304, H2305, H2654, H2898, H4885, H5937, H5938, H5947, H5965, H5970, H6342, H6670, H7440, H7442, H7444, H7445, H7797, H7832, H8055, H8056, H8057, H8342, H8643, G20, G21, G2165, G2167, G2620, G2744, G2745, G3685, G4640, G4796, G4913, G5463, G5479


---

<a id="judaism"/>

### Judaism, Jewish religion ###

#### Definition: ####

The term "Judaism" refers to the religion practiced by the Jews. It is also referred to as the "Jewish religion."

* In the Old Testament, the term "Jewish religion" is used, while in the New Testament, the term "Judaism" is used.
* Judaism includes all the Old Testament laws and instructions that God gave to the Israelites to obey. It also includes the customs and traditions that have been added to the Jewish religion over time.
* When translating, the term "Jewish religion" or "religion of the Jews" can be used in both the Old and New Testaments.
* "Judaism," however should only be used in the New Testament, since the term did not exist before that time.

(See also: [Jew](kt.html#jew), [law](kt.html#lawofmoses))

#### Bible References: ####

* [Galatians 01:13-14](https://git.door43.org/Door43/en_tn/src/master/gal/01/13.md)

#### Word Data:####

* Strong's: G2454


---

<a id="judgeposition"/>

### judge, judges ###

#### Definition: ####

A judge is a person who decides what is right or wrong when there are disputes between people, usually in matters that pertain to the law.

* In the Bible, God is often referred to as a judge because he is the one perfect judge who makes the final decisions about what is right or wrong.
* After the people of Israel entered the land of Canaan and before they had kings to rule them, God appointed leaders called "judges" to lead them in times of trouble. Often these judges were military leaders who rescued the Israelites by defeating their enemies.
* The term "judge" could also be called "decision-maker" or "leader" or "deliverer" or "governor," depending on the context.

(See also: [governor](#governor), [judge](kt.html#judge), [law](kt.html#lawofmoses))

#### Bible References: ####

* [2 Timothy 04:6-8](https://git.door43.org/Door43/en_tn/src/master/2ti/04/06.md)
* [Acts 07:26-28](https://git.door43.org/Door43/en_tn/src/master/act/07/26.md)
* [Luke 11:18-20](https://git.door43.org/Door43/en_tn/src/master/luk/11/18.md)
* [Luke 12:13-15](https://git.door43.org/Door43/en_tn/src/master/luk/12/13.md)
* [Luke 18:1-2](https://git.door43.org/Door43/en_tn/src/master/luk/18/01.md)
* [Matthew 05:25-26](https://git.door43.org/Door43/en_tn/src/master/mat/05/25.md)
* [Ruth 01:1-2](https://git.door43.org/Door43/en_tn/src/master/rut/01/01.md)

#### Word Data:####

* Strong's: H148, H430, H1777, H1778, H1779, H1780, H1781, H1782, H2940, H4055, H6414, H6415, H6416, H6417, H6419, H8196, H8199, H8201, G350, G1252, G1348, G2919, G2922, G2923


---

<a id="kin"/>

### kin, kinfolk, kindred, kinsfolk, kinsman, kinsmen ###

#### Definition: ####

The term "kin" refers to a person's blood relatives, considered as a group. The word "kinsman" refers specifically to a male relative.

* "Kin" can only refer to a person's close relatives, such as parents and siblings, or it can also include more distant relatives, such as an aunts, uncles, or cousins.
* In ancient Israel, if a man died, his nearest male relative was expected to marry his widow, manage his property, and help carry on his family name. This relative was called a "kinsman-redeemer."
* This term "kin" could also be translated as, "relative" or "family member."
 
#### Bible References: ####

* [Romans 16:9-11](https://git.door43.org/Door43/en_tn/src/master/rom/16/09.md)
* [Ruth 02:19-20](https://git.door43.org/Door43/en_tn/src/master/rut/02/19.md)
* [Ruth 03:8-9](https://git.door43.org/Door43/en_tn/src/master/rut/03/08.md)

#### Word Data:####

* Strong's: H251, H1350, H4129, H4130, H7138, H7607, G4773


---

<a id="kind"/>

### kind, kinds, kindness, kindnesses ###

#### Definition: ####

The terms "kind" and "kinds" refer to groups or classifications of things that are connected by shared characteristics.

* In the Bible, this term is specifically used to refer to the distinctive kinds of plants and animals that God made when he created the world.
* Often there are many different variations or species within each "kind." For example, horses, zebras, and donkeys are all members of the same "kind," but they are different species.
* The main thing that distinguishes each "kind" as a separate group is that members of that group can reproduce more of their same "kind." Members of different kinds cannot do that with each other.

#### Translation Suggestions ####

* Ways to translate this term could include "type" or "class" or "group" or "animal (plant) group" or "category."

#### Bible References: ####

* [Genesis 01:20-21](https://git.door43.org/Door43/en_tn/src/master/gen/01/20.md)
* [Genesis 01:24-25](https://git.door43.org/Door43/en_tn/src/master/gen/01/24.md)
* [Mark 09:28-29](https://git.door43.org/Door43/en_tn/src/master/mrk/09/28.md)
* [Matthew 13:47-48](https://git.door43.org/Door43/en_tn/src/master/mat/13/47.md)

#### Word Data:####

* Strong's: H2178, H3978, H4327, G1085, G5449


---

<a id="king"/>

### king, kings, kingdom, kingdoms, kingship, kingly ###

#### Definition: ####

The term "king" refers to a man who is the supreme ruler of a city, state, or country.

* A king was usually chosen to rule because of his family relation to previous kings.
* When a king died, it was usually his oldest son who became the next king.
* In ancient times, the king had absolute authority over the people in his kingdom.
* Rarely the term "king" was used to refer to someone who was not a true king, such as "King Herod" in the New Testament.
* In the Bible, God is often referred to as a king who rules over his people.
* The "kingdom of God" refers to God's rule over his people.
* Jesus was called "king of the Jews," "king of Israel," and "king of kings."
* When Jesus comes back, he will rule as king over the world.
* This term could also be translated as "supreme chief" or "absolute leader" or "sovereign ruler."
* The phrase "king of kings" could be translated as  "king who rules over all other kings" or "supreme ruler who has authority over all other rulers."

(See also: [authority](kt.html#authority), [Herod Antipas](names.html#herodantipas), [kingdom](#kingdom), [kingdom of God](kt.html#kingdomofgod))

#### Bible References: ####

* [1 Timothy 06:15-16](https://git.door43.org/Door43/en_tn/src/master/1ti/06/15.md)
* [2 Kings 05:17-19](https://git.door43.org/Door43/en_tn/src/master/2ki/05/17.md)
* [2 Samuel 05:3-5](https://git.door43.org/Door43/en_tn/src/master/2sa/05/03.md)
* [Acts 07:9-10](https://git.door43.org/Door43/en_tn/src/master/act/07/09.md)
* [Acts 13:21-22](https://git.door43.org/Door43/en_tn/src/master/act/13/21.md)
* [John 01:49-51](https://git.door43.org/Door43/en_tn/src/master/jhn/01/49.md)
* [Luke 01:5-7](https://git.door43.org/Door43/en_tn/src/master/luk/01/05.md)
* [Luke 22:24-25](https://git.door43.org/Door43/en_tn/src/master/luk/22/24.md)
* [Matthew 05:33-35](https://git.door43.org/Door43/en_tn/src/master/mat/05/33.md)
* [Matthew 14:8-9](https://git.door43.org/Door43/en_tn/src/master/mat/14/08.md)

#### Examples from the Bible stories: ####

  __*[08:06](https://git.door43.org/Door43/en_tn/src/master/obs/08/06.md)__  One night, the Pharaoh, which is what the Egyptians called their kings, had two dreams that disturbed him greatly.
  __*[16:01](https://git.door43.org/Door43/en_tn/src/master/obs/16/01.md)__  The Israelites had no __king__, so everyone did what they thought was right for them.
  __*[16:18](https://git.door43.org/Door43/en_tn/src/master/obs/16/18.md)__  Finally, the people asked God for a __king__ like all the other nations had.
  __*[17:05](https://git.door43.org/Door43/en_tn/src/master/obs/17/05.md)__  Eventually, Saul died in battle, and David became __king__ of Israel. He was a good __king__, and the people loved him.
  __*[21:06](https://git.door43.org/Door43/en_tn/src/master/obs/21/06.md)__  God's prophets also said that the Messiah would be a prophet, a priest, and a __king__.
  __*[48:14](https://git.door43.org/Door43/en_tn/src/master/obs/48/14.md)__  David was the __king__ of Israel, but Jesus is the __king__ of the entire universe!

#### Word Data:####

* Strong's: H4427, H4428, H4430, G935, G936


---

<a id="kingdom"/>

### kingdom, kingdoms ###

#### Definition: ####

A kingdom is a group of people ruled by a king. It also refers to the realm or political regions over which a king or other ruler has control and authority.

* A kingdom can be of any geographical size. A king might govern a nation or country or only one city.
* The term "kingdom" can also refer to a spiritual reign or authority, as in the term "kingdom of God."
* God is the ruler of all creation, but the term "kingdom of God" especially refers to his reign and authority over the people who have believed in Jesus and who have submitted to his authority.
* The Bible also talks about Satan having a "kingdom" in which he temporarily rules over many things on this earth. His kingdom is evil and is referred to as "darkness."

#### Translation Suggestions: ####

* When referring to a physical region that is ruled over by a king, the term "kingdom" could be translated as "country (ruled by a king)" or "king's territory" or "region ruled by a king."
* In a spiritual sense, "kingdom" could be translated as "ruling" or "reigning" or "controlling" or "governing."
* One way to translate "kingdom of priests" might be "spiritual priests who are ruled by God."
* The phrase "kingdom of light" could be translated as "God's reign that is good like light" or "when God, who is light, rules people" or "the light and goodness of God's kingdom." It is best to keep the word "light" in this expression since that is a very important term in the Bible.
* Note that the term "kingdom" is different from an empire, in which an emperor rules over several countries.

(See also: [authority](kt.html#authority), [king](#king), [kingdom of God](kt.html#kingdomofgod), [kingdom of Israel](names.html#kingdomofisrael), [Judah](names.html#judah), [Judah](names.html#kingdomofjudah), [priest](kt.html#priest))

#### Bible References: ####

* [1 Thessalonians 02:10-12](https://git.door43.org/Door43/en_tn/src/master/1th/02/10.md)
* [2 Timothy 04:17-18](https://git.door43.org/Door43/en_tn/src/master/2ti/04/17.md)
* [Colossians 01:13-14](https://git.door43.org/Door43/en_tn/src/master/col/01/13.md)
* [John 18:36-37](https://git.door43.org/Door43/en_tn/src/master/jhn/18/36.md)
* [Mark 03:23-25](https://git.door43.org/Door43/en_tn/src/master/mrk/03/23.md)
* [Matthew 04:7-9](https://git.door43.org/Door43/en_tn/src/master/mat/04/07.md)
* [Matthew 13:18-19](https://git.door43.org/Door43/en_tn/src/master/mat/13/18.md)
* [Matthew 16:27-28](https://git.door43.org/Door43/en_tn/src/master/mat/16/27.md)
* [Revelation 01:9-11](https://git.door43.org/Door43/en_tn/src/master/rev/01/09.md)

#### Examples from the Bible stories: ####

* __[13:02](https://git.door43.org/Door43/en_tn/src/master/obs/13/02.md)__ God said to Moses and the people of Israel, "If you will obey me and keep my covenant, you will be my prized possession, a __kingdom__  of priests, and a holy nation."
* __[18:04](https://git.door43.org/Door43/en_tn/src/master/obs/18/04.md)__ God was angry with Solomon and, as a punishment for Solomon's unfaithfulness, he promised to divide the nation of Israel in two __kingdoms__  after Solomon's death.
* __[18:07](https://git.door43.org/Door43/en_tn/src/master/obs/18/07.md)__ Ten of the tribes of the nation of Israel rebelled against Rehoboam. Only two tribes remained faithful to him. These two tribes became the __kingdom__  of Judah.
* __[18:08](https://git.door43.org/Door43/en_tn/src/master/obs/18/08.md)__ The other ten tribes of the nation of Israel that rebelled against Rehoboam appointed a man named Jeroboam to be their king. They set up their __kingdom__  in the northern part of the land and were called the __kingdom__  of Israel.
* __[21:08](https://git.door43.org/Door43/en_tn/src/master/obs/21/08.md)__ A king is someone who rules over a __kingdom__  and judges the people.

#### Word Data:####

* Strong's: H4410, H4437, H4438, H4467, H4468, H4474, H4475, G932


---

<a id="kiss"/>

### kiss, kisses, kissed, kissing ###

#### Definition: ####

A kiss is an action in which one person puts his lips to another person's lips or face. This term can also be used figuratively.

* Some cultures kiss each other on the cheek as a form of greeting or to say goodbye.
* A kiss can communicate deep love between two people, such as a husband and wife.
* The expression to "kiss someone farewell" means to say goodbye with a kiss.
* Sometimes the word "kiss" is used to mean "say goodbye to." When Elisha said to Elijah, "Let me first go and kiss my father and mother," he wanted to say goodbye to his parents before leaving them to follow Elijah.

#### Bible References: ####

* [1 Thessalonians 05:25-28](https://git.door43.org/Door43/en_tn/src/master/1th/05/25.md)
* [Genesis 27:26-27](https://git.door43.org/Door43/en_tn/src/master/gen/27/26.md)
* [Genesis 29:11-12](https://git.door43.org/Door43/en_tn/src/master/gen/29/11.md)
* [Genesis 31:26-28](https://git.door43.org/Door43/en_tn/src/master/gen/31/26.md)
* [Genesis 45:14-15](https://git.door43.org/Door43/en_tn/src/master/gen/45/14.md)
* [Genesis 48:8-10](https://git.door43.org/Door43/en_tn/src/master/gen/48/08.md)
* [Luke 22:47-48](https://git.door43.org/Door43/en_tn/src/master/luk/22/47.md)
* [Mark 14:43-46](https://git.door43.org/Door43/en_tn/src/master/mrk/14/43.md)
* [Matthew 26:47-48](https://git.door43.org/Door43/en_tn/src/master/mat/26/47.md)

#### Word Data:####

* Strong's: H5390, H5401, G2705, G5368, G5370


---

<a id="know"/>

### know, knows, knew, knowing, knowledge, known, make known, makes known, made known, unknown, foreknew, foreknowledge ###

#### Definition: ####

To "know" means to understand something or to be aware of a fact. The expression "make known" is an expression that means to tell information.

* The term "knowledge" refers to information that people know. It can apply to knowing things in both the physical and spiritual worlds.
* To "know about" God means to understand facts about him because of what he has revealed to us. 
* To "know" God means to have a relationship with him. This also applies to knowing people.
* To know God's will means to be aware of what he has commanded, or to understand what he wants a person to do.
* To "know the Law" means to be aware of what God has commanded or to understand what God has instructed in the laws he gave to Moses.
* Sometimes "knowledge" is used as a synonym for "wisdom," which includes living in a way that is pleasing to God.
* The "knowledge of God" is sometimes used as a synonym for the "fear of Yahweh."

#### Translation Suggestions ####

* Depending on the context, ways to translate "know" could include "understand" or "be familiar with" or "be aware of" or "be acquainted with" or "be in relationship with."
* Some languages have two different words for "know," one for knowing facts and one for knowing a person and having a relationship with him.
* The term "make known" could be translated as "cause people to know" or "reveal" or "tell about" or "explain."
* To "know about" something could be translated as "be aware of" or "be familiar with."
* The expression "know how to" means to understand the process or method of getting something done. It could also be translated as "be able to" or "have the skill to."
* The term "knowledge" could also be translated as "what is known" or "wisdom" or "understanding," depending on the context.

(See also: [law](kt.html#lawofmoses), [reveal](kt.html#reveal), [understand](#understand), [wise](kt.html#wise))

#### Bible References: ####

* [1 Corinthians 02:12-13](https://git.door43.org/Door43/en_tn/src/master/1co/02/12.md)
* [1 Samuel 17:46-47](https://git.door43.org/Door43/en_tn/src/master/1sa/17/46.md)
* [2 Corinthians 02:14-15](https://git.door43.org/Door43/en_tn/src/master/2co/02/14.md)
* [2 Peter 01:3-4](https://git.door43.org/Door43/en_tn/src/master/2pe/01/03.md)
* [Deuteronomy 04:39-40](https://git.door43.org/Door43/en_tn/src/master/deu/04/39.md)
* [Genesis 19:4-5](https://git.door43.org/Door43/en_tn/src/master/gen/19/04.md)
* [Luke 01:76-77](https://git.door43.org/Door43/en_tn/src/master/luk/01/76.md)

#### Word Data:####

* Strong's: H1843, H1844, H1847, H1875, H3045, H3046, H4093, H4486, H5046, H5234, H5475, H5869, G50, G56, G1097, G1107, G1108, G1231, G1492, G1921, G1922, G1987, G2467, G2589, G3877, G4267, G4894


---

<a id="labor"/>

### labor, labors, labored, laborer, laborers ###

#### Definition: ####

The term "labor" refers to doing hard work of any kind.

 * In general, labor is any task which uses energy. It is often implied that the task is difficult.
 * A laborer is a person who does any type of labor.
 * In English, the word "labor" is also used for part of the process of giving birth. Other languages may have a completely different word for this.
 * Ways to translate "labor" could include "work" or "hard work" or "difficult work" or to "work hard."

(See also: [hard](#hard), [labor pains](#laborpains))

#### Bible References: ####

* [1 Thessalonians 02:7-9](https://git.door43.org/Door43/en_tn/src/master/1th/02/07.md)
* [1 Thessalonians 03:4-5](https://git.door43.org/Door43/en_tn/src/master/1th/03/04.md)
* [Galatians 04:10-11](https://git.door43.org/Door43/en_tn/src/master/gal/04/10.md)
* [James 05:4-6](https://git.door43.org/Door43/en_tn/src/master/jas/05/04.md)
* [John 04:37-38](https://git.door43.org/Door43/en_tn/src/master/jhn/04/37.md)
* [Luke 10:1-2](https://git.door43.org/Door43/en_tn/src/master/luk/10/01.md)
* [Matthew 10:8-10](https://git.door43.org/Door43/en_tn/src/master/mat/10/08.md)

#### Word Data:####

* Strong's: H213, H3018, H3021, H3022, H3023, H3205, H5447, H4522, H4639, H5445, H5647, H5656, H5998, H5999, H6001, H6089, H6468, H6635, G75, G2038, G2040, G2041, G2872, G2873, G4704, G4866, G4904, G5389


---

<a id="laborpains"/>

### labor, in labor, labor pains ###

#### Definition: ####

A woman who is "in labor" is experiencing the pains that lead up to the birth of her child. These are called "labor pains."

* In his letter to the Galatians, the apostle Paul used this term figuratively to describe his own intense striving to help his fellow believers become more and more like Christ.
* The analogy of labor pains is also used in the Bible to describe how disasters in the last days will happen with increasing frequency and intensity.

(See also: [labor](#labor), [last day](kt.html#lastday))

#### Bible References: ####

* [1 Samuel 04:19-20](https://git.door43.org/Door43/en_tn/src/master/1sa/04/19.md)
* [Galatians 04:19-20](https://git.door43.org/Door43/en_tn/src/master/gal/04/19.md)
* [Isaiah 13:6-8](https://git.door43.org/Door43/en_tn/src/master/isa/13/06.md)
* [Jeremiah 13:20-21](https://git.door43.org/Door43/en_tn/src/master/jer/13/20.md)
* [Psalms 048:4-6](https://git.door43.org/Door43/en_tn/src/master/psa/048/004.md)
* [Romans 08:20-22](https://git.door43.org/Door43/en_tn/src/master/rom/08/20.md)

#### Word Data:####

* Strong's: H2342, H2470, H3018, H3205, H5999, H6045, H6887, H8513, G3449, G4944, G5088, G5604, G5605


---

<a id="lamp"/>

### lamp, lamps ###

#### Definition: ####

The term "lamp" generally refers to something that produces light. The lamps used in Bible times were usually oil lamps.

The type of lamp that was used in Bible times is a small container with a fuel source, usually oil, that gives light when it burns.

* An ordinary oil lamp usually consisted of a common piece of pottery filled with olive oil, with a wick placed in the oil to burn.
* For some lamps, the pot or jar was oval, with one end pinched close together to hold the wick.
* An oil lamp could be carried or placed on a stand so that its light could fill a room or house.
* In scripture, lamps are used in several figurative ways as symbols of light and life.

(See also: [lampstand](#lampstand), [life](kt.html#life), [light](#light))

#### Bible References: ####

* [1 Kings 11:34-36](https://git.door43.org/Door43/en_tn/src/master/1ki/11/34.md)
* [Exodus 25:3-7](https://git.door43.org/Door43/en_tn/src/master/exo/25/03.md)
* [Luke 08:16-18](https://git.door43.org/Door43/en_tn/src/master/luk/08/16.md)
* [Matthew 05:15-16](https://git.door43.org/Door43/en_tn/src/master/mat/05/15.md)
* [Matthew 06:22-24](https://git.door43.org/Door43/en_tn/src/master/mat/06/22.md)
* [Matthew 25:1-4](https://git.door43.org/Door43/en_tn/src/master/mat/25/01.md)

#### Word Data:####

* Strong's: H3940, H3974, H4501, H5215, H5216, G2985, G3088


---

<a id="lampstand"/>

### lampstand, lampstands ###

#### Definition: ####

In the Bible, the term "lampstand" generally refers to a structure on which a lamp is placed in order to provide light to a room.

* A simple lampstand usually held one lamp and was made of clay, wood, or metal (such as bronze, silver, or gold.)
* In the Jerusalem temple there was a special gold lampstand which had seven branches for holding seven lamps.

#### Translation Suggestions ####

* This term could be also translated as "lamp pedestal" or "structure for holding a lamp" or "lamp holder."
* For the temple lampstand, this could be translated as "seven-lamp lampstand" or "gold pedestal with seven lamps."
* It would also be helpful in a translation to include pictures of a simple lampstand and a seven-branch lampstand in the relevant Bible passages.

(See also: [bronze](#bronze), [gold](#gold), [lamp](#lamp), [light](#light), [silver](#silver), [temple](kt.html#temple))

#### Bible References: ####

* [Daniel 05:5-6](https://git.door43.org/Door43/en_tn/src/master/dan/05/05.md)
* [Exodus 37:17-19](https://git.door43.org/Door43/en_tn/src/master/exo/37/17.md)
* [Mark 04:21-23](https://git.door43.org/Door43/en_tn/src/master/mrk/04/21.md)
* [Matthew 05:15-16](https://git.door43.org/Door43/en_tn/src/master/mat/05/15.md)
* [Revelation 01:12-13](https://git.door43.org/Door43/en_tn/src/master/rev/01/12.md)
* [Revelation 01:19-20](https://git.door43.org/Door43/en_tn/src/master/rev/01/19.md)

#### Word Data:####

* Strong's: H4501, G3087


---

<a id="law"/>

### law, laws, lawgiver, lawbreaker, lawbreakers, lawsuit, lawyer, principle, principled, principles ###

#### Definition: ####

A "law" is a legal rule that is usually written down and enforced by someone in authority. A "principle" is a guideline for decision-making and behavior.

* Both "law" and "principle" can refer to a general rule or belief that guides a person's behavior.
* This meaning of "law" is different from its meaning in the term "law of Moses," where it refers to commands and instructions that God gave the Israelites.
* When a general law is being referred to, "law" could be translated as "principle" or "general rule."

(See also: [law](#law), [law](kt.html#lawofmoses))

#### Bible References: ####

* [Deuteronomy 04:1-2](https://git.door43.org/Door43/en_tn/src/master/deu/04/01.md)
* [Esther 03:8-9](https://git.door43.org/Door43/en_tn/src/master/est/03/08.md)
* [Exodus 12:12-14](https://git.door43.org/Door43/en_tn/src/master/exo/12/12.md)
* [Genesis 26:4-5](https://git.door43.org/Door43/en_tn/src/master/gen/26/04.md)
* [John 18:31-32](https://git.door43.org/Door43/en_tn/src/master/jhn/18/31.md)
* [Romans 07:1](https://git.door43.org/Door43/en_tn/src/master/rom/07/01.md)

#### Word Data:####

* Strong's: H1285, H1881, H1882, H2706, H2708, H2710, H4687, H4941, H6310, H7560, H8451, G1785, G3548, G3551, G4747


---

<a id="lawful"/>

### lawful, lawfully, unlawful, not lawful, lawless, lawlessness ###

#### Definition: ####

The term "lawful" refers to something that is permitted to be done according to a law or other requirement. The opposite of this is "unlawful," which simply means "not lawful." 

* In the Bible, something was "lawful" if it was permitted by God's moral law, or by the Law of Moses and other Jewish laws. Something that was "unlawful" was "not permitted" by those laws.
* To do something "lawfully" means to do it "properly" or "in the right way."
* Many of the things that the Jewish laws considered lawful or not lawful were not in agreement with God's laws about loving others.
* Depending on the context, ways to translate "lawful" could include "permitted" or "according to God's law" or "following our laws" or "proper" or "fitting."
* The phrase "Is it lawful?" could also be translated as "Do our laws allow?" or "Is that something our laws permit?"

The terms "unlawful" and "not lawful" are used to describe actions that break a law.

* In the New Testament, the term "unlawful" is not only used to refer to breaking God's laws, but also often refers to breaking Jewish man-made laws.
* Over the years, the Jews added to the laws that God gave to them. The Jewish leaders would call something "unlawful" if it did not conform to their man-made laws.
* When Jesus and his disciples were picking grain on a Sabbath day, the Pharisees accused them of doing something "unlawful" because it was breaking the Jewish laws about not working on that day.
* When Peter stated that eating unclean foods was "unlawful" for him, he meant that if he ate those foods he would be breaking the laws God had given the Israelites about not eating certain foods.

The term "lawless" describes a person who does not obey laws or rules. When a country or group of people are in a state of "lawlessness," there is widespread disobedience, rebellion, or immorality.

* A lawless person is rebellious and does not obey God's laws.
* The apostle Paul wrote that in the last days there will be a "man of lawlessness," or a "lawless one," who will be influenced by Satan to do evil things.

#### Translation Suggestions: ####

* This term "unlawful" should be translated using a word or expression that means "not lawful" or "lawbreaking." 
* Other ways to translate "unlawful" could be "not permitted" or "not according to God's law" or "not conforming to our laws."
* The expression "against the law" has the same meaning as "unlawful."

* The term "lawless" could also be translated as "rebellious" or "disobedient" or "law-defying".
* The term "lawlessness" could be translated as "not obeying any laws" or "rebellion (against God's laws)."
* The phrase "man of lawlessness" could be translated as "man who does not obey any laws" or "man who rebels against God's laws."
* It is important to keep the concept of "law" in this term, if possible.
* Note that the term "unlawful" has a different meaning from this term.

(See also: [law](#law), [law](kt.html#lawofmoses), [Moses](names.html#moses), [Sabbath](kt.html#sabbath))

#### Bible References: ####

* [Matthew 07:21-23](https://git.door43.org/Door43/en_tn/src/master/mat/07/21.md)
* [Matthew 12:1-2](https://git.door43.org/Door43/en_tn/src/master/mat/12/01.md)
* [Matthew 12:3-4](https://git.door43.org/Door43/en_tn/src/master/mat/12/03.md)
* [Matthew 12:9-10](https://git.door43.org/Door43/en_tn/src/master/mat/12/09.md)
* [Mark 03:3-4](https://git.door43.org/Door43/en_tn/src/master/mrk/03/03.md)
* [Luke 06:1-2](https://git.door43.org/Door43/en_tn/src/master/luk/06/01.md)
* [Acts 02:22-24](https://git.door43.org/Door43/en_tn/src/master/act/02/22.md)
* [Acts 10:27-29](https://git.door43.org/Door43/en_tn/src/master/act/10/27.md)
* [Acts 22:25-26](https://git.door43.org/Door43/en_tn/src/master/act/22/25.md)
* [2 Thessalonians 02:3-4](https://git.door43.org/Door43/en_tn/src/master/2th/02/03.md)
* [Titus 02:14](https://git.door43.org/Door43/en_tn/src/master/tit/02/14.md)
* [1 John 03:4-6](https://git.door43.org/Door43/en_tn/src/master/1jn/03/04.md)


#### Word Data:####

* Strong's: H4941, H6530, H6662, H7386, H7990, G111, G113, G266, G458, G459, G1832, G3545


---

<a id="learnedmen"/>

### learned men, astrologers ###

#### Definition: ####

In Matthew's account of the birth of Christ, the "learned" or "educated" men were the "wise men" who brought gifts to Jesus in Bethlehem sometime after his birth there. They may have been "astrologers," people who study the stars.

* These men traveled a long way from a country far to the east of Israel. It is not known exactly where they came from or who they were. But they were obviously scholars who had studied the stars.
* They may have been descendants of the wise men who served the Babylonian kings in Daniel's time and who were trained in many things, including studying the stars and interpreting dreams.
* Traditionally it has been said that there were three wise men or learned men because of the three gifts they brought to Jesus. However, the Bible text does not say how many there were.

(See also: [Babylon](names.html#babylon), [Bethlehem](names.html#bethlehem), [Daniel](names.html#daniel))

#### Bible References: ####

* [Daniel 02:27-28](https://git.door43.org/Door43/en_tn/src/master/dan/02/27.md)
* [Daniel 05:7](https://git.door43.org/Door43/en_tn/src/master/dan/05/07.md)
* [Matthew 02:1-3](https://git.door43.org/Door43/en_tn/src/master/mat/02/01.md)
* [Matthew 02:7-8](https://git.door43.org/Door43/en_tn/src/master/mat/02/07.md)
* [Matthew 02:16](https://git.door43.org/Door43/en_tn/src/master/mat/02/16.md)

#### Word Data:####

* Strong's: H1505, G3097


---

<a id="leopard"/>

### leopard, leopards ###

#### Facts: ####

A leopard is a large, cat-like, wild animal that is brown with black spots.

* A leopard is a kind of animal which catches other animals and eats them.
* In the Bible, the suddenness of disaster is compared to a leopard, which pounces suddenly on its prey.
* The prophet Daniel and the apostle John tell about visions in which they saw a beast that looked like a leopard.

(See also: [How to Translate Unknowns](https://git.door43.org/Door43/en_ta/src/master/translate/translate-unknown.md))

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_ta/src/master/translate/translate-names.md))

(See also: [beast](#beast), [Daniel](names.html#daniel), [prey](#prey), [vision](#vision))

#### Bible References: ####

* [Daniel 07:6-7](https://git.door43.org/Door43/en_tn/src/master/dan/07/06.md)
* [Hosea 13:7-8](https://git.door43.org/Door43/en_tn/src/master/hos/13/07.md)
* [Revelation 13:1-2](https://git.door43.org/Door43/en_tn/src/master/rev/13/01.md)
* [Song of Solomon 04:8](https://git.door43.org/Door43/en_tn/src/master/sng/04/08.md)

#### Word Data:####

* Strong's: H5245, H5246


---

<a id="leprosy"/>

### leper, lepers, leprosy, leprous ###

#### Definition: ####

The term "leprosy" is used in the Bible to refer to several different skin diseases. A "leper" is a person who has leprosy. The term "leprous" describes a person or body part that is infected with leprosy.

* Certain kinds of leprosy cause the skin to become discolored with white patches, as when Miriam and Naaman had leprosy.
* In modern times, leprosy often causes hands, feet, and other body parts to become damaged and deformed.
* According to the instructions that God gave to the Israelites, when a person had leprosy, he was considered "unclean" and had to stay away from other people so that they would not become infected with the disease.
* A leper would often call out "unclean" so that others would be warned not to come near him.
* Jesus healed many lepers, and also people who had other kinds of diseases.

#### Translation Suggestions: ####

* The term "leprosy" in the Bible can be translated as "skin disease" or "dreaded skin disease."
* Ways to translate "leprous" could include  "full of leprosy" or "infected with skin disease" or "covered with skin sores."

(See also: [Miriam](names.html#miriam), [Naaman](names.html#naaman), [clean](kt.html#clean))

#### Bible References: ####

* [Luke 05:12-13](https://git.door43.org/Door43/en_tn/src/master/luk/05/12.md)
* [Luke 17:11-13](https://git.door43.org/Door43/en_tn/src/master/luk/17/11.md)
* [Mark 01:40-42](https://git.door43.org/Door43/en_tn/src/master/mrk/01/40.md)
* [Mark 14:3-5](https://git.door43.org/Door43/en_tn/src/master/mrk/14/03.md)
* [Matthew 08:1-3](https://git.door43.org/Door43/en_tn/src/master/mat/08/01.md)
* [Matthew 10:8-10](https://git.door43.org/Door43/en_tn/src/master/mat/10/08.md)
* [Matthew 11:4-6](https://git.door43.org/Door43/en_tn/src/master/mat/11/04.md)

#### Word Data:####

* Strong's: H6879, H6883, G3014, G3015


---

<a id="letter"/>

### epistle, letter, letters ###

#### Definition: ####

A letter is a written message sent to a person or group of persons who are usually a distance away from the writer. An epistle is a special type of letter, often written in a more formal style, for a special purpose, such as teaching.

* In New Testament times, epistles and other types of letters were written on parchment made from animal skins or on papyrus made from plant fibers.
* The New Testament epistles from Paul, John, James, Jude, and Peter were letters of instruction that they wrote to encourage, exhort, and teach the early Christians in various cities throughout the Roman Empire.
* Ways to translate this term could include "written message" or "written down words" or "writing."

(See also: [encourage](#encourage), [exhort](kt.html#exhort), [teach](#teach))

#### Bible References: ####

* [1 Thessalonians 05:25-28](https://git.door43.org/Door43/en_tn/src/master/1th/05/25.md)
* [2 Thessalonians 02:13-15](https://git.door43.org/Door43/en_tn/src/master/2th/02/13.md)
* [Acts 09:1-2](https://git.door43.org/Door43/en_tn/src/master/act/09/01.md)
* [Acts 28:21-22](https://git.door43.org/Door43/en_tn/src/master/act/28/21.md)

#### Word Data:####

* Strong's: H104, H107, H3791, H4385, H5406, H5407, H5612, H6600, G1121, G1989, G1992


---

<a id="light"/>

### light, lights, lighting, lightning, daylight, sunlight, twilight, enlighten, enlightened ###

#### Definition: ####

There are several figurative uses of the term "light" in the Bible. It is often used as a metaphor for righteousness, holiness, and truth. (See: [Metaphor](https://git.door43.org/Door43/en_ta/src/master/translate/figs-metaphor.md))

* Jesus said, "I am the light of the world" to express that he brings God's true message to the world and rescues people from the darkness of their sin.
* Christians are commanded to "walk in the light," which means they should be living the way God wants them to and avoiding evil.
* The apostle John stated that "God is light" and in him there is no darkness at all.
* Light and darkness are complete opposites. Darkness is the absence of all light. 
* Jesus said that he was "the light of the world" and that his followers should shine like lights in the world by living in a way that clearly shows how great God is.
* "Walking in the light" represents living in a way that pleases God, doing what is good and right. Walking in darkness represents living in rebellion against God, doing evil things.
 
#### Translation Suggestions: ####

* When translating, it is important to keep the literal terms "light" and "darkness" even when they are used figuratively.
* It may be necessary to explain the comparison in the text. For example, "walk as children of light" could be translated as, "live openly righteous lives, like someone who walks in bright sunlight."
* Make sure that the translation of "light" does not refer to an object that gives light, such as a lamp. The translation of this term should refer to the light itself.

(See also: [darkness](#darkness), [holy](kt.html#holy), [righteous](kt.html#righteous), [true](kt.html#true))

#### Bible References: ####

* [1 John 01:5-7](https://git.door43.org/Door43/en_tn/src/master/1jn/01/05.md)
* [1 John 02:7-8](https://git.door43.org/Door43/en_tn/src/master/1jn/02/07.md)
* [2 Corinthians 04:5-6](https://git.door43.org/Door43/en_tn/src/master/2co/04/05.md)
* [Acts 26:15-18](https://git.door43.org/Door43/en_tn/src/master/act/26/15.md)
* [Isaiah 02:5-6](https://git.door43.org/Door43/en_tn/src/master/isa/02/05.md)
* [John 01:4-5](https://git.door43.org/Door43/en_tn/src/master/jhn/01/04.md)
* [Matthew 05:15-16](https://git.door43.org/Door43/en_tn/src/master/mat/05/15.md)
* [Matthew 06:22-24](https://git.door43.org/Door43/en_tn/src/master/mat/06/22.md)
* [Nehemiah 09:12-13](https://git.door43.org/Door43/en_tn/src/master/neh/09/12.md)
* [Revelation 18:23-24](https://git.door43.org/Door43/en_tn/src/master/rev/18/23.md)

#### Word Data:####

* Strong's: H216, H217, H3313, H3974, H4237, H5051, H5094, H5105, H5216, H6348, H7052, H7837, G681, G796, G1645, G2985, G3088, G5338, G5457, G5458, G5460, G5462


---

<a id="like"/>

### like, likeminded, liken, likeness, likenesses, likewise, alike, unlike ###

#### Definition: ####

The terms "like" and "likeness" refer to something being the same as, or similar to, something else.

* The word "like" is also often used in a figurative expressions called a "simile" in which something is compared to something else, usually highlighting a shared characteristic. For example, "his clothes shined like the sun" and "the voice boomed like thunder." (See: [Simile](https://git.door43.org/Door43/en_ta/src/master/translate/figs-simile.md))
* To "be like" or "sound like" or "look like" something or someone means to have qualities that are similar to the thing or person being compared to.
* People were created in God's "likeness," that is, in his "image." It means that they have qualities or characteristics that are "like" or "similar to" qualities that God has, such as the ability to think, feel, and communicate.
* To have "the likeness of" something or someone means to have characteristics that look like that thing or person.

#### Translation Suggestions ####

* In some contexts, the expression "the likeness of" could be translated as "what looked like" or "what appeared to be."
* The expression "in the likeness of his death" could be translated as "sharing in the experience of his death" or "as if experiencing his death with him."
* The expression "in the likeness of sinful flesh" could be translated as "being like a sinful human being" or to "be a human being." Make sure the translation of this expression does not sound like Jesus was sinful.
* "In his own likeness" could also be translated as to "be like him" or "having many of the same qualities that he has."
* The expression "the likeness of an image of perishable man, of birds, of four-footed beasts and of creeping things" could be translated as "idols made to look like perishable humans, or animals, such as birds, beasts, and small, crawling things."

(See also: [beast](#beast), [flesh](kt.html#flesh), [image of God](kt.html#imageofgod), [image](#image), [perish](kt.html#perish))

#### Bible References: ####

* [Ezekiel 01:4-6](https://git.door43.org/Door43/en_tn/src/master/ezk/01/04.md)
* [Mark 08:24-26](https://git.door43.org/Door43/en_tn/src/master/mrk/08/24.md)
* [Matthew 17:1-2](https://git.door43.org/Door43/en_tn/src/master/mat/17/01.md)
* [Matthew 18:1-3](https://git.door43.org/Door43/en_tn/src/master/mat/18/01.md)
* [Psalms 073:4-5](https://git.door43.org/Door43/en_tn/src/master/psa/073/004.md)
* [Revelation 01:12-13](https://git.door43.org/Door43/en_tn/src/master/rev/01/12.md)

#### Word Data:####

* Strong's: H1823, H8403, H8544, G1503, G1504, G2509, G2531, G2596, G3664, G3665, G3666, G3667, G3668, G3669, G3697, G4833, G5108, G5613, G5615, G5616, G5618, G5619


---

<a id="lion"/>

### lions, lion, lioness, lionesses ###

#### Definition: ####

A lion is a large, cat-like, that has animal, with powerful teeth and claws for killing and tearing apart its prey.

* Lions have powerful bodies and great speed to catch their prey. Their fur is short and golden-brown.
* Male lions have a mane of hair that encircles their heads.
* Lions kill other animals to eat them and can be dangerous to human beings.
* When King David was a boy, he killed lions that tried to attack the sheep he was caring for.
* Samson also killed a lion, with his bare hands.

(See also: [How to Translate Unknowns](https://git.door43.org/Door43/en_ta/src/master/translate/translate-unknown.md))

(See also: [David](names.html#david), [leopard](#leopard), [Samson](names.html#samson), [sheep](#sheep))

#### Bible References: ####

* [1 Chronicles 11:22-23](https://git.door43.org/Door43/en_tn/src/master/1ch/11/22.md)
* [1 Kings 07:27-29](https://git.door43.org/Door43/en_tn/src/master/1ki/07/27.md)
* [Proverbs 19:11-12](https://git.door43.org/Door43/en_tn/src/master/pro/19/11.md)
* [Psalms 017:11-12](https://git.door43.org/Door43/en_tn/src/master/psa/017/011.md)
* [Revelation 05:3-5](https://git.door43.org/Door43/en_tn/src/master/rev/05/03.md)

#### Word Data:####

* Strong's: H738, H739, H744, H3715, H3833, H3918, H7826, H7830, G3023


---

<a id="livestock"/>

### livestock ###

#### Facts: ####

The term "livestock" refers to animals which are raised to provide food and other useful products. Some types of livestock are also trained as work animals.

* Kinds of livestock include sheep, cattle, goats, horses, and donkeys.
* In Biblical times, wealth was partly measured by how much livestock a person had.
* Livestock are used to produce items such as wool, milk, cheese, housing materials, and clothing.
* This term could also be translated as "farm animals."

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_ta/src/master/translate/translate-names.md))

(See also: [cow](#cow), [donkey](#donkey), [goat](#goat), [horse](#horse), [ox](#ox), [sheep](#sheep)) 

#### Bible References: ####

* [2 Kings 03:15-17](https://git.door43.org/Door43/en_tn/src/master/2ki/03/15.md)
* [Genesis 30:29-30](https://git.door43.org/Door43/en_tn/src/master/gen/30/29.md)
* [Joshua 01:14-15](https://git.door43.org/Door43/en_tn/src/master/jos/01/14.md)
* [Nehemiah 09:36-37](https://git.door43.org/Door43/en_tn/src/master/neh/09/36.md)
* [Numbers 03:40-41](https://git.door43.org/Door43/en_tn/src/master/num/03/40.md)

#### Word Data:####

* Strong's: H929, H4399, H4735


---

<a id="locust"/>

### locust, locusts ###

#### Facts: ####

The term "locust" refers to a type of large, flying grasshopper that sometimes flies with many other of its kind in a very destructive swarm that eats all vegetation. 
 
* Locusts and other grasshoppers are large, straight-winged insects with long, jointed back legs that give them the ability to jump a long distance way.
* In the Old Testament, swarming locusts were referred to figuratively as a symbol or picture of the overwhelming devastation that would come as a result of Israel's disobedience.
* God sent locusts as one of the ten plagues against the Egyptians. 
* The New Testament says that locusts were a main source of food for John the Baptist while he was living in the desert. 

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_ta/src/master/translate/translate-names.md))

(See also: [captive](#captive), [Egypt](names.html#egypt), [Israel](kt.html#israel), [John (the Baptist)](names.html#johnthebaptist), [plague](#plague))

#### Bible References: ####

* [2 Chronicles 06:28-31](https://git.door43.org/Door43/en_tn/src/master/2ch/06/28.md)
* [Deuteronomy 28:38-39](https://git.door43.org/Door43/en_tn/src/master/deu/28/38.md)
* [Exodus 10:3-4](https://git.door43.org/Door43/en_tn/src/master/exo/10/03.md)
* [Mark 01:4-6](https://git.door43.org/Door43/en_tn/src/master/mrk/01/04.md)
* [Proverbs 30:27-28](https://git.door43.org/Door43/en_tn/src/master/pro/30/27.md)

#### Word Data:####

* Strong's: H697, H1357, H1462, H1501, H2284, H3218, H5556, H6767, G200


---

<a id="loins"/>

### loins ###

#### Definition: ####

The term "loins" refers to the part of the body of an animal or person that is between the lower ribs and the hip bones, also known as the lower abdomen. 

* The expression "gird up the loins" refers to preparing to work hard. It comes from the custom of tucking the bottom of one's robe into a belt around the waist in order to move with ease.
* The term "loins" is often used in the Bible to refer to the lower back part of an animal that was sacrificed.
* In the Bible, the term "loins" often refers figuratively and euphemistically to a man's reproductive organs as the source of his descendants. (See: [euphemism](https://git.door43.org/Door43/en_ta/src/master/translate/figs-euphemism.md))
* The expression "will come from your loins" could also be translated as, "will be your offspring" or "will be born from your seed" or "God will cause to come from you." (See: [euphemism](https://git.door43.org/Door43/en_ta/src/master/translate/figs-euphemism.md))
* When referring to a part of the body, this could also be translated as "abdomen" or "hips" or "waist," depending on the context.

(See also: [descendant](#descendant), [gird](#gird), [offspring](#offspring))

#### Bible References: ####

* [1 Peter 01:13-14](https://git.door43.org/Door43/en_tn/src/master/1pe/01/13.md)
* [2 Chronicles 06:7-9](https://git.door43.org/Door43/en_tn/src/master/2ch/06/07.md)
* [Deuteronomy 33:11](https://git.door43.org/Door43/en_tn/src/master/deu/33/11.md)
* [Genesis 37:34-36](https://git.door43.org/Door43/en_tn/src/master/gen/37/34.md)
* [Job 15:27-28](https://git.door43.org/Door43/en_tn/src/master/job/15/27.md)

#### Word Data:####

* Strong's: H2504, H2783, H3409, H3689, H4975, G3751


---

<a id="lots"/>

### lots, casting lots ###

#### Definition: ####

A "lot" is a marked object that is chosen from among other similar objects as a way of deciding something. "Casting lots" referred to tossing marked objects onto the ground or other surface.

* Often the lots were small marked stones or pieces of broken pottery.
* Some cultures "draw" or "pull out" lots using a bunch of straws. Someone holds the straws so that no one can see how long they are. Each person pulls out a straw and the one who picks the longest (or shortest) straw is the one who is chosen.
* The practice of casting lots was used by the Israelites to find out what God wanted them to do.
* As in the time of Zechariah and Elizabeth, it was also used to choose which priest would perform a specific duty in the temple at a specific time.
* The soldiers who crucified Jesus cast lots to decide who would get to keep Jesus' robe.
* The phrase "casting lots" can be translated as "tossing lots" or "drawing lots" or "rolling lots." Make sure the translation of "cast" does not sound like the lots were being thrown a long distance.
* Depending on the context, the term "lot" could also be translated as "marked stone" or "pottery piece" or "stick" or "piece of straw."
* If a decision is made "by lot" this could be translated as, "by drawing (or throwing) lots."

(See also: [Elizabeth](names.html#elizabeth), [priest](kt.html#priest), [Zechariah (OT)](names.html#zechariahot), [Zechariah (NT)](names.html#zechariahnt))                                                  

#### Bible References: ####

* [Jonah 01:6-7](https://git.door43.org/Door43/en_tn/src/master/jon/01/06.md)
* [Luke 01:8-10](https://git.door43.org/Door43/en_tn/src/master/luk/01/08.md)
* [Luke 23:33-34](https://git.door43.org/Door43/en_tn/src/master/luk/23/33.md)
* [Mark 15:22-24](https://git.door43.org/Door43/en_tn/src/master/mrk/15/22.md)
* [Matthew 27:35-37](https://git.door43.org/Door43/en_tn/src/master/mat/27/35.md)
* [Psalms 022:18-19](https://git.door43.org/Door43/en_tn/src/master/psa/022/018.md)

#### Word Data:####

* Strong's: H1486, H2256, H5307, G2624, G2819, G2975, G3091


---

<a id="lover"/>

### lover, lovers ###

#### Definition: ####

The term "lover" literally means "person who loves." Usually this refers to people who are in a sexual relationship with each other.

* When the term "lover" is used in the Bible, it usually refers to a person who is involved in a sexual relationship with someone he or she is not married to.
* This wrong sexual relationship is often used in the Bible to refer to Israel's disobedience to God in worshiping idols. So the term "lovers" is also used in a figurative way to refer to the idols that the people of Israel worshiped. In these contexts, this term could possibly be translated by "immoral partners" or "partners in adultery" or "idols." [See  Metaphor]
* A "lover" of money is someone who puts too much importance on getting money and being rich.
* In the Old Testament book Song of Songs, the term "lover" is used in a positive way.
 
(See also: [adultery](kt.html#adultery), [false god](kt.html#falsegod), [false god](kt.html#falsegod), [love](kt.html#love))

#### Bible References: ####

* [Hosea 02:4-5](https://git.door43.org/Door43/en_tn/src/master/hos/02/04.md)
* [Jeremiah 03:1-2](https://git.door43.org/Door43/en_tn/src/master/jer/03/01.md)
* [Lamentations 01:1-2](https://git.door43.org/Door43/en_tn/src/master/lam/01/01.md)
* [Luke 16:14-15](https://git.door43.org/Door43/en_tn/src/master/luk/16/14.md)

#### Word Data:####

* Strong's: H157, H158, H868, H5689, H7453, H8566, G865, G866, G5358, G5366, G5367, G5369, G5377, G5381, G5382


---

<a id="lowly"/>

### lowly, lowliest, lowliness ###

#### Definition: ####

The terms "lowly" and "lowliness" refer to being poor or having low status. Being lowly can also have the meaning of being humble.

* Jesus humbled himself to the lowly position of becoming a human being and serving others.
* His birth was lowly because he was born in a place where animals were kept, not in a palace.
* Having a lowly attitude is the opposite of being proud.
* Ways to translate "lowly" could include "humble" or "of low status" or "unimportant."
* The word "lowliness" could also be translated as "humility" or "little importance."

(See also: [humble](kt.html#humble), [proud](#proud))

#### Bible References: ####

* [Acts 20:17-21](https://git.door43.org/Door43/en_tn/src/master/act/20/17.md)
* [Ezekiel 17:13-14](https://git.door43.org/Door43/en_tn/src/master/ezk/17/13.md)
* [Luke 01:48-49](https://git.door43.org/Door43/en_tn/src/master/luk/01/48.md)
* [Romans 12:14-16](https://git.door43.org/Door43/en_tn/src/master/rom/12/14.md)

#### Word Data:####

* Strong's: H6041, H6819, H8217, G5011, G5012, G5014


---

<a id="lust"/>

### lust, lusts, lusted, lusting, lustful ###

#### Definition: ####

Lust is a very strong desire, usually in the context of wanting something sinful or immoral. To lust is to have lust.

* In the Bible, "lust" usually referred to sexual desire for someone other than one's own spouse.
* Sometimes this term was used in a figurative sense to refer to worshiping idols.
* Depending on the context, "lust" could be translated as "wrong desire" or "strong desire" or "wrongful sexual desire" or "strong immoral desire" or to "strongly desire to sin."
* The phrase to "lust after" could be translated as to "wrongly desire" or to "think immorally about" or to "immorally desire."

 (See also: [adultery](kt.html#adultery), [false god](kt.html#falsegod)) 

#### Bible References: ####

* [1 John 02:15-17](https://git.door43.org/Door43/en_tn/src/master/1jn/02/15.md)
* [2 Timothy 02:22-23](https://git.door43.org/Door43/en_tn/src/master/2ti/02/22.md)
* [Galatians 05:16-18](https://git.door43.org/Door43/en_tn/src/master/gal/05/16.md)
* [Galatians 05:19-21](https://git.door43.org/Door43/en_tn/src/master/gal/05/19.md)
* [Genesis 39:7-9](https://git.door43.org/Door43/en_tn/src/master/gen/39/07.md)
* [Matthew 05:27-28](https://git.door43.org/Door43/en_tn/src/master/mat/05/27.md)

#### Word Data:####

* Strong's: H183, H185, H310, H1730, H2181, H2183, H2530, H5178, H5375, H5689, H5691, H5869, H7843, H8307, H8378, G766, G1937, G1938, G1939, G1971, G2237, G3715, G3806


---

<a id="lute"/>

### lute, lyre, lyres ###

#### Definition: ####

A lute and a lyre are small, stringed, musical instruments that were used by the Israelites to worship God.

* A lyre looks like a small harp, having strings strung across an open frame.
* A lute is very similar to a modernday acoustic guitar, having a wooden sound box and an extended neck on which strings are strung.
* In playing a lute or a lyre, certain strings are held down with the fingers of one hand while these and  other strings are plucked or strummed with the other hand.
* The lute, lyre, and harp are all played by strumming or plucking the strings.
* The number of strings varied, but the Old Testament specifically mentions instruments that had ten strings.
 

(See also: [harp](#harp))

#### Bible References: ####

* [1 Kings 10:11-12](https://git.door43.org/Door43/en_tn/src/master/1ki/10/11.md)
* [1 Samuel 10:5-6](https://git.door43.org/Door43/en_tn/src/master/1sa/10/05.md)
* [2 Chronicles 05:11-12](https://git.door43.org/Door43/en_tn/src/master/2ch/05/11.md)

#### Word Data:####

* Strong's: H3658, H5035, H5443


---

<a id="magic"/>

### magic, magical, magician, magicians ###

#### Definition: ####

The term "magic" refers to the practice of using supernatural power that does not come from God. A "magician" is someone who practices magic.

* In Egypt, when God did miraculous things through Moses, the Egyptian pharaoh's magicians were able to do some of the same things, but their power did not come from God.
* Magic often involves casting spells or repeating certain words in order to make something supernatural happen.
* God commands his people to not do any of these practices of magic or divination.
* A sorcerer is a type of magician, usually one who uses magic to do harm to others.

(See also: [divination](#divination), [Egypt](names.html#egypt), [Pharaoh](names.html#pharaoh), [power](kt.html#power), [sorcery](#sorcery))

#### Bible References: ####

* [Genesis 41:7-8](https://git.door43.org/Door43/en_tn/src/master/gen/41/07.md)
* [Genesis 41:22-24](https://git.door43.org/Door43/en_tn/src/master/gen/41/22.md)
* [Genesis 44:3-5](https://git.door43.org/Door43/en_tn/src/master/gen/44/03.md)
* [Genesis 44:14-15](https://git.door43.org/Door43/en_tn/src/master/gen/44/14.md)

#### Word Data:####

* Strong's: H2748, H2749, H3049, G3097


---

<a id="magistrate"/>

### magistrate, magistrates ###

#### Definition: ####

A magistrate is an appointed official who acts as a judge and decides matters of law.

* In Bible times, a magistrate also settled disputes between people.
* Depending on the context, ways to translate this term could include "ruling judge" or "legal officer" or "city leader."

(See also: [judge](#judgeposition), [law](kt.html#lawofmoses))

#### Bible References: ####

* [Acts 16:19-21](https://git.door43.org/Door43/en_tn/src/master/act/16/19.md)
* [Acts 16:35-36](https://git.door43.org/Door43/en_tn/src/master/act/16/35.md)
* [Daniel 03:1-2](https://git.door43.org/Door43/en_tn/src/master/dan/03/01.md)
* [Luke 12:57-59](https://git.door43.org/Door43/en_tn/src/master/luk/12/57.md)

#### Word Data:####

* Strong's: H6114, H8200, H8614, G758, G3980, G4755


---

<a id="manager"/>

### manager, managers, steward, stewards, stewardship ###

#### Definition: ####

The term "manager" or "steward" in the Bible refers to a servant who was entrusted with taking care of his master's property and business dealings.

* A steward was given a lot of responsibility, which included supervising the work of other servants.
* The term "manager" is a more modern term for a steward. Both terms refer to someone who manages practical affairs for someone else.

#### Translation Suggestions: ####

* This could also be translated as "supervisor" or "household organizer" or "servant who manages" or "person who organizes."

(See also: [servant](#servant))

#### Bible References: ####

* [1 Timothy 03:4-5](https://git.door43.org/Door43/en_tn/src/master/1ti/03/04.md)
* [Genesis 39:3-4](https://git.door43.org/Door43/en_tn/src/master/gen/39/03.md)
* [Genesis 43:16-17](https://git.door43.org/Door43/en_tn/src/master/gen/43/16.md)
* [Isaiah 55:10-11](https://git.door43.org/Door43/en_tn/src/master/isa/55/10.md)
* [Luke 08:1-3](https://git.door43.org/Door43/en_tn/src/master/luk/08/01.md)
* [Luke 16:1-2](https://git.door43.org/Door43/en_tn/src/master/luk/16/01.md)
* [Matthew 20:8-10](https://git.door43.org/Door43/en_tn/src/master/mat/20/08.md)
* [Titus 01:6-7](https://git.door43.org/Door43/en_tn/src/master/tit/01/06.md)

#### Word Data:####

* Strong's: H376, H4453, H5057, H6485, G2012, G3621, G3623


---

<a id="mealoffering"/>

### grain offering, grain offerings, meal offerings ###

#### Definition: ####

A "meal offering" or "grain offering" was a sacrifice to God in the form of grain or bread made out of grain flour.

* The term "meal" refers to grain that has been ground up into flour.
* The flour was mixed with water or oil to make a flat bread. Sometimes oil was spread on top of the bread.
* This kind of offering was usually offered together with a burnt offering. 

(See also: [burnt offering](#burntoffering), [grain](#grain), [sacrifice](#sacrifice))

#### Bible References: ####

* [Ezekiel 44:30-31](https://git.door43.org/Door43/en_tn/src/master/ezk/44/30.md)
* [Joel 02:14](https://git.door43.org/Door43/en_tn/src/master/jol/02/14.md)

#### Word Data:####

* Strong's: H4503, H8641


---

<a id="mediator"/>

### mediator ###

#### Definition: ####

A mediator is a person who helps two or more people to resolve their disagreements or conflicts with each other. He helps them to become reconciled.

* Because people have sinned, they are God's enemies who deserve his wrath and punishment. Because of sin, the relationship between God and his people is broken.
* Jesus is the mediator between God the Father and his people, restoring that broken relationship through his death as payment for their sin.

#### Translation Suggestions: ####

* Ways to translate "mediator" could be "go-between person" or "reconciler" or "person who brings peace."
* Compare this term with how the term "priest" is translated. It is best if the term "mediator" is translated differently.

(See also: [priest](kt.html#priest), [reconcile](kt.html#reconcile))

#### Bible References: ####

* [1 Timothy 02:5-7](https://git.door43.org/Door43/en_tn/src/master/1ti/02/05.md)
* [Galatians 03:19-20](https://git.door43.org/Door43/en_tn/src/master/gal/03/19.md)
* [Hebrews 08:6-7](https://git.door43.org/Door43/en_tn/src/master/heb/08/06.md)
* [Hebrews 12:22-24](https://git.door43.org/Door43/en_tn/src/master/heb/12/22.md)
* [Luke 12:13-15](https://git.door43.org/Door43/en_tn/src/master/luk/12/13.md)

#### Word Data:####

* Strong's: H3887, G3312, G3316


---

<a id="meditate"/>

### meditate, meditates, meditation ###

#### Definition: ####

"The term meditate" means to spend time thinking about something carefully and deeply.

* This term is often used in the Bible to refer to thinking about God and his teachings.
* Psalm 1 says that the person who meditates on the law of the Lord  "day and night" will be greatly blessed.

#### Translation Suggestions: ####

* To "meditate on" could be translated as to "think about carefully and deeply" or to "consider thoughtfully" or to "think about often."
* The noun form is "meditation" and could be translated as "deep thoughts." A phrase like "meditation of my heart" could be translated as "what I think deeply about" or "what I often think about."

#### Bible References: ####

* [Genesis 24:63-65](https://git.door43.org/Door43/en_tn/src/master/gen/24/63.md)
* [Joshua 01:8-9](https://git.door43.org/Door43/en_tn/src/master/jos/01/08.md)
* [Psalm 001:1-2](https://git.door43.org/Door43/en_tn/src/master/psa/001/001.md)
* [Psalms 119:15-16](https://git.door43.org/Door43/en_tn/src/master/psa/119/015.md)

#### Word Data:####

* Strong's: H1897, H1900, H1901, H1902, H7742, H7878, H7879, H7881, G3191, G4304


---

<a id="meek"/>

### meek, meekness ###

#### Definition: ####

The term "meek" describes a person who is gentle, submissive, and willing to suffer injustice. Meekness is the ability to be gentle even when harshness or force might seem appropriate.

* Meekness is often associated with humility.
* This term could also be translated as "gentle" or "mild-mannered" or "sweet-tempered."
* The term "meekness" could be translated as "gentleness" or "humility."

(See also: [humble](kt.html#humble))

#### Bible References: ####

* [1 Peter 03:15-17](https://git.door43.org/Door43/en_tn/src/master/1pe/03/15.md)
* [2 Corinthians 10:1-2](https://git.door43.org/Door43/en_tn/src/master/2co/10/01.md)
* [2 Timothy 02:24-26](https://git.door43.org/Door43/en_tn/src/master/2ti/02/24.md)
* [Matthew 05:5-8](https://git.door43.org/Door43/en_tn/src/master/mat/05/05.md)
* [Matthew 11:28-30](https://git.door43.org/Door43/en_tn/src/master/mat/11/28.md)
* [Psalms 037:11-13](https://git.door43.org/Door43/en_tn/src/master/psa/037/011.md)

#### Word Data:####

* Strong's: H6035, H6037, H6038, G4235, G4236, G4239, G4240


---

<a id="melt"/>

### melt, melted, melting, melts, molten ###

#### Facts: ####
The term "melt" refers to something becoming liquid when it is heated. It is also used in figurative ways. Something that is melted is described as being "molten."

* Different kinds of metals are heated until they melt and can be poured into molds in order to make things such as weapons or idols. The expression "molten metal" refers to a metal that is melted.
* As a candle burns, its wax melts and drips. In ancient times, letters were often sealed by pouring a small amount of melted wax on the edges.
* A figurative use of "melt" means to become soft and weak, like melted wax. 
* The expression "their hearts will melt" means that they will become very weak because of fear.
* Another figurative expression "they will melt away" means that they will be forced to go away or they will be shown to be weak and will go away in defeat.
* The literal meaning of "melt" could be translated as "become liquid" or "liquefy" or "cause to become liquid."
* Other ways to translate the figurative meanings of "melt" could include "become soft" or "become weak" or "be defeated."

(See also: [heart](kt.html#heart), [false god](kt.html#falsegod), [image](#image), [seal](#seal))

#### Bible References: ####

* [Psalms 112:10](https://git.door43.org/Door43/en_tn/src/master/psa/112/010.md)

#### Word Data:####

* Strong's: H1811, H2003, H2046, H3988, H4127, H4529, H4541, H4549, H5140, H5258, H5413, H6884, H8557, G3089, G5080


---

<a id="member"/>

### member, members ###

#### Definition: ####

The term "member" refers to one part of a complex body or group.

* The New Testament describes Christians as "members" of the body of Christ. Believers in Christ belong to a group that is made up of many members. 
* Jesus Christ is the "head" of the body and individual believers function as the members of the body. The Holy Spirit gives each member of the body a special role to help the entire body to function well.
* Individuals who participate in groups such as the Jewish Council and the Pharisees are also called "members" of these groups.

(See also: [body](kt.html#body), [Pharisee](kt.html#pharisee), [council](#council))

#### Bible References: ####

* [1 Corinthians 06:14-15](https://git.door43.org/Door43/en_tn/src/master/1co/06/14.md)
* [1 Corinthians 12:14-17](https://git.door43.org/Door43/en_tn/src/master/1co/12/14.md)
* [Numbers 16:1-3](https://git.door43.org/Door43/en_tn/src/master/num/16/01.md)
* [Romans 12:4-5](https://git.door43.org/Door43/en_tn/src/master/rom/12/04.md)

#### Word Data:####

* Strong's: H1004, H1121, H3338, H5315, H8212, G1010, G3196, G3609


---

<a id="memorialoffering"/>

### memorial, memorial offering ###

#### Definition: ####

The term "memorial" refers to an action or object that causes someone or something to be remembered.

* This word is also used as an adjective to describe something that is to remind them of something, as in a "memorial offering," a "memorial portion" of a sacrifice or "memorial stones."
* In the Old Testament memorial offerings were made so the Israelites would remember what God had done for them.
* God told the Israelite priests to wear special clothing that had memorial stones. These stones had the names of the twelve tribes of Israel engraved on them. These were perhaps to remind them of God's faithfulness to them.
* In the New Testament, God honored a man named Cornelius because of his charitable deeds for the poor. These deeds were said to be a "memorial" before God.

#### Translation Suggestions: ####

* This could also be translated as "lasting reminder."
* A "memorial stone" could be translated as a "stone to remind them (of something)."

#### Bible References: ####

* [Acts 10:3-6](https://git.door43.org/Door43/en_tn/src/master/act/10/03.md)
* [Exodus 12:12-14](https://git.door43.org/Door43/en_tn/src/master/exo/12/12.md)
* [Isaiah 66:3](https://git.door43.org/Door43/en_tn/src/master/isa/66/03.md)
* [Joshua 04:6-7](https://git.door43.org/Door43/en_tn/src/master/jos/04/06.md)
* [Leviticus 23:23-25](https://git.door43.org/Door43/en_tn/src/master/lev/23/23.md)

#### Word Data:####

* Strong's: H2142, H2146, G3422


---

<a id="messenger"/>

### messenger, messengers ###

#### Facts: ####

The term "messenger" refers to someone who is given a message to tell others.

* In ancient times, a messenger would be sent from the battlefield to tell people back in the city what was happening.
* An angel is a special kind of messenger whom God sends to give people messages. Some translations translate "angel" as "messenger."
* John the Baptist was called a messenger who came before Jesus to announce the Messiah's coming and to prepare people to receive him.
* Jesus' apostles were his messengers to go share with other people the good news about the kingdom of God.

(See also: [angel](kt.html#angel), [apostle](kt.html#apostle), [John (the Baptist)](names.html#johnthebaptist))

#### Bible References: ####

* [1 Kings 19:1-3](https://git.door43.org/Door43/en_tn/src/master/1ki/19/01.md)
* [1 Samuel 06:21](https://git.door43.org/Door43/en_tn/src/master/1sa/06/21.md)
* [2 Kings 01:1-2](https://git.door43.org/Door43/en_tn/src/master/2ki/01/01.md)
* [Luke 07:27-28](https://git.door43.org/Door43/en_tn/src/master/luk/07/27.md)
* [Matthew 11:9-10](https://git.door43.org/Door43/en_tn/src/master/mat/11/09.md)

#### Word Data:####

* Strong's: H1319, H4397, H4398, H5046, H5894, H6735, H6737, H7323, H7971, G32, G652


---

<a id="mighty"/>

### might, mighty, mightier, mightily ###

#### Definition: ####

The terms "mighty" and "might" refer to having great strength or power.

* Often the word "might" is another word for "strength." When talking about God, it can mean "power."
* The phrase "mighty men" often refers to men who are courageous and victorious in battle. David's band of faithful men who helped protect and defend him were often called "mighty men."
* God is also referred to as the "mighty one."
* The phrase "mighty works" usually refers to the amazing things God does, especially miracles.
* This term is related to the term "almighty," which is a common description for God, meaning that he has complete power.

#### Translation Suggestions: ####

* Depending on the context, the term "mighty" could be translated as "powerful" or "amazing" or "very strong."
* The phrase "his might" could be translated as "his strength" or "his power."
* In Acts 7, Moses is described as a man who was "mighty in word and deed." This could be translated as "Moses spoke powerful words from God and did miraculous things" or "Moses spoke God's word powerfully and did many amazing things."
* Depending on the context, "mighty works" could be translated as "amazing things that God does" or "miracles" or "God doing things with power."
* The term "might" could also be translated as "power" or "great strength."
* Do not confuse this term with the English word that is used to express a possibility, as in "It might rain."

(See also: [Almighty](kt.html#almighty), [miracle](kt.html#miracle), [power](kt.html#power), [strength](#strength))

#### Bible References: ####

* [Acts 07:22-25](https://git.door43.org/Door43/en_tn/src/master/act/07/22.md)
* [Genesis 06:4](https://git.door43.org/Door43/en_tn/src/master/gen/06/04.md)
* [Mark 09:38-39](https://git.door43.org/Door43/en_tn/src/master/mrk/09/38.md)
* [Matthew 11:23-24](https://git.door43.org/Door43/en_tn/src/master/mat/11/23.md)

#### Word Data:####

* Strong's: H46, H47, H117, H193, H202, H352, H386, H410, H430, H533, H650, H1219, H1368, H1369, H1370, H1396, H1397, H1401, H1419, H2220, H2389, H2394, H2428, H3201, H3524, H3581, H3966, H4101, H5794, H5797, H5807, H5868, H6099, H6105, H6108, H6184, H6697, H6743, H7227, H7580, H7989, H8623, H8624, H8632, G972, G1411, G1413, G1414, G1415, G1498, G1752, G1754, G2159, G2478, G2479, G2900, G2904, G3168, G3173, G5082


---

<a id="mind"/>

### mind, minds, minded, mindful, remind, reminds, reminded, reminder, reminders, reminding, likeminded ###

#### Definition: ####

The term "mind" refers to the part of a person that thinks and makes decisions.

* The mind of each person is the total of his or her thoughts and reasoning.
* To "have the mind of Christ" means to be thinking and acting as Jesus Christ would think and act. It means being obedient to God the Father, obeying the teachings of Christ, being enabled to do this through the power of the Holy Spirit.
* To "change his mind" means someone made a different decision or had a different opinion than he had previously.
 

#### Translation Suggestions ####

* The term "mind" could also be translated as "thoughts" or "reasoning" or "thinking" or "understanding."
* The expression "keep in mind" could be translated as "remember" or "pay attention to this" or "be sure to know this." 
* The expression "heart, soul, and mind" could also be translated as "what you feel, what you believe, and what you think about."
* The expression "call to mind" could be translated as "remember" or "think about."
* The expression "changed his mind and went" could also be translated as "decided differently and went" or "decided to go after all" or "changed his opinion and went."
* The expression "double-minded" could also be translated as "doubting" or "unable to decide" or "with conflicting thoughts."

(See also: [believe](kt.html#believe), [heart](kt.html#heart), [soul](kt.html#soul))

#### Bible References: ####

* [Luke 10:25-28](https://git.door43.org/Door43/en_tn/src/master/luk/10/25.md)
* [Mark 06:51-52](https://git.door43.org/Door43/en_tn/src/master/mrk/06/51.md)
* [Matthew 21:28-30](https://git.door43.org/Door43/en_tn/src/master/mat/21/28.md)
* [Matthew 22:37-38](https://git.door43.org/Door43/en_tn/src/master/mat/22/37.md)
* [James 04:08](https://git.door43.org/Door43/en_tn/src/master/jms/04/08.md)

#### Word Data:####

* Strong's: H3629, H3820, H3824, H5162, H7725, G1271, G1374, G3328, G3525, G3540, G3563, G4993, G5590


---

<a id="mock"/>

### mock, mocks, mocked, mocking, mocker, mockers, mockery, ridicule, ridiculed, scoff at, scoffed at ###

#### Definition: ####

The terms "mock," ridicule," and "scoff at" all refer to making fun of someone, especially  in a cruel way.

 * Mocking often involves imitating people's words or actions with the intent to embarrass them or show contempt for them.
 * The Roman soldiers mocked or ridiculed Jesus when they put a robe on him and pretended to honor him as king.
 * A group of young people ridiculed or scoffed at Elisha when they called him a name, making fun of his bald head.
 * The term "scoff at" can also refer to ridiculing an idea that is not considered believable or important.
 * A "mocker" is someone who mocks and ridicules consistently. 

#### Bible References: ####

* [2 Peter 03:3-4](https://git.door43.org/Door43/en_tn/src/master/2pe/03/03.md)
* [Acts 02:12-13](https://git.door43.org/Door43/en_tn/src/master/act/02/12.md)
* [Galatians 06:6-8](https://git.door43.org/Door43/en_tn/src/master/gal/06/06.md)
* [Genesis 39:13-15](https://git.door43.org/Door43/en_tn/src/master/gen/39/13.md)
* [Luke 22:63-65](https://git.door43.org/Door43/en_tn/src/master/luk/22/63.md)
* [Mark 10:32-34](https://git.door43.org/Door43/en_tn/src/master/mrk/10/32.md)
* [Matthew 09:23-24](https://git.door43.org/Door43/en_tn/src/master/mat/09/23.md)
* [Matthew 20:17-19](https://git.door43.org/Door43/en_tn/src/master/mat/20/17.md)
* [Matthew 27:27-29](https://git.door43.org/Door43/en_tn/src/master/mat/27/27.md)

#### Examples from the Bible stories: ####

  __*[21:12](https://git.door43.org/Door43/en_tn/src/master/obs/21/12.md)__ Isaiah prophesied that people would spit on, __mock__, and beat the Messiah. 
  __*[39:05](https://git.door43.org/Door43/en_tn/src/master/obs/39/05.md)__ The Jewish leaders all answered the high priest, "He deserves to die!" Then they blindfolded Jesus, spit on him, hit him, and __mocked__ him.
  __*[39:12](https://git.door43.org/Door43/en_tn/src/master/obs/39/12.md)__ The soldiers whipped Jesus, and put a royal robe and a crown made of thorns on him. Then they __mocked__ him by saying, "Look, the King of the Jews!"
  __*[40:04](https://git.door43.org/Door43/en_tn/src/master/obs/40/04.md)__ Jesus was crucified between two robbers. One of them __mocked__ Jesus, but the other said, "Do you have no fear of God?"
  __*[40:05](https://git.door43.org/Door43/en_tn/src/master/obs/40/05.md)__ The Jewish leaders and the other people in the crowd __mocked__ Jesus. They said to him, "If you are the Son of God, come down from the cross and save yourself! Then we will believe you."

#### Word Data:####

* Strong's: H1422, H2048, H2049, H2778, H2781, H3213, H3887, H3931, H3932, H3933, H3934, H3944, H3945, H4167, H4485, H4912, H5058, H5607, H5953, H6026, H6711, H7046, H7048, H7814, H7832, H8103, H8148, H8437, H8595, G1592, G1701, G1702, G1703, G2301, G2606, G3456, G5512


---

<a id="mold"/>

### mold, molds, molded, molding, molder, moldy ###

#### Definition: ####

A mold is a hollowed-out piece of wood, metal, or clay that is used to form objects out of gold, silver, or other materials that can be softened and then shaped by the mold.

* Molds were used to make jewelry, dishes, and utensils for eating, among other things.
* In the Bible, molds are mentioned mainly in connection with molding statues to be used as idols.
* Metals have to be heated to a very high temperature so that they can be poured into the mold.
* To mold something means to form an object into a certain shape or likeness by using a mold or the hands to form a certain shape.

#### Translation Suggestions ####

* This term could also be translated as, to "form" or to "shape" or to "make."
* The word "molded" could be translated as "shaped" or "formed."
* The object "mold" could possibly be translated with a phrase or word that means, "shaped container" or "sculpted dish." 

(See also: [false god](kt.html#falsegod), [gold](#gold), [false god](kt.html#falsegod), [silver](#silver))

#### Bible References: ####

* [Exodus 32:3-4](https://git.door43.org/Door43/en_tn/src/master/exo/32/03.md)

#### Word Data:####

* Strong's: H4541, H4165, G4110, G4111


---

<a id="mourn"/>

### mourn, mourns, mourned, mourning, mourner, mourners, mournful, mournfully ###

#### Facts: ####

The terms "mourn" and "mourning" refer to expressing deep grief, usually in response to the death of someone.

* In many cultures, mourning includes specific outward behaviors that show this sadness and grief.
* The Israelites and other people groups in ancient times expressed mourning through loud wailing and lamenting. They also wore rough clothing made of sackcloth and put ashes on themselves.
* Hired mourners, usually women, would loudly weep and wail from the time of death until well after the body was put in the tomb.
* The typical period of mourning was seven days, but could last as long as thirty days (as for Moses and Aaron) or seventy days (as for Jacob).
* The Bible also uses the term figuratively to talk about "mourning" because of sin. This refers to feeling deeply grieved because sin hurts God and people.

(See also: [sackcloth](#sackcloth), [sin](kt.html#sin))

#### Bible References: ####

* [1 Samuel 15:34-35](https://git.door43.org/Door43/en_tn/src/master/1sa/15/34.md)
* [2 Samuel 01:11-13](https://git.door43.org/Door43/en_tn/src/master/2sa/01/11.md)
* [Genesis 23:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/23/01.md)
* [Luke 07:31-32](https://git.door43.org/Door43/en_tn/src/master/luk/07/31.md)
* [Matthew 11:16-17](https://git.door43.org/Door43/en_tn/src/master/mat/11/16.md)

#### Word Data:####

* Strong's: H56, H57, H60, H205, H578, H584, H585, H1058, H1065, H1068, H1669, H1671, H1897, H1899, H1993, H4553, H4798, H5092, H5098, H5110, H5594, H6937, H6941, H6969, H7300, H8386, G2354, G2875, G3602, G3996, G3997


---

<a id="multiply"/>

### multiply, multiplies, multiplied, multiplying, multiplication ###

#### Definition: ####

The term "multiply" means to greatly increase in number. It can also mean to cause something to increase in amount, such as causing pain to multiply.

* God told animals and human beings to "multiply" and fill the earth. This was a command to reproduce many more of their own kind.
* Jesus made the bread and fish multiply in order to feed the 5,000 people. The amount of food kept increasing so that there was more than enough food to feed everyone.
* Depending on the context, this term  could also be translated as "increase" or "cause to increase" or "greatly increase in number" or "become greater in number" or "become more numerous."
* The phrase "greatly multiply your pain" could also be translated as "cause your pain to become more severe" or "cause you to experience much more pain."
* To "multiply horses" means to "greedily keep acquiring more horses" or to "get large numbers of horses."

#### Bible References: ####

* [Deuteronomy 08:1-2](https://git.door43.org/Door43/en_tn/src/master/deu/08/01.md)
* [Genesis 09:5-7](https://git.door43.org/Door43/en_tn/src/master/gen/09/05.md)
* [Genesis 22:15-17](https://git.door43.org/Door43/en_tn/src/master/gen/22/15.md)
* [Hosea 04:6-7](https://git.door43.org/Door43/en_tn/src/master/hos/04/06.md)

#### Word Data:####

* Strong's: H3254, H3527, H6280, H7231, H7233, H7235, H7680, G4052, G4129


---

<a id="mystery"/>

### mystery, mysteries, hidden truth, hidden truths ###

#### Definition: ####

In the Bible, the term "mystery" refers to something unknown or difficult to understand that God is now explaining.

* The New Testament states that the gospel of Christ was a mystery that was not known in past ages.
* One of the specific points described as a mystery is that Jews and Gentiles would be equal in Christ.
* This term could also be translated as "secret" or "hidden things" or "something unknown."

(See also: [Christ](kt.html#christ), [Gentile](kt.html#gentile), [good news](kt.html#goodnews), [Jew](kt.html#jew), [true](kt.html#true))

#### Bible References: ####

* [Colossians 04:2-4](https://git.door43.org/Door43/en_tn/src/master/col/04/02.md)
* [Ephesians 06:19-20](https://git.door43.org/Door43/en_tn/src/master/eph/06/19.md)
* [Luke 08:9-10](https://git.door43.org/Door43/en_tn/src/master/luk/08/09.md)
* [Mark 04:10-12](https://git.door43.org/Door43/en_tn/src/master/mrk/04/10.md)
* [Matthew 13:10-12](https://git.door43.org/Door43/en_tn/src/master/mat/13/10.md)

#### Word Data:####

* Strong's: H1219, H7328, G3466


---

<a id="nation"/>

### nation, nations ###

#### Definition: ####

A nation is a large group of people ruled by some form of government. The people of a nation often have the same ancestors and share a common ethnicity.

* A "nation" usually has a well-defined culture and territorial boundaries.
* In the Bible, a "nation" could be a country (like Egypt or Ethiopia), but often it is more general and refers to a people group, especially when used in the plural. It is important to check the context.
* Nations in the Bible included the Israelites, the Philistines, the Assyrians, the Babylonians, the Canaanites, the Romans, and the Greeks, among many others.
* Sometimes the word "nation" was used figuratively to refer to the ancestor of a certain people group, as when Rebekah was told by God that her unborn sons were "nations" that would fight against each other. This could be translated as "the founders of two nations" or the "ancestors of two people groups."
* The word translated as "nation" was also sometimes used to refer to "Gentiles" or to people who do not worship Yahweh. The context usually makes the meaning clear.
 
#### Translation Suggestions: ####

* Depending on the context, the word "nation" could also be translated as "people group" or "people" or "country."
* If a language has a term for "nation" that is distinct from these other terms, then that term can be used wherever it occurs in the Bible text, as long as it is natural and accurate in each context.
* The plural term "nations" can often be translated as "people groups."
* In certain contexts, this term could also be translated as "Gentiles" or "nonJews."

(See also: [Assyria](names.html#assyria), [Babylon](names.html#babylon), [Canaan](names.html#canaan), [Gentile](kt.html#gentile), [Greek](names.html#greek), [people group](#peoplegroup), [Philistines](names.html#philistines), [Rome](names.html#rome))

#### Bible References: ####

* [1 Chronicles 14:15-17](https://git.door43.org/Door43/en_tn/src/master/1ch/14/15.md)
* [2 Chronicles 15:6-7](https://git.door43.org/Door43/en_tn/src/master/2ch/15/06.md)
* [2 Kings 17:11-12](https://git.door43.org/Door43/en_tn/src/master/2ki/17/11.md)
* [Acts 02:5-7](https://git.door43.org/Door43/en_tn/src/master/act/02/05.md)
* [Acts 13:19-20](https://git.door43.org/Door43/en_tn/src/master/act/13/19.md)
* [Acts 17:26-27](https://git.door43.org/Door43/en_tn/src/master/act/17/26.md)
* [Acts 26:4-5](https://git.door43.org/Door43/en_tn/src/master/act/26/04.md)
* [Daniel 03:3-5](https://git.door43.org/Door43/en_tn/src/master/dan/03/03.md)
* [Genesis 10:2-5](https://git.door43.org/Door43/en_tn/src/master/gen/10/02.md)
* [Genesis 27:29](https://git.door43.org/Door43/en_tn/src/master/gen/27/29.md)
* [Genesis 35:11-13](https://git.door43.org/Door43/en_tn/src/master/gen/35/11.md)
* [Genesis 49:10](https://git.door43.org/Door43/en_tn/src/master/gen/49/10.md)
* [Luke 07:2-5](https://git.door43.org/Door43/en_tn/src/master/luk/07/02.md)
* [Mark 13:7-8](https://git.door43.org/Door43/en_tn/src/master/mrk/13/07.md)
* [Matthew 21:43-44](https://git.door43.org/Door43/en_tn/src/master/mat/21/43.md)
* [Romans 04:16-17](https://git.door43.org/Door43/en_tn/src/master/rom/04/16.md)

#### Word Data:####

* Strong's: H249, H523, H524, H776, H1471, H3816, H4940, H5971, G246, G1074, G1085, G1484


---

<a id="neighbor"/>

### neighbor, neighbors, neighborhood, neighboring ###

#### Definition: ####

The term "neighbor" usually refers to a person who lives nearby. It can also refer more generally to someone who lives in the same community or people group.

* A "neighbor" is someone who would be protected and treated kindly because he is part of the same community.
* In the New Testament parable of the Good Samaritan, Jesus used the term "neighbor" figuratively, expanding its meaning to include all human beings, even someone who is considered an enemy.
* If possible, it is best to translate this term literally with a word or phrase that means "person who lives nearby."

(See also: [adversary](#adversary), [parable](kt.html#parable), [people group](#peoplegroup), [Samaria](names.html#samaria))

#### Bible References: ####

* [Acts 07:26-28](https://git.door43.org/Door43/en_tn/src/master/act/07/26.md)
* [Ephesians 04:25-27](https://git.door43.org/Door43/en_tn/src/master/eph/04/25.md)
* [Galatians 05:13-15](https://git.door43.org/Door43/en_tn/src/master/gal/05/13.md)
* [James 02:8-9](https://git.door43.org/Door43/en_tn/src/master/jas/02/08.md)
* [John 09:8-9](https://git.door43.org/Door43/en_tn/src/master/jhn/09/08.md)
* [Luke 01:56-58](https://git.door43.org/Door43/en_tn/src/master/luk/01/56.md)
* [Matthew 05:43-45](https://git.door43.org/Door43/en_tn/src/master/mat/05/43.md)
* [Matthew 19:18-19](https://git.door43.org/Door43/en_tn/src/master/mat/19/18.md)
* [Matthew 22:39-40](https://git.door43.org/Door43/en_tn/src/master/mat/22/39.md)

#### Word Data:####

* Strong's: H5997, H7138, H7453, H7468, H7934, G1069, G2087, G4040, G4139


---

<a id="newmoon"/>

### new moon, new moons ###

#### Definition: ####

The term "new moon" refers to the moon when it looks like a small, crescent-shaped sliver of light. This is the beginning phase of the moon as it moves in its orbit around the planet Earth at sunset. It also refers to the first day a new moon should be visible after the moon has been dark for a few days.

* In ancient times, new moons marked the beginnings of certain time periods, such as months.
* The Israelites celebrated a new moon festival that was marked by the blowing of a ram's horn.
* The Bible also refers to this time as the "beginning of the month."

(See also: [month](#biblicaltimemonth), [earth](#earth), [festival](#festival), [horn](#horn), [sheep](#sheep))

#### Bible References: ####

* [1 Chronicles 23:30-31](https://git.door43.org/Door43/en_tn/src/master/1ch/23/30.md)
* [1 Samuel 20:4-5](https://git.door43.org/Door43/en_tn/src/master/1sa/20/04.md)
* [2 Kings 04:23-24](https://git.door43.org/Door43/en_tn/src/master/2ki/04/23.md)
* [Ezekiel 45:16-17](https://git.door43.org/Door43/en_tn/src/master/ezk/45/16.md)
* [Isaiah 01:12-13](https://git.door43.org/Door43/en_tn/src/master/isa/01/12.md)

#### Word Data:####

* Strong's: H2320, G3376, G3561


---

<a id="noble"/>

### noble, nobles, nobleman, noblemen ###

#### Definition: ####

The term "noble" refers to something that is excellent and of high quality. A "nobleman" is a person who belongs to a high political or social class. A man "of noble birth" is one who was born a nobleman.

* A nobleman was often an officer of the state, a close servant to the king.
* The term "nobleman" could also be translated by, "king's official" or "government officer."

#### Bible References: ####

* [2 Chronicles 23:20-21](https://git.door43.org/Door43/en_tn/src/master/2ch/23/20.md)
* [Daniel 04:36-37](https://git.door43.org/Door43/en_tn/src/master/dan/04/36.md)
* [Ecclesiastes 10:16-17](https://git.door43.org/Door43/en_tn/src/master/ecc/10/16.md)
* [Luke 19:11-12](https://git.door43.org/Door43/en_tn/src/master/luk/19/11.md)
* [Psalm 016:1-3](https://git.door43.org/Door43/en_tn/src/master/psa/016/001.md)

#### Word Data:####

* Strong's: H117, H678, H1281, H1419, H2715, H3358, H3513, H5057, H5081, H6440, H6579, H7336, H7261, H8282, H8269, H8321, G937, G2104, G2903


---

<a id="oak"/>

### oak, oaks ###

#### Definition: ####

An oak, or oak tree,  is a tall shade tree with a large trunk and wide spreading branches.

* Oak trees have strong, hard wood that was used to build ships and to make farming plows, oxen yokes and walking sticks.
* The seed of an oak tree is called an acorn.
* The trunks of certain oak trees could bemeasured up to 6 meters around.
* Oak trees were symbolic of long life and had other spiritual meanings. In the Bible, they were often associated with holy places.

#### Translation Suggestions: ####

* Many translations will find it important to use the term "oak tree" rather than just the word "oak."
* If oak trees are not known in the receptor area, "an oak" could be translated as "an oak, which is a large shade tree like…," then give the name of a local tree that has similar characteristics.
* See: [How to Translate Unknowns](https://git.door43.org/Door43/en_ta/src/master/translate/translate-unknown.md)

(See also: [holy](kt.html#holy))

#### Bible References: ####

* [1 Samuel 10:3-4](https://git.door43.org/Door43/en_tn/src/master/1sa/10/03.md)
* [Genesis 13:16-18](https://git.door43.org/Door43/en_tn/src/master/gen/13/16.md)
* [Genesis 14:13-14](https://git.door43.org/Door43/en_tn/src/master/gen/14/13.md)
* [Genesis 35:4-5](https://git.door43.org/Door43/en_tn/src/master/gen/35/04.md)
* [Judges 06:11-12](https://git.door43.org/Door43/en_tn/src/master/jdg/06/11.md)

#### Word Data:####

* Strong's: H352, H424, H427, H436, H437, H438


---

<a id="oath"/>

### oath, oaths, swear, swears, swearing, swear by, swears by ###

#### Definition: ####

In the Bible, an oath is a formal promise to do something. The person making the oath is required to fulfill that promise. An oath involves a commitment to being faithful and truthful.

* In a court of law, a witness often gives an oath to promise that whatever he says will be true and factual.
* In the Bible, the term "swear" means to speak an oath.
* The term "swear by" means to use the name of something or someone as the basis or power on which the oath is made.
* Sometimes these terms are used together, as in "swear an oath."
* Abraham and Abimelech swore an oath when they made a covenant together concerning the use of a well.
* Abraham told his servant to swear (formally promise) that he would find Isaac a wife from among Abraham's relatives.
* God also made oaths in which he made promises to his people.
* A modern-day meaning of the word "swear" means is "use foul language." This is not its meaning in the Bible.

#### Translation Suggestions: ####

* Depending on the context, "an oath" could also be translated as "a pledge" or "a solemn promise."
* To "swear" could be translated as to "formally promise" or to "pledge" or to "commit to do something."
* Other ways to translate "swear by my name" could include "make a promise using my name to confirm it."
* To "swear by heaven and earth" could be translated as to, "promise to do something, stating that heaven and earth will confirm it."
* Make sure the translation of "swear" or "oath" does not refer to cursing. In the Bible it does not have that meaning.

(See also: [Abimelech](names.html#abimelech), [covenant](kt.html#covenant), [vow](kt.html#vow))

#### Bible References: ####

* [Genesis 21:22-24](https://git.door43.org/Door43/en_tn/src/master/gen/21/22.md)
* [Genesis 24:1-4](https://git.door43.org/Door43/en_tn/src/master/gen/24/01.md)
* [Genesis 31:51-53](https://git.door43.org/Door43/en_tn/src/master/gen/31/51.md)
* [Genesis 47:29-31](https://git.door43.org/Door43/en_tn/src/master/gen/47/29.md)
* [Luke 01:72-75](https://git.door43.org/Door43/en_tn/src/master/luk/01/72.md)
* [Mark 06:26-29](https://git.door43.org/Door43/en_tn/src/master/mrk/06/26.md)
* [Matthew 05:36-37](https://git.door43.org/Door43/en_tn/src/master/mat/05/36.md)
* [Matthew 14:6-7](https://git.door43.org/Door43/en_tn/src/master/mat/14/06.md)
* [Matthew 26:71-72](https://git.door43.org/Door43/en_tn/src/master/mat/26/71.md)

#### Word Data:####

* Strong's: H422, H423, H3027, H5375, H7621, H7650, G332, G3660, G3727, G3728


---

<a id="obey"/>

### obey, obeys, obeyed, obeying, obedience, obedient, obediently, disobey, disobeys, disobeyed, disobedience, disobedient ###

#### Definition: ####

The term "obey" means to do what is required or commanded. The term "obedient" describes someone who obeys. "Obedience" is the characteristic that an obedient person has.Sometimes the command is about not doing something, as in "do not steal."

* Usually the term "obey" is used in the context of obeying the commands or laws of a person in authority.
* For example, people obey laws which are created by the leaders of a country, kingdom, or other organization.
* Children obey their parents, slaves obey their masters, people obey God, and citizens obey the laws of their country.
* When someone in authority commands people not to do something, they obey by not doing that.
* Ways to translate obey could include a word or phrase that means "do what is commanded" or "follow orders" or "do what God says to do."
* The term "obedient" could be translated as "doing what was commanded" or "following orders" or "doing what God commands."

(See also: [citizen](#citizen), [command](kt.html#command), [disobey](#disobey), [kingdom](#kingdom), [law](#law))

#### Bible References: ####

* [Acts 05:29-32](https://git.door43.org/Door43/en_tn/src/master/act/05/29.md)
* [Acts 06:7](https://git.door43.org/Door43/en_tn/src/master/act/06/07.md)
* [Genesis 28:6-7](https://git.door43.org/Door43/en_tn/src/master/gen/28/06.md)
* [James 01:22-25](https://git.door43.org/Door43/en_tn/src/master/jas/01/22.md)
* [James 02:10-11](https://git.door43.org/Door43/en_tn/src/master/jas/02/10.md)
* [Luke 06:46-48](https://git.door43.org/Door43/en_tn/src/master/luk/06/46.md)
* [Matthew 07:26-27](https://git.door43.org/Door43/en_tn/src/master/mat/07/26.md)
* [Matthew 19:20-22](https://git.door43.org/Door43/en_tn/src/master/mat/19/20.md)
* [Matthew 28:20](https://git.door43.org/Door43/en_tn/src/master/mat/28/20.md)

#### Examples from the Bible stories: ####

* __[03:04](https://git.door43.org/Door43/en_tn/src/master/obs/03/04.md)__ Noah __obeyed__  God. He and his three sons built the boat just the way God had told them.
* __[05:06](https://git.door43.org/Door43/en_tn/src/master/obs/05/06.md)__ Again Abraham __obeyed__  God and prepared to sacrifice his son.
* __[05:10](https://git.door43.org/Door43/en_tn/src/master/obs/05/10.md)__ "Because you (Abraham) have __obeyed __  me, all the families of the world will be blessed through your family"
* __[05:10](https://git.door43.org/Door43/en_tn/src/master/obs/05/10.md)__ But the Egyptians did not believe God or __obey__  his commands.
* __[13:07](https://git.door43.org/Door43/en_tn/src/master/obs/13/07.md)__ If the people __obeyed__  these laws, God promised that he would bless and protect them.

#### Word Data:####

* Strong's: H1697, H2388, H3349, H4928, H6213, H7181, H8085, H8086, H8104, G191, G544, G3980, G3982, G4198, G5083, G5084, G5218, G5219, G5255, G5292, G5293, G5442


---

<a id="offspring"/>

### offspring ###

#### Definition: ####

The term "offspring" is a general reference to the biological descendants of people or animals.

* Often in the Bible, "offspring" has the same meaning as "children" or "descendants."
* The term "seed" is sometimes used figuratively to refer to offspring.

(See also: [descendant](#descendant), [seed](#seed))

#### Bible References: ####

* [Acts 17:28-29](https://git.door43.org/Door43/en_tn/src/master/act/17/28.md)
* [Exodus 13:11-13](https://git.door43.org/Door43/en_tn/src/master/exo/13/11.md)
* [Genesis 24:5-7](https://git.door43.org/Door43/en_tn/src/master/gen/24/05.md)
* [Isaiah 41:8-9](https://git.door43.org/Door43/en_tn/src/master/isa/41/08.md)
* [Job 05:23-25](https://git.door43.org/Door43/en_tn/src/master/job/05/23.md)
* [Luke 03:7](https://git.door43.org/Door43/en_tn/src/master/luk/03/07.md)
* [Matthew 12:33-35](https://git.door43.org/Door43/en_tn/src/master/mat/12/33.md)

#### Word Data:####

* Strong's: H1121, H2233, H5209, H6363, H6529, H6631, G1081, G1085


---

<a id="oil"/>

### oil ###

#### Definition: ####

Oil is a thick, clear liquid that can be taken from certain plants. In Bible times, oil usually came from olives.

* Olive oil was used for cooking, anointing, sacrifice, lamps, and medicine.
* In ancient times, olive oil was highly prized, and the possession of oil was considered a measurement of wealth.
* Make sure the translation of this term refers to the kind of oil that can be used in cooking, not motor oil. Some languages have different words for these different kinds of oil.

(See also: [olive](#olive), [sacrifice](#sacrifice))

#### Bible References: ####

* [2 Samuel 01:21-22](https://git.door43.org/Door43/en_tn/src/master/2sa/01/21.md)
* [Exodus 29:1-2](https://git.door43.org/Door43/en_tn/src/master/exo/29/01.md)
* [Leviticus 05:11](https://git.door43.org/Door43/en_tn/src/master/lev/05/11.md)
* [Leviticus 08:1-3](https://git.door43.org/Door43/en_tn/src/master/lev/08/01.md)
* [Mark 06:12-13](https://git.door43.org/Door43/en_tn/src/master/mrk/06/12.md)
* [Matthew 25:7-9](https://git.door43.org/Door43/en_tn/src/master/mat/25/07.md)

#### Word Data:####

* Strong's: H1880, H2091, H3323, H4887, H6671, H7246, H8081, G1637, G3464


---

<a id="olive"/>

### olive, olives ###

#### Definition: ####

The olive is the small, oval fruit from an olive tree, which is mostly grown in the regions surrounding the Mediterranean Sea.

* Olive trees are a type of large evergreen shrub with tiny white flowers. They grow best in hot weather and can survive well with little water.
* The olive tree's fruit starts out green and changes to black as they ripen. Olives were useful for food and for the oil that could be extracted from them.
* Olive oil was used for cooking in lamps and for religious ceremonies.
* In the Bible, olive trees and branches are sometimes used figuratively to refer to people.

(See also: [lamp](#lamp), [the sea](names.html#mediterranean), [Mount of Olives](names.html#mountofolives))

#### Bible References: ####

* [1 Chronicles 27:28-29](https://git.door43.org/Door43/en_tn/src/master/1ch/27/28.md)
* [Deuteronomy 06:10-12](https://git.door43.org/Door43/en_tn/src/master/deu/06/10.md)
* [Exodus 23:10-11](https://git.door43.org/Door43/en_tn/src/master/exo/23/10.md)
* [Genesis 08:10-12](https://git.door43.org/Door43/en_tn/src/master/gen/08/10.md)
* [James 03:11-12](https://git.door43.org/Door43/en_tn/src/master/jas/03/11.md)
* [Luke 16:5-7](https://git.door43.org/Door43/en_tn/src/master/luk/16/05.md)
* [Psalms 052:8-9](https://git.door43.org/Door43/en_tn/src/master/psa/052/008.md)

#### Word Data:####

* Strong's: H2132, H3323, H8081, G65, G1636, G1637, G2565


---

<a id="onhigh"/>

### on high, in the highest ###

#### Definition: ####

The terms "on high" and "in the highest" are expressions that usually mean "in heaven."

* Another meaning for the expression "in the highest" could be "the most honored."
* This expression could also be used literally, as in the expression "in the highest tree, " which means "in the tallest tree."
* The expression "on high" could also refer to being high in the sky, such as a bird's nest that is on high. In that context it could be translated as "high in the sky" or "at the top of a tall tree."
* The word "high" could also indicate the elevated location or importance of a person or thing.
* The expression "from on high" could be translated as "from heaven."

(See also: [heaven](kt.html#heaven), [honor](kt.html#honor))

#### Bible References: ####

* [Lamentations 01:13-14](https://git.door43.org/Door43/en_tn/src/master/lam/01/13.md)
* [Psalms 069:28-29](https://git.door43.org/Door43/en_tn/src/master/psa/069/028.md)

#### Word Data:####

* Strong's: H1361, H4605, H4791, H7682, G1722, G5308, G5310, G5311


---

<a id="oppress"/>

### oppress, oppresses, oppressed, oppressing, oppression, oppressive, oppressor, oppressors ###

#### Definition: ####

The terms "oppress" and "oppression" refer to treating people harshly. An "oppressor" is a person who oppresses people.

* The term "oppression" especially refers to a situation where people of greater strength mistreat or enslave people who are under their power or rule.
* The term "oppressed" describes the people who are being harshly treated.
* Often enemy nations and their rulers were oppressors to the people of Israel.

#### Translation Suggestions: ####

 * Depending on the context, "oppress" could be translated as, "severely mistreat" or "cause to be heavily burdened" or "put under miserable bondage" or "rule harshly."
 * Ways to translate "oppression" could include "heavy suppression and bondage" or "burdensome control."
 * The phrase "the oppressed" could be translated as "oppressed people" or "people in terrible bondage" or "those who are treated harshly."
 * The term "oppressor" could be translated as "person who oppresses" or "nation who controls and rules harshly" or "persecutor."

(See also: [bind](kt.html#bond), [enslave](#enslave), [persecute](#persecute))

#### Bible References: ####

* [1 Samuel 10:17-19](https://git.door43.org/Door43/en_tn/src/master/1sa/10/17.md)
* [Deuteronomy 26:6-7](https://git.door43.org/Door43/en_tn/src/master/deu/26/06.md)
* [Ecclesiastes 04:1](https://git.door43.org/Door43/en_tn/src/master/ecc/04/01.md)
* [Job 10:1-3](https://git.door43.org/Door43/en_tn/src/master/job/10/01.md)
* [Judges 02:18-19](https://git.door43.org/Door43/en_tn/src/master/jdg/02/18.md)
* [Nehemiah 05:14-15](https://git.door43.org/Door43/en_tn/src/master/neh/05/14.md)
* [Psalms 119:133-134](https://git.door43.org/Door43/en_tn/src/master/psa/119/133.md)

#### Word Data:####

* Strong's: H1790, H1792, H2541, H2555, H3238, H3905, H3906, H4642, H4939, H5065, H6115, H6125, H6184, H6206, H6216, H6217, H6231, H6233, H6234, H6693, H7429, H7533, H7701, G2616, G2669


---

<a id="ordain"/>

### ordain, ordained, ordinary, ordination ###

#### Definition: ####

To ordain means to formally appoint a person for a special task or role. It also means to formally make a rule or decree.

* The term "ordain" often refers to formally appointing somebody as a priest, minister, or rabbi.
* For example, God ordained Aaron and his descendants to be priests.
* It can also mean to institute or establish something, such as a religious feast or covenant.
* Depending on the context, to "ordain" could be translated as to "assign" or to "appoint" or to "command" or to "make a rule" or to "institute."

(See also: [command](kt.html#command), [covenant](kt.html#covenant), [decree](#decree), [law](#law), [law](kt.html#lawofmoses), [priest](kt.html#priest))

#### Bible References: ####

* [1 Kings 12:31-32](https://git.door43.org/Door43/en_tn/src/master/1ki/12/31.md)
* [2 Samuel 17:13-14](https://git.door43.org/Door43/en_tn/src/master/2sa/17/13.md)
* [Exodus 28:40-41](https://git.door43.org/Door43/en_tn/src/master/exo/28/40.md)
* [Numbers 03:3-4](https://git.door43.org/Door43/en_tn/src/master/num/03/03.md)
* [Psalms 111:7-9](https://git.door43.org/Door43/en_tn/src/master/psa/111/007.md)

#### Word Data:####

* Strong's: H3245, H4390, H4483, H6186, H6213, H6466, H6680, H7760, H8239, G1299, G2525, G2680, G3724, G4270, G4282, G4309, G5021, G5500


---

<a id="ordinance"/>

### ordinance, ordinances ###

#### Definition: ####

An ordinance is a public regulation or law that gives rules or instructions for people to follow. This term is related to the term "ordain."

* Sometimes an ordinance is a custom that has become well established through years of practice.
* In the Bible, an ordinance was something that God commanded the Israelites to do. Sometimes he commanded them to do it forever.
* The term "ordinance" could be translated as "public decree" or "regulation" or "law," depending on the context.

(See also: [command](kt.html#command), [decree](#decree), [law](kt.html#lawofmoses), [ordain](#ordain), [statute](#statute))

#### Bible References: ####

* [Deuteronomy 04:13-14](https://git.door43.org/Door43/en_tn/src/master/deu/04/13.md)
* [Exodus 27:20-21](https://git.door43.org/Door43/en_tn/src/master/exo/27/20.md)
* [Leviticus 08:31-33](https://git.door43.org/Door43/en_tn/src/master/lev/08/31.md)
* [Malachi 03:6-7](https://git.door43.org/Door43/en_tn/src/master/mal/03/06.md)

#### Word Data:####

* Strong's: H2706, H2708, H4687, H4931, H4941, G1296, G1345, G1378, G1379, G2937, G3862


---

<a id="overseer"/>

### oversee, oversees, overseen, overseer, overseers ###

#### Definition: ####

The term "overseer" refers to a person who is in charge of the work and welfare of other people.

* In the Old Testament, an overseer had the job of making sure the workers under him did their work well. 
* In the New Testament, this term is used to describe leaders of the early Christian church. Their work was to take care of the spiritual needs of the church, making sure the believers received accurate biblical teaching.
* Paul refers to an overseer as being like a shepherd who takes care of the believers in a local church, who are his "flock."
* The overseer, like a shepherd, keeps watch over the flock. He guards and protects the believers from false spiritual teaching and other evil influences.
* In the New Testament, the terms "overseers," "elders," and "shepherds/pastors" are different ways of referring to the same spiritual leaders.

#### Translation Suggestions ####

* Other ways to translate this term could be "supervisor" or "caretaker" or "manager."
* When referring to a leader of a local group of God's people, this term could be translated with a word or phrase that means "spiritual supervisor" or "someone who takes care of the spiritual needs of a group of believers" or "person who oversees the spiritual needs of the Church."

(See also: [church](kt.html#church), [elder](#elder), [pastor](kt.html#pastor), [shepherd](#shepherd))

#### Bible References: ####

* [1 Chronicles 26:31-32](https://git.door43.org/Door43/en_tn/src/master/1ch/26/31.md)
* [1 Timothy 03:1-3](https://git.door43.org/Door43/en_tn/src/master/1ti/03/01.md)
* [Acts 20:28-30](https://git.door43.org/Door43/en_tn/src/master/act/20/28.md)
* [Genesis 41:33-34](https://git.door43.org/Door43/en_tn/src/master/gen/41/33.md)
* [Philippians 01:1-2](https://git.door43.org/Door43/en_tn/src/master/php/01/01.md)

#### Word Data:####

* Strong's: H5329, H6485, H6496, H7860, H8104, G1983, G1984, G1985


---

<a id="overtake"/>

### overtake, overtakes, overtaken, overtook ###

#### Definition: ####

The term "overtake" and "overtook" refer to gaining control over someone or something. It usually includes the idea of catching up to something after pursuing it.

* When military troops "overtake" an enemy, it means they defeat that enemy in battle.
* When a predator overtakes its prey, it means that it pursues and catches its prey.
* If a curse "overtakes" someone, it means that whatever was said in that curse happens to the person
* If blessings "overtake" people, it means that those people experience those blessings. 
* Depending on the context, "overtake" could be translated as "conquer" or "capture" or "defeat" or "catch up to" or "completely affect."
* The past action "overtook" can be translated as "caught up to" or "came alongside of" or "conquered" or "defeated" or "caused harm to."
* When used in a warning that darkness or punishment or terrors will overtake people because of their sin, it means that those people will experience these negative things if they don't repent.
* The phrase "My words have overtaken your fathers" means that the teachings that Yahweh gave to their ancestors will now cause the ancestors to receive punishment because they failed to obey those teachings.

(See also: [bless](kt.html#bless), [curse](kt.html#curse), [prey](#prey), [punish](#punish))

#### Bible References: ####

* [2 Kings 25:4-5](https://git.door43.org/Door43/en_tn/src/master/2ki/25/04.md)
* [John 12:34-36](https://git.door43.org/Door43/en_tn/src/master/jhn/12/34.md)

{{tag>publish ktlink}

#### Word Data:####

* Strong's: H579, H935, H1692, H4672, H5066, H5381, G2638, G2983


---

<a id="pagan"/>

### pagan, pagans ###

#### Definition: ####

In Bible times, the term "pagan" was used to describe people who worshiped false gods instead of Yahweh.

* Anything associated with these people, such as the altars where they worshiped, the religious rituals they performed, and their beliefs, were also called "pagan."
* Pagan belief systems often included the worship of false gods and the worship of nature.
* Some pagan religions included sexually immoral rituals or the killing of human beings as part of their worship.

(See also: [altar](kt.html#altar), [false god](kt.html#falsegod), [sacrifice](#sacrifice), [worship](kt.html#worship), [Yahweh](kt.html#yahweh))

#### Bible References: ####

* [1 Corinthians 10:20-22](https://git.door43.org/Door43/en_tn/src/master/1co/10/20.md)
* [1 Corinthians 12:1-3](https://git.door43.org/Door43/en_tn/src/master/1co/12/01.md)
* [2 Kings 17:14-15](https://git.door43.org/Door43/en_tn/src/master/2ki/17/14.md)
* [2 Kings 21:4-6](https://git.door43.org/Door43/en_tn/src/master/2ki/21/04.md)

#### Word Data:####

* Strong's: H1471, G1484, G1494


---

<a id="palace"/>

### palace, palaces ###

#### Definition: ####

The term "palace" refers to the building or house where a king lived, along with his family members and servants.

* The high priest also lived in a palace complex, as mentioned in the New Testament.
* Palaces were very ornate, with beautiful architecture and furnishings.
* The buildings and furnishings of a palace were constructed of stone or wood, and often were overlaid with expensive wood, gold, or ivory.
* Many other people also lived and worked in the palace complex, which usually included several buildings and courtyards.

(See also: [courtyard](#courtyard), [high priest](kt.html#highpriest), [king](#king))

#### Bible References: ####

* [2 Chronicles 28:7-8](https://git.door43.org/Door43/en_tn/src/master/2ch/28/07.md)
* [2 Samuel 11:2-3](https://git.door43.org/Door43/en_tn/src/master/2sa/11/02.md)
* [Daniel 05:5-6](https://git.door43.org/Door43/en_tn/src/master/dan/05/05.md)
* [Matthew 26:3-5](https://git.door43.org/Door43/en_tn/src/master/mat/26/03.md)
* [Psalms 045:8-9](https://git.door43.org/Door43/en_tn/src/master/psa/045/008.md)

#### Word Data:####

* Strong's: H643, H759, H1001, H1002, H1004, H1055, H1406, H1964, H1965, H2038, H2918, H8651, G833, G933, G4232


---

<a id="palm"/>

### palm, palms ###

#### Definition: ####

The term "palm" refers to a type of tall tree with long, flexible, leafy branches extending from the top in a fan-like pattern.

* The palm tree in the Bible usually refers to a type of palm tree that produces a fruit called a "date." The leaves have a feather-like pattern.
* Palm trees typically grow in places that have a hot, humid climate. Their leaves stay green all year long.
* As Jesus was entering Jerusalem riding on a donkey, the people laid palm branches on the ground in front of him.
* Palm branches signified peace and the celebration of a victory.

(See also: [donkey](#donkey), [Jerusalem](names.html#jerusalem), [peace](#peace)) 

#### Bible References: ####

* [1 Kings 06:29-30](https://git.door43.org/Door43/en_tn/src/master/1ki/06/29.md)
* [Ezekiel 40:14-16](https://git.door43.org/Door43/en_tn/src/master/ezk/40/14.md)
* [John 12:12-13](https://git.door43.org/Door43/en_tn/src/master/jhn/12/12.md)
* [Numbers 33:8-10](https://git.door43.org/Door43/en_tn/src/master/num/33/08.md)

#### Word Data:####

* Strong's: H3712, H8558, H8560, H8561, G5404


---

<a id="partial"/>

### partial, be partial, partiality ###

#### Definition: ####

The terms "be partial" and "show partiality" refer to making a choice to treat certain people as more important than other people.

* This is similar to showing favoritism, which means to treat some people better than others.
* Usually partiality or favoritism is shown to people because they are more rich or more popular than other people. 
* The Bible instructs his people to not show partiality or favoritism to people who are rich or of high status.
* In his letter to the Romans, Paul teaches that God judges people fairly and with no partiality.
* The book of James teaches that it is wrong to give someone a better seat or better treatment because they are rich.

(See also: [favor](kt.html#favor))

#### Bible References: ####

* [Deuteronomy 01:17-18](https://git.door43.org/Door43/en_tn/src/master/deu/01/17.md)
* [Malachi 02:8-9](https://git.door43.org/Door43/en_tn/src/master/mal/02/08.md)
* [Mark 12:13-15](https://git.door43.org/Door43/en_tn/src/master/mrk/12/13.md)
* [Matthew 22:15-17](https://git.door43.org/Door43/en_tn/src/master/mat/22/15.md)
* [Romans 02:10-12](https://git.door43.org/Door43/en_tn/src/master/rom/02/10.md)

#### Word Data:####

* Strong's: H5234, H6440, G991, G1519, G2983, G4299, G4382, G4383


---

<a id="patient"/>

### patient, patiently, patience, impatient ###

#### Definition: ####

The terms "patient" and "patience" refer to persevering through difficult circumstances. Often patience involves waiting.

* When people are patient with someone, it means they are loving that person and forgiving whatever faults that person has.
* The Bible teaches God's people to be patient when facing difficulties and to be patient with each other.
* Because of his mercy, God is patient with people, even though they are sinners who deserve to be punished.

(See also: [endure](#endure), [forgive](kt.html#forgive), [persevere](#perseverance))

#### Bible References: ####

* [1 Peter 03:18-20](https://git.door43.org/Door43/en_tn/src/master/1pe/03/18.md)
* [2 Peter 03:8-9](https://git.door43.org/Door43/en_tn/src/master/2pe/03/08.md)
* [Hebrews 06:11-12](https://git.door43.org/Door43/en_tn/src/master/heb/06/11.md)
* [Matthew 18:28-29](https://git.door43.org/Door43/en_tn/src/master/mat/18/28.md)
* [Psalms 037:7](https://git.door43.org/Door43/en_tn/src/master/psa/037/007.md)
* [Revelation 02:1-2](https://git.door43.org/Door43/en_tn/src/master/rev/02/01.md)

#### Word Data:####

* Strong's: H750, H753, H2342, H3811, H6960, H7114, G420, G463, G1933, G3114, G3115, G3116, G5278, G5281


---

<a id="patriarchs"/>

### patriarch, patriarchs ###

#### Definition: ####

The term "patriarch" in the Bible refers to someone who was a founding ancestor of the Jewish people, particularly Abraham, Isaac, or Jacob.

* It also can refer to the twelve sons of Jacob who became the 12 patriarchs of the 12 tribes of Israel.
* The term "patriarch" has a similar meaning to "forefather," but more specifically refers to the most well-known male ancestral leaders of a people group.

(See also: [ancestor, father, forefather](#father))

#### Bible References: ####

* [Acts 02:29-31](https://git.door43.org/Door43/en_tn/src/master/act/02/29.md)
* [Acts 07:6-8](https://git.door43.org/Door43/en_tn/src/master/act/07/06.md)
* [Acts 07:9-10](https://git.door43.org/Door43/en_tn/src/master/act/07/09.md)
* [Ezra 03:12-13](https://git.door43.org/Door43/en_tn/src/master/ezr/03/12.md)

#### Word Data:####

* Strong's: H1, H7218, G3966


---

<a id="peace"/>

### peace, peaceful, peacefully, peaceable, peacemakers ###

#### Definition: ####

The term "peace" refers to a state of being or a feeling of having no conflict, anxiety, or fearfulness. A person who is "peaceful" feels calm and assured of being safe and secure.

* "Peace" can also refer to a time when people groups or countries are not at war with each other. These people are said to have "peaceful relations."
* To "make peace" with a person or a group of people means to take actions to cause fighting to stop.
* A "peacemaker" is someone who does and says things to influence people to live at peace with each other.
* To be "at peace" with other people means being in a state of not fighting against those people.
* A good or right relationship between God and people happens when God saves people from their sin. This is called having "peace with God."
* The greeting "grace and peace" was used by the apostles in their letters to their fellow believers as a blessing.
* The term "peace" can also refer to being in a good relationship with other people or with God.

#### Bible References: ####

* [1 Thessalonians 05:1-3](https://git.door43.org/Door43/en_tn/src/master/1th/05/01.md)
* [Acts 07:26-28](https://git.door43.org/Door43/en_tn/src/master/act/07/26.md)
* [Colossians 01:18-20](https://git.door43.org/Door43/en_tn/src/master/col/01/18.md)
* [Colossians 03:15-17](https://git.door43.org/Door43/en_tn/src/master/col/03/15.md)
* [Galatians 05:22-24](https://git.door43.org/Door43/en_tn/src/master/gal/05/22.md)
* [Luke 07:48-50](https://git.door43.org/Door43/en_tn/src/master/luk/07/48.md)
* [Luke 12:51-53](https://git.door43.org/Door43/en_tn/src/master/luk/12/51.md)
* [Mark 04:38-39](https://git.door43.org/Door43/en_tn/src/master/mrk/04/38.md)
* [Matthew 05:9-10](https://git.door43.org/Door43/en_tn/src/master/mat/05/09.md)
* [Matthew 10:11-13](https://git.door43.org/Door43/en_tn/src/master/mat/10/11.md)

#### Examples from the Bible stories: ####

  __*[15:06](https://git.door43.org/Door43/en_tn/src/master/obs/15/06.md)__ God had commanded the Israelites not to make a __peace__ treaty with any of the people groups in Canaan.  
  __*[15:12](https://git.door43.org/Door43/en_tn/src/master/obs/15/12.md)__ Then God gave Israel __peace__ along all its borders. 
  __*[16:03](https://git.door43.org/Door43/en_tn/src/master/obs/16/03.md)__ Then God provided a deliverer who rescued them from their enemies and brought __peace__ to the land. 
  __*[21:13](https://git.door43.org/Door43/en_tn/src/master/obs/21/13.md)__ He (Messiah) would die to receive the punishment for other people's sin. His punishment would bring __peace__ between God and people. 
  __*[48:14](https://git.door43.org/Door43/en_tn/src/master/obs/48/14.md)__ David was the king of Israel, but Jesus is the king of the entire universe! He will come again and rule his kingdom with justice and __peace__, forever.
  __*[50:17](https://git.door43.org/Door43/en_tn/src/master/obs/50/17.md)__ Jesus will rule his kingdom with __peace__ and justice, and he will be with his people forever.

#### Word Data:####

* Strong's: H5117, H7521, H7961, H7962, H7965, H7999, H8001, H8002, H8003, H8252, G269, G425, G31514, G1515, G1516, G1517, G1518, G2272


---

<a id="peaceoffering"/>

### peace offering, peace offerings ###

#### Facts: ####

A "peace offering" was one of several sacrificial offerings that God commanded the Israelites to make. It is sometimes called the "thanksgiving offering" or "fellowship offering."

* This offering involved sacrificing an animal that had no defects, sprinkling the animal's blood on the altar, and burning the animal's fat, as well as the rest of the animal separately.
* Added to this sacrifice was an offering of both unleavened and leavened bread, which was burned on top of the burnt offering.
* The priest and offerer of the sacrifice were permitted to share in eating the food that was offered.
* This offering symbolizes the fellowship of God with his people.

(See also: [burnt offering](#burntoffering), [fellowship](kt.html#fellowship), [fellowship offering](#fellowshipoffering), [grain offering](#grainoffering), [priest](kt.html#priest), [sacrifice](#sacrifice), [unleavened bread](kt.html#unleavenedbread))

#### Bible References: ####

* [1 Samuel 13:8-10](https://git.door43.org/Door43/en_tn/src/master/1sa/13/08.md)
* [Ezekiel 45:16-17](https://git.door43.org/Door43/en_tn/src/master/ezk/45/16.md)
* [Joshua 08:30-32](https://git.door43.org/Door43/en_tn/src/master/jos/08/30.md)
* [Leviticus 09:3-5](https://git.door43.org/Door43/en_tn/src/master/lev/09/03.md)
* [Proverbs 07:13-15](https://git.door43.org/Door43/en_tn/src/master/pro/07/13.md)

#### Word Data:####

* Strong's: H8002


---

<a id="peoplegroup"/>

### people group, peoples, the people, a people ###

#### Definition: ####

The term "peoples" or "people groups" refers to groups of people who share a common language and culture. The phrase "the people" often refers to a gathering of people in a certain place or at a specific event.

* When God set apart "a people" for himself, it means that he chose certain people to belong to him and serve him.
* In Bible times, the members of a people group usually had the same ancestors and lived together in a particular country or area of land.
* Depending on the context, a phrase such as "your people" can mean "your people group" or "your family" or "your relatives."
* The term "peoples" is often used to refer to all people groups on the earth. Sometimes it refers more specifically to people who are not Israelites or who do not serve Yahweh. In some English Bible translations the term "nations" is also used in this way.

#### Translation Suggestions: ####

* The term "people group" could be translated by a word or phrase that means "large family group" or "clan" or "ethnic group."
* A phrase such as "my people" could be translated as "my relatives" or "my fellow Israelites" or "my family" or "my people group," depending on the context.
* The expression "scatter you among the peoples" could also be translated as "cause you to go live with many different people groups" or "cause you to separate from each other and go live in many different regions of the world."
* The term "the peoples" or "the people" could also be translated as "the people in the world" or "people groups," depending on the context.
* The phrase "the people of" could be translated as "the people living in" or "the people descended from" or "the family of," depending on whether it is followed by the name of a place or a person.
* "All the peoples of the earth" could be translated as "everyone living on earth" or "every person in the world" or "all people."
* The phrase "a people" could also be translated as "a group of people" or "certain people" or "a community of people" or "a family of people."

(See also: [descendant](#descendant), [nation](#nation), [tribe](#tribe), [world](kt.html#world))

#### Bible References: ####

* [1 Kings 08:51-53](https://git.door43.org/Door43/en_tn/src/master/1ki/08/51.md)
* [1 Samuel 08:6-7](https://git.door43.org/Door43/en_tn/src/master/1sa/08/06.md)
* [Deuteronomy 28:9-10](https://git.door43.org/Door43/en_tn/src/master/deu/28/09.md)
* [Genesis 49:16-18](https://git.door43.org/Door43/en_tn/src/master/gen/49/16.md)
* [Ruth 01:16-18](https://git.door43.org/Door43/en_tn/src/master/rut/01/16.md)

#### Examples from the Bible stories: ####

* __[14:02](https://git.door43.org/Door43/en_tn/src/master/obs/14/02.md)__ God had promised Abraham, Isaac, and Jacob that he would give the Promised Land to their descendants, but now there were many __people groups__  living there. what follows is
* __[21:02](https://git.door43.org/Door43/en_tn/src/master/obs/21/02.md)__ God promised Abraham that through him all __people groups__  of the world would receive a blessing. This blessing would be that the Messiah would come sometime in the future and provide the way of salvation for people from all the __people groups__  of the world.
* __[42:08](https://git.door43.org/Door43/en_tn/src/master/obs/42/08.md)__ "It was also written in the scriptures that my disciples will proclaim that everyone should repent in order to receive forgiveness for their sins. They will do this starting in Jerusalem, and then go to all __people groups__  everywhere."
* __[42:10](https://git.door43.org/Door43/en_tn/src/master/obs/42/10.md)__ "So go, make disciples of all __people groups__  by baptizing them in the name of the Father, the Son, and the Holy Spirit and by teaching them to obey everything I have commanded you."
* __[48:11](https://git.door43.org/Door43/en_tn/src/master/obs/48/11.md)__ Because of this New Covenant, anyone from any __people group__  can become part of God's people by believing in Jesus.
* __[50:03](https://git.door43.org/Door43/en_tn/src/master/obs/50/03.md)__ He (Jesus) said, "Go and make disciples of all __people groups__!" and, "The fields are ripe for harvest!"

#### Word Data:####

* Strong's: H249, H523, H524, H776, H1121, H1471, H3816, H5712, H5971, H5972, H6153, G246, G1074, G1085, G1218, G1484, G2560, G2992, G3793


---

<a id="perfect"/>

### perfect, perfected, perfecter, perfection, perfectly ###

#### Definition: ####

In the Bible, the term "perfect" means to be mature in our Christian life. To perfect something means to work at it until it is excellent and without flaws.

* Being perfect and mature means that a Christian is obedient, not sinless.
* The term "perfect" also has the meaning of being "complete" or "whole."
* The New Testament Book of James states that persevering through trials will produce completeness and maturity in the believer.
* When Christians study the Bible and obey it, they will become more spiritually perfect and mature because they will be more like Christ in their character.

#### Translation Suggestions: ####

* This term could be translated as "without flaw" or "without error" or "flawless" or "without fault" or "not having any faults."

#### Bible References: ####

* [Hebrews 12:1-3](https://git.door43.org/Door43/en_tn/src/master/heb/12/01.md)
* [James 03:1-2](https://git.door43.org/Door43/en_tn/src/master/jas/03/01.md)
* [Matthew 05:46-48](https://git.door43.org/Door43/en_tn/src/master/mat/05/46.md)
* [Psalms 019:7-8](https://git.door43.org/Door43/en_tn/src/master/psa/019/007.md)

#### Word Data:####

* Strong's: H724, H998, H1584, H1585, H3632, H3634, H4357, H4359, H4512, H8003, H8502, H8503, H8535, H8537, H8549, H8552, G195, G197, G199, G739, G1295, G2005, G2675, G2676, G2677, G3647, G5046, G5047, G5048, G5050, G5052


---

<a id="persecute"/>

### persecute, persecuted, persecuting, persecution, persecutions, persecutor, persecutors ###

#### Definition: ####

The terms "persecute" and "persecution" refer to continually treating a person or a certain group of people in a harsh way that causes harm to them.

 * Persecution can be against one person or many people and usually involves repeated, persistent attacks.
 * The Israelites were persecuted by many different people groups Who attacked them, captured them, and stole things from them.
 * People often persecute other people who have different religious beliefs or who are weaker.
 * The Jewish religious leaders persecuted Jesus because they did not like what he was teaching.
 * After Jesus went back to heaven, the Jewish religious leaders and the Roman government persecuted his followers.
 * The term "persecute" could also be translated as "keep oppressing" or "treat harshly" or "continually mistreat."
 * Ways to translate "persecution" could include,  "harsh mistreatment" or "oppression" or "persistent hurtful treatment"

(See also: [Christian](kt.html#christian), [church](kt.html#church), [oppress](#oppress), [Rome](names.html#rome))

#### Bible References: ####

* [Acts 07:51-53](https://git.door43.org/Door43/en_tn/src/master/act/07/51.md)
* [Acts 13:50-52](https://git.door43.org/Door43/en_tn/src/master/act/13/50.md)
* [Galatians 01:13-14](https://git.door43.org/Door43/en_tn/src/master/gal/01/13.md)
* [John 05:16-18](https://git.door43.org/Door43/en_tn/src/master/jhn/05/16.md)
* [Mark 10:29-31](https://git.door43.org/Door43/en_tn/src/master/mrk/10/29.md)
* [Matthew 05:9-10](https://git.door43.org/Door43/en_tn/src/master/mat/05/09.md)
* [Matthew 05:43-45](https://git.door43.org/Door43/en_tn/src/master/mat/05/43.md)
* [Matthew 10:21-23](https://git.door43.org/Door43/en_tn/src/master/mat/10/21.md)
* [Matthew 13:20-21](https://git.door43.org/Door43/en_tn/src/master/mat/13/20.md)
* [Philippians 03:6-7](https://git.door43.org/Door43/en_tn/src/master/php/03/06.md)

#### Examples from the Bible stories: ####

 * __[33:07](https://git.door43.org/Door43/en_tn/src/master/obs/33/07.md)__ "The rocky ground is a person who hears God's word and accepts it with joy. But when he experiences hardship or __persecution__, he falls away."
 * __[45:06](https://git.door43.org/Door43/en_tn/src/master/obs/45/06.md)__ That day many people in Jerusalem started __persecuting__ the followers of Jesus, so the believers fled to other places. 
 * __[46:02](https://git.door43.org/Door43/en_tn/src/master/obs/46/02.md)__ Saul heard someone say, "Saul! Saul! Why do you __persecute__ me?" Saul asked, "Who are you, Master?" Jesus replied to him, "I am Jesus. You are __persecuting__ me!"
 * __[46:04](https://git.door43.org/Door43/en_tn/src/master/obs/46/04.md)__ But Ananias said, "Master, I have heard how this man has __persecuted__ the believers."

#### Word Data:####

* Strong's: H1814, H4783, H6233, H7291, H7852, G1375, G1376, G1377, G1559, G2347


---

<a id="perseverance"/>

### persevere, perseverance ###

#### Definition: ####

The terms "persevere" and "perseverance" refer to continuing to do something even though it may be very difficult or take a long time.

* To persevere can also mean to keep acting in a Christ-like way even while going through difficult trials or circumstances.
* If a person has "perseverance" it means he is able to keep doing what he should do, even when it is painful or difficult.
* Continuing to believe what God teaches requires perseverance, especially when faced with false teachings.
* Be careful not to use a word like "stubborn" which usually has a negative meaning.

(See also: [patient](#patient), [trial](#trial))

#### Bible References: ####

* [Colossians 01:11-12](https://git.door43.org/Door43/en_tn/src/master/col/01/11.md)
* [Ephesians 06:17-18](https://git.door43.org/Door43/en_tn/src/master/eph/06/17.md)
* [James 05:9-11](https://git.door43.org/Door43/en_tn/src/master/jas/05/09.md)
* [Luke 08:14-15](https://git.door43.org/Door43/en_tn/src/master/luk/08/14.md)

#### Word Data:####

* Strong's: G3115, G4343, G5281

---

<a id="perverse"/>

### perverse, perversely, perversion, perversions, perversities, pervert, perverts, perverted, perverting ###

#### Definition: ####

The term "perverse" is used to describe a person or action that is morally crooked or twisted. The term "perversely" means "in a perverse manner." To "pervert" something means to twist it or turn it away from what is right or good.

* Someone or something that is perverse has deviated from what is good and right.
* In the Bible, the Israelites acted perversely when they disobeyed God. They often did this by worshiping false gods.
* Any action which is against God's standards or behavior is considered perverse.
* Ways to translate "perverse" could include "morally twisted" or "immoral" or "turning away from God's straight path," depending on the context.
* "Perverse speech" could be translated as "speaking in an evil way" or "deceitful talk" or "immoral way of talking."
* "Perverse people" could be described as "immoral people" or "people who are morally deviant" or "people who continually disobey God."
* The phrase "acting perversely" could be translated as "behaving in an evil way" or "doing things against God's commands" or "living in a way that rejects God's teachings."
* The term "pervert" could also be translated as "cause to be corrupt" or "turn into something evil."

(See also: [corrupt](#corrupt), [deceive](#deceive), [disobey](#disobey), [evil](kt.html#evil), [turn](#turn))

#### Bible References: ####

* [1 Kings 08:46-47](https://git.door43.org/Door43/en_tn/src/master/1ki/08/46.md)
* [1 Samuel 20:30-31](https://git.door43.org/Door43/en_tn/src/master/1sa/20/30.md)
* [Job 33:27-28](https://git.door43.org/Door43/en_tn/src/master/job/33/27.md)
* [Luke 23:1-2](https://git.door43.org/Door43/en_tn/src/master/luk/23/01.md)
* [Psalms 101:4-6](https://git.door43.org/Door43/en_tn/src/master/psa/101/004.md)

#### Word Data:####

* Strong's: H1942, H2015, H3399, H3868, H3891, H4297, H5186, H5557, H5558, H5753, H5766, H5773, H5791, H5999, H6140, H6141, H8138, H8397, H8419, G654, G1294, G3344, G3346, G3859, G4106


---

<a id="pierce"/>

### pierce, pierces, pierced, piercing ###

#### Definition: ####

The term "pierce" means to stab something with a sharp, pointed object. It is also used figuratively to refer to causing someone deep emotional pain.

* A soldier pierced Jesus' side when he was hanging on the cross.
* In Bible times, a slave who was set free would have his ear pierced as a sign that he was choosing to continue working for his master.
* Simeon spoke figuratively when he told Mary that a sword would pierce her heart, meaning that she would experience deep grief because of what would happen to her son Jesus.

(See also: [cross](kt.html#cross), [Jesus](kt.html#jesus), [servant](#servant), [Simeon](names.html#simeon))

#### Bible References: ####

* [Job 16:13-14](https://git.door43.org/Door43/en_tn/src/master/job/16/13.md)
* [Job 20:23-25](https://git.door43.org/Door43/en_tn/src/master/job/20/23.md)
* [John 19:36-37](https://git.door43.org/Door43/en_tn/src/master/jhn/19/36.md)
* [Psalms 022:16-17](https://git.door43.org/Door43/en_tn/src/master/psa/022/016.md)

#### Word Data:####

* Strong's: H935, H1856, H2342, H2490, H2491, H2944, H3738, H4272, H5181, H5344, H5365, H6398, H7376, G1330, G1338, G1574, G2660, G3572, G4044, G4138


---

<a id="pig"/>

### pig, pigs, pork, swine ###

#### Definition: ####

A pig is a type of four-legged, hoofed animal that is raised for meat. Its meat is called "pork." The general term for pigs and related animals is "swine."

 * God told the Israelites not to eat pig meat and to consider it unclean. Jews today still view pigs as unclean and do not eat pork.
 * Pigs are raised on farms to be sold to other people for their meat.
 * There is a kind of swine that is not raised on farms but rather lives out in the wild; it is called a "wild boar." Wild boars have tusks and are considered to be very dangerous animals.
 * Sometimes large pigs are referred to as "hogs."

(See also: [How to Translate Unknowns](https://git.door43.org/Door43/en_ta/src/master/translate/translate-unknown.md))

(See also: [clean](kt.html#clean))

#### Bible References: ####

* [2 Peter 02:20-22](https://git.door43.org/Door43/en_tn/src/master/2pe/02/20.md)
* [Mark 05:11-13](https://git.door43.org/Door43/en_tn/src/master/mrk/05/11.md)
* [Matthew 07:6](https://git.door43.org/Door43/en_tn/src/master/mat/07/06.md)
* [Matthew 08:30-32](https://git.door43.org/Door43/en_tn/src/master/mat/08/30.md)

#### Word Data:####

* Strong's: H2386, G5519


---

<a id="pillar"/>

### column, columns, pillar, pillars  ###

#### Definition: ####

The term "pillar" usually refers to a large vertical structure that is used to hold up a roof or other part of a building. Another word for "pillar" is "column."

* In Bible times, pillars used as support in buildings were normally carved from a single piece of stone.
* When Samson in the Old Testament was captured by the Philistines, he destroyed their pagan temple by pushing the supporting pillars and causing the temple to collapse.
* The word "pillar" sometimes refers to a large stone or boulder that is set up as a memorial to mark a grave or to mark the place where an important event happened.
* It can also refer to an idol that was made to worship a false god. It is another name for a "carved image" and could be translated as "statue."
* The term "pillar" is used to refer to something that is shaped like a pillar, such as the "pillar of fire" that led the Israelites at night through the desert or the "pillar of salt" that Lot's wife became after she looked back at the city.
* As a structure supporting a building, the term "pillar" or "column" could be translated as "upright stone support beam" or "supporting stone structure."
* Other uses of "pillar" could be translated as "statue" or "pile" or "mound" or "monument" or "tall mass," depending on the context.

(See also: [foundation](#foundation), [false god](kt.html#falsegod), [image](#image))

#### Bible References: ####

* [2 Kings 18:4-5](https://git.door43.org/Door43/en_tn/src/master/2ki/18/04.md)
* [Exodus 13:19-22](https://git.door43.org/Door43/en_tn/src/master/exo/13/19.md)
* [Exodus 33:7-9](https://git.door43.org/Door43/en_tn/src/master/exo/33/07.md)
* [Genesis 31:45-47](https://git.door43.org/Door43/en_tn/src/master/gen/31/45.md)
* [Proverbs 09:1-2](https://git.door43.org/Door43/en_tn/src/master/pro/09/01.md)

#### Word Data:####

* Strong's: H352, H547, H2106, H2553, H3730, H4552, H4676, H4678, H4690, H5324, H5333, H5982, H8490, G4769


---

<a id="pit"/>

### pit, pits, pitfall ###

#### Definition: ####

A pit is a deep hole that has been dug in the ground.

* People dig pits for the purpose of trapping animals or finding water.
* A pit can also be used as a temporary place to hold a prisoner.
* Sometimes the phrase "the pit" refers to the grave or to hell. Other times it may refer to "the abyss."
* A very deep pit can also be called a "cistern."
* The term "pit" is also used figuratively in phrases such as, "pit of destruction" which describes being trapped in a disastrous situation or being deeply involved in sinful, destructive practices.

(See also: [abyss](#abyss), [hell](kt.html#hell), [prison](#prison))

#### Bible References: ####

* [Genesis 37:21-22](https://git.door43.org/Door43/en_tn/src/master/gen/37/21.md)
* [Job 33:16-18](https://git.door43.org/Door43/en_tn/src/master/job/33/16.md)
* [Luke 06:39-40](https://git.door43.org/Door43/en_tn/src/master/luk/06/39.md)
* [Proverbs 01:12-14](https://git.door43.org/Door43/en_tn/src/master/pro/01/12.md)

#### Word Data:####

* Strong's: H875, H953, H1356, H1360, H1475, H2352, H4087, H4113, H4379, H6354, H7585, H7745, H7816, H7825, H7845, H7882, G12, G999, G5421


---

<a id="plague"/>

### plague, plagues ###

#### Definition: ####

Plagues are events which cause suffering or death to a large number of people. Often a plague is a disease that spreads quickly and causes many people to die before it can be stopped.

* Many plagues have natural causes, but some were sent by God to punish people for sin.
* In the time of Moses, God sent ten plagues against Egypt to force Pharaoh to let Israel leave Egypt. These plagues included water turning into blood, physical diseases, destruction of crops by insects and hail, three days of complete darkness, and death of the firstborn sons.
* This could also be translated as "widespread disasters" or "widespread disease," depending on the context.

(See also: [hail](#hail), [Israel](kt.html#israel), [Moses](names.html#moses), [Pharaoh](names.html#pharaoh))

#### Bible References: ####

* [2 Samuel 24:13-14](https://git.door43.org/Door43/en_tn/src/master/2sa/24/13.md)
* [Exodus 09:13-14](https://git.door43.org/Door43/en_tn/src/master/exo/09/13.md)
* [Genesis 12:17-20](https://git.door43.org/Door43/en_tn/src/master/gen/12/17.md)
* [Luke 21:10-11](https://git.door43.org/Door43/en_tn/src/master/luk/21/10.md)
* [Revelation 09:18-19](https://git.door43.org/Door43/en_tn/src/master/rev/09/18.md)

#### Word Data:####

* Strong's: H1698, H4046, H4194, H4347, H5061, H5062, H5063, H7752, G3061, G3148, G4127


---

<a id="plead"/>

### plea, pleas, plead, pleads, pleaded, pleading, pleadings ###

#### Facts: ####

The terms "plead" and "pleading" refer to urgently asking someone to do something. A "plea" is an urgent request.

* Pleading often implies that the person feels in very great need or strongly desires help.
* People can plead or make an urgent appeal to God for mercy or to ask him to grant something, either for themselves or someone else.
* Other ways to translate this could include "beg" or "implore" or "urgently ask."
* The term "plea" could also be translated as "urgent request" or "strong urging."
* Make sure it is clear in the context that this term does not refer to begging for money.

#### Bible References: ####

* [2 Corinthians 08:3-5](https://git.door43.org/Door43/en_tn/src/master/2co/08/03.md)
* [Judges 06:31-32](https://git.door43.org/Door43/en_tn/src/master/jdg/06/31.md)
* [Luke 04:38-39](https://git.door43.org/Door43/en_tn/src/master/luk/04/38.md)
* [Proverbs 18:17-18](https://git.door43.org/Door43/en_tn/src/master/pro/18/17.md)

#### Word Data:####

* Strong's: H1777, H2603, H3198, H4941, H4994, H6279, H6293, H6664, H6419, H7378, H7379, H7775, H8199, H8467, H8469, G1189, G1793, G2065, G3870


---

<a id="pledge"/>

### pledge, pledged, pledges ###

#### Definition: ####

The term "pledge" refers to formally and solemnly promising to do something or give something.

* In the Old Testament the officials of Israel pledged to be loyal to King David.
* The object given as a pledge would be returned to its owner when the promise was fulfilled.
* To "pledge" could be translate as to "formally commit to" or to "strongly  promise."
* The term "pledge" can also refer to an object given as a guarantee or promise that a debt will be paid.
* Ways to translate "a pledge" could include "a solemn promise" or "a formal commitment" or "a guarantee" or "a formal assurance," depending on the context.

(See also: [promise](kt.html#promise), [oath](#oath), [vow](kt.html#vow))

#### Bible References: ####

* [2 Corinthians 05:4-5](https://git.door43.org/Door43/en_tn/src/master/2co/05/04.md)
* [Exodus 22:25-27](https://git.door43.org/Door43/en_tn/src/master/exo/22/25.md)
* [Genesis 38:17-18](https://git.door43.org/Door43/en_tn/src/master/gen/38/17.md)
* [Nehemiah 10:28-29](https://git.door43.org/Door43/en_tn/src/master/neh/10/28.md)

#### Word Data:####

* Strong's: H781, H2254, H2258, H5667, H5671, H6148, H6161, H6162, G728


---

<a id="plow"/>

### plow, plows, plowed, plowing, plowers, plowman, plowmen, plowshares, unplowed ###

#### Definition: ####

A "plow" is a farm tool that is used for breaking up soil to prepare a field for planting.

* Plows have sharp, pointed prongs that dig into the soil. They usually have handles that the farmer uses to guide the plow.
* In Bible times, plows were usually pulled by a pair of oxen or other work animals.
* Most plows were made of hard wood, except for the sharp points which were made of a metal, such as bronze or iron.
 

(See also: [bronze](#bronze), [ox](#ox))

#### Bible References: ####

* [1 Samuel 08:10-12](https://git.door43.org/Door43/en_tn/src/master/1sa/08/10.md)
* [Deuteronomy 21:3-4](https://git.door43.org/Door43/en_tn/src/master/deu/21/03.md)
* [Luke 09:61-62](https://git.door43.org/Door43/en_tn/src/master/luk/09/61.md)
* [Luke 17:7-8](https://git.door43.org/Door43/en_tn/src/master/luk/17/07.md)
* [Psalm 141:5-7](https://git.door43.org/Door43/en_tn/src/master/psa/141/005.md)

#### Word Data:####

* Strong's: H406, H855, H2758, H2790, H5215, H5647, H5674, H6398, G722, G723


---

<a id="pomegranate"/>

### pomegranate, pomegranates ###

#### Facts: ####

A pomegranate is a kind of fruit that has a thick, tough skin filled with many seeds that are covered with edible red pulp.

* The outer rind is reddish in color and the pulp surrounding the seeds is shiny and red.
* Pomegranates are very commonly grown in countries with a hot, dry climate, such as Egypt and Israel.
* Yahweh promised the Israelites that Canaan was a land with abundant water and fertile soil so that food was plentiful there, including pomegranates.
* The construction of Solomon's temple included bronze decorations in the shape of pomegranates.

(See also: [bronze](#bronze), [Canaan](names.html#canaan), [Egypt](names.html#egypt), [Solomon](names.html#solomon), [temple](kt.html#temple))

#### Bible References: ####

* [2 Kings 25:16-17](https://git.door43.org/Door43/en_tn/src/master/2ki/25/16.md)
* [Deuteronomy 08:7-8](https://git.door43.org/Door43/en_tn/src/master/deu/08/07.md)
* [Jeremiah 52:22-23](https://git.door43.org/Door43/en_tn/src/master/jer/52/22.md)
* [Numbers 13:23-24](https://git.door43.org/Door43/en_tn/src/master/num/13/23.md)
[Egypt](names.html#egypt)

#### Word Data:####

* Strong's: H7416


---

<a id="possess"/>

### possess, possesses, possessed, possessing, possession, possessions, dispossess ###

#### Facts: ####

The terms "possess" and "possession" usually refer to owning something. They can also mean to gain control over something or occupy an area of land.

* In the Old Testament, this term is often used in the context of "possessing" or "taking possession of" an area of land.
* When Yahweh commanded the Israelites to "possess" the land of Canaan, it meant that they should go into the land and live there. This involved first conquering the Canaanite peoples who were living on that land.
* Yahweh told the Israelites that he had given them the land of Canaan as "their possession." This could also be translated as "their rightful place to live."
* The people of Israel were also called Yahweh's "special possession." This means that they belonged to him as his people whom he had specifically called to worship and serve him.

#### Translation Suggestions: ####

* The term "possess" could also be translated as "own" or "have" or "have charge over."
* The phrase "take possession of" could be translated as "take control of" or "occupy' or "live on," depending on the context.
* When referring to things that people own, "possessions" could be translated as "belongings" or "property" or "owned things" or "things they owned."
* When Yahweh calls the Israelites,  "my special possession" this could also be translated as "my special people" or "people who belong to me" or "my people whom I love and rule."
* The sentence, "they will become their possession" when referring to land, means "they will occupy the land" or "the land will belong to them."
* The expression, "found in his possession" could be translated as, "that he was holding" or "that he had with him."
* The phrase "as your possession" could also be translated as, "as something that belongs to you" or "as a place where your people will live."
* The phrase, "in his possession" could be translated as "that he owned" or "which belonged to him."

(See also: [Canaan](names.html#canaan), [worship](kt.html#worship))

#### Bible References: ####

* [1 Chronicles 06:70](https://git.door43.org/Door43/en_tn/src/master/1ch/06/70.md)
* [1 Kings 09:17-19](https://git.door43.org/Door43/en_tn/src/master/1ki/09/17.md)
* [Acts 02:43-45](https://git.door43.org/Door43/en_tn/src/master/act/02/43.md)
* [Deuteronomy 04:5-6](https://git.door43.org/Door43/en_tn/src/master/deu/04/05.md)
* [Genesis 31:36-37](https://git.door43.org/Door43/en_tn/src/master/gen/31/36.md)
* [Matthew 13:44-46](https://git.door43.org/Door43/en_tn/src/master/mat/13/44.md)

#### Word Data:####

* Strong's: H270, H272, H834, H2505, H2631, H3027, H3423, H3424, H3425, H3426, H4180, H4181, H4672, H4735, H4736, H5157, H5159, H5459, H7069, G1139, G2192, G2697, G2722, G2932, G2933, G2935, G4047, G5224, G5564


---

<a id="praise"/>

### praise, praises, praised, praising, praiseworthy ###

#### Definition: ####

To praise someone is to express admiration and honor for that person.

* People praise God because of how great he is and because of all the amazing things he has done as the Creator and Savior of the world.
* Praise for God often includes being thankful for what he has done.
* Music and singing is often used as a way to praise God.
* Praising God is part of what it means to worship him.
* The term to "praise" could also be translated as to "speak well of" or to "highly honor with words" or to "say good things about."
* The noun "praise" could be translated as "spoken honor" or "speech that honors" or "speaking good things about." 

(See also: [worship](kt.html#worship))

#### Bible References: ####

* [2 Corinthians 01:3-4](https://git.door43.org/Door43/en_tn/src/master/2co/01/03.md)
* [Acts 02:46-47](https://git.door43.org/Door43/en_tn/src/master/act/02/46.md)
* [Acts 13:48-49](https://git.door43.org/Door43/en_tn/src/master/act/13/48.md)
* [Daniel 03:28](https://git.door43.org/Door43/en_tn/src/master/dan/03/28.md)
* [Ephesians 01:3-4](https://git.door43.org/Door43/en_tn/src/master/eph/01/03.md)
* [Genesis 49:8](https://git.door43.org/Door43/en_tn/src/master/gen/49/08.md)
* [James 03:9-10](https://git.door43.org/Door43/en_tn/src/master/jas/03/09.md)
* [John 05:41-42](https://git.door43.org/Door43/en_tn/src/master/jhn/05/41.md)
* [Luke 01:46-47](https://git.door43.org/Door43/en_tn/src/master/luk/01/46.md)
* [Luke 01:64-66](https://git.door43.org/Door43/en_tn/src/master/luk/01/64.md)
* [Luke 19:37-38](https://git.door43.org/Door43/en_tn/src/master/luk/19/37.md)
* [Matthew 11:25-27](https://git.door43.org/Door43/en_tn/src/master/mat/11/25.md)
* [Matthew 15:29-31](https://git.door43.org/Door43/en_tn/src/master/mat/15/29.md)

#### Examples from the Bible stories: ####

  __*[12:13](https://git.door43.org/Door43/en_tn/src/master/obs/12/13.md)__ The Israelites sang many songs to celebrate their new freedom and to __praise__ God because he saved them from the Egyptian army.
  __*[17:08](https://git.door43.org/Door43/en_tn/src/master/obs/17/08.md)__ When David heard these words, he immediately thanked and __praised__ God because he had promised David this great honor and many blessings. 
  __*[22:07](https://git.door43.org/Door43/en_tn/src/master/obs/22/07.md)__ Zechariah said, "__Praise__ God, because he has remembered his people!
  __*[43:13](https://git.door43.org/Door43/en_tn/src/master/obs/43/13.md)__ They (disciples) enjoyed __praising__ God together and they shared everything they had with each other.
  __*[47:08](https://git.door43.org/Door43/en_tn/src/master/obs/47/08.md)__ They put Paul and Silas in the most secure part of the prison and even locked up their feet. Yet in the middle of the night, they were singing songs of __praise__ to God.

#### Word Data:####

* Strong's: H1319, H6953, H7121, H7150, G1229, G1256, G2097, G2605, G2782, G2783, G2784, G2980, G3853, G3955, G4283, G4296


---

<a id="preach"/>

### preach, preached, preaching, preacher, proclaim ###

#### Definition: ####

To "preach" means to speak to a  group of people, teaching them about God and urging them to obey him.
Related concept: proclaim, proclaims, proclaimed, proclaiming, proclamation, proclamations
Definition of proclaim: to announce or declare something publicly and boldly.

 * Often preaching is done by one person to a large group of people. It is usually spoken, not written.
 * "Preaching" and "teaching" are similar, but are not exactly the same.
 * "Preaching" mainly refers to publicly proclaiming spiritual or moral truth, and urging the audience to respond. "Teaching" is a term that emphasizes instruction, that is, giving people information or teaching them how to do something.
 * The term "preach" is usually used with the word "gospel."
 * What a person has preached to others can also be referred to in general as his "teachings."

(See also: [good news](kt.html#goodnews), [Jesus](kt.html#jesus), [kingdom of God](kt.html#kingdomofgod))


Often in the Bible, "proclaim" means to announce publicly something that God has commanded, or to tell others about God and how great he is.
In the New Testament, the apostles proclaimed the good news about Jesus to many people in many different cities and regions.
The term "proclaim" can also be used for decrees made by kings or for denouncing evil in a public way.
Other ways to translate "proclaim" could include "announce" or "openly preach" or "publicly declare."
The term "proclamation" could also be translated as "announcement" or "public preaching."
(See also: preach)

#### Bible References for "preach: ####

* [2 Timothy 04:1-2](https://git.door43.org/Door43/en_tn/src/master/2ti/04/01.md)
* [Acts 08:4-5](https://git.door43.org/Door43/en_tn/src/master/act/08/04.md)
* [Acts 10:42-43](https://git.door43.org/Door43/en_tn/src/master/act/10/42.md)
* [Acts 14:21-22](https://git.door43.org/Door43/en_tn/src/master/act/14/21.md)
* [Acts 20:25-27](https://git.door43.org/Door43/en_tn/src/master/act/20/25.md)
* [Luke 04:42-44](https://git.door43.org/Door43/en_tn/src/master/luk/04/42.md)
* [Matthew 03:1-3](https://git.door43.org/Door43/en_tn/src/master/mat/03/01.md)
* [Matthew 04:17](https://git.door43.org/Door43/en_tn/src/master/mat/04/17.md)
* [Matthew 12:41](https://git.door43.org/Door43/en_tn/src/master/mat/12/41.md)
* [Matthew 24:12-14](https://git.door43.org/Door43/en_tn/src/master/mat/24/12.md)

#### Bible references for "proclaim" ####

Acts 09:20-22
Acts 13:38-39
Jonah 03:1-3
Luke 04:18-19
Mark 01:14-15
Matthew 10:26-27


#### Examples from the Bible stories: ####

  __*[24:02](https://git.door43.org/Door43/en_tn/src/master/obs/24/02.md)__ He (John) __preached__ to them, saying, "Repent, for the Kingdom of God is near!"
  __*[30:01](https://git.door43.org/Door43/en_tn/src/master/obs/30/01.md)__ Jesus sent his apostles to __preach__ and to teach people in many different villages. 
  __*[38:01](https://git.door43.org/Door43/en_tn/src/master/obs/38/01.md)__ About three years after Jesus first began __preaching__ and teaching publicly, Jesus told his disciples that he wanted to celebrate this Passover with them in Jerusalem, and that he would be killed there.
  __*[45:06](https://git.door43.org/Door43/en_tn/src/master/obs/45/06.md)__ But in spite of this, they __preached__ about Jesus everywhere they went.
  __*[45:07](https://git.door43.org/Door43/en_tn/src/master/obs/45/07.md)__ He (Philip) went to Samaria where he preached about Jesus and many people were saved. 
  __*[46:06](https://git.door43.org/Door43/en_tn/src/master/obs/46/06.md)__ Right away, Saul began __preaching__ to the Jews in Damascus, saying, "Jesus is the Son of God!" 
  __*[46:10](https://git.door43.org/Door43/en_tn/src/master/obs/46/10.md)__ Then they sent them off to __preach__ the good news of Jesus in many other places. 
  __*[47:14](https://git.door43.org/Door43/en_tn/src/master/obs/47/14.md)__ Paul and other Christian leaders traveled to many cities, __preaching__ and teaching people the good news about Jesus. 
  __*[50:02](https://git.door43.org/Door43/en_tn/src/master/obs/50/02.md)__ When Jesus was living on earth he said, "My disciples will __preach__ the good news about the kingdom of God to people everywhere in the world, and then the end will come."

#### Word Data:####

* (foe preach): Strong's: H1319, H6953, H7121, H7150, G1229, G1256, G2097, G2605, G2782, G2783, G2784, G2980, G3955, G4283, G4296
* (for proclaim): Word Data: H1319, H1696, H1697, H2199, H3045, H3745, H4161, H5046, H5608, H6963, H7121, H7440, H8085, G518, G591, G1229, G1861, G2097, G2605, G2782, G2784, G2980, G3142, G3853, G4135



---

<a id="precious"/>

### precious ###

#### Facts: ####

The term "precious" describes people or things that are considered to be very valuable.

* The term "precious stones" or "precious jewels" refers to rocks and minerals that are colorful or have other qualities that make them beautiful or useful.
* Examples of precious stones include diamonds, rubies, and emeralds.
* Gold and silver are called "precious metals."
* Yahweh says that his people are "precious" in his sight (Isaiah 43:4).
* Peter wrote that a gentle and quiet spirit is precious in God's sight (1 Peter 3:4).
* This term could also be translated as "valuable" or "very dear" or "cherished" or "highly valued."

(See also: [gold](#gold), [silver](#silver))

#### Bible References: ####

* [2 Peter 01:1-2](https://git.door43.org/Door43/en_tn/src/master/2pe/01/01.md)
* [Acts 20:22-24](https://git.door43.org/Door43/en_tn/src/master/act/20/22.md)
* [Daniel 11:38-39](https://git.door43.org/Door43/en_tn/src/master/dan/11/38.md)
* [Lamentations 01:7](https://git.door43.org/Door43/en_tn/src/master/lam/01/07.md)
* [Luke 07:2-5](https://git.door43.org/Door43/en_tn/src/master/luk/07/02.md)
* [Psalms 036:7-9](https://git.door43.org/Door43/en_tn/src/master/psa/036/007.md)

#### Word Data:####

* Strong's: H68, H1431, H2532, H2580, H2667, H2896, H3357, H3365, H3366, H3368, H4022, H4030, H4261, H4262, H4901, H5238, H5730, H8443, G927, G1784, G2472, G4185, G4186, G5092, G5093


---

<a id="prey"/>

### prey, prey on ###

#### Definition: ####

The term "prey" refers to something that is hunted, usually an animal that is used for food.

* In a figurative sense, "prey" can refer to a person who is taken advantage of, abused, or oppressed by a more powerful person.
* To "prey on" people means to take advantage of them by oppressing them or stealing something from them.
* The term "prey" could also be translated as "hunted animal" or "hunted one" or "victim."

(See also: [oppress](#oppress))

#### Bible References: ####

* [Jeremiah 12:7-9](https://git.door43.org/Door43/en_tn/src/master/jer/12/07.md)
* [Psalms 104:21-22](https://git.door43.org/Door43/en_tn/src/master/psa/104/021.md)

#### Word Data:####

* Strong's: H400, H957, H961, H962, H2863, H2963, H2964, H4455, H5706, H5861, H7997, H7998


---

<a id="prince"/>

### prince, princes, princess, princesses ###

#### Definition: ####

A "prince" is the son of a king.  A "princess" is a daughter of a king.

* The term "prince" is often used figuratively to refer to a leader, ruler, or other powerful person.
* Because of Abraham's wealth and importance, he was referred to as a "prince" by the Hittites he was living among.
* In the book of Daniel, the term "prince" is used in the expressions "prince of Persia" and "prince of Greece," which in those contexts probably refer to powerful evil spirits who had authority over those regions.
* The archangel Michael is also referred to as a "prince" in the book of Daniel.
* Sometimes in the Bible Satan is referred to as "the prince of this world."
* Jesus is called the "Prince of Peace" and the "Prince of Life."
* In Acts 2:36, Jesus is referred to as "Lord and Christ" and in Acts 5:31 he is referred to as "Prince and Savior," showing the parallel meaning of "Lord" and "Prince."

#### Translation Suggestions: ####

* Ways to translate "prince" could include, "king's son" or "ruler" or "leader" or "chieftain" or "captain." 
* When referring to angels, this could also be translated as, "spirit ruler" or "leading angel."
* When referring to Satan or other evil spirits, this term could also be translated as, "evil spirit ruler" or "powerful spirit leader" or "ruling spirit,"  depending on the context.

(See also: [angel](kt.html#angel), [authority](kt.html#authority), [Christ](kt.html#christ), [demon](kt.html#demon), [lord](kt.html#lord), [power](kt.html#power), [ruler](#ruler), [Satan](kt.html#satan), [Savior](kt.html#savior), [spirit](kt.html#spirit))

#### Bible References: ####

* [Acts 05:29-32](https://git.door43.org/Door43/en_tn/src/master/act/05/29.md)
* [Genesis 12:14-16](https://git.door43.org/Door43/en_tn/src/master/gen/12/14.md)
* [Genesis 49:26](https://git.door43.org/Door43/en_tn/src/master/gen/49/26.md)
* [Luke 01:52-53](https://git.door43.org/Door43/en_tn/src/master/luk/01/52.md)

#### Word Data:####

* Strong's: H1, H117, H324, H2831, H3548, H4502, H5057, H5081, H5139, H5257, H5387, H5633, H5993, H6579, H7101, H7261, H7333, H7336, H7786, H7991, H8269, H8282, H8323, G747, G758, G1413, G2232, G3175


---

<a id="prison"/>

### prison, prisoner, prisoners, prisons, imprison, imprisons, imprisoned, imprisonment, imprisonments ###

#### Definition: ####

The term "prison" refers to a place where criminals are kept as a punishment for their crimes. A "prisoner" is someone who has been put in the prison.

 * A person may be kept in a prison while waiting to be judged in a trial.
 * The term "imprisoned" means "kept in a prison" or "kept in captivity."
 * Many prophets and other servants of God were put in prison even though they had not done anything wrong.

#### Translation Suggestions: ####

 * Another word for "prison" is "jail."
 * This term could also be translated as "dungeon" in contexts where the prison is probably underground or beneath the main part of a palace or other building.
 * The term "prisoners" can also refer in general to people who have been captured by an enemy and kept somewhere against their will. Another way to translate this meaning would be "captives."
 * Other ways to translate "imprisoned" could be, "kept as a prisoner" or "kept in captivity" or "held captive."

(See also: [captive](#captive))

#### Bible References: ####

* [Acts 25:4-5](https://git.door43.org/Door43/en_tn/src/master/act/25/04.md)
* [Ephesians 04:1-3](https://git.door43.org/Door43/en_tn/src/master/eph/04/01.md)
* [Luke 12:57-59](https://git.door43.org/Door43/en_tn/src/master/luk/12/57.md)
* [Luke 22:33-34](https://git.door43.org/Door43/en_tn/src/master/luk/22/33.md)
* [Mark 06:16-17](https://git.door43.org/Door43/en_tn/src/master/mrk/06/16.md)
* [Matthew 05:25-26](https://git.door43.org/Door43/en_tn/src/master/mat/05/25.md)
* [Matthew 14:3-5](https://git.door43.org/Door43/en_tn/src/master/mat/14/03.md)
* [Matthew 25:34-36](https://git.door43.org/Door43/en_tn/src/master/mat/25/34.md)

#### Word Data:####

* Strong's: H612, H613, H615, H616, H631, H1004, H1540, H3608, H3628, H3947, H4115, H4307, H4455, H4525, H4929, H5470, H6115, H6495, H7617, H7622, H7628, G1198, G1199, G1200, G1201, G1202, G1210, G2252, G3612, G4788, G4869, G5083, G5084, G5438, G5439


---

<a id="profane"/>

### profane, profaned, profaning ###

#### Definition: ####

To profane something means to act in a way that defiles, pollutes, or disrespects something that is holy.

* A profane person is one who acts in a way that is unholy and dishonoring of God.
* The verb to "profane" could be translated as to "treat as unholy" or to "be irreverent toward" or to "dishonor."
* God told the Israelites that they "profaned" themselves with idols, meaning that the people were making themselves "unclean" or "dishonored" by this sin. They were also dishonoring God.
* Depending on the context, the adjective "profane" could be translated as "dishonoring" or "godless" or "unholy."
 
(See also: [defile](#defile), [holy](kt.html#holy), [clean](kt.html#clean))

#### Bible References: ####

* [2 Timothy 02:16-18](https://git.door43.org/Door43/en_tn/src/master/2ti/02/16.md)
* [Ezekiel 20:8-9](https://git.door43.org/Door43/en_tn/src/master/ezk/20/08.md)
* [Malachi 01:10-12](https://git.door43.org/Door43/en_tn/src/master/mal/01/10.md)
* [Matthew 12:5-6](https://git.door43.org/Door43/en_tn/src/master/mat/12/05.md)
* [Numbers 18:30-32](https://git.door43.org/Door43/en_tn/src/master/num/18/30.md)

#### Word Data:####

* Strong's: H2455, H2490, H2491, H2610, H2613, H2930, H5234, H8610, G952, G953


---

<a id="profit"/>

### profit, profits, profitable, unprofitable ###

#### Definition: ####

In general, the terms "profit" and "profitable" refer to gaining something good through doing certain actions or behaviors.

Something is "profitable" to someone if it brings them good things or if it helps them bring about good things for other people.

* More specifically, the term "profit" often refers to money that is gained from doing business. A business is "profitable" if it gains more money than it spends.
* Actions are profitable if they bring about good things for people.
* 2 Timothy 3:16 says that all Scripture is "profitable" for correcting and training people in righteousness. This means that the Bible's teachings are helpful and useful for teaching people to live according to God's will.

The term "unprofitable" means to not be useful.

* It literally means to not profit anything or to not help someone gain anything.
* Something that is unprofitable is not worth doing because it does not give any benefit.
* This could be translated as "useless" or "worthless" or "not useful" or "unworthy" or "not beneficial" or "giving no benefit."

(See also: [worthy](kt.html#worthy))

#### Translation Suggestions: ####

* Depending on the context, the term "profit" could also be translated as "benefit" or "help" or "gain."
* The term "profitable" could be translated as "useful" or "beneficial" or "helpful."
* To "profit from" something could be translated as "benefit from" or "gain money from" or "receive help from."
* In the context of a business, "profit" could be translated with a word or phrase that means "money gained" or "surplus of money" or "extra money."

#### Bible References: ####

* [Job 15:1-3](https://git.door43.org/Door43/en_tn/src/master/job/15/01.md)
* [Proverbs 10:16-17](https://git.door43.org/Door43/en_tn/src/master/pro/10/16.md)
* [Jeremiah 02:7-8](https://git.door43.org/Door43/en_tn/src/master/jer/02/07.md)
* [Ezekiel 18:12-13](https://git.door43.org/Door43/en_tn/src/master/ezk/18/12.md)
* [John 06:62-63](https://git.door43.org/Door43/en_tn/src/master/jhn/06/62.md)
* [Mark 08:35-37](https://git.door43.org/Door43/en_tn/src/master/mrk/08/35.md)
* [Matthew 16:24-26](https://git.door43.org/Door43/en_tn/src/master/mat/16/24.md)
* [2 Peter 02:1-3](https://git.door43.org/Door43/en_tn/src/master/2pe/02/01.md)

#### Word Data:####

* Strong's: H1215, H3148, H3276, H3504, H4195, H4768, H5532, H7737, H7939, G147, G255, G512, G888, G889, G890, G1281, G2585, G2770, G2771, G3408, G4297, G4298, G4851, G5539, G5622, G5623, G5624


---

<a id="prosper"/>

### prosper, prospered, prospering, prosperity, prosperous ###

#### Definition: ####

The term "prosper" generally refers to living well and can refer to prospering physically or spiritually. When people or a country are "prosperous," it means they are wealthy and have all that they need to be successful. They are experiencing "prosperity."

* The term "prosperous" often refers to success in owning money and property or in producing everything needed for people to live well.
* In the Bible, the term "prosperous" also includes good health and being blessed with children.
* A "prosperous" city or country is one that has many people, good production of food, and businesses that bring in plenty of money.
* The Bible teaches that a person will prosper spiritually when he obeys God's teachings. He will also experience the blessings of joy and peace. God does not always give people a lot of material wealth, but he will always prosper them spiritually as they follow his ways.
* Depending on the context, the term "prosper" could also be translated as "succeed spiritually" or "be blessed by God" or "experience good things" or "live well."
* The term "prosperous" could also be translated as "successful" or "wealthy" or "spiritually fruitful."
* "Prosperity" could also be translated as "well-being" or "wealth" or "success" or "abundant blessings."

(See also: [bless](kt.html#bless), [fruit](#fruit), [spirit](kt.html#spirit))

#### Bible References: ####

* [1 Chronicles 29:22-23](https://git.door43.org/Door43/en_tn/src/master/1ch/29/22.md)
* [Deuteronomy 23:5-6](https://git.door43.org/Door43/en_tn/src/master/deu/23/05.md)
* [Job 36:10-12](https://git.door43.org/Door43/en_tn/src/master/job/36/10.md)
* [Leviticus 25:26-28](https://git.door43.org/Door43/en_tn/src/master/lev/25/26.md)
* [Psalms 001:3](https://git.door43.org/Door43/en_tn/src/master/psa/001/003.md)

#### Word Data:####

* Strong's: H1129, H1767, H1878, H1879, H2428, H2896, H2898, H3027, H3190, H3444, H3498, H3787, H4195, H5381, H6500, H6509, H6555, H6743, H6744, H7230, H7487, H7919, H7951, H7961, H7963, H7965, G2137


---

<a id="prostitute"/>

### prostitute, prostituted, prostitutes, harlot, whored ###

#### Definition: ####

The terms "prostitute" and "harlot" both refer to a person who performs sexual acts for money or for religious rites. Prostitutes or harlots were usually female, but some were male.

* In the Bible, the word "prostitute" is sometimes used figuratively to refer to a person who worships false gods or who practices witchcraft.
* The expression "play the harlot" means to act like a harlot by being sexually immoral. This expression is also used in the Bible to refer to a person who worships idols.
* To "prostitute oneself" to something means to be sexually immoral or when used figuratively, to be unfaithful to God by worshiping false gods.
* In ancient times, some pagan temples used male and female prostitutes as part of their rituals.
* This term could be translated by the word or phrase that is used in the project language to refer to a prostitute. Some languages may have a euphemistic term that is used for this. (See: [euphemism](https://git.door43.org/Door43/en_ta/src/master/translate/figs-euphemism.md))

(See also: [adultery](kt.html#adultery), [false god](kt.html#falsegod), [sexual immorality](#fornication), [false god](kt.html#falsegod))

#### Bible References: ####

* [Genesis 34:30-31](https://git.door43.org/Door43/en_tn/src/master/gen/34/30.md)
* [Genesis 38:21-23](https://git.door43.org/Door43/en_tn/src/master/gen/38/21.md)
* [Luke 15:28-30](https://git.door43.org/Door43/en_tn/src/master/luk/15/28.md)
* [Matthew 21:31-32](https://git.door43.org/Door43/en_tn/src/master/mat/21/31.md)

#### Word Data:####

* Strong's: H2154, H2181, H2183, H2185, H6945, H6948, H8457, G4204


---

<a id="prostrate"/>

### prostrate, prostrated ###

#### Definition: ####

The term "prostrate" means to be lying face down, stretched out on the ground.

* To "fall prostrate" or to "prostrate oneself" before someone means to suddenly bow down very low or in front of that person.
* Usually this position of being prostrate is a response that shows shock, amazement, and awe because of something miraculous that happened. It also shows honor and respect for the person being bowed to.
* Being prostrate also was a way to worship God. People often responded this way to Jesus in thanksgiving and worship when he did a miracle or to honor him as a great teacher.
* Depending on the context, ways to translate "prostrated" could include "bowed down low with the face to the ground" or "worshiped him by lying face down in front of him" or "bowed down low to the ground in amazement" or "worshiped."
* The phrase "will not prostrate ourselves" could be translated as "will not worship" or "will not lie face down in worship" or "will not bow down and worship."
* "Prostrate himself to" could also be translated as "worship" or "bow down in front of."

(See also: [awe](#awe), [bow](#bow))

#### Bible References: ####

* [2 Kings 17:36-38](https://git.door43.org/Door43/en_tn/src/master/2ki/17/36.md)
* [Genesis 43:28-29](https://git.door43.org/Door43/en_tn/src/master/gen/43/28.md)
* [Revelation 19:3-4](https://git.door43.org/Door43/en_tn/src/master/rev/19/03.md)

#### Word Data:####

* Strong's: H5307, H5457, H6440, H6915, H7812, G4098


---

<a id="proud"/>

### proud, proudly, pride, prideful ###

#### Definition: ####

The terms "proud" and "prideful" refer to a person thinking too highly of himself, and especially, thinking that he is better than other people.

* A proud person often does not admit his own faults. He is not humble.
* Pride can lead to disobeying God in other ways.
* The terms "proud" and "pride" can also be used in a positive sense, such as being "proud of" what someone else has achieved and being "proud of" your children. The expression "take pride in your work" means to find joy in doing your work well.
* Someone can be proud of what he has done without being prideful about it. Some languages have different words for these two different meanings of "pride."
* The term "prideful" is always negative, with the meaning of being "arrogant" or "conceited" or "self-important."

#### Translation Suggestions: #####

* The noun "pride" could be translated as "arrogance" or "conceit" or "self-importance."
* In other contexts, "pride" could be translated as "joy" or "satisfaction" or "pleasure."
* To be "proud of" could also be translated as "happy with" or "satisfied with" or "joyful about (the accomplishments of)."
* The phrase "take pride in your work" could be translated as, "find satisfaction in doing your work well."
* The expression "take pride in Yahweh" could also be translated as "be delighted about all the wonderful things Yahweh has done" or "be happy about how amazing Yahweh is."

(See also: [arrogant](#arrogant), [humble](kt.html#humble), [joy](#joy))

#### Bible References: ####

* [1 Timothy 03:6-7](https://git.door43.org/Door43/en_tn/src/master/1ti/03/06.md)
* [2 Corinthians 01:12-14](https://git.door43.org/Door43/en_tn/src/master/2co/01/12.md)
* [Galatians 06:3-5](https://git.door43.org/Door43/en_tn/src/master/gal/06/03.md)
* [Isaiah 13:19-20](https://git.door43.org/Door43/en_tn/src/master/isa/13/19.md)
* [Luke 01:50-51](https://git.door43.org/Door43/en_tn/src/master/luk/01/50.md)

#### Examples from the Bible stories: ####

  __*[04:02](https://git.door43.org/Door43/en_tn/src/master/obs/04/02.md)__ They were very __proud__, and they did not care about what God said.
  __*[34:10](https://git.door43.org/Door43/en_tn/src/master/obs/34/10.md)__ Then Jesus said, "I tell you the truth, God heard the tax collector's prayer and declared him to be righteous. But he did not like the prayer of the religious leader. God will humble everyone who is __proud__, and he will lift up whoever humbles himself."

#### Word Data:####

* Strong's: H1341, H1343, H1344, H1346, H1347, H1348, H1349, H1361, H1362, H1363, H1364, H1396, H1466, H1467, H1984, H2086, H2087, H2102, H2103, H2121, H3093, H3238, H3513, H4062, H1431, H4791, H5965, H6580, H7293, H7295, H7312, H7342, H7311, H7407, H7830, H8597, G212, G1391, G1392, G2744, G2745, G2746, G3173, G5187, G5229, G5243, G5244, G5308, G5309, G5426, G5450


---

<a id="proverb"/>

### proverb, proverbs ###

#### Definition: ####

A proverb is a short statement that expresses some wisdom or truth.

* Proverbs are powerful because they are easy to remember and repeat.
* Often a proverb will include practical examples from everyday life.
* Some proverbs are very clear and direct, while others are more difficult to understand.
* King Solomon was known for his wisdom and wrote over 1,000 proverbs.
* Jesus often used proverbs or parables when he taught people.
* Ways to translate "proverb" could include "wise saying" or "true word." 

(See also: [Solomon](names.html#solomon), [true](kt.html#true), [wise](kt.html#wise))

#### Bible References: ####

* [1 Kings 04:32-34](https://git.door43.org/Door43/en_tn/src/master/1ki/04/32.md)
* [1 Samuel 24:12-13](https://git.door43.org/Door43/en_tn/src/master/1sa/24/12.md)
* [2 Peter 02:20-22](https://git.door43.org/Door43/en_tn/src/master/2pe/02/20.md)
* [Luke 04:23-24](https://git.door43.org/Door43/en_tn/src/master/luk/04/23.md)
* [Proverbs 01:1-3](https://git.door43.org/Door43/en_tn/src/master/pro/01/01.md)

#### Word Data:####

* Strong's: H2420, H4911, H4912, G3850, G3942


---

<a id="province"/>

### province, provinces, provincial ###

#### Facts: ####

A province is a division or part of a nation or empire. The term "provincial" describes something that is related to a province, such as a provincial governor.

* For example, the ancient Persian Empire was divided up into provinces such as Media, Persia, Syria, and Egypt.
* During the time of the New Testament, the Roman Empire was divided up into provinces such as Macedonia, Asia, Syria, Judea, Samaria, Galilee, and Galatia.
* Each province had its own ruling authority, who was subject to the king or ruler of the empire. This ruler was sometimes called a "provincial official" or "provincial governor."
* The terms "province" and "provincial" could also be translated as "region" and "regional."

(See also: [Asia](names.html#asia), [Egypt](names.html#egypt), [Esther](names.html#esther), [Galatia](names.html#galatia), [Galilee](names.html#galilee), [Judea](names.html#judea), [Macedonia](names.html#macedonia), [Medes](names.html#mede), [Rome](names.html#rome), [Samaria](names.html#samaria), [Syria](names.html#syria))

#### Bible References: ####

* [Acts 19:30-32](https://git.door43.org/Door43/en_tn/src/master/act/19/30.md)
* [Daniel 03:1-2](https://git.door43.org/Door43/en_tn/src/master/dan/03/01.md)
* [Daniel 06:1-3](https://git.door43.org/Door43/en_tn/src/master/dan/06/01.md)
* [Ecclesiastes 02:7-8](https://git.door43.org/Door43/en_tn/src/master/ecc/02/07.md)

#### Word Data:####

* Strong's: H4082, H4083, H5675, H5676, G1885


---

<a id="provoke"/>

### provoke, provokes, provoked, provoking, provocation ###

#### Facts: ####

The term "provoke" means to cause someone to experience a negative reaction or feeling.

* To provoke someone to anger means to do something that causes that person to be angry. This could also be translated as to "cause to become angry" or to "anger."
* When used in a phrase such as, "do not provoke him," this could be translated as "do not anger him" or "do not cause him to be angry" or "do not make him angry with you."

(See also: [angry](#angry))

#### Bible References: ####

* [Ezekiel 20:27-29](https://git.door43.org/Door43/en_tn/src/master/ezk/20/27.md)

#### Word Data:####

* Strong's: H3707, H3708, H4784, H4843, H5006, H5496, H7065, H7069, H7107, H7264, H7265, G653, G2042, G3863, G3893, G3947, G3948, G3949, G4292


---

<a id="prudent"/>

### prudence, prudent, prudently ###

#### Facts: ####

The term "prudent" describes a person who thinks carefully about his actions and makes wise decisions. 

* Often "prudence" refers to the ability to make wise decisions about practical, physical matters, such as in managing money or property.
* Although "prudence" and "wisdom" are similar in meaning, often "wisdom" is more general and focuses on spiritual or moral matters.
* Depending on the context, "prudent" could also be translated as "shrewd" or "careful" or "wise."

(See also: [shrewd](#shrewd), [spirit](kt.html#spirit), [wise](kt.html#wise))

#### Bible References: ####

* [Proverbs 08:4-5](https://git.door43.org/Door43/en_tn/src/master/pro/08/04.md)
* [Proverbs 12:23-24](https://git.door43.org/Door43/en_tn/src/master/pro/12/23.md)
* [Proverbs 27:11-12](https://git.door43.org/Door43/en_tn/src/master/pro/27/11.md)

#### Word Data:####

* Strong's: H995, H5843, H6175, H6191, H6195, H7080, H7919, H7922, G4908, G5428


---

<a id="puffed-up"/>

### puffed up, puffs up ###

#### Definition: ####

The term "puffed up" is a figurative expression that refers to being proud or arrogant. (See: [Idiom](https://git.door43.org/Door43/en_ta/src/master/translate/figs-idiom.md))

* A person who is puffed up has an attitude of feeling superior to others.
* Paul taught that knowing a lot of information or having religious experiences can lead to being "puffed up" or proud.
* Other languages may have a similar idiom or a different one that expresses this meaning, such as "having a big head."
* This could also be translated as "very proud" or "disdainful of others" or "haughty" or "thinking oneself better than others."

(See also: [arrogant](#arrogant), [proud](#proud))

#### Bible References: ####

* [1 Corinthians 04:6-7](https://git.door43.org/Door43/en_tn/src/master/1co/04/06.md)
* [1 Corinthians 08:1-3](https://git.door43.org/Door43/en_tn/src/master/1co/08/01.md)
* [2 Corinthians 12:6-7](https://git.door43.org/Door43/en_tn/src/master/2co/12/06.md)
* [Habakkuk 02:4-5](https://git.door43.org/Door43/en_tn/src/master/hab/02/04.md)

#### Word Data:####

* Strong's: H6075, G5229, G5448


---

<a id="punish"/>

### punish, punishes, punished, punishing, punishment, unpunished ###

#### Definition: ####

The term "punish" means to cause someone to suffer a negative consequence for doing something wrong. The term "punishment" refers to the negative consequence that is given as a result of that wrong behavior.

* Often punishment is intended to motivate a person to stop sinning.
* God punished the Israelites when they disobeyed him, especially when they worshiped false gods. Because of their sin, God allowed their enemies to attack and capture them.
* God is righteous and just, so he has to punish sin. Every human being has sinned against God and deserves punishment.
* Jesus was punished for all the evil things that every person has ever done. He received each person's punishment on himself even though he did nothing wrong and did not deserve that punishment.
* The expressions "go unpunished" and "leave unpunished" mean to decide not to punish people for their wrongdoing. God often allows sin to go unpunished as he waits for people to repent.

(See also: [just](kt.html#justice), [repent](kt.html#repent), [righteous](kt.html#righteous), [sin](kt.html#sin))

#### Bible References: ####

* [1 John 04:17-18](https://git.door43.org/Door43/en_tn/src/master/1jn/04/17.md)
* [2 Thessalonians 01:9-10](https://git.door43.org/Door43/en_tn/src/master/2th/01/09.md)
* [Acts 04:21-22](https://git.door43.org/Door43/en_tn/src/master/act/04/21.md)
* [Acts 07:59-60](https://git.door43.org/Door43/en_tn/src/master/act/07/59.md)
* [Genesis 04:13-15](https://git.door43.org/Door43/en_tn/src/master/gen/04/13.md)
* [Luke 23:15-17](https://git.door43.org/Door43/en_tn/src/master/luk/23/15.md)
* [Matthew 25:44-46](https://git.door43.org/Door43/en_tn/src/master/mat/25/44.md)

their
#### Examples from the Bible stories: ####

  __*[13:07](https://git.door43.org/Door43/en_tn/src/master/obs/13/07.md)__ God also gave many other laws and rules to follow. If the people obeyed these laws, God promised that he would bless and protect them. If they disobeyed them, God would __punish__ them. 
  __*[16:02](https://git.door43.org/Door43/en_tn/src/master/obs/16/02.md)__ Because the Israelites kept disobeying God, he __punished__ them by allowing their enemies to defeat them. 
  __*[19:16](https://git.door43.org/Door43/en_tn/src/master/obs/19/16.md)__ The prophets warned the people that if they did not stop doing evil and start obeying God, then God would judge them as guilty, and he would __punish__ them. 
  __*[48:06](https://git.door43.org/Door43/en_tn/src/master/obs/48/06.md)__ Jesus was the perfect high priest because he took the __punishment__ for every sin that anyone has ever committed.
  __*[48:10](https://git.door43.org/Door43/en_tn/src/master/obs/48/10.md)__ When anyone believes in Jesus, the blood of Jesus takes away that person's sin, and God's __punishment__ passes over him.
  __*[49:09](https://git.door43.org/Door43/en_tn/src/master/obs/49/09.md)__ But God loved everyone in the world so much that he gave his only Son so that whoever believes in Jesus will not be __punished__ for his sins, but will live with God forever.
  __*[49:11](https://git.door43.org/Door43/en_tn/src/master/obs/49/11.md)__ Jesus never sinned, but he chose to be __punished__ and die as the perfect sacrifice to take away your sins and the sins of every person in the world.

#### Word Data:####

* Strong's: H3027, H3256, H4148, H4941, H5221, H5414, H6031, H6064, H6213, H6485, H7999, H8199, G1349, G1556, G1557, G2849, G3811, G5097


---

<a id="purple"/>

### purple ###

#### Facts: ####

The term "purple" is the name of a color that is a mixture of blue and red.

* In ancient times, purple was a rare and highly valuable color of dye that was used to dye the clothing of kings and other high officials.
* Because it was costly and time-consuming to produce this dye, purple clothing was considered a sign of wealth, distinction, and royalty.
* Purple was also one of the colors used for the curtains in the tabernacle and temple, and for the ephod worn by the priests.
* Purple dye was extracted from a kind of sea snail by either crushing or boiling the snails or by causing them to release the dye while still alive. This was an expensive process.
* Roman soldiers put a purple royal robe on Jesus before his crucifixion, to mock him for his claim to be King of the Jews.
* Lydia from the town of Philippi was a woman who made her living by selling purple cloth.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_ta/src/master/translate/translate-names.md))

(See also: [ephod](kt.html#ephod), [Philippi](names.html#philippi), [royal](#royal), [tabernacle](kt.html#tabernacle), [temple](kt.html#temple))

#### Bible References: ####

* [2 Chronicles 02:13-14](https://git.door43.org/Door43/en_tn/src/master/2ch/02/13.md)
* [Daniel 05:7](https://git.door43.org/Door43/en_tn/src/master/dan/05/07.md)
* [Daniel 05:29-31](https://git.door43.org/Door43/en_tn/src/master/dan/05/29.md)
* [Proverbs 31:22-23](https://git.door43.org/Door43/en_tn/src/master/pro/31/22.md)

#### Word Data:####

* Strong's: H710, H711, H713, H8438, H8504, G4209, G4210, G4211


---

<a id="push"/>

### push, pushed, pushing ###

#### Definition: ####

The term "push" literally means to physically move something away using force. There are also several figurative meanings of this term.

* The expression "push away" can mean "reject" or "refuse to help."
* To "push down" can mean to "oppress" or "persecute" or "defeat." It can also mean that someone is literally being pushed down to the ground.
* To "push someone out" means to "get rid of" or "send away" that person.
* The expression "push ahead" means to persevere or to continue doing something without really making sure it is right or safe.

(See also: [oppress](#oppress), [persecute](#persecute), [reject](#reject))

#### Bible References: ####

#### Word Data:####

* Strong's: H1556, H1760, H1792, H3276, H3423, H3728, H5055, H5056, H5186, H8804, G683, G4261


---

<a id="qualify"/>

### qualify, qualified, disqualified ###

#### Definition: ####

The term "qualify" refers to earning the right to receive certain benefits or to be recognized as having certain skills.

* A person who is "qualified" for a particular job has the necessary skills and training to do that job.
* In his letter to the Colossian church, the apostle Paul wrote that God the Father has made believers "qualified" to participate in his kingdom of light. This means that God has given them everything they need to live godly lives.
* The believer cannot earn the right to be part of God's kingdom. He is only qualified because God has redeemed him with the blood of Christ.

#### Translation Suggestions ####

* Depending on the context, "qualified" could be translated as "equipped" or "skilled" or "enabled."
* To "qualify" someone could be translated as to "equip" or to "enable" or to "empower."

(See also: [Colossae](names.html#colossae), [godly](kt.html#godly), [kingdom](#kingdom), [light](#light), [Paul](names.html#paul), [redeem](kt.html#redeem))

#### Bible References: ####

* [Daniel 01:3-5](https://git.door43.org/Door43/en_tn/src/master/dan/01/03.md)

#### Word Data:####

* Strong's: H3581


---

<a id="queen"/>

### queen, queens ###

#### Definition: ####

A queen is either the female ruler of a country or the wife of a king.

* Esther became the queen of the Persian empire when she married King Ahasuerus.
* Queen Jezebel was the evil wife of King Ahab.
* The Queen of Sheba was a famous ruler who came to visit King Solomon.
* A term such as "queen mother" usually referred to the mother or grandmother of a ruling king or the widow of the previous king. A queen mother had much influence; Athaliah, for example, influenced the people to worship idols.

(See also: [Ahasuerus](names.html#ahasuerus), [Athaliah](names.html#athaliah), [Esther](names.html#esther), [king](#king). [Persia](names.html#persia) [ruler](#ruler), [Sheba](names.html#sheba))

#### Bible References: ####

* [1 Kings 10:10](https://git.door43.org/Door43/en_tn/src/master/1ki/10/10.md)
* [1 Kings 11:18-19](https://git.door43.org/Door43/en_tn/src/master/1ki/11/18.md)
* [2 Kings 10:12-14](https://git.door43.org/Door43/en_tn/src/master/2ki/10/12.md)
* [Acts 08:26-28](https://git.door43.org/Door43/en_tn/src/master/act/08/26.md)
* [Esther 01:16-18](https://git.door43.org/Door43/en_tn/src/master/est/01/16.md)
* [Luke 11:31](https://git.door43.org/Door43/en_tn/src/master/luk/11/31.md)
* [Matthew 12:42](https://git.door43.org/Door43/en_tn/src/master/mat/12/42.md)

#### Word Data:####

* Strong's: H1404, H1377, H4410, H4427, H4433, H4436, H4438, H4446, H7694, H8282, G938


---

<a id="quench"/>

### quench, quenched, unquenchable ###

#### Definition: ####

The term "quench" means to put out or stop something that is demanding to be satisfied.

* This term is usually used in the context of quenching thirst and means to stop being thirsty by drinking something.
* It can also be used to refer to putting out a fire.
* Both thirst and fire are quenched with water.
* Paul uses the term "quench" in a figurative way when he instructs believers to not "quench the Holy Spirit." This means to not discourage people from allowing the Holy Spirit from produce his fruits and gifts in them. Quenching the Holy Spirit means preventing the Holy Spirit from freely manifesting his power and work in people..

(See also: [fruit](#fruit), [gift](kt.html#gift), [Holy Spirit](kt.html#holyspirit))

#### Bible References: ####

* [1 Thessalonians 05:19-22](https://git.door43.org/Door43/en_tn/src/master/1th/05/19.md)
* [Ezekiel 20:45-47](https://git.door43.org/Door43/en_tn/src/master/ezk/20/45.md)
* [Isaiah 01:31](https://git.door43.org/Door43/en_tn/src/master/isa/01/31.md)
* [Jeremiah 21:11-12](https://git.door43.org/Door43/en_tn/src/master/jer/21/11.md)

#### Word Data:####

* Strong's: H1846, H3518, H7665, H8257, G762, G4570


---

<a id="rage"/>

### rage, rages, raged, raging ###

#### Facts: ####

Rage is excessive anger what is out of control. When someone rages, it means that person is expressing anger in a destructive way.

* Rage happens when the emotion of anger causes a person to lose self control.
* When controlled by rage, people commit destructive acts and say destructive things.
* The term to "rage" can also mean to move powerfully, in descriptions such as a "raging" storm or ocean waves that "rage."
* When the "nations rage," their to ungodly people disobey God and rebel against him.
* To be "filled with rage" means to have an overwhelming feeling of extreme anger.

(See also: [angry](#angry), [self-control](#selfcontrol)) 

#### Bible References: ####

* [Acts 04:23-25](https://git.door43.org/Door43/en_tn/src/master/act/04/23.md)
* [Daniel 03:13-14](https://git.door43.org/Door43/en_tn/src/master/dan/03/13.md)
* [Luke 04:28-30](https://git.door43.org/Door43/en_tn/src/master/luk/04/28.md)
* [Numbers 25:10-11](https://git.door43.org/Door43/en_tn/src/master/num/25/10.md)
* [Proverbs 19:3-4](https://git.door43.org/Door43/en_tn/src/master/pro/19/03.md)

#### Word Data:####

* Strong's: H398, H1348, H1984, H1993, H2121, H2195, H2196, H2197, H2534, H2734, H2740, H3491, H3820, H5590, H5678, H7264, H7265, H7266, H7267, H7283, H7857, G1693, G2830, G3710, G5433



---

<a id="raise"/>

### raise, raises, raised, rise, risen, arise, arose ###

#### Definition: ####

__raise, raise up__

In general, the word "raise" means to "lift up" or "make higher."

* The figurative phrase "raise up" means to cause something to come into being or to appear. It can also mean to appoint someone to do something.
* Sometimes "raise up" means to "restore" or "rebuild."
* "Raise" has a specialized meaning in the phrase "raise from the dead." It means to cause a dead person to become alive again.
* Sometimes "raise up" means to "exalt" someone or something.

__rise, arise__

To "rise" or "arise" means to "go up" or "get up." The terms "risen," "rose," and "arose" express past action.

* When a person gets up to go somewhere, this is sometimes expressed as "he arose and went" or "he rose up and went."
* If something "arises" it means it "happens" or "begins to happen."
* Jesus predicted that he would "rise from the dead." Three days after Jesus died, the angel said, "He has risen!"

#### Translation Suggestions: ####

* The term "raise" or "raise up" could be translated as "lift up" or "make higher."
* To "raise up" could also be translated as to "cause to appear" or to "appoint" or to "bring into existence."
* To "raise up the strength of your enemies" could be translated as, "cause your enemies to be very strong."
* The phrase "raise someone from the dead" could be translated as "cause someone to return from death to life" or "cause someone to come back to life."
* Depending on the context, "raise up" could also be translated as "provide" or to "appoint" or to "cause to have" or "build up" or "rebuild" or "repair."
* The phrase "arose and went" could be translated as "got up and went" or "went."
* Depending on the context, the term "arose" could also be translated as "began" or "started up" or "got up" or "stood up."

(See also: [resurrection](kt.html#resurrection), [appoint](kt.html#appoint), [exalt](kt.html#exalt))

#### Bible References: ####

* [2 Chronicles 06:40-42](https://git.door43.org/Door43/en_tn/src/master/2ch/06/40.md)
* [2 Samuel 07:12-14](https://git.door43.org/Door43/en_tn/src/master/2sa/07/12.md)
* [Acts 10:39-41](https://git.door43.org/Door43/en_tn/src/master/act/10/39.md)
* [Colossians 03:1-4](https://git.door43.org/Door43/en_tn/src/master/col/03/01.md)
* [Deuteronomy 13:1-3](https://git.door43.org/Door43/en_tn/src/master/deu/13/01.md)
* [Jeremiah 06:1-3](https://git.door43.org/Door43/en_tn/src/master/jer/06/01.md)
* [Judges 02:18-19](https://git.door43.org/Door43/en_tn/src/master/jdg/02/18.md)
* [Luke 07:21-23](https://git.door43.org/Door43/en_tn/src/master/luk/07/21.md)
* [Matthew 20:17-19](https://git.door43.org/Door43/en_tn/src/master/mat/20/17.md)

#### Examples from the Bible stories: ####

* __[21:14](https://git.door43.org/Door43/en_tn/src/master/obs/21/14.md)__ The prophets foretold that the Messiah would die and that God would also __raise__  him from the dead.
* __[41:05](https://git.door43.org/Door43/en_tn/src/master/obs/41/05.md)__ "Jesus is not here. He has __risen__  from the dead, just like he said he would!"
* __[43:07](https://git.door43.org/Door43/en_tn/src/master/obs/43/07.md)__ "Although Jesus died, God __raised__  him from the dead. This fulfills the prophecy which says, 'You will not let your Holy One rot in the grave.' We are witnesses to the fact that God __raised__  Jesus to life again."
* __[44:05](https://git.door43.org/Door43/en_tn/src/master/obs/44/05.md)__ " You killed the author of life, but God __raised__  him from the dead. "
* __[44:08](https://git.door43.org/Door43/en_tn/src/master/obs/44/08.md)__ Peter answered them, "This man stands before you healed by the power of Jesus the Messiah. You crucified Jesus, but God __raised__  him to life again!"
* __[48:04](https://git.door43.org/Door43/en_tn/src/master/obs/48/04.md)__ This meant that Satan would kill the Messiah, but God would __raise__  him to life again, and then the Messiah will crush the power of Satan forever.
* __[49:02](https://git.door43.org/Door43/en_tn/src/master/obs/49/02.md)__ He (Jesus) walked on water, calmed storms, healed many sick people, drove out demons, __raised__  the dead to life, and turned five loaves of bread and two small fish into enough food for over 5,000 people.
* __[49:12](https://git.door43.org/Door43/en_tn/src/master/obs/49/12.md)__ You must believe that Jesus is the Son of God, that he died on the cross instead of you, and that God __raised__  him to life again.

#### Word Data:####

* Strong's: H2210, H2224, H5549, H5782, H5927, H5975, H6209, H6965, H6966, H6974, H7613, H7721, G305, G386, G393, G450, G1096, G1326, G1453, G1525, G1817, G1825, G1892, G1999, G4891


---

<a id="reap"/>

### reap, reaps, reaped, reaper, reapers, reaping ###

#### Definition: ####

The term  "reap" means to harvest crops such as grain. A "reaper" is someone who harvests the crop.

* Usually reapers harvested the crops by hand, pulling up the plants or cutting them with a sharp cutting tool.
* The idea of reaping a harvest is often used figuratively to refer to telling people the good news about Jesus and bringing them into God's family.
* This term is also used figuratively to refer to the consequences that come from a person's actions, as in the saying "a man reaps what he plants."  (See: [Metaphor](https://git.door43.org/Door43/en_ta/src/master/translate/figs-metaphor.md))
* Other ways to translate to "reap" and "reaper" could include to "harvest" and "harvester" (or "person who harvests"). 

(See also: [good news](kt.html#goodnews), [harvest](#harvest))

#### Bible References: ####

* [Galatians 06:9-10](https://git.door43.org/Door43/en_tn/src/master/gal/06/09.md)
* [Matthew 06:25-26](https://git.door43.org/Door43/en_tn/src/master/mat/06/25.md)
* [Matthew 13:29-30](https://git.door43.org/Door43/en_tn/src/master/mat/13/29.md)
* [Matthew 13:36-39](https://git.door43.org/Door43/en_tn/src/master/mat/13/36.md)
* [Matthew 25:24-25](https://git.door43.org/Door43/en_tn/src/master/mat/25/24.md)

#### Word Data:####

* Strong's: H4672, H7114, H7938, G270, G2325, G2327


---

<a id="rebel"/>

### rebel, rebels, rebelled, rebelling, rebellion, rebellious, rebelliousness ###

#### Definition: ####

The term "rebel" means to refuse to submit to someone's authority. A "rebellious" person often disobeys and does evil things. This kind of person is called "a rebel."

* A person is rebelling when he does something the authorities over him have told him not to do.
* A person can also rebel by refusing to do what the authorities have commanded him to do.
* Sometimes people rebel against their government or leader who is ruling over them.
* The term to "rebel" could also be translated as to "disobey" or to "revolt," depending on the context.
* "Rebellious" could also be translated as "continually disobedient" or "refusing to obey."
* The term "rebellion" means "refusal to obey" or "disobedience" or "law-breaking."
* The phrase "the rebellion" or "a rebellion" can also refer to an organized group of people who publicly rebel against ruling authorities by breaking the law and attacking leaders and other people. Often they try to get other people to join them in rebelling.

(See also: [authority](kt.html#authority), [governor](#governor))

#### Bible References: ####

* [1 Kings 12:18-19](https://git.door43.org/Door43/en_tn/src/master/1ki/12/18.md)
* [1 Samuel 12:14-15](https://git.door43.org/Door43/en_tn/src/master/1sa/12/14.md)
* [1 Timothy 01:9-11](https://git.door43.org/Door43/en_tn/src/master/1ti/01/09.md)
* [2 Chronicles 10:17-19](https://git.door43.org/Door43/en_tn/src/master/2ch/10/17.md)
* [Acts 21:37-38](https://git.door43.org/Door43/en_tn/src/master/act/21/37.md)
* [Luke 23:18-19](https://git.door43.org/Door43/en_tn/src/master/luk/23/18.md)

#### Examples from the Bible stories: ####

  __*[14:14](https://git.door43.org/Door43/en_tn/src/master/obs/14/14.md)__ After the Israelites had wandered in the wilderness for forty years, all of them who had __rebelled__ against God were dead. 
  __*[18:07](https://git.door43.org/Door43/en_tn/src/master/obs/18/07.md)__ Ten of the tribes of the nation of Israel __rebelled__ against Rehoboam. 
  __*[18:09](https://git.door43.org/Door43/en_tn/src/master/obs/18/09.md)__ Jeroboam __rebelled__ against God and caused the people to sin. 
  __*[18:13](https://git.door43.org/Door43/en_tn/src/master/obs/18/13.md)__ Most of the people of Judah also __rebelled__ against God and worshiped other gods. 
  __*[20:07](https://git.door43.org/Door43/en_tn/src/master/obs/20/07.md)__ But after a few years, the king of Judah __rebelled__ against Babylon. 
  __*[45:03](https://git.door43.org/Door43/en_tn/src/master/obs/45/03.md)__ Then he (Stephen) said, "You stubborn and __rebellious__ people always reject the Holy Spirit, just as your ancestors always rejected God and killed his prophets.

#### Word Data:####

* Strong's: H4775, H4776, H4777, H4779, H4780, H4784, H4805, H5327, H5627, H5637, H6586, H6588, H7846, G3893, G4955


---

<a id="rebuke"/>

### rebuke, rebukes, rebuked ###

#### Definition: ####

To rebuke is to give someone a stern verbal correction, often in order to help that person turn away from sin. Such a correction is a rebuke.

* The New Testament commands Christians to rebuke other believers when they are clearly disobeying God.
* The book of Proverbs instructs parents to rebuke their children when they are disobedient.
* A rebuke is typically given to prevent those who committed a wrong from further involving themselves in sin.
* This could be translated by "sternly correct" or "admonish."
* The phrase "a rebuke" could be translated by "a stern correction" or "a strong criticism."
* "Without rebuke" could be translated as "without admonishing" or "without criticism."

(See also [admonish](#admonish), [disobey](#disobey))

#### Bible References: ####

* [Mark 01:23-26](https://git.door43.org/Door43/en_tn/src/master/mrk/01/23.md)
* [Mark 16:14-16](https://git.door43.org/Door43/en_tn/src/master/mrk/16/14.md)
* [Matthew 08:26-27](https://git.door43.org/Door43/en_tn/src/master/mat/08/26.md)
* [Matthew 17:17-18](https://git.door43.org/Door43/en_tn/src/master/mat/17/17.md)

#### Word Data:####

* Strong's: H1605, H1606, H2778, H2781, H3198, H4045, H4148, H8156, H8433, G298, G299, G1649, G1651, G1969, G2008, G3679


---

<a id="receive"/>

### receive, receives, received, receiving, receiver ###

#### Definition: ####

The term "receive" generally means to get or accept something that is given, offered, or presented.

* To "receive" can also mean to suffer or experience something, as in "he received punishment for what he did."
* There is also a special sense in which we can "receive" a person. For example, to "receive" guests or visitors means to welcome them and  treat them with honor in order to build a relationship with them.
* To "receive the gift of the Holy Spirit" means we are given the Holy Spirit and welcome him to work in and through our lives.
* To "receive Jesus" means to accept God's offer of salvation through Jesus Christ.
* When a blind person "receives his sight" means that God has healed him and enabled him to see.

#### Translation Suggestions: ####

* Depending on the context, "receive" could be translated as "accept" or "welcome" or "experience" or "be given."
* The expression "you will receive power" could be translated as "you will be given power" or "God will give you power" or "power will be given to you (by God)" or "God will cause the Holy Spirit to work powerfully in you."
* The phrase "received his sight" could be translated as "was able to see" or "became able to see again" or "was healed by God so that he was able to see."

(See also: [Holy Spirit](kt.html#holyspirit), [Jesus](kt.html#jesus), [lord](kt.html#lord), [save](kt.html#save))

#### Bible References: ####

* [1 John 05:9-10](https://git.door43.org/Door43/en_tn/src/master/1jn/05/09.md)
* [1 Thessalonians 01:6-7](https://git.door43.org/Door43/en_tn/src/master/1th/01/06.md)
* [1 Thessalonians 04:1-2](https://git.door43.org/Door43/en_tn/src/master/1th/04/01.md)
* [Acts 08:14-17](https://git.door43.org/Door43/en_tn/src/master/act/08/14.md)
* [Jeremiah 32:33-35](https://git.door43.org/Door43/en_tn/src/master/jer/32/33.md)
* [Luke 09:5-6](https://git.door43.org/Door43/en_tn/src/master/luk/09/05.md)
* [Malachi 03:10-12](https://git.door43.org/Door43/en_tn/src/master/mal/03/10.md)
* [Psalms 049:14-15](https://git.door43.org/Door43/en_tn/src/master/psa/049/014.md)

#### Examples from the Bible stories: ####

* __[21:13](https://git.door43.org/Door43/en_tn/src/master/obs/21/13.md)__ The prophets also said that the Messiah would be perfect, having no sin. He would die to __receive__  the punishment for other people's sin. His punishment would bring peace between God and people.
* __[45:05](https://git.door43.org/Door43/en_tn/src/master/obs/45/05.md)__ As Stephen was dying, he cried out, "Jesus, __receive__  my spirit."
* __[49:06](https://git.door43.org/Door43/en_tn/src/master/obs/49/06.md)__ He (Jesus) taught that some people will receive him and be saved, but others will not.
* __[49:10](https://git.door43.org/Door43/en_tn/src/master/obs/49/10.md)__ When Jesus died on the cross, he __received__  your punishment.
* __[49:13](https://git.door43.org/Door43/en_tn/src/master/obs/49/13.md)__ God will save everyone who believes in Jesus and __receives__  him as their Master.

#### Word Data:####

* Strong's: H1878, H2505, H3557, H3947, H6901, H6902, H8254, G308, G324, G353, G354, G568, G588, G618, G1183, G1209, G1523, G1653, G1926, G2210, G2865, G2983, G3028, G3335, G3336, G3549, G3858, G3880, G3970, G4327, G4355, G4356, G4687, G4732, G5264, G5274, G5562


---

<a id="reed"/>

### reed, reeds ###

#### Facts: ####

The term "reed" refers to a plant with a long stalk that grows in the water, usually along the edge of a river or stream.

* The reeds in the Nile River where Moses was hidden as a baby were also called "bulrushes." They were tall, hollow stalks growing in dense clumps in the river water.
* These fibrous plants were used in ancient Egypt for making paper, baskets, and boats.
* The stalk of the reed plant is flexible and is easily bent over by the wind.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_ta/src/master/translate/translate-names.md))

(See also: [Egypt](names.html#egypt), [Moses](names.html#moses), [Nile River](names.html#nileriver))

#### Bible References: ####

* [1 Kings 14:14-16](https://git.door43.org/Door43/en_tn/src/master/1ki/14/14.md)
* [Luke 07:24-26](https://git.door43.org/Door43/en_tn/src/master/luk/07/24.md)
* [Matthew 11:7-8](https://git.door43.org/Door43/en_tn/src/master/mat/11/07.md)
* [Matthew 12:19-21](https://git.door43.org/Door43/en_tn/src/master/mat/12/19.md)
* [Psalm 068:30-31](https://git.door43.org/Door43/en_tn/src/master/psa/068/030.md)

#### Word Data:####

* Strong's: H98, H100, H260, H5488, H6169, H7070, G2063, G2563


---

<a id="refuge"/>

### refuge, refugee, refugees, shelter, shelters, sheltered, sheltering ###

#### Definition: ####

The term "refuge" refers to a place or condition of safety and protection. A "refugee" is someone who is seeking a safe place. A "shelter" refers to a place that can protect from weather or danger.

* In the Bible, God is often referred to as a refuge where his people can be safe, protected, and cared for.
* The term "city of refuge" in the Old Testament referred to one of several cities where a person who accidentally killed someone could go for protection from people who would attack them in revenge.
* A "shelter" is often a physical structure such as a building or roof that can provide protection to people or animals.
* Sometimes "shelter" means "protection," as when Lot said that his guests were "under the shelter" of his roof. He was saying that they should be safe because he was taking responsibility to protect them as members of his household.

#### Translation Suggestions: ####

* The term "refuge" could be translated as "safe place" or "place of protection."
* "Refugees" are people leaving their home to escape from a dangerous situation, and could be translated as "aliens," "homeless people," or "exiles." 
* Depending on the context, the term "shelter" could be translated as "something that protects" or "protection" or "protected place."
* If it refers to a physical structure, "shelter" could also be translated as "protective building" or "house of safety."
* The phrase "into safe shelter" could be translated as "into a safe place" or "into a place that will protect."
* To "find shelter" or to "take shelter" or to "take refuge" could be translated as to "find a place of safety" or to "put oneself in a protected place."

#### Bible References: ####

* [2 Samuel 22:3-4](https://git.door43.org/Door43/en_tn/src/master/2sa/22/03.md)
* [Deuteronomy 32:37-38](https://git.door43.org/Door43/en_tn/src/master/deu/32/37.md)
* [Isaiah 23:13-14](https://git.door43.org/Door43/en_tn/src/master/isa/23/13.md)
* [Jeremiah 16:19-21](https://git.door43.org/Door43/en_tn/src/master/jer/16/19.md)
* [Numbers 35:24-25](https://git.door43.org/Door43/en_tn/src/master/num/35/24.md)
* [Psalm 046:1-3](https://git.door43.org/Door43/en_tn/src/master/psa/046/001.md)
* [Psalms 028:6-8](https://git.door43.org/Door43/en_tn/src/master/psa/028/006.md)

#### Word Data:####

* Strong's: H2620, H4268, H4498, H4585, H4733, H4869


---

<a id="reign"/>

### reign, reigns, reigned, reigning ###

#### Definition: ####

The term to "reign" means to rule over the people of a particular country or kingdom. The reign of a king is the time period during which he is ruling.

* The term "reign" is also used to refer to God reigning as king over the entire world.
* God allowed human kings to reign over Israel after the people rejected him as their king.
* When Jesus Christ returns, he will openly reign as king over the whole world, and Christians will reign with Him.
* This term could also be translated as "absolute rule" or "rule as king."

(See also: [kingdom](#kingdom))

#### Bible References: ####

* [2 Timothy 02:11-13](https://git.door43.org/Door43/en_tn/src/master/2ti/02/11.md)
* [Genesis 36:34-36](https://git.door43.org/Door43/en_tn/src/master/gen/36/34.md)
* [Luke 01:30-33](https://git.door43.org/Door43/en_tn/src/master/luk/01/30.md)
* [Luke 19:26-27](https://git.door43.org/Door43/en_tn/src/master/luk/19/26.md)
* [Matthew 02:22-23](https://git.door43.org/Door43/en_tn/src/master/mat/02/22.md)

#### Word Data:####

* Strong's: H3427, H4427, H4437, H4438, H4467, H4468, H4475, H4791, H4910, H6113, H7287, H7786, G757, G936, G2231, G4821


---

<a id="reject"/>

### reject, rejects, rejected, rejecting, rejection ###

#### Definition: ####

To "reject" someone or something means to refuse to accept that person or thing.

* The term "reject" can also mean to "refuse to believe in" something.
* To reject God also means to refuse to obey him.
* When the Israelites rejected Moses' leadership, it means that they were rebelling against his authority. They did not want to obey him.
* The Israelites showed that they were rejecting God when they worshiped false gods.
* The term "push away" is the literal meaning of this word. Other languages may have a similar expression that means to reject or refuse to believe someone or something.

#### Translation Suggestions ####

* Depending on the context, the term "reject" could also be translated by "not accept" or "stop helping" or "refuse to obey" or "stop obeying."
* In the expression "stone that the builders rejected," the term "rejected" could be translated as "refused to use" or "did not accept" or "threw away" or "got rid of as worthless."
* In the context of people who rejected God's commandments, rejected could be translated as "refused to obey" his commands or "stubbornly chose to not accept" God's laws.

(See also: [command](kt.html#command), [disobey](#disobey), [obey](#obey), [stiff-necked](#stiffnecked))

#### Bible References: ####

* [Galatians 04:12-14](https://git.door43.org/Door43/en_tn/src/master/gal/04/12.md)
* [Hosea 04:6-7](https://git.door43.org/Door43/en_tn/src/master/hos/04/06.md)
* [Isaiah 41:8-9](https://git.door43.org/Door43/en_tn/src/master/isa/41/08.md)
* [John 12:48-50](https://git.door43.org/Door43/en_tn/src/master/jhn/12/48.md)
* [Mark 07:8-10](https://git.door43.org/Door43/en_tn/src/master/mrk/07/08.md)

#### Word Data:####

* Strong's: H947, H959, H2186, H2310, H3988, H5006, H5034, H5186, H5203, H5307, H5541, H5800, G96, G114, G483, G550, G579, G580, G593, G683, G720, G1609, G3868


---

<a id="renown"/>

### renown, renowned ###

#### Definition: ####

The term "renown" refers to the greatness associated with being well known and having a praiseworthy reputation. Something or someone is "renowned" if it has renown.

* A "renowned" person is someone who is well known and highly esteemed.
* "Renown" especially refers to a good reputation that is widely known over a long period of time.
* A city that is "renowned" is often well known for its wealth and prosperity.

#### Translation Suggestions: ####

   * The term "renown" could also be translated as "fame" or "esteemed reputation" or "greatness that is well-known by many people."
   * The term "renowned" could also be translated as "well known and highly esteemed" or "having an excellent reputation."
   * The expression "May the Lord's name be renowned in Israel" could be translated as "May the Lord's name be well known and honored by the people of Israel."
   * The phrase "men of renown" could be translated as "men well known for their courage" or "famous warriors" or "highly esteemed men."
   * The expression "your renown endures through all generations" could be translated as "throughout the years people will hear about how great you are" or "your greatness is seen and heard by people in every generation."

(See also: [honor](kt.html#honor))

#### Bible References: ####

* [Genesis 06:4](https://git.door43.org/Door43/en_tn/src/master/gen/06/04.md)
* [Psalms 135:12-14](https://git.door43.org/Door43/en_tn/src/master/psa/135/012.md)

#### Word Data:####

* Strong's: H1984, H7121, H8034


---

<a id="report"/>

### report, reports, reported ###

#### Definition: ####

The term to "report" means to tell people about something that happened, often giving details about that event. A "report" is what is told, and can be spoken or written.

* "Report" could also be translated as "tell" or "explain" or "tell the details of."
* The expression "Report this to no one" could be translated as, "Don't talk about this with anyone" or "Don't tell anyone about this."
* Ways to translate "a report" could include "an explanation" or "a story" or "a detailed account," depending on the context.

#### Bible References: ####

 

* [Acts 05:22-23](https://git.door43.org/Door43/en_tn/src/master/act/05/22.md)
* [John 12:37-38](https://git.door43.org/Door43/en_tn/src/master/jhn/12/37.md)
* [Luke 05:15-16](https://git.door43.org/Door43/en_tn/src/master/luk/05/15.md)
* [Luke 08:34-35](https://git.door43.org/Door43/en_tn/src/master/luk/08/34.md)
* [Matthew 28:14-15](https://git.door43.org/Door43/en_tn/src/master/mat/28/14.md)

#### Word Data:####

* Strong's: H1681, H1696, H1697, H5046, H7725, H8034, H8052, H8085, H8088, G189, G191, G312, G518, G987, G1225, G1310, G1426, G1834, G2036, G2162, G2163, G3004, G3056, G3140, G3141, G3377


---

<a id="reproach"/>

### reproach, reproaches, reproached, reproaching, reproachfully ###

#### Definition: ####

To reproach someone means to criticize or disapprove of that person's character or behavior. A reproach is the negative comment about the person.

* Saying that a person is "above reproach" or "beyond reproach" or "without reproach" means that this person behaves in a God-honoring way and there is little or nothing that could be said in criticism of him.
* The word "reproach" could also be translated as "accusation" or "shame" or "disgrace."
* To "reproach" could also be translated as to "rebuke" or to "accuse" or to "criticize," depending on the context.

(See also: [accuse](#accuse), [rebuke](#rebuke), [shame](#shame))

#### Bible References: ####

* [1 Timothy 05:7-8](https://git.door43.org/Door43/en_tn/src/master/1ti/05/07.md)
* [1 Timothy 06:13-14](https://git.door43.org/Door43/en_tn/src/master/1ti/06/13.md)
* [Jeremiah 15:15-16](https://git.door43.org/Door43/en_tn/src/master/jer/15/15.md)
* [Job 16:9-10](https://git.door43.org/Door43/en_tn/src/master/job/16/09.md)
* [Proverbs 18:3-4](https://git.door43.org/Door43/en_tn/src/master/pro/18/03.md)

#### Word Data:####

* Strong's: H1421, H1442, H2617, H2659, H2778, H2781, H3637, H3639, H7036, G410, G423, G819, G3059, G3679, G3680, G3681, G5195, G5196, G5484


---

<a id="rest"/>

### rest, rests, rested, resting, restless ###

#### Definition: ####

The term to "rest" literally means to stop working in order to relax or regain strength. The phrase "the rest of" refers to the remainder of something. A "rest" is to stop working.

* An object can be said to be "resting" somewhere, which means it is "standing" or "sitting" there.
* A boat that "comes to rest" somewhere has "stopped" or "landed" there.
* When a person or animals rest, they are sitting or lying down in order to refresh themselves.
* God commanded the Israelites to rest on the seventh day of the week. This day of not working was called the "Sabbath" day.
* To rest an object on something means to "place" or "put" it there.

#### Translation Suggestions: ####

* Depending on the context, to "rest (oneself)" could also be translated as to "stop working" or to "refresh himself" or to "stop carrying burdens."
* To "rest" an object on something could be translated as to "place" or "put" or "set" that object on something.
* When Jesus said, "I will give you rest," this could also be translated as " I will cause you to stop carrying your burden" or "I will help you be at peace" or "I will empower you to relax and trust in me."
* God said, "they will not enter my rest," and this statement could be translated as "they will not experience my blessings of rest" or "they will not experience the joy and peace that comes from trusting in me."
* The term "the rest" could be translated as "those that remain" or "all the other people" or "everything that is left."

(See also: [remnant](kt.html#remnant), [Sabbath](kt.html#sabbath))

#### Bible References: ####

* [2 Chronicles 06:40-42](https://git.door43.org/Door43/en_tn/src/master/2ch/06/40.md)
* [Genesis 02:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/02/01.md)
* [Jeremiah 06:16-19](https://git.door43.org/Door43/en_tn/src/master/jer/06/16.md)
* [Matthew 11:28-30](https://git.door43.org/Door43/en_tn/src/master/mat/11/28.md)
* [Revelation 14:11-12](https://git.door43.org/Door43/en_tn/src/master/rev/14/11.md)

#### Word Data:####

* Strong's: H14, H1824, H1826, H2308, H3498, H3499, H4494, H4496, H4771, H5117, H5118, H5183, H5564, H6314, H7258, H7280, H7599, H7604, H7605, H7606, H7611, H7673, H7677, H7901, H7931, H7954, H8058, H8172, H8252, H8300, G372, G373, G425, G1515, G1879, G1954, G1981, G2270, G2663, G2664, G2681, G2838, G3062, G4520


---

<a id="return"/>

### return, returns, returned, returning ###

#### Definition: ####

The term "return" means to go back or to give something back.

* To "return to" something means to start doing that activity again. To "return to" a place or person means to bo back to that place or person again.
* When the Israelites returned to their worship of idols, they were starting to worship them again.
* When they returned to Yahweh, they repented and were worshiping Yahweh again.
* To return land or things that were taken or received from someone else means to give that property back to the person it belongs to.

(See also: [turn](#turn))

#### Bible References: ####

#### Word Data:####

* Strong's: H5437, H7725, H7729, H8421, H8666, G344, G360, G390, G1877, G1880, G1994, G5290


---

<a id="reverence"/>

### revere, revered, reverence, reverences, reverent ###

#### Definition: ####

The term "reverence" refers to feelings of profound, deep respect for someone or something. "Revere" someone or something is to show reverence towards that person or thing.

* Feelings of reverence can be seen in actions that honor the person who is revered.
* The fear of the Lord is an inner reverence that manifests itself in obedience to God's commandments.
* This term could also be translated as "fear and honor" or "sincere respect."

(See also: [fear](kt.html#fear), [honor](kt.html#honor), [obey](#obey))

#### Bible References: ####

* [1 Peter 01:15-17](https://git.door43.org/Door43/en_tn/src/master/1pe/01/15.md)
* [Hebrews 11:7](https://git.door43.org/Door43/en_tn/src/master/heb/11/07.md)
* [Isaiah 44:17](https://git.door43.org/Door43/en_tn/src/master/isa/44/17.md)
* [Psalms 005:7-8](https://git.door43.org/Door43/en_tn/src/master/psa/005/007.md)

#### Word Data:####

* Strong's: H3372, H3373, H3374, H4172, H6342, H7812, G127, G1788, G2125, G2412, G5399, G5401


---

<a id="reward"/>

### reward, rewards, rewarded, rewarding, rewarder ###

#### Definition: ####

The term "reward" refers to what a person receives because of something he has done, either good or bad. To "reward" someone is to give someone something he deserves.

* A reward can be a good or positive thing that a person receives because he has done something well or because he has obeyed God.
* Sometimes a reward can refer to negative things that may result from bad behavior, such as the statement "the reward of the wicked." In this context "reward" refers to the punishment or negative consequences they receive because of their sinful actions.

#### Translation Suggestions: ####

* Depending on the context, the term "reward" could be translated as "payment" or "something that is deserved" or "punishment."
* To "reward" someone could be translated by to "repay" or to "punish" or to "give what is deserved."
* Make sure the translation of this term does not refer to wages. A reward is not specifically about earning money as part of a job.

(See also: [punish](#punish))

#### Bible References: ####

* [Deuteronomy 32:5-6](https://git.door43.org/Door43/en_tn/src/master/deu/32/05.md)
* [Isaiah 40:9-10](https://git.door43.org/Door43/en_tn/src/master/isa/40/09.md)
* [Luke 06:35-36](https://git.door43.org/Door43/en_tn/src/master/luk/06/35.md)
* [Mark 09:40-41](https://git.door43.org/Door43/en_tn/src/master/mrk/09/40.md)
* [Matthew 05:11-12](https://git.door43.org/Door43/en_tn/src/master/mat/05/11.md)
* [Matthew 06:3-4](https://git.door43.org/Door43/en_tn/src/master/mat/06/03.md)
* [Psalms 127:3-5](https://git.door43.org/Door43/en_tn/src/master/psa/127/003.md)
* [Revelation 11:18](https://git.door43.org/Door43/en_tn/src/master/rev/11/18.md)

#### Word Data:####

* Strong's: H319, H866, H868, H1576, H1578, H1580, H4864, H4909, H4991, H5023, H6118, H6468, H6529, H7809, H7810, H7936, H7938, H7939, H7966, H7999, H8011, H8021, G469, G514, G591, G2603, G3405, G3406, G3408


---

<a id="robe"/>

### robe, robes, robed ###

#### Definition: ####

A robe is an outer garment with long sleeves that can be worn by a man or a woman. It is similar to a coat.

* Robes are open in the front and are tied shut with a sash or belt.
* They can be long or short.
* Purple robes were worn by kings as a sign of royalty, wealth, and prestige.

(See also: [royal](#royal), [tunic](#tunic))

#### Bible References: ####

* [Exodus 28:4-5](https://git.door43.org/Door43/en_tn/src/master/exo/28/04.md)
* [Genesis 49:11-12](https://git.door43.org/Door43/en_tn/src/master/gen/49/11.md)
* [Luke 15:22-24](https://git.door43.org/Door43/en_tn/src/master/luk/15/22.md)
* [Luke 20:45-47](https://git.door43.org/Door43/en_tn/src/master/luk/20/45.md)
* [Matthew 27:27-29](https://git.door43.org/Door43/en_tn/src/master/mat/27/27.md)

#### Word Data:####

* Strong's: H145, H155, H899, H1545, H2436, H2684, H3671, H3801, H3830, H3847, H4060, H4254, H4598, H5497, H5622, H6614, H7640, H7757, H7897, H8071, G1746, G2066, G2067, G2440, G4749, G4016, G5511


---

<a id="rod"/>

### rod, rods ###

#### Definition: ####

The term "rod" refers to a narrow, solid, stick-like tool that was used in several different ways. It was probably at least a meter in length.

* A wooden rod was used by a shepherd to defend the sheep from other animals. It was also thrown toward a wandering sheep to bring it back to the the flock.
* In Psalm 23, King David used the terms "rod" and "staff" as metaphors to refer to God's guidance and discipline for his people.
* A shepherd's rod was also used to count the sheep as they passed under it.
* Another metaphorical expression, "rod of iron," refers to God's punishment for people who rebel against him and do evil things.
* In ancient times, measuring rods made of metal, wood, or stone were used to measure the length of a building or object.
* In the Bible, a wooden rod was also referred to as an instrument to discipline children.

(See also: [staff](#staff), [sheep](#sheep), [shepherd](#shepherd))

#### Bible References: ####

* [1 Corinthians 04:19-21](https://git.door43.org/Door43/en_tn/src/master/1co/04/19.md)
* [1 Samuel 14:43-44](https://git.door43.org/Door43/en_tn/src/master/1sa/14/43.md)
* [Acts 16:22-24](https://git.door43.org/Door43/en_tn/src/master/act/16/22.md)
* [Exodus 27:9-10](https://git.door43.org/Door43/en_tn/src/master/exo/27/09.md)
* [Revelation 11:1-2](https://git.door43.org/Door43/en_tn/src/master/rev/11/01.md)

#### Word Data:####

* Strong's: H2415, H4294, H4731, H7626, G2563, G4463, G4464


---

<a id="royal"/>

### royal, royalty ###

#### Definition: ####

The term "royal" describes people and things associated with a king or queen.

* Examples of things that could be called "royal" include a king's clothing, palace, throne, and crown.
* A king or queen usually lived in a royal palace.
* A king wore special clothing, sometimes called "royal robes." Often a king's robes were purple, this color could only be produced by  a rare and expensive type of dye.
* In the New Testament, believers in Jesus were called a "royal priesthood." Other ways to translate this could include "priests who serve God the King" or "called to be priests for God the King."
* The term "royal" could also be translated as "kingly" or "belonging to a king."

(See also: [king](#king). [palace](#palace), [priest](kt.html#priest), [purple](#purple), [queen](#queen), [robe](#robe))

#### Bible References: ####

* [1 Kings 10:13](https://git.door43.org/Door43/en_tn/src/master/1ki/10/13.md)
* [2 Chronicles 18:28-30](https://git.door43.org/Door43/en_tn/src/master/2ch/18/28.md)
* [Amos 07:12-13](https://git.door43.org/Door43/en_tn/src/master/amo/07/12.md)
* [Genesis 49:19-21](https://git.door43.org/Door43/en_tn/src/master/gen/49/19.md)

#### Word Data:####

* Strong's: H643, H1935, H4410, H4428, H4430, H4437, H4438, H4467, H4468, H7985, H8237, G933, G934, G937


---

<a id="ruin"/>

### ruin, ruins, ruined ###

#### Definition: ####

To "ruin" something means to spoil, destroy, or cause to be useless. The term "ruin" or "ruins" refers to the rubble and spoiled remains of something that has been destroyed.

* The prophet Zephaniah spoke about the day of God's wrath as a "day of ruin" when the world will be judged and punished.
* The book of Proverbs says that ruin and destruction await those who are ungodly.
* Depending on the context, to "ruin" could be translated as to "destroy" or to "spoil" or to "make useless" or to "break."
* The term "ruin" or "ruins" could be translated as "rubble" or "broken-down buildings" or "destroyed city" or "devastation" or "brokenness" or "destruction," depending on the context.

#### Bible References: ####

* [2 Chronicles 12:7-8](https://git.door43.org/Door43/en_tn/src/master/2ch/12/07.md)
* [2 Kings 19:25-26](https://git.door43.org/Door43/en_tn/src/master/2ki/19/25.md)
* [Acts 15:15-18](https://git.door43.org/Door43/en_tn/src/master/act/15/15.md)
* [Isaiah 23:13-14](https://git.door43.org/Door43/en_tn/src/master/isa/23/13.md)

#### Word Data:####

* Strong's: H6, H1197, H1530, H1820, H1942, H2034, H2040, H2717, H2719, H2720, H2723, H2930, H3510, H3765, H3782, H3832, H4072, H4288, H4383, H4384, H4654, H4658, H4876, H4889, H5221, H5557, H5754, H5856, H6365, H7451, H7489, H7582, H7591, H7612, H7701, H7703, H7843, H8047, H8074, H8077, H8414, H8510, G2679, G2692, G3639, G4485


---

<a id="ruler"/>

### rule, rules, ruled, ruler, rulers, ruling, rulings, overrules, overruled ###

#### Definition: ####

The term "ruler" is a general reference to a person who has authority over other people, such as a leader of a country, kingdom, or religious group. A ruler is one who "rules," and his authority is his "rule."


* In the Old Testament, a king was sometimes referred to generally as a "ruler," as in the phrase "appointed him ruler over Israel."
* God was referred to as the ultimate ruler, who rules over all other rulers.
* In the New Testament, the leader of a synagogue was called a "ruler."
* Another type of ruler in the New Testament was a "governor."
* Depending on the context, "ruler" could be translated as "leader" or "person who has authority over."
* The action to "rule" means to "lead" to "have authority over." It is means the same thing as "reign" when it refers to the ruling of a king.

(See also: [authority](kt.html#authority), [governor](#governor), [king](#king), [synagogue](kt.html#synagogue))

#### Bible References: ####

* [Acts 03:17-18](https://git.door43.org/Door43/en_tn/src/master/act/03/17.md)
* [Acts 07:35-37](https://git.door43.org/Door43/en_tn/src/master/act/07/35.md)
* [Luke 12:11-12](https://git.door43.org/Door43/en_tn/src/master/luk/12/11.md)
* [Luke 23:35](https://git.door43.org/Door43/en_tn/src/master/luk/23/35.md)
* [Mark 10:41-42](https://git.door43.org/Door43/en_tn/src/master/mrk/10/41.md)
* [Matthew 09:32-34](https://git.door43.org/Door43/en_tn/src/master/mat/09/32.md)
* [Matthew 20:25-28](https://git.door43.org/Door43/en_tn/src/master/mat/20/25.md)
* [Titus 03:1-2](https://git.door43.org/Door43/en_tn/src/master/tit/03/01.md)

#### Word Data:####

* Strong's: H995, H1166, H1167, H1404, H2708, H2710, H3027, H3548, H3920, H4043, H4410, H4427, H4428, H4438, H4467, H4474, H4475, H4623, H4910, H4941, H5057, H5065, H5387, H5401, H5461, H5715, H6113, H6213, H6485, H6957, H7101, H7218, H7287, H7300, H7336, H7786, H7860, H7980, H7981, H7985, H7989, H7990, H8199, H8269, H8323, H8451, G746, G752, G755, G757, G758, G932, G936, G1018, G1203, G1299, G1778, G1785, G1849, G2232, G2233, G2525, G2583, G2888, G2961, G3545, G3841, G4165, G4173, G4291


---

<a id="run"/>

### run, runs, runner, runners, running ###

#### Definition: ####

Literally the term "run" means "move very quickly on foot," usually at a greater speed than can be accomplished by walking.

This main meaning of "run" is also used in figurative expressions such as the following:
*     To "run in such a way as to win the prize"– refers to persevering in doing God's will with the same perseverance as running a race in order to win.
*     To "run in the path of your commands" – means to gladly and quickly obey God's commands.
*     To "run after other gods" means to persist in worshiping other gods.
*     "I run to you to hide me"  means to quickly turn to God for refuge and safety when faced with difficult things.
*     Water and other liquids such as tears, blood, sweat, and rivers are said to "run." This could also be translated as, "flow."
    The border of a country or region is said to "run along" a river or the border of a different country. This could be translated by saying that the country’s border "is next to" the river or other country or by saying that the country "borders" the river or other country."
*     Rivers and streams can "run dry," which means that they no longer have water in them. This could be translated as "have dried up" or "have become dry."
*     The days of a feast can "run their course," which means they "have passed by" or "are finished" or "are over."*

(See also: [false god](kt.html#falsegod), [persevere](#perseverance), [refuge](#refuge), [turn](#turn))

#### Bible References: ####

* [1 Corinthians 06:18](https://git.door43.org/Door43/en_tn/src/master/1co/06/18.md)
* [Galatians 02:1-2](https://git.door43.org/Door43/en_tn/src/master/gal/02/01.md)
* [Galatians 05:5-8](https://git.door43.org/Door43/en_tn/src/master/gal/05/05.md)
* [Philippians 02:14-16](https://git.door43.org/Door43/en_tn/src/master/php/02/14.md)
* [Proverbs 01:15-17](https://git.door43.org/Door43/en_tn/src/master/pro/01/15.md)

#### Word Data:####

* Strong's: H213, H386, H935, H1065, H1272, H1518, H1556, H1980, H2100, H2416, H3001, H3212, H3332, H3381, H3920, H3988, H4422, H4754, H4794, H4944, H5074, H5127, H5140, H5472, H5756, H6437, H6440, H6544, H6805, H7272, H7291, H7310, H7323, H7325, H7519, H7751, H8264, H8308, H8444, G413, G1377, G1601, G1530, G1532, G1632, G1998, G2027, G2701, G3729, G4063, G4370, G4390, G4890, G4936, G5143, G5240, G5295, G5302, G5343


---

<a id="sackcloth"/>

### sackcloth ###

#### Definition: ####

Sackcloth was a coarse, scratchy type of cloth that was made from goat hair or camel hair.

* A person who wore clothing made from it would be uncomfortable. Sackcloth was worn to show mourning, grief, or humble repentance.
* The phrase "sackcloth and ashes" was a common term referring to a traditional expression of grief and repentance.

#### Translation Suggestions:##

* This term could also be translated as "coarse cloth from animal hair" or "clothes made of goat hair" or "rough, scratchy clothing."
* Another way to translate this term could be "rough, scratchy mourning clothes."
* The phrase "sit in sackcloth and ashes" could be translated as "show mourning and humility by wearing scratchy cloth and sitting in ashes."


(See also: [How to Translate Unknowns](https://git.door43.org/Door43/en_ta/src/master/translate/translate-unknown.md))

(See also: [ash](#ash), [camel](#camel), [goat](#goat), [humble](kt.html#humble), [mourn](#mourn), [repent](kt.html#repent), [sign](kt.html#sign))

#### Bible References: ####

* [2 Samuel 03:31-32](https://git.door43.org/Door43/en_tn/src/master/2sa/03/31.md)
* [Genesis 37:34-36](https://git.door43.org/Door43/en_tn/src/master/gen/37/34.md)
* [Joel 01:8-10](https://git.door43.org/Door43/en_tn/src/master/jol/01/08.md)
* [Jonah 03:4-5](https://git.door43.org/Door43/en_tn/src/master/jon/03/04.md)
* [Luke 10:13-15](https://git.door43.org/Door43/en_tn/src/master/luk/10/13.md)
* [Matthew 11:20-22](https://git.door43.org/Door43/en_tn/src/master/mat/11/20.md)

#### Word Data:####

* Strong's: H8242, G4526


---

<a id="sacrifice"/>

### sacrifice, sacrifices, sacrificed, sacrificing, offering, offerings ###

#### Definition: ####

In the Bible, the terms "sacrifice" and "offering" refer to special gifts given to God as an act of worshiping him. People also offered sacrifices to false gods.

* The word "offering" generally refers to anything that is offered or given. The term "sacrifice" refers to something that is given or done at great cost to the giver.
* Offerings to God were specific things that he commanded the Israelites to give in order to express devotion and obedience to him.
* The names of the different offerings, such as "burnt offering" and "peace offering," indicated what kind of offering was being given.
* Sacrifices to God often involved the killing of an animal.
* Only the sacrifice of Jesus, God's perfect, sinless Son, can completely cleanse people from sin animal sacrifices could never do that.
* The figurative expression "offer yourselves as a living sacrifice" means, "live your life in complete obedience to God, giving up everything in order to serve him."

#### Translation Suggestions ####

* The term "offering" could also be translated as "a gift to God" or "something given to God" or "something valuable that is presented to God."
* Depending on the context, the term "sacrifice" could also be translated as "something valuable given in worship" or "a special animal killed and presented to God."
* The action to "sacrifice" could be translated as to "give up something valuable" or to "kill an animal and give it to God."
* Another way to translate "present yourself as a living sacrifice" could be "as you live your life, offer yourself to God as completely as an animal is offered on an altar."


(See also: [altar](kt.html#altar), [burnt offering](#burntoffering), [drink offering](#drinkoffering), [false god](kt.html#falsegod), [fellowship offering](#fellowshipoffering), [freewill offering](#freewilloffering) [peace offering](#peaceoffering), [priest](kt.html#priest), [sin offering](#sinoffering), [worship](kt.html#worship))

#### Bible References: ####

* [2 Timothy 04:6-8](https://git.door43.org/Door43/en_tn/src/master/2ti/04/06.md)
* [Acts 07:41-42](https://git.door43.org/Door43/en_tn/src/master/act/07/41.md)
* [Acts 21:25-26](https://git.door43.org/Door43/en_tn/src/master/act/21/25.md)
* [Genesis 04:3-5](https://git.door43.org/Door43/en_tn/src/master/gen/04/03.md)
* [James 02:21-24](https://git.door43.org/Door43/en_tn/src/master/jas/02/21.md)
* [Mark 01:43-44](https://git.door43.org/Door43/en_tn/src/master/mrk/01/43.md)
* [Mark 14:12-14](https://git.door43.org/Door43/en_tn/src/master/mrk/14/12.md)
* [Matthew 05:23-24](https://git.door43.org/Door43/en_tn/src/master/mat/05/23.md)

#### Examples from the Bible stories: ####

* __[03:14](https://git.door43.org/Door43/en_tn/src/master/obs/03/14.md)__ After Noah got off the boat, he built an altar and __sacrificed__  some of each kind of animal which could be used for a __sacrifice__. God was happy with the __sacrifice__  and blessed Noah and his family.
* __[05:06](https://git.door43.org/Door43/en_tn/src/master/obs/05/06.md)__ "Take Isaac, your only son, and kill him as a __sacrifice__  to me." Again Abraham obeyed God and prepared to __sacrifice__  his son.
* __[05:09](https://git.door43.org/Door43/en_tn/src/master/obs/05/09.md)__ God had provided the ram to be the __sacrifice__  instead of Isaac.
* __[13:09](https://git.door43.org/Door43/en_tn/src/master/obs/13/09.md)__ Anyone who disobeyed God's law could bring an animal to the Tent of Meeting as a __sacrifice__  to God. A priest would kill the animal and burn it on the altar. The blood of the animal that was __sacrificed__  covered the person's sin and made that person clean in God's sight.
* __[17:06](https://git.door43.org/Door43/en_tn/src/master/obs/17/06.md)__ David wanted to build a temple where all the Israelites could worship God and offer him __sacrifices__.
* __[48:06](https://git.door43.org/Door43/en_tn/src/master/obs/48/06.md)__ Jesus is the Great High Priest. Unlike other priests, he offered himself as the only __sacrifice__  that could to take away the sin of all the people in the world.
* __[48:08](https://git.door43.org/Door43/en_tn/src/master/obs/48/08.md)__ But God provided Jesus, the Lamb of God, as a __sacrifice__  to die in our place.
* __[49:11](https://git.door43.org/Door43/en_tn/src/master/obs/49/11.md)__ Because Jesus __sacrificed__  himself, God can forgive any sin, even terrible sins.

#### Word Data:####

* Strong's: H801, H817, H819, H1685, H1890, H1974, H2076, H2077, H2281, H2282, H2398, H2401, H2402, H2403, H2409, H3632, H4394, H4469, H4503, H4504, H5066, H5068, H5069, H5071, H5257, H5258, H5261, H5262, H5927, H5928, H5930, H6453, H6944, H6999, H7133, H7311, H8002, H8426, H8548, H8573, H8641, G266, G334, G1049, G1435, G1494, G2378, G2380, G3646, G4376, G5485


---

<a id="sandal"/>

### sandal, sandals ###

#### Definition: ####

A sandal is a simple flat-soled shoe held onto the foot by straps that go around the foot or ankle. Sandals are worn by both men and women.

* A sandal was sometimes used to confirm a legal transaction, such as the selling of property: one man would take off a sandal and give it to the other.
* Removing one's shoes or sandals was also a sign of respect and reverence, especially in God's presence.
* John said that he was not worthy to even untie Jesus' sandals, which would have been the task of a lowly servant or slave.

#### Bible References: ####

* [Acts 07:33-34](https://git.door43.org/Door43/en_tn/src/master/act/07/33.md)
* [Deuteronomy 25:9-10](https://git.door43.org/Door43/en_tn/src/master/deu/25/09.md)
* [John 01:26-28](https://git.door43.org/Door43/en_tn/src/master/jhn/01/26.md)
* [Joshua 05:14-15](https://git.door43.org/Door43/en_tn/src/master/jos/05/14.md)
* [Mark 06:7-9](https://git.door43.org/Door43/en_tn/src/master/mrk/06/07.md)

#### Word Data:####

* Strong's: H5274, H5275, H8288, G4547, G5266


---

<a id="scepter"/>

### scepter, scepters ###

#### Definition: ####

The term "scepter" refers to an ornamental rod or staff held by a ruler, such as a king.

* Scepters were originally a branch of wood with carved decorations. Later scepters were also made of precious metals such as gold.
* The scepter was a symbol of royalty and authority and also symbolized the honor and dignity associated with a king.
* In the Old Testament, God was described as having a scepter of righteousness because God rules as king over his people.
* An Old Testament prophecy referred to the Messiah as a symbolic scepter that would come from Israel to rule over all nations.
* This could also be translated as "ruling rod" or "king's rod.

(See also: [authority](kt.html#authority), [Christ](kt.html#christ), [king](#king), [righteous](kt.html#righteous))

#### Bible References: ####

* [Amos 01:5](https://git.door43.org/Door43/en_tn/src/master/amo/01/05.md)
* [Esther 04:9-12](https://git.door43.org/Door43/en_tn/src/master/est/04/09.md)
* [Genesis 49:10](https://git.door43.org/Door43/en_tn/src/master/gen/49/10.md)
* [Hebrews 01:8-9](https://git.door43.org/Door43/en_tn/src/master/heb/01/08.md)
* [Numbers 21:17-18](https://git.door43.org/Door43/en_tn/src/master/num/21/17.md)
* [Psalms 045:5-7](https://git.door43.org/Door43/en_tn/src/master/psa/045/005.md)

#### Word Data:####

* Strong's: H2710, H4294, H7626, H8275, G4464


---

<a id="scroll"/>

### scroll, scrolls ###

#### Definition: ####

In ancient times, a scroll was a type of book made of one long, rolled-up sheet of papyrus or leather.

* After writing on a scroll or reading from it, people rolled it up by using the rods attached to its ends.
* Scrolls were used for legal documents and scripture.
* Sometimes scrolls that were delivered by a messenger were sealed with wax. If the wax was still present when the scroll was received, then the receiver knew that no one had opened the scroll to read it or write on it since it had been sealed.
* Scrolls containing the Hebrew Scriptures were read aloud in the synagogues.

(See also: [seal](#seal), [synagogue](kt.html#synagogue), [word of God](kt.html#wordofgod))

#### Bible References: ####

* [Jeremiah 29:1-3](https://git.door43.org/Door43/en_tn/src/master/jer/29/01.md)
* [Luke 04:16-17](https://git.door43.org/Door43/en_tn/src/master/luk/04/16.md)
* [Numbers 21:14-15](https://git.door43.org/Door43/en_tn/src/master/num/21/14.md)
* [Revelation 05:1-2](https://git.door43.org/Door43/en_tn/src/master/rev/05/01.md)

#### Word Data:####

* Strong's: H4039, H4040, H5612, G974, G975


---

<a id="seacow"/>

### sea cow ###

#### Definition: ####

The term "sea cow" refers to a large sea animal that eats sea grass and other vegetation on the ocean floor.

* A sea cow is grey with thick skin. It moves in the water by using its flippers.
* The skins or hides of the sea cow were used by people in Bible times for making tents. These animal hides were also used in the coverings for the tabernacle.
* It was nicknamed "sea cow" because it eats grass like a cow, but it is not similar to a cow in other ways.
* Related animals are the "dugong" and the "manatee."

(See also: [How to Translate Unknowns](https://git.door43.org/Door43/en_ta/src/master/translate/translate-unknown.md))

(See also: [tabernacle](kt.html#tabernacle))

#### Bible References: ####

* [Numbers 04:5-6](https://git.door43.org/Door43/en_tn/src/master/num/04/05.md)
* [Numbers 04:12-14](https://git.door43.org/Door43/en_tn/src/master/num/04/12.md)
* [Numbers 04:24-26](https://git.door43.org/Door43/en_tn/src/master/num/04/24.md)

The person who received the scroll would see the unbroken seal and know that no one had opened it.

#### Word Data:####

* Strong's: H8476


---

<a id="seal"/>

### seal, seals, sealed, sealing, unsealed ###

#### Definition: ####

To seal an object means to keep it closed with something that makes it impossible to open without breaking the seal.

* Often a seal is marked with a design to show who it belongs to. 
* Melted wax was used to seal letters or other documents that needed to be protected. When the wax cooled and hardened, the letter could not be opened without breaking the wax seal.
* A seal was put on the stone in front of Jesus' grave in order to keep anyone from moving the stone.
* Paul figuratively refers to the Holy Spirit as a "seal" showing that our salvation is secure.

(See also: [Holy Spirit](kt.html#holyspirit), [tomb](#tomb))

#### Bible References: ####

* [Exodus 02:3-4](https://git.door43.org/Door43/en_tn/src/master/exo/02/03.md)
* [Isaiah 29:11-12](https://git.door43.org/Door43/en_tn/src/master/isa/29/11.md)
* [John 06:26-27](https://git.door43.org/Door43/en_tn/src/master/jhn/06/26.md)
* [Matthew 27:65-66](https://git.door43.org/Door43/en_tn/src/master/mat/27/65.md)
* [Revelation 05:1-2](https://git.door43.org/Door43/en_tn/src/master/rev/05/01.md)

#### Word Data:####

* Strong's: H2368, H2560, H2856, H2857, H2858, H5640, G2696, G4972, G4973


---

<a id="seed"/>

### seed, semen ###

#### Definition: ####

A seed is the part of a plant that gets planted in the ground to reproduce more of the same kind of plant. It also has several figurative meanings.

* The term "seed" is used figuratively and euphemistically to refer to the tiny cells inside a man that combine with cells of a woman to cause a baby to grow inside her. A collection of these  is called semen.
* Related to this, "seed" is also used to refer to a person's offspring or descendants.
* This word often has a plural meaning, referring to more than one seed grain or more than one descendant.
* In the parable of the farmer planting seeds, Jesus compared his seeds to the Word of God, which is planted in people's hearts in order to produce good spiritual fruit.
* The apostle Paul also uses the term "seed" to refer to the Word of God.

#### Translation Suggestions: ####

* For a literal seed, it is best to use the literal term for "seed" that is used in the target language for what a farmer plants in his field.
* The literal term should also be used in contexts where it refers figuratively to God's Word.
* For the figurative use that refers to people who are of the same family line, it may be more clear to use the word "descendant" or "descendants" instead of seed. Some languages may have a word that means "children and grandchildren."
* For a man or woman's "seed," consider how the target expresses this in a way that will not offend or embarrass people.  (See: [euphemism](https://git.door43.org/Door43/en_ta/src/master/translate/figs-euphemism.md))

(See also: [descendant](#descendant), [offspring](#offspring))

#### Bible References: ####

* [1 Kings 18:30-32](https://git.door43.org/Door43/en_tn/src/master/1ki/18/30.md)
* [Genesis 01:11-13](https://git.door43.org/Door43/en_tn/src/master/gen/01/11.md)
* [Jeremiah 02:20-22](https://git.door43.org/Door43/en_tn/src/master/jer/02/20.md)
* [Matthew 13:7-9](https://git.door43.org/Door43/en_tn/src/master/mat/13/07.md)

#### Word Data:####

* Strong's: H2232, H2233, H2234, H3610, H6507, G4615, G4687, G4690, G4701, G4703


---

<a id="seek"/>

### seek, seeks, seeking, sought ###

#### Definition: ####

The term "seek" means to look for something or someone. The past tense is "sought." It can also mean "try hard" or "make an effort" to do something.

* To "seek" or "look for" an opportunity to do something can mean  to "try to find a time" to do it.
* To "seek Yahweh" means to "spend time and energy getting to know Yahweh and learning to obey him."
* To "seek protection" means to "try to find a person or place that will protect you from danger."
* To "seek justice" means to "make an effort to see that people are treated justly or fairly."
* To "seek the truth" means to "make an effort to find out what the truth is."
* To "seek favor" means to "try to get favor" or to "do things to cause someone to help you."

(See also: [just](kt.html#justice), [true](kt.html#true))

#### Bible References: ####

* [1 Chronicles 10:13-14](https://git.door43.org/Door43/en_tn/src/master/1ch/10/13.md)
* [Acts 17:26-27](https://git.door43.org/Door43/en_tn/src/master/act/17/26.md)
* [Hebrews 11:5-6](https://git.door43.org/Door43/en_tn/src/master/heb/11/05.md)
* [Luke 11:9-10](https://git.door43.org/Door43/en_tn/src/master/luk/11/09.md)
* [Psalms 027:7-8](https://git.door43.org/Door43/en_tn/src/master/psa/027/007.md)

#### Word Data:####

* Strong's: H579, H1156, H1239, H1243, H1245, H1556, H1875, H2470, H2603, H2658, H2664, H2713, H3289, H7125, H7592, H7836, H8446, G327, G1567, G1934, G2052, G2212


---

<a id="seize"/>

### seize, seizes, seized, seizure ###

#### Definition: ####

The term "seize" means to take or capture someone or something by force. It can also mean to overpower and control someone.

* When a city was taken by means of military force, the soldiers would seize the valuable property of the people they had conquered.
* When used figuratively, a person can be described as being "seized with fear." This means that the person was suddenly "overcome by fear." If a person was "seized with fear" it  could also be stated that the person "suddenly became very afraid."
* In the context of labor pains that "seize" a woman, the meaning is that the pains are sudden and overpowering. This could be translated by saying that the pains "overcome" or "suddenly come upon" the woman.
* This term could also be translated as "take control of" or "suddenly take" or "grab."
* The expression "seized and slept with her" could be translated as "forced himself on her" or "violated her" or "raped her." Make sure the translation of this concept is acceptable. 

(See: [euphemism](https://git.door43.org/Door43/en_ta/src/master/translate/figs-euphemism.md))

#### Bible References: ####

* [Acts 16:19-21](https://git.door43.org/Door43/en_tn/src/master/act/16/19.md)
* [Exodus 15:14-15](https://git.door43.org/Door43/en_tn/src/master/exo/15/14.md)
* [John 10:37-39](https://git.door43.org/Door43/en_tn/src/master/jhn/10/37.md)
* [Luke 08:28-29](https://git.door43.org/Door43/en_tn/src/master/luk/08/28.md)
* [Matthew 26:47-48](https://git.door43.org/Door43/en_tn/src/master/mat/26/47.md)

#### Word Data:####

* Strong's: H270, H1497, H2388, H3027, H3920, H3947, H4672, H5377, H5860, H6031, H7760, H8610, G724, G1949, G2638, G2902, G2983, G4815, G4884


---

<a id="selah"/>

### selah ###

#### Definition: ####

The term "selah" is a Hebrew word that occurs mostly in the book of Psalms. It has several possible meanings.

* It could mean "pause and praise," which would invite the audience to think carefully about what was just said.
* Since many of the Psalms were written as songs, it is thought that "selah" may have been a musical term to instruct the singer to pause in his singing to allow for the musical instruments to play alone or to encourage listeners to think about the words of the song.

(See also: [psalm](kt.html#psalm))

#### Bible References: ####

* [Psalm 003:3-4](https://git.door43.org/Door43/en_tn/src/master/psa/003/003.md)
* [Psalm 024:5-6](https://git.door43.org/Door43/en_tn/src/master/psa/024/005.md)
* [Psalms 046:6-7](https://git.door43.org/Door43/en_tn/src/master/psa/046/006.md)

#### Word Data:####

* Strong's: H5542


---

<a id="selfcontrol"/>

### self-control, self-controlled, controlled self ###

#### Definition: ####

Self-control is the ability to control one's behavior in order to avoid sinning.

* It refers to good behavior, that is, avoiding sinful thoughts, speech, and actions.
* Self-control is a fruit or characteristic that the Holy Spirit gives to Christians.
* A person who is using self-control is able to stop himself from doing something wrong that he may want to do. God is the one who enables a person to have self-control.

(See also: [fruit](#fruit), [Holy Spirit](kt.html#holyspirit))

#### Bible References: ####

* [1 Corinthians 07:8-9](https://git.door43.org/Door43/en_tn/src/master/1co/07/08.md)
* [2 Peter 01:5-7](https://git.door43.org/Door43/en_tn/src/master/2pe/01/05.md)
* [2 Timothy 03:1-4](https://git.door43.org/Door43/en_tn/src/master/2ti/03/01.md)
* [Galatians 05:22-24](https://git.door43.org/Door43/en_tn/src/master/gal/05/22.md)

#### Word Data:####

* Strong's: H4623, H7307, G192, G193, G1466, G1467, G1468, G4997


---

<a id="send"/>

### send, sends, sent, sending, send out, sends out, sent out, sending out ###

#### Definition: ####

To "send" is to cause someone or something to go somewhere. To "send out" someone is to tell that person to go on an errand or a mission.

* Often a person who is "sent out" has been appointed to do a specific task.
* Phrases like "send rain" or "send disaster" mean to "cause…to come." This type of expression is usually used in reference to God causing these things to happen.
* The term "send" is also used in expressions such as to "send word" or to "send a message," which means to give someone a message to tell someone else.
* To "send" someone "with" something can mean to "give" that thing "to" someone else, usually moving it some distance in order for the person to receive it.
* Jesus frequently used the phrase "the one who sent me" to refer to God the Father, who "sent" him to earth to redeem and save people. This could also be translated as "the one who commis

(See also: [appoint](kt.html#appoint), [redeem](kt.html#redeem))

#### Bible References: ####

* [Acts 07:33-34](https://git.door43.org/Door43/en_tn/src/master/act/07/33.md)
* [Acts 08:14-17](https://git.door43.org/Door43/en_tn/src/master/act/08/14.md)
* [John 20:21-23](https://git.door43.org/Door43/en_tn/src/master/jhn/20/21.md)
* [Matthew 09:37-38](https://git.door43.org/Door43/en_tn/src/master/mat/09/37.md)
* [Matthew 10:5-7](https://git.door43.org/Door43/en_tn/src/master/mat/10/05.md)
* [Matthew 10:40-41](https://git.door43.org/Door43/en_tn/src/master/mat/10/40.md)
* [Matthew 21:1-3](https://git.door43.org/Door43/en_tn/src/master/mat/21/01.md)

#### Word Data:####

* Strong's: H935, H1540, H1980, H2199, H2904, H3318, H3474, H3947, H4916, H4917, H5042, H5130, H5375, H5414, H5674, H6963, H7368, H7725, H7964, H7971, H7972, H7993, H8421, H8446, G782, G375, G630, G649, G652, G657, G1026, G1032, G1544, G1599, G1821, G3333, G3343, G3936, G3992, G4311, G4341, G4369, G4842, G4882


---

<a id="serpent"/>

### serpent, serpents, snake, snakes, viper, vipers ###

#### Facts: ####

These terms all refer to a kind of reptile that has a long, thin body and large, fanged jaws, and that moves by slithering back and forth across the ground. The term "serpent" usually refers to a large snake and "viper" refers to a type of snake that has venom which it uses to poison its prey.

* This animal is also used figuratively to refer to a person who is evil, especially someone who is deceitful.
* Jesus called the religious leaders "offspring of vipers" because they pretended to be righteous but deceived people and treated them unfairly.
* In the garden of Eden, Satan took the form of a serpent when he talked to Eve and tempted her to disobey God.
* After the serpent tempted Eve to sin, and both Eve and her husband Adam did sin, God cursed the snake, saying that from then on, all snakes would slither along the ground, implying that before then they had had legs.

(Translation suggestions:  [How to Translate Names](https://git.door43.org/Door43/en_ta/src/master/translate/translate-names.md))

(See also: [curse](kt.html#curse), [deceive](#deceive), [disobey](#disobey), [Eden](names.html#eden), [evil](kt.html#evil), [offspring](#offspring), [prey](#prey), [Satan](kt.html#satan), [sin](kt.html#sin), [tempt](kt.html#tempt))

#### Bible References: ####

* [Genesis 03:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/03/01.md)
* [Genesis 03:4-6](https://git.door43.org/Door43/en_tn/src/master/gen/03/04.md)
* [Genesis 03:12-13](https://git.door43.org/Door43/en_tn/src/master/gen/03/12.md)
* [Mark 16:17-18](https://git.door43.org/Door43/en_tn/src/master/mrk/16/17.md)
* [Matthew 03:7-9](https://git.door43.org/Door43/en_tn/src/master/mat/03/07.md)
* [Matthew 23:32-33](https://git.door43.org/Door43/en_tn/src/master/mat/23/32.md)

#### Word Data:####

* Strong's: H660, H2119, H5175, H6620, H6848, H8314, H8577, G2191, G2062, G3789


---

<a id="servant"/>

### enslave, enslaves, enslaved, servant, servants, slave, slaves, slaved, slavery, maidservants, serve ###

#### Definition: ####

The word for "servant" can also mean "slave" and refers to a person who works for another person, either by choice or by force. The surrounding text usually makes it clear whether a person is a servant or a slave.
The word for "serve" means to do things to help other people. It can also mean to "worship."
serve, serves, served, serving, service, services, eyeservice

Servant: * In Bible times, there was less of a difference between a servant and a slave than there is today. Both servants and slaves were an important part of their master's household and many were treated almost like members of the family. Sometimes a servant would choose to become a lifetime servant to his master.
* A slave was a kind of servant who was the property of the person he worked for. The person who bought a slave was called his "owner" or "master." Some masters treated their slaves very cruelly, while other masters treated their slaves very well, as a servant who was a valued member of the household.
* In ancient times, some people willingly became slaves to a person they owed money to in order to pay off their debt to that person.
* In the Bible, the phrase "I am your servant" was used as a sign of respect and service to a person of higher rank, such as a king. It did not mean that the person speaking was an actual servant.
* In the Old Testament, God's prophets and other people who worshiped God were often referred to as his "servants."
* In the New Testament, people who obeyed God through faith in Christ were often called his "servants."
* Christians are also called "slaves to righteousness," which is a metaphor that compares the commitment to obey God to a slave's commitment to obey his master. 

Servant (See: [Metaphor](https://git.door43.org/Door43/en_ta/src/master/translate/figs-metaphor.md))

Serve (See also: [commit](#commit), [enslave](#enslave), [household](#household), [lord](kt.html#lord), [obey](#obey), [righteous](kt.html#righteous), [serve](#serve))


Serve: In the context of a person serving guests, this term means "care for" or "serve food to" or "provide food for."
When Jesus told the disciples to "serve" the fish to the people, this could be translated as, "distribute" or "hand out" or "give."
The term "service" refers to the act of serving. It can also be used to refer to a "meeting" of Christians as they worship God together.
The term "serve" can also be translated as "minister to" or "work for" or "take care of" or "obey," depending on the context.
To "serve God" can be translated as to "worship and obey God" or to "do the work that God has commanded."
To "serve tables" means to bring food to people who are sitting at tables, or more generally, to "distribute food."
People who teach others about God are said to serve both God and the ones they are teaching.
The apostle Paul wrote to the Corinthian Christians about how they used to "serve" the old covenant. This refers to obeying the laws of Moses.
Now they "serve" the new covenant. That is, because of Jesus' sacrifice on the cross, believers in Jesus are enabled by the Holy Spirit to please God and live holy lives.
Paul talks about their actions in terms of their "service" to either the old or new covenant. This could be translated as "serving" or "obeying" or "devotion to."
(See also: covenant, law, servant)

#### Bible References for "servant": ####

* [Acts 04:29-31](https://git.door43.org/Door43/en_tn/src/master/act/04/29.md)
* [Acts 10:7-8](https://git.door43.org/Door43/en_tn/src/master/act/10/07.md)
* [Colossians 01:7-8](https://git.door43.org/Door43/en_tn/src/master/col/01/07.md)
* [Colossians 03:22-25](https://git.door43.org/Door43/en_tn/src/master/col/03/22.md)
* [Genesis 21:10-11](https://git.door43.org/Door43/en_tn/src/master/gen/21/10.md)
* [Luke 12:47-48](https://git.door43.org/Door43/en_tn/src/master/luk/12/47.md)
* [Mark 09:33-35](https://git.door43.org/Door43/en_tn/src/master/mrk/09/33.md)
* [Matthew 10:24-25](https://git.door43.org/Door43/en_tn/src/master/mat/10/24.md)
* [Matthew 13:27-28](https://git.door43.org/Door43/en_tn/src/master/mat/13/27.md)

Bible References for "serve":

2 Timothy 02:3-5
Acts 06:2-4
Genesis 25:23
Luke 04:8
Luke 12:37-38
Luke 22:26-27
Mark 08:7-10
Matthew 04:10-11
Matthew 06:22-24

#### Examples from the Bible stories: ####

  __*[06:01](https://git.door43.org/Door43/en_tn/src/master/obs/06/01.md)__ When Abraham was very old and his son, Isaac, had grown to be a man, Abraham sent one of his __servants__ back to the land where his relatives lived to find a wife for his son, Isaac.
  __*[08:04](https://git.door43.org/Door43/en_tn/src/master/obs/08/04.md)__ The __slave__ traders sold Joseph as a __slave__ to a wealthy government official.
  __*[09:13](https://git.door43.org/Door43/en_tn/src/master/obs/09/13.md)__ "I (God) will send you (Moses) to Pharaoh so that you can bring the Israelites out of their __slavery__ in Egypt."
  __*[19:10](https://git.door43.org/Door43/en_tn/src/master/obs/19/10.md)__ Then Elijah prayed, "O Yahweh, God of Abraham, Isaac, and Jacob, show us today that you are the God of Israel and that I am your __servant__."
  __*[29:03](https://git.door43.org/Door43/en_tn/src/master/obs/29/03.md)__ "Since the __servant__ could not pay the debt, the king said, 'Sell this man and his family as __slaves__ to make payment on his debt.'"
  __*[35:06](https://git.door43.org/Door43/en_tn/src/master/obs/35/06.md)__ "All my father's __servants__ have plenty to eat, and yet here I am starving."
  __*[47:04](https://git.door43.org/Door43/en_tn/src/master/obs/47/04.md)__ The __slave__ girl kept yelling as they walked, "These men are servants of the Most High God. 
  __*[50:04](https://git.door43.org/Door43/en_tn/src/master/obs/50/04.md)__ Jesus also said, "A __servant__ is not greater than his master."

#### Word Data:####

* (Servant) Strong's: H5288, H5647, H5649, H5650, H5657, H7916, H8198, H8334, G1249, G1401, G1402, G2324, G3407, G3411, G3610, G3816, G4983, G5257
* (Serve) H327, H3547, H4929, H4931, H5647, H5656, H5673, H5975, H6399, H6402, H6440, H6633, H6635, H7272, H8104, H8120, H8199, H8278, H8334, G1247, G1248, G1398, G1402, G1438, G1983, G2064, G2212, G2323, G2999, G3000, G3009, G4337, G4342, G4754, G5087, G5256


---

<a id="sex"/>

### had relations with, lovemaking, sleep with, sleeps with, slept with, sleeping with ###

#### Definition: ####

In the Bible, these terms are euphemisms that refer to having sexual intercourse. (See: [Euphemism](https://git.door43.org/Door43/en_ta/src/master/translate/figs-euphemism.md))

* The expression "sleep with" someone commonly refers to having sexual relations with that person. The past tense is "slept with."
* In the Old Testament book "Song of Solomon," the ULB uses the term "lovemaking" to translate the word "love," which in that context refers to sexual relations. This term is related to the expression "make love to."

#### Translation Suggestions: ####

* Some languages may use different expressions for these terms in different contexts, depending on whether whether those involved are a married couple or whether they have some other relationship. It is important to make sure that the translation of this term has the correct meaning in each context.
* Depending on the context, expressions like these could be used to translate "sleep with": "lie with" or "make love to" or "be intimate with."
* Other ways to translate "have relations with" could include "have sexual relations with" or "have marital relations with."
* The term "lovemaking" could also be translated as "loving" or "intimacy." Or there may be an expression that is a natural way to translate this in the project language.
* It is important to check that the terms used to translate this concept are acceptable to the people who will be using the Bible translation.

(See also: [sexual immorality](#fornication))

#### Bible References: ####

* [1 Corinthians 05:1-2](https://git.door43.org/Door43/en_tn/src/master/1co/05/01.md)
* [1 Samuel 01:19-20](https://git.door43.org/Door43/en_tn/src/master/1sa/01/19.md)
* [Deuteronomy 21:13-14](https://git.door43.org/Door43/en_tn/src/master/deu/21/13.md)
* [Genesis 19:4-5](https://git.door43.org/Door43/en_tn/src/master/gen/19/04.md)
* [Matthew 01:24-25](https://git.door43.org/Door43/en_tn/src/master/mat/01/24.md)

#### Word Data:####

* Strong's: H160, H935, H1540, H2181, H2233, H3045, H3212, H6172, H7250, H7901, H7903, G1097


---

<a id="shadow"/>

### shadow, shadows, overshadow, overshadowed ###

#### Definition: ####

The word "shadow" literally refers to the darkness that is caused by an object blocking the light. It also has several figurative meanings.

* The "shadow of death" means that death is present or near, just as a shadow indicates the presence of its object.
* Many times in the Bible, the life of a human being is compared to a shadow, which does not last very long and has no substance.
* Sometimes "shadow" is used as another word for "darkness."
* The Bible talks about being hidden or protected in the shadow of God's wings or hands. This is a picture of being protected and hidden from danger. Other ways to translate "shadow" in these contexts could include "shade" or "safety" or "protection."
* It is best to translate "shadow" literally using the local term that is used to refer to an actual shadow.

(See also: [darkness](#darkness), [light](#light))

#### Bible References: ####

* [2 Kings 20:8-9](https://git.door43.org/Door43/en_tn/src/master/2ki/20/08.md)
* [Genesis 19:6-8](https://git.door43.org/Door43/en_tn/src/master/gen/19/06.md)
* [Isaiah 30:1-2](https://git.door43.org/Door43/en_tn/src/master/isa/30/01.md)
* [Jeremiah 06:4-5](https://git.door43.org/Door43/en_tn/src/master/jer/06/04.md)
* [Psalms 017:8-10](https://git.door43.org/Door43/en_tn/src/master/psa/017/008.md)

#### Word Data:####

* Strong's: H2927, H6738, H6751, H6752, H6754, H6757, H6767, G644, G1982, G2683, G4639


---

<a id="shame"/>

###  shame, shames, shamed, shameful, shamefully, shameless, shamelessly, ashamed, unashamed ###

#### Definition: ####

The term "shame" refers to a painful feeling of being disgraced a person has because of something dishonorable or improper that he or someone else has done.

* Something that is "shameful" is "improper" or "dishonorable."
* The term "ashamed" describes how a person feels when he has done something shameful.
* The phrase "put to shame" means to defeat people or expose their sin so that they feel ashamed of themselves.
* The prophet Isaiah said that those who make and worship idols will be put to shame.
* God can bring shame to a person who does not repent by exposing that person's sin and causing him to be humiliated.

(See also: [false god](kt.html#falsegod), [humble](kt.html#humble), [humiliate](#humiliate), [Isaiah](names.html#isaiah), [repent](kt.html#repent), [sin](kt.html#sin), [worship](kt.html#worship)) 

#### Bible References: ####

* [1 Peter 03:15-17](https://git.door43.org/Door43/en_tn/src/master/1pe/03/15.md)
* [2 Kings 02:17-18](https://git.door43.org/Door43/en_tn/src/master/2ki/02/17.md)
* [2 Samuel 13:13-14](https://git.door43.org/Door43/en_tn/src/master/2sa/13/13.md)
* [Luke 20:11-12](https://git.door43.org/Door43/en_tn/src/master/luk/20/11.md)
* [Mark 08:38](https://git.door43.org/Door43/en_tn/src/master/mrk/08/38.md)
* [Mark 12:4-5](https://git.door43.org/Door43/en_tn/src/master/mrk/12/04.md)

#### Word Data:####

* Strong's: H937, H954, H955, H1317, H1322, H2616, H2659, H2781, H3001, H3637, H3639, H3640, H6172, H7022, H7036, H8103, H8106, G127, G149, G152, G153, G422, G808, G818, G819, G821, G1788, G1791, G1870, G2617, G3856, G5195


---

<a id="sheep"/>

### ewe, ewes, ram, rams, sheep, sheepfold, sheepfolds, sheepshearers, sheepskins ###

#### Definition: ####

A "sheep" is a medium-sized animal with four legs that has wool all over its body. A male sheep is called a "ram." A female sheep is called a "ewe." The plural of "sheep" is also "sheep."

* A baby sheep is called a "lamb."
* The Israelites often used sheep for sacrifices, especially male sheep and young sheep.
* People eat meat from sheep and use their wool to make clothing and other things.
* Sheep are very trusting, weak, and timid. They are easily influenced to wander away. They need a shepherd to lead them, protect them, and provide them with food, water, and shelter.
* In the Bible, people are compared to sheep who have God as their shepherd.

(Translation suggestions: [How to Translate Unknowns](https://git.door43.org/Door43/en_ta/src/master/translate/translate-unknown.md))

(See also: [Israel](kt.html#israel), [lamb](kt.html#lamb), [sacrifice](#sacrifice), [shepherd](#shepherd))

#### Bible References: ####

* [Acts 08:32-33](https://git.door43.org/Door43/en_tn/src/master/act/08/32.md)
* [Genesis 30:31-32](https://git.door43.org/Door43/en_tn/src/master/gen/30/31.md)
* [John 02:13-14](https://git.door43.org/Door43/en_tn/src/master/jhn/02/13.md)
* [Luke 15:3-5](https://git.door43.org/Door43/en_tn/src/master/luk/15/03.md)
* [Mark 06:33-34](https://git.door43.org/Door43/en_tn/src/master/mrk/06/33.md)
* [Matthew 09:35-36](https://git.door43.org/Door43/en_tn/src/master/mat/09/35.md)
* [Matthew 10:5-7](https://git.door43.org/Door43/en_tn/src/master/mat/10/05.md)
* [Matthew 12:11-12](https://git.door43.org/Door43/en_tn/src/master/mat/12/11.md)
* [Matthew 25:31-33](https://git.door43.org/Door43/en_tn/src/master/mat/25/31.md)

#### Examples from the Bible stories: ####

* __[09:12](https://git.door43.org/Door43/en_tn/src/master/obs/09/12.md)__ One day while Moses was taking care of his __sheep__, he saw a bush that was on fire.
* __[17:02](https://git.door43.org/Door43/en_tn/src/master/obs/17/02.md)__ David was a shepherd from the town of Bethlehem. At different times while he was watching his father's __sheep__, David had killed both a lion and a bear that had attacked the __sheep__.
* __[30:03](https://git.door43.org/Door43/en_tn/src/master/obs/30/03.md)__ To Jesus, these people were like __sheep__  without a shepherd.
* __[38:08](https://git.door43.org/Door43/en_tn/src/master/obs/38/08.md)__ Jesus said, "All of you will all abandon me tonight. It is written, 'I will strike the shepherd and all the __sheep__  will be scattered.'"

#### Word Data:####

* Strong's: H352, H1494, H1798, H2169, H3104, H3532, H3535, H3733, H3775, H5739, H5763, H6260, H6629, H6792, H7353, H7462, H7716, G4165, G4262, G4263


---

<a id="shepherd"/>

### shepherd, shepherds, shepherded, shepherding ###

#### Definition: ####

A shepherd is a person who takes care of sheep. The verb to "shepherd" means to protect the sheep and provide them with food and water.
Shepherds watch over the sheep, leading them to places with good food and water. Shepherds also keep the sheep from getting lost and protect them from wild animals.

* This term is often used metaphorically in the Bible to refer to taking care of people's spiritual needs. This includes teaching them what God has told them in the Bible and guiding them in the way they should live.
* In the Old Testament, God was called the "shepherd" of his people because he took care of all their needs and protected them. He also led and guided them. (See: [Metaphor](https://git.door43.org/Door43/en_ta/src/master/translate/figs-metaphor.md))
* Moses was a shepherd for the Israelites as he guided them spiritually in their worship of Yahweh and led them physically on their journey to the land of Canaan.
* In the New Testament, Jesus called himself the "good shepherd." The apostle Paul also referred to him as the "great shepherd" over the Church.
* Also, in the New Testament, the term "shepherd" was used to refer to a person who was a spiritual leader over other believers. The word translated as "pastor" is the same word that is translated as "shepherd." The elders and overseers were also called shepherds.


#### Translation Suggestions ####

* When used literally, the action "shepherd" could be translated as "take care of sheep" or "watch over sheep."
* The person "shepherd" could be translated as "person who takes care of sheep" or "sheep tender" or "sheep caregiver."
* When used as a metaphor, different ways to translate this term could include "spiritual shepherd" or "spiritual leader" or "one who is like a shepherd" or "one who cares for his people like a shepherd cares for his sheep" or "one who leads his people like a shepherd guides his sheep" or "one who takes care of God's sheep."
* In some contexts, "shepherd" could be translated as "leader" or "guide" or "caregiver."
* The spiritual expression to "shepherd" could be translated as to "take care of" or to "spiritually nourish" or to "guide and teach" or to "lead and take care of (like a shepherd cares for sheep)."
* In figurative uses, it is best to use or include the literal word for "shepherd" in the translation of this term.

(See also: [believe](kt.html#believe), [Canaan](names.html#canaan), [church](kt.html#church), [Moses](names.html#moses), [pastor](kt.html#pastor), [sheep](#sheep), [spirit](kt.html#spirit))

#### Bible References: ####

* [Genesis 49:24](https://git.door43.org/Door43/en_tn/src/master/gen/49/24.md)
* [Luke 02:8-9](https://git.door43.org/Door43/en_tn/src/master/luk/02/08.md)
* [Mark 06:33-34](https://git.door43.org/Door43/en_tn/src/master/mrk/06/33.md)
* [Mark 14:26-27](https://git.door43.org/Door43/en_tn/src/master/mrk/14/26.md)
* [Matthew 02:4-6](https://git.door43.org/Door43/en_tn/src/master/mat/02/04.md)
* [Matthew 09:35-36](https://git.door43.org/Door43/en_tn/src/master/mat/09/35.md)
* [Matthew 25:31-33](https://git.door43.org/Door43/en_tn/src/master/mat/25/31.md)
* [Matthew 26:30-32](https://git.door43.org/Door43/en_tn/src/master/mat/26/30.md)

#### Examples from the Bible stories: ####

* __[09:11](https://git.door43.org/Door43/en_tn/src/master/obs/09/11.md)__ Moses became a __shepherd__  in the wilderness far away from Egypt.to
* __[17:02](https://git.door43.org/Door43/en_tn/src/master/obs/17/02.md)__ David was a __shepherd__  from the town of Bethlehem. At different times while he was watching his father's sheep, David had killed both a lion and a bear that had attacked the sheep.
* __[23:06](https://git.door43.org/Door43/en_tn/src/master/obs/23/06.md)__ That night, there were some __shepherds__  in a nearby field guarding their flocks.
* __[23:08](https://git.door43.org/Door43/en_tn/src/master/obs/23/08.md)__ The __shepherds__  soon arrived at the place where Jesus was and they found him lying in a feeding trough, just as the angel had told them.
* __[30:03](https://git.door43.org/Door43/en_tn/src/master/obs/30/03.md)__ To Jesus, these people were like sheep without a __shepherd__.

#### Word Data:####

* Strong's: H6629, H7462, H7469, H7473, G750, G4165, G4166


---

<a id="shield"/>

### shield, shields, shielded ###

#### Definition: ####

A shield was an object held by a soldier in battle to protect himself from being injured by the enemy's weapons. To "shield" someone means to protect that person from harm.

* Shields were often circular or oval, were made of materials such as leather, wood, or metal, andt were sturdy and thick enough to keep a sword or arrow from piercing them. 
* Using this term as a metaphor, the Bible refers to God as a protective shield for his people. (See: Metaphor)
* Paul talked about the "shield of faith," which is a figurative way of saying that having faith in Jesus and living out that faith in obedience to God will protect believers from the spiritual attacks of Satan.

(See also: [faith](kt.html#faith), [obey](#obey), [Satan](kt.html#satan), [spirit](kt.html#spirit))

#### Bible References: ####

* [1 Kings 14:25-26](https://git.door43.org/Door43/en_tn/src/master/1ki/14/25.md)
* [2 Chronicles 23:8-9](https://git.door43.org/Door43/en_tn/src/master/2ch/23/08.md)
* [2 Samuel 22:36-37](https://git.door43.org/Door43/en_tn/src/master/2sa/22/36.md)
* [Deuteronomy 33:29](https://git.door43.org/Door43/en_tn/src/master/deu/33/29.md)
* [Psalms 018:35-36](https://git.door43.org/Door43/en_tn/src/master/psa/018/035.md)

#### Word Data:####

* Strong's: H2653, H3591, H4043, H5437, H5526, H6793, H7982, G2375


---

<a id="shrewd"/>

### shrewd, shrewdly ###

#### Definition: ####

The term "shrewd" describes a person who is intelligent and clever, especially in practical matters.

* Often the term "shrewd" has a meaning that is partly negative since it usually also involves being selfish.
* A shrewd person is usually focused on helping himself, not others.
* Other ways to translate this term could include "cunning" or "crafty" or "smart" or "clever," depending on the context.

#### Bible References: ####

#### Word Data:####

* Strong's: H2450, H6175, G5429


---

<a id="siege"/>

### siege, besiege, besieged, besiegers, besieging, siegeworks ###

#### Definition: ####

A "siege" occurs when an attacking army surrounds a city and keeps it from receiving any supplies of food and water. To "besiege" a city or to put it "under siege" means to attack it by means of a siege.

* When the Babylonians came to attack Israel, they used the tactic of a siege against Jerusalem to weaken the people inside the city.
* Often during a siege, ramps of dirt are gradually constructed to enable the attacking army to cross over the city walls and invade the city.
* To "besiege" a city can also be expressed as to "lay siege" to it or to "perform a siege" on it.
* The term "besieged" has the same meaning as the expression "under siege." Both these expressions describe a city that an enemy army is surrounding and besieging.

#### Bible References: ####

* [1 Chronicles 20:1](https://git.door43.org/Door43/en_tn/src/master/1ch/20/01.md)
* [1 Kings 20:1-3](https://git.door43.org/Door43/en_tn/src/master/1ki/20/01.md)
* [1 Samuel 11:1-2](https://git.door43.org/Door43/en_tn/src/master/1sa/11/01.md)
* [Jeremiah 33:4-5](https://git.door43.org/Door43/en_tn/src/master/jer/33/04.md)

#### Word Data:####

* Strong's: H4692, H4693, H5341, H5437, H5564, H6693, H6696, H6887


---

<a id="silver"/>

### silver ###

#### Definition: ####

Silver is a shiny, gray precious metal used to make coins, jewelry, containers, and ornaments.

* The various containers that are made include silver cups and bowls, and other things used for cooking, eating, or serving.
* Silver and gold were used in the building of the tabernacle and the temple.The temple in Jerusalem had containers made of silver.
* In Bible times, a shekel was a unit of weight, and a purchase was often priced at a certain number of shekels of silver. By New Testament times there were silver coins of various weights that were measured in shekels.
* Joseph's brothers sold him as a slave for twenty shekels of silver.
* Judas was paid thirty silver coins for betraying Jesus.

(See also: [tabernacle](kt.html#tabernacle), [temple](kt.html#temple))

#### Bible References: ####

* [1 Chronicles 18:9-11](https://git.door43.org/Door43/en_tn/src/master/1ch/18/09.md)
* [1 Samuel 02:36](https://git.door43.org/Door43/en_tn/src/master/1sa/02/36.md)
* [2 Kings 25:13-15](https://git.door43.org/Door43/en_tn/src/master/2ki/25/13.md)
* [Acts 03:4-6](https://git.door43.org/Door43/en_tn/src/master/act/03/04.md)
* [Matthew 26:14-16](https://git.door43.org/Door43/en_tn/src/master/mat/26/14.md)

#### Word Data:####

* Strong's: H3701, H3702, H7192, G693, G694, G695, G696, G1406


---

<a id="sinoffering"/>

### sin offering, sin offerings ###

#### Definition: ####

The "sin offering" was one of several sacrifices that God required the Israelites to offer.

* This offering involved sacrificing a bull, burning its blood and fat on the altar, and taking the rest of the animal's body and burning it on the ground outside the Israelite camp.
* The complete burning up of this animal sacrifice shows how holy God is and how terrible sin is.
* The Bible teaches that in order for there to be a cleansing from sin, blood must be shed to pay the cost for the sin that was committed.
* Animal sacrifices could not permanently bring about forgiveness of sin.
* Jesus' death on the cross paid the penalty for sin, for all time. He was the perfect sin offering.

(See also: [altar](kt.html#altar), [cow](#cow), [forgive](kt.html#forgive), [sacrifice](#sacrifice), [sin](kt.html#sin))

#### Bible References: ####

* [2 Chronicles 29:20-21](https://git.door43.org/Door43/en_tn/src/master/2ch/29/20.md)
* [Exodus 29:35-37](https://git.door43.org/Door43/en_tn/src/master/exo/29/35.md)
* [Ezekiel 44:25-27](https://git.door43.org/Door43/en_tn/src/master/ezk/44/25.md)
* [Leviticus 05:11](https://git.door43.org/Door43/en_tn/src/master/lev/05/11.md)
* [Numbers 07:15-17](https://git.door43.org/Door43/en_tn/src/master/num/07/15.md)

#### Word Data:####

* Strong's: H2401, H2402, H2398, H2403


---

<a id="sister"/>

### sister, sisters ###

#### Definition: ####

A sister is a female person who shares at least one biological parent with another person. She is said to be that other person’s sister or the sister of that other person.

* In the New Testament, "sister" is also used figuratively to refer to a woman who is a fellow believer in Jesus Christ.
* Sometimes the phrase "brothers and sisters" is used to refer to all believers in Christ, both men and women.
* In the Old Testament book Song of Songs, "sister" refers to a female lover or spouse.

#### Translation Suggestions: ####

* It is best to translate this term with the literal word that is used in the target language to refer to a natural or biological sister, unless this would give wrong meaning.
* Other ways to translate this could include "sister in Christ" or "spiritual sister" or "woman who believes in Jesus" or "fellow woman believer."
* If possible, it is best to use a family term.
* If the language has a feminine form for "believer," this may be a possible way to translate this term.
* When referring to a lover or wife, this could be translated using a feminine form of "loved one" or "dear one."

(See also: [brother](kt.html#brother) [in Christ](kt.html#inchrist), [spirit](kt.html#spirit))

#### Bible References: ####

* [1 Chronicles 02:16-17](https://git.door43.org/Door43/en_tn/src/master/1ch/02/16.md)
* [Deuteronomy 27:22-23](https://git.door43.org/Door43/en_tn/src/master/deu/27/22.md)
* [Philemon 01:1-3](https://git.door43.org/Door43/en_tn/src/master/phm/01/01.md)
* [Romans 16:1-2](https://git.door43.org/Door43/en_tn/src/master/rom/16/01.md)

#### Word Data:####

* Strong's: H269, H1323, G27, G79


---

<a id="skull"/>

### skull ###

#### Definition: ####

The term "skull" refers to the bony, skeletal structure of the head of a person or animal.

* Sometimes the term "skull" means "head," as in the phrase "shave your skull."
* The term "Place of the Skull" was another name for Golgotha, where Jesus was crucified.
* This term could also be translated as "head" or "head bone."

(See also: [crucify](kt.html#crucify), [Golgotha](names.html#golgotha))

#### Bible References: ####

* [2 Kings 09:35-37](https://git.door43.org/Door43/en_tn/src/master/2ki/09/35.md)
* [Jeremiah 02:14-17](https://git.door43.org/Door43/en_tn/src/master/jer/02/14.md)
* [John 19:17-18](https://git.door43.org/Door43/en_tn/src/master/jhn/19/17.md)
* [Matthew 27:32-34](https://git.door43.org/Door43/en_tn/src/master/mat/27/32.md)

#### Word Data:####

* Strong's: H1538, H2026, H2076, H2490, H2491, H2717, H2763, H2873, H2874, H4191, H4194, H5221, H6936, H6991, H6992, H7523, H7819, G337, G615, G1315, G2380, G2695, G4968, G4969, G5407


---

<a id="slain"/>

### slay, slain ###

#### Definition: ####

To "slay" a person or animal means to kill it. Often it means to kill it in a forceful or violent way. If a man has killed an animal he has "slain" it.

* When referring to an animal or to a large number of people, the term "slaughter" is another term that is often used. 
* An act of slaughtering is also called a "slaughter."
* The phrase "the slain" could also be translated as "the slain people" or "the people who were killed."

(See also: [slaughter](#slaughter))

#### Bible References: ####

* [Ezekiel 28:23-24](https://git.door43.org/Door43/en_tn/src/master/ezk/28/23.md)
* [Isaiah 26:20-21](https://git.door43.org/Door43/en_tn/src/master/isa/26/20.md)

#### Word Data:####

* Strong's: H2026, H2076, H2490, H2491, H2717, H2763, H2873, H2874, H4191, H4194, H5221, H6991, H6992, H7523, H7819, G337, G615, G1315, G2380, G2695, G4968, G4969, G5407


---

<a id="slander"/>

### slander, slanders, slandered, slanderers, slandering, slanderous ###

#### Definition: ####

A slander consists of  negative, defaming things spoken (not written) about another person. To say such things (not to write them) about someone is to slander that person. The person saying such things is a slanderer.

* Slander may be a true report or a false accusation, but its effect is to cause others to think negatively of the person being slandered.
* To  "slander" could be translated as to "speak against" or to "spread an evil report" or to "defame."
* A slanderer is also called an "informer" or a "tale-bearer."

(See also: [blasphemy](kt.html#blasphemy))

#### Bible References: ####

* [1 Corinthians 04:12-13](https://git.door43.org/Door43/en_tn/src/master/1co/04/12.md)
* [1 Timothy 03:11-13](https://git.door43.org/Door43/en_tn/src/master/1ti/03/11.md)
* [2 Corinthians 06:8-10](https://git.door43.org/Door43/en_tn/src/master/2co/06/08.md)
* [Mark 07:20-23](https://git.door43.org/Door43/en_tn/src/master/mrk/07/20.md)

#### Word Data:####

* Strong's: H1681, H1696, H1848, H3960, H5006, H5791, H7270, H7400, H8267, G987, G988, G1228, G1426, G2636, G2637, G3059, G3060, G6022


---

<a id="slaughter"/>

### slaughter, slaughters, slaughtered, slaughtering ###

#### Definition: ####

The term "slaughter" refers to killing a large number of animals or people, or to killing in a violent way. It can also refer to killing an animal for the purpose of eating it. The act of slaughtering is also called "slaughter."

* When Abraham received three visitors at his tent in the desert, he ordered his servants to slaughter and cook a calf for his guests.
* The prophet Ezekiel prophesied that God would send his angel to slaughter all those who would not follow His word.
* 1 Samuel records a great slaughter in which 30,000 Israelites were killed by their enemies because of disobedience to God.
* "Weapons of slaughter" could be translated as "weapons for killing."
* The expression "the slaughter was very great" could be translated as "a large number were killed" or "the number of deaths was very great" or "a terribly high number of people died."
* Other ways to translate "slaughter" could include "kill" or "slay" or "killing."

(See also: [angel](kt.html#angel), [cow](#cow), [disobey](#disobey), [Ezekiel](names.html#ezekiel), [servant](#servant), [slay](#slain))

#### Bible References: ####

* [Ezekiel 21:10-11](https://git.door43.org/Door43/en_tn/src/master/ezk/21/10.md)
* [Hebrews 07:1-3](https://git.door43.org/Door43/en_tn/src/master/heb/07/01.md)
* [Isaiah 34:1-2](https://git.door43.org/Door43/en_tn/src/master/isa/34/01.md)
* [Jeremiah 25:34-36](https://git.door43.org/Door43/en_tn/src/master/jer/25/34.md)

#### Word Data:####

* Strong's: H2026, H2027, H2028, H2076, H2491, H2873, H2874, H2878, H4046, H4293, H4347, H4660, H5221, H6993, H7524, H7819, H7821, G2871, G4967, G4969, G5408


---

<a id="sleep"/>

### asleep, fall asleep, fell asleep, fallen asleep, sleep, sleeps, slept, sleeping, sleeper, sleepless, sleepy ###

#### Definition: ####

These terms can have figurative meanings relating to death.

* To "sleep" or "be asleep" can be a metaphor meaning to "be dead." (See: Metaphor)
* The expression "fall asleep" means start sleeping, or, figuratively, die.
* To "sleep with one’s fathers" means to die, as one’s ancestors have, or to be dead, as one's ancestors are.

#### Translation Suggestions: ####

* To "fall asleep" could be translated as to "suddenly become asleep" or to "start sleeping" or to "die," depending on its meaning.
* Note: It is especially important to keep the figurative expression in contexts where the audience did not understand the meaning. For example, when Jesus told his disciples that Lazarus was "sleeping" they thought he meant that Lazarus was just sleeping naturally. In this context, it would not make sense to translate this as "he died."
* Some project languages may have a different expression for death or dying which could be used if the expressions "sleep" and "asleep" do not make sense.

#### Bible References: ####

* [1 Kings 18:27-29](https://git.door43.org/Door43/en_tn/src/master/1ki/18/27.md)
* [1 Thessalonians 04:13-15](https://git.door43.org/Door43/en_tn/src/master/1th/04/13.md)
* [Acts 07:59-60](https://git.door43.org/Door43/en_tn/src/master/act/07/59.md)
* [Daniel 12:1-2](https://git.door43.org/Door43/en_tn/src/master/dan/12/01.md)
* [Psalms 044:23-24](https://git.door43.org/Door43/en_tn/src/master/psa/044/023.md)
* [Romans 13:11-12](https://git.door43.org/Door43/en_tn/src/master/rom/13/11.md)

#### Word Data:####

* Strong's: H1957, H3462, H3463, H7290, H7901, H8139, H8142, H8153, H8639, G879, G1852, G1853, G2518, G2837, G5258


---

<a id="snare"/>

### snare, snares, ensnare, ensnares, ensnared, entrap, trap, traps, trapped ###

#### Definition: ####

The terms "snare" and "trap" refer to devices that are used to catch animals and keep them from escaping. To "snare" or "ensnare" is to catch with a snare, and to "trap" or "entrap" is to catch with a trap. In the Bible, these terms were also used figuratively to talk about how sin and temptation are like hidden traps that catch people and harm them.

* A "snare" is a loop of rope or wire that suddenly pulls tight when an animal steps into it, ensnaring its leg.
* A "trap" is usually made of metal or wood and has two parts that suddenly and powerfully close together, catching an animal so it can't get away. Sometimes a trap can be a deep hole that has been made in order to get something to fall into it.
* Usually the snare or trap is hidden so that its prey is taken by surprise.
* The phrase "set a trap" means to get a trap ready to capture something.
* To "fall into a trap" refers to falling into a deep hole or pit that was dug and hidden in order to catch an animal.
* A person who is starts sinning and cannot stop can be described as "ensnared by sin" in a figurative reference to the way an animal can be ensnared and cannot escape.
* Just as an animal is endangered and hurt by being in a trap, so a person caught in the trap of sin is being harmed by that sin and needs to be set free.

(See also: [free](#free), , [prey](#prey), [Satan](kt.html#satan), [tempt](kt.html#tempt))

#### Bible References: ####

* [Ecclesiastes 07:26](https://git.door43.org/Door43/en_tn/src/master/ecc/07/26.md)
* [Luke 21:34-35](https://git.door43.org/Door43/en_tn/src/master/luk/21/34.md)
* [Mark 12:13-15](https://git.door43.org/Door43/en_tn/src/master/mrk/12/13.md)
* [Psalms 018:4-5](https://git.door43.org/Door43/en_tn/src/master/psa/018/004.md)

#### Word Data:####

* Strong's: H2256, H3353, H3369, H3920, H3921, H4170, H4204, H4434, H4685, H4686, H4889, H5367, H5914, H6315, H6341, H6351, H6354, H6679, H6983, H7639, H7845, H8610, G64, G1029, G2339, G2340, G3802, G3803, G3985, G4625


---

<a id="snow"/>

### snow, snowed, snowing ###

#### Facts: ####

The term "snow" refers to white flakes of frozen water that can fall from clouds in places where the air temperature is cold.

* Snow falls in places of higher elevation in Israel, but does not always stay on the ground very long before melting. The peaks of mountains tend to have snow that lasts longer. One example of a place mentioned in the Bible as having snow is Mount Lebanon.
* Something that is very white often has its color compared to the color of snow. For example, in the book of Revelation Jesus' clothing and hair were described as being "white as snow."
* The whiteness of snow also symbolizes purity and cleanliness. For example, the statement that our "sins will be as white as snow" means that God will completely cleanse his people from their sins.
* Some languages might refer to snow as "frozen rain" or "flakes of ice" or "frozen flakes."
* "Snow water" refers to the water that comes from melted snow.

(See also: [How to Translate Unknowns](https://git.door43.org/Door43/en_ta/src/master/translate/translate-unknown.md))

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_ta/src/master/translate/translate-names.md))

(See also: [Lebanon](names.html#lebanon), [pure](kt.html#purify))

#### Bible References: ####

* [Exodus 04:6-7](https://git.door43.org/Door43/en_tn/src/master/exo/04/06.md)
* [Job 37:4-6](https://git.door43.org/Door43/en_tn/src/master/job/37/04.md)
* [Matthew 28:3-4](https://git.door43.org/Door43/en_tn/src/master/mat/28/03.md)
* [Psalms 147:15-16](https://git.door43.org/Door43/en_tn/src/master/psa/147/015.md)
* [Revelation 01:14-16](https://git.door43.org/Door43/en_tn/src/master/rev/01/14.md)

#### Word Data:####

* Strong's: H7949, H7950, H8517, G5510


---

<a id="sorcery"/>

### sorcerer, sorcerers, sorceress, sorcery, sorceries, witchcraft ###

#### Definition: ####

"Sorcery" or "witchcraft" refers to using magic, which involves doing powerful things through the help of evil spirits. A "sorcerer" is someone who does these powerful, magical things.

* The use of magic and sorcery can involve both beneficial things (such as healing someone) and harmful things (such as putting a curse on someone). But all kinds of sorcery are wrong, because they use the power of evil spirits.
* In the Bible, God says that the use of sorcery is as evil as other terrible sins (such as adultery, worshiping idols, and child sacrifice).
* The terms "sorcery" and "witchcraft" could also be translated as "evil spirit power" or "casting spells."
* Possible ways to translated "sorcerer" could include "worker of magic" or "person who casts spells" or "person who does miracles using evil spirit power."
* Note that "sorcery" has a different meaning than the term "divination," which refers to attempting to contact the spirit world. 

(See also: [adultery](kt.html#adultery), [demon](kt.html#demon), [divination](#divination), [false god](kt.html#falsegod), [magic](#magic), [sacrifice](#sacrifice), [worship](kt.html#worship))

#### Bible References: ####

* [Acts 08:9-11](https://git.door43.org/Door43/en_tn/src/master/act/08/09.md)
* [Exodus 07:11-13](https://git.door43.org/Door43/en_tn/src/master/exo/07/11.md)
* [Galatians 05:19-21](https://git.door43.org/Door43/en_tn/src/master/gal/05/19.md)
* [Revelation 09:20-21](https://git.door43.org/Door43/en_tn/src/master/rev/09/20.md)

#### Word Data:####

* Strong's: H3784, H3785, H3786, H6049, G3095, G3096, G3097, G5331, G5332, G5333


---

<a id="sow"/>

### plant, plants, planted, planting, implanted, replanted, transplanted, sow, sows, sowed, sown, sowing ###

#### Definition: ####

A "plant" is generally something that grows and is attached to the ground. To "sow" means to put seeds in the ground in order to grow plants. A "sower" is a person who sows or plants seeds.

* The method of sowing or planting varies, but one method is to take handfuls of seeds and scatter them on the ground.
* Another method for planting seeds is to make holes in the soil and place seeds in each hole.
* The term "sow" can be used figuratively, as in "a person will reap what he sows." This means that if a person does something evil, he will receive a negative result, a if a person does good, he will receive a positive result.

#### Translations Suggestions ####

* The term to "sow" could also be translated as to "plant." Make sure the word used to translate this can include planting seeds.
* Other ways to translate "sower" could include "planter" or "farmer" or "person who plants seeds."
* In English, "sow" is only used for planting seeds, but the English word "plant" can be used for planting seeds as well as larger things, such as trees. Other languages may also use different words, depending on what is being planted.
* The expression "a person reaps what he sows" could also be translated as "just like a certain kind of seed produces a certain kind of plant, in the same way a person's good actions will bring a good result and a person's evil actions will bring an evil result."

(See also: [evil](kt.html#evil), [good](kt.html#good), [reap](#reap))

#### Bible References: ####

* [Galatians 06:6-8](https://git.door43.org/Door43/en_tn/src/master/gal/06/06.md)
* [Luke 08:4-6](https://git.door43.org/Door43/en_tn/src/master/luk/08/04.md)
* [Matthew 06:25-26](https://git.door43.org/Door43/en_tn/src/master/mat/06/25.md)
* [Matthew 13:3-6](https://git.door43.org/Door43/en_tn/src/master/mat/13/03.md)
* [Matthew 13:18-19](https://git.door43.org/Door43/en_tn/src/master/mat/13/18.md)
* [Matthew 25:24-25](https://git.door43.org/Door43/en_tn/src/master/mat/25/24.md)

#### Word Data:####

* Strong's: H2221, H2232, H2233, H2236, H4218, H4302, H5193, H7971, H8362, G4687, G4703, G5300, G5452 , G6037


---

<a id="spear"/>

### spear, spears, spearmen ###

#### Definition: ####

A spear is a weapon with a long wooden handle and sharp metal blade on one end that is thrown a long distance.

* Spears were commonly used for war in biblical times. They are sometimes still used in present-day conflicts between certain people groups.
* A spear was used by a Roman soldier to pierce the side of Jesus while he hung on the cross.
* Sometimes people throw spears to catch fish or other prey to eat.
* Similar weapons are the "javelin" or "lance."
* Make sure that the translation of "spear" is different from the translation of "sword," which is a weapon that is used for thrusting or stabbing, not throwing. Also, a sword has a long blade with a handle, while a spear has a small blade on the end of a long shaft.

(See also: [prey](#prey), [Rome](names.html#rome), [sword](#sword), [warrior](#warrior))

#### Bible References: ####

* [1 Samuel 13:19-21](https://git.door43.org/Door43/en_tn/src/master/1sa/13/19.md)
* [2 Samuel 21:18-19](https://git.door43.org/Door43/en_tn/src/master/2sa/21/18.md)
* [Nehemiah 04:12-14](https://git.door43.org/Door43/en_tn/src/master/neh/04/12.md)
* [Psalm 035:1-3](https://git.door43.org/Door43/en_tn/src/master/psa/035/001.md)

#### Word Data:####

* Strong's: H1265, H2595, H3591, H6767, H7013, H7420, G3057


---

<a id="splendor"/>

### splendor ###

#### Definition: ####

The term "splendor" refers to the extreme beauty and elegance that is often associated with wealth and a magnificent appearance.

* Often splendor is used to describe the wealth that a king has, or how he looks in his expensive, beautiful finery.
* The word "splendor" can also be used to describe the beauty of trees, mountains, and other things that God has created.
* Certain cities are said to have splendor because of o their natural resources, elaborate buildings and roads, and the wealth of their people, which includes rich clothing, gold, and silver.
* Depending on the context, this word could be translated as "magnificent beauty" or "amazing majesty" or "kingly greatness."

(See also: [glory](kt.html#glory), [king](#king), [majesty](kt.html#majesty))

#### Bible References: ####

* [1 Chronicles 16:25-27](https://git.door43.org/Door43/en_tn/src/master/1ch/16/25.md)
* [Exodus 28:1-3](https://git.door43.org/Door43/en_tn/src/master/exo/28/01.md)
* [Ezekiel 28:6-7](https://git.door43.org/Door43/en_tn/src/master/ezk/28/06.md)
* [Luke 04:5-7](https://git.door43.org/Door43/en_tn/src/master/luk/04/05.md)
* [Psalms 089:44-45](https://git.door43.org/Door43/en_tn/src/master/psa/089/044.md)
* [Revelation 21:26-27](https://git.door43.org/Door43/en_tn/src/master/rev/21/26.md)

#### Word Data:####

* Strong's: H1925, H1926, H1927, H1935, H2091, H2122, H2892, H3314, H3519, H6643, H7613, H8597


---

<a id="staff"/>

### staff, staffs ###

#### Definition: ####

A staff is a long wooden stick or rod, often used as a walking stick.

* When Jacob was old, he used a staff to help him walk.
* God turned Moses' staff into a snake to show his power to Pharaoh.
* Shepherds also used a staff to help guide their sheep, or to rescue the sheep when they fell or wandered.
* The shepherd's staff had a hook on the end, so it differed from the shepherd's rod, which was straight and was used to kill wild animals that were trying to attack the sheep.

(See also: [Pharaoh](names.html#pharaoh), [power](kt.html#power), [sheep](#sheep), [shepherd](#shepherd))

#### Bible References: ####

* [Exodus 04:1-3](https://git.door43.org/Door43/en_tn/src/master/exo/04/01.md)
* [Exodus 07:8-10](https://git.door43.org/Door43/en_tn/src/master/exo/07/08.md)
* [Luke 09:3-4](https://git.door43.org/Door43/en_tn/src/master/luk/09/03.md)
* [Mark 06:7-9](https://git.door43.org/Door43/en_tn/src/master/mrk/06/07.md)
* [Matthew 10:8-10](https://git.door43.org/Door43/en_tn/src/master/mat/10/08.md)
* [Matthew 27:27-29](https://git.door43.org/Door43/en_tn/src/master/mat/27/27.md)

#### Word Data:####

* Strong's: H4132, H4294, H4731, H4938, H6086, H6418, H7626, G2563, G3586, G4464


---

<a id="statute"/>

### statute, statutes ###

#### Definition: ####

A statute is a specific written law that provides guidance for people to live by.

* The term "statute" is similar in meaning to "ordinance" and " command" and "law" and "decree." All these terms involve instructions and requirements that God gives to his people or rulers give to their people.
* King David said that he delighted himself in Yahweh's statutes.
* The term "statute" could also be translated as "specific command" or "special decree."

(See also: [command](kt.html#command), [decree](#decree), [law](kt.html#lawofmoses), [ordinance](#ordinance), [Yahweh](kt.html#yahweh))

#### Bible References: ####

* [1 Kings 11:11-13](https://git.door43.org/Door43/en_tn/src/master/1ki/11/11.md)
* [Deuteronomy 06:20-23](https://git.door43.org/Door43/en_tn/src/master/deu/06/20.md)
* [Ezekiel 33:14-16](https://git.door43.org/Door43/en_tn/src/master/ezk/33/14.md)
* [Numbers 19:1-2](https://git.door43.org/Door43/en_tn/src/master/num/19/01.md)

#### Word Data:####

* Strong's: H2706, H2708, H6490, H7010


---

<a id="stiffnecked"/>

### stiff-necked, stubborn, stubbornly, stubbornness ###

#### Definition: ####

The term "stiff-necked" is an idiom used in the Bible to describe people who keep disobeying God and refuse to repent. Such people are very proud and will not submit to God's authority.

* Similarly, the term "stubborn" describes a person who refuses to change his mind or actions even when urged to do so. Stubborn people will not listen to good advice or warnings that other people give them.
* The Old Testament described the Israelites as "stiff-necked" because they did not listen to the many messages from God's prophets who urged them to repent and turn back to Yahweh.
* If a neck is "stiff" it does not bend easily. The project language may have a different idiom that communicates that a person is "unbending" in that he refuses to change his ways.
* Other ways to translate this term could include "pridefully stubborn" or "arrogant and unyielding" or "refusing to change."

(See also: [arrogant](#arrogant), [proud](#proud), [repent](kt.html#repent))

#### Bible References: ####

* [Acts 07:51-53](https://git.door43.org/Door43/en_tn/src/master/act/07/51.md)
* [Deuteronomy 09:13-14](https://git.door43.org/Door43/en_tn/src/master/deu/09/13.md)
* [Exodus 13:14-16](https://git.door43.org/Door43/en_tn/src/master/exo/13/14.md)
* [Jeremiah 03:17-18](https://git.door43.org/Door43/en_tn/src/master/jer/03/17.md)

#### Word Data:####

* Strong's: H47, H3513, H5637, H6203, H6484, H7185, H7186, H7190, H8307, G483, G4644, G4645


---

<a id="storehouse"/>

### storehouse, storehouses ###

#### Definition: ####

A "storehouse" is a large building that is used for keeping food or other things, often for a long time.

* In the Bible a "storehouse" was usually used to store extra grain and other food to be used later when there was a famine.
* This term was also used figuratively to refer to all the good things that God wants to give to his people.
* The storehouses of the temple contained valuable things that had been dedicated to Yahweh, such as gold and silver. Some of these things used to repair and maintain the temple were also kept there.
* Other ways to translate "storehouse" could include "a building for storing grain" or "place for keeping food" or "room for keeping valuable things safe."

(See also: [consecrate](kt.html#consecrate), [dedicate](#dedicate), [famine](#famine), [gold](#gold), [grain](#grain), [silver](#silver), [temple](kt.html#temple))

#### Bible References: ####

* [2 Chronicles 16:2-3](https://git.door43.org/Door43/en_tn/src/master/2ch/16/02.md)
* [Luke 03:17](https://git.door43.org/Door43/en_tn/src/master/luk/03/17.md)
* [Matthew 03:10-12](https://git.door43.org/Door43/en_tn/src/master/mat/03/10.md)
* [Psalms 033:7-9](https://git.door43.org/Door43/en_tn/src/master/psa/033/007.md)

#### Word Data:####

* Strong's: H214, H618, H624, H4035, H4200, H4543, G596


---

<a id="strength"/>

### strength, strengthen, strengthens, strengthened, strengthening ###

#### Facts: ####

The term "strength" refers to physical, emotional, or spiritual power. To "strengthen" someone or something means to make that person or object stronger.

* "Strength" can also refer to the power to withstand some kind of opposing force.
* A person has "strength of will" if he is able to avoid sinning when tempted.
* One writer of the Psalms called Yahweh his "strength" because God helped him to be strong.
* If a physical structure like a wall or building is being "strengthened," people are rebuilding the structure, reinforcing it with more stones or brick so that it can withstand an attack.

#### Translation Suggestions ####

* In general, the term "strengthen" can be translated as "cause to be strong" or "make more powerful."
* In a spiritual sense, the phrase "strengthen your brothers" could also be translated as "encourage your brothers" or "help your brothers to persevere."
* The following examples show the meaning of these terms, and therefore how they can be translated, when they are included in longer expressions.
   * "puts strength on me like a belt" means "causes me to be completely strong, like a belt that completely surrounds my waist."
   * "in quietness and trust will be your strength" means "acting calmly and trusting in God will make you spiritually strong."
   * "will renew their strength" means "will become stronger again."
   * "by my strength and by my wisdom I acted" means "I have done all this because I am so strong and wise."
   * "strengthen the wall" means "reinforce the wall" or "rebuild the wall."
   * "I will strengthen you" means "I will cause you to be strong"
   * "in Yahweh alone are salvation and strength" means "Yahweh is the only one who saves us and strengthens us."
   * "the rock of your strength" means "the faithful one who makes you strong"
   * "with the saving strength of his right hand" means "he strongly rescues you from trouble like someone who holds you safely with his strong hand."
   * "of little strength" means "not very strong" or "weak."
   * "with all my strength" means "using my best efforts" or "strongly and completely."
(See also: [faithful](kt.html#faithful), [persevere](#perseverance), [right hand](kt.html#righthand), [save](kt.html#save))

#### Bible References: ####

* [2 Kings 18:19-21](https://git.door43.org/Door43/en_tn/src/master/2ki/18/19.md)
* [2 Peter 02:10-11](https://git.door43.org/Door43/en_tn/src/master/2pe/02/10.md)
* [Luke 10:25-28](https://git.door43.org/Door43/en_tn/src/master/luk/10/25.md)
* [Psalm 021:1-2](https://git.door43.org/Door43/en_tn/src/master/psa/021/001.md)

#### Word Data:####

* Strong's: H193, H202, H353, H360, H386, H410, H553, H556, H905, H1082, H1369, H1396, H1679, H2220, H2388, H2391, H2392, H2393, H2428, H2633, H3027, H3028, H3559, H3581, H3811, H3955, H4206, H4581, H5326, H5331, H5332, H5582, H5797, H5807, H5810, H5934, H5975, H6106, H6109, H6697, H6965, H7292, H7293, H7296, H7307, H8003, H8443, H8510, H8632, H8633, G461, G772, G950, G1411, G1412, G1743, G1765, G1840, G1849, G1991, G2479, G2480, G2901, G2904, G3619, G3756, G4599, G4732, G4733, G4741


---

<a id="strife"/>

### strife ###

#### Definition: ####

The term "strife" refers to physical or emotional conflict between people.

* A person who causes strife does things that result in strong disagreements between people and in hurt feelings.
* Sometimes the use of the word "strife" implies that strong emotions are involved, such as anger or bitterness.
* Other ways to translate this term could include "disagreement" or "dispute" or "conflict."

(See also: [angry](#angry))

#### Bible References: ####

* [1 Corinthians 03:3-5](https://git.door43.org/Door43/en_tn/src/master/1co/03/03.md)
* [Habakkuk 01:3-4](https://git.door43.org/Door43/en_tn/src/master/hab/01/03.md)
* [Philippians 01:15-17](https://git.door43.org/Door43/en_tn/src/master/php/01/15.md)
* [Proverbs 17:1-2](https://git.door43.org/Door43/en_tn/src/master/pro/17/01.md)
* [Psalms 055:8-9](https://git.door43.org/Door43/en_tn/src/master/psa/055/008.md)
* [Romans 13:13-14](https://git.door43.org/Door43/en_tn/src/master/rom/13/13.md)

#### Word Data:####

* Strong's: H1777, H1779, H4066, H4090, H4683, H4808, H7379, H7701, G485, G2052, G2054, G3055, G3163, G5379


---

<a id="strongdrink"/>

### strong drink, strong drinks ###

#### Definition: ####

The term "strong drink" refers to drinks that have been fermented and have alcohol in them.
* Alcoholic drinks are made from either grain or fruit and have undergone fermentation.
* Kinds of "strong drink" include grape wine, palm wine, beer, and apple cider. In the Bible, grape wine was the most frequently mentioned strong drink.
* Priests and anyone who took a special vow such as the "Nazirite vow" were not permitted to drink fermented drinks.
* This term could also be translated as "fermented drink" or "alcoholic drink."

(See also: [grape](#grape), [Nazirite](kt.html#nazirite), [vow](kt.html#vow), [wine](#wine))

#### Bible References: ####

* [Isaiah 05:11-12](https://git.door43.org/Door43/en_tn/src/master/isa/05/11.md)
* [Leviticus 10:8-11](https://git.door43.org/Door43/en_tn/src/master/lev/10/08.md)
* [Luke 01:14-15](https://git.door43.org/Door43/en_tn/src/master/luk/01/14.md)
* [Numbers 06:1-4](https://git.door43.org/Door43/en_tn/src/master/num/06/01.md)

#### Word Data:####

* Strong's: H5435, H7941, G4608


---

<a id="stronghold"/>

### stronghold, strongholds, fortifications, fortified, fortress, fortresses ###

#### Definition: ####

The terms "stronghold" and "fortress" both refer to places that are well protected against an attack by enemy soldiers. The term "fortified" describes a city or other place that has been made safe from attack.

* Often, strongholds and fortresses were manmade structures with defensive walls. They could also have been places with natural protective barriers such as rocky cliffs or high mountains.
* People fortified strongholds by building thick walls or other structures that made it difficult for an enemy to break through.
* "Stronghold" or "fortress" could be translated as "securely strong place" or "strongly protected place."
* The term "fortified city" could be translated as "securely protected city" or "strongly built city."
* This term was also used figuratively to refer to God as a stronghold or fortress for those who trust in him. (See: [Metaphor](https://git.door43.org/Door43/en_ta/src/master/translate/figs-metaphor.md))
* Another figurative meaning for the term "stronghold" referred to something that someone wrongly trusted in for security, such as a false god or other thing that was worshiped instead of Yahweh. This could be translated as "false strongholds."
* This term should be translated differently from "refuge," which emphasizes safety more than the concept of being fortified.

(See also: [false god](kt.html#falsegod), [false god](kt.html#falsegod), [refuge](#refuge), [Yahweh](kt.html#yahweh))

#### Bible References: ####

* [2 Corinthians 10:3-4](https://git.door43.org/Door43/en_tn/src/master/2co/10/03.md)
* [2 Kings 08:10-12](https://git.door43.org/Door43/en_tn/src/master/2ki/08/10.md)
* [2 Samuel 05:8-10](https://git.door43.org/Door43/en_tn/src/master/2sa/05/08.md)
* [Acts 21:34-36](https://git.door43.org/Door43/en_tn/src/master/act/21/34.md)
* [Habakkuk 01:10-11](https://git.door43.org/Door43/en_tn/src/master/hab/01/10.md)

#### Word Data:####

* Strong's: H490, H553, H759, H1001, H1002, H1003, H1219, H1225, H2388, H4013, H4026, H4581, H4526, H4679, H4685, H4686, H4692, H4693, H4694, H4869, H5794, H5797, H5800, H6438, H6696, H6877, H7682, G3794


---

<a id="stumble"/>

### stumble, stumbles, stumbled, stumbling ###

#### Definition: ####

The term "stumble" means "almost fall" when walking or running. Usually it involves tripping over something.

* Figuratively, to "stumble" can mean to "sin" or to "falter" in believing.
* This term can also refer to faltering or showing weakness when fighting a battle or when being persecuted or punished.

#### Translation Suggestions ####

* In contexts where the term "stumble" means to physically trip over something, it should be translated with a term that means "almost fall" or "trip over."
* This literal meaning could also be used in a figurative context, if it communicates the correct meaning in that context.
* For figurative uses where the literal meaning would not make sense in the project language, "stumble" could be translated as, "sin" or "falter" or "stop believing" or "become weak," depending on the context.
* Another way to translate this term could be, "stumble by sinning" or "stumble by not believing."
* The phrase "made to stumble" could be translated as "caused to become weak" or "caused to falter."

(See also: [believe](kt.html#believe), [persecute](#persecute), [sin](kt.html#sin), [stumbling block](#stumblingblock))

#### Bible References: ####

* [1 Peter 02:7-8](https://git.door43.org/Door43/en_tn/src/master/1pe/02/07.md)
* [Hosea 04:4-5](https://git.door43.org/Door43/en_tn/src/master/hos/04/04.md)
* [Isaiah 31:3](https://git.door43.org/Door43/en_tn/src/master/isa/31/03.md)
* [Matthew 11:4-6](https://git.door43.org/Door43/en_tn/src/master/mat/11/04.md)
* [Matthew 18:7-8](https://git.door43.org/Door43/en_tn/src/master/mat/18/07.md)

#### Word Data:####

* Strong's: H1762, H3782, H4383, H4384, H5062, H5063, H5307, H6328, H6761, H8058, G679, G4348, G4350, G4417, G4624, G4625


---

<a id="stumblingblock"/>

### stumbling block, stumbling blocks, stone of stumbling ###

#### Definition: ####

The term "stumbling block" or "stone of stumbling" refers to a physical object that causes a person to trip and fall.

* A figurative stumbling block is anything that causes a person to fail in a moral or spiritual sense.
* Also figuratively, a "stumbling block" or "stone of stumbling" can be something that prevents someone from having faith in Jesus or that causes someone to not grow spiritually.
* Often it is sin that is like a stumbling block to oneself or to others.
* Sometimes God places a stumbling block in the way of people who are rebelling against him.

#### Translation Suggestions: ####

* If a language has a term for an object that triggers a trap, that word could be used to translate this term.
* This term could also be translated as "stone that causes stumbling" or "something that causes someone to not believe" or "obstacle that causes doubt" or "obstacle to faith" or "something that causes someone to sin."

(See also: [stumble](#stumble), [sin](kt.html#sin))

#### Bible References: ####

* [1 Corinthians 01:22-23](https://git.door43.org/Door43/en_tn/src/master/1co/01/22.md)
* [Galatians 05:11-12](https://git.door43.org/Door43/en_tn/src/master/gal/05/11.md)
* [Matthew 05:29-30](https://git.door43.org/Door43/en_tn/src/master/mat/05/29.md)
* [Matthew 16:21-23](https://git.door43.org/Door43/en_tn/src/master/mat/16/21.md)
* [Romans 09:32-33](https://git.door43.org/Door43/en_tn/src/master/rom/09/32.md)

#### Word Data:####

* Strong's: H4383, G3037, G4349, G4625


---

<a id="subject"/>

### subject, subjects, subjected, subject to, be subject to, subjection, be subjected, are subjected, was subjected, were subjected, in subjection to ###

#### Facts: ####

A person is the "subject" of another person if the second person rules over the first. To "be subject to" is to "obey" or to "submit to the authority of."

* The phrase "put in subjection to" refers to causing people to be under the authority of a leader or ruler.
* To "subject someone to something" means to cause that person to experience something negative, such as punishment.
* Sometimes the term "subject" is used to refer to being the topic or focus of something, such as in, "you will be the subject of ridicule."
* The phrase "be subject to" means the same as "be submissive to" or "submit to."

(See also: [submit](#submit))

#### Bible References: ####

* [1 Corinthians 02:14-16](https://git.door43.org/Door43/en_tn/src/master/1co/02/14.md)
* [1 Kings 04:5-6](https://git.door43.org/Door43/en_tn/src/master/1ki/04/05.md)
* [1 Peter 02:18-20](https://git.door43.org/Door43/en_tn/src/master/1pe/02/18.md)
* [Hebrews 02:5-6](https://git.door43.org/Door43/en_tn/src/master/heb/02/05.md)
* [Proverbs 12:23-24](https://git.door43.org/Door43/en_tn/src/master/pro/12/23.md)

#### Word Data:####

* Strong's: H1697, H3533, H3665, H4522, H5647, H5927, G350, G1379, G1396, G1777, G3663, G5292, G5293


---

<a id="submit"/>

### submit, submits, submitted, submitting, submission, in submission ###

#### Definition: ####

To "submit" usually means to voluntarily place oneself under the authority of a person or government.

* The Bible tells believers in Jesus to submit to God and other authorities in their lives.
* The instruction to "submit to one another" means to humbly accept correction and to focus on the needs of others rather than on our own needs.
* To "live in submission to" means to put oneself under the authority of something or someone.

#### Translation Suggestions: ####

* The command "submit to" could be translated as "put yourself under the authority of" or "follow the leadership of" or "humbly honor and respect"
* The term "submission" could be translated as "obedience" or "the following of authority."
* The phrase "live in submission to" could be translated as "be obedient to" or "put oneself under the authority of."
* The phrase "be in submission" could be translated as "humbly accept authority."

(See also: [subject](#subject))

#### Bible References: ####

* [1 Corinthians 14:34-36](https://git.door43.org/Door43/en_tn/src/master/1co/14/34.md)
* [1 Peter 03:1-2](https://git.door43.org/Door43/en_tn/src/master/1pe/03/01.md)
* [Hebrews 13:15-17](https://git.door43.org/Door43/en_tn/src/master/heb/13/15.md)
* [Luke 10:17-20](https://git.door43.org/Door43/en_tn/src/master/luk/10/17.md)

#### Word Data:####

* Strong's: H3584, H7511, G5226, G5293


---

<a id="suffer"/>

### suffer, suffers, suffered, suffering, sufferings ###

#### Definition: ####

The terms "suffer" and "suffering" refer to experiencing something very unpleasant, such as illness, pain, or other hardships.

* When people are persecuted or when they are sick, they suffer.
* Sometimes people suffer because of wrong things they have done; other times they suffer because of sin and disease in the world.
* Suffering can be physical, such as feeling pain or sickness. It can also be emotional, such as feeling fear, sadness, or loneliness.
* The phrase "suffer me" means "bear with me" or "hear me out" or "listen patiently."

#### Translation Suggestions: ####

* The term "suffer" can be translated as "feel pain" or "endure difficulty" or "experience hardships" or "go through difficult and painful experiences."
* Depending on the context, "suffering" could be translated as "extremely difficult circumstances" or "severe hardships" or "experiencing hardship" or "time of painful experiences."
* The phrase "suffer thirst" could be translated as "experience thirst" or "suffer with thirst."
* To "suffer violence" could also be translated as "undergo violence" or "be harmed by violent acts."

#### Bible References: ####

* [1 Thessalonians 02:14-16](https://git.door43.org/Door43/en_tn/src/master/1th/02/14.md)
* [2 Thessalonians 01:3-5](https://git.door43.org/Door43/en_tn/src/master/2th/01/03.md)
* [2 Timothy 01:8-11](https://git.door43.org/Door43/en_tn/src/master/2ti/01/08.md)
* [Acts 07:11-13](https://git.door43.org/Door43/en_tn/src/master/act/07/11.md)
* [Isaiah 53:10-11](https://git.door43.org/Door43/en_tn/src/master/isa/53/10.md)
* [Jeremiah 06:6-8](https://git.door43.org/Door43/en_tn/src/master/jer/06/06.md)
* [Matthew 16:21-23](https://git.door43.org/Door43/en_tn/src/master/mat/16/21.md)
* [Psalms 022:24-25](https://git.door43.org/Door43/en_tn/src/master/psa/022/024.md)
* [Revelation 01:9-11](https://git.door43.org/Door43/en_tn/src/master/rev/01/09.md)
* [Romans 05:3-5](https://git.door43.org/Door43/en_tn/src/master/rom/05/03.md)

#### Examples from the Bible stories: ####

* __[09:13](https://git.door43.org/Door43/en_tn/src/master/obs/09/13.md)__ God said, "I have seen the __suffering__  of my people."
* __[38:12](https://git.door43.org/Door43/en_tn/src/master/obs/38/12.md)__ Jesus prayed three times, "My Father, if it is possible, please let me not have to drink this cup of __suffering__."
* __[42:03](https://git.door43.org/Door43/en_tn/src/master/obs/42/03.md)__ He (Jesus) reminded them that the prophets said the Messiah would __suffer__  and be killed, but would rise again on the third day.
* __[42:07](https://git.door43.org/Door43/en_tn/src/master/obs/42/07.md)__ He (Jesus) said, "It was written long ago that the Messiah would __suffer__, die, and rise from the dead on the third day."
* __[44:05](https://git.door43.org/Door43/en_tn/src/master/obs/44/05.md)__ "Although you did not understand what you were doing, God used your actions to fulfill the prophecies that the Messiah would __suffer__  and die."
* __[46:04](https://git.door43.org/Door43/en_tn/src/master/obs/46/04.md)__ God said, "I have chosen him (Saul) to declare my name to the unsaved. I will show him how much he must __suffer__  for my sake."
* __[50:17](https://git.door43.org/Door43/en_tn/src/master/obs/50/17.md)__ He (Jesus) will wipe away every tear and there will be no more __suffering__, sadness, crying, evil, pain, or death.

#### Word Data:####

* Strong's: H943, H1741, H1934, H4342, H4531, H4912, H5142, H5254, H5375, H5999, H6031, H6040, H6041, H6064, H6090, H6770, H6869, H6887, H7661, G91, G941, G971, G2210, G2346, G2347, G3804, G3958, G4310, G4778, G4841, G5004, G5723


---

<a id="sulfur"/>

### sulfur, sulfurous ###

#### Definition: ####

Sulfur is a yellow substance that becomes a burning liquid when it is set on fire.

* Sulfur also has a very strong smell that is like the odor of rotten eggs.
* In the Bible, burning sulfur is a symbol of God's judgment on ungodly and rebellious people.
* During the time of Lot, God rained down fire and sulfur on the evil cities of Sodom and Gomorrah.
* In some English Bible versions, sulfur is referred to as "brimstone," which literally means "burning stone."

#### Translation Suggestions: ####

* Possible translations of this term could include "yellow stone that burns" or "burning yellowish rock."

(See also: [Gomorrah](names.html#gomorrah), [judge](kt.html#judge), [Lot](names.html#lot), [rebel](#rebel), [Sodom](names.html#sodom), [godly](kt.html#godly))

#### Bible References: ####

* [Genesis 19:23-25](https://git.door43.org/Door43/en_tn/src/master/gen/19/23.md)
* [Isaiah 34:8-10](https://git.door43.org/Door43/en_tn/src/master/isa/34/08.md)
* [Luke 17:28-29](https://git.door43.org/Door43/en_tn/src/master/luk/17/28.md)
* [Revelation 20:9-10](https://git.door43.org/Door43/en_tn/src/master/rev/20/09.md)

#### Word Data:####

* Strong's: H1614, G2303


---

<a id="sweep"/>

### sweep, sweeps, swept, sweeping ###

#### Facts: ####

To "sweep" usually means to remove dirt by making broad, quick movements with a broom or brush. "Swept" is the past tense of "sweep." These words are also used figuratively.

* The term "sweep" is used figuratively to describe how an army attacks with swift, decisive, wide-reaching movements.
* For example, Isaiah prophesied that the Assyrians would "sweep through" the Kingdom of Judah. This means they would destroy Judah and capture its people.
* The term "sweep" can also be used to describe the manner in which rapidly flowing water pushes things and forces them away.
* When overwhelming, difficult things are happening to a person, it can be said that they are "sweeping over" him.

(See also: [Assyria](names.html#assyria), [Isaiah](names.html#isaiah), [Judah](names.html#judah), [prophet](kt.html#prophet))

#### Bible References: ####

* [1 Kings 16:3-4](https://git.door43.org/Door43/en_tn/src/master/1ki/16/03.md)
* [Daniel 11:40-41](https://git.door43.org/Door43/en_tn/src/master/dan/11/40.md)
* [Genesis 18:24-26](https://git.door43.org/Door43/en_tn/src/master/gen/18/24.md)
* [Proverbs 21:7-8](https://git.door43.org/Door43/en_tn/src/master/pro/21/07.md)
* [Psalms 090:5-6](https://git.door43.org/Door43/en_tn/src/master/psa/090/005.md)

#### Word Data:####

* Strong's: H622, H857, H1640, H2498, H2894, H3261, H5500, H5502, H5595, H7857, H8804, G4216, G4563, G4951


---

<a id="sword"/>

### sword, swords, swordsmen ###

#### Definition: ####

A sword is a flat-bladed metal weapon used to cut or stab. It has a handle and a long, pointed blade with a very sharp cutting edge.

* In ancient times the length of a sword’s blade was about 60 to 91 centimeters.
* Some swords have two sharp edges and are called "double-edged" or "two-edged" swords.
* Jesus' disciples had swords for self defense. With his sword, Peter cut off the ear of the high priest's servant.
* Both John the Baptist and the apostle James were beheaded with swords.

#### Translation Suggestions ####

* A sword is used as a metaphor for God's word. God's teachings in the Bible exposed people's innermost thoughts and convicted them of their sin. In a similar way, a sword cuts deeply, causing pain. (See: [Metaphor](https://git.door43.org/Door43/en_ta/src/master/translate/figs-metaphor.md))
* One way to translate this figurative use would be, "God's word is like a sword, which cuts deeply and exposes sin."
* Another figurative use of this term occurred in the book of Psalms, where the tongue or speech of a person was compared to a sword, which can injure people. This could be translated as "the tongue is like a sword that can badly injure someone."
* If swords are not known in your culture, this word could be translated with the name of another long-bladed weapon that is used to cut or stab.
* A sword could also be described as a "sharp weapon" or "long knife." Some translations could include a picture of a sword.

(See also: [How to Translate Unknowns](https://git.door43.org/Door43/en_ta/src/master/translate/translate-unknown.md))

(See also: [James (brother of Jesus)](names.html#jamesbrotherofjesus), [John (the Baptist)](names.html#johnthebaptist), [tongue](#tongue), [word of God](kt.html#wordofgod))

#### Bible References: ####

* [Acts 12:1-2](https://git.door43.org/Door43/en_tn/src/master/act/12/01.md)
* [Genesis 27:39-40](https://git.door43.org/Door43/en_tn/src/master/gen/27/39.md)
* [Genesis 34:24-26](https://git.door43.org/Door43/en_tn/src/master/gen/34/24.md)
* [Luke 02:33-35](https://git.door43.org/Door43/en_tn/src/master/luk/02/33.md)
* [Luke 21:23-24](https://git.door43.org/Door43/en_tn/src/master/luk/21/23.md)
* [Matthew 10:34-36](https://git.door43.org/Door43/en_tn/src/master/mat/10/34.md)
* [Matthew 26:55-56](https://git.door43.org/Door43/en_tn/src/master/mat/26/55.md)
* [Revelation 01:14-16](https://git.door43.org/Door43/en_tn/src/master/rev/01/14.md)

#### Word Data:####

* Strong's: H19, H1300, H2719, H4380, H6609, H7524, H7973, G3162, G4501


---

<a id="tax"/>

### tax, taxes, taxed, taxation, taxpayers, tax collector ###

#### Definition: ####

The terms "tax" and "taxes" refer to money or goods that people pay to a government that is in authority over them.

* The amount of money that is paid as a tax is usually based on the value of an item or on how much a person's property is worth.
* If taxes are not paid, the government can take legal action against a person to get the money that is owed.
* Joseph and Mary traveled to Bethlehem to be counted in the census held to tax everyone living in the Roman empire.
* The term "tax" could also be translated as, "required payment" or "government money" or "temple money," depending on the context.
* To "pay taxes" could also be translated as to "pay money to the government" or "receive money for the government" or "make the required payment." To "collect taxes" could be translated as to "receive money for the government.
* A "tax collector" is someone who works for the government and receives the money that people are required to pay it.

(See also: [Bethlehem](names.html#bethlehem), [census](#census), [citizen](#citizen), [Rome](names.html#rome), [tax collector](#taxcollector))

Definition:

A "tax collector" was a government worker whose job was to receive money that people were required to pay the government in taxes.

In the time of Jesus and and the apostles, the Roman government required taxes from everyone living in the Roman empire, including the Jews.
The people who collected taxes for the Roman government would often demand more money from the people than the government required. The tax collectors would keep the extra amount for themselves.
Because tax collectors cheated people in this way, the Jews considered them to be among the worst of sinners.
The Jews also considered Jewish tax collectors to be traitors to their own people because they worked for the Roman government which was oppressing the Jewish people.
The phrase, "tax collectors and sinners" was a common expression in the New Testament, showing how much the Jews despised tax collectors.
(See also: Jew, Rome, sin, tax)

#### Bible References for tax: ####

* [Luke 20:21-22](https://git.door43.org/Door43/en_tn/src/master/luk/20/21.md)
* [Mark 02:13-14](https://git.door43.org/Door43/en_tn/src/master/mrk/02/13.md)
* [Matthew 09:7-9](https://git.door43.org/Door43/en_tn/src/master/mat/09/07.md)
* [Numbers 31:28-29](https://git.door43.org/Door43/en_tn/src/master/num/31/28.md)
* [Romans 13:6-7](https://git.door43.org/Door43/en_tn/src/master/rom/13/06.md)

Bible References for tax collector:

Luke 03:12-13
Luke 05:27-28
Matthew 05:46-48
Matthew 09:10-11
Matthew 11:18-19
Matthew 17:26-27
Matthew 18:17

Examples from the Bible stories:

34:06 He said, "Two men went to the Temple to pray. One of them was a tax collector, and the other was a religious leader."
34:07 "The religious leader prayed like this, 'Thank you, God, that I am not a sinner like other men—such as robbers, unjust men, adulterers, or even like that tax collector.'"
34:09 "But the tax collector stood far away from the religious ruler, did not even look up to heaven. Instead, he pounded on his chest and prayed, 'God, please be merciful to me because I am a sinner.'"
34:10 Then Jesus said, "I tell you the truth, God heard the tax collector's prayer and declared him to be righteous."
35:01 One day, Jesus was teaching many tax collectors and other sinners who had gathered to hear him.

#### Word Data:####

* Tax: Strong's: H2670, H4060, H4371, H4522, H4864, H6186, G583, G5411
* Tax Collector: Strong's: H5065, H5674, G5057, G5058


---

<a id="teach"/>

### teach, teaches, taught, teaching, teachings, untaught ###

#### Definition: ####

To "teach" someone is to tell him something he doesn’t already know. It can also mean to "provide information" in general, with no reference to the person who is learning. Usually the information is given in a formal or systematic way. A person’s "teaching" is or his "teachings" are what he has taught.

* A "teacher" is someone who teaches. The past action of "teach" is "taught."
* When Jesus was teaching, he was explaining things about God and his kingdom.
* Jesus' disciples called him "Teacher" as a respectful form of address for someone who taught people about God.
* The information that is being taught can be shown or spoken.
* The term "doctrine" refers to a set of teachings from God about himself as well as God's instructions about how to live. This could also be translated as "teachings from God" or "what God teaches us."
* The phrase "what you have been taught" could also be translated as, "what these people have taught you" or "what God has taught you," depending on the context.
* Other ways to translate "teach" could include "tell" or "explain" or "instruct."
* Often this term can be translated as "teaching people about God."

(See also: [instruct](#instruct), [teacher](#teacher), [word of God](kt.html#wordofgod))

#### Bible References: ####

* [1 Timothy 01:3-4](https://git.door43.org/Door43/en_tn/src/master/1ti/01/03.md)
* [Acts 02:40-42](https://git.door43.org/Door43/en_tn/src/master/act/02/40.md)
* [John 07:14-16](https://git.door43.org/Door43/en_tn/src/master/jhn/07/14.md)
* [Luke 04:31-32](https://git.door43.org/Door43/en_tn/src/master/luk/04/31.md)
* [Matthew 04:23-25](https://git.door43.org/Door43/en_tn/src/master/mat/04/23.md)
* [Psalms 032:7-8](https://git.door43.org/Door43/en_tn/src/master/psa/032/007.md)

#### Word Data: ####

* Strong's: H502, H2094, H2449, H3045, H3046, H3256, H3384, H3925, H3948, H7919, H8150, G1317, G1321, G1322, G2085, G2605, G2727, G3100, G2312, G2567, G3811, G4994


---

<a id="teacher"/>

### teacher, teachers, Teacher ###

#### Definition: ####

A teacher is a person who gives other people new information. Teachers help others to obtain and use both knowledge and skills.

* In the Bible, the word "teacher" is used in a special sense to refer to someone who teaches about God. 
* People who learn from a teacher are called "students" or "disciples."
* In some Bible translations, this term is capitalized ("Teacher") when it is used as a title for Jesus.

#### Translation Suggestions: ####

* The usual word for a teacher can be used to translate this term, unless that word is only used for a school teacher.
* Some cultures may have a special title that is used for religious teachers, such as "Sir" or "Rabbi" or "Preacher."
 

(See also: [disciple](kt.html#disciple), [preach](#preach))

#### Bible References: ####

* [Ecclesiastes 01:12-15](https://git.door43.org/Door43/en_tn/src/master/ecc/01/12.md)
* [Ephesians 04:11-13](https://git.door43.org/Door43/en_tn/src/master/eph/04/11.md)
* [Galatians 06:6-8](https://git.door43.org/Door43/en_tn/src/master/gal/06/06.md)
* [Habakkuk 02:18-20](https://git.door43.org/Door43/en_tn/src/master/hab/02/18.md)
* [James 03:1-2](https://git.door43.org/Door43/en_tn/src/master/jas/03/01.md)
* [John 01:37-39](https://git.door43.org/Door43/en_tn/src/master/jhn/01/37.md)
* [Luke 06:39-40](https://git.door43.org/Door43/en_tn/src/master/luk/06/39.md)
* [Matthew 12:38-40](https://git.door43.org/Door43/en_tn/src/master/mat/12/38.md)

#### Examples from the Bible stories: ####

* __[27:01](https://git.door43.org/Door43/en_tn/src/master/obs/27/01.md)__ One day, an expert in the Jewish law came to Jesus to test him, saying, "__Teacher__, what must I do to inherit eternal life?"
* __[28:01](https://git.door43.org/Door43/en_tn/src/master/obs/28/01.md)__ One day a rich young ruler came up to Jesus and asked him, "Good __Teacher__, what must I do to have eternal life?"
* __[37:02](https://git.door43.org/Door43/en_tn/src/master/obs/37/02.md)__ After the two days had passed, Jesus said to his disciples, "Let's go back to Judea." "But __Teacher__," the disciples answered, "Just a short time ago the people there wanted to kill you!"
* __[38:14](https://git.door43.org/Door43/en_tn/src/master/obs/38/14.md)__ Judas came to Jesus and said, "Greetings, __Teacher__," and kissed him.
* __[49:03](https://git.door43.org/Door43/en_tn/src/master/obs/49/03.md)__ Jesus was also a great __teacher__, and he spoke with authority because he is the Son of God.

#### Word Data: ####

* Strong's: H3384, H3887, H3925, G1320, G2567, G3547, G5572


---

<a id="tencommandments"/>

### Ten Commandments ###

#### Facts: ####

The "Ten Commandments" were commands that God gave to Moses on Mount Sinai while the Israelites were living in the desert on their way to the land of Canaan. God wrote these commands on two large slabs of stone.

* God gave the Israelites many commands to obey, but the Ten Commandments were special commands to help the Israelites love and worship God and love other people.
* These commandments were also part of God's covenant with his people. By obeying what God had commanded them to do, the people of Israel would show that they loved God and belonged to him.
* The stone slabs with the commandments written on them were kept in the Ark of the Covenant, which was located in the most holy place of the tabernacle and later, the temple.

(See also: [ark of the covenant](kt.html#arkofthecovenant), [command](kt.html#command), [covenant](kt.html#covenant), [desert](#desert), [law](kt.html#lawofmoses), [obey](#obey), [Sinai](names.html#sinai), [worship](kt.html#worship))

#### Bible References: ####

* [Deuteronomy 04:13-14](https://git.door43.org/Door43/en_tn/src/master/deu/04/13.md)
* [Deuteronomy 10:3-4](https://git.door43.org/Door43/en_tn/src/master/deu/10/03.md)
* [Exodus 34:27-28](https://git.door43.org/Door43/en_tn/src/master/exo/34/27.md)
* [Luke 18:18-21](https://git.door43.org/Door43/en_tn/src/master/luk/18/18.md)

#### Examples from the Bible stories: ####

  __*[13:07](https://git.door43.org/Door43/en_tn/src/master/obs/13/07.md)__  Then God wrote these __Ten Commandments__ on two stone tablets and gave them to Moses.
  __*[13:13](https://git.door43.org/Door43/en_tn/src/master/obs/13/13.md)__  When Moses came down the mountain and saw the idol, he was so angry that he smashed the stones on which God had written the __Ten Commandments__. 
  __*[13:15](https://git.door43.org/Door43/en_tn/src/master/obs/13/15.md)__  Moses wrote the __Ten Commandments__ on new stone tablets to replace the ones he had broken.

#### Word Data:####

* Strong's: H1697, H6235


---

<a id="tent"/>

### tent, tents, tentmakers ###

#### Definition: ####

A tent is a portable shelter made of sturdy fabric that is draped over a structure of poles and attached to them.

* Tents can be small, with just enough space for a few people to sleep in, or they can be very large, with space for an entire family to sleep, cook, and live in.
* For many people, tents are used as permanent dwelling places. For example, during most of the time that Abraham's family lived in the land of Canaan, they dwelled in large tents constucted from sturdy cloth made of goat hair.
* The Israelites also lived in tents during their forty-year wanderings through the desert of Sinai.
* The tabernacle building was a kind of very large tent, with thick walls made of cloth curtains.
* When the apostle Paul traveled to different cities to share the gospel, he supported himself by making tents.
* The term "tents" is sometimes used figuratively to refer generally to where people live. This could also be translated as "homes" or "dwellings" or "houses" or even "bodies." (See: [synecdoche](https://git.door43.org/Door43/en_ta/src/master/translate/figs-synecdoche.md))

(See also: [Abraham](names.html#abraham), [Canaan](names.html#canaan), [curtain](#curtain), [Paul](names.html#paul), [Sinai](names.html#sinai), [tabernacle](kt.html#tabernacle), [tent of meeting](#tentofmeeting))

#### Bible References: ####

* [1 Chronicles 05:10](https://git.door43.org/Door43/en_tn/src/master/1ch/05/10.md)
* [Daniel 11:44-45](https://git.door43.org/Door43/en_tn/src/master/dan/11/44.md)
* [Exodus 16:16-18](https://git.door43.org/Door43/en_tn/src/master/exo/16/16.md)
* [Genesis 12:8-9](https://git.door43.org/Door43/en_tn/src/master/gen/12/08.md)

#### Word Data:####

* Strong's: H167, H168, H2583, H3407, H6898


---

<a id="tenth"/>

### tenth, tenths, tithe, tithes ###

#### Definition: ####

The terms "tenth" and "tithe" refer to "ten percent" or "one-out-of-ten portion" of one's money, crops, livestock, or other possessions, which is given to God.

* In the Old Testament, God instructed the Israelites to set aside a tenth of their belongings to give as an offering of thanksgiving to him.
* This offering was used to support the Levite tribe of Israel who served the Israelites as priests and caretakers of the tabernacle and later, the temple.
* In the New Testament, God does not require giving a tithe, but instead he instructs believers to generously and cheerfully help people in need and support the work of Christian ministry.
* This could also be translated as "one-tenth" or "one out of ten."

(See also: [believe](kt.html#believe), [Israel](kt.html#israel), [Levite](names.html#levite), [livestock](#livestock), [Melchizedek](names.html#melchizedek), [minister](kt.html#minister), [sacrifice](#sacrifice)  [tabernacle](kt.html#tabernacle), [temple](kt.html#temple))

#### Bible References: ####

* [Genesis 14:19-20](https://git.door43.org/Door43/en_tn/src/master/gen/14/19.md)
* [Genesis 28:20-22](https://git.door43.org/Door43/en_tn/src/master/gen/28/20.md)
* [Hebrews 07:4-6](https://git.door43.org/Door43/en_tn/src/master/heb/07/04.md)
* [Isaiah 06:13](https://git.door43.org/Door43/en_tn/src/master/isa/06/13.md)
* [Luke 11:42](https://git.door43.org/Door43/en_tn/src/master/luk/11/42.md)
* [Luke 18:11-12](https://git.door43.org/Door43/en_tn/src/master/luk/18/11.md)
* [Matthew 23:23-24](https://git.door43.org/Door43/en_tn/src/master/mat/23/23.md)

#### Word Data:####

* Strong's: H4643, H6237, H6241, G586, G1181, G1183


---

<a id="tentofmeeting"/>

### tent of meeting ###

#### Facts: ####

The term "tent of meeting" refers to a tent which was a temporary place where God met with Moses before the tabernacle was built.

* The tent of meeting was set up outside the camp of the Israelites.
* When Moses went into the tent of meeting to meet with God, a pillar of cloud would stand at the entrance to the tent as a sign of God's presence there. 
* After the Israelites built the tabernacle, the temporary tent was no longer needed and the term "tent of meeting" was sometimes used to refer to the tabernacle. 

(See also: [Israel](kt.html#israel), [Moses](names.html#moses), [pillar](#pillar), [tabernacle](kt.html#tabernacle), [tent](#tent))

#### Bible References: ####

* [1 Kings 02:28-29](https://git.door43.org/Door43/en_tn/src/master/1ki/02/28.md)
* [Joshua 19:51](https://git.door43.org/Door43/en_tn/src/master/jos/19/51.md)
* [Leviticus 01:1-2](https://git.door43.org/Door43/en_tn/src/master/lev/01/01.md)
* [Numbers 04:31-32](https://git.door43.org/Door43/en_tn/src/master/num/04/31.md)

#### Examples from the Bible stories: ####

  __*[13:08](https://git.door43.org/Door43/en_tn/src/master/obs/13/08.md)__ God gave the Israelites a detailed description of a tent he wanted them to make. It was called the __Tent of Meeting__, and it had two rooms, separated by a large curtain. 
  __*[13:09](https://git.door43.org/Door43/en_tn/src/master/obs/13/09.md)__ Anyone who disobeyed God's law could bring an animal to the altar in front of the __Tent of Meeting__ as a sacrifice to God. 
  __*[14:08](https://git.door43.org/Door43/en_tn/src/master/obs/14/08.md)__ God was very angry and came to the __Tent of Meeting__. 
  __*[18:02](https://git.door43.org/Door43/en_tn/src/master/obs/18/02.md)__ Instead of at the __Tent of Meeting__, people now worshiped God and offered sacrifices to him at the Temple.

#### Word Data:####

* Strong's: H168, H4150


---

<a id="terror"/>

### terror, terrorize, terrorized, terrors, terrify, terrified, terrifying ###

#### Definition: ####

The term "terror" refers to a feeling of extreme fear. To "terrify" someone means to cause that person to feel very afraid.

* A "terror" is something or someone that causes great fear or dread. An example of a terror could be an attacking enemy army or a plague or disease that is widespread, killing many people.
* These terrors can be described as "terrifying." This term could be translated as, "fear-causing" or "terror-producing."
* The judgment of God will someday cause terror in unrepentant people who reject his grace.
* The "terror of Yahweh" could be translated as "the terrifying presence of Yahweh" or "the dreaded judgment of Yahweh" or "when Yahweh causes great fear."
* Ways to translate "terror" could also include "extreme fear" or "deep dread."

(See also: [adversary](#adversary), [fear](kt.html#fear), [judge](kt.html#judge), [plague](#plague), [Yahweh](kt.html#yahweh))

#### Bible References: ####

* [Deuteronomy 02:24-25](https://git.door43.org/Door43/en_tn/src/master/deu/02/24.md)
* [Exodus 14:10-12](https://git.door43.org/Door43/en_tn/src/master/exo/14/10.md)
* [Luke 21:7-9](https://git.door43.org/Door43/en_tn/src/master/luk/21/07.md)
* [Mark 06:48-50](https://git.door43.org/Door43/en_tn/src/master/mrk/06/48.md)
* [Matthew 28:5-7](https://git.door43.org/Door43/en_tn/src/master/mat/28/05.md)

#### Word Data:####

* Strong's: H367, H926, H928, H1091, H1161, H1204, H1763, H2111, H2189, H2283, H2731, H2847, H2851, H2865, H3372, H3707, H4032, H4048, H4172, H4288, H4637, H6184, H6206, H6343, H6973, H8541, G1629, G1630, G2258, G4422, G4426, G5401


---

<a id="thief"/>

### thief, thieves, rob, robs, robbed, robber, robbers, robbery, robbing ###

#### Facts: ####

The term "thief" refers to a person who steals money or property from other people. The plural of "theif" is "theives." The term "robber" often refers to a thief who also physically harms or threatens the people he is stealing from.

* Jesus told a parable about a Samaritan man who took care of a Jewish man who had been attacked by robbers. The robbers had beaten the Jewish man and wounded him before stealing his money and clothing.
* Both thieves and robbers come suddenly to steal, when people are not expecting it. Often they use the cover of darkness to hide what they are doing.
* In a figurative sense, the New Testament describes Satan as a thief who comes to steal, kill, and destroy. This means that Satan's plan is to try to get God's people to stop obeying him. If he succeeded in doing this Satan would be stealing from them the good things that God has planned for them.
* Jesus compared the suddenness of his return to the suddenness of a thief coming to steal from people. Just as a thief comes at a time when people are not expecting it, so Jesus will return at a time when people do not expect it.

(See also: [bless](kt.html#bless), [crime](#criminal), [crucify](kt.html#crucify), [darkness](#darkness), [destroyer](#destroyer), [power](kt.html#power), [Samaria](names.html#samaria), [Satan](kt.html#satan))

#### Bible References: ####

* [2 Peter 03:10](https://git.door43.org/Door43/en_tn/src/master/2pe/03/10.md)
* [Luke 12:33-34](https://git.door43.org/Door43/en_tn/src/master/luk/12/33.md)
* [Mark 14:47-50](https://git.door43.org/Door43/en_tn/src/master/mrk/14/47.md)
* [Proverbs 06:30-31](https://git.door43.org/Door43/en_tn/src/master/pro/06/30.md)
* [Revelation 03:3-4](https://git.door43.org/Door43/en_tn/src/master/rev/03/03.md)

#### Word Data:####

* Strong's: H1214, H1215, H1416, H1589, H1590, H1980, H6530, H6782, H7703, G727, G1888, G2417, G2812, G3027


---

<a id="thorn"/>

### thorn, thornbush, thornbushes, thorns, thistle, thistles ###

#### Facts: ####

Thorn bushes and thistles are plants that have prickly branches or flowers. These plants do not produce fruit or anything else that is useful.

* A "thorn" is a hard, sharp growth on the branch or stem of a plant. A "thornbush" is a type of small tree or shrub that has many thorns on its branches.
* A "thistle" is a plant with prickly stems and leaves. Often the flowers are purple.
* Thorn and thistle plants multiply quickly and can cause nearby plants or crops to not be able to grow. This is a picture of how sin keeps a person from producing good spiritual fruit. 
* A crown made of twisted thorn branches was placed on Jesus' head before he was crucified. 
* If possible, these terms should be translated by the names of two different plants or bushes that are known in the language area.

(See also: [crown](#crown), [fruit](#fruit), [spirit](kt.html#spirit))

#### Bible References: ####

* [Hebrews 06:7-8](https://git.door43.org/Door43/en_tn/src/master/heb/06/07.md)
* [Matthew 13:7-9](https://git.door43.org/Door43/en_tn/src/master/mat/13/07.md)
* [Matthew 13:22-23](https://git.door43.org/Door43/en_tn/src/master/mat/13/22.md)
* [Numbers 33:55-56](https://git.door43.org/Door43/en_tn/src/master/num/33/55.md)

#### Word Data:####

* Strong's: H329, H1863, H2312, H2336, H4534, H5285, H5518, H5544, H6791, H6796, H6975, H7063, H7898, G173, G174, G4647, G5146


---

<a id="thresh"/>

### thresh, threshes, threshed, threshing ###

#### Definition: ####

The terms "thresh" and "threshing" refer to the first part of the process of separating wheat grain from the rest of the wheat plant. 

* Threshing the wheat plant loosens the grain from the straw and the chaff. Afterwards the grain is "winnowed" to completely separate the grain from all unwanted materials, leaving only the part the grain that can be eaten.
* In Bible times, a "threshing floor" was a large flat rock or an area of packed-down dirt, giving a hard, level surface to crush the grain stalks and remove the grain.
* A "threshing cart" or "threshing wheel" was sometimes used to crush the grain and help separate it from the straw and chaff.
* A "threshing sledge" or "threshing board" was also used for separating grain. It was made of wooden boards that had sharp metal spikes on the end.

(See also: [chaff](#chaff), [grain](#grain), [winnow](#winnow))

#### Bible References: ####

* [2 Chronicles 03:1-3](https://git.door43.org/Door43/en_tn/src/master/2ch/03/01.md)
* [2 Kings 13:6-7](https://git.door43.org/Door43/en_tn/src/master/2ki/13/06.md)
* [2 Samuel 24:15-16](https://git.door43.org/Door43/en_tn/src/master/2sa/24/15.md)
* [Daniel 02:34-35](https://git.door43.org/Door43/en_tn/src/master/dan/02/34.md)
* [Luke 03:17](https://git.door43.org/Door43/en_tn/src/master/luk/03/17.md)
* [Matthew 03:10-12](https://git.door43.org/Door43/en_tn/src/master/mat/03/10.md)
* [Ruth 03:1-2](https://git.door43.org/Door43/en_tn/src/master/rut/03/01.md)

#### Word Data:####

* Strong's: H212, H4173, H1637, H1758, H1786, H1869, H2251, G248


---

<a id="threshold"/>

### threshold, thresholds ###

#### Definition: ####

The term "threshold" refers to the bottom part of a doorway or the part of a building that is just inside the door.

* Sometimes a threshold is a strip of wood or stone that must be stepped over in order to enter a room or building.
* Both a gate and the opening to a tent can also have a threshold.
* This term should be translated with a term in the project language that refers to the place at the very entrance to a home that a person steps across.
* If there is no term for this, "threshold" could also be translated as "doorway" or "opening" or "entranceway," depending on the context.

(See also: [gate](#gate), [tent](#tent))

#### Bible References: ####

* [1 Chronicles 09:17-19](https://git.door43.org/Door43/en_tn/src/master/1ch/09/17.md)
* [Ezekiel 09:3-4](https://git.door43.org/Door43/en_tn/src/master/ezk/09/03.md)
* [Isaiah 06:4-5](https://git.door43.org/Door43/en_tn/src/master/isa/06/04.md)
* [Proverbs 17:19-20](https://git.door43.org/Door43/en_tn/src/master/pro/17/19.md)

#### Word Data:####

* Strong's: H624, H4670, H5592


---

<a id="throne"/>

### throne, thrones, enthroned ###

#### Definition: ####

A throne is a specially-designed chair where a ruler sits when he decides important matters and listens to requests from his people.

* A throne is also a symbol of the authority and power that a ruler has.
* The word "throne" is often used figuratively to refer to the ruler, his reign, or his power. (See: [metonymy](https://git.door43.org/Door43/en_ta/src/master/translate/figs-metonymy.md)) 
* In the Bible, God was often portrayed as a king who sits on his throne. Jesus was described as sitting on a throne at the right hand of God the Father.
* Jesus said that heaven is God's throne. One way to translate this could be, "where God reigns as king."

(See also: [authority](kt.html#authority), [power](kt.html#power), [king](#king), [reign](#reign))

#### Bible References: ####

* [Colossians 01:15-17](https://git.door43.org/Door43/en_tn/src/master/col/01/15.md)
* [Genesis 41:39-41](https://git.door43.org/Door43/en_tn/src/master/gen/41/39.md)
* [Luke 01:30-33](https://git.door43.org/Door43/en_tn/src/master/luk/01/30.md)
* [Luke 22:28-30](https://git.door43.org/Door43/en_tn/src/master/luk/22/28.md)
* [Matthew 05:33-35](https://git.door43.org/Door43/en_tn/src/master/mat/05/33.md)
* [Matthew 19:28](https://git.door43.org/Door43/en_tn/src/master/mat/19/28.md)
* [Revelation 01:4-6](https://git.door43.org/Door43/en_tn/src/master/rev/01/04.md)

#### Word Data:####

* Strong's: H3427, H3676, H3678, H3764, H7675, G968, G2362


---

<a id="time"/>

### time, timely, times, untimely ###

#### Facts: ####

In the Bible the term "time" was often used figuratively to refer to a specific season or period of time when certain events took place. It has a meaning similar to "age" or "epoch" or "season."

* In both Daniel and Revelation speak of a "time" of great trouble or tribulation that will come upon the earth.
* In the phrase "time, times, and half a time" the term "time" means "year." This phrase refers to a three-and-a-half-year period of time during the great tribulation at the end of this present age.
* "Time" can mean "occasion" in a phrase like "third time." The phrase "many times" can mean "on many occasions."
* To be "on time" means to arrive when expected, not late.
* Depending on the context, the term "time" could be translated as, "season" or "time period" or "moment" or "event" or "occurrence."
* The phrase "times and seasons" is a figurative expression which states the same idea twice. This could also be translated as "certain events happening in certain time periods." (See: [doublet](https://git.door43.org/Door43/en_ta/src/master/translate/figs-doublet.md))

(See also: [age](#age), [tribulation](#tribulation))

#### Bible References: ####

* [Acts 01:6-8](https://git.door43.org/Door43/en_tn/src/master/act/01/06.md)
* [Daniel 12:1-2](https://git.door43.org/Door43/en_tn/src/master/dan/12/01.md)
* [Mark 11:11-12](https://git.door43.org/Door43/en_tn/src/master/mrk/11/11.md)
* [Matthew 08:28-29](https://git.door43.org/Door43/en_tn/src/master/mat/08/28.md)
* [Psalms 068:28-29](https://git.door43.org/Door43/en_tn/src/master/psa/068/028.md)
* [Revelation 14:14-16](https://git.door43.org/Door43/en_tn/src/master/rev/14/14.md)

#### Word Data:####

* Strong's: H116, H227, H268, H310, H570, H865, H1697, H1755, H2165, H2166, H2233, H2465, H3027, H3117, H3118, H3119, H3259, H3427, H3706, H3967, H4150, H4279, H4489, H4557, H5331, H5703, H5732, H5750, H5769, H6049, H6235, H6256, H6258, H6440, H6471, H6635, H6924, H7105, H7138, H7223, H7272, H7281, H7637, H7651, H7655, H7659, H7674, H7992, H8027, H8032, H8138, H8145, H8462, H8543, G744, G530, G1074, G1208, G1441, G1597, G1626, G1909, G2034, G2119, G2121, G2235, G2250, G2540, G3379, G3461, G3568, G3763, G3764, G3819, G3956, G3999, G4178, G4181, G4183, G4218, G4277, G4287, G4340, G4455, G5119, G5151, G5305, G5550, G5551, G5610


---

<a id="tomb"/>

### grave, gravediggers, graves, tomb, tombs, burial place ###

#### Definition: ####

The terms "tomb" and "grave" refer to a place where people put the body of a person who has died. A "burial place" is a more general term that also refers to this.

* The Jews sometimes used natural caves as tombs, and sometimes they dug caves into rock in the side of a hill.
* In New Testament times, it was common to roll a large, heavy stone in front of the opening of a tomb in order to close it.
* If the target language the word for a tomb can only refer to a hole in which the body is placed below the ground, other ways to translate this could include "cave" or "hole in the side of a hill."
* The phrase "the grave" is often used generally and figuratively to refer to the condition of being dead or a place where the souls of dead people are.

(See also: [bury](#bury), [death](#death))

#### Bible References: ####

* [Acts 02:29-31](https://git.door43.org/Door43/en_tn/src/master/act/02/29.md)
* [Genesis 23:5-6](https://git.door43.org/Door43/en_tn/src/master/gen/23/05.md)
* [Genesis 50:4-6](https://git.door43.org/Door43/en_tn/src/master/gen/50/04.md)
* [John 19:40-42](https://git.door43.org/Door43/en_tn/src/master/jhn/19/40.md)
* [Luke 23:52-53](https://git.door43.org/Door43/en_tn/src/master/luk/23/52.md)
* [Mark 05:1-2](https://git.door43.org/Door43/en_tn/src/master/mrk/05/01.md)
* [Matthew 27:51-53](https://git.door43.org/Door43/en_tn/src/master/mat/27/51.md)
* [Romans 03:13-14](https://git.door43.org/Door43/en_tn/src/master/rom/03/13.md)

#### Examples from the Bible stories: ####

* __[32:04](https://git.door43.org/Door43/en_tn/src/master/obs/32/04.md)__ The man lived among the __tombs__  in the area.
* __[37:06](https://git.door43.org/Door43/en_tn/src/master/obs/37/06.md)__ Jesus asked them, "Where have you put Lazarus?" They told him, "In the __tomb__. Come and see."
* __[37:07](https://git.door43.org/Door43/en_tn/src/master/obs/37/07.md)__ The __tomb__  was a cave with a stone rolled in front of its opening.
* __[40:09](https://git.door43.org/Door43/en_tn/src/master/obs/40/09.md)__ Then Joseph and Nicodemus, two Jewish leaders who believed Jesus was the Messiah, asked Pilate for Jesus' body. They wrapped his body in cloth and placed it in a __tomb__  cut out of rock. Then they rolled a large stone in front the __tomb__  to block the opening.
* __[41:04](https://git.door43.org/Door43/en_tn/src/master/obs/41/04.md)__ He (the angel) rolled away the stone that was covering the entrance to the __tomb__  and sat on it. The soldiers guarding the __tomb__  were terrified and fell to the ground like dead men.
* __[41:05](https://git.door43.org/Door43/en_tn/src/master/obs/41/05.md)__ When the women arrived at the __tomb__, the angel told them, "Do not be afraid. Jesus is not here. He has risen from the dead, just like he said he would! Look in the __tomb__  and see." The women looked into the __tomb__  and saw where Jesus' body had been laid. His body was not there!

#### Word Data:####

* Strong's: H1164, H1430, H6900, H6913, H7585, H7845, G86, G2750, G3418, G3419, G5028


---

<a id="tongue"/>

### tongue, tongues ###

#### Definition: ####

There are several figurative meanings of "tongue" in the Bible. 

* In the Bible, the most common figurative meaning for this term is "language" or "speech."
* Sometimes "tongue" may refer to a human language spoken by a certain people group.
* Other times it refers to a supernatural language that the Holy Spirit gives believers in Christ as one of the "gifts of the Spirit."
* The expression "tongues" of fire refers to "flames" of fire.
* In the expression "my tongue rejoices," the term "tongue" refers to the whole person. (See: [synecdoche](https://git.door43.org/Door43/en_ta/src/master/translate/figs-synecdoche.md))
* The phrase "lying tongue" refers to a person's voice or speech. (See: [metonymy](https://git.door43.org/Door43/en_ta/src/master/translate/figs-metonymy.md))

#### Translation Suggestions ####

* Depending on the context, the term "tongue" can be translated by "language" or "spiritual language." If it is not clear which one it is referring to, it is better to translate it as "language."
* When referring to fire, this term could be translated as "flames."
* The expression "my tongue rejoices" could be translated as "I rejoice and praise God" or "I am joyfully praising God."
* The phrase, "tongue that lies" could be translated as "person who tell lies" or "people who lie."
* Phrases such as "with their tongues" could be translated as "with what they say" or "by their words."

(See also: [gift](kt.html#gift), [Holy Spirit](kt.html#holyspirit), [joy](#joy), [praise](#praise), [rejoice](#joy), [spirit](kt.html#spirit))

#### Bible References: ####

* [1 Corinthians 12:9-11](https://git.door43.org/Door43/en_tn/src/master/1co/12/09.md)
* [1 John 03:16-18](https://git.door43.org/Door43/en_tn/src/master/1jn/03/16.md)
* [2 Samuel 23:1-2](https://git.door43.org/Door43/en_tn/src/master/2sa/23/01.md)
* [Acts 02:25-26](https://git.door43.org/Door43/en_tn/src/master/act/02/25.md)
* [Ezekiel 36:1-3](https://git.door43.org/Door43/en_tn/src/master/ezk/36/01.md)
* [Philippians 02:9-11](https://git.door43.org/Door43/en_tn/src/master/php/02/09.md)

#### Word Data:####

* Strong's: H762, H2013, H2790, H3956, G1100, G1258, G1447, G2084


---

<a id="torment"/>

### torment, tormented, tormenting, tormentors ###

#### Facts: ####

The term "torment" refers to terrible suffering. To torment someone means to cause that person to suffer, often in a cruel way.

* Sometimes the term "torment" refers to physical pain and suffering. For example, the book of Revelation describes physical torment that worshipers of the "beast" will suffer in the end times.
* Suffering may also take the form of spiritual and emotional pain, as experienced by Job.
* The apostle John wrote in the book of Revelation that people who do not believe in Jesus as their Savior will experience eternal torment in the lake of fire.
* This term could be translated as "terrible suffering" or "cause someone to suffer greatly" or "agony." Some translators may add "physical" or "spiritual" to make the meaning clear.


(See also: [beast](#beast), [everlasting](kt.html#eternity), [Job](names.html#job), [Savior](kt.html#savior), [spirit](kt.html#spirit), [suffer](#suffer), [worship](kt.html#worship))

#### Bible References: ####

* [2 Peter 02:7-9](https://git.door43.org/Door43/en_tn/src/master/2pe/02/07.md)
* [Jeremiah 30:20-22](https://git.door43.org/Door43/en_tn/src/master/jer/30/20.md)
* [Lamentations 01:11-12](https://git.door43.org/Door43/en_tn/src/master/lam/01/11.md)
* [Luke 08:28-29](https://git.door43.org/Door43/en_tn/src/master/luk/08/28.md)
* [Revelation 11:10-12](https://git.door43.org/Door43/en_tn/src/master/rev/11/10.md)

#### Word Data:####

* Strong's: H3013, G928, G929, G930, G931, G2558, G2851, G3600


---

<a id="tradition"/>

### tradition, traditions ###

#### Definition: ####

The term "tradition" refers to a custom or practice that has been kept over time and which is passed down to people in later generations.

* Often in the Bible the word "traditions" referred to teachings and practices that people made, not God's laws. The expression "tradition of men" or "human tradition" makes this clear.
* Phrases such as "traditions of the elders" or "traditions of my fathers" referred specifically to Jewish customs and practices that Jewish leaders over time had added to the laws God gave to the Israelites through Moses. Even though these added traditions had not come from God, people thought they had to obey them in order to be righteous.
* The apostle Paul used the term "tradition" in a different way to refer to teachings about Christian practice that came from God and that he and other apostles had taught new believers.
* In modern times, there are many Christian traditions that are not taught in the Bible, but rather are the result of historically accepted customs and practices. These traditions should always be evaluated in light of what God teaches us in the Bible.


(See also: [apostle](kt.html#apostle), [believe](kt.html#believe), [Christian](kt.html#christian), [ancestor](#father), [generation](#generation), [Jew](kt.html#jew), [law](kt.html#lawofmoses), [Moses](names.html#moses))

#### Bible References: ####

* [2 Thessalonians 03:6-9](https://git.door43.org/Door43/en_tn/src/master/2th/03/06.md)
* [Colossians 02:8-9](https://git.door43.org/Door43/en_tn/src/master/col/02/08.md)
* [Galatians 01:13-14](https://git.door43.org/Door43/en_tn/src/master/gal/01/13.md)
* [Mark 07:2-4](https://git.door43.org/Door43/en_tn/src/master/mrk/07/02.md)
* [Matthew 15:1-3](https://git.door43.org/Door43/en_tn/src/master/mat/15/01.md)

#### Word Data:####

* Strong's: G3862, G3970


---

<a id="trample"/>

### trample, tramples, trampled, trampling ###

#### Definition: ####

To "trample" means to step on something and smash it with the feet. This term is also used figuratively in the Bible to mean "destroy" or "defeat" or "humiliate."

* An example of "trampling" would be the smashing down of grass by the feet of people running in a field..
* In ancient times, wine was sometimes made by trampling grapes to remove the juice from them.
* Sometimes the term to "trample" has a figurative meaning of to "punish by humiliating," comparing it to trampling mud for a threshing floor.
* The term "trample" was used figuratively to express how Yahweh would punish his people Israel for their pride and rebellion.
* Other ways that "trample" could be translated include "crush with the feet" or "smash down with the feet" or "stomp on and crush" or "smash into the ground."
* Depending on the context, this term could also be translated 


(See also: [grape](#grape), [humiliate](#humiliate), [punish](#punish), [rebel](#rebel), [thresh](#thresh), [wine](#wine))

#### Bible References: ####

* [Hebrews 10:28-29](https://git.door43.org/Door43/en_tn/src/master/heb/10/28.md)
* [Psalms 007:5](https://git.door43.org/Door43/en_tn/src/master/psa/007/005.md)

#### Word Data:####

* Strong's: H947, H1758, H1869, H4001, H4823, H7429, H7512, G2662, G3961


---

<a id="tremble"/>

### tremble, trembles, trembled, trembling ###

#### Definition: ####

To "tremble" means to shake or quiver out of fear or extreme distress.

* This term is also used figuratively to mean "be very afraid."
* Sometimes when the ground shakes it is said to "tremble." It can do this during an earthquake or in response to  a very loud noise.
* The Bible says that in the presence of the Lord the earth will tremble. This could mean that the people of the earth will shake out of fear of God or that the earth itself will shake.
* This term could be translated as "be afraid" or "fear God" or "shake," depending on the context.


(See also: [earth](#earth), [fear](kt.html#fear), [Lord](kt.html#lord))

#### Bible References: ####

* [2 Corinthians 07:15-16](https://git.door43.org/Door43/en_tn/src/master/2co/07/15.md)
* [2 Samuel 22:44-46](https://git.door43.org/Door43/en_tn/src/master/2sa/22/44.md)
* [Acts 16:29-31](https://git.door43.org/Door43/en_tn/src/master/act/16/29.md)
* [Jeremiah 05:20-22](https://git.door43.org/Door43/en_tn/src/master/jer/05/20.md)
* [Luke 08:47-48](https://git.door43.org/Door43/en_tn/src/master/luk/08/47.md)

#### Word Data:####

* Strong's: H1674, H2111, H2112, H2151, H2342, H2648, H2729, H2730, H2731, H5128, H5568, H6342, H6426, H6427, H7264, H7268, H7269, H7322, H7460, H7461, H7478, H7481, H7493, H7578, H8078, H8653, G1719, G1790, G5141, G5156, G5425


---

<a id="trial"/>

### trial, trials ###

#### Definition: ####

The term "trial" refers to a situation in which something or someone is "tried" or tested.

* A trial can be a judicial hearing in which evidence is given to prove whether a person is innocent or guilty of wrongdoing.
* The term "trial" can also refer to difficult circumstances that a person goes through as God tests their faith. Another word for this is "a testing" or "a temptation" is one particular type of trial.
* Many people in the Bible were tested to see if they would continue to believe and obey God. They went through trials which included being beaten, imprisoned, or even killed because of their faith.

(See also: [tempt](kt.html#tempt), [test](kt.html#test), [innocent](kt.html#innocent), [guilt](kt.html#guilt))

#### Bible References: ####

* [Deuteronomy 04:34](https://git.door43.org/Door43/en_tn/src/master/deu/04/34.md)
* [Ezekiel 21:12-13](https://git.door43.org/Door43/en_tn/src/master/ezk/21/12.md)
* [Lamentations 03:58-61](https://git.door43.org/Door43/en_tn/src/master/lam/03/58.md)
* [Proverbs 25:7-8](https://git.door43.org/Door43/en_tn/src/master/pro/25/07.md)

#### Word Data:####

* Strong's: H974, H4531, H4941, H7378, G178, G1382, G1383, G2919, G3984, G3986, G4451


---

<a id="tribe"/>

### tribe, tribes, tribal, tribesmen ###

#### Definition: ####

A tribe is a group of people who are descended from a common ancestor. 

* People from the same tribe usually also share a common language and culture.
* In the Old Testament, God divided the people of Israel into twelve tribes. Each tribe was descended from a son or grandson of Jacob.
* A tribe is smaller than a nation, but larger than a clan.

(See also: [clan](#clan), [nation](#nation), [people group](#peoplegroup), [twelve tribes of Israel](#12tribesofisrael))

#### Bible References: ####

* [1 Samuel 10:17-19](https://git.door43.org/Door43/en_tn/src/master/1sa/10/17.md)
* [2 Kings 17:16-18](https://git.door43.org/Door43/en_tn/src/master/2ki/17/16.md)
* [Genesis 25:13-16](https://git.door43.org/Door43/en_tn/src/master/gen/25/13.md)
* [Genesis 49:16-18](https://git.door43.org/Door43/en_tn/src/master/gen/49/16.md)
* [Luke 02:36-38](https://git.door43.org/Door43/en_tn/src/master/luk/02/36.md)

#### Word Data:####

* Strong's: H523, H4294, H7625, H7626, G1429, G5443


---

<a id="tribulation"/>

### tribulation ###

#### Definition: ####

The term "tribulation" refers to a time of hardship, suffering, and distress.

* It is explained in the New Testament that Christians will endure times of persecution and other kinds of tribulation because many people in this world are opposed to Jesus' teachings.
* "The Great Tribulation" is a term used in the Bible to describe a period of time just before Jesus' second coming when God's wrath will be poured out on the earth for several years.
* The term "tribulation" could also be translated as "time of great suffering" or "deep distress" or "severe difficulties."


(See also: [earth](#earth), [teach](#teach), [wrath](kt.html#wrath))

#### Bible References: ####

* [Mark 04:16-17](https://git.door43.org/Door43/en_tn/src/master/mrk/04/16.md)
* [Mark 13:17-20](https://git.door43.org/Door43/en_tn/src/master/mrk/13/17.md)
* [Matthew 13:20-21](https://git.door43.org/Door43/en_tn/src/master/mat/13/20.md)
* [Matthew 24:9-11](https://git.door43.org/Door43/en_tn/src/master/mat/24/09.md)
* [Matthew 24:29](https://git.door43.org/Door43/en_tn/src/master/mat/24/29.md)
* [Romans 02:8-9](https://git.door43.org/Door43/en_tn/src/master/rom/02/08.md)

#### Word Data:####

* Strong's: H6869, G2346, G2347


---

<a id="tribute"/>

### tribute ###

#### Definition: ####
 
The term "tribute" refers to a gift from one ruler to another ruler, for the purpose of protection and for good relations between their nations.

* A tribute can also be a payment that a ruler or government requires from the people, such as a toll or tax.
* In Bible times, traveling kings or rulers sometimes paid a tribute to the king of the region they were traveling through to make sure they would be protected and safe.
* Often the tribute would include things besides money, such as foods, spices, rich clothing, and expensive metals such as gold.

#### Translation Suggestions: ####

* Depending on the context, "tribute" could be translated as "official gifts" or "special tax" or "required payment."
 

(See also: [gold](#gold), [king](#king), [ruler](#ruler), [tax](#tax))

#### Bible References: ####

* [1 Chronicles 18:1-2](https://git.door43.org/Door43/en_tn/src/master/1ch/18/01.md)
* [2 Chronicles 09:22-24](https://git.door43.org/Door43/en_tn/src/master/2ch/09/22.md)
* [2 Kings 17:1-3](https://git.door43.org/Door43/en_tn/src/master/2ki/17/01.md)
* [Luke 23:1-2](https://git.door43.org/Door43/en_tn/src/master/luk/23/01.md)

#### Word Data:####

* Strong's: H1093, H4060, H4061, H4371, H4503, H4522, H4530, H4853, H6066, H7862, G1323, G2778, G5411


---

<a id="trouble"/>

### trouble, troubles, troubled, troubling, troublemaker, troublesome ###

#### Definition: ####

A "trouble" is an experience in life that is very difficult and distressing. To "trouble" someone means to "bother" that person or to cause him distress.To be "troubled" means to feel upset or distressed about something.

* Troubles can be physical, emotional, or spiritual things that hurt a person.
* In the Bible, often troubles are times of testing that God uses to help believers mature and grow in their faith.
* The Old Testament use of "trouble" also referred to judgment that came on people groups who were immoral and rejected God.


#### Translation Suggestions ####

* The term "trouble" or "troubles" could also be translated as "danger" or "painful things that happen" or "persecution" or "difficult experiences" or "distress."
* The term "troubled" could be translated with a word or phrase that means "undergoing distress" or "feeling terrible distress" or "worried" or "anxious" or "distressed" or "terrified" or "disturbed."
* "Don't trouble her" could also be translated as "don't bother her" or "don't criticize her."
* The phrase "day of trouble" or "times of trouble" could also be translated as "when you experience distress" or " when difficult things happen to you" or "when God causes distressing things to happen."
* Ways to translate "make trouble" or "bring trouble" could include "cause distressing things to happen" or "cause difficulties" or "make them experience very difficult things."



(See also: [afflict](#afflict), [persecute](#persecute))

#### Bible References: ####

* [1 Kings 18:18-19](https://git.door43.org/Door43/en_tn/src/master/1ki/18/18.md)
* [2 Chronicles 25:18-19](https://git.door43.org/Door43/en_tn/src/master/2ch/25/18.md)
* [Luke 24:38-40](https://git.door43.org/Door43/en_tn/src/master/luk/24/38.md)
* [Matthew 24:6-8](https://git.door43.org/Door43/en_tn/src/master/mat/24/06.md)
* [Matthew 26:36-38](https://git.door43.org/Door43/en_tn/src/master/mat/26/36.md)

#### Word Data:####

* Strong's: H205, H598, H926, H927, H928, H1204, H1205, H1607, H1644, H1804, H1993, H2000, H2113, H2189, H2560, H2960, H4103, H5590, H5753, H5916, H5999, H6031, H6040, H6470, H6696, H6862, H6869, H6887, H7264, H7267, H7451, H7481, H7489, H7515, H7561, H8513, G387, G1298, G1613, G1776, G2346, G2347, G2350, G2360, G2553, G2873, G3636, G3926, G3930, G3986, G4423, G4660, G5015, G5016, G5182


---

<a id="trumpet"/>

### trumpet, trumpets, trumpeters ###

#### Definition: ####

The term "trumpet" refers to an instrument for producing music or for calling people to gather together for an announcement or meeting.

* A trumpet was commonly made from either metal, seashell, or an animal horn.
* Trumpets were most commonly blown to call people to come together for battle, and for Israel's public assemblies.
* The book of Revelation describes a scene in the end times in which angels blow their trumpets to signal the outpouring of the wrath of God on the earth.

(See also: [angel](kt.html#angel), [assembly](#assembly), [earth](#earth), [horn](#horn), [Israel](kt.html#israel), [wrath](kt.html#wrath))

#### Bible References: ####

* [1 Chronicles 13:7-8](https://git.door43.org/Door43/en_tn/src/master/1ch/13/07.md)
* [2 Kings 09:11-13](https://git.door43.org/Door43/en_tn/src/master/2ki/09/11.md)
* [Exodus 19:12-13](https://git.door43.org/Door43/en_tn/src/master/exo/19/12.md)
* [Hebrews 12:18-21](https://git.door43.org/Door43/en_tn/src/master/heb/12/18.md)
* [Matthew 06:1-2](https://git.door43.org/Door43/en_tn/src/master/mat/06/01.md)
* [Matthew 24:30-31](https://git.door43.org/Door43/en_tn/src/master/mat/24/30.md)

#### Word Data:####

* Strong's: H2689, H2690, H3104, H7782, H8619, H8643, G4536, G4537, G4538


---

<a id="tunic"/>

### tunic, tunics ###

#### Definition: ####

In the Bible, the term "tunic" referred to a garment that was worn next to the skin, under other clothing.

* A tunic reached from the shoulders down to the waist or knees and was usually worn with a belt. Tunics worn by wealthy people sometimes had sleeves and reached down to the ankles.
* Tunics were made of leather, haircloth, wool, or linen, and were worn by both men and women.
* A tunic was normally worn under a longer over-garment, such as a toga or outer robe. In warmer weather a tunic was sometimes worn with no outer garment.
* This term could be translated as "long shirt" or "long undergarment" or "shirt-like garment." It could also be written in a similar way to "tunic," with a note to explain what kind of clothing it was.


(See also: [How to Translate Unknowns](https://git.door43.org/Door43/en_ta/src/master/translate/translate-unknown.md))

(See Also: [robe](#robe))

#### Bible References: ####

* [Daniel 03:21-23](https://git.door43.org/Door43/en_tn/src/master/dan/03/21.md)
* [Isaiah 22:20-22](https://git.door43.org/Door43/en_tn/src/master/isa/22/20.md)
* [Leviticus 08:12-13](https://git.door43.org/Door43/en_tn/src/master/lev/08/12.md)
* [Luke 03:10-11](https://git.door43.org/Door43/en_tn/src/master/luk/03/10.md)
* [Mark 06:7-9](https://git.door43.org/Door43/en_tn/src/master/mrk/06/07.md)
* [Matthew 10:8-10](https://git.door43.org/Door43/en_tn/src/master/mat/10/08.md)

#### Word Data:####

* Strong's: H2243, H3801, H6361, G5509


---

<a id="turn"/>

### turn, turns, turn away, turns away, turn back, turns back, turned, turned away, turned back, turning, turning away, turning back, returns, returned, returning, return back ###

#### Definition: ####

To "turn" means to physically change direction or to cause something else to change direction.

* The term "turn" can also mean "turn around" to look behind or to face a different direction.
* To "turn back" or "turn away" means to "go back" or "go away" or "cause to go away."
* To "turn away from" can mean to "stop" doing something or to reject someone.
* To "turn toward" someone means to look directly at that person.
* To "turn and leave" or "turn his back to leave" means to "go away."
* To "turn back to" means to "start doing something again."
* To "turn away from" means to "stop doing something."

#### Translation Suggestions: ####

* Depending on the context, "turn" can be translated as "change direction" or "go" or "move."
* In some contexts, "turn" could be translated as "cause" (someone) to do something. To "turn (someone) away from" could be translated as "cause (someone) to go away" or "cause (someone) to stop."
* The phrase "turn away from God" could be translated as "stop worshiping God."
* The phrase "turn back to God" could be translated as "start worshiping God again."
* When enemies "turn back," it means they "retreat." To "turn back the enemy" means to "cause the enemy to retreat."
* Used figuratively, when Israel "turned to" false gods, they "started to worship" them. When they "turned away" from idols, they "stopped worshiping" them.
* When God "turned away from" his rebellious people, he "stopped protecting" or "stopped helping" them.
* The phrase "turn the hearts of the fathers to their children" could be translated as "cause fathers to care for their children again."
* The expression "turn my honor into shame" could be translated as "cause my honor to become shame" or "dishonor me so that I am shamed" or "shame me (by doing what is evil) so that people no longer honor me."
* "I will turn your cities into ruin" could be translated as "I will cause your cities to be destroyed" or "I will cause enemies to destroy your cities."
* The phrase "turn into" could be translated as "become." When Moses' rod "turned into" a snake, it "became" a snake." It could also be translated as "changed into."

(See also: [false god](kt.html#falsegod), [leprosy](#leprosy), [worship](kt.html#worship))

#### Bible References: ####

* [1 Kings 11:1-2](https://git.door43.org/Door43/en_tn/src/master/1ki/11/01.md)
* [Acts 07:41-42](https://git.door43.org/Door43/en_tn/src/master/act/07/41.md)
* [Acts 11:19-21](https://git.door43.org/Door43/en_tn/src/master/act/11/19.md)
* [Jeremiah 36:1-3](https://git.door43.org/Door43/en_tn/src/master/jer/36/01.md)
* [Luke 01:16-17](https://git.door43.org/Door43/en_tn/src/master/luk/01/16.md)
* [Malachi 04:4-6](https://git.door43.org/Door43/en_tn/src/master/mal/04/04.md)
* [Revelation 11:6-7](https://git.door43.org/Door43/en_tn/src/master/rev/11/06.md)

#### Word Data:####

* Strong's: H541, H1750, H2015, H2017, H2186, H2559, H3399, H3943, H4142, H4672, H4740, H4878, H5186, H5253, H5414, H5437, H5472, H5493, H5528, H5627, H5753, H5844, H6437, H6801, H7227, H7725, H7734, H7750, H7760, H7847, H8159, H8447, G344, G387, G402, G576, G654, G665, G868, G1294, G1578, G1612, G1624, G1994, G2827, G3179, G3313, G3329, G3344, G3346, G4762, G5077, G5157, G5290, G6060


---

<a id="understand"/>

### understand, understands, understood, understanding ###

#### Definition: ####

The term "understand" means to hear or receive information and know what it means.

* The term "understanding" can refer to "knowledge" or "wisdom" or realizing how to do something.
* To understand someone can also mean to know how that person is feeling.
* While walking on the road to Emmaus, Jesus caused the disciples to understand the meaning of the scriptures about the Messiah.
* Depending on the context, the term "understand" could be translated by "know" or "believe" or "comprehend" or "know what (something) means."
* Often the term "understanding" can be translated by "knowledge" or "wisdom" or "insight."

(See also: [believe](kt.html#believe), [know](#know), [wise](kt.html#wise))

#### Bible References: ####

* [Job 34:16-17](https://git.door43.org/Door43/en_tn/src/master/job/34/16.md)
* [Luke 02:45-47](https://git.door43.org/Door43/en_tn/src/master/luk/02/45.md)
* [Luke 08:9-10](https://git.door43.org/Door43/en_tn/src/master/luk/08/09.md)
* [Matthew 13:10-12](https://git.door43.org/Door43/en_tn/src/master/mat/13/10.md)
* [Matthew 13:13-14](https://git.door43.org/Door43/en_tn/src/master/mat/13/13.md)
* [Proverbs 03:5-6](https://git.door43.org/Door43/en_tn/src/master/pro/03/05.md)

#### Word Data:####

* Strong's: H995, H998, H999, H1847, H2940, H3045, H3820, H3824, H4486, H7200, H7306, H7919, H7922, H7924, H8085, H8394, G50, G145, G191, G801, G1097, G1107, G1108, G1271, G1921, G1922, G1987, G1990, G2657, G3129, G3539, G3563, G3877, G4441, G4907, G4908, G4920, G5424, G5428, G5429, G6063


---

<a id="vain"/>

### vain, vanity ###

#### Definition: ####

The term "vain" describes something that is useless or has no purpose. Vain things are empty and worthless.

* The term "vanity" refers to worthlessness or emptiness. It can also refer to pride or arrogance.
* In the Old Testament, idols are described as vain things that cannot deliver or save. They are worthless and have no use or purpose.
* If something was done "in vain," it means that there was no good result from it. The effort or action did not accomplish anything.
* To "believe in vain" means to believe in something that is not true and that gives false hope.

#### Translation Suggestions: ####

* Depending on the context, the term "vain" could be translated as "empty" or "useless" or "hopeless" or "worthless" or "meaningless."
* The phrase "in vain" could be translated as "without result" or "with no result" or "for no reason" or "with no purpose."
* The term "vanity" could be translated as "pride" or "nothing worthwhile" or "hopelessness."

(See also: [false god](kt.html#falsegod), [worthy](kt.html#worthy))

#### Bible References: ####

* [1 Corinthians 15:1-2](https://git.door43.org/Door43/en_tn/src/master/1co/15/01.md)
* [1 Samuel 25:21-22](https://git.door43.org/Door43/en_tn/src/master/1sa/25/21.md)
* [2 Peter 02:17-19](https://git.door43.org/Door43/en_tn/src/master/2pe/02/17.md)
* [Isaiah 45:19](https://git.door43.org/Door43/en_tn/src/master/isa/45/19.md)
* [Jeremiah 02:29-31](https://git.door43.org/Door43/en_tn/src/master/jer/02/29.md)
* [Matthew 15:7-9](https://git.door43.org/Door43/en_tn/src/master/mat/15/07.md)

#### Word Data:####

* Strong's: H205, H1891, H1892, H2600, H3576, H5014, H6754, H7307, H7385, H7386, H7387, H7723, H8193, H8267, H8414, G945, G1432, G1500, G2755, G2756, G2757, G2758, G2761, G3150, G3151, G3152, G3153, G3154, G3155


---

<a id="veil"/>

### veil, veils, veiled, unveiled ###

#### Definition: ####

The term "veil" usually refers to a thin piece of cloth that is used as a head covering, to cover the head or face so that it cannot be seen.

* Moses covered his face with a veil after he had been in the presence of Yahweh, so that the brightness of his face would be hidden from the people.
* In the Bible, women wore a veil to cover their head, and often their face as well, when they were in public or in the presence of men.
* The verb to "veil" means to cover something with a veil.
* In some English versions, the word "veil" is used to refer to the thick curtain that covered the entrance into the most holy place. But "curtain" is a better term in that context, since it refers to a heavy, thick piece of cloth.

#### Translation Suggestions ####

* The term "veil" could also be translated as "thin cloth covering" or "cloth covering" or "head covering."
* In some cultures, there may already be a term for a veil for women. It may be necessary to find a different word when it is used for Moses.

(See also: [Moses](names.html#moses))

#### Bible References: ####

* [2 Corinthians 03:12-13](https://git.door43.org/Door43/en_tn/src/master/2co/03/12.md)
* [2 Corinthians 03:14-16](https://git.door43.org/Door43/en_tn/src/master/2co/03/14.md)
* [Ezekiel 13:17-18](https://git.door43.org/Door43/en_tn/src/master/ezk/13/17.md)
* [Isaiah 47:1-2](https://git.door43.org/Door43/en_tn/src/master/isa/47/01.md)
* [Song of Solomon 04:3](https://git.door43.org/Door43/en_tn/src/master/sng/04/03.md)

#### Word Data:####

* Strong's: H7289, G2665


---

<a id="vine"/>

### vine, vines ###

#### Definition: ####

The term "vine" refers to a plant that grows by trailing along the ground or by climbing trees and other structures. The word "vine" in the Bible is used only of fruit-bearing vines and usually refers to grape vines.

* In the Bible, the word "vine" almost always means "grapevine."
* The branches of the grapevine are attached to the main stem which gives them water and other nutrients so that they can grow.
* Jesus called himself the "vine" and called his people the "branches." In this context, the word "vine" could also be translated as "grapevine stem" or "grape plant stem." (See: [Metaphor](https://git.door43.org/Door43/en_ta/src/master/translate/figs-metaphor.md))

(See also: [grape](#grape), [vineyard](#vineyard))

#### Bible References: ####

* [Genesis 40:9-11](https://git.door43.org/Door43/en_tn/src/master/gen/40/09.md)
* [Genesis 49:11-12](https://git.door43.org/Door43/en_tn/src/master/gen/49/11.md)
* [John 15:1-2](https://git.door43.org/Door43/en_tn/src/master/jhn/15/01.md)
* [Luke 22:17-18](https://git.door43.org/Door43/en_tn/src/master/luk/22/17.md)
* [Mark 12:1-3](https://git.door43.org/Door43/en_tn/src/master/mrk/12/01.md)
* [Matthew 21:35-37](https://git.door43.org/Door43/en_tn/src/master/mat/21/35.md)

#### Word Data:####

* Strong's: H5139, H1612, H8321, G288, G290, G1009, G1092


---

<a id="vineyard"/>

### vineyard, vineyards ###

#### Definition: ####

A vineyard is a large garden area where grapevines are grown and grapes are cultivated.

 * A vineyard often has a wall around it to protect the fruit from thieves and animals.
 * God compared the people of Israel to a vineyard that did not bear good fruit. (See: [Metaphor](https://git.door43.org/Door43/en_ta/src/master/translate/figs-metaphor.md))
 * Vineyard could be also translated as "grapevine garden" or "grape plantation."

(See also: [grape](#grape), [Israel](kt.html#israel), [vine](#vine))

#### Bible References: ####

* [Genesis 09:20-21](https://git.door43.org/Door43/en_tn/src/master/gen/09/20.md)
* [Luke 13:6-7](https://git.door43.org/Door43/en_tn/src/master/luk/13/06.md)
* [Luke 20:15-16](https://git.door43.org/Door43/en_tn/src/master/luk/20/15.md)
* [Matthew 20:1-2](https://git.door43.org/Door43/en_tn/src/master/mat/20/01.md)
* [Matthew 21:40-41](https://git.door43.org/Door43/en_tn/src/master/mat/21/40.md)

#### Word Data:####

* Strong's: H64, H1612, H3657, H3661, H3754, H3755, H8284, G289, G290


---

<a id="virgin"/>

### virgin, virgins, virginity ###

#### Definition: ####

A virgin is a woman who has never had sexual relations.

 * The prophet Isaiah said that the Messiah would be born from a virgin.
 * Mary was a virgin when she was pregnant with Jesus. He did not have a human father.
 * Some languages may have a term that is a polite way of referring to a virgin. (See: [Euphemism](https://git.door43.org/Door43/en_ta/src/master/translate/figs-euphemism.md))

(See also: [Christ](kt.html#christ), [Isaiah](names.html#isaiah), [Jesus](kt.html#jesus), [Mary](names.html#mary))

#### Bible References: ####

* [Genesis 24:15-16](https://git.door43.org/Door43/en_tn/src/master/gen/24/15.md)
* [Luke 01:26-29](https://git.door43.org/Door43/en_tn/src/master/luk/01/26.md)
* [Luke 01:34-35](https://git.door43.org/Door43/en_tn/src/master/luk/01/34.md)
* [Matthew 01:22-23](https://git.door43.org/Door43/en_tn/src/master/mat/01/22.md)
* [Matthew 25:1-4](https://git.door43.org/Door43/en_tn/src/master/mat/25/01.md)

#### Examples from the Bible stories: ####

  __*[21:09](https://git.door43.org/Door43/en_tn/src/master/obs/21/09.md)__ The prophet Isaiah prophesied that the Messiah would be born from a __virgin__.
  __*[22:04](https://git.door43.org/Door43/en_tn/src/master/obs/22/04.md)__ She (Mary) was a __virgin__ and was engaged to be married to a man named Joseph.
  __*[22:05](https://git.door43.org/Door43/en_tn/src/master/obs/22/05.md)__ Mary replied, "How can this be, since I am a __virgin__?"
  __*[49:01](https://git.door43.org/Door43/en_tn/src/master/obs/49/01.md)__ An angel told a __virgin__ named Mary that she would give birth to God's Son. So while she was still a __virgin__, she gave birth to a son and named him Jesus.

#### Word Data:####

* Strong's: H1330, H1331, H5959, G3932, G3933


---

<a id="vision"/>

### vision, visions, envision ###

#### Facts: ####

The term "vision" refers to something that a person sees. It especially refers to something unusual or supernatural that God shows people in order to give them a message.

 * Usually, visions are seen while the person is awake. However, sometimes a vision is something a person sees in a dream while asleep.
 * God sends visions to tell people something that is very important. For example, Peter was shown a vision to tell him that God wanted him to welcome Gentiles.

#### Translation Suggestion ####

 * The phrase "saw a vision" could be translated as "saw something unusual from God" or "God showed him something special."
 * Some languages may not have separate words for "vision" and "dream." So a sentence such as "Daniel had dreams and visions in his mind" could be translated as something like "Daniel was dreaming while asleep and God caused him to see unusual things."

(See also: [dream](#dream))

#### Bible References: ####

* [Acts 09:10-12](https://git.door43.org/Door43/en_tn/src/master/act/09/10.md)
* [Acts 10:3-6](https://git.door43.org/Door43/en_tn/src/master/act/10/03.md)
* [Acts 10:9-12](https://git.door43.org/Door43/en_tn/src/master/act/10/09.md)
* [Acts 12:9-10](https://git.door43.org/Door43/en_tn/src/master/act/12/09.md)
* [Luke 01:21-23](https://git.door43.org/Door43/en_tn/src/master/luk/01/21.md)
* [Luke 24:22-24](https://git.door43.org/Door43/en_tn/src/master/luk/24/22.md)
* [Matthew 17:9-10](https://git.door43.org/Door43/en_tn/src/master/mat/17/09.md)

#### Word Data:####

* Strong's: H2376, H2377, H2378, H2380, H2384, H4236, H4758, H4759, H7203, H7723, H8602, G3701, G3705, G3706


---

<a id="voice"/>

### voice, voices ###

#### Definition: ####

The term "voice" is often used figuratively to refer to speaking or communicating something.

* God is said to use his voice, even though he doesn't have a voice in the same way a human being does.
* This term can be used to refer to the whole person, as in the statement "A voice is heard in the desert saying, 'Prepare the way of the Lord.'" This could be translated as "A person is heard calling out in the desert…." (See: [synecdoche](https://git.door43.org/Door43/en_ta/src/master/translate/figs-synecdoche.md))
* To "hear someone's voice" could also be translated as "hear someone speaking."
* Sometimes the word "voice" may be used for objects that cannot literally speak, such as when David exclaims in the psalms that the "voice" of the heavens proclaims God's mighty works. This could also be translated as "their splendor shows clearly how great God is."

(See also: [call](kt.html#call), [proclaim](#proclaim), [splendor](#splendor))

#### Bible References: ####

* [John 05:36-38](https://git.door43.org/Door43/en_tn/src/master/jhn/05/36.md)
* [Luke 01:42-45](https://git.door43.org/Door43/en_tn/src/master/luk/01/42.md)
* [Luke 09:34-36](https://git.door43.org/Door43/en_tn/src/master/luk/09/34.md)
* [Matthew 03:16-17](https://git.door43.org/Door43/en_tn/src/master/mat/03/16.md)
* [Matthew 12:19-21](https://git.door43.org/Door43/en_tn/src/master/mat/12/19.md)

#### Word Data:####

* Strong's: H6963, H7032, H7445, H8193, G2906, G5456, G5586


---

<a id="walk"/>

### walk, walks, walked, walking ###

#### Definition: ####

The term "walk" is often used in a figurative sense to mean "live."

* "Enoch walked with God" means that Enoch lived in a close relationship with God.
* To "walk by the Spirit" means to be guided by the Holy Spirit so that we do things that please and honor God.
* To "walk in" God's commands or God's ways means to "live in obedience to" his commands, that is, to "obey his commands" or "do his will."
* When God says he will "walk among" his people, it means that he is living among them or closely interacting with them.
* To "walk contrary to" means to live or behave in a way that is against something or someone.
* To "walk after" means to seek or pursue someone or something. It can also mean to act in the same way as someone else.

#### Translation Suggestions: ####

* It is best to translate "walk" literally, as long as the correct meaning will be understood.
* Otherwise, figurative uses of"walk" could also be translated by "live" or "act" or "behave."
* The phrase "walk by the Spirit" could be translated by, "live in obedience to the Holy Spirit" or "behave in a way that is pleasing to the Holy Spirit" or "do things that are pleasing to God as the Holy Spirit guides you."
* To "walk in God's commands" could be translated by "live by God's commands" or "obey God's commands."
* The phrase "walked with God" could be translated as, "lived in close relationship with God by obeying and honoring him."

(See also: [Holy Spirit](kt.html#holyspirit), [honor](kt.html#honor))

#### Bible References: ####

* [1 John 01:5-7](https://git.door43.org/Door43/en_tn/src/master/1jn/01/05.md)
* [1 Kings 02:1-4](https://git.door43.org/Door43/en_tn/src/master/1ki/02/01.md)
* [Colossians 02:6-7](https://git.door43.org/Door43/en_tn/src/master/col/02/06.md)
* [Galatians 05:25-26](https://git.door43.org/Door43/en_tn/src/master/gal/05/25.md)
* [Genesis 17:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/17/01.md)
* [Isaiah 02:5-6](https://git.door43.org/Door43/en_tn/src/master/isa/02/05.md)
* [Jeremiah 13:8-11](https://git.door43.org/Door43/en_tn/src/master/jer/13/08.md)
* [Micah 04:2-3](https://git.door43.org/Door43/en_tn/src/master/mic/04/02.md)

#### Word Data:####

* Strong's: H1869, H1979, H1980, H1981, H3212, H4108, H4109, G1330, G1704, G3716, G4043, G4198, G4748


---

<a id="warrior"/>

### soldier, soldiers, warrior, warriors ###

#### Facts: ####
The terms "warrior" and "soldier" both can refer to someone who fights in an army. But there are also some differences.
 
* Usually the term "warrior" is a general, broad term to refer to a man who is gifted and courageous in battle.
* Yahweh is figuratively described as a "warrior."
* The term "soldier" more specifically refers to someone who belongs to a certain army or who is fighting in a certain battle.
* Roman soldiers in Jerusalem were there to keep order and to carry out duties such as executing prisoners. They guarded Jesus before crucifying him and some were ordered to stand guard at his tomb.
* The translator should consider whether there are two words in the project language for "warrior" and "soldier" that also differ in meaning and use.

(See also: [courage](#courage), [crucify](kt.html#crucify), [Rome](names.html#rome), [tomb](#tomb))

#### Bible References: ####

* [1 Chronicles 21:4-5](https://git.door43.org/Door43/en_tn/src/master/1ch/21/04.md)
* [Acts 21:32-33](https://git.door43.org/Door43/en_tn/src/master/act/21/32.md)
* [Luke 03:14](https://git.door43.org/Door43/en_tn/src/master/luk/03/14.md)
* [Luke 23:11-12](https://git.door43.org/Door43/en_tn/src/master/luk/23/11.md)
* [Matthew 08:8-10](https://git.door43.org/Door43/en_tn/src/master/mat/08/08.md)

#### Word Data:####

* Strong's: , H352, H510, H1368, H1416, H1995, H2389, H2428, H2502, H3715, H4421, H5431, H5971, H6518, H6635, H7273, H7916, G4686, G4753, G4754, G4757, G4758, G4961


---

<a id="waste"/>

### waste, wastes, wasted, wasting, wasteland, wastelands ###

#### Definition: ####

To waste something means to carelessly throw it away or to use it unwisely. Something that is a  "wasteland" or a "waste" refers to land or a city that has been destroyed so that nothing lives in it anymore. 

* The term "waste away" is an expression that means to become more and more sick or ruined. A person who is wasting away usually becomes very thin due to illness or lack of food.
* To "lay waste" to a city or land means to destroy it.
* Another word for a "wasteland" could be "desert" or "wilderness." But a wasteland also implies that people used to live there and the land used to have trees and plants that produced food.

#### Bible References: ####

* [Ezekiel 06:6-7](https://git.door43.org/Door43/en_tn/src/master/ezk/06/06.md)
* [Leviticus 26:37-39](https://git.door43.org/Door43/en_tn/src/master/lev/26/37.md)
* [Matthew 26:6-9](https://git.door43.org/Door43/en_tn/src/master/mat/26/06.md)
* [Revelation 18:15-17](https://git.door43.org/Door43/en_tn/src/master/rev/18/15.md)
* [Zechariah 07:13-14](https://git.door43.org/Door43/en_tn/src/master/zec/07/13.md)

#### Word Data:####

* Strong's: H535, H1086, H1104, H1110, H1197, H1326, H2100, H2490, H2522, H2717, H2720, H2721, H2723, H3615, H3765, H3856, H4127, H4198, H4592, H4743, H4875, H5307, H5327, H7334, H7582, H7703, H7722, H7736, H7843, H8047, H8074, H8077, H8414, H8437, G684, G1287, G2049, G2673, G4199


---

<a id="watch"/>

### watch, watches, watched, watching, watchman, watchmen, watchful ###

#### Definition: ####

The term "watch" means to look at something very closely and carefully. It also has several figurative meanings. A "watchman" was someone whose job was to guard a city by looking carefully all around him for any danger or threat to the people in the city.

* The command to "watch your life and doctrine closely" means to be careful to live wisely and to not believe false teachings.
* To "watch out" is a warning to be careful to avoid a danger or harmful influence.
* To "watch" or "keep watch" means to always be alert and on guard against sin and evil. It can also mean to "be ready."
* To "keep watch over" or "keep close watch" can mean to guard, protect or take care of someone or something.
* Other ways of translating "watch" could include "pay close attention to" or "be diligent" or "be very careful" or "be on guard."
* Other words for "watchman" are "sentry" or "guard."

#### Bible References: ####

* [1 Thessalonians 05:4-7](https://git.door43.org/Door43/en_tn/src/master/1th/05/04.md)
* [Hebrews 13:15-17](https://git.door43.org/Door43/en_tn/src/master/heb/13/15.md)
* [Jeremiah 31:4-6](https://git.door43.org/Door43/en_tn/src/master/jer/31/04.md)
* [Mark 08:14-15](https://git.door43.org/Door43/en_tn/src/master/mrk/08/14.md)
* [Mark 13:33-34](https://git.door43.org/Door43/en_tn/src/master/mrk/13/33.md)
* [Matthew 25:10-13](https://git.door43.org/Door43/en_tn/src/master/mat/25/10.md)

#### Word Data:####

* Strong's: H821, H2370, H4929, H4931, H5027, H5341, H5894, H6486, H6822, H6836, H6974, H7462, H7789, H7919, H8104, H8108, H8245, G69, G70, G991, G1127, G1492, G2334, G2892, G3525, G3708, G3906, G4337, G4648, G5083, G5438


---

<a id="watchtower"/>

### watchtower, watchtowers, tower ###

#### Definition: ####

The term "watchtower" refers to a tall structure built as a place from which guards could look out for any danger. These towers were often made of stone.

* Landowners sometimes built watchtowers from which they could guard their crops and protect them from being stolen.
* The towers often included rooms where the watchmen or family lived, so that they could guard the crops day and night.
* Watchtowers for cities were built higher than the city walls so that watchmen could see if any enemies were coming to attack the city.
* The term "watchtower" is also used as a symbol of protection from enemies. (See: [Metaphor](https://git.door43.org/Door43/en_ta/src/master/translate/figs-metaphor.md))

(See also: [adversary](#adversary), [watch](#watch))

#### Bible References: ####

* [1 Chronicles 27:25-27](https://git.door43.org/Door43/en_tn/src/master/1ch/27/25.md)
* [Ezekiel 26:3-4](https://git.door43.org/Door43/en_tn/src/master/ezk/26/03.md)
* [Mark 12:1-3](https://git.door43.org/Door43/en_tn/src/master/mrk/12/01.md)
* [Matthew 21:33-34](https://git.door43.org/Door43/en_tn/src/master/mat/21/33.md)
* [Psalm 062:1-2](https://git.door43.org/Door43/en_tn/src/master/psa/062/001.md)

#### Word Data:####

* Strong's: H803, H969, H971, H975, H1785, H2918, H4024, H4026, H4029, H4692, H4707, H4869, H6076, H6438, H6836, H6844, G4444


---

<a id="water"/>

### water, waters, watered, watering ###

#### Definition: ####

In addition to its primary meaning, "water" also often refers to a body of water, such as an ocean, sea, lake, or river.

* The term "waters" refers to bodies of water or many sources of water. It can also be a general reference for a large amount of water.
* A figurative use of "waters" refers to great distress, difficulties, and suffering. For example, God promises that when we "go through the waters" he will be with us.
* The phrase "many waters" emphasizes how great the difficulties are.
* To "water" livestock and other animals means to "provide water for" them. In Bible times, this usually involved drawing water from a well with a bucket and pouring the water into a trough or other container for the animals to drink from.
* In the Old Testament, God is referred to as the spring or fountain of "living waters" for his people. This means he is the source of spiritual power and refreshment.
* In the New Testament, Jesus used the phrase "living water" to refer to the Holy Spirit working in a person to transform and bring new life.

#### Translation Suggestions: ####

* The phrase, "draw water" could be translated as "pull water up from a well with a bucket."
* "Streams of living water will flow from them" could be translated as "the power and blessings from the Holy Spirit will flow out of them them like streams of water." Instead of "blessings" the term "gifts" or "fruits" or "godly character" could be used.
* When Jesus is talking to the Samaritan woman at the well, the phrase "living water" could be translated as "water that gives life" or "lifegiving water." In this context, the imagery of water must be kept in the translation.
* Depending on the context, the term "waters" or "many waters" could be translated as "great suffering (that surrounds you like water)" or "overwhelming difficulties (like a flood of water)" or "large amounts of water."

(See also: [life](kt.html#life), [spirit](kt.html#spirit), [Holy Spirit](kt.html#holyspirit), [power](kt.html#power))

#### Bible References: ####

* [Acts 08:36-38](https://git.door43.org/Door43/en_tn/src/master/act/08/36.md)
* [Exodus 14:21-22](https://git.door43.org/Door43/en_tn/src/master/exo/14/21.md)
* [John 04:9-10](https://git.door43.org/Door43/en_tn/src/master/jhn/04/09.md)
* [John 04:13-14](https://git.door43.org/Door43/en_tn/src/master/jhn/04/13.md)
* [John 04:15-16](https://git.door43.org/Door43/en_tn/src/master/jhn/04/15.md)
* [Matthew 14:28-30](https://git.door43.org/Door43/en_tn/src/master/mat/14/28.md)

#### Word Data:####

* Strong's: H2222, H4325, H4529, H4857, H7301, H7783, H8248, G504, G4215, G4222, G5202, G5204


---

<a id="well"/>

### cistern, cisterns, well, wells ###

#### Definition: ####

The terms "well" and "cistern" refer to two different kinds of sources for water in Bible times.

* A well is a deep hole dug into the ground so that underground water can flow into it.
* A cistern is a deep hole dug into rock that was used as a holding tank for collecting rain water.
* Cisterns were usually dug into rock and sealed with plaster to keep the water in. A "broken cistern" happened when the plaster became cracked so that the water leaked out.
* Cisterns were often located in the courtyard area of people's homes to catch the rainwater that would run off the roof.
* Wells were often located where they could be accessed by several families or a whole community.
* Because water was very important for both people and livestock, the right to use a well was often a cause of strife and conflict.
* Both wells and cisterns were usually covered with a large stone to prevent anything falling in it. Often there was a rope with a bucket or pot attached to it to bring the water up to the surface.
* Sometimes a dry cistern was used as a place to imprison someone, such as happened to Joseph and Jeremiah.

#### Translation Suggestions: ####

* Ways to translate "well" could include "deep water hole" or "deep hole for spring water" or "deep hole for drawing water."
* The term "cistern" could be translated as "stone water pit" or "deep and narrow pit for water" or "underground tank for holding water."
* These terms are similar in meaning. The main difference is that a well continually receives water from underground springs, whereas a cistern is a holding tank for water that usually comes from rain.

(See also: [Jeremiah](names.html#jeremiah), [prison](#prison), [strife](#strife))

#### Bible References: ####

* [1 Chronicles 11:15-17](https://git.door43.org/Door43/en_tn/src/master/1ch/11/15.md)
* [2 Samuel 17:17-18](https://git.door43.org/Door43/en_tn/src/master/2sa/17/17.md)
* [Genesis 16:13-14](https://git.door43.org/Door43/en_tn/src/master/gen/16/13.md)
* [Luke 14:4-6](https://git.door43.org/Door43/en_tn/src/master/luk/14/04.md)
* [Numbers 20:17](https://git.door43.org/Door43/en_tn/src/master/num/20/17.md)

#### Word Data:####

* Strong's: H875, H883, H953, H1360, H3653, H4599, H4726, H4841, G4077, G5421


---

<a id="wheat"/>

### wheat ###

#### Definition: ####

Wheat is a type of grain that people grow for food. When the Bible mentions "grain" or "seeds," it is often talking about wheat grain or seeds.

 * The wheat seeds or grains grow at the top of the wheat plant.
 * After harvesting the wheat, the grain is separated from the stalk of the plant by threshing it. The stalk of the wheat plant is also called "straw" and is often placed on the ground for animals to sleep on.
* After threshing, the chaff surrounding the grain seed is separated from the grain by winnowing and is thrown away.
 * People grind the wheat grain into flour, and use this for making bread.

(See also: [barley](#barley), [chaff](#chaff), [grain](#grain), [seed](#seed), [thresh](#thresh), [winnow](#winnow))

#### Bible References: ####

* [Acts 27:36-38](https://git.door43.org/Door43/en_tn/src/master/act/27/36.md)
* [Exodus 34:21-22](https://git.door43.org/Door43/en_tn/src/master/exo/34/21.md)
* [John 12:23-24](https://git.door43.org/Door43/en_tn/src/master/jhn/12/23.md)
* [Luke 03:17](https://git.door43.org/Door43/en_tn/src/master/luk/03/17.md)
* [Matthew 03:10-12](https://git.door43.org/Door43/en_tn/src/master/mat/03/10.md)
* [Matthew 13:24-26](https://git.door43.org/Door43/en_tn/src/master/mat/13/24.md)

#### Word Data:####

* Strong's: H1250, H2406, G4621


---

<a id="wine"/>

### wine, winepress, winepresses, wines, wineskin, wineskins, new wine ###

#### Definition: ####

In the Bible, the term "wine" refers to a kind of fermented drink made from the juice of a fruit called grapes. Wine was stored in "wineskins," which were containers made out of animal skin.

 * The term "new wine" referred to grape juice that had just been taken from the grape and was not fermented yet. Sometimes the term "wine" also referred to unfermented grape juice.
 * To make wine, grapes are crushed in a winepress so that the juice comes out. The juice eventually ferments and alcohol forms in it.
 * In Bible times, wine was the normal drink with meals. It did not have as much alcohol as present-day wine has.
 * Before wine was served for a meal, it was often mixed with water.
 * A wineskin that was old and brittle would get cracks in it, which allowed the wine to leak out. New wineskins were soft and flexible, which meant they did not tear easily and could store the wine safely.
 * If wine is unknown in your culture, it could be translated as "fermented grape juice" or "fermented drink made from a fruit called grapes" or "fermented fruit juice." (See: [How to Translate Unknowns](https://git.door43.org/Door43/en_ta/src/master/translate/translate-unknown.md))
 * Ways to translate "wineskin" could include "bag for wine" or "animal skin wine bag" or "animal skin container for wine."

(See also: [grape](#grape), [vine](#vine), [vineyard](#vineyard), [winepress](#winepress))

#### Bible References: ####

* [1 Timothy 05:23-25](https://git.door43.org/Door43/en_tn/src/master/1ti/05/23.md)
* [Genesis 09:20-21](https://git.door43.org/Door43/en_tn/src/master/gen/09/20.md)
* [Genesis 49:11-12](https://git.door43.org/Door43/en_tn/src/master/gen/49/11.md)
* [John 02:3-5](https://git.door43.org/Door43/en_tn/src/master/jhn/02/03.md)
* [John 02:9-10](https://git.door43.org/Door43/en_tn/src/master/jhn/02/09.md)
* [Matthew 09:17](https://git.door43.org/Door43/en_tn/src/master/mat/09/17.md)
* [Matthew 11:18-19](https://git.door43.org/Door43/en_tn/src/master/mat/11/18.md)

smashed

#### Word Data:####

* Strong's: H2561, H2562, H3196, H4469, H4997, H5435, H6025, H6071, H8492, G1098, G3631, G3820, G3943


---

<a id="winepress"/>

### winepress ###

#### Definition: ####

During Bible times, a "winepress" was a large container or open place where the juice of grapes was extracted in order to make wine.

* In Israel, winepresses were usually large, wide basins that were dug out of solid rock. Clusters of grapes were put on the flat bottom of the hole and people trampled the grapes with their feet to get the grape juice to flow out.
* Usually a winepress had two levels, with the grapes being trampled in the top level so that the juice would run down into the lower level where it could be collected.
* The term "winepress" is also used figuratively in the Bible as a picture of God's wrath being poured out on wicked people. (See: [Metaphor](https://git.door43.org/Door43/en_ta/src/master/translate/figs-metaphor.md))

(See also: [grape](#grape), [wrath](kt.html#wrath))

#### Bible References: ####

* [Isaiah 63:1-2](https://git.door43.org/Door43/en_tn/src/master/isa/63/01.md)
* [Mark 12:1-3](https://git.door43.org/Door43/en_tn/src/master/mrk/12/01.md)
* [Matthew 21:33-34](https://git.door43.org/Door43/en_tn/src/master/mat/21/33.md)
* [Revelation 14:19-20](https://git.door43.org/Door43/en_tn/src/master/rev/14/19.md)

#### Word Data:####

* Strong's: H1660, H3342, H6333, G3025, G5276


---

<a id="winnow"/>

### winnow, winnows, winnowed, winnowing, sift, sifting ###

#### Definition: ####

The terms "winnow" and "sift" mean to separate grain from unwanted materials. In the Bible, both words are also used in a figurative sense to refer to separating or dividing people.

* To "winnow" means to separate grain from the unwanted parts of the plant by tossing both the grain and chaff into the air, allowing the wind to blow the chaff away.
* The word "sift" refers to shaking the winnowed grain in a sieve to get rid of any remaining unwanted materials, such as dirt or stones.
* In the Old Testament, "winnow" and "sift" are used figuratively to describe hardship that separates the righteous people from the unrighteous people.
* Jesus also used the term "sift" in this figurative way when he was telling Simon Peter about how he and the other disciples would be tested in their faith.
* To translate these terms, use the words or phrases in the project language that refer to these activities; possible translations might be "shaking" or "fanning." If winnowing or sifting are not known, then these terms could be translated by a term that refers to a different method of separating grain from chaff or dirt, or by describing this process.

(See also: [How to Translate Unknowns](https://git.door43.org/Door43/en_ta/src/master/translate/translate-unknown.md))

(See also: [chaff](#chaff), [grain](#grain))

#### Bible References: ####

* [Isaiah 21:10](https://git.door43.org/Door43/en_tn/src/master/isa/21/10.md)
* [Luke 22:31-32](https://git.door43.org/Door43/en_tn/src/master/luk/22/31.md)
* [Matthew 03:10-12](https://git.door43.org/Door43/en_tn/src/master/mat/03/10.md)
* [Proverbs 20:7-8](https://git.door43.org/Door43/en_tn/src/master/pro/20/07.md)
* [Ruth 03:1-2](https://git.door43.org/Door43/en_tn/src/master/rut/03/01.md)

#### Word Data:####

* Strong's: H2219, H5128, H5130, G4425, G4617


---

<a id="wisemen"/>

### wise men ###

#### Facts: ####

In the Bible, the phrase "wise men" often refers to men who serve God and act wisely, not foolishly. This is also a special term that refers to men with unusual knowledge and abilities who served as part of a king's court.

* Sometimes the term "wise men" is explained in the text as "prudent men" or "men with understanding." This refers to men who act wisely and righteously because they obey God.
* The "wise men" who served pharaohs and other kings were often scholars who studied the stars, especially looking for special meanings for the patterns that the stars made in their positions in the sky.
* Often wise men were expected to explain the meanings of dreams. For example, King Nebuchadnezzar demanded that his wise men describe his dreams and tell him what they meant, but none of them was able to do this, except Daniel who had received this knowledge from God.
* Sometimes wise men also performed magical acts such as divination or miracles that were done through the power of evil spirits.
* In the New Testament, the group of men who came from eastern regions to worship Jesus were called "magi," which is often translated as "wise men," since this probably refers to scholars who served a ruler of an eastern country.
* It is very probable that these men were astrologers who studied the stars. Some have thought that they may have been descendants of the wise men whom Daniel taught when he was in Babylon.
* Depending on the context, the term "wise men" could be translated using the term "wise" or with a phrase such as "gifted men" or "educated men" or some other term that refers to men who have an important job working for a ruler.
* When "wise men" is simply a noun phrase, the word "wise" should be translated in the same or similar way to how it is translated elsewhere in the Bible.

(See also: [Babylon](names.html#babylon), [Daniel](names.html#daniel), [divination](#divination), [magic](#magic), [Nebuchadnezzar](names.html#nebuchadnezzar), [ruler](#ruler), [wise](kt.html#wise))

#### Bible References: ####

* [1 Chronicles 27:32-34](https://git.door43.org/Door43/en_tn/src/master/1ch/27/32.md)
* [Daniel 02:1-2](https://git.door43.org/Door43/en_tn/src/master/dan/02/01.md)
* [Daniel 02:10-11](https://git.door43.org/Door43/en_tn/src/master/dan/02/10.md)

#### Word Data:####

* Strong's: H2445, H2450, H3778, H3779, G4680


---

<a id="wolf"/>

### wolf, wolves, wild dogs ###

#### Definition: ####

A wolf is a fierce, meat-eating animal that is similar to a wild dog.

* Wolves usually hunt in groups and stalk their prey in a clever and stealthy manner.
* In the Bible, the term "wolves" is used figuratively to refer to false teachers or false prophets who destroy believers, who are compared to sheep. False teaching causes people to believe wrong things that bring harm to them.
* This comparison is based on the fact that sheep are especially vulnerable to being attacked and eaten by wolves, because they are weak and cannot defend themselves.

#### Translation Suggestion ####

* This term could be translated as "wild dog" or "wild animal."
* Other names for wild dogs could be "jackal" or "coyote."
* When used figuratively to refer to people, this could be translated as "evil people who harm people like animals that attack sheep."

(See also: [evil](kt.html#evil), [false prophet](#falseprophet), [sheep](#sheep), [teach](#teach))

#### Bible References: ####

* [Acts 20:28-30](https://git.door43.org/Door43/en_tn/src/master/act/20/28.md)
* [Isaiah 11:6-7](https://git.door43.org/Door43/en_tn/src/master/isa/11/06.md)
* [John 10:11-13](https://git.door43.org/Door43/en_tn/src/master/jhn/10/11.md)
* [Luke 10:3-4](https://git.door43.org/Door43/en_tn/src/master/luk/10/03.md)
* [Matthew 07:15-17](https://git.door43.org/Door43/en_tn/src/master/mat/07/15.md)
* [Zephaniah 03:3-4](https://git.door43.org/Door43/en_tn/src/master/zep/03/03.md)

#### Word Data:####

* Strong's: H2061, H3611, G3074


---

<a id="womb"/>

### womb, wombs ###

#### Definition: ####

The term "womb" refers to where a baby grows inside its mother.

* This is an older term that is sometimes used in order to be polite and less direct. (See: [euphemism](https://git.door43.org/Door43/en_ta/src/master/translate/figs-euphemism.md))
* A more modern term for womb is "uterus."
* Some languages use a word like "belly" to refer to a woman's womb or uterus.
* Use a word for this in the project language that is well-known, natural, and acceptable.

#### Bible References: ####

* [Genesis 25:23](https://git.door43.org/Door43/en_tn/src/master/gen/25/23.md)
* [Genesis 25:24-26](https://git.door43.org/Door43/en_tn/src/master/gen/25/24.md)
* [Genesis 38:27-28](https://git.door43.org/Door43/en_tn/src/master/gen/38/27.md)
* [Genesis 49:25](https://git.door43.org/Door43/en_tn/src/master/gen/49/25.md)
* [Luke 02:21](https://git.door43.org/Door43/en_tn/src/master/luk/02/21.md)
* [Luke 11:27-28](https://git.door43.org/Door43/en_tn/src/master/luk/11/27.md)
* [Luke 23:29-31](https://git.door43.org/Door43/en_tn/src/master/luk/23/29.md)
* [Matthew 19:10-12](https://git.door43.org/Door43/en_tn/src/master/mat/19/10.md)

#### Word Data:####

* Strong's: H990, H4578, H7356, H7358, G1064, G2836, G3388


---

<a id="word"/>

### word, words ###

#### Definition: ####

A "word" refers to something that someone has said.

* An example of this would be when the angel told Zechariah, "You did not believe my words," which means, "You did not believe what I said."
* This term almost always refers to an entire message, not just one word.
* Sometimes "word" refers to speech in general, such as "powerful in word and deed" which means "powerful in speech and behavior."
* Often in the Bible "the word" refers to everything God has said or commanded, as in "the word of God" or "the word of truth."
* A very special use of this term is when Jesus is called "the Word." For these last two meanings, see [word of God](kt.html#wordofgod)

#### Translation Suggestions: ####

* Different ways of translating "word" or "words" include "teaching" or "message" or "news" or "a saying" or "what was said."

(See also: [word of God](kt.html#wordofgod))

#### Bible References: ####

* [2 Timothy 04:1-2](https://git.door43.org/Door43/en_tn/src/master/2ti/04/01.md)
* [Acts 08:4-5](https://git.door43.org/Door43/en_tn/src/master/act/08/04.md)
* [Colossians 04:2-4](https://git.door43.org/Door43/en_tn/src/master/col/04/02.md)
* [James 01:17-18](https://git.door43.org/Door43/en_tn/src/master/jas/01/17.md)
* [Jeremiah 27:1-4](https://git.door43.org/Door43/en_tn/src/master/jer/27/01.md)
* [John 01:1-3](https://git.door43.org/Door43/en_tn/src/master/jhn/01/01.md)
* [John 01:14-15](https://git.door43.org/Door43/en_tn/src/master/jhn/01/14.md)
* [Luke 08:14-15](https://git.door43.org/Door43/en_tn/src/master/luk/08/14.md)
* [Matthew 02:7-8](https://git.door43.org/Door43/en_tn/src/master/mat/02/07.md)
* [Matthew 07:26-27](https://git.door43.org/Door43/en_tn/src/master/mat/07/26.md)

#### Word Data:####

* Strong's: H561, H562, H565, H1697, H1703, H3983, H4405, H4406, H6310, H6600, G518, G1024, G3050, G3054, G3055, G3056, G4086, G4487, G4935, G5023, G5542


---

<a id="written"/>

### written ###

#### Definition: ####

The phrase "as it is written" or "what is written" occurs frequently in the New Testament and usually refers to commands or prophecies that were written in the Hebrew scriptures.

* Sometimes "as it is written" refers to what was written in the Law of Moses.
* Other times it is a quote from what one of the prophets wrote in the Old Testament.
* This could be translated "as it is written in the Law of Moses" or "as the prophets wrote long ago" or "what it says in God's laws that Moses wrote down long ago".
* Another option is to keep "It is written" and give a footnote that explains what this means.

(See also: [command](kt.html#command), [law](kt.html#lawofmoses), [prophet](kt.html#prophet), [word of God](kt.html#wordofgod))

#### Bible References: ####

* [1 John 05:13-15](https://git.door43.org/Door43/en_tn/src/master/1jn/05/13.md)
* [Acts 13:28-29](https://git.door43.org/Door43/en_tn/src/master/act/13/28.md)
* [Exodus 32:15-16](https://git.door43.org/Door43/en_tn/src/master/exo/32/15.md)
* [John 21:24-25](https://git.door43.org/Door43/en_tn/src/master/jhn/21/24.md)
* [Luke 03:4](https://git.door43.org/Door43/en_tn/src/master/luk/03/04.md)
* [Mark 09:11-13](https://git.door43.org/Door43/en_tn/src/master/mrk/09/11.md)
* [Matthew 04:5-6](https://git.door43.org/Door43/en_tn/src/master/mat/04/05.md)
* [Revelation 01:1-3](https://git.door43.org/Door43/en_tn/src/master/rev/01/01.md)

#### Word Data:####

* Strong's: H3789, H7559, G1125


---

<a id="wrong"/>

### wrong, wrongs, wronged, wrongly, wrongfully, wrongdoer, wrongdoing, mistreat, mistreated, hurt, hurts, hurting, hurtful ###

#### Definition: ####

To "wrong" someone means to treat that person unjustly and dishonestly.

* The term "mistreat" means to act badly or roughly toward someone, causing physical or emotional harm to that person.
* The term "hurt" is more general and means to "cause someone harm in some way." It often has the meaning of "physically injure."
* Depending on the context, these terms could also be translated as "do wrong to" or, "treat unjustly" or "cause harm to" or treat in a harmful way" or "injure."

#### Bible References: ####

* [Acts 07:26-28](https://git.door43.org/Door43/en_tn/src/master/act/07/26.md)
* [Exodus 22:20-21](https://git.door43.org/Door43/en_tn/src/master/exo/22/20.md)
* [Genesis 16:5-6](https://git.door43.org/Door43/en_tn/src/master/gen/16/05.md)
* [Luke 06:27-28](https://git.door43.org/Door43/en_tn/src/master/luk/06/27.md)
* [Matthew 20:13-14](https://git.door43.org/Door43/en_tn/src/master/mat/20/13.md)
* [Psalms 071:12-13](https://git.door43.org/Door43/en_tn/src/master/psa/071/012.md)

#### Word Data:####

* Strong's: H205, H816, H2248, H2250, H2255, H2257, H2398, H2554, H2555, H3238, H3637, H4834, H5062, H5142, H5230, H5627, H5753, H5766, H5791, H5792, H5916, H6031, H6087, H6127, H6231, H6485, H6565, H6586, H7451, H7489, H7563, H7665, H7667, H7686, H8133, H8267, H8295, G91, G92, G93, G95, G264, G824, G983, G984, G1536, G1626, G1651, G1727, G1908, G2556, G2558, G2559, G2607, G3076, G3077, G3762, G4122, G5195, G5196


---

<a id="yeast"/>

### yeast, leaven, leavens, leavened, unleavened ###

#### Definition: ####

"Leaven" is a general term for a substance that causes bread dough to expand and rise. "Yeast" is a specific kind of leaven.

* In some English translations, the word for leaven is translated as "yeast," which is a modern leavening agent that fills the bread dough with gas bubbles, making the dough expand before baking it. The yeast is kneaded into the dough so that it spreads throughout the entire lump of dough.
* In Old Testament times, the leavening or rising agent was produced by allowing the dough to sit for awhile. Small amounts of dough from a previous batch of dough were saved as leavening for the next batch.
* When the Israelites escaped from Egypt, they didn't have time to wait for bread dough to rise, so they made bread without leaven to take with them on their journey. As a reminder of this, every year the Jewish people celebrate Passover by eating bread that has no leaven in it.
* The term "leaven" or "yeast" is used figuratively in the Bible as a picture of how sin spreads through a person's life or how sin can influence other people.
* It can also refer to false teaching which often spreads to many people and influences them.
* The term "leaven" is also used in a positive way to explain how the influence of God's kingdom spreads from person to person.

#### Translation Suggestions ####

* This could be translated as "leaven" or "substance that causes dough to rise" or "expanding agent." The word "rise" could be expressed as "expand" or "get bigger" or "puff up."
* If a local leavening agent is used for making bread dough rise, that term can be used. If the language has a well-known, general term that means, "leavening," this would be the best term to use.
  

(See also: [Egypt](names.html#egypt), [Passover](kt.html#passover), [unleavened bread](kt.html#unleavenedbread))

#### Bible References: ####

 

* [Exodus 12:5-8](https://git.door43.org/Door43/en_tn/src/master/exo/12/05.md)
* [Galatians 05:9-10](https://git.door43.org/Door43/en_tn/src/master/gal/05/09.md)
* [Luke 12:1](https://git.door43.org/Door43/en_tn/src/master/luk/12/01.md)
* [Luke 13:20-21](https://git.door43.org/Door43/en_tn/src/master/luk/13/20.md)
* [Matthew 13:33](https://git.door43.org/Door43/en_tn/src/master/mat/13/33.md)
* [Matthew 16:5-8](https://git.door43.org/Door43/en_tn/src/master/mat/16/05.md)

#### Word Data:####

* Strong's: H2556, H2557, H4682, H7603, G106, G2219, G2220


---

<a id="yoke"/>

### yoke, yokes, yoked ###

#### Definition: ####

A yoke is a piece of wood or metal attached to two or more animals to connect them for the purpose of pulling a plow or a cart. There are also several figurative meanings for this term.

   * The term "yoke" is used figuratively to refer to something that joins people for the purpose of working together, such as in serving Jesus.
   * Paul used the term "yokefellow" to refer to someone who was serving Christ as he was. This could also be translated as "fellow worker" or "fellow servant" or "coworker."
   * The term "yoke" is also often used figuratively to refer to a heavy load that someone has to carry, such as when being oppressed by slavery or persecution.
   * In most contexts, it is best to translate this term literally, using the local term for a yoke that is used for farming.
   * Other ways to translate the figurative use of this term could be, "oppressive burden" or "heavy load" or "bond," depending on the context.

(See also: [bind](kt.html#bond), [burden](#burden), [oppress](#oppress), [persecute](#persecute), [servant](#servant))

#### Bible References: ####

* [Acts 15:10-11](https://git.door43.org/Door43/en_tn/src/master/act/15/10.md)
* [Galatians 05:1-2](https://git.door43.org/Door43/en_tn/src/master/gal/05/01.md)
* [Genesis 27:39-40](https://git.door43.org/Door43/en_tn/src/master/gen/27/39.md)
* [Isaiah 09:4-5](https://git.door43.org/Door43/en_tn/src/master/isa/09/04.md)
* [Jeremiah 27:1-4](https://git.door43.org/Door43/en_tn/src/master/jer/27/01.md)
* [Matthew 11:28-30](https://git.door43.org/Door43/en_tn/src/master/mat/11/28.md)
* [Philippians 04:1-3](https://git.door43.org/Door43/en_tn/src/master/php/04/01.md)

#### Word Data:####

* Strong's: H3627, H4132, H4133, H5674, H5923, H6776, G2086, G2201, G2218, G4805


---

