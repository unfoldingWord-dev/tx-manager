# <a id="tw-section-names"/>Names

## <a id="tw-term-names-aaron"/>Aaron

### Facts:

Aaron was Moses' older brother. God chose Aaron to be the first high priest for the people of Israel.

* Aaron helped Moses speak to Pharaoh about letting the Israelites go free.
* While the Israelites were traveling through the desert, Aaron sinned by making an idol for the people to worship.
* God also appointed Aaron and his descendants to be the [priest](kt.html#priest) priests for the people of Israel.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [priest](kt.html#priest), [Moses](#moses), [Israel](kt.html#israel))

### Bible References:

* [1 Chronicles 23:12-14](https://git.door43.org/Door43/en_tn/src/master/1ch/23/12.md)
* [Acts 07:38-40](https://git.door43.org/Door43/en_tn/src/master/act/07/38.md)
* [Exodus 28:1-3](https://git.door43.org/Door43/en_tn/src/master/exo/28/01.md)
* [Luke 01:5-7](https://git.door43.org/Door43/en_tn/src/master/luk/01/05.md)
* [Numbers 16:44-46](https://git.door43.org/Door43/en_tn/src/master/num/16/44.md)

### Examples from the Bible stories:

* __[09:15](https://git.door43.org/Door43/en_tn/src/master/obs/09/15.md)__ God warned Moses and __Aaron__  that Pharaoh would be stubborn.
* __[10:05](https://git.door43.org/Door43/en_tn/src/master/obs/10/05.md)__ Pharaoh called Moses and __Aaron__  and told them that if they stopped the plague, the Israelites could leave Egypt.
* __[13:09](https://git.door43.org/Door43/en_tn/src/master/obs/13/09.md)__ God chose Moses' brother, __Aaron__, and Aaron's descendants to be his priests.
* __[13:11](https://git.door43.org/Door43/en_tn/src/master/obs/13/11.md)__ So they (the Israelites) brought gold to __Aaron__  and asked him to form it into an idol for them!
* __[14:07](https://git.door43.org/Door43/en_tn/src/master/obs/14/07.md)__ They (the Israelites) became angry with Moses and __Aaron__  and said, "Oh, why did you bring us to this horrible place?"

### Word Data:

* Strong's: H175, G2


## <a id="tw-term-names-abel"/>Abel

### Facts:

Abel was Adam and Eve's second son. He was Cain's younger brother.

 * Abel was a shepherd.
 * Abel sacrificed some of his animals as an offering to God.
 * God was pleased with Abel and his offerings.
 * Adam and Eve's firstborn son Cain murdered Abel.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md)) 

(See also: [Cain](#cain), [sacrifice](other.html#sacrifice), [shepherd](other.html#shepherd))

### Bible References:

* [Genesis 04:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/04/01.md)
* [Genesis 04:8-9](https://git.door43.org/Door43/en_tn/src/master/gen/04/08.md)
* [Hebrews 12:22-24](https://git.door43.org/Door43/en_tn/src/master/heb/12/22.md)
* [Luke 11:49-51](https://git.door43.org/Door43/en_tn/src/master/luk/11/49.md)
* [Matthew 23:34-36](https://git.door43.org/Door43/en_tn/src/master/mat/23/34.md)

### Word Data:

* Strong's: H01893, G6


## <a id="tw-term-names-abiathar"/>Abiathar

### Definition:

Abiathar was a high priest for the nation of Israel during the time of King David.

* When King Saul killed the priests, Abiathar escaped and went to David in the wilderness.
* Abiathar and another high priest named Zadok served David faithfully throughout his reign.
* After David's death, Abiathar helped Adonijah try to become king instead of Solomon. 
* Because of this, King Solomon removed Abiathar from the priesthood.
  
  (See also: [Zadok](#zadok), [Saul (OT)](#saul), [David](#david), [Solomon](#solomon), [Adonijah](#adonijah))

### Bible References:

* [1 Chronicles 27:32-34](https://git.door43.org/Door43/en_tn/src/master/1ch/27/32.md)
* [1 Kings 01:7-8](https://git.door43.org/Door43/en_tn/src/master/1ki/01/07.md)
* [1 Kings 02:22-23](https://git.door43.org/Door43/en_tn/src/master/1ki/02/22.md)
* [2 Samuel 17:15-16](https://git.door43.org/Door43/en_tn/src/master/2sa/17/15.md)
* [Mark 02:25-26](https://git.door43.org/Door43/en_tn/src/master/mrk/02/25.md)

### Word Data:

* Strong's: H54, G8


## <a id="tw-term-names-abijah"/>Abijah

### Facts:

Abijah was a king of Judah who reigned from 915 to 913 B.C. He was a son of King Rehoboam. There were also several other men named Abijah in the Old Testament:

* Samuel's sons Abijah and Joel were leaders over the people of Israel at Beersheba. Because Abijah and his brother were dishonest and greedy, the people asked Samuel to appoint a king to rule them instead.
* Abijah was one of the temple priests during the time of King David.
* Abijah was one of King Jeroboam's sons.
* Abijah was also a chief priest who returned with Zerubbabel to Jerusalem from the Babylonian captivity.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

### Bible References:

* [1 Kings 15:1-3](https://git.door43.org/Door43/en_tn/src/master/1ki/15/01.md)
* [1 Samuel 08:1-3](https://git.door43.org/Door43/en_tn/src/master/1sa/08/01.md)
* [2 Chronicles 13:1-3](https://git.door43.org/Door43/en_tn/src/master/2ch/13/01.md)
* [2 Chronicles 13:19-22](https://git.door43.org/Door43/en_tn/src/master/2ch/13/19.md)
* [Luke 01:5-7](https://git.door43.org/Door43/en_tn/src/master/luk/01/05.md)

### Word Data:

* Strong's: H29, G7


## <a id="tw-term-names-abimelech"/>Abimelech

### Facts:

Abimelech was a Philistine king over the region of Gerar during the time when Abraham and Isaac were living in the land of Canaan.

* Abraham deceived King Abimelech by telling him that Sarah was his sister rather than his wife.
* Abraham and Abimelech made an agreement regarding ownership of wells at Beersheba.
* Many years later, Isaac also deceived Abimelech and the other men of Gerar by saying that Rebekah was his sister, not his wife.
* King Abimelech rebuked Abraham, and later Isaac, for lying to him.
* Another man by the name of Abimelech was a son of Gideon and a brother of Jotham. Some translations may use a slightly different spelling of his name to make it clear that he is a different person from King Abimelech.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Beersheba](#beersheba), [Gerar](#gerar), [Gideon](#gideon), [Jotham](#jotham), [Philistines](#philistines))

### Bible References:

* [2 Samuel 11:21](https://git.door43.org/Door43/en_tn/src/master/2sa/11/21.md)
* [Genesis 20:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/20/01.md)
* [Genesis 20:4-5](https://git.door43.org/Door43/en_tn/src/master/gen/20/04.md)
* [Genesis 21:22-24](https://git.door43.org/Door43/en_tn/src/master/gen/21/22.md)
* [Genesis 26:9-11](https://git.door43.org/Door43/en_tn/src/master/gen/26/09.md)
* [Judges 09:52-54](https://git.door43.org/Door43/en_tn/src/master/jdg/09/52.md)

### Word Data:

* Strong's: H40


## <a id="tw-term-names-abner"/>Abner

### Definition:

Abner was a cousin of King Saul in the Old Testament.

* Abner was the chief commander of Saul's army, and introduced young David to Saul after David killed Goliath the giant.
* After King Saul's death, Abner appointed Saul's son Ishbosheth as king in Israel, while David was appointed king in Judah.
* Later, Abner was treacherously killed by David's chief commander, Joab.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

### Bible References:

* [1 Chronicles 26:26-28](https://git.door43.org/Door43/en_tn/src/master/1ch/26/26.md)
* [1 Kings 02:5-6](https://git.door43.org/Door43/en_tn/src/master/1ki/02/05.md)
* [1 Kings 02:32-33](https://git.door43.org/Door43/en_tn/src/master/1ki/02/32.md)
* [1 Samuel 17:55-56](https://git.door43.org/Door43/en_tn/src/master/1sa/17/55.md)
* [2 Samuel 03:22-23](https://git.door43.org/Door43/en_tn/src/master/2sa/03/22.md)

### Word Data:

* Strong's: H74


## <a id="tw-term-names-abraham"/>Abraham, Abram

### Facts:

Abram was a Chaldean man from the city of Ur who was chosen by God to be the forefather of the Israelites. God changed his name to "Abraham."

* The name "Abram" means "exalted father."
* "Abraham" means "father of many."
* God promised Abraham that he would have many descendants, who would become a great nation.
* Abraham believed God and obeyed him. God led Abraham to move from Chaldea to the land of Canaan.
* Abraham and his wife Sarah, when they were very old and living in the land of Canaan, had a son, Isaac.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Canaan](#canaan), [Chaldea](#chaldeans), [Sarah](#sarah), [Isaac](#isaac))

### Bible References:

* [Galatians 03:6-9](https://git.door43.org/Door43/en_tn/src/master/gal/03/06.md)
* [Genesis 11:29-30](https://git.door43.org/Door43/en_tn/src/master/gen/11/29.md)
* [Genesis 21:1-4](https://git.door43.org/Door43/en_tn/src/master/gen/21/01.md)
* [Genesis 22:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/22/01.md)
* [James 02:21-24](https://git.door43.org/Door43/en_tn/src/master/jas/02/21.md)
* [Matthew 01:1-3](https://git.door43.org/Door43/en_tn/src/master/mat/01/01.md)

### Examples from the Bible stories:

* __[04:06](https://git.door43.org/Door43/en_tn/src/master/obs/04/06.md)__ When __Abram__  arrived in Canaan, God said, "Look all around you. I will give to you and your descendants all the land that you can see as an inheritance."
* __[05:04](https://git.door43.org/Door43/en_tn/src/master/obs/05/04.md)__ Then God changed __Abram__'s name to __Abraham__, which means "father of many."
* __[05:05](https://git.door43.org/Door43/en_tn/src/master/obs/05/05.md)__ About a year later, when __Abraham__  was 100 years old and Sarah was 90, Sarah gave birth to Abraham's son.
* __[05:06](https://git.door43.org/Door43/en_tn/src/master/obs/05/06.md)__ When Isaac was a young man, God tested __Abraham's__  faith by saying, "Take Isaac, your only son, and kill him as a sacrifice to me."
* __[06:01](https://git.door43.org/Door43/en_tn/src/master/obs/06/01.md)__ When __Abraham__  was very old and his son, Isaac, had grown to be a man, __Abraham__  sent one of his servants back to the land where his relatives lived to find a wife for his son, Isaac.
* __[06:04](https://git.door43.org/Door43/en_tn/src/master/obs/06/04.md)__ After a long time, __Abraham__  died and all of the promises that God had made to him in the covenant were passed on to Isaac.
* __[21:02](https://git.door43.org/Door43/en_tn/src/master/obs/21/02.md)__ God promised __Abraham__  that through him all people groups of the world would receive a blessing.

### Word Data:

* Strong's: H87, H85, G11


## <a id="tw-term-names-absalom"/>Absalom

### Facts:

Absalom was the third son of King David. He was known for his handsome appearance and fiery temperament.

* When Absalom's sister Tamar was raped by their half-brother, Amnon, Absalom made a plan to have Amnon killed.
* After the murder of Amnon, Absalom fled to the region of Geshur (where his mother Maacah was from) and stayed there three years. Then King David sent for him to come back to Jerusalem, but did not allow Absalom to come into his presence for two years.
* Absalom turned some of the people against King David and led a revolt against him.
* David's army fought against Absalom and killed him. David was very grieved when this happened.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Geshur](#geshur), [Amnon](#amnon))

### Bible References:

* [1 Chronicles 03:1-3](https://git.door43.org/Door43/en_tn/src/master/1ch/03/01.md)
* [1 Kings 01:5-6](https://git.door43.org/Door43/en_tn/src/master/1ki/01/05.md)
* [2 Samuel 15:1-2](https://git.door43.org/Door43/en_tn/src/master/2sa/15/01.md)
* [2 Samuel 17:1-4](https://git.door43.org/Door43/en_tn/src/master/2sa/17/01.md)
* [2 Samuel 18:18](https://git.door43.org/Door43/en_tn/src/master/2sa/18/18.md)
* [Psalm 003:1-2](https://git.door43.org/Door43/en_tn/src/master/psa/003/001.md)

### Word Data:

* Strong's: H53


## <a id="tw-term-names-adam"/>Adam

### Facts:

Adam was the first person whom God created. He and his wife Eve were made in the image of God. 

* God formed Adam from dirt and breathed life into him.
* Adam's name sounds similar to the Hebrew word for "red dirt" or "ground."
* The name "Adam" is the same as the Old Testament word for "mankind" or "human being."
* All people are descendants of Adam and Eve.
* Adam and Eve disobeyed God. This separated them from God and caused sin and death to come into the world.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [death](other.html#death), [descendant](other.html#descendant), [Eve](#eve), [image of God](kt.html#imageofgod), [life](kt.html#life))

### Bible References:

* [1 Timothy 02:13-15](https://git.door43.org/Door43/en_tn/src/master/1ti/02/13.md)
* [Genesis 03:17-19](https://git.door43.org/Door43/en_tn/src/master/gen/03/17.md)
* [Genesis 05:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/05/01.md)
* [Genesis 11:5-7](https://git.door43.org/Door43/en_tn/src/master/gen/11/05.md)
* [Luke 03:36-38](https://git.door43.org/Door43/en_tn/src/master/luk/03/36.md)
* [Romans 05:14-15](https://git.door43.org/Door43/en_tn/src/master/rom/05/14.md)

### Examples from the Bible stories:

* __[01:09](https://git.door43.org/Door43/en_tn/src/master/obs/01/09.md)__ Then God said, "Let us make human beings in our image to be like us."
* __[01:10](https://git.door43.org/Door43/en_tn/src/master/obs/01/10.md)__ This man's name was __Adam__. God planted a garden where __Adam__  could live, and put him there to care for it.
* __[01:12](https://git.door43.org/Door43/en_tn/src/master/obs/01/12.md)__ Then God said, "It is not good for man to be alone." But none of the animals could be __Adam's__  helper.
* __[02:11](https://git.door43.org/Door43/en_tn/src/master/obs/02/11.md)__ And God clothed __Adam__  and Eve with animal skins.
* __[02:12](https://git.door43.org/Door43/en_tn/src/master/obs/02/12.md)__ So God sent __Adam__  and Eve away from the beautiful garden.
* __[49:08](https://git.door43.org/Door43/en_tn/src/master/obs/49/08.md)__ When __Adam__  and Eve sinned, it affected all of their descendants.
* __[50:16](https://git.door43.org/Door43/en_tn/src/master/obs/50/16.md)__ Because __Adam__  and Eve disobeyed God and brought sin into this world, God cursed it and decided to destroy it.
*

### Word Data:

* Strong's: H120, G76


## <a id="tw-term-names-adonijah"/>Adonijah

### Definition:

Adonijah was the fourth son of King David.

* Adonijah tried to take over as king of Israel after the deaths of his brothers Absalom and Amnon.
* God, however, had promised that David's son Solomon would be king., so Adonijah's plot was overthrown and Solomon was made king.
* When Adonijah tried a second time to make himself king, Solomon put him to death.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [David](#david), [Solomon](#solomon)) 

### Bible References:

### Word Data:

* Strong's: G138


## <a id="tw-term-names-ahab"/>Ahab

### Facts:

Ahab was a very evil king who reigned over the northern kingdom of Israel from 875 to 854 BC.

* King Ahab influenced the people of Israel to worship false gods.
* The prophet Elijah confronted Ahab and told him there would be a severe drought for three and a half years as punishment for the sins that Ahab caused Israel to commit.
* Ahab and his wife Jezebel did many other evil things, including using their power to kill innocent people.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Baal](#baal), [Elijah](#elijah), [Jezebel](#jezebel), [kingdom of Israel](#kingdomofisrael), [Yahweh](kt.html#yahweh))

### Bible References:

* [1 Kings 18:1-2](https://git.door43.org/Door43/en_tn/src/master/1ki/18/01.md)
* [1 Kings 20:1-3](https://git.door43.org/Door43/en_tn/src/master/1ki/20/01.md)
* [2 Chronicles 21:6-7](https://git.door43.org/Door43/en_tn/src/master/2ch/21/06.md)
* [2 Kings 09:7-8](https://git.door43.org/Door43/en_tn/src/master/2ki/09/07.md)

### Examples from the Bible stories:

* __[19:02](https://git.door43.org/Door43/en_tn/src/master/obs/19/02.md)__ Elijah was a prophet when __Ahab__  was king over the kingdom of Israel. __Ahab__  was an evil man who encouraged people to worship a false god named Baal.
* __[19:03](https://git.door43.org/Door43/en_tn/src/master/obs/19/03.md)__ __Ahab__  and his army looked for Elijah, but they could not find him.
* __[19:05](https://git.door43.org/Door43/en_tn/src/master/obs/19/05.md)__ After three and a half years, God told Elijah to return to the kingdom of Israel and speak with __Ahab__  because he was going to send rain again.

### Word Data:

* Strong's: H256


## <a id="tw-term-names-ahasuerus"/>Ahasuerus

### Facts:

Ahasuerus was a king who ruled over the ancient kingdom of Persia for twenty years.

* This was during the time the exiled Jews were living in Babylonia, which had come under Persian rule.
* Another name for this king may have been Xerxes.
* After sending away his queen in a fit of anger, King Ahasuerus later chose a Jewish woman named Esther to be his new wife and queen.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Babylon](#babylon), [Esther](#esther), [Ethiopia](#ethiopia), [exile](other.html#exile), [Persia](#persia))

### Bible References:

* [Daniel 09:1-2](https://git.door43.org/Door43/en_tn/src/master/dan/09/01.md)
* [Esther 10:1-2](https://git.door43.org/Door43/en_tn/src/master/est/10/01.md)
* [Ezra 04:7-8](https://git.door43.org/Door43/en_tn/src/master/ezr/04/07.md)

### Word Data:

* Strong's: H325


## <a id="tw-term-names-ahaz"/>Ahaz

### Definition:

Ahaz was a wicked king who ruled over the kingdom of Judah from 732 BC to 716 BC. This was about 140 years before the time when many people in Israel and Judah were taken as captives to Babylonia.

* While he was ruling Judah, Ahaz had an altar built for worshiping the false gods of the Assyrians, which caused the people to turn away from the one true God, Yahweh.
* King Ahaz was 20 years old when he started to rule over Judah, and he ruled for 16 years.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Babylon](#babylon))

### Bible References:

* [1 Chronicles 08:35-37](https://git.door43.org/Door43/en_tn/src/master/1ch/08/35.md)
* [2 Chronicles 28:1-2](https://git.door43.org/Door43/en_tn/src/master/2ch/28/01.md)
* [2 Kings 16:19-20](https://git.door43.org/Door43/en_tn/src/master/2ki/16/19.md)
* [Hosea 01:1-2](https://git.door43.org/Door43/en_tn/src/master/hos/01/01.md)
* [Isaiah 01:1](https://git.door43.org/Door43/en_tn/src/master/isa/01/01.md)
* [Isaiah 07:3-4](https://git.door43.org/Door43/en_tn/src/master/isa/07/03.md)
* [Matthew 01:9-11](https://git.door43.org/Door43/en_tn/src/master/mat/01/09.md)

### Word Data:

* Strong's: H271


## <a id="tw-term-names-ahaziah"/>Ahaziah

### Facts:

Ahaziah was the name of two kings: one ruled over the kingdom of Israel, and the other ruled over the kingdom of Judah.

* Judah's King Ahaziah was the son of King Jehoram. He reigned for one year (841 B.C.) and then was killed by Jehu. Ahaziah's young son Joash eventually took his place as king.
* Israel's King Ahaziah was the son of King Ahab. He reigned for two years (850-49 B.C.). He died from injuries suffered in a fall at his palace, and his brother Joram became king.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Jehu](#jehu), [Ahab](#ahab), [Jeroboam](#jeroboam), [Joash](#joash))

### Bible References:
* [1 Kings 22:39-40](https://git.door43.org/Door43/en_tn/src/master/1ki/22/39.md)
* [2 Chronicles 22:1-3](https://git.door43.org/Door43/en_tn/src/master/2ch/22/01.md)
* [2 Chronicles 25:23-24](https://git.door43.org/Door43/en_tn/src/master/2ch/25/23.md)
* [2 Kings 11:1-3](https://git.door43.org/Door43/en_tn/src/master/2ki/11/01.md)

### Word Data:

* Strong's: H274


## <a id="tw-term-names-ahijah"/>Ahijah

### Facts:

Ahijah was the name of several different men in the Old Testament. The following are some of these men:

* Ahijah was the name of a priest in the time of Saul.
* A man named Ahijah was a secretary during the reign of King Solomon.
* Ahijah was the name of a prophet from Shiloh who predicted that the nation of Israel would be divided into two kingdoms.
* The father of King Baasha of Israel was also named Ahijah.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Baasha](#baasha), [Shiloh](#shiloh))

### Bible References:

* [1 Kings 15:27-28](https://git.door43.org/Door43/en_tn/src/master/1ki/15/27.md)
* [1 Kings 21:21-22](https://git.door43.org/Door43/en_tn/src/master/1ki/21/21.md)
* [1 Samuel 14:18-19](https://git.door43.org/Door43/en_tn/src/master/1sa/14/18.md)
* [2 Chronicles 10:15](https://git.door43.org/Door43/en_tn/src/master/2ch/10/15.md)

### Word Data:

* Strong's: H281


## <a id="tw-term-names-ai"/>Ai

### Facts:

In Old Testament times, Ai was the name of a Canaanite town located just south of Bethel and about 8 km northwest of Jericho.

* After defeating Jericho, Joshua led the Israelites in an attack of Ai. But they were easily defeated because God was not pleased with them.
* An Israelite named Achan had stolen plunder from Jericho, and God ordered that he and his family be killed. Then God helped the Israelites defeat the people of Ai.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Bethel](#bethel), [Jericho](#jericho))

### Bible References:

* [Ezra 02:27-30](https://git.door43.org/Door43/en_tn/src/master/ezr/02/27.md)
* [Genesis 12:8-9](https://git.door43.org/Door43/en_tn/src/master/gen/12/08.md)
* [Genesis 13:3-4](https://git.door43.org/Door43/en_tn/src/master/gen/13/03.md)
* [Joshua 07:2-3](https://git.door43.org/Door43/en_tn/src/master/jos/07/02.md)
* [Joshua 08:10-12](https://git.door43.org/Door43/en_tn/src/master/jos/08/10.md)

### Word Data:

* Strong's: H5857


## <a id="tw-term-names-amalekite"/>Amalek, Amalekite, Amalekites

### Facts:

The Amalekites were a nomadic people group who lived throughout the southern part of Canaan, from the Negev desert to the country of Arabia.  This people group was descended from Amalek, the grandson of Esau.

 
* The Amalekites were bitter enemies of Israel from the time when Israel first came to live in Canaan.
* Sometimes the term "Amalek" is used figuratively to refer to all the Amalekites. (See: [synecdoche](https://git.door43.org/Door43/en_man/src/master/translate/figs-synecdoche/01.md))
* In one battle against the Amalekites, when Moses held up his hands, the Israelites were winning. When he got tired and his hands came down, they started losing. So Aaron and Hur helped Moses keep his hands up until the Israelite army had defeated the Amalekites.
* Both King Saul and King David led military expeditions against the Amalekites.
* After one victory over the Amalekites, Saul disobeyed God by keeping some of the plunder and by not killing the Amalekite king as God had commanded him to do.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Arabia](#arabia), [David](#david), [Esau](#esau), [Negev](#negev), [Saul (OT)](#saul))



### Bible References:

* [1 Chronicles 04:42-43](https://git.door43.org/Door43/en_tn/src/master/1ch/04/42.md)
* [2 Samuel 01:8-10](https://git.door43.org/Door43/en_tn/src/master/2sa/01/08.md)
* [Exodus 17:8-10](https://git.door43.org/Door43/en_tn/src/master/exo/17/08.md)
* [Numbers 14:23-25](https://git.door43.org/Door43/en_tn/src/master/num/14/23.md)

### Word Data:

* Strong's: H6002, H6003


## <a id="tw-term-names-amaziah"/>Amaziah

### Facts:

Amaziah became king over the kingdom of Judah when his father, King Joash, was murdered.

* King Amaziah reigned over Judah for twenty-nine years, from 796 BC to 767 BC.
* He was a good king, but he did not destroy the high places where idols were worshiped.
* Amaziah eventually put to death all the men who were responsible for the murder of his father.
* He defeated the rebellious Edomites and brought them back under the control of the Kingdom of Judah.
* He challenged King Jehoash of Israel to a battle, but lost. Part of the walls of Jerusalem were broken down and the silver and gold vessels of the temple were stolen.
* Years later King Amaziah turned away from Yahweh and certain men in Jerusalem plotted together and killed him.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Joash](#joash), [Edom](#edom))

### Bible References:

* [1 Chronicles 03:10-12](https://git.door43.org/Door43/en_tn/src/master/1ch/03/10.md)
* [1 Chronicles 04:34-38](https://git.door43.org/Door43/en_tn/src/master/1ch/04/34.md)
* [2 Chronicles 25:9-10](https://git.door43.org/Door43/en_tn/src/master/2ch/25/09.md)
* [2 Kings 14:8-10](https://git.door43.org/Door43/en_tn/src/master/2ki/14/08.md)

### Word Data:

* Strong's: H558


## <a id="tw-term-names-ammon"/>Ammon, Ammonite, Ammonites

### Facts:

The "people of Ammon" or the "Ammonites" were a people group in Canaan. They were descended from Ben-ammi, who was the son of Lot by his younger daughter.

* The term "Ammonitess" refers specifically to a female Ammonite. This could also be translated as "Ammonite woman."
* The Ammonites lived east of the Jordan River and were enemies of the Israelites.
* At one point, the Ammonites hired a prophet named Balaam to curse Israel, but God did not allow him to do it.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [curse](kt.html#curse), [Jordan River](#jordanriver), [Lot](#lot))

### Bible References:

* [1 Chronicles 19:1-3](https://git.door43.org/Door43/en_tn/src/master/1ch/19/01.md)
* [Ezekiel 25:1-2](https://git.door43.org/Door43/en_tn/src/master/ezk/25/01.md)
* [Genesis 19:36-38](https://git.door43.org/Door43/en_tn/src/master/gen/19/36.md)
* [Joshua 12:1-2](https://git.door43.org/Door43/en_tn/src/master/jos/12/01.md)
* [Judges 11:26-28](https://git.door43.org/Door43/en_tn/src/master/jdg/11/26.md)
* [Zephaniah 02:8-9](https://git.door43.org/Door43/en_tn/src/master/zep/02/08.md)

### Word Data:

* Strong's: H5983, H5984, H5985


## <a id="tw-term-names-amnon"/>Amnon

### Facts:

Amnon was the oldest son of King David. His mother was King David's wife Ahinoam.

* Amnon raped his half-sister Tamar, who was also Absalom's sister.
* Because of this, Absalom plotted against Amnon and had him killed.

(See also: [David](#david), [Absalom](#absalom))

### Bible References:

* [1 Chronicles 03:1-3](https://git.door43.org/Door43/en_tn/src/master/1ch/03/01.md)
* [2 Samuel 13:1-2](https://git.door43.org/Door43/en_tn/src/master/2sa/13/01.md)
* [2 Samuel 13:7-9](https://git.door43.org/Door43/en_tn/src/master/2sa/13/07.md)

### Word Data:

* Strong's: H550


## <a id="tw-term-names-amorite"/>Amorite, Amorites

### Facts:

The Amorites were a powerful group of people who were descended from Noah's grandson Canaan.

* Their name means "high one," which may refer to the mountainous regions where they lived or to the fact that they were known to be very tall.
* The Amorites lived in regions on both sides of the Jordan River. The city of Ai was inhabited by Amorites.
* God refers to the "sin of the Amorites," which included their worship of false gods and the sinful practices associated.
* Joshua led the Israelites in destroying the Amorites, as God had commanded them to do.

### Bible References:

* [Amos 02:9-10](https://git.door43.org/Door43/en_tn/src/master/amo/02/09.md)
* [Ezekiel 16:1-3](https://git.door43.org/Door43/en_tn/src/master/ezk/16/01.md)
* [Genesis 10:15-18](https://git.door43.org/Door43/en_tn/src/master/gen/10/15.md)
* [Genesis 15:14-16](https://git.door43.org/Door43/en_tn/src/master/gen/15/14.md)
* [Joshua 09:9-10](https://git.door43.org/Door43/en_tn/src/master/jos/09/09.md)

### Examples from the Bible stories:

  __*[15:07](https://git.door43.org/Door43/en_tn/src/master/obs/15/07.md)__ Sometime later, the kings of another people group in Canaan, the __Amorites__, heard that the Gibeonites had made a peace treaty with the Israelites, so they combined their armies into one large army and attacked Gibeon. 
  __*[15:08](https://git.door43.org/Door43/en_tn/src/master/obs/15/08.md)__ In the early morning they surprised the __Amorite__ armies and attacked them. 
  __*[15:09](https://git.door43.org/Door43/en_tn/src/master/obs/15/09.md)__ God fought for Israel that day. He caused the __Amorites__ to be confused and he sent large hailstones that killed many of the __Amorites__.
  __*[15:10](https://git.door43.org/Door43/en_tn/src/master/obs/15/10.md)__ God also caused the sun to stay in one place in the sky so that Israel would have enough time to completely defeat the __Amorites__.

### Word Data:

* Strong's: H567,


## <a id="tw-term-names-amos"/>Amos

### Facts:

Amos was an Israelite prophet who lived during the time of King Uzziah of Judah.

* Before being called as a prophet, Amos was originally a shepherd and fig farmer living in the kingdom of Judah.
* Amos prophesied against the prosperous northern kingdom of Israel regarding their unjust treatment of people.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [fig](other.html#fig), [Judah](#judah), [kingdom of Israel](#kingdomofisrael), [shepherd](other.html#shepherd), [Uzziah](#uzziah))

### Bible References:

* [Amos 01:1-2](https://git.door43.org/Door43/en_tn/src/master/amo/01/01.md)

### Word Data:

* Strong's: H5986


## <a id="tw-term-names-amoz"/>Amoz

### Facts:

Amoz was the father of the prophet Isaiah.

* The only times he is mentioned in the Bible are when Isaiah is identified as the "son of Amoz."
* This name is different from the name of the prophet Amos and should be spelled differently.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Amos](#amos), [Isaiah](#isaiah))

### Bible References:

* [2 Kings 19:1-2](https://git.door43.org/Door43/en_tn/src/master/2ki/19/01.md)
* [Isaiah 37:1-2](https://git.door43.org/Door43/en_tn/src/master/isa/37/01.md)
* [Isaiah 37:21-23](https://git.door43.org/Door43/en_tn/src/master/isa/37/21.md)

### Word Data:

* Strong's: H531


## <a id="tw-term-names-andrew"/>Andrew

### Facts:

Andrew was one of twelve men whom Jesus chose to be his closest disciples (later called apostles).

* Andrew's brother was Simon Peter. Both of them were fishermen.
* Peter and Andrew were fishing in the Sea of Galilee when Jesus called them to be his disciples.
* Before Peter and Andrew met Jesus, they had been disciples of John the Baptizer.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [apostle](kt.html#apostle), [disciple](kt.html#disciple), [the twelve](kt.html#thetwelve))

### Bible References:

* [Acts 01:12-14](https://git.door43.org/Door43/en_tn/src/master/act/01/12.md)
* [John 01:40-42](https://git.door43.org/Door43/en_tn/src/master/jhn/01/40.md)
* [Mark 01:16-18](https://git.door43.org/Door43/en_tn/src/master/mrk/01/16.md)
* [Mark 01:29-31](https://git.door43.org/Door43/en_tn/src/master/mrk/01/29.md)
* [Mark 03:17-19](https://git.door43.org/Door43/en_tn/src/master/mrk/03/17.md)
* [Matthew 04:18-20](https://git.door43.org/Door43/en_tn/src/master/mat/04/18.md)
* [Matthew 10:2-4](https://git.door43.org/Door43/en_tn/src/master/mat/10/02.md)

### Word Data:

* Strong's: G406


## <a id="tw-term-names-annas"/>Annas

### Facts:

Annas was the Jewish high priest in Jerusalem for 10 years, from approximately AD 6 to AD 15. Then he was removed from the high priesthood by the Roman government, although he continued to be an influential leader among the Jews.

* Annas was father-in-law to Caiaphas, the official high priest during the ministry of Jesus.
* After high priests retired, they still kept the title, along with some of the responsibilities of the office, so Annas was still referred to as high priest during the priesthood of Caiaphas and others. 
* During his trial before the Jewish leaders, Jesus was first brought to Annas for questioning.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [high priest](kt.html#highpriest), [priest](kt.html#priest))

### Bible References:

* [Acts 04:5-7](https://git.door43.org/Door43/en_tn/src/master/act/04/05.md)
* [John 18:22-24](https://git.door43.org/Door43/en_tn/src/master/jhn/18/22.md)
* [Luke 03:1-2](https://git.door43.org/Door43/en_tn/src/master/luk/03/01.md)

### Word Data:

* Strong's: G452


## <a id="tw-term-names-antioch"/>Antioch

### Facts:

Antioch was the name of two cities in the New Testament. One was in Syria, near the coast of the Mediterranean Sea. The other was in the Roman province of Pisidia, near the city of Colossae.

* The local church at Antioch of Syria was the first place where believers in Jesus were called "Christians." The church there was also active in sending out missionaries to reach the Gentiles.
* The leaders of the church in Jerusalem sent a letter to the believers in the church at Antioch in Syria to help them know they didn't have to keep the Jewish laws in order to be Christians.
* Paul, Barnabas and John Mark traveled to the Antioch in Pisidia to share the gospel. Some Jews from other cities came there to stir up trouble, and they tried to kill Paul. But many other people, both Jews and Gentiles, listened to the teaching and believed in Jesus.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also:[Barnabas](#barnabas), [Colossae](#colossae), [John Mark](#johnmark), [Paul](#paul), [province](other.html#province), [Rome](#rome), [Syria](#syria))   

### Bible References:

* [2 Timothy 03:10-13](https://git.door43.org/Door43/en_tn/src/master/2ti/03/10.md)
* [Acts 06:5-6](https://git.door43.org/Door43/en_tn/src/master/act/06/05.md)
* [Acts 11:19-21](https://git.door43.org/Door43/en_tn/src/master/act/11/19.md)
* [Acts 11:25-26](https://git.door43.org/Door43/en_tn/src/master/act/11/25.md)
* [Galatians 02:11-12](https://git.door43.org/Door43/en_tn/src/master/gal/02/11.md)

### Word Data:

* Strong's: G491


## <a id="tw-term-names-apollos"/>Apollos

### Facts:

Apollos was a Jew from the city of Alexandria in Egypt who had a special ability in teaching people about Jesus.

* Apollos was well educated in the Hebrew Scriptures and was a gifted speaker.
* He was instructed by two Christians in Ephesus named Aquila and Priscilla.
* Paul emphasized that he and Apollos, as well as other evangelists and teachers, were working toward the same goal of helping people to believe in Jesus.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Aquila](#aquila), [Ephesus](#ephesus), [Priscilla](#priscilla), [word of God](kt.html#wordofgod))

### Bible References:

* [1 Corinthians 01:12-13](https://git.door43.org/Door43/en_tn/src/master/1co/01/12.md)
* [1 Corinthians 16:10-12](https://git.door43.org/Door43/en_tn/src/master/1co/16/10.md)
* [Acts 18:24-26](https://git.door43.org/Door43/en_tn/src/master/act/18/24.md)
* [Titus 03:12-13](https://git.door43.org/Door43/en_tn/src/master/tit/03/12.md)

### Word Data:

* Strong's: G625


## <a id="tw-term-names-aquila"/>Aquila

### Facts:

Aquila was a Jewish Christian from the province of Pontus, a region along the southern coast of the Black Sea.
 
* Aquila and Priscilla lived in Rome, Italy, for a time, but then the Roman emperor, Claudius, forced all Jews to leave Rome. 
* After that Aquila and Priscilla traveled to Corinth, where they met the apostle Paul.
* They worked as tentmakers with Paul and also helped him with his missionary work.
* Both Aquila and Priscilla taught believers the truth about Jesus; one of those believers was a gifted teacher named Apollos.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Apollos](#apollos), [Corinth](#corinth), [Rome](#rome))

### Bible References:

* [1 Corinthians 16:19-20](https://git.door43.org/Door43/en_tn/src/master/1co/16/19.md)
* [2 Timothy 04:19-22](https://git.door43.org/Door43/en_tn/src/master/2ti/04/19.md)
* [Acts 18:1-3](https://git.door43.org/Door43/en_tn/src/master/act/18/01.md)
* [Acts 18:24-26](https://git.door43.org/Door43/en_tn/src/master/act/18/24.md)

### Word Data:

* Strong's: G207


## <a id="tw-term-names-arabah"/>Arabah

### Facts:

The Old Testament term "Arabah" often refers to a very large desert and plains region that includes the valley surrounding the Jordan River and extends south to the northern tip of the Red Sea.

* The Israelites traveled through this desert region on their journey from Egypt to the land of Canaan.
* The "Sea of the Arabah" could also be translated as "sea located in the Arabah desert region." This sea is often referred to as the "Salt Sea" or the "Dead Sea."
* The term "arabah" can also be a general reference to any desert region.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [desert](other.html#desert), [Sea of Reeds](#redsea), [Jordan River](#jordanriver), [Canaan](#canaan), [Salt Sea](#saltsea), [Egypt](#egypt))

### Bible References:

* [1 Samuel 23:24-25](https://git.door43.org/Door43/en_tn/src/master/1sa/23/24.md)
* [2 Kings 25:4-5](https://git.door43.org/Door43/en_tn/src/master/2ki/25/04.md)
* [2 Samuel 02:28-29](https://git.door43.org/Door43/en_tn/src/master/2sa/02/28.md)
* [Jeremiah 02:4-6](https://git.door43.org/Door43/en_tn/src/master/jer/02/04.md)
* [Job 24:5-7](https://git.door43.org/Door43/en_tn/src/master/job/24/05.md)
* [Zechariah 14:9-11](https://git.door43.org/Door43/en_tn/src/master/zec/14/09.md)

### Word Data:

* Strong's: H1026, H6160


## <a id="tw-term-names-arabia"/>Arabia, Arabian, Arabians

### Facts:

Arabia is the largest peninsula in the world, covering nearly 3,000,000 square kilometers. It is located southeast of Israel, and is bordered by the Red Sea, the Arabian Sea, and the Persian Gulf.

* The term "Arabian" is used to refer to someone who lives in Arabia or to something that is connected with Arabia.
* The earliest people to live in Arabia were grandchildren of Shem. Other early inhabitants of Arabia included Abraham's son Ishmael and his descendants, as well as descendants of Esau.
* The desert region where the Israelites wandered for 40 years was located in Arabia.
* After becoming a believer in Jesus, the apostle Paul spent a few years in the desert of Arabia.
* In his letter to the Christians in Galatia, Paul mentioned that Mt. Sinai was located in Arabia.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Esau](#esau), [Galatia](#galatia), [Ishmael](#ishmael), [Shem](#shem), [Sinai](#sinai))

### Bible References:

* [1 Kings 10:14-15](https://git.door43.org/Door43/en_tn/src/master/1ki/10/14.md)
* [Acts 02:8-11](https://git.door43.org/Door43/en_tn/src/master/act/02/08.md)
* [Galatians 01:15-17](https://git.door43.org/Door43/en_tn/src/master/gal/01/15.md)
* [Galatians 04:24-25](https://git.door43.org/Door43/en_tn/src/master/gal/04/24.md)
* [Jeremiah 25:24-26](https://git.door43.org/Door43/en_tn/src/master/jer/25/24.md)
* [Nehemiah 02:19-20](https://git.door43.org/Door43/en_tn/src/master/neh/02/19.md)

### Word Data:

* Strong's: H6152, H6153, H6163, G688, G690


## <a id="tw-term-names-aram"/>Aram, Aramean, Arameans, Aramaic

### Definition:

"Aram" was the name of two men in the Old Testament. It was also the name of a region northeast of Canaan, where modern-day Syria is located.

* The people living in Aram became known as "Arameans" and spoke "Aramaic." Jesus and other Jews of his time also spoke Aramaic.
* One of Shem's sons was named Aram. Another man named Aram was a cousin of Rebekah. It is probable that the region of Aram was named after one of these two men.
* Aram later became known by the Greek name "Syria."
* The term "Paddan Aram" means "plain of Aram" and this plain was located in the northern part of Aram.
* Some of Abraham's relatives lived in the city of Haran, which was located in "Paddan Aram."
* In the Old Testament, sometimes the terms "Aram" and "Paddan Aram" refer to the same region.
* The term "Aram Naharaim" may mean "Aram of Two Rivers." This region was located in the northern part of Mesopotamia and was to the east of "Paddan Aram."

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Mesopotamia](#mesopotamia), [Paddan Aram](#paddanaram), [Rebekah](#rebekah), [Shem](#shem), [Syria](#syria))

### Bible References:

* [1 Chronicles 01:17-19](https://git.door43.org/Door43/en_tn/src/master/1ch/01/17.md)
* [2 Samuel 08:5-6](https://git.door43.org/Door43/en_tn/src/master/2sa/08/05.md)
* [Amos 01:5](https://git.door43.org/Door43/en_tn/src/master/amo/01/05.md)
* [Ezekiel 27:16-18](https://git.door43.org/Door43/en_tn/src/master/ezk/27/16.md)
* [Genesis 31:19-21](https://git.door43.org/Door43/en_tn/src/master/gen/31/19.md)
* [Hosea 12:11-12](https://git.door43.org/Door43/en_tn/src/master/hos/12/11.md)
* [Psalm 060:1](https://git.door43.org/Door43/en_tn/src/master/psa/060/001.md)

### Word Data:

* Strong's: H758, H763, G689


## <a id="tw-term-names-ararat"/>Ararat

### Facts:

In the Bible, "Ararat" is the name given to a land, a kingdom, and a mountain range.

* The "land of Ararat" was probably located in what is now the northeastern part of the country of Turkey.
* Ararat is best known as the name of the mountain that Noah's ark came to rest on after the waters of the great flood began to recede.
* In modern times, a mountain called "Mount Ararat" is often thought to be the location of the "mountains of Ararat" in the Bible.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [ark](kt.html#ark), [Noah](#noah))

### Bible References:

* [2 Kings 19:35-37](https://git.door43.org/Door43/en_tn/src/master/2ki/19/35.md)
* [Genesis 08:4-5](https://git.door43.org/Door43/en_tn/src/master/gen/08/04.md)
* [Isaiah 37:38](https://git.door43.org/Door43/en_tn/src/master/isa/37/38.md)
* [Jeremiah 51:27-28](https://git.door43.org/Door43/en_tn/src/master/jer/51/27.md)

### Word Data:

* Strong's: H780


## <a id="tw-term-names-artaxerxes"/>Artaxerxes

### Facts:

Artaxerxes was a king who reigned over the Persian empire from about 464 to 424 BC.

* During Artaxerxes' reign, the Israelites from Judah were in exile in Babylon, which was under the control of Persia at that time.
* Artaxerxes allowed Ezra the priest and other Jewish leaders to leave Babylon and go back to Jerusalem to teach the Israelites the Law of God.
* Later during this time, Artaxerxes also allowed his cupbearer Nehemiah to return to Jerusalem to lead the Jews in rebuilding the walls surrounding the city.
* Because Babylon was under the rule of Persia, Artaxerxes was sometimes called the "king of Babylon."
* Note that Artaxerxers is not the same person as Xerxes (Ahasuerus).

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Ahasuerus](#ahasuerus), [Babylon](#babylon), [cupbearer](other.html#cupbearer), [Ezra](#ezra), [Nehemiah](#nehemiah), [Persia](#persia))

### Bible References:

* [Ezra 04:7-8](https://git.door43.org/Door43/en_tn/src/master/ezr/04/07.md)
* [Ezra 07:1-5](https://git.door43.org/Door43/en_tn/src/master/ezr/07/01.md)
* [Nehemiah 02:1-2](https://git.door43.org/Door43/en_tn/src/master/neh/02/01.md)
* [Nehemiah 13:6-7](https://git.door43.org/Door43/en_tn/src/master/neh/13/06.md)

### Word Data:

* Strong's: H783


## <a id="tw-term-names-asa"/>Asa

### Facts:

Asa was a king who ruled over the kingdom of Judah for forty years, from 913 B.C. to 873 B.c.

* King Asa was a good king who removed many idols of false gods and caused the Israelites to start worshiping Yahweh again.
* Yahweh gave King Asa success in his warfare against other nations.
* Later in his reign, however, King Asa stopped trusting Yahweh and became sick with a disease that eventually killed him.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

### Bible References:

* [1 Chronicles 09:14-16](https://git.door43.org/Door43/en_tn/src/master/1ch/09/14.md)
* [1 Kings 15:7-8](https://git.door43.org/Door43/en_tn/src/master/1ki/15/07.md)
* [2 Chronicles 14:1-4](https://git.door43.org/Door43/en_tn/src/master/2ch/14/01.md)
* [Jeremiah 41:8-9](https://git.door43.org/Door43/en_tn/src/master/jer/41/08.md)
* [Matthew 01:7-8](https://git.door43.org/Door43/en_tn/src/master/mat/01/07.md)

### Word Data:

* Strong's: H609


## <a id="tw-term-names-asaph"/>Asaph

### Facts:

Asaph was a Levite priest and gifted musician who composed the music for the psalms of King David. He also wrote his own psalms.

* Asaph was appointed by King David to be one of three musicians who were responsible for providing songs for worship in the temple. Some of these songs were also prophecies.
* Asaph trained his sons and they carried on this responsibility, playing musical instruments and prophesying in the temple.
* Some of the musical instruments included the lute, harp, trumpet, and cymbals.
* Psalms 50 and 73-83 are said to be from Asaph. It may be that some of these psalms were written by his family members.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [descendant](other.html#descendant), [harp](other.html#harp), [lute](other.html#lute), [prophet](kt.html#prophet), [psalm](kt.html#psalm), [trumpet](other.html#trumpet))

### Bible References:

* [1 Chronicles 06:39-43](https://git.door43.org/Door43/en_tn/src/master/1ch/06/39.md)
* [2 Chronicles 35:15](https://git.door43.org/Door43/en_tn/src/master/2ch/35/15.md)
* [Nehemiah 02:7-8](https://git.door43.org/Door43/en_tn/src/master/neh/02/07.md)
* [Psalm 050:1-2](https://git.door43.org/Door43/en_tn/src/master/psa/050/001.md)

### Word Data:

* Strong's: H623


## <a id="tw-term-names-ashdod"/>Ashdod, Azotus

### Facts:

Ashdod was one of the five most important cities of the Philistines. It was located in southwestern Canaan near the Mediterranean Sea, halfway between the cities of Gaza and Joppa.

* The temple of the Philistine's false god Dagon was located in Ashdod.
* God severely punished the people of Ashdod when the Philistines stole the ark of the covenant and put it in the pagan temple at Ashdod. 
* The Greek name for this city was Azotus. It was one of the cities where the evangelist Philip preached the gospel.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Ekron](#ekron), [Gath](#gath), [Gaza](#gaza), [Joppa](#joppa), [Philip](#philip), [Philistines](#philistines))

### Bible References:

* [1 Samuel 05:1-3](https://git.door43.org/Door43/en_tn/src/master/1sa/05/01.md)
* [Acts 08:39-40](https://git.door43.org/Door43/en_tn/src/master/act/08/39.md)
* [Amos 01:8](https://git.door43.org/Door43/en_tn/src/master/amo/01/08.md)
* [Joshua 15:45-47](https://git.door43.org/Door43/en_tn/src/master/jos/15/45.md)
* [Zechariah 09:5-7](https://git.door43.org/Door43/en_tn/src/master/zec/09/05.md)

{{tag>publish ktlink}

### Word Data:

* Strong's: H795, G108


## <a id="tw-term-names-asher"/>Asher

### Facts:

Asher was the eighth son of Jacob. His descendants formed one of the twelve tribes of Israel and this tribe was also called "Asher." 

 * Asher's mother was Zilpah, the servant of Leah.
 * His name means "happy" or "blessed."
 * Asher was also the name of the territory assigned to the tribe of Asher when the Israelites entered the promised land.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Israel](kt.html#israel), [twelve tribes of Israel](other.html#12tribesofisrael))

### Bible References:

* [1 Chronicles 02:1-2](https://git.door43.org/Door43/en_tn/src/master/1ch/02/01.md)
* [1 Kings 04:15-17](https://git.door43.org/Door43/en_tn/src/master/1ki/04/15.md)
* [Ezekiel 48:1-3](https://git.door43.org/Door43/en_tn/src/master/ezk/48/01.md)
* [Genesis 30:12-13](https://git.door43.org/Door43/en_tn/src/master/gen/30/12.md)
* [Luke 02:36-38](https://git.door43.org/Door43/en_tn/src/master/luk/02/36.md)

### Word Data:

* Strong's: H836


## <a id="tw-term-names-asherim"/>Asherah, Asherah pole, Asherah poles, Ashtoreth, Ashtoreths

### Definition:

Asherah was the name of a goddess that was worshiped by Canaanite people groups during Old Testament times. "Ashtoreth" may be another name for "Asherah," or it could be the name of a different goddess that was very similar.

* The term "Asherah poles" refers to carved wooden images or carved trees that were made to represent this goddess.
* Asherah poles were often set up near altars of the false god Baal, who was thought of as Asherah's husband. Some people groups worshiped Baal as the sun god and Asherah or Ashtoreth as the moon goddess.
* God commanded the Israelites to destroy all the carved images of Asherah.
* Some Israelite leaders such as Gideon, King Asa, and King Josiah obeyed God and led the people in destroying these idols.
* But other Israelite leaders such as King Solomon, King Manasseh, and King Ahab did not get rid of the Asherah poles and influenced the people to worship these idols.

(See also: [false god](kt.html#falsegod), [Baal](#baal), [Gideon](#gideon), [image](other.html#image), [Solomon](#solomon))

### Bible References:

* [2 Kings 18:4-5](https://git.door43.org/Door43/en_tn/src/master/2ki/18/04.md)
* [2 Kings 21:1-3](https://git.door43.org/Door43/en_tn/src/master/2ki/21/01.md)
* [Isaiah 27:9](https://git.door43.org/Door43/en_tn/src/master/isa/27/09.md)
* [Judges 03:7-8](https://git.door43.org/Door43/en_tn/src/master/jdg/03/07.md)
* [Micah 05:12-15](https://git.door43.org/Door43/en_tn/src/master/mic/05/12.md)

### Word Data:

* Strong's: H842, H6252, H6253


## <a id="tw-term-names-ashkelon"/>Ashkelon

### Facts:

In Bible times, Ashkelon was a major Philistine city located on the coast of the Mediterranean Sea. It still exists in Israel today.

* Ashkelon was one of the five most important Philistine cities, along with Ashdod, Ekron, Gath, and Gaza.
* The Israelites did not completely conquer the people of Ashkelon, even though the kingdom of Judah occupied its hill country.
* Ashkelon remained occupied by the Philistines for hundreds of years.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Ashdod](#ashdod), [Canaan](#canaan), [Ekron](#ekron), [Gath](#gath), [Gaza](#gaza), [Philistines](#philistines), [Mediterranean](#mediterranean))

### Bible References:

* [1 Samuel 06:17-18](https://git.door43.org/Door43/en_tn/src/master/1sa/06/17.md)
* [Amos 01:8](https://git.door43.org/Door43/en_tn/src/master/amo/01/08.md)
* [Jeremiah 25:19-21](https://git.door43.org/Door43/en_tn/src/master/jer/25/19.md)
* [Joshua 13:2-3](https://git.door43.org/Door43/en_tn/src/master/jos/13/02.md)
* [Judges 01:18-19](https://git.door43.org/Door43/en_tn/src/master/jdg/01/18.md)
* [Zechariah 09:5-7](https://git.door43.org/Door43/en_tn/src/master/zec/09/05.md)

### Word Data:

* Strong's: H831


## <a id="tw-term-names-asia"/>Asia

### Facts:

In Bible times, "Asia" was the name of a province of the Roman Empire. It was located in the western part of what is now the country of Turkey.

* Paul traveled to Asia and shared the gospel in several cities there. Among these were the cities of Ephesus and Colossae. 
* To avoid confusion with modern day Asia, it may be necessary to translate this as, "the ancient Roman province called Asia" or "Asia Province."
* All of the churches referenced in Revelation were in the Roman province of Asia.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Rome](#rome), [Paul](#paul), [Ephesus](#ephesus))

### Bible References:

* [1 Corinthians 16:19-20](https://git.door43.org/Door43/en_tn/src/master/1co/16/19.md)
* [1 Peter 01:1-2](https://git.door43.org/Door43/en_tn/src/master/1pe/01/01.md)
* [2 Timothy 01:15-18](https://git.door43.org/Door43/en_tn/src/master/2ti/01/15.md)
* [Acts 06:8-9](https://git.door43.org/Door43/en_tn/src/master/act/06/08.md)
* [Acts 16:6-8](https://git.door43.org/Door43/en_tn/src/master/act/16/06.md)
* [Acts 27:1-2](https://git.door43.org/Door43/en_tn/src/master/act/27/01.md)
* [Revelation 01:4-6](https://git.door43.org/Door43/en_tn/src/master/rev/01/04.md)
* [Romans 16:3-5](https://git.door43.org/Door43/en_tn/src/master/rom/16/03.md)

### Word Data:

* Strong's: G773


## <a id="tw-term-names-assyria"/>Assyria, Assyrian, Assyrians, Assyrian Empire

### Facts:

Assyria was a powerful nation during the time the Israelites were living in the land of Canaan. The Assyrian Empire was a group of nations ruled by an Assyrian king.

 * The nation of Assyria was located in a region that is now the northern part of Iraq.
 * The Assyrians fought against Israel at different times in their history.
 * In the year 722 BC, the Assyrians completely conquered the kingdom of Israel and forced many of the Israelites to move to Assyria.
 * The remaining Israelites intermarried with foreigners that the Assyrians had brought into Israel from Samaria. The descendants of those people who intermarried were later called the Samaritans.

(See also: [Samaria](#samaria))

### Bible References:

* [Genesis 10:11-14](https://git.door43.org/Door43/en_tn/src/master/gen/10/11.md)
* [Genesis 25:17-18](https://git.door43.org/Door43/en_tn/src/master/gen/25/17.md)
* [Isaiah 07:16-17](https://git.door43.org/Door43/en_tn/src/master/isa/07/16.md)
* [Jeremiah 50:17-18](https://git.door43.org/Door43/en_tn/src/master/jer/50/17.md)
* [Micah 07:11-13](https://git.door43.org/Door43/en_tn/src/master/mic/07/11.md)

### Examples from the Bible stories:

  __*[20:02](https://git.door43.org/Door43/en_tn/src/master/obs/20/02.md)__ So God punished both kingdoms by allowing their enemies to destroy them. The kingdom of Israel was destroyed by the __Assyrian Empire__, a powerful, cruel nation. The __Assyrians__ killed many people in the kingdom of Israel, took away everything of value, and burned much of the country.
  __*[20:03](https://git.door43.org/Door43/en_tn/src/master/obs/20/03.md)__ The __Assyrians__ gathered all the leaders, the rich people, and the people with skills and took them to __Assyria__.
  __*[20:04](https://git.door43.org/Door43/en_tn/src/master/obs/20/04.md)__ Then the __Assyrians__ brought foreigners to live in the land where the kingdom of Israel had been.

### Word Data:

* Strong's: H804, H1121


## <a id="tw-term-names-athaliah"/>Athaliah

### Facts:

Athaliah was the evil wife of Jehoram king of Judah. She was the granddaughter of the evil King Omri of Israel.

* Athaliah's son Ahaziah became king after Jehoram died.
* When her son Ahaziah died, Athaliah made a plan to kill all the rest of the king's family.
* But Athaliah's young grandson Joash was hidden by his aunt and saved from being killed. After Athaliah had ruled the land for six years, she was killed and Joash became king.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Ahaziah](#ahaziah), [Jehoram](#jehoram), [Joash](#joash), [Omri](#omri))

### Bible References:

* [2 Chronicles 22:1-3](https://git.door43.org/Door43/en_tn/src/master/2ch/22/01.md)
* [2 Chronicles 24:6-7](https://git.door43.org/Door43/en_tn/src/master/2ch/24/06.md)
* [2 Kings 11:1-3](https://git.door43.org/Door43/en_tn/src/master/2ki/11/01.md)

### Word Data:

* Strong's: H6721


## <a id="tw-term-names-azariah"/>Azariah

### Facts:

Azariah was the name of several men in the Old Testament.

* One Azariah is best known by his Babylonian name, Abednego. He was one of many Israelites from Judah who were captured by Nebuchadnezzar's army and taken to live in Babylon. Azariah and his fellow Israelites Hananiah and Mishael  refused to worship the Babylonian king, so he had them thrown into a blazing furnace as punishment. But God protected them and they were not harmed at all.
* Uzziah king of Judah was also known as "Azariah."
* Another Azariah was an Old Testament high priest.
* In the time of the prophet Jeremiah, a man named Azariah wrongly urged the Israelites to disobey God by leaving their homeland.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Babylon](#babylon), [Daniel](#daniel), [Hananiah](#hananiah), [Mishael](#mishael), [Jeremiah](#jeremiah), [Uzziah](#uzziah))

### Bible References:

* [1 Chronicles 02:36-38](https://git.door43.org/Door43/en_tn/src/master/1ch/02/36.md)
* [1 Kings 04:1-4](https://git.door43.org/Door43/en_tn/src/master/1ki/04/01.md)
* [2 Chronicles 15:1-2](https://git.door43.org/Door43/en_tn/src/master/2ch/15/01.md)
* [Daniel 01:6-7](https://git.door43.org/Door43/en_tn/src/master/dan/01/06.md)
* [Jeremiah 43:1-3](https://git.door43.org/Door43/en_tn/src/master/jer/43/01.md)

### Word Data:

* Strong's: H5838


## <a id="tw-term-names-baal"/>Baal

### Facts:

"Baal" means "lord" or "master" and was the name of the primary false god that was worshiped by the Canaanites.

* There were also local false gods that had "Baal" as part of their names, such as "Baal of Peor." Sometimes all these gods together are referred to as "the Baals."
* Some people had names that included the word "Baal" in them.
* The worship of Baal included evil practices such as sacrificing children and using prostitutes.
* At different time periods throughout their history, the Israelites also became deeply involved in Baal worship, following the example of the pagan nations around them.
* During the reign of King Ahab, God's prophet Elijah set up a test to prove to the people that Baal does not exist and that Yahweh is the only true God. As a result, the prophets of Baal were destroyed and the people started worshiping Yahweh again.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md)) 

(See also: [Ahab](#ahab), [Asherah](#asherim), [Elijah](#elijah), [false god](kt.html#falsegod), [prostitute](other.html#prostitute), [Yahweh](kt.html#yahweh))

### Bible References:

* [1 Kings 16:31-33](https://git.door43.org/Door43/en_tn/src/master/1ki/16/31.md)
* [1 Samuel 07:3-4](https://git.door43.org/Door43/en_tn/src/master/1sa/07/03.md)
* [Jeremiah 02:7-8](https://git.door43.org/Door43/en_tn/src/master/jer/02/07.md)
* [Judges 02:11-13](https://git.door43.org/Door43/en_tn/src/master/jdg/02/11.md)
* [Numbers 22:41](https://git.door43.org/Door43/en_tn/src/master/num/22/41.md)

### Examples from the Bible stories:

* __[19:02](https://git.door43.org/Door43/en_tn/src/master/obs/19/02.md)__ Ahab was an evil man who encouraged people to worship a false god named __Baal__.
* __[19:06](https://git.door43.org/Door43/en_tn/src/master/obs/19/06.md)__ All the people of the entire kingdom of Israel, including the 450 prophets of __Baal__, came to Mount Carmel. Elijah said to the people, "How long will you keep changing your mind? If Yahweh is God, serve him! If __Baal__  is God, serve him!"
* __[19:07](https://git.door43.org/Door43/en_tn/src/master/obs/19/07.md)__ Then Elijah said to the prophets of __Baal__, "Kill a bull and prepare it as a sacrifice, but do not light the fire.
* __[19:08](https://git.door43.org/Door43/en_tn/src/master/obs/19/08.md)__ Then the prophets of __Baal__  prayed to __Baal__, "Hear us, O __Baal__!"
* __[19:12](https://git.door43.org/Door43/en_tn/src/master/obs/19/12.md)__ So the people captured the prophets of __Baal__. Then Elijah took them away from there and killed them.

### Word Data:

* Strong's: H1120, G896


## <a id="tw-term-names-baasha"/>Baasha

### Facts:

Baasha was one of Israel's evil kings, who influenced the Israelites to worship idols.

* Baasha was the third king of Israel and reigned for twenty-four years, during the time when Asa was king of Judah.
* He was a military commander who became king by killing the previous king, Nadab.
* During Baasha's reign there were many wars between the kingdoms of Israel and Judah, especially with King Asa of Judah.
* Baasha's many sins caused God to eventually remove him from office by his death.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Asa](#asa), [false god](kt.html#falsegod))

### Bible References:

* [1 Kings 15:16-17](https://git.door43.org/Door43/en_tn/src/master/1ki/15/16.md)
* [2 Kings 09:9-10](https://git.door43.org/Door43/en_tn/src/master/2ki/09/09.md)
* [Jeremiah 41:8-9](https://git.door43.org/Door43/en_tn/src/master/jer/41/08.md)

### Word Data:

* Strong's: H1201


## <a id="tw-term-names-babel"/>Babel

### Facts:

Babel was a chief city in a region called Shinar in the southern part of Mesopotamia. Shinar was later called Babylonia.

* The city of Babel was founded by Ham's great-grandson, Nimrod, who ruled the region of Shinar.
* The people of Shinar became proud and decided to build a tower high enough to reach heaven. This later became known as the "Tower of Babel."
* Because the people building the tower refused to spread out as God had commanded, he confused their languages so that they could not understand one another. This forced them to move away to live in many different places across the earth.
* The root meaning of the word for "Babel" is "confusion," named for when God confused the people's language.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Babylon](#babylon), [Ham](#ham), [Mesopotamia](#mesopotamia))

### Bible References:

* [Genesis 10:8-10](https://git.door43.org/Door43/en_tn/src/master/gen/10/08.md)
* [Genesis 11:8-9](https://git.door43.org/Door43/en_tn/src/master/gen/11/08.md)

### Word Data:

* Strong's: H894


## <a id="tw-term-names-babylon"/>Babylon, Babylonia, Babylonian, Babylonians

### Facts:

The city of Babylon was the capital of the ancient region of Babylonia, which was also part of the Babylonian Empire.

* Babylon was located along the Euphrates River, in the same region where the Tower of Babel had been built hundreds of years before.
* Sometimes the word "Babylon" refers to the entire Babylonian Empire. For example, the "king of Babylon" ruled the entire empire, not just the city.
* The Babylonians were a powerful people group who attacked the kingdom of Judah and kept the people in exile in Babylonia for 70 years.
* Part of this region was called "Chaldea" and the people living there were the "Chaldeans." As a result, the term "Chaldea" was often used to refer to Babylonia. (See: [synecdoche](https://git.door43.org/Door43/en_man/src/master/translate/figs-synecdoche/01.md))
* In the New Testament, the term "Babylon" is sometimes used as a metaphor to refer to places, people, and thinking patterns that are associated with idol-worship and other sinful behaviors.
* The phrase "Babylon the Great" or "great city of Babylon" refers metaphorically to a city or nation that was large, wealthy, and sinful, just as the ancient city of Babylon was. (See: [Metaphor](https://git.door43.org/Door43/en_man/src/master/translate/figs-metaphor/01.md))

(See also: [Babel](#babel), [Chaldea](#chaldeans), [Judah](#kingdomofjudah), [Nebuchadnezzar](#nebuchadnezzar))

### Bible References:

* [1 Chronicles 09:1-3](https://git.door43.org/Door43/en_tn/src/master/1ch/09/01.md)
* [2 Kings 17:24-26](https://git.door43.org/Door43/en_tn/src/master/2ki/17/24.md)
* [Acts 07:43](https://git.door43.org/Door43/en_tn/src/master/act/07/43.md)
* [Daniel 01:1-2](https://git.door43.org/Door43/en_tn/src/master/dan/01/01.md)
* [Ezekiel 12:11-13](https://git.door43.org/Door43/en_tn/src/master/ezk/12/11.md)
* [Matthew 01:9-11](https://git.door43.org/Door43/en_tn/src/master/mat/01/09.md)
* [Matthew 01:15-17](https://git.door43.org/Door43/en_tn/src/master/mat/01/15.md)

### Examples from the Bible stories:

* __[20:06](https://git.door43.org/Door43/en_tn/src/master/obs/20/06.md)__ About 100 years after the Assyrians destroyed the kingdom of Israel, God sent Nebuchadnezzar, king of the __Babylonians__, to attack the kingdom of Judah. __Babylon__  was a powerful empire.
* __[20:07](https://git.door43.org/Door43/en_tn/src/master/obs/20/07.md)__ But after a few years, the king of Judah rebelled against __Babylon__. So, the __Babylonians__  came back and attacked the kingdom of Judah. They captured the city of Jerusalem, destroyed the Temple, and took away all the treasures of the city and the Temple.
* __[20:09](https://git.door43.org/Door43/en_tn/src/master/obs/20/09.md)__ Nebuchadnezzar and his army took almost all of the people of the kingdom of Judah to __Babylon__, leaving only the poorest people behind to plant the fields.
* __[20:11](https://git.door43.org/Door43/en_tn/src/master/obs/20/11.md)__ About seventy years later, Cyrus, the king of the Persians, defeated __Babylon__.

### Word Data:

* Strong's: H3778, H3779, H8152, H894, H895, H896, G897


## <a id="tw-term-names-balaam"/>Balaam

### Facts:

Balaam was a pagan prophet whom King Balek hired to curse Israel while they were camped at the Jordan River in northern Moab, preparing to enter the land of Canaan.

* Balaam was from the city of Pethor, which was located in the region around the Euphrates River, about 400 miles away from the land of Moab.
* The Midianite king, Balek, was afraid of the strength and numbers of the Israelites, so he hired Balaam to curse them.
* As Balaam was traveling toward Israel, an angel of God stood in his path so that Balaam's donkey stopped. God also gave the donkey the ability to speak to Balaam.
* God did not allow Balaam to curse the Israelites and commanded him to bless them instead.
* Later however, Balaam still brought evil on the Israelites when he influenced them to worship the false god Baal-peor.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [bless](kt.html#bless), [Canaan](#canaan), [curse](kt.html#curse), [donkey](other.html#donkey), [Euphrates River](#euphrates), [Jordan River](#jordanriver), [Midian](#midian), [Moab](#moab), [Peor](#peor))

### Bible References:

* [2 Peter 02:15-16](https://git.door43.org/Door43/en_tn/src/master/2pe/02/15.md)
* [Deuteronomy 23:3-4](https://git.door43.org/Door43/en_tn/src/master/deu/23/03.md)
* [Joshua 13:22-23](https://git.door43.org/Door43/en_tn/src/master/jos/13/22.md)
* [Numbers 22:5-6](https://git.door43.org/Door43/en_tn/src/master/num/22/05.md)
* [Revelation 02:14-15](https://git.door43.org/Door43/en_tn/src/master/rev/02/14.md)

### Word Data:

* Strong's: H1109, G903


## <a id="tw-term-names-barabbas"/>Barabbas

### Facts:

Barabbas was a prisoner in Jerusalem at the time when Jesus was arrested.

* Barabbas was a criminal who had committed crimes of murder and rebellion against the Roman government.
* When Pontius Pilate offered to either release Barabbas or Jesus, the people chose Barabbas.
* So Pilate allowed Barabbas to go free, but condemned Jesus to be killed.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Pilate](#pilate), [Rome](#rome))

### Bible References:

* [John 18:38-40](https://git.door43.org/Door43/en_tn/src/master/jhn/18/38.md)
* [Luke 23:18-19](https://git.door43.org/Door43/en_tn/src/master/luk/23/18.md)
* [Mark 15:6-8](https://git.door43.org/Door43/en_tn/src/master/mrk/15/06.md)
* [Matthew 27:15-16](https://git.door43.org/Door43/en_tn/src/master/mat/27/15.md)

### Word Data:

* Strong's: G912


## <a id="tw-term-names-barnabas"/>Barnabas

### Facts:

Barnabas was one of the early Christians who lived during the time of the apostles.

* Barnabas was from the Israelite tribe of Levi and was from the island of Cyprus.
* When Saul (Paul) became a Christian, Barnabas urged the other believers to accept him as a fellow believer.
* Barnabas and Paul traveled together to preach the good news about Jesus in different cities.
* His name was Joseph, but he was called "Barnabas," which means "son of encouragement."

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Christian](kt.html#christian), [Cyprus](#cyprus), [good news](kt.html#goodnews), [Levite](#levite), [Paul](#paul))

### Bible References:

* [Acts 04:36-37](https://git.door43.org/Door43/en_tn/src/master/act/04/36.md)
* [Acts 11:25-26](https://git.door43.org/Door43/en_tn/src/master/act/11/25.md)
* [Acts 13:1-3](https://git.door43.org/Door43/en_tn/src/master/act/13/01.md)
* [Acts 15:33-35](https://git.door43.org/Door43/en_tn/src/master/act/15/33.md)
* [Colossians 04:10-11](https://git.door43.org/Door43/en_tn/src/master/col/04/10.md)
* [Galatians 02:9-10](https://git.door43.org/Door43/en_tn/src/master/gal/02/09.md)
* [Galatians 02:13-14](https://git.door43.org/Door43/en_tn/src/master/gal/02/13.md)

### Examples from the Bible stories:

  __*[46:08](https://git.door43.org/Door43/en_tn/src/master/obs/46/08.md)__ Then a believer named __Barnabas__ took Saul to the apostles and told them how Saul had preached boldly in Damascus. 
  __*[46:09](https://git.door43.org/Door43/en_tn/src/master/obs/46/09.md)__ __Barnabas__ and Saul went there to teach these new believers more about Jesus and to strengthen the church. I
  __*[46:10](https://git.door43.org/Door43/en_tn/src/master/obs/46/10.md)__ One day, while the Christians at Antioch were fasting and praying, the Holy Spirit said to them, "Set apart for me __Barnabas__ and Saul to do the work I have called them to do." So the church in Antioch prayed for __Barnabas__ and Saul and placed their hands on them.

### Word Data:

* Strong's: G921


## <a id="tw-term-names-bartholomew"/>Bartholomew

### Facts:

Bartholomew was one of Jesus' twelve apostles.

* Along with the other apostles, Bartholomew was sent out to preach the gospel and do miracles in Jesus' name.
* He was also one of those who saw Jesus return to heaven.
* A few weeks after that, he was with the other apostles in Jerusalem at Pentecost when the Holy Spirit came upon them.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [apostle](kt.html#apostle), [good news](kt.html#goodnews), [Holy Spirit](kt.html#holyspirit), [miracle](kt.html#miracle), [Pentecost](kt.html#pentecost), [the twelve](kt.html#thetwelve))

### Bible References:

* [Acts 01:12-14](https://git.door43.org/Door43/en_tn/src/master/act/01/12.md)
* [Luke 06:14-16](https://git.door43.org/Door43/en_tn/src/master/luk/06/14.md)
* [Mark 03:17-19](https://git.door43.org/Door43/en_tn/src/master/mrk/03/17.md)

### Word Data:

* Strong's: G918


## <a id="tw-term-names-baruch"/>Baruch

### Facts:

Baruch is the name of several men in the Old Testament.

* One Baruch (son of Zabbal) worked with Nehemiah to repair the walls of Jerusalem. 
* Also during the time of Nehemiah, another Baruch (son of Kol-Hozeh) was one of the leaders who settled in Jerusalem after its walls were restored.
* A different Baruch (son of Neriah) was an assistant to the prophet Jeremiah, who helped him with various practical tasks such as writing down the messages God gave to Jeremiah and then reading them to the people.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [disciple](kt.html#disciple), [Jeremiah](#jeremiah), [Jerusalem](#jerusalem), [Nehemiah](#nehemiah), [prophet](kt.html#prophet))

### Bible References:

* [Jeremiah 32:10-12](https://git.door43.org/Door43/en_tn/src/master/jer/32/10.md)
* [Jeremiah 36:4-6](https://git.door43.org/Door43/en_tn/src/master/jer/36/04.md)
* [Jeremiah 43:1-3](https://git.door43.org/Door43/en_tn/src/master/jer/43/01.md)

### Word Data:

* Strong's: G1263


## <a id="tw-term-names-bashan"/>Bashan

### Facts:

Bashan was a region of land east of the Sea of Galilee. It covered an area that is now part of Syria and the Golan Heights.

* An Old Testament city of refuge called "Golan" was located in the region of Bashan.
* Bashan was a very fertile region known for its oak trees and pasturing animals. 
* Genesis 14 records that Bashan was the site of a war between several kings and their nations.
* During Israel's wanderings in the desert after their escape from Egypt, they took possession of part of the region of Bashan.
* Years later, King Solomon obtained supplies from that region.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Egypt](#egypt), [oak](other.html#oak), [Sea of Galilee](#seaofgalilee), [Syria](#syria))

### Bible References:

* [1 Kings 04:11-14](https://git.door43.org/Door43/en_tn/src/master/1ki/04/11.md)
* [Amos 04:1-2](https://git.door43.org/Door43/en_tn/src/master/amo/04/01.md)
* [Jeremiah 22:20-21](https://git.door43.org/Door43/en_tn/src/master/jer/22/20.md)
* [Joshua 09:9-10](https://git.door43.org/Door43/en_tn/src/master/jos/09/09.md)

### Word Data:

* Strong's: H1316


## <a id="tw-term-names-bathsheba"/>Bathsheba

### Facts:

Bathsheba was the wife of Uriah, a soldier in King David's army. After Uriah's death, she became the wife of David, and the mother of Solomon.

* David committed adultery with Bathsheba while she was married to Uriah.
* When Bathsheba became pregnant with David's child, David caused Uriah to be killed in battle.
* David then married Bathsheba and she gave birth to their child. 
* God punished David for his sin by causing the child to die several days after he was born.
* Later, Bathsheba gave birth to another son, Solomon, who grew up to become king after David.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [David](#david), [Solomon](#solomon). [Uriah](#uriah))

### Bible References:

* [1 Chronicles 03:4-5](https://git.door43.org/Door43/en_tn/src/master/1ch/03/04.md)
* [1 Kings 01:11-12](https://git.door43.org/Door43/en_tn/src/master/1ki/01/11.md)
* [2 Samuel 11:2-3](https://git.door43.org/Door43/en_tn/src/master/2sa/11/02.md)
* [Psalm 051:1-2](https://git.door43.org/Door43/en_tn/src/master/psa/051/001.md)

### Examples from the Bible stories:

  __*[17:10](https://git.door43.org/Door43/en_tn/src/master/obs/17/10.md)__ One day, when all of David's soldiers were away from home fighting battles, he got up from an afternoon nap and saw a beautiful woman bathing. Her name was __Bathsheba__.
  __*[17:11](https://git.door43.org/Door43/en_tn/src/master/obs/17/11.md)__ A short time later __Bathsheba__ sent a message to David saying that she was pregnant.
  __*[17:12](https://git.door43.org/Door43/en_tn/src/master/obs/17/12.md)__ __Bathsheba's__ husband, a man named Uriah, was one of David's best soldiers.
  __*[17:13](https://git.door43.org/Door43/en_tn/src/master/obs/17/13.md)__ After Uriah was killed, David married __Bathsheba__.
  __*[17:14](https://git.door43.org/Door43/en_tn/src/master/obs/17/14.md)__ Later,  David and __Bathsheba__ had another son, and they named him Solomon.

### Word Data:

* Strong's: H1339


## <a id="tw-term-names-beelzebul"/>Beelzebul

### Facts:

Beelzebul is another name for Satan, or the devil. It is also sometimes spelled, "Beelzebub."

 * This name literally means "lord of flies" which means, "ruler over demons." But it is best to translate this term close to the original spelling rather than translate the meaning.
 * It could also be translated as "Beelzebul the devil" to make it clear who is being referred to.
 * This name is related to the name of the false god "Baal-zebub" of Ekron.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [demon](kt.html#demon), [Ekron](#ekron), [Satan](kt.html#satan))

### Bible References:

* [Luke 11:14-15](https://git.door43.org/Door43/en_tn/src/master/luk/11/14.md)
* [Mark 03:20-22](https://git.door43.org/Door43/en_tn/src/master/mrk/03/20.md)
* [Matthew 10:24-25](https://git.door43.org/Door43/en_tn/src/master/mat/10/24.md)
* [Matthew 12:24-25](https://git.door43.org/Door43/en_tn/src/master/mat/12/24.md)

### Word Data:

* Strong's: G954


## <a id="tw-term-names-beersheba"/>Beersheba

### Facts:

In Old Testament times, Beersheba was a city located about 45 miles southwest of Jerusalem in a desert area that is now called the Negev.

* The desert surrounding Beersheba was the wilderness area where Hagar and Ishmael wandered after Abraham sent them away from his tents.
* The name of this city means "well of the oath." It was given this name when Abraham swore an oath to not punish King Abimelech's men for seizing control of one of Abraham's wells.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Abimelech](#abimelech), [Abraham](#abraham), [Hagar](#hagar), [Ishmael](#ishmael), [Jerusalem](#jerusalem), [oath](other.html#oath))

===== Bible References:=====

* [1 Samuel 03:19-21](https://git.door43.org/Door43/en_tn/src/master/1sa/03/19.md)
* [2 Samuel 17:11-12](https://git.door43.org/Door43/en_tn/src/master/2sa/17/11.md)
* [Genesis 21:14-16](https://git.door43.org/Door43/en_tn/src/master/gen/21/14.md)
* [Genesis 21:31-32](https://git.door43.org/Door43/en_tn/src/master/gen/21/31.md)
* [Genesis 46:1-4](https://git.door43.org/Door43/en_tn/src/master/gen/46/01.md)
* [Nehemiah 11:28-30](https://git.door43.org/Door43/en_tn/src/master/neh/11/28.md)

### Word Data:

* Strong's: H884


## <a id="tw-term-names-benaiah"/>Benaiah

### Definition:

Benaiah was the name of several men in the Old Testament.

* Benaiah son of Jehoiada was one of David's mighty men. He was a skilled warrior and was put in charge of David's bodyguards.
* When Solomon was being made king, Benaiah helped him overthrow his enemies. He eventually became commander of the Israelite army.
* Other men in the Old Testament named Benaiah include three Levites: a priest, a musician, and a descendant of Asaph.

(See also: [Asaph](#asaph), [Jehoiada](#jehoiada), [Levite](#levite), [Solomon](#solomon))

### Bible References:

* [1 Chronicles 04:34-38](https://git.door43.org/Door43/en_tn/src/master/1ch/04/34.md)
* [1 Kings 01:7-8](https://git.door43.org/Door43/en_tn/src/master/1ki/01/07.md)
* [2 Samuel 23:20-21](https://git.door43.org/Door43/en_tn/src/master/2sa/23/20.md)

### Word Data:

* Strong's: H1141


## <a id="tw-term-names-benjamin"/>Benjamin, Benjamite, Benjamites

### Facts:

Benjamin was the youngest son born to Jacob and his wife Rachel. His name means, "son of my right hand."

* He and his older brother Joseph were the only children of Rachel, who died after Benjamin was born.
* The descendants of Benjamin became one of the twelve tribes of Israel.
* King Saul was from the Israelite tribe of Benjamin.
* The apostle Paul was also from the tribe of Benjamin.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Israel](kt.html#israel), [Jacob](#jacob), [Joseph (OT)](#josephot), [Paul](#paul), [Rachel](#rachel), [twelve tribes of Israel](other.html#12tribesofisrael))

### Bible References:

* [1 Chronicles 02:1-2](https://git.door43.org/Door43/en_tn/src/master/1ch/02/01.md)
* [1 Kings 02:8-9](https://git.door43.org/Door43/en_tn/src/master/1ki/02/08.md)
* [Acts 13:21-22](https://git.door43.org/Door43/en_tn/src/master/act/13/21.md)
* [Genesis 35:16-20](https://git.door43.org/Door43/en_tn/src/master/gen/35/16.md)
* [Genesis 42:1-4](https://git.door43.org/Door43/en_tn/src/master/gen/42/01.md)
* [Genesis 42:35-36](https://git.door43.org/Door43/en_tn/src/master/gen/42/35.md)
* [Philippians 03:4-5](https://git.door43.org/Door43/en_tn/src/master/php/03/04.md)

### Word Data:

* Strong's: H1144, G958


## <a id="tw-term-names-berea"/>Berea

### Facts:

In New Testament times, Berea (or Beroea) was a prosperous Greek city in southeast Macedonia, about 80 kilometers south of Thessalonica.

* Paul and Silas fled to the city of Berea after their fellow Christians helped them escape from certain Jews who had caused trouble for them in Thessalonica.
* When the people living in Berea heard Paul preach, they researched the Scriptures to confirm that what he was telling them was true.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Macedonia](#macedonia), [Paul](#paul), [Silas](#silas), [Thessalonica](#thessalonica))

### Bible References:

* [Acts 17:10-12](https://git.door43.org/Door43/en_tn/src/master/act/17/10.md)
* [Acts 17:13-15](https://git.door43.org/Door43/en_tn/src/master/act/17/13.md)
* [Acts 20:4-6](https://git.door43.org/Door43/en_tn/src/master/act/20/04.md)

### Word Data:

* Strong's: G960


## <a id="tw-term-names-bethany"/>Bethany

### Facts:

The town of Bethany was located at the base of the eastern slope of the Mount of Olives, about 2 miles east of Jerusalem. 

* Bethany was near the road that ran between Jerusalem and Jericho.
* Jesus often visited Bethany where his close friends Lazarus, Martha, and Mary lived.
* Bethany is especially known as the place where Jesus raised Lazarus from the dead.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Jericho](#jericho), [Jerusalem](#jerusalem), [Lazarus](#lazarus), [Martha](#martha), [Mary (sister of Martha)](#marysisterofmartha), [Mount of Olives](#mountofolives))

### Bible References:

* [John 01:26-28](https://git.door43.org/Door43/en_tn/src/master/jhn/01/26.md)
* [Luke 24:50-51](https://git.door43.org/Door43/en_tn/src/master/luk/24/50.md)
* [Mark 11:1-3](https://git.door43.org/Door43/en_tn/src/master/mrk/11/01.md)
* [Matthew 21:15-17](https://git.door43.org/Door43/en_tn/src/master/mat/21/15.md)

### Word Data:

* Strong's: G963


## <a id="tw-term-names-bethel"/>Bethel

### Facts:

Bethel was a city located just north of Jerusalem in the land of Canaan. It was formerly called "Luz."

* After receiving God's promises for the first time, Abram (Abraham) built an altar to God near Bethel. The actual name of the city was not yet Bethel at that time, but it was usually referred to as "Bethel," which was better known.
* When fleeing from his brother Esau, Jacob stayed overnight near this city and slept outdoors on the ground there. While he was sleeping, he had a dream showing angels going up and down a ladder to heaven.
* This city did not have the name "Bethel" until after Jacob named it that. To make this clear, some translations may translate it as "Luz (later called Bethel)" in the passages about Abraham, as well as when Jacob first arrives there (before he changed the name).
* Bethel is mentioned often in the Old Testament and was a place where many important events happened.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Abraham](#abraham), [altar](kt.html#altar), [Jacob](#jacob), [Jerusalem](#jerusalem))

### Bible References:

* [Genesis 12:8-9](https://git.door43.org/Door43/en_tn/src/master/gen/12/08.md)
* [Genesis 35:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/35/01.md)
* [Hosea 10:14-15](https://git.door43.org/Door43/en_tn/src/master/hos/10/14.md)
* [Judges 01:22-24](https://git.door43.org/Door43/en_tn/src/master/jdg/01/22.md)

### Word Data:

* Strong's: H1008


## <a id="tw-term-names-bethlehem"/>Bethlehem, Ephrathah

### Facts:

Bethlehem was a small city in the land of Israel, near the city of Jerusalem. It was also known as "Ephrathah," which was probably its original name.

* Bethlehem has been called the "city of David," since King David was born there.
* The prophet Micah said that the Messiah would come from "Bethlehem Ephrathah."
* Fulfilling that prophecy, Jesus was born in Bethlehem, many years later.
* The name "Bethlehem" means "house of bread" or "house of food."

(See also: [Caleb](#caleb), [David](#david), [Micah](#micah))

### Bible References:

* [Genesis 35:16-20](https://git.door43.org/Door43/en_tn/src/master/gen/35/16.md)
* [John 07:40-42](https://git.door43.org/Door43/en_tn/src/master/jhn/07/40.md)
* [Matthew 02:4-6](https://git.door43.org/Door43/en_tn/src/master/mat/02/04.md)
* [Matthew 02:16](https://git.door43.org/Door43/en_tn/src/master/mat/02/16.md)
* [Ruth 01:1-2](https://git.door43.org/Door43/en_tn/src/master/rut/01/01.md)
* [Ruth 01:19-21](https://git.door43.org/Door43/en_tn/src/master/rut/01/19.md)

### Examples from the Bible stories:

  __*[17:02](https://git.door43.org/Door43/en_tn/src/master/obs/17/02.md)__ David was a shepherd from the town of __Bethlehem__.
  __*[21:09](https://git.door43.org/Door43/en_tn/src/master/obs/21/09.md)__ The prophet Isaiah prophesied that the Messiah would be born from a virgin. The prophet Micah said that he would be born in the town of __Bethlehem__.
  __*[23:04](https://git.door43.org/Door43/en_tn/src/master/obs/23/04.md)__ Joseph and Mary had to make a long journey from where they lived in Nazareth to __Bethlehem__ because their ancestor was David whose hometown was __Bethlehem__.
  __*[23:06](https://git.door43.org/Door43/en_tn/src/master/obs/23/06.md)__ "The Messiah, the Master, has been born in __Bethlehem__!"

### Word Data:

* Strong's: H376, H672, H1035, G965


## <a id="tw-term-names-bethshemesh"/>Beth Shemesh

### Facts:

Beth Shemesh was the name of a Canaanite city approximately 30 kilometers west of Jerusalem.

* The Israelites captured Beth Shemesh during the time of Joshua's leadership.
* Beth Shemesh was a city that was set aside as a place for the Levite priests to live.
* When the Philistines were taking the captured ark of the covenant back to Jerusalem, Beth Shemesh was the first city where they stopped with it.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [ark of the covenant](kt.html#arkofthecovenant), [Canaan](#canaan), [Jerusalem](#jerusalem), [Joshua](#joshua), [Levite](#levite), [Philistines](#philistines))

### Bible References:

* [1 Kings 04:7-10](https://git.door43.org/Door43/en_tn/src/master/1ki/04/07.md)
* [1 Samuel 06:7-9](https://git.door43.org/Door43/en_tn/src/master/1sa/06/07.md)
* [Joshua 19:20-22](https://git.door43.org/Door43/en_tn/src/master/jos/19/20.md)
* [Judges 01:33](https://git.door43.org/Door43/en_tn/src/master/jdg/01/33.md)

### Word Data:

* Strong's: H1053


## <a id="tw-term-names-bethuel"/>Bethuel

### Facts:

Bethuel was the son of Abraham's brother Nahor.

* Bethuel was the father of Rebekah and Laban.
* There was also a town called Bethuel, which may have been located in southern Judah, not far from the town of Beersheba.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Beersheba](#beersheba), [Laban](#laban), [Nahor](#nahor), [Rebekah](#rebekah))

### Bible References:

* [1 Chronicles 04:29-31](https://git.door43.org/Door43/en_tn/src/master/1ch/04/29.md)
* [Genesis 28:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/28/01.md)

### Word Data:

* Strong's: H1328


## <a id="tw-term-names-boaz"/>Boaz

### Facts:

Boaz was an Israelite man who was the husband of Ruth, the great grandfather of King David, and an ancestor of Jesus Christ.

 * Boaz lived during the time when there were judges in Israel.
 * He was a relative of an Israelite woman named Naomi who had returned to Israel after her husband and sons died in Moab.
 * Boaz "redeemed" Naomi's widowed daughter-in-law Ruth by marrying her and giving her a future with a husband and children.
 * He is seen as a picture of how Jesus rescued and redeemed us from sin.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Moab](#moab), [redeem](kt.html#redeem), [Ruth](#ruth))

### Bible References:

* [1 Chronicles 02:9-12](https://git.door43.org/Door43/en_tn/src/master/1ch/02/09.md)
* [2 Chronicles 03:15-17](https://git.door43.org/Door43/en_tn/src/master/2ch/03/15.md)
* [Luke 03:30-32](https://git.door43.org/Door43/en_tn/src/master/luk/03/30.md)
* [Matthew 01:4-6](https://git.door43.org/Door43/en_tn/src/master/mat/01/04.md)
* [Ruth 02:3-4](https://git.door43.org/Door43/en_tn/src/master/rut/02/03.md)

### Word Data:

* Strong's: H1162


## <a id="tw-term-names-caesar"/>Caesar

### Facts:

The term "Caesar" was the name or title used by many of the rulers of the Roman Empire. In the Bible, this name refers to three different Roman rulers.

 * The first Roman ruler named Caesar was "Caesar Augustus," who was ruling during the time that Jesus was born.
 * About thirty years later, at the time when John the Baptist was preaching, Tiberius Caesar was the ruler of the Roman Empire. 
 * Tiberius Caesar was still ruling Rome when Jesus told the people to pay Caesar what was due him and to give to God what is due him.
 * When Paul appealed to Caesar, this referred to the Roman emperor, Nero, who also had the title "Caesar."
 * When "Caesar" is used by itself as a title, it can also be translated as: "the Emperor" or "the Roman Ruler."
 * In names such as Caesar Augustus or Tiberius Caesar, "Caesar" can be spelled close to the way a national language spells it.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [king](other.html#king), [Paul](#paul), [Rome](#rome))

### Bible References:

* [Acts 25:6-8](https://git.door43.org/Door43/en_tn/src/master/act/25/06.md)
* [Luke 02:1-3](https://git.door43.org/Door43/en_tn/src/master/luk/02/01.md)
* [Luke 20:23-24](https://git.door43.org/Door43/en_tn/src/master/luk/20/23.md)
* [Luke 23:1-2](https://git.door43.org/Door43/en_tn/src/master/luk/23/01.md)
* [Mark 12:13-15](https://git.door43.org/Door43/en_tn/src/master/mrk/12/13.md)
* [Matthew 22:15-17](https://git.door43.org/Door43/en_tn/src/master/mat/22/15.md)
* [Philippians 04:21-23](https://git.door43.org/Door43/en_tn/src/master/php/04/21.md)

### Word Data:

* Strong's: G2541


## <a id="tw-term-names-caesarea"/>Caesarea, Caesarea Philippi

### Facts:

Caesarea was an important city on the coast of the Mediterranean Sea, about 39 km south of Mount Carmel. Caesarea Philippi was a city located in the northeastern part of Israel, near Mount Hermon.

* These cities were named for the Caesars who ruled the Roman empire.
* The coastal Caesarea became the capital city of the Roman province of Judea around the time of the birth of Jesus.
* The apostle Peter first preached to the Gentiles in Caesarea.
* Paul sailed from Caesarea to Tarsus and also passed through this city on two of his missionary journeys.
* Jesus and his disciples traveled in the region surrounding Caesarea Philippi in Syria. Both cities were named after Herod Philip.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Caesar](#caesar), [Gentile](kt.html#gentile), [the sea](#mediterranean), [Carmel](#carmel), [Mount Hermon](#mounthermon), [Rome](#rome), [Tarsus](#tarsus))

### Bible References:

* [Acts 09:28-30](https://git.door43.org/Door43/en_tn/src/master/act/09/28.md)
* [Acts 10:1-2](https://git.door43.org/Door43/en_tn/src/master/act/10/01.md)
* [Acts 25:1-3](https://git.door43.org/Door43/en_tn/src/master/act/25/01.md)
* [Acts 25:13-16](https://git.door43.org/Door43/en_tn/src/master/act/25/13.md)
* [Mark 08:27-28](https://git.door43.org/Door43/en_tn/src/master/mrk/08/27.md)
* [Matthew 16:13-16](https://git.door43.org/Door43/en_tn/src/master/mat/16/13.md)

### Word Data:

* Strong's: G2542, G5376


## <a id="tw-term-names-caiaphas"/>Caiaphas

### Facts:

Caiaphas was the high priest of Israel during the time of John the Baptist and Jesus.

 * Caiaphas played a major role in the trial and condemnation of Jesus.
 * ​The high priests Annas and Caiaphas were at the trial of Peter and John when they were arrested after healing a crippled man.
 * Caiaphas is the one who said that it was better for one man to die for the whole nation than for the whole nation to perish. God caused him to say this as a prophecy about how Jesus would die to save his people.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Annas](#annas), [high priest](kt.html#highpriest))

### Bible References:

* [Acts 04:5-7](https://git.door43.org/Door43/en_tn/src/master/act/04/05.md)
* [John 18:12-14](https://git.door43.org/Door43/en_tn/src/master/jhn/18/12.md)
* [Luke 03:1-2](https://git.door43.org/Door43/en_tn/src/master/luk/03/01.md)
* [Matthew 26:3-5](https://git.door43.org/Door43/en_tn/src/master/mat/26/03.md)
* [Matthew 26:57-58](https://git.door43.org/Door43/en_tn/src/master/mat/26/57.md)

### Word Data:

* Strong's: G2533


## <a id="tw-term-names-cain"/>Cain

### Facts:

Cain and his younger brother Abel were the first sons of Adam and Eve mentioned in the Bible.

* Cain was a farmer who produced food crops while Abel was a sheep herder.
* Cain killed his brother Abel in a fit of jealousy because God had accepted Abel's sacrifice but had not accepted Cain's sacrifice.
* As punishment, God sent him away from Eden and told him that the land would no longer yield crops for him.
* God put a mark on Cain's forehead as a sign that God would protect him from being killed by other people as he wandered.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Adam](#adam), [sacrifice](other.html#sacrifice))

### Bible References:

* [1 John 03:11-12](https://git.door43.org/Door43/en_tn/src/master/1jn/03/11.md)
* [Genesis 04:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/04/01.md)
* [Genesis 04:8-9](https://git.door43.org/Door43/en_tn/src/master/gen/04/08.md)
* [Genesis 04:13-15](https://git.door43.org/Door43/en_tn/src/master/gen/04/13.md)
* [Hebrews 11:4](https://git.door43.org/Door43/en_tn/src/master/heb/11/04.md)
* [Jude 01:9-11](https://git.door43.org/Door43/en_tn/src/master/jud/01/09.md)

### Word Data:

* Strong's: H7014, G2535


## <a id="tw-term-names-caleb"/>Caleb

### Facts:

Caleb was one of the twelve Israelite spies whom Moses sent to explore the land of Canaan.

* He and Joshua told the people to trust God to help them defeat the Canaanites.
* Joshua and Caleb were the only men of their generation who were allowed to enter the Promised Land of Canaan.
* Caleb requested that the land of Hebron be given to him and his family. He knew that God would help him defeat the people who lived there.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Hebron](#hebron), [Joshua](#joshua))

### Bible References:

* [1 Chronicles 04:13-16](https://git.door43.org/Door43/en_tn/src/master/1ch/04/13.md)
* [Joshua 14:6-7](https://git.door43.org/Door43/en_tn/src/master/jos/14/06.md)
* [Judges 01:11-13](https://git.door43.org/Door43/en_tn/src/master/jdg/01/11.md)
* [Numbers 32:10-12](https://git.door43.org/Door43/en_tn/src/master/num/32/10.md)

### Examples from the Bible stories:

  __*[14:04](https://git.door43.org/Door43/en_tn/src/master/obs/14/04.md)__ When the Israelites reached the edge of Canaan, Moses chose twelve men, one from each tribe of Israel. He gave the men instructions to go and spy on the land to see what it was like. 
  __*[14:06](https://git.door43.org/Door43/en_tn/src/master/obs/14/06.md)__ Immediately __Caleb__ and Joshua, the other two spies, said, "It is true that the people of Canaan are tall and strong, but we can certainly defeat them! God will fight for us!"
  __*[14:08](https://git.door43.org/Door43/en_tn/src/master/obs/14/08.md)__ "Except for Joshua and __Caleb__, everyone who is twenty years old or older will die there and never enter the Promised Land."

 so that they could live at peace in that land.

### Word Data:

* Strong's: H3612, H3614


## <a id="tw-term-names-cana"/>Cana

### Definition:

Cana was a village or town in the province of Galilee, located about nine miles north of Nazareth.

* Cana was the hometown of Nathanael, one of the Twelve.
* Jesus attended a wedding feast in Cana and performed his first miracle there when he turned water into wine.
* Some time after that, Jesus came back to Cana and met an official there from Capernaum who requested healing for his son.

(See also: [Capernaum](#capernaum), [Galilee](#galilee), [the twelve](kt.html#thetwelve))

### Bible References:

* [John 02:1-2](https://git.door43.org/Door43/en_tn/src/master/jhn/02/01.md)
* [John 04:46-47](https://git.door43.org/Door43/en_tn/src/master/jhn/04/46.md)

### Word Data:

* Strong's: G2580


## <a id="tw-term-names-canaan"/>Canaan, Canaanite, Canaanites

### Facts:

Canaan was the son of Ham, who was one of Noah's sons. The Canaanites were the descendants of Canaan.

* The term "Canaan" or the "land of Canaan" also referred to an area of land between the Jordan River and the Mediterranean Sea. It extended south to the border of Egypt and north to the border of Syria.
* This land was inhabited by the Canaanites, as well as several other people groups.
* God promised to give the land of Canaan to Abraham and his descendants, the Israelites.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Ham](#ham), [Promised Land](kt.html#promisedland))

### Bible References:

* [Acts 13:19-20](https://git.door43.org/Door43/en_tn/src/master/act/13/19.md)
* [Exodus 03:7-8](https://git.door43.org/Door43/en_tn/src/master/exo/03/07.md)
* [Genesis 09:18-19](https://git.door43.org/Door43/en_tn/src/master/gen/09/18.md)
* [Genesis 10:19-20](https://git.door43.org/Door43/en_tn/src/master/gen/10/19.md)
* [Genesis 13:5-7](https://git.door43.org/Door43/en_tn/src/master/gen/13/05.md)
* [Genesis 47:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/47/01.md)

### Examples from the Bible stories:

* __[04:05](https://git.door43.org/Door43/en_tn/src/master/obs/04/05.md)__ He (Abram) took his wife, Sarai, together with all his servants and everything he owned and went to the land God showed him, the land of __Canaan__.
* __[04:06](https://git.door43.org/Door43/en_tn/src/master/obs/04/06.md)__ When Abram arrived in __Canaan__  God said, "Look all around you. I will give to you and your descendants all the land that you can see as an inheritance."
* __[04:09](https://git.door43.org/Door43/en_tn/src/master/obs/04/09.md)__ "I give the land of __Canaan__  to your descendants."
* __[05:03](https://git.door43.org/Door43/en_tn/src/master/obs/05/03.md)__ "I will give you and your descendants the land of __Canaan__  as their possession and I will be their God forever."
* __[07:08](https://git.door43.org/Door43/en_tn/src/master/obs/07/08.md)__ After twenty years away from his home in __Canaan__, Jacob returned there with his family, his servants, and all his herds of animals.

### Word Data:

* Strong's: H3667, H3669, G2581, G5478


## <a id="tw-term-names-capernaum"/>Capernaum

### Facts:

Capernaum was a fishing village on the northwest shore of the Sea of Galilee.

 * Jesus lived in Capernaum whenever he was teaching in Galilee.
 * Several of his disciples were from Capernaum.
 * Jesus also did many miracles in this city, including bringing a dead girl back to life.
 * Capernaum was one of three cities that Jesus publicly rebuked because their people rejected him and did not believe his message. He warned them that God would punish them for their unbelief.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Galilee](#galilee), [Sea of Galilee](#seaofgalilee))

### Bible References:

* [John 02:12](https://git.door43.org/Door43/en_tn/src/master/jhn/02/12.md)
* [Luke 04:31-32](https://git.door43.org/Door43/en_tn/src/master/luk/04/31.md)
* [Luke 07:1](https://git.door43.org/Door43/en_tn/src/master/luk/07/01.md)
* [Mark 01:21-22](https://git.door43.org/Door43/en_tn/src/master/mrk/01/21.md)
* [Mark 02:1-2](https://git.door43.org/Door43/en_tn/src/master/mrk/02/01.md)
* [Matthew 04:12-13](https://git.door43.org/Door43/en_tn/src/master/mat/04/12.md)
* [Matthew 17:24-25](https://git.door43.org/Door43/en_tn/src/master/mat/17/24.md)

### Word Data:

* Strong's: G2584


## <a id="tw-term-names-carmel"/>Carmel, Mount Carmel

### Facts:

"Mount Carmel" refers to a mountain range that was located along the coast of the Mediterranean Sea just north of the Plain of Sharon. Its highest peak is 546 meters high.

* There was also a town called "Carmel" located in Judah, south of the Salt Sea.
* The wealthy landowner Nabal and his wife Abigail lived near the town of Carmel where David and his men helped guard Nabal's sheep shearers.
* On Mount Carmel, Elijah challenged the prophets of Baal to a contest in order to prove that Yahweh is the only true God.
* To make it clear that this wasn't just a single mountain, "Mount Carmel" could be translated as, "mountain on the Carmel mountain range" or "Carmel mountain range."

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Baal](#baal), [Elijah](#elijah), [Judah](#judah), [Salt Sea](#saltsea))

### Bible References:

* [1 Kings 18:18-19](https://git.door43.org/Door43/en_tn/src/master/1ki/18/18.md)
* [1 Samuel 15:12-13](https://git.door43.org/Door43/en_tn/src/master/1sa/15/12.md)
* [Jeremiah 46:18-19](https://git.door43.org/Door43/en_tn/src/master/jer/46/18.md)
* [Micah 07:14-15](https://git.door43.org/Door43/en_tn/src/master/mic/07/14.md)

### Word Data:

* Strong's: H3760, H3761, H3762


## <a id="tw-term-names-chaldeans"/>Chaldea, Chaldean, Chaldeans

### Facts:

Chaldea was a region in the southern part of Mesopotamia or Babylonia. The people who lived in this region were called Chaldeans.

* The city of Ur, where Abraham was from, was located in Chaldea. It is often referred to as "Ur of the Chaldeans."
* King Nebuchadnezzar was one of several Chaldeans who became kings over Babylonia.
* After many years, around 600 BC, the term "Chaldean" came to mean "Babylonian."
* In the book of Daniel, the term "Chaldean" also refers to a special class of men who were highly educated and studied the stars.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Abraham](#abraham), [Babylon](#babylon), [Shinar](#shinar), [Ur](#ur))

### Bible References:

* [Acts 07:4-5](https://git.door43.org/Door43/en_tn/src/master/act/07/04.md)
* [Ezekiel 01:1-3](https://git.door43.org/Door43/en_tn/src/master/ezk/01/01.md)
* [Genesis 11:27-28](https://git.door43.org/Door43/en_tn/src/master/gen/11/27.md)
* [Genesis 11:31-32](https://git.door43.org/Door43/en_tn/src/master/gen/11/31.md)
* [Genesis 15:6-8](https://git.door43.org/Door43/en_tn/src/master/gen/15/06.md)
* [Isaiah 13:19-20](https://git.door43.org/Door43/en_tn/src/master/isa/13/19.md)

### Word Data:

* Strong's: H3679, H3778, H3779, G5466


## <a id="tw-term-names-cherethites"/>Kerethites

### Facts:

The Kerethites were a people group who were probably part of the Philistines. Some versions write this name as "Cherethites."

* The "Kerethites and Pelethites" were a special group of soldiers from King David's army who were especially devoted to him as his bodyguards.
* Benaiah, son of Jehoiada, a member of David's administrative corps, was the leader of the Kerethites and Pelethites.
* The Kerethites remained with David when he had to flee Jerusalem because of Absalom's revolt.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Absalom](#absalom), [Benaiah](#benaiah), [David](#david), [Philistines](#philistines))

### Bible References:

* [Zephaniah 02:4-5](https://git.door43.org/Door43/en_tn/src/master/zep/02/04.md)

### Word Data:

* Strong's: H3774


## <a id="tw-term-names-cilicia"/>Cilicia

### Facts:

Cilicia was a small Roman province located in the southeastern part of what is now the modern-day country of Turkey. It borders the Aegean Sea.

* The apostle Paul was a citizen from the city of Tarsus located in Cilicia.
* Paul spent several years in Cilicia after his encounter with Jesus on the road to Damascus.
* Some of the Jews from Cilicia were among those who confronted Stephen and influenced the people to stone him to death.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Paul](#paul), [Stephen](#stephen), [Tarsus](#tarsus))

### Bible References:

* [Acts 06:8-9](https://git.door43.org/Door43/en_tn/src/master/act/06/08.md)
* [Acts 15:39-41](https://git.door43.org/Door43/en_tn/src/master/act/15/39.md)
* [Acts 27:3-6](https://git.door43.org/Door43/en_tn/src/master/act/27/03.md)
* [Galatians 01:21-24](https://git.door43.org/Door43/en_tn/src/master/gal/01/21.md)

### Word Data:

* Strong's: G2791


## <a id="tw-term-names-cityofdavid"/>city of David

### Facts:

The term "city of David" is another name for both Jerusalem and Bethlehem.

 * Jerusalem is where David lived while he ruled Israel.
 * Bethlehem is where David was born.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [David](#david), [Bethlehem](#bethlehem), [Jerusalem](#jerusalem))

### Bible References:

* [1 Kings 08:1-2](https://git.door43.org/Door43/en_tn/src/master/1ki/08/01.md)
* [2 Samuel 05:6-7](https://git.door43.org/Door43/en_tn/src/master/2sa/05/06.md)
* [Isaiah 22:8-9](https://git.door43.org/Door43/en_tn/src/master/isa/22/08.md)
* [Luke 02:4-5](https://git.door43.org/Door43/en_tn/src/master/luk/02/04.md)
* [Nehemiah 03:14-15](https://git.door43.org/Door43/en_tn/src/master/neh/03/14.md)

### Word Data:

* Strong's: H1732, H5892, G1138, G4172


## <a id="tw-term-names-colossae"/>Colossae, Colossians

### Facts:

In New Testament times, Colossae was a city located in the Roman province of Phrygia, an area of land that is now southwestern Turkey. The Colossians were the people who lived in Colossae.

* Located about 100 miles inland from the Mediterranean Sea, Colossae was on an important trade route between the city of Ephesus and the Euphrates River.
* While in prison in Rome, Paul wrote a letter to the "Colossians" to correct false teachings among the believers at Colossae.
* When he wrote this letter, Paul had not visited the church at Colossae, but had heard about the believers there from his coworker, Epaphras.
* Epaphras was probably the Christian worker who started the church at Colossae.
* The book of Philemon was a letter by Paul addressed to a slave owner in Colossae.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Ephesus](#ephesus), [Paul](#paul))

### Bible References:

* [Colossians 01:1-3](https://git.door43.org/Door43/en_tn/src/master/col/01/01.md)

### Word Data:

* Strong's: G2857, G2858


## <a id="tw-term-names-corinth"/>Corinth, Corinthians

### Facts:

Corinth was a city in the country of Greece, about 50 miles west of Athens. The Corinthians were the people who lived at Corinth.

* Corinth was the location of one of the early Christian churches.
* The New Testament books, 1 Corinthians and 2 Corinthians were letters written by Paul to the Christians living in Corinth.
* On his first missionary journey, Paul stayed in Corinth for approximately 18 months.
* Paul met the believers Aquila and Priscilla while in Corinth.
* Other early church leaders associated with Corinth include Timothy, Titus, Apollos, and Silas.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Apollos](#apollos), [Timothy](#timothy), [Titus](#titus))

### Bible References:

* [1 Corinthians 01:1-3](https://git.door43.org/Door43/en_tn/src/master/1co/01/01.md)
* [2 Corinthians 01:23-24](https://git.door43.org/Door43/en_tn/src/master/2co/01/23.md)
* [2 Timothy 04:19-22](https://git.door43.org/Door43/en_tn/src/master/2ti/04/19.md)
* [Acts 18:1-3](https://git.door43.org/Door43/en_tn/src/master/act/18/01.md)

### Word Data:

* Strong's: G2881, G2882


## <a id="tw-term-names-cornelius"/>Cornelius

### Facts:

Cornelius was a Gentile, or non-Jewish man, who was a military officer in the Roman army.

* He prayed regularly to God and was very generous in giving to the poor.
* When Cornelius and his family heard the apostle Peter explain the gospel, they became believers in Jesus.
* The people of Cornelius' household were the first non-Jewish people to become believers.
* This showed Jesus' followers that he had come to save all people, including Gentiles.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [apostle](kt.html#apostle), [believe](kt.html#believe), [Gentile](kt.html#gentile), [good news](kt.html#goodnews), [Greek](#greek), [centurion](kt.html#centurion))

### Bible References:

* [Acts 10:1-2](https://git.door43.org/Door43/en_tn/src/master/act/10/01.md)
* [Acts 10:7-8](https://git.door43.org/Door43/en_tn/src/master/act/10/07.md)
* [Acts 10:17-18](https://git.door43.org/Door43/en_tn/src/master/act/10/17.md)
* [Acts 10:22-23](https://git.door43.org/Door43/en_tn/src/master/act/10/22.md)
* [Acts 10:24](https://git.door43.org/Door43/en_tn/src/master/act/10/24.md)
* [Acts 10:25-26](https://git.door43.org/Door43/en_tn/src/master/act/10/25.md)
* [Acts 10:30-33](https://git.door43.org/Door43/en_tn/src/master/act/10/30.md)

### Word Data:

* Strong's: G2883


## <a id="tw-term-names-crete"/>Crete, Cretan, Cretans

### Facts:

Crete is an island that is located off the southern coast of Greece. A "Cretan" is someone who lives on this island.

* The apostle Paul traveled to the island of Crete during his missionary journeys.
* Paul left his co-worker Titus on Crete to teach the Christians and to help appoint leaders for the church there.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

### Bible References:

* [Acts 02:8-11](https://git.door43.org/Door43/en_tn/src/master/act/02/08.md)
* [Acts 27:7-8](https://git.door43.org/Door43/en_tn/src/master/act/27/07.md)
* [Amos 09:7-8](https://git.door43.org/Door43/en_tn/src/master/amo/09/07.md)
* [Titus 01:12-13](https://git.door43.org/Door43/en_tn/src/master/tit/01/12.md)

### Word Data:

* Strong's: G2912, G2914


## <a id="tw-term-names-cush"/>Cush

### Facts:

Cush was the oldest son of Noah's son Ham. He was also the ancestor of Nimrod. Two of his brothers were named Egypt and Canaan.

* In Old Testament times, "Cush" was the name of a large region of land south of Israel. It is probable that the land was named after Ham's son Cush.
* The ancient region of Cush covered an area of land that may have, at different times, included parts of the modern-day countries of Sudan, Egypt, Ethiopia, and possibly, Saudi Arabia.
* Another man named Cush is mentioned in the Psalms. He was a Benjamite.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Arabia](#arabia), [Canaan](#canaan), [Egypt](#egypt), [Ethiopia](#ethiopia))

### Bible References:

* [1 Chronicles 01:8-10](https://git.door43.org/Door43/en_tn/src/master/1ch/01/08.md)
* [Ezekiel 29:8-10](https://git.door43.org/Door43/en_tn/src/master/ezk/29/08.md)
* [Genesis 02:13-14](https://git.door43.org/Door43/en_tn/src/master/gen/02/13.md)
* [Genesis 10:6-7](https://git.door43.org/Door43/en_tn/src/master/gen/10/06.md)
* [Jeremiah 13:22-24](https://git.door43.org/Door43/en_tn/src/master/jer/13/22.md)

### Word Data:

* Strong's: H3568, H3569, H3570


## <a id="tw-term-names-cyprus"/>Cyprus

### Facts:

Cyprus is an island in the Mediterranean Sea, about 64 kilometers south of the modern-day country of Turkey.

* Barnabas was from Cyprus so it is probable that his cousin John Mark was also from there.
* Paul and Barnabas preached together on the island of Cyprus at the beginning of their first missionary journey. John Mark came along to help them on that trip.
* Later on, Barnabas and Mark visited Cyprus again.
* In the Old Testament, Cyprus is mentioned as being a rich source of cypress trees.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Barnabas](#barnabas), [John Mark](#johnmark), [the sea](#mediterranean))

### Bible References:

* [Acts 04:36-37](https://git.door43.org/Door43/en_tn/src/master/act/04/36.md)
* [Acts 13:4-5](https://git.door43.org/Door43/en_tn/src/master/act/13/04.md)
* [Acts 15:39-41](https://git.door43.org/Door43/en_tn/src/master/act/15/39.md)
* [Acts 27:3-6](https://git.door43.org/Door43/en_tn/src/master/act/27/03.md)
* [Ezekiel 27:6-7](https://git.door43.org/Door43/en_tn/src/master/ezk/27/06.md)
* [Isaiah 23:10-12](https://git.door43.org/Door43/en_tn/src/master/isa/23/10.md)

### Word Data:

* Strong's: G2953, G2954


## <a id="tw-term-names-cyrene"/>Cyrene

### Facts:

Cyrene was a Greek city on the north coast of Africa on the Mediterranean Sea, directly south of the island of Crete.

* In New Testament times, both Jews and Christians lived in Cyrene.
* Cyrene is probably most well-known in the Bible as the home city of a man named Simon who carried the cross of Jesus.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Crete](#crete))

### Bible References:

* [Acts 11:19-21](https://git.door43.org/Door43/en_tn/src/master/act/11/19.md)
* [Matthew 27:32-34](https://git.door43.org/Door43/en_tn/src/master/mat/27/32.md)

### Word Data:

* Strong's: G2956, G2957


## <a id="tw-term-names-cyrus"/>Cyrus

### Facts:

Cyrus was a Persian king who founded the Persian empire in about 550 BC, through military conquest. In history he was also known as Cyrus the Great.

* King Cyrus conquered the city of Babylon, which led to the release of the Israelites who had been kept in exile there.
* Cyrus was known for his tolerant attitude toward the people of the nations he conquered. His kindness toward the Jews led to the rebuilding of the Jerusalem temple after the exile.
* Cyrus was reigning during the time when Daniel, Ezra, and Nehemiah were living.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Daniel](#daniel), [Darius](#darius), [Ezra](#ezra), [Nehemiah](#nehemiah), [Persia](#persia))

### Bible References:

* [2 Chronicles 36:22-23](https://git.door43.org/Door43/en_tn/src/master/2ch/36/22.md)
* [Daniel 01:19-21](https://git.door43.org/Door43/en_tn/src/master/dan/01/19.md)
* [Ezra 05:12-13](https://git.door43.org/Door43/en_tn/src/master/ezr/05/12.md)
* [Isaiah 44:28](https://git.door43.org/Door43/en_tn/src/master/isa/44/28.md)

### Word Data:

* Strong's: H3566


## <a id="tw-term-names-damascus"/>Damascus

### Facts:

Damascus is the capital city of the country of Syria. It is still in the same location as it was in Bible times.

* Damascus is one of the oldest, continuously inhabited cities in the world.
* During the time of Abraham, Damascus was the capital of the Aram kingdom (located in what is now Syria).
* Throughout the Old Testament, there are many references to the interactions between the inhabitants of Damascus and the people of Israel.
* Several biblical prophecies predict the destruction of Damascus. These prophecies may have been fulfilled when Assyria destroyed the city during Old Testament times, or there may be also be a future, more complete destruction of this city.
* In the New Testament, the Pharisee Saul (later known as Paul) was on his way to arrest Christians in the city of Damascus when Jesus confronted him and caused him to become a believer.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Aram](#aram), [Assyria](#assyria), [believe](kt.html#believe), [Syria](#syria))

### Bible References:

* [2 Chronicles 24:23-24](https://git.door43.org/Door43/en_tn/src/master/2ch/24/23.md)
* [Acts 09:1-2](https://git.door43.org/Door43/en_tn/src/master/act/09/01.md)
* [Acts 09:3-4](https://git.door43.org/Door43/en_tn/src/master/act/09/03.md)
* [Acts 26:12-14](https://git.door43.org/Door43/en_tn/src/master/act/26/12.md)
* [Galatians 01:15-17](https://git.door43.org/Door43/en_tn/src/master/gal/01/15.md)
* [Genesis 14:15-16](https://git.door43.org/Door43/en_tn/src/master/gen/14/15.md)

### Word Data:

* Strong's: H1833, H1834, G1154


## <a id="tw-term-names-dan"/>Dan

### Facts:

Dan was the fifth son of Jacob and was one of the twelve tribes of Israel.The region settled by the tribe of Dan in the northern part of Canaan also was given this name.

* During the time of Abram, there was a city named Dan located west of Jerusalem.
* Years later, during the time the nation of Israel entered the promised land, a different city named Dan was located about 60 miles north of Jerusalem.
* The term "Danites" refers to the descendants of Dan, who were also members of his clan.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Canaan](#canaan), [Jerusalem](#jerusalem), [twelve tribes of Israel](other.html#12tribesofisrael))

### Bible References:

* [1 Chronicles 12:34-35](https://git.door43.org/Door43/en_tn/src/master/1ch/12/34.md)
* [1 Kings 04:24-25](https://git.door43.org/Door43/en_tn/src/master/1ki/04/24.md)
* [Exodus 01:1-5](https://git.door43.org/Door43/en_tn/src/master/exo/01/01.md)
* [Genesis 14:13-14](https://git.door43.org/Door43/en_tn/src/master/gen/14/13.md)
* [Genesis 30:5-6](https://git.door43.org/Door43/en_tn/src/master/gen/30/05.md)

### Word Data:

* Strong's: H1835, H1839, H2051


## <a id="tw-term-names-daniel"/>Daniel

### Facts:

Daniel was an Israelite prophet who as a young man was taken captive by the Babylonian king Nebuchadnezzar around 600 BC.

* This was during the time that many other Israelites from Judah were held captive in Babylon for 70 years.
* Daniel was given the Babylonian name Belteshazzar.
* Daniel was an honorable and righteous young man who obeyed God.
* God enabled Daniel to interpret several dreams or visions for the Babylonian kings.
* Because of this ability and because of his honorable character, Daniel was given a high leadership position in the Babylonian empire.
* Many years later, Daniels enemies tricked the Babylonian king Darius into making a law forbidding the worship of anyone except the king. Daniel continued to pray to God, so he was arrested and thrown into a den of lions. But God rescued him and he was not harmed at all.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Babylon](#babylon), [Nebuchadnezzar](#nebuchadnezzar))

### Bible References:

* [Daniel 01:6-7](https://git.door43.org/Door43/en_tn/src/master/dan/01/06.md)
* [Daniel 05:29-31](https://git.door43.org/Door43/en_tn/src/master/dan/05/29.md)
* [Daniel 07:27-28](https://git.door43.org/Door43/en_tn/src/master/dan/07/27.md)
* [Ezekiel 14:12-14](https://git.door43.org/Door43/en_tn/src/master/ezk/14/12.md)
* [Matthew 24:15-18](https://git.door43.org/Door43/en_tn/src/master/mat/24/15.md)

### Word Data:

* Strong's: H1840, H1841, G1158


## <a id="tw-term-names-darius"/>Darius

### Facts:

Darius was the name of several kings of Persia. It is possible that "Darius" was a title rather than a name.
 * "Darius the Mede" was the king who was tricked into having the prophet Daniel thrown into a lion's den as punishment for worshiping God.
 * "Darius the Persian" helped facilitate the reconstruction of the temple in Jerusalem during the time of Ezra and Nehemiah.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Persia](#persia), [Babylon](#babylon), [Daniel](#daniel), [Ezra](#ezra), [Nehemiah](#nehemiah))

### Bible References:

* [Ezra 04:4-6](https://git.door43.org/Door43/en_tn/src/master/ezr/04/04.md)
* [Haggai 01:1-2](https://git.door43.org/Door43/en_tn/src/master/hag/01/01.md)
* [Nehemiah 12:22-23](https://git.door43.org/Door43/en_tn/src/master/neh/12/22.md)
* [Zechariah 01:1-3](https://git.door43.org/Door43/en_tn/src/master/zec/01/01.md)

### Word Data:

* Strong's: H1867, H1868


## <a id="tw-term-names-david"/>David

### Facts:

David was the second king of Israel and he loved and served God. He was the main writer of the book of Psalms.

* When David was still a young boy caring for his family's sheep, God chose him to become the next king of Israel. 
* David became a great fighter and led the Israelite army in battles against their enemies. His defeat of Goliath the Philistine is well known.
* King Saul tried to kill David, but God protected him, and made him king after Saul's death.
* David committed a terrible sin, but he repented and God forgave him.
* Jesus, the Messiah, is called the "Son of David" because he is a descendant of King David. 

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Goliath](#goliath), [Philistines](#philistines), [Saul (OT)](#saul))

### Bible References:

* [1 Samuel 17:12-13](https://git.door43.org/Door43/en_tn/src/master/1sa/17/12.md)
* [1 Samuel 20:32-34](https://git.door43.org/Door43/en_tn/src/master/1sa/20/32.md)
* [2 Samuel 05:1-2](https://git.door43.org/Door43/en_tn/src/master/2sa/05/01.md)
* [2 Timothy 02:8-10](https://git.door43.org/Door43/en_tn/src/master/2ti/02/08.md)
* [Acts 02:25-26](https://git.door43.org/Door43/en_tn/src/master/act/02/25.md)
* [Acts 13:21-22](https://git.door43.org/Door43/en_tn/src/master/act/13/21.md)
* [Luke 01:30-33](https://git.door43.org/Door43/en_tn/src/master/luk/01/30.md)
* [Mark 02:25-26](https://git.door43.org/Door43/en_tn/src/master/mrk/02/25.md)

### Examples from the Bible stories:

  __*[17:02](https://git.door43.org/Door43/en_tn/src/master/obs/17/02.md)__ God chose a young Israelite named __David__ to be king after Saul. __David__ was a shepherd from the town of Bethlehem. … __David__ was a humble and righteous man who trusted and obeyed God. 
  __*[17:03](https://git.door43.org/Door43/en_tn/src/master/obs/17/03.md)__ __David__ was also a great soldier and leader. When __David__ was still a young man, he fought against a giant named Goliath. 
  __*[17:04](https://git.door43.org/Door43/en_tn/src/master/obs/17/04.md)__ Saul became jealous of the people's love for __David__. Saul tried many times to kill him, so __David__ hid from Saul. 
  __*[17:05](https://git.door43.org/Door43/en_tn/src/master/obs/17/05.md)__ God blessed __David__ and made him successful. __David__ fought many battles and God helped him defeat Israel's enemies.  
  __*[17:06](https://git.door43.org/Door43/en_tn/src/master/obs/17/06.md)__ __David__ wanted to build a temple where all the Israelites could worship God and offer him sacrifices. 
  __*[17:09](https://git.door43.org/Door43/en_tn/src/master/obs/17/09.md)__ __David__ ruled with justice and faithfulness for many years, and God blessed him. However, toward the end of his life he sinned terribly against God. 
  __*[17:13](https://git.door43.org/Door43/en_tn/src/master/obs/17/13.md)__ God was very angry about what __David__ had done, so he sent the prophet Nathan to tell __David__ how evil his sin was. __David__ repented of his sin and God forgave him. For the rest of his life, __David__ followed and obeyed God, even in difficult times.

### Word Data:

* Strong's: H1732, G1138


## <a id="tw-term-names-delilah"/>Delilah

### Facts:

Delilah was a Philistine woman who was loved by Samson, but was not his wife.

* Delilah loved money more than she loved Samson.
* The Philistines bribed Delilah to trick Samson into telling her how he could be made weak. When his strength was gone, the Philistines captured him.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [bribe](other.html#bribe), [Philistines](#philistines), [Samson](#samson))

### Bible References:

* [Judges 16:4-5](https://git.door43.org/Door43/en_tn/src/master/jdg/16/04.md)
* [Judges 16:6-7](https://git.door43.org/Door43/en_tn/src/master/jdg/16/06.md)
* [Judges 16:10-12](https://git.door43.org/Door43/en_tn/src/master/jdg/16/10.md)
* [Judges 16:18-19](https://git.door43.org/Door43/en_tn/src/master/jdg/16/18.md)

### Word Data:

* Strong's: H1807


## <a id="tw-term-names-eden"/>Eden, garden of Eden

### Facts:

In ancient times, Eden was a region that had a garden where God placed the first man and woman to live.

* The garden where Adam and Eve lived was only part of Eden.
* The exact location of the region of Eden is not certain, but the Tigris and Euphrates Rivers were flowing through it.
* The word "Eden" comes from a Hebrew word meaning to "take great delight in."

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Adam](#adam), [Euphrates River](#euphrates), [Eve](#eve))

### Bible References:

* [Ezekiel 28:11-13](https://git.door43.org/Door43/en_tn/src/master/ezk/28/11.md)
* [Genesis 02:7-8](https://git.door43.org/Door43/en_tn/src/master/gen/02/07.md)
* [Genesis 02:9-10](https://git.door43.org/Door43/en_tn/src/master/gen/02/09.md)
* [Genesis 02:15-17](https://git.door43.org/Door43/en_tn/src/master/gen/02/15.md)
* [Genesis 04:16-17](https://git.door43.org/Door43/en_tn/src/master/gen/04/16.md)
* [Joel 02:3](https://git.door43.org/Door43/en_tn/src/master/jol/02/03.md)

### Word Data:

* Strong's: H5729, H5731


## <a id="tw-term-names-edom"/>Edom, Edomite, Edomites, Idumea

### Facts:

Edom was another name for Esau. The region where he lived also became known as "Edom" and later, "Idumea." The "Edomites" were his descendants.

* The region of Edom changed locations over time. It was mostly located to the south of Israel and eventually extended into southern Judah.
* During New Testament times, Edom covered the southern half of the province of Judea. The Greeks called it "Idumea."
* The name "Edom" means "red," which may refer to the fact that Esau was covered with red hair when he was born. Or it may refer to the red lentil stew that Esau traded his birthright for.
* In the Old Testament, the country of Edom is often mentioned as an enemy of Israel.
* The entire book of Obadiah is about the destruction of Edom. Other Old Testament prophets also spoke negative prophecies against Edom.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [adversary](other.html#adversary), [birthright](kt.html#birthright), [Esau](#esau), [Obadiah](#obadiah), [prophet](kt.html#prophet))

### Bible References:

* [Genesis 25:29-30](https://git.door43.org/Door43/en_tn/src/master/gen/25/29.md)
* [Genesis 32:3-5](https://git.door43.org/Door43/en_tn/src/master/gen/32/03.md)
* [Genesis 36:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/36/01.md)
* [Isaiah 11:14-15](https://git.door43.org/Door43/en_tn/src/master/isa/11/14.md)
* [Joshua 11:16-17](https://git.door43.org/Door43/en_tn/src/master/jos/11/16.md)
* [Obadiah 01:1-2](https://git.door43.org/Door43/en_tn/src/master/oba/01/01.md)

### Word Data:

* Strong's: H123, H130, H8165, G2401


## <a id="tw-term-names-egypt"/>Egypt, Egyptian, Egyptians

### Facts:

Egypt is a country in the northeast part of Africa, to the southwest of the land of Canaan. An Egyptian is a person who is from the country of Egypt.

* In ancient times, Egypt was a powerful and wealthy country.
* Ancient Egypt was divided into two parts, Lower Egypt (northern part where the Nile River flowed downward into the sea) and Upper Egypt (southern part). In the Old Testament, these parts are referred to as "Egypt" and "Pathros" in the original language text.
* Several times when there was little food in Canaan, Israel's patriarchs traveled to Egypt to buy food for their families.
* For several hundred years, the Israelites were slaves in Egypt.
* Joseph and Mary went down to Egypt with the young child Jesus, to escape from Herod the Great.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Herod the Great](#herodthegreat), [Joseph (NT)](#josephnt), [Nile River](#nileriver), [patriarchs](other.html#patriarchs))

### Bible References:

* [1 Samuel 04:7-9](https://git.door43.org/Door43/en_tn/src/master/1sa/04/07.md)
* [Acts 07:9-10](https://git.door43.org/Door43/en_tn/src/master/act/07/09.md)
* [Exodus 03:7-8](https://git.door43.org/Door43/en_tn/src/master/exo/03/07.md)
* [Genesis 41:27-29](https://git.door43.org/Door43/en_tn/src/master/gen/41/27.md)
* [Genesis 41:55-57](https://git.door43.org/Door43/en_tn/src/master/gen/41/55.md)
* [Matthew 02:13-15](https://git.door43.org/Door43/en_tn/src/master/mat/02/13.md)

### Examples from the Bible stories:

* __[08:04](https://git.door43.org/Door43/en_tn/src/master/obs/08/04.md)__ The slave traders took Joseph to __Egypt__. __Egypt__  was a large, powerful country located along the Nile River.
* __[08:08](https://git.door43.org/Door43/en_tn/src/master/obs/08/08.md)__ Pharaoh was so impressed with Joseph that he appointed him to be the second most powerful man in all of __Egypt__!
* __[08:11](https://git.door43.org/Door43/en_tn/src/master/obs/08/11.md)__ So Jacob sent his older sons to __Egypt __  to buy food.
* __[08:14](https://git.door43.org/Door43/en_tn/src/master/obs/08/14.md)__ Even though Jacob was an old man, he moved to __Egypt__  with all of his family, and they all lived there.
* __[09:01](https://git.door43.org/Door43/en_tn/src/master/obs/09/01.md)__ After Joseph died, all of his relatives stayed in __Egypt__.

### Word Data:

* Strong's: H4713, H4714, G124, G125


## <a id="tw-term-names-ekron"/>Ekron, Ekronites

### Facts:

Ekron was a major city of the Philistines, located nine miles inland from the Mediterranean Sea.

* A temple of the false god Baal-zebub was located at Ekron.
* When the Philistines captured the ark of the covenant, they took it to Ashdod and then moved it to Gath and Ekron because God kept causing people to get sick and die in whatever city the ark was taken to. Finally the Philistines sent the ark back to Israel.
* When King Ahaziah fell through the roof of his house and injured himself, he sinned by trying to find out from the false god Baal-zebub of Ekron as to whether or not he would die from his injuries. Because of this sin, Yahweh said that he would die.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md)) 

(See also: [Ahaziah](#ahaziah), [ark of the covenant](kt.html#arkofthecovenant), [Ashdod](#ashdod), [Beelzebul](#beelzebul), [false god](kt.html#falsegod), [Gath](#gath), [Philistines](#philistines))

### Bible References:

* [1 Samuel 05:10](https://git.door43.org/Door43/en_tn/src/master/1sa/05/10.md)
* [Joshua 13:2-3](https://git.door43.org/Door43/en_tn/src/master/jos/13/02.md)
* [Judges 01:18-19](https://git.door43.org/Door43/en_tn/src/master/jdg/01/18.md)
* [Zechariah 09:5-7](https://git.door43.org/Door43/en_tn/src/master/zec/09/05.md)

### Word Data:

* Strong's: H6138, H6139


## <a id="tw-term-names-elam"/>Elam, Elamites

### Facts:

Elam was a son of Shem and a grandson of Noah.

* The descendants of Elam were called "Elamites," and they lived in a region that was also called "Elam."
* The region of Elam was located southeast of the Tigris River in what is now western Iran.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Noah](#noah), [Shem](#shem))

### Bible References:

* [1 Chronicles 01:17-19](https://git.door43.org/Door43/en_tn/src/master/1ch/01/17.md)
* [Acts 02:8-11](https://git.door43.org/Door43/en_tn/src/master/act/02/08.md)
* [Ezra 08:4-7](https://git.door43.org/Door43/en_tn/src/master/ezr/08/04.md)
* [Isaiah 22:5-7](https://git.door43.org/Door43/en_tn/src/master/isa/22/05.md)

### Word Data:

* Strong's: H5867, H5962, G1639


## <a id="tw-term-names-eleazar"/>Eleazar

### Facts:

Eleazar was the name of several men in the Bible.
 
* Eleazar was the third son of Moses' brother Aaron. After Aaron died, Eleazar became the high priest in Israel.
* Eleazar was also the name of one of David's "mighty men."
* Another Eleazar was one of Jesus' ancestors.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Aaron](#aaron), [high priest](kt.html#highpriest), [David](#david), [mighty](other.html#mighty))

### Bible References:

* [1 Chronicles 24:1-3](https://git.door43.org/Door43/en_tn/src/master/1ch/24/01.md)
* [Judges 20:27-28](https://git.door43.org/Door43/en_tn/src/master/jdg/20/27.md)
* [Numbers 26:1-2](https://git.door43.org/Door43/en_tn/src/master/num/26/01.md)
* [Numbers 34:16-18](https://git.door43.org/Door43/en_tn/src/master/num/34/16.md)

### Word Data:

* Strong's: H499, G1648


## <a id="tw-term-names-eliakim"/>Eliakim

### Facts:

Eliakim was the name of two men in the Old Testament.

* One man named Eliakim was the manager of the palace under King Hezekiah.
* Another man named Eliakim was a son of King Josiah. He was made king of Judah by the Egyptian pharaoh Necho.
* Necho changed Eliakim's name to Jehoiakim.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Hezekiah](#hezekiah), [Jehoiakim](#jehoiakim), [Josiah](#josiah), [Pharaoh](#pharaoh))

### Bible References:

* [2 Kings 18:16-18](https://git.door43.org/Door43/en_tn/src/master/2ki/18/16.md)
* [2 Kings 18:26-27](https://git.door43.org/Door43/en_tn/src/master/2ki/18/26.md)
* [2 Kings 18:36-37](https://git.door43.org/Door43/en_tn/src/master/2ki/18/36.md)
* [2 Kings 23:34-35](https://git.door43.org/Door43/en_tn/src/master/2ki/23/34.md)

### Word Data:

* Strong's: H471, G1662


## <a id="tw-term-names-elijah"/>Elijah

### Facts:

Elijah was one of the most important prophets of Yahweh. Elijah prophesied during the reigns of several kings of Israel and Judah, including King Ahab.

 * God did many miracles through Elijah, including raising a dead boy back to life.
 * Elijah rebuked King Ahab for worshiping the false god Baal.
 * He challenged the prophets of Baal to a test that proved that Yahweh is the only true God.
 * At the end of Elijah's life, God miraculously took him up to heaven while he was still alive.
 * Hundreds of years later, Elijah, along with Moses, appeared with Jesus on a mountain, and they talked together about Jesus' coming suffering and death in Jerusalem.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [miracle](kt.html#miracle), [prophet](kt.html#prophet), [Yahweh](kt.html#yahweh))

### Bible References:

* [1 Kings 17:1](https://git.door43.org/Door43/en_tn/src/master/1ki/17/01.md)
* [2 Kings 01:3-4](https://git.door43.org/Door43/en_tn/src/master/2ki/01/03.md)
* [James 05:16-18](https://git.door43.org/Door43/en_tn/src/master/jas/05/16.md)
* [John 01:19-21](https://git.door43.org/Door43/en_tn/src/master/jhn/01/19.md)
* [John 01:24-25](https://git.door43.org/Door43/en_tn/src/master/jhn/01/24.md)
* [Mark 09:4-6](https://git.door43.org/Door43/en_tn/src/master/mrk/09/04.md)

### Examples from the Bible stories:

  __*[19:02](https://git.door43.org/Door43/en_tn/src/master/obs/19/02.md)__ __Elijah__ was a prophet when Ahab was king over the kingdom of Israel.
  __*[19:02](https://git.door43.org/Door43/en_tn/src/master/obs/19/02.md)__ __Elijah__ said to Ahab, "There will be no rain or dew in the kingdom of Israel until I say so."
  __*[19:03](https://git.door43.org/Door43/en_tn/src/master/obs/19/03.md)__ God told __Elijah__ to go to a stream in the wilderness to hide from Ahab who wanted to kill him. Every morning and every evening, birds would bring him bread and meat.
  __*[19:04](https://git.door43.org/Door43/en_tn/src/master/obs/19/04.md)__ But they took care of __Elijah__, and God provided for them so that their flour jar and their bottle of oil never became empty.
  __*[19:05](https://git.door43.org/Door43/en_tn/src/master/obs/19/05.md)__ After three and a half years, God told __Elijah__ to return to the kingdom of Israel and speak with Ahab because he was going to send rain again.
  __*[19:07](https://git.door43.org/Door43/en_tn/src/master/obs/19/07.md)__ Then __Elijah__ said to the prophets of Baal, "Kill a bull and prepare it as a sacrifice, but do not light the fire."
  __*[19:12](https://git.door43.org/Door43/en_tn/src/master/obs/19/12.md)__ Then __Elijah__ said, "Do not let any of the prophets of Baal escape!"
  __*[36:03](https://git.door43.org/Door43/en_tn/src/master/obs/36/03.md)__ Then Moses and the prophet __Elijah__ appeared. These men had lived hundreds of years before this. They talked with Jesus about his death that would soon happen in Jerusalem.

### Word Data:

* Strong's: H452, G2243


## <a id="tw-term-names-elisha"/>Elisha

### Facts:

Elisha was a prophet in Israel during the reigns of several kings of Israel: Ahab, Ahaziah, Jehoram, Jehu, Jehoahaz, and Jehoash.

* God told the prophet Elijah to anoint Elisha as prophet.
* When Elijah was taken to heaven in a fiery chariot, Elisha became God's prophet to the kings of Israel. 
* Elisha did many miracles, including healing a man from Syria who had leprosy and raising from the dead the son of a woman from Shunem.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Elijah](#elijah), [Naaman](#naaman), [prophet](kt.html#prophet))

### Bible References:

* [1 Kings 19:15-16](https://git.door43.org/Door43/en_tn/src/master/1ki/19/15.md)
* [2 Kings 03:15-17](https://git.door43.org/Door43/en_tn/src/master/2ki/03/15.md)
* [2 Kings 05:8-10](https://git.door43.org/Door43/en_tn/src/master/2ki/05/08.md)
* [Luke 04:25-27](https://git.door43.org/Door43/en_tn/src/master/luk/04/25.md)

### Word Data:

* Strong's: H477


## <a id="tw-term-names-elizabeth"/>Elizabeth

### Facts:

Elizabeth was the mother of John the Baptist. Her husband's name was Zechariah.

 * Zechariah and Elizabeth had never been able to have children, but in their old age, God promised Zechariah that Elizabeth would bear him a son.
* God kept his promise, and soon Zechariah and Elizabeth were able to conceive, and she gave birth to a son. They named the baby John.
* Elizabeth was also a relative of Mary, Jesus' mother.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [John (the Baptist)](#johnthebaptist), [Zechariah (NT)](#zechariahnt))

### Bible References:

* [Luke 01:5-7](https://git.door43.org/Door43/en_tn/src/master/luk/01/05.md)
* [Luke 01:24-25](https://git.door43.org/Door43/en_tn/src/master/luk/01/24.md)
* [Luke 01:39-41](https://git.door43.org/Door43/en_tn/src/master/luk/01/39.md)

### Word Data:

* Strong's: G1665


## <a id="tw-term-names-engedi"/>En Gedi

### Definition:
En Gedi was the name of a city in the wilderness of Judah southeast of Jerusalem. 
 
* En Gedi was located on the western bank of the Salt Sea.
* Part of its name means "fountain," referring to a spring of water that flows down from the city into the sea.
* En Gedi was known for having beautiful vineyards and other fertile land, probably due to the continual watering by the fountain of water.
* There were strongholds in En Gedi which David fled to when he was being chased by King Saul.

(See also: [David](#david), [desert](other.html#desert), [fountain](other.html#fountain), [Judah](#judah), [rest](other.html#rest), [Salt Sea](#saltsea), [Saul (OT)](#saul), [stronghold](other.html#stronghold), [vineyard](other.html#vineyard))

### Bible References:

* [2 Chronicles 20:1-2](https://git.door43.org/Door43/en_tn/src/master/2ch/20/01.md)
* [Song of Solomon 01:12-14](https://git.door43.org/Door43/en_tn/src/master/sng/01/12.md)

### Word Data:

* Strong's: H5872


## <a id="tw-term-names-enoch"/>Enoch

### Facts:

Enoch was the name of two men in the Old Testament.

* One man named Enoch was descended from Seth. He was the great grandfather of Noah.
* This Enoch had a close relationship with God and when he was 365 years old, God took him to heaven while he was still alive.
* A different man named Enoch was a son of Cain.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Cain](#cain), [Seth](#seth))

### Bible References:

* [1 Chronicles 01:1-4](https://git.door43.org/Door43/en_tn/src/master/1ch/01/01.md)
* [Genesis 05:18-20](https://git.door43.org/Door43/en_tn/src/master/gen/05/18.md)
* [Genesis 05:21-24](https://git.door43.org/Door43/en_tn/src/master/gen/05/21.md)
* [Jude 01:14-16](https://git.door43.org/Door43/en_tn/src/master/jud/01/14.md)
* [Luke 03:36-38](https://git.door43.org/Door43/en_tn/src/master/luk/03/36.md)

### Word Data:

* Strong's: H2585, G1802


## <a id="tw-term-names-ephesus"/>Ephesus, Ephesian, Ephesians

### Facts:

Ephesus was an ancient Greek city on the west coast of what is now the present-day country of Turkey.

* During the time of the early Christians, Ephesus was the capital of Asia, which was a small Roman province at that time.
* Because of its location, this city was an important center of trade and travel.
* A well-known pagan temple for the worship of the goddess Artemis (Diana) was located in Ephesus.
* Paul lived and worked in Ephesus for more than two years and later appointed Timothy to lead the new believers there.
* The book of Ephesians in the New Testament is a letter that Paul wrote to the believers in Ephesus.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Asia](#asia), [Paul](#paul), [Timothy](#timothy))

### Bible References:

* [1 Corinthians 15:31-32](https://git.door43.org/Door43/en_tn/src/master/1co/15/31.md)
* [1 Timothy 01:3-4](https://git.door43.org/Door43/en_tn/src/master/1ti/01/03.md)
* [2 Timothy 04:11-13](https://git.door43.org/Door43/en_tn/src/master/2ti/04/11.md)
* [Acts 19:1-2](https://git.door43.org/Door43/en_tn/src/master/act/19/01.md)
* [Ephesians 01:1-2](https://git.door43.org/Door43/en_tn/src/master/eph/01/01.md)

### Word Data:

* Strong's: G2179, G2180, G2181


## <a id="tw-term-names-ephraim"/>Ephraim, Ephraimite, Ephraimites

### Facts:

Ephraim was the second son of Joseph. His descendants, the Ephraimites, formed one of the twelve tribes of Israel.

* The tribe of Ephraim was one of the ten tribes that were located in the northern part of Israel.
* Sometimes the name Ephraim is used in the Bible to refer to the whole northern kingdom of Israel. (See: [synecdoche](https://git.door43.org/Door43/en_man/src/master/translate/figs-synecdoche/01.md))
* Ephraim was apparently a very mountainous or hilly area, based on references to "the hill country of Ephraim" or "the mountains of Ephraim."

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [kingdom of Israel](#kingdomofisrael), [twelve tribes of Israel](other.html#12tribesofisrael))

### Bible References:

* [1 Chronicles 06:66-69](https://git.door43.org/Door43/en_tn/src/master/1ch/06/66.md)
* [2 Chronicles 13:4-5](https://git.door43.org/Door43/en_tn/src/master/2ch/13/04.md)
* [Ezekiel 37:15-17](https://git.door43.org/Door43/en_tn/src/master/ezk/37/15.md)
* [Genesis 41:50-52](https://git.door43.org/Door43/en_tn/src/master/gen/41/50.md)
* [Genesis 48:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/48/01.md)
* [John 11:54-55](https://git.door43.org/Door43/en_tn/src/master/jhn/11/54.md)

### Word Data:

* Strong's: H669, H673, G2187


## <a id="tw-term-names-ephrathah"/>Ephrath, Ephrathah, Ephrathite, Ephrathites

### Facts:

Ephrathah was the name of a city and region in the northern part of Israel. The city of Ephrathah was later called "Bethlehem" or "Ephrathah-Bethlehem."

* Ephrathah was the name of one of Caleb's sons. The city of Ephrathah was probably named after him.
* A person who was from the city of Ephrathah was called an "Ephrathite."
* Boaz, the great-grandfather of David, was an Ephrathite.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Bethlehem](#bethlehem), [Boaz](#boaz), [Caleb](#caleb), [David](#david), [Israel](kt.html#israel))

### Bible References:

### Word Data:

* Strong's: H672, H673


## <a id="tw-term-names-esau"/>Esau

### Facts:

Esau was one of the twin sons of Isaac and Rebekah. He was the first baby born to them. His twin brother was Jacob.

 * Esau sold his birthright to his brother Jacob in exchange for a bowl of food.
 * Since Esau was born first, his father Isaac was supposed to give him a special blessing. But Jacob tricked Isaac into giving him that blessing instead. At first Esau was so angry that he wanted to kill Jacob, but later he forgave him.
 * Esau had many children and grandchildren, and these descendants formed a large people group living in the land of Canaan.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Edom](#edom), [Isaac](#isaac), [Jacob](#jacob), [Rebekah](#rebekah))

### Bible References:

* [Genesis 25:24-26](https://git.door43.org/Door43/en_tn/src/master/gen/25/24.md)
* [Genesis 25:29-30](https://git.door43.org/Door43/en_tn/src/master/gen/25/29.md)
* [Genesis 26:34-35](https://git.door43.org/Door43/en_tn/src/master/gen/26/34.md)
* [Genesis 27:11-12](https://git.door43.org/Door43/en_tn/src/master/gen/27/11.md)
* [Genesis 32:3-5](https://git.door43.org/Door43/en_tn/src/master/gen/32/03.md)
* [Hebrews 12:14-17](https://git.door43.org/Door43/en_tn/src/master/heb/12/14.md)
* [Romans 09:10-13](https://git.door43.org/Door43/en_tn/src/master/rom/09/10.md)

### Examples from the Bible stories:

  __*[06:07](https://git.door43.org/Door43/en_tn/src/master/obs/06/07.md)__ When Rebekah's babies were born, the older son came out red and hairy, and they named him __Esau__.
  __*[07:02](https://git.door43.org/Door43/en_tn/src/master/obs/07/02.md)__ So __Esau __ gave Jacob his rights as the oldest son.
  __*[07:04](https://git.door43.org/Door43/en_tn/src/master/obs/07/04.md)__ When Isaac felt the goat hair and smelled the clothes, he thought it was __Esau__ and blessed him.
  __*[07:05](https://git.door43.org/Door43/en_tn/src/master/obs/07/05.md)__ __Esau__ hated Jacob because Jacob had stolen his rights as oldest son and also his blessing.
  __*[07:10](https://git.door43.org/Door43/en_tn/src/master/obs/07/10.md)__ But __Esau __ had already forgiven Jacob, and they were happy to see each other again.

### Word Data:

* Strong's: H6215, G2269


## <a id="tw-term-names-esther"/>Esther

### Facts:

Esther was a Jewish woman who became queen of the Persian kingdom during the time of the Babylonian captivity of the Jews.

* The book of Esther tells the story of how Esther became the wife of the Persian King Ahasuerus and how God used her to save her people.
* Esther was an orphan who was raised by her godly older cousin, Mordecai.
* Her obedience to her adoptive father helped her to be obedient to God.
* Esther obeyed God and risked her life in order to save her people, the Jews.
* The story of Esther illustrates God's sovereign control over the events of history, especially how he protects his people and works through those who obey him.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Ahasuerus](#ahasuerus), [Babylon](#babylon), [Mordecai](#mordecai), [Persia](#persia))

### Bible References:

* [Esther 02:7](https://git.door43.org/Door43/en_tn/src/master/est/02/07.md)
* [Esther 02:15-16](https://git.door43.org/Door43/en_tn/src/master/est/02/15.md)
* [Esther 07:1-2](https://git.door43.org/Door43/en_tn/src/master/est/07/01.md)
* [Esther 08:1-2](https://git.door43.org/Door43/en_tn/src/master/est/08/01.md)

### Word Data:

* Strong's: H635


## <a id="tw-term-names-ethiopia"/>Ethiopia, Ethiopian

### Facts:

Ethiopia is a country in Africa located just south of Egypt, bordered by the Nile River to the west and by the Red Sea to the east. A person from Ethiopia is an "Ethiopian."

* Ancient Ethiopia was located south of Egypt and included land that is now part of several modern-day African countries, such as Sudan, modern Ethiopia, Somalia, Kenya, Uganda, Central African Republic, and Chad. 
* In the Bible, Ethiopia is sometimes called "Cush" or "Nubia."
* The countries of Ethiopia ("Cush") and Egypt are often mentioned together in the Bible, perhaps because they were located next to each other and their people may have had some of the same ancestors.
* God sent Philip the evangelist to a desert where he shared the good news about Jesus with an Ethiopian eunuch.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Cush](#cush), [Egypt](#egypt), [eunuch](kt.html#eunuch), [Philip](#philip))

### Bible References:

* [Acts 08:26-28](https://git.door43.org/Door43/en_tn/src/master/act/08/26.md)
* [Acts 08:29-31](https://git.door43.org/Door43/en_tn/src/master/act/08/29.md)
* [Acts 08:32-33](https://git.door43.org/Door43/en_tn/src/master/act/08/32.md)
* [Acts 08:36-38](https://git.door43.org/Door43/en_tn/src/master/act/08/36.md)
* [Isaiah 18:1-2](https://git.door43.org/Door43/en_tn/src/master/isa/18/01.md)
* [Nahum 03:8-9](https://git.door43.org/Door43/en_tn/src/master/nam/03/08.md)
* [Zephaniah 03:9-11](https://git.door43.org/Door43/en_tn/src/master/zep/03/09.md)

### Word Data:

* Strong's: H3568, H3569, H3571, G128


## <a id="tw-term-names-euphrates"/>Euphrates River, the River

### Facts:

The Euphrates is the name of one of the four rivers that flowed through the Garden of Eden. It is the river that is most often mentioned in the Bible.

* The modern day river named Euphrates is located in the Middle East and is the longest and most important river in Asia.
* Together with the Tigris River, the Euphrates borders a region of land known as Mesopotamia.
* The ancient city of Ur where Abraham came from was at the mouth of the Euphrates River.
* This river was one of the boundaries of the land that God promised to give to Abraham (Genesis 15:18).
* Sometimes the Euphrates is simply called "the River."

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

### Bible References:

* [1 Chronicles 05:7-9](https://git.door43.org/Door43/en_tn/src/master/1ch/05/07.md)
* [2 Chronicles 09:25-26](https://git.door43.org/Door43/en_tn/src/master/2ch/09/25.md)
* [Exodus 23:30-33](https://git.door43.org/Door43/en_tn/src/master/exo/23/30.md)
* [Genesis 02:13-14](https://git.door43.org/Door43/en_tn/src/master/gen/02/13.md)
* [Isaiah 07:20-22](https://git.door43.org/Door43/en_tn/src/master/isa/07/20.md)

### Word Data:

* Strong's: H5104, H6578, G2166


## <a id="tw-term-names-eve"/>Eve

### Facts:

This was the name of the first woman. Her name means "life" or "living."

 * God formed Eve from a rib that he took out of Adam.
 * Eve was created to be Adam's "helper." She came alongside Adam to assist him in the work that God gave them to do.
 * Eve was tempted by Satan (in the form of a snake) and was the first to sin by eating the fruit that God said not to eat.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Adam](#adam), [life](kt.html#life), [Satan](kt.html#satan))

### Bible References:

* [1 Timothy 02:13-15](https://git.door43.org/Door43/en_tn/src/master/1ti/02/13.md)
* [2 Corinthians 11:3-4](https://git.door43.org/Door43/en_tn/src/master/2co/11/03.md)
* [Genesis 03:20-21](https://git.door43.org/Door43/en_tn/src/master/gen/03/20.md)
* [Genesis 04:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/04/01.md)

### Examples from the Bible stories:

 * __[01:13](https://git.door43.org/Door43/en_tn/src/master/obs/01/13.md)__ Then God took one of Adam's ribs and made it into a woman and brought her to him.
 * __[02:02](https://git.door43.org/Door43/en_tn/src/master/obs/02/02.md)__ But there was a crafty snake in the garden. He asked the woman, "Did God really tell you not to eat the fruit from any of the trees in the garden?"
 * __[02:11](https://git.door43.org/Door43/en_tn/src/master/obs/02/11.md)__ The man named his wife __Eve__, which means "life-giver," because she would become the mother of all people.
 * __[21:01](https://git.door43.org/Door43/en_tn/src/master/obs/21/01.md)__ God promised that a descendant of __Eve__  would be born who would crush the snake's head.
 * __[48:02](https://git.door43.org/Door43/en_tn/src/master/obs/48/02.md)__ Satan spoke through the snake in the garden in order to deceive __Eve__. 
 * __[49:08](https://git.door43.org/Door43/en_tn/src/master/obs/49/08.md)__ When Adam and __Eve__ sinned, it affected all of their descendants.
 * __[50:16](https://git.door43.org/Door43/en_tn/src/master/obs/50/16.md)__ Because Adam and __Eve__ disobeyed God and brought sin into this world, God cursed it and decided to destroy it.

### Word Data:

* Strong's: H2332, G2096


## <a id="tw-term-names-ezekiel"/>Ezekiel

### Facts:

Ezekiel was a prophet of God during the exile period when many Jews were taken to Babylon.

* Ezekiel was a priest living in the kingdom of Judah when he and many other Jews were captured by the Babylonian army.
* For over twenty years, he and his wife lived in Babylon near a river, and the Jews came there to hear him speak messages from God.
* Among other things, Ezekiel prophesied about the destruction and restoration of Jerusalem and the temple.
* He also prophesied about the future kingdom of the Messiah.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Babylon](#babylon), [Christ](kt.html#christ), [exile](other.html#exile), [prophet](kt.html#prophet))

### Bible References:

* [Ezekiel 01:1-3](https://git.door43.org/Door43/en_tn/src/master/ezk/01/01.md)
* [Ezekiel 24:22-24](https://git.door43.org/Door43/en_tn/src/master/ezk/24/22.md)

### Word Data:

* Strong's: H3168


## <a id="tw-term-names-ezra"/>Ezra

### Facts:

Ezra was an Israelite priest and expert in Jewish law who recorded the history of the Israelites' return to Jerusalem from Babylon where Israel had been held captive for 70 years.

* Ezra recorded this part of Israel's history in the biblical book of Ezra. He may also have written the book of Nehemiah, since these two books had originally been one single book.
* When Ezra returned to Jerusalem he re-established the Law, since the Israelites had stopped obeying the Sabbath laws and had intermarried with women who practiced pagan religions.
* Ezra also helped rebuild the temple, which had been destroyed by the Babylonians when they captured Jerusalem.
* There are two other men named Ezra mentioned in the Old Testament.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Babylon](#babylon), [exile](other.html#exile), [Jerusalem](#jerusalem), [law](kt.html#lawofmoses), [Nehemiah](#nehemiah), [temple](kt.html#temple))

### Bible References:

* [Ezra 07:6-7](https://git.door43.org/Door43/en_tn/src/master/ezr/07/06.md)
* [Nehemiah 08:1-3](https://git.door43.org/Door43/en_tn/src/master/neh/08/01.md)
* [Nehemiah 12:1-3](https://git.door43.org/Door43/en_tn/src/master/neh/12/01.md)

### Word Data:

* Strong's: H250, H5830, H5831, H5834


## <a id="tw-term-names-gabriel"/>Gabriel

### Facts:

Gabriel is the name of one of God's angels. He is mentioned by name several times, in both the Old and New Testaments.

 * God sent Gabriel to tell the prophet Daniel the meaning of a vision he had seen.
 * Another time, while Daniel was praying, the angel Gabriel flew to him and prophesied about what would happen in the future. Daniel described him as a "man."
 * In the New Testament it is recorded that Gabriel came to Zechariah to prophesy that his aged wife Elizabeth would have a son, John.
 * Sixth months after that, Gabriel was sent to Mary to tell her that God would miraculously enable her to conceive a child who would be the "Son of God." Gabriel told Mary to name her son "Jesus."
	
(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [angel](kt.html#angel), [Daniel](#daniel), [Elizabeth](#elizabeth), [John (the Baptist)](#johnthebaptist), [Mary](#mary), [prophet](kt.html#prophet), [Son of God](kt.html#sonofgod), [Zechariah (NT)](#zechariahnt))

### Bible References:

* [Daniel 08:15-17](https://git.door43.org/Door43/en_tn/src/master/dan/08/15.md)
* [Daniel 09:20-21](https://git.door43.org/Door43/en_tn/src/master/dan/09/20.md)
* [Luke 01:18-20](https://git.door43.org/Door43/en_tn/src/master/luk/01/18.md)
* [Luke 01:26-29](https://git.door43.org/Door43/en_tn/src/master/luk/01/26.md)

### Word Data:

* Strong's:  H1403, G1043


## <a id="tw-term-names-gad"/>Gad

### Facts:

Gad was one of the sons of Jacob. Jacob was also named Isreal.

 * Gad's family became one of the twelve tribes of Israel.
 * Another man in the Bible named Gad was a prophet who confronted King David for his sin of taking a census of the Israelite people.
 * The names of the cities Baalgad and Migdalgad are each two words in the original text and are sometimes written "Baal Gad" and "Migdal Gad."

(Translation suggestions:[How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [census](other.html#census), [prophet](kt.html#prophet), [twelve tribes of Israel](other.html#12tribesofisrael))

### Bible References:

* [1 Chronicles 05:18-19](https://git.door43.org/Door43/en_tn/src/master/1ch/05/18.md)
* [Exodus 01:1-5](https://git.door43.org/Door43/en_tn/src/master/exo/01/01.md)
* [Genesis 30:9-11](https://git.door43.org/Door43/en_tn/src/master/gen/30/09.md)
* [Joshua 01:12-13](https://git.door43.org/Door43/en_tn/src/master/jos/01/12.md)
* [Joshua 21:36-38](https://git.door43.org/Door43/en_tn/src/master/jos/21/36.md)

### Word Data:

* Strong's: H1410, H1425, G1045


## <a id="tw-term-names-galatia"/>Galatia, Galatians

### Facts:

In New Testament times, Galatia was a large Roman province located in the central part of what is now the country of Turkey.

* Part of Galatia bordered the Black Sea, which was to the north. It was also bordered by the provinces of Asia, Bithynia, Cappadocia, Celicia, and Pamphylia.
* The apostle Paul wrote a letter to the Christians who lived in the province of Galatia. This letter is the New Testament book called "Galatians."
* One reason that Paul wrote his letter to the Galatians was to emphasize again the gospel of salvation by grace, not by works.
* The Jewish Christians there were incorrectly teaching the Gentile Christians there that it was necessary for believers to keep certain Jewish laws.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Asia](#asia), [believe](kt.html#believe), [Cilicia](#cilicia), [good news](kt.html#goodnews), [Paul](#paul), [works](kt.html#works))

### Bible References:

* [1 Corinthians 16:1-2](https://git.door43.org/Door43/en_tn/src/master/1co/16/01.md)
* [1 Peter 01:1-2](https://git.door43.org/Door43/en_tn/src/master/1pe/01/01.md)
* [2 Timothy 04:9-10](https://git.door43.org/Door43/en_tn/src/master/2ti/04/09.md)
* [Acts 16:6-8](https://git.door43.org/Door43/en_tn/src/master/act/16/06.md)
* [Galatians 01:1-2](https://git.door43.org/Door43/en_tn/src/master/gal/01/01.md)

### Word Data:

* Strong's: G1053, G1054


## <a id="tw-term-names-galilee"/>Galilee, Galilean, Galileans

### Facts:

Galilee was the most northern region of Israel, just north of Samaria. A "Galilean" was a person who lived in Galilee or who lived in Galilee.

* Galilee, Samaria, and Judea were the three main provinces of Israel during New Testament times.
* Galilee is bordered on the east by a large lake called the "Sea of Galilee."
* Jesus grew up and lived in the town of Nazareth in Galilee.
* Most of the miracles and teachings of Jesus took place in the region of Galilee.

(See also: [Nazareth](#nazareth), [Samaria](#samaria), [Sea of Galilee](#seaofgalilee))

### Bible References:

* [Acts 09:31-32](https://git.door43.org/Door43/en_tn/src/master/act/09/31.md)
* [Acts 13:30-31](https://git.door43.org/Door43/en_tn/src/master/act/13/30.md)
* [John 02:1-2](https://git.door43.org/Door43/en_tn/src/master/jhn/02/01.md)
* [John 04:1-3](https://git.door43.org/Door43/en_tn/src/master/jhn/04/01.md)
* [Luke 13:1-3](https://git.door43.org/Door43/en_tn/src/master/luk/13/01.md)
* [Mark 03:7-8](https://git.door43.org/Door43/en_tn/src/master/mrk/03/07.md)
* [Matthew 02:22-23](https://git.door43.org/Door43/en_tn/src/master/mat/02/22.md)
* [Matthew 03:13-15](https://git.door43.org/Door43/en_tn/src/master/mat/03/13.md)

### Examples from the Bible stories:

* __[21:10](https://git.door43.org/Door43/en_tn/src/master/obs/21/10.md)__ The prophet Isaiah said the Messiah would live in __Galilee__, comfort broken-hearted people, and proclaim freedom to captives and release to prisoners.
* __[26:01](https://git.door43.org/Door43/en_tn/src/master/obs/26/01.md)__ After overcoming Satan's temptations, Jesus returned in the power of the Holy Spirit to the region of __Galilee__  where he lived.
* __[39:06](https://git.door43.org/Door43/en_tn/src/master/obs/39/06.md)__ Finally, the people said, "We know that you were with Jesus because you both are from __Galilee__."
* __[41:06](https://git.door43.org/Door43/en_tn/src/master/obs/41/06.md)__ Then the angel told the women, "Go and tell the disciples, 'Jesus has risen from the dead and he will go to __Galilee__  ahead of you.'"

### Word Data:

* Strong's: H1551, G1056, G1057


## <a id="tw-term-names-gath"/>Gath, Gittite, Gittites

### Facts:

Gath was one of the five major cities of the Philistines. It was located north of Ekron and east of Ashdod and Ashkelon.

* The Philistine warrior Goliath was from the city of Gath.
* During the time of Samuel, the Philistines stole the ark of the covenant from Israel and took it to their pagan temple at Ashdod. It was then moved to Gath and later to Ekron. But God punished the people of those cities with disease, so they sent it back to Israel again.
* When David was escaping from King Saul, he fled to Gath and lived there awhile with his two wives and with six hundred men who were his loyal followers.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Ashdod](#ashdod), [Ashkelon](#ashkelon), [Ekron](#ekron), [Gaza](#gaza), [Goliath](#goliath), [Philistines](#philistines))

### Bible References:

* [1 Kings 02:39-40](https://git.door43.org/Door43/en_tn/src/master/1ki/02/39.md)
* [1 Samuel 05:8-9](https://git.door43.org/Door43/en_tn/src/master/1sa/05/08.md)
* [2 Chronicles 26:6-8](https://git.door43.org/Door43/en_tn/src/master/2ch/26/06.md)
* [Joshua 11:21-22](https://git.door43.org/Door43/en_tn/src/master/jos/11/21.md)

### Word Data:

* Strong's: H1661, H1663


## <a id="tw-term-names-gaza"/>Gaza

### Facts:

During Bible times, Gaza was a prosperous Philistine city located on the coast of the Mediterranean Sea, about 38 kilometers south of Ashdod. It was one of the Philistines' five major cities.

* Because of its location, Gaza was a key seaport where commercial activities took place between many different people groups and nations.
* Today, the city of Gaza is still an important seaport in the Gaza Strip, which is a region of land located along the coast of the Mediterranean Sea bordered by Israel on the north and east, and by Egypt on the south.
* Gaza was the city that the Philistines took Samson to after they had captured him.
* Philip the evangelist was walking along the desert road to Gaza when he met an Ethiopian eunuch.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Ashdod](#ashdod), [Philip](#philip), [Philistines](#philistines), [Ethiopia](#ethiopia), [Gath](#gath))

### Bible References:

* [1 Kings 04:24-25](https://git.door43.org/Door43/en_tn/src/master/1ki/04/24.md)
* [Acts 08:26-28](https://git.door43.org/Door43/en_tn/src/master/act/08/26.md)
* [Genesis 10:19-20](https://git.door43.org/Door43/en_tn/src/master/gen/10/19.md)
* [Joshua 10:40-41](https://git.door43.org/Door43/en_tn/src/master/jos/10/40.md)
* [Judges 06:3-4](https://git.door43.org/Door43/en_tn/src/master/jdg/06/03.md)

### Word Data:

* Strong's: H5804, H5841, G1048


## <a id="tw-term-names-gerar"/>Gerar

### Facts:

​Gerar was a city and region in the land of Canaan, located southwest of Hebron and northwest of Beersheba.

* King Abimelech was the ruler of Gerar when Abraham and Sarah settled there.
* The Philistines dominated the region of Gerar during the time that the Israelites were living in Canaan.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Abimelech](#abimelech), [Beersheba](#beersheba), [Hebron](#hebron), [Philistines](#philistines))

### Bible References:

* [2 Chronicles 14:12-13](https://git.door43.org/Door43/en_tn/src/master/2ch/14/12.md)
* [Genesis 20:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/20/01.md)
* [Genesis 26:1](https://git.door43.org/Door43/en_tn/src/master/gen/26/01.md)
* [Genesis 26:6-8](https://git.door43.org/Door43/en_tn/src/master/gen/26/06.md)

### Word Data:

* Strong's: H1642


## <a id="tw-term-names-geshur"/>Geshur, Geshurites

### Definition:

During the time of King David, Geshur was a small kingdom located on the east side of the Sea of Galilee between the countries of Israel and Aram.

* King David married Maacah, the daughter of Geshur's king, and she bore him a son, Absalom.
* After murdering his half-brother Amnon, Absalom fled northeast from Jerusalem to Geshur, a distance of about 140 kilometers. He stayed there three years.

(See also: [Absalom](#absalom), [Amnon](#amnon), [Aram](#aram), [Sea of Galilee](#seaofgalilee))

### Bible References:

* [1 Chronicles 02:23-24](https://git.door43.org/Door43/en_tn/src/master/1ch/02/23.md)
* [2 Samuel 03:2-3](https://git.door43.org/Door43/en_tn/src/master/2sa/03/02.md)
* [Deuteronomy 03:14](https://git.door43.org/Door43/en_tn/src/master/deu/03/14.md)
* [Joshua 12:3-5](https://git.door43.org/Door43/en_tn/src/master/jos/12/03.md)

### Word Data:

* Strong's: H1650


## <a id="tw-term-names-gethsemane"/>Gethsemane

### Facts:

Gethsemane was a garden of olive trees east of Jerusalem beyond the Kidron valley and near the Mount of Olives.

* The garden of Gethsemane was a place where Jesus and his followers would go to be alone and rest, away from the crowds.
* It was in Gethsemane that Jesus prayed in deep sorrow, before being arrested there by Jewish leaders.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Judas Iscariot](#judasiscariot), [Kidron Valley](#kidronvalley), [Mount of Olives](#mountofolives))

### Bible References:

* [Mark 14:32-34](https://git.door43.org/Door43/en_tn/src/master/mrk/14/32.md)
* [Matthew 26:36-38](https://git.door43.org/Door43/en_tn/src/master/mat/26/36.md)

### Word Data:

* Strong's: G1068


## <a id="tw-term-names-gibeah"/>Gibeah

### Facts:

Gibeah was a city located north of Jerusalem and south of Bethel.

* Gibeah was in the territory of the tribe of Benjamin.
* It was the site of a huge battle between the Benjamites and Israel.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Benjamin](#benjamin), [Bethel](#bethel), [Jerusalem](#jerusalem))

### Bible References:

* [1 Samuel 10:26-27](https://git.door43.org/Door43/en_tn/src/master/1sa/10/26.md)
* [2 Samuel 21:5-6](https://git.door43.org/Door43/en_tn/src/master/2sa/21/05.md)
* [Hosea 09:8-9](https://git.door43.org/Door43/en_tn/src/master/hos/09/08.md)
* [Judges 19:12-13](https://git.door43.org/Door43/en_tn/src/master/jdg/19/12.md)

### Word Data:

* Strong's: H1387, H1389, H1390, H1394


## <a id="tw-term-names-gibeon"/>Gibeon, Gibeonite, Gibeonites

### Facts:

Gibeon was a city that was located about 13 kilometers northwest of Jerusalem. The people living in Gibeon were the Gibeonites.

* When the Gibeonites heard about how the Israelites had destroyed the cities of Jericho and Ai, they were afraid.
* So the Gibeonites came to the leaders of Israel at Gilgal and pretended to be people from a far-away country. 
* The Israelite leaders were deceived and made an agreement with the Gibeonites that they would protect them and not destroy them.

(See also: [Gilgal](#gilgal), [Jericho](#jericho), [Jerusalem](#jerusalem))

### Bible References:

* [1 Chronicles 08:29-31](https://git.door43.org/Door43/en_tn/src/master/1ch/08/29.md)
* [1 Kings 03:4-5](https://git.door43.org/Door43/en_tn/src/master/1ki/03/04.md)
* [2 Samuel 02:12-13](https://git.door43.org/Door43/en_tn/src/master/2sa/02/12.md)
* [Joshua 09:3-5](https://git.door43.org/Door43/en_tn/src/master/jos/09/03.md)

### Examples from the Bible stories:

  __*[15:06](https://git.door43.org/Door43/en_tn/src/master/obs/15/06.md)__ But one of the Canaanite people groups, called the __Gibeonites__, lied to Joshua and said they were from a place far from Canaan.  
  __*[15:07](https://git.door43.org/Door43/en_tn/src/master/obs/15/07.md)__ Sometime later, the kings of another people group in Canaan, the Amorites, heard that the __Gibeonites__ had made a peace treaty with the Israelites, so they combined their armies into one large army and attacked __Gibeon__.  
  __*[15:08](https://git.door43.org/Door43/en_tn/src/master/obs/15/08.md)__ So Joshua gathered the Israelite army and they marched all night to reach the __Gibeonites__.

### Word Data:

* Strong's: H1391, H1393


## <a id="tw-term-names-gideon"/>Gideon

### Facts:

Gideon was an Israelite man whom God raised up to deliver the Israelites from their enemies.

* During the time when Gideon lived, a people group called the Midianites kept attacking the Israelites and destroying their crops.
* Even though Gideon was afraid, God used him to lead the Israelites to fight against the Midianites and defeat them.
* Gideon also obeyed God by taking down altars to the false gods Baal and Asherah.
* He not only led the people in defeating their enemies but also encouraged them to obey and worship Yahweh, the one true God.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Baal](#baal), [Asherah](#asherim), [deliver](other.html#deliverer), [Midian](#midian), [Yahweh](kt.html#yahweh)) 

### Bible References:

* [Hebrews 11:32-34](https://git.door43.org/Door43/en_tn/src/master/heb/11/32.md)
* [Judges 06:11-12](https://git.door43.org/Door43/en_tn/src/master/jdg/06/11.md)
* [Judges 06:22-24](https://git.door43.org/Door43/en_tn/src/master/jdg/06/22.md)
* [Judges 08:15-17](https://git.door43.org/Door43/en_tn/src/master/jdg/08/15.md)

### Examples from the Bible stories:

* __[16:05](https://git.door43.org/Door43/en_tn/src/master/obs/16/05.md)__ The angel of Yahweh came to __Gideon__  and said, "God is with you, mighty warrior. Go and save Israel from the Midianites."
* __[16:06](https://git.door43.org/Door43/en_tn/src/master/obs/16/06.md)__ __Gideon's__  father had an altar dedicated to an idol. God told __Gideon__  to tear down that altar.
* __[16:08](https://git.door43.org/Door43/en_tn/src/master/obs/16/08.md)__ There were so many of them (Midianites) that they could not be counted. __Gideon__  called the Israelites together to fight them.
* __[16:08](https://git.door43.org/Door43/en_tn/src/master/obs/16/08.md)__ __Gideon__  called the Israelites together to fight them. __Gideon__  asked God for two signs so he could be sure that God would use him to save Israel.
* __[16:10](https://git.door43.org/Door43/en_tn/src/master/obs/16/10.md)__ 32,000 Israelite soldiers came to __Gideon__, but God told him this was too many.
* __[16:12](https://git.door43.org/Door43/en_tn/src/master/obs/16/12.md)__ Then __Gideon__  returned to his soldiers and gave each of them a horn, a clay pot, and a torch.
* __[16:15](https://git.door43.org/Door43/en_tn/src/master/obs/16/15.md)__ The people wanted to make __Gideon__  their king.
* __[16:16](https://git.door43.org/Door43/en_tn/src/master/obs/16/16.md)__ Then __Gideon__  used the gold to make a special garment like the high priest used to wear. But the people started worshiping it as if it were an idol.

### Word Data:

* Strong's: H1439, H1441


## <a id="tw-term-names-gilead"/>Gilead, Gileadite, Gileadites

### Definition:

Gilead was the name of a mountainous region east of the Jordan river where the Israelite tribes of Gad, Reuben, and Manasseh lived.

 * This region was also referred to as the "hill country of Gilead" or "Mount Gilead." 
 * "Gilead" was also the name of several men in the Old Testament. One of these men was the grandson of Manasseh. Another Gilead was the father of Jephthah.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Gad](#gad), [Jephthah](#jephthah), [Manasseh](#manasseh), [Reuben](#reuben), [twelve tribes of Israel](other.html#12tribesofisrael))

### Bible References:

* [1 Chronicles 02:21-22](https://git.door43.org/Door43/en_tn/src/master/1ch/02/21.md)
* [1 Samuel 11:1-2](https://git.door43.org/Door43/en_tn/src/master/1sa/11/01.md)
* [Amos 01:3-4](https://git.door43.org/Door43/en_tn/src/master/amo/01/03.md)
* [Deuteronomy 02:36-37](https://git.door43.org/Door43/en_tn/src/master/deu/02/36.md)
* [Genesis 31:19-21](https://git.door43.org/Door43/en_tn/src/master/gen/31/19.md)
* [Genesis 37:25-26](https://git.door43.org/Door43/en_tn/src/master/gen/37/25.md)

### Word Data:

* Strong's: H1568, H1569


## <a id="tw-term-names-gilgal"/>Gilgal

### Facts:

Gilgal was a town north of Jericho and was the first place that the Israelites camped after crossing the Jordan River to enter Canaan.

* At Gilgal, Joshua set up twelve stones taken from the dry river bed of the Jordan River that they had just crossed over.
* Gilgal was the city that Elijah and Elisha were leaving as they crossed the Jordan when Elijah was taken up to heaven.
* There were also several other places called "Gilgal" in the Old Testament.
* The word "gilgal" means "circle of stones," perhaps referring to a place where a circular altar was built.
* In the Old Testament, this name almost always occurs as "the gilgal." This may indicate that it was not a specific place name but rather was a description of a certain kind of place.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Elijah](#elijah), , [Elisha](#elisha), [Jericho](#jericho), [Jordan River](#jordanriver))

### Bible References:

* [1 Samuel 07:15-17](https://git.door43.org/Door43/en_tn/src/master/1sa/07/15.md)
* [2 Kings 02:1-2](https://git.door43.org/Door43/en_tn/src/master/2ki/02/01.md)
* [Hosea 04:15-16](https://git.door43.org/Door43/en_tn/src/master/hos/04/15.md)
* [Judges 02:1-2](https://git.door43.org/Door43/en_tn/src/master/jdg/02/01.md)

### Word Data:

* Strong's: H1537


## <a id="tw-term-names-girgashites"/>Girgashites

### Facts:

The Girgashites were a people group living near the Sea of Galilee in the land of Canaan. 

* They were descendants of Ham's son Canaan and so were one of the many people groups who were also known as "Canaanites."
* God promised the Israelites that he would help them defeat the Girgashites and other Canaanite people groups.
* Like all the Canaanite peoples, the Girgashites worshiped false gods and did immoral things as part of that worship.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Canaan](#canaan) , [Ham](#ham), [Noah](#noah))

### Bible References:

* [1 Chronicles 01:13-16](https://git.door43.org/Door43/en_tn/src/master/1ch/01/13.md)
* [Deuteronomy 07:1](https://git.door43.org/Door43/en_tn/src/master/deu/07/01.md)
* [Genesis 10:15-18](https://git.door43.org/Door43/en_tn/src/master/gen/10/15.md)
* [Joshua 03:9-11](https://git.door43.org/Door43/en_tn/src/master/jos/03/09.md)
* [Joshua 24:11-12](https://git.door43.org/Door43/en_tn/src/master/jos/24/11.md)

### Word Data:

* Strong's: H1622

## <a id="tw-term-names-golgotha"/>Golgotha

### Facts:

 "Golgotha" was the name of the place where Jesus was crucified. Its name comes from an Aramaic word that means "Skull" or "Place of the Skull."

* Golgotha was located outside the city walls of Jerusalem, somewhere nearby. It was perhaps located on a slope of the Mount of Olives.
* In some older English versions of the Bible, Golgotha is translated as "Calvary," which comes from the Latin word for "skull." 
* Many Bible versions use a word that looks or sounds similar to "Golgotha," since its meaning is already explained in the Bible text. 

(Translation Suggestion: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Aram](#aram), [Mount of Olives](#mountofolives))

### Bible References:

* [John 19:17-18](https://git.door43.org/Door43/en_tn/src/master/jhn/19/17.md)
* [Mark 15:22-24](https://git.door43.org/Door43/en_tn/src/master/mrk/15/22.md)
* [Matthew 27:32-34](https://git.door43.org/Door43/en_tn/src/master/mat/27/32.md)

### Word Data:

* Strong's: G1115


## <a id="tw-term-names-goliath"/>Goliath

### Facts:

Goliath was a very tall and very large soldier in the army of the Philistines who was killed by David.

* Goliath was between two and three meters tall. He is often referred to as a giant because of his great size.
* Although Goliath had better weapons and was much bigger than David, God gave David the strength and ability to defeat Goliath.
* The Israelites were declared victorious over the Philistines as a result of David's victory over Goliath.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [David](#david), [Philistines](#philistines))

### Bible References:

* [1 Chronicles 20:4-5](https://git.door43.org/Door43/en_tn/src/master/1ch/20/04.md)
* [1 Samuel 17:4-5](https://git.door43.org/Door43/en_tn/src/master/1sa/17/04.md)
* [1 Samuel 21:8-9](https://git.door43.org/Door43/en_tn/src/master/1sa/21/08.md)
* [1 Samuel 22:9-10](https://git.door43.org/Door43/en_tn/src/master/1sa/22/09.md)

### Word Data:

* Strong's: H1555


## <a id="tw-term-names-gomorrah"/>Gomorrah

### Facts:

Gomorrah was a city located in a fertile valley near Sodom, where Abraham's nephew Lot chose to live.

* The exact location of Gomorrah and Sodom is unknown, but there are indications that they may have been located directly south of the Salt Sea, near the Valley of Siddim.
* There were many kings at war in the region where Sodom and Gomorrah were located.
* When Lot's family was captured in a conflict between Sodom and other cities, Abraham and his men rescued them.
* Not long after that, Sodom and Gomorrah were destroyed by God because of the wickedness of the people who lived there.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Abraham](#abraham) , [Babylon](#babylon), [Lot](#lot), [Salt Sea](#saltsea), [Sodom](#sodom))

### Bible References:

* [2 Peter 02:4-6](https://git.door43.org/Door43/en_tn/src/master/2pe/02/04.md)
* [Genesis 10:19-20](https://git.door43.org/Door43/en_tn/src/master/gen/10/19.md)
* [Genesis 14:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/14/01.md)
* [Genesis 18:20-21](https://git.door43.org/Door43/en_tn/src/master/gen/18/20.md)
* [Isaiah 01:9](https://git.door43.org/Door43/en_tn/src/master/isa/01/09.md)
* [Matthew 10:14-15](https://git.door43.org/Door43/en_tn/src/master/mat/10/14.md)

### Word Data:

* Strong's: H6017


## <a id="tw-term-names-goshen"/>Goshen

### Definition:

Goshen was the name of a fertile region of land located along the Nile River in the northern part of Egypt.

 * When Joseph was a ruler in Egypt, his father and brothers and their families came to live in Goshen to escape a famine in Canaan.
 * They and their descendants lived well in Goshen for over 400 years, but then they were forced into slavery by the Egyptian pharaoh.
 * Finally God sent Moses to help the people of Israel leave the land of Goshen and escape this slavery.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Egypt](#egypt), [famine](other.html#famine), [Moses](#moses), [Nile River](#nileriver))

### Bible References:

* [Exodus 08:22-24](https://git.door43.org/Door43/en_tn/src/master/exo/08/22.md)
* [Genesis 45:9-11](https://git.door43.org/Door43/en_tn/src/master/gen/45/09.md)
* [Genesis 47:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/47/01.md)
* [Genesis 50:7-9](https://git.door43.org/Door43/en_tn/src/master/gen/50/07.md)
* [Joshua 10:40-41](https://git.door43.org/Door43/en_tn/src/master/jos/10/40.md)

### Word Data:

* Strong's: H1657


## <a id="tw-term-names-greece"/>Greece, Grecian

### Facts:

During New Testament times, Greece was a province in the Roman Empire.

* Like the modern-day country of Greece, it was located on a peninsula that is bordered by the Mediterranean Sea, the Aegean Sea, and the Ionian Sea.
* The apostle Paul visited several cities in Greece and established churches in the cities of Corinth, Thessalonica, and Philippi and probably others.
* People who are from Greece are called "Greeks" and their language is "Greek." People from other Roman provinces also spoke Greek, including many Jews.
* Sometimes the term "Greek" is used to refer to a Gentile.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Corinth](#corinth), [Gentile](kt.html#gentile), [Greek](#greek), [Hebrew](kt.html#hebrew), [Philippi](#philippi), [Thessalonica](#thessalonica))

### Bible References:

* [Daniel 08:20-21](https://git.door43.org/Door43/en_tn/src/master/dan/08/20.md)
* [Daniel 10:20-21](https://git.door43.org/Door43/en_tn/src/master/dan/10/20.md)
* [Daniel 11:1-2](https://git.door43.org/Door43/en_tn/src/master/dan/11/01.md)
* [Zechariah 09:11-13](https://git.door43.org/Door43/en_tn/src/master/zec/09/11.md)

### Word Data:

* Strong's: H3120, G1671


## <a id="tw-term-names-greek"/>Greek, Grecian

### Facts:

The term "Greek" refers to the language spoken in the country of Greece, it is also a person from the country of Greece.  Greek was also spoken throughout the Roman Empire. The term "Grecian" means "Greek-speaking."

* Since most non-Jewish people in the Roman Empire spoke Greek, Gentiles are often referred to as "Greeks" in the New Testament, especially when contrasted with Jews.
* The phrase "Grecian Jews" referred to Jews who spoke Greek in contrast to the "Hebraic Jews" who spoke only Hebrew, or perhaps Aramaic.
* Other ways to translate "Grecian" could include, "Greek-speaking" or "culturally Greek" or "Greek."
* When referring to non-Jews, "Greek" could be translated as "Gentile."

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Aram](#aram), [Gentile](kt.html#gentile), [Greece](#greece), [Hebrew](kt.html#hebrew), [Rome](#rome))

### Bible References:

* [Acts 06:1](https://git.door43.org/Door43/en_tn/src/master/act/06/01.md)
* [Acts 09:28-30](https://git.door43.org/Door43/en_tn/src/master/act/09/28.md)
* [Acts 11:19-21](https://git.door43.org/Door43/en_tn/src/master/act/11/19.md)
* [Acts 14:1-2](https://git.door43.org/Door43/en_tn/src/master/act/14/01.md)
* [Colossians 03:9-11](https://git.door43.org/Door43/en_tn/src/master/col/03/09.md)
* [Galatians 02:3-5](https://git.door43.org/Door43/en_tn/src/master/gal/02/03.md)
* [John 07:35-36](https://git.door43.org/Door43/en_tn/src/master/jhn/07/35.md)

### Word Data:

* Strong's: H3125, G1672, G1673, G1674, G1675, G1676


## <a id="tw-term-names-habakkuk"/>Habakkuk

### Facts:

Habakkuk was an Old Testament prophet who lived around the time that King Jehoiakim was reigning over Judah. The prophet Jeremiah was also alive during some of this time.

* This prophet wrote the book of Habakkuk around 600 BC when the Babylonians conquered Jerusalem and took many of the people of Judah into exile.
* Yahweh gave Habakkuk the prophecy about how the "Chaldeans" (Babylonians) would come and conquer the people of Judah.
* One of Habakkuk's most well-known statements is: "the righteous person shall live by his faith."

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Babylon](#babylon), [Jehoiakim](#jehoiakim), [Jeremiah](#jeremiah))

### Bible References:

* [Habakkuk 01:1-2](https://git.door43.org/Door43/en_tn/src/master/hab/01/01.md)

### Word Data:

* Strong's: H2265


## <a id="tw-term-names-hagar"/>Hagar

### Facts:

Hagar was an Egyptian woman who was Sarai's personal slave.

* When Sarai was not able to bear children, she gave Hagar to her husband Abram to have a child by him.
* Hagar conceived and gave birth to Abram's son Ishmael.
* God watched over Hagar when she was in distress in the desert and promised to bless her descendants.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Abraham](#abraham), [descendant](other.html#descendant), [Ishmael](#ishmael), [Sarah](#sarah), [servant](other.html#servant))

### Bible References:

* [Galatians 04:24-25](https://git.door43.org/Door43/en_tn/src/master/gal/04/24.md)
* [Genesis 16:1-4](https://git.door43.org/Door43/en_tn/src/master/gen/16/01.md)
* [Genesis 21:8-9](https://git.door43.org/Door43/en_tn/src/master/gen/21/08.md)
* [Genesis 25:12](https://git.door43.org/Door43/en_tn/src/master/gen/25/12.md)

### Examples from the Bible stories:

  __*[05:01](https://git.door43.org/Door43/en_tn/src/master/obs/05/01.md)__ So Abram's wife, Sarai, said to him, "Since God has not allowed me to have children and now I am too old to have children, here is my servant, __Hagar__. Marry her also so she can have a child for me."
  __*[05:02](https://git.door43.org/Door43/en_tn/src/master/obs/05/02.md)__ __Hagar__ had a baby boy, and Abram named him Ishmael.

### Word Data:

* Strong's: H1904


## <a id="tw-term-names-haggai"/>Haggai

### Facts:

Haggai was a prophet of Judah after the Jews returned home from being captives in Babylon.

* During the period when Haggai was prophesying, King Uzziah was reigning over Judah.
* The prophet Zechariah was also prophesying during this period.
* Haggai and Zechariah exhorted the Jews to rebuild the temple, which had been destroyed by the Babylonians under King Nebuchadnezzar.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Babylon](#babylon), [Judah](#kingdomofjudah), [Nebuchadnezzar](#nebuchadnezzar), [Uzziah](#uzziah), [Zechariah (OT)](#zechariahot))

### Bible References:

* [Ezra 05:1-2](https://git.door43.org/Door43/en_tn/src/master/ezr/05/01.md)
* [Ezra 06:13-15](https://git.door43.org/Door43/en_tn/src/master/ezr/06/13.md)

### Word Data:

* Strong's: H2292


## <a id="tw-term-names-ham"/>Ham

### Facts:

Ham was the second of Noah's three sons.

* During the worldwide flood that covered the whole earth, Ham and his brothers were with Noah in the ark, along with their wives.
* After the flood, there was an occasion where Ham was very dishonoring to his father, Noah. As a result, Noah cursed Ham's son Canaan and all his descendants, who eventually became known as the Canaanites.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [ark](kt.html#ark), [Canaan](#canaan), [dishonor](other.html#dishonor), [Noah](#noah))

### Bible References:

* [Genesis 05:32](https://git.door43.org/Door43/en_tn/src/master/gen/05/32.md)
* [Genesis 06:9-10](https://git.door43.org/Door43/en_tn/src/master/gen/06/09.md)
* [Genesis 07:13-14](https://git.door43.org/Door43/en_tn/src/master/gen/07/13.md)
* [Genesis 10:1](https://git.door43.org/Door43/en_tn/src/master/gen/10/01.md)
* [Genesis 10:19-20](https://git.door43.org/Door43/en_tn/src/master/gen/10/19.md)

### Word Data:

* Strong's: H2526


## <a id="tw-term-names-hamath"/>Hamath, Hamathites, Lebo Hamath

### Facts:

Hamath was an important city in northern Syria, north of the land of Canaan. The Hamathites were descendants of Noah's son Canaan.

* The name "Lebo Hamath" probably refers to a mountain pass near the city of Hamath.
* Some versions translate "Lebo Hamath" as "entrance to Hamath."
* King David defeated enemies of King Tou of Hamath, causing them to be on good terms.
* Hamath was one of Solomon's storehouse cities where provisions were kept.
* The land of Hamath was where King Zedekiah was killed by King Nebuchadnezzar and where King Jehoahaz was captured by an Egyptian pharaoh.
* The term "Hamathite" could also be translated as "person from Hamath."
 

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Babylon](#babylon), [Canaan](#canaan), [Nebuchadnezzar](#nebuchadnezzar), [Syria](#syria), [Zedekiah](#zedekiah))

### Bible References:

* [1 Chronicles 18:3-4](https://git.door43.org/Door43/en_tn/src/master/1ch/18/03.md)
* [2 Samuel 08:9-10](https://git.door43.org/Door43/en_tn/src/master/2sa/08/09.md)
* [Amos 06:1-2](https://git.door43.org/Door43/en_tn/src/master/amo/06/01.md)
* [Ezekiel 47:15-17](https://git.door43.org/Door43/en_tn/src/master/ezk/47/15.md)

### Word Data:

* Strong's: H2574, H2577


## <a id="tw-term-names-hamor"/>Hamor

### Facts:

Hamor was a Canaanite man living in the city of Shechem when Jacob and his family were living in nearby Succoth. He was a Hivite.

* Jacob bought a family burial ground from Hamor's sons.
* While they were there, Hamor's son Shechem raped Jacob's daughter Dinah.
* Dinah's brothers took revenge on Hamor's family and killed all the men in the city of Shechem.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Canaan](#canaan), [Hivite](#hivite), [Jacob](#jacob), [Shechem](#shechem), [Succoth](#succoth))

### Bible References:

* [Acts 07:14-16](https://git.door43.org/Door43/en_tn/src/master/act/07/14.md)
* [Genesis 34:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/34/01.md)
* [Genesis 34:20-21](https://git.door43.org/Door43/en_tn/src/master/gen/34/20.md)
* [Joshua 24:32-33](https://git.door43.org/Door43/en_tn/src/master/jos/24/32.md)
* [Judges 09:28-29](https://git.door43.org/Door43/en_tn/src/master/jdg/09/28.md)

### Word Data:

* Strong's: H2544


## <a id="tw-term-names-hananiah"/>Hananiah

### Facts:

Hananiah was the name of several different men in the Old Testament.

* One Hananiah was an Israelite captive in Babylon whose name was changed to "Shadrach."
* He was given a position as a royal servant due to his excellent character and abilities.
* Once Hanahiah (Shadrach) and two other Israelite young men were thrown into a fire in a furnace because they refused to worship the Babylonian king. God showed his power by protecting them from being harmed.
* Another man named Hananiah was listed as a descendant of King Solomon.
* A different Hananiah was a false prophet during the time of the prophet Jeremiah.
* One man named Hananiah was a priest who helped lead a celebration during the time of Nehemiah.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Azariah](#azariah), [Babylon](#babylon), [Daniel](#daniel), [false prophet](other.html#falseprophet), [Jeremiah](#jeremiah), [Mishael](#mishael))

### Bible References:

* [Daniel 01:6-7](https://git.door43.org/Door43/en_tn/src/master/dan/01/06.md)
* [Daniel 02:17-18](https://git.door43.org/Door43/en_tn/src/master/dan/02/17.md)
* [Jeremiah 28:1-2](https://git.door43.org/Door43/en_tn/src/master/jer/28/01.md)
* [Jeremiah 28:5-7](https://git.door43.org/Door43/en_tn/src/master/jer/28/05.md)
* [Jeremiah 28:15-17](https://git.door43.org/Door43/en_tn/src/master/jer/28/15.md)

### Word Data:

* Strong's: H2608


## <a id="tw-term-names-hannah"/>Hannah

### Facts:

Hannah was the mother of the prophet Samuel. She was one of two wives of Elkanah.

* Hannah was not able to conceive a child, which was a great grief to her.
* At the temple, Hannah earnestly prayed for God to give her a son, promising to dedicate him to serving God.
* God granted her request and when the boy Samuel was old enough, she brought him to serve at the temple.
* God also gave Hannah other children after that.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [conceive](other.html#conceive), [Samuel](#samuel))

### Bible References:

* [1 Samuel 01:1-2](https://git.door43.org/Door43/en_tn/src/master/1sa/01/01.md)
* [1 Samuel 02:1](https://git.door43.org/Door43/en_tn/src/master/1sa/02/01.md)

### Word Data:

* Strong's: H2584


## <a id="tw-term-names-haran"/>Haran

### Facts:

Haran was a younger brother of Abram and the father of Lot.

* Haran was also the name of the town where Abram and his family lived awhile on their journey from the city of Ur to the land of Canaan.
* A different man named Haran was a son of Caleb.
* A third man in the Bible named Haran was a descendant of Levi.
  

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Abraham](#abraham), [Caleb](#caleb), [Canaan](#canaan), [Levite](#levite), [Lot](#lot), [Terah](#terah), [Ur](#ur))

### Bible References:

* [2 Kings 19:12-13](https://git.door43.org/Door43/en_tn/src/master/2ki/19/12.md)
* [Acts 07:1-3](https://git.door43.org/Door43/en_tn/src/master/act/07/01.md)
* [Genesis 11:31-32](https://git.door43.org/Door43/en_tn/src/master/gen/11/31.md)
* [Genesis 27:43-45](https://git.door43.org/Door43/en_tn/src/master/gen/27/43.md)
* [Genesis 28:10-11](https://git.door43.org/Door43/en_tn/src/master/gen/28/10.md)
* [Genesis 29:4-6](https://git.door43.org/Door43/en_tn/src/master/gen/29/04.md)

### Word Data:

* Strong's: H2039


## <a id="tw-term-names-hebron"/>Hebron

### Facts:

Hebron was a city located in the high, rocky hills about 20 miles south of Jerusalem.

* The city was built around 2000 BC during the time of Abram. It was mentioned many times in the historical accounts given in the Old Testament.
* Hebron had a very important role in King David's life. Several of his sons, including Absalom, were born there.
* The city was destroyed around AD 70 by the Romans.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Absalom](#absalom))

### Bible References:

* [2 Samuel 02:10-11](https://git.door43.org/Door43/en_tn/src/master/2sa/02/10.md)
* [Genesis 13:16-18](https://git.door43.org/Door43/en_tn/src/master/gen/13/16.md)
* [Genesis 23:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/23/01.md)
* [Genesis 35:26-27](https://git.door43.org/Door43/en_tn/src/master/gen/35/26.md)
* [Genesis 37:12-14](https://git.door43.org/Door43/en_tn/src/master/gen/37/12.md)
* [Judges 01:8-10](https://git.door43.org/Door43/en_tn/src/master/jdg/01/08.md)
* [Numbers 13:21-22](https://git.door43.org/Door43/en_tn/src/master/num/13/21.md)

### Word Data:

* Strong's: H2275, H2276, H5683


## <a id="tw-term-names-herodantipas"/>Herod Antipas

### Facts:

 During most of Jesus' lifetime, Herod Antipas was the ruler of the part of the Roman Empire that included Galilee province. 

* Like his father Herod the Great, Antipas was sometimes referred to as "King Herod" even though he was not really a king.
* Herod Antipas ruled one-fourth of the Roman Empire and so he was also called "Herod the tetrarch."
* Antipas is the "Herod" who gave the order for John the Baptist to be killed by beheading.
* It was also Herod Antipas who questioned Jesus before his crucifixion.
* The other Herods in the New Testament were Antipas' son (Agrippa) and grandson (Agrippa 2) who ruled during the time of the apostles. 

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [crucify](kt.html#crucify), [Herod the Great](#herodthegreat), [John (the Baptist)](#johnthebaptist), [king](other.html#king), [Rome](#rome))

### Bible References:

* [Luke 03:1-2](https://git.door43.org/Door43/en_tn/src/master/luk/03/01.md)
* [Luke 03:18-20](https://git.door43.org/Door43/en_tn/src/master/luk/03/18.md)
* [Luke 09:7-9](https://git.door43.org/Door43/en_tn/src/master/luk/09/07.md)
* [Luke 13:31-33](https://git.door43.org/Door43/en_tn/src/master/luk/13/31.md)
* [Luke 23:8-10](https://git.door43.org/Door43/en_tn/src/master/luk/23/08.md)
* [Mark 06:18-20](https://git.door43.org/Door43/en_tn/src/master/mrk/06/18.md)
* [Matthew 14:1-2](https://git.door43.org/Door43/en_tn/src/master/mat/14/01.md)

### Word Data:

* Strong's: G2264, G2265, G2267


## <a id="tw-term-names-herodias"/>Herodias

### Facts:

Herodias was the wife of Herod Antipas in Judea during the time of John the Baptist.

* Herodias was originally the wife of Herod Antipas's brother Philip, but later she unlawfully married Herod Antipas.
* John the Baptist rebuked Herod and Herodias for their unlawful marriage. Because of this, Herod put John in prison and because of Herodias eventually was beheaded.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Herod Antipas](#herodantipas), [John (the Baptist)](#johnthebaptist))

### Bible References:

* [Luke 03:18-20](https://git.door43.org/Door43/en_tn/src/master/luk/03/18.md)
* [Mark 06:16-17](https://git.door43.org/Door43/en_tn/src/master/mrk/06/16.md)
* [Mark 06:21-22](https://git.door43.org/Door43/en_tn/src/master/mrk/06/21.md)
* [Matthew 14:3-5](https://git.door43.org/Door43/en_tn/src/master/mat/14/03.md)

### Word Data:

* Strong's: G2266


## <a id="tw-term-names-herodthegreat"/>Herod the Great

### Facts:

Herod the Great was ruling over Judea at the time Jesus was born. He was the first of several Edomite rulers named Herod who ruled over parts of the Roman Empire.

 * His ancestors converted to Judaism and he was raised as a Jew.
 * Caesar Augustus named him "King Herod" even though he was not a true king. He ruled over the Jews in Judea for 33 years.
 * Herod the Great was known for the beautiful buildings he ordered to be built and for the rebuilding of the Jewish temple in Jerusalem.
 * This Herod was very cruel and had many people killed. When he heard that a "king of the Jews" had been born in Bethlehem, he had all the baby boys in that town killed.
 * His sons Herod Antipas and Herod Philip and his grandson Herod Agrippa also became Roman rulers. His great-grandson Herod Agrippa II (called "King Agrippa") ruled over the entire area of Judea.

(See [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Herod Antipas](#herodantipas), [Judea](#judea), [king](other.html#king), [temple](kt.html#temple))

### Bible References:

* [Matthew 02:1-3](https://git.door43.org/Door43/en_tn/src/master/mat/02/01.md)
* [Matthew 02:11-12](https://git.door43.org/Door43/en_tn/src/master/mat/02/11.md)
* [Matthew 02:16](https://git.door43.org/Door43/en_tn/src/master/mat/02/16.md)
* [Matthew 02:19-21](https://git.door43.org/Door43/en_tn/src/master/mat/02/19.md)
* [Matthew 02:22-23](https://git.door43.org/Door43/en_tn/src/master/mat/02/22.md)

### Word Data:

* Strong's: G2264


## <a id="tw-term-names-hezekiah"/>Hezekiah

### Definition:

Hezekiah was the 13th king over the kingdom of Judah. He was a king who trusted and obeyed God.

* Unlike his father Ahaz, who had been an evil king, King Hezekiah was a good king who destroyed all the places of idol worship in Judah.
* One time when Hezekiah became very sick and almost died, he earnestly prayed that God would spare his life. God healed him and allowed him to live 15 more years.
* As a sign to Hezekiah that this would happen, God performed a miracle and caused the sun to move backwards in the sky.
* God also answered Hezekiah's prayer to save his people from King Sennacherib of Assyria, who was attacking them.

(See also: [Ahaz](#ahaz), [Assyria](#assyria), [false god](kt.html#falsegod), [Judah](#judah), [Sennacherib](#sennacherib))

### Bible References:

* [1 Chronicles 03:13-14](https://git.door43.org/Door43/en_tn/src/master/1ch/03/13.md)
* [2 Kings 16:19-20](https://git.door43.org/Door43/en_tn/src/master/2ki/16/19.md)
* [Hosea 01:1-2](https://git.door43.org/Door43/en_tn/src/master/hos/01/01.md)
* [Matthew 01:9-11](https://git.door43.org/Door43/en_tn/src/master/mat/01/09.md)
* [Proverbs 25:1-3](https://git.door43.org/Door43/en_tn/src/master/pro/25/01.md)

### Word Data:

* Strong's: H2396, H3169, G1478


## <a id="tw-term-names-hilkiah"/>Hilkiah

### Facts:

Hilkiah was the high priest during the reign of King Josiah. 

* When the temple was being repaired, Hilkiah the high priest found the Book of the Law and ordered that it be brought to King Josiah.
* After the Book of the Law was read to him, Josiah was grieved and caused the people of Judah to worship Yahweh again and obey his laws.
* Another man named Hilkiah was the son of Eliakim and worked in the palace during the time of King Hezekiah.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Eliakim](#eliakim), [Hezekiah](#hezekiah), [high priest](kt.html#highpriest), [Josiah](#josiah), [Judah](#kingdomofjudah), [law](other.html#law), [worship](kt.html#worship), [Yahweh](kt.html#yahweh))

### Bible References:

* [2 Kings 18:16-18](https://git.door43.org/Door43/en_tn/src/master/2ki/18/16.md)

### Word Data:

* Strong's: H2518


## <a id="tw-term-names-hittite"/>Hittite, Hittites

### Definition:

The Hittites were descendants of Ham through his son Canaan. They became a large empire located in what is now Turkey and northern Palestine.

* Abraham bought a piece of property from Ephron the Hittite so that he could bury his deceased wife Sarah in a cave there. Eventually Abraham and several of his descendants were also buried in that cave.
* Esau's parents were grieved when he married two Hittite women.
* One of David's mighty men was named Uriah the Hittite.
* Some of the foreign women that Solomon married were Hittites. These foreign women turned Solomon's heart away from God because of the false gods they worshiped.
* The Hittites were often a threat to the Israelites, both physically and spiritually.

(See also: [descendant](other.html#descendant), [Esau](#esau), [foreigner](other.html#foreigner), [Ham](#ham), [mighty](other.html#mighty), [Solomon](#solomon), [Uriah](#uriah))

### Bible References:

* [1 Kings 09:20-21](https://git.door43.org/Door43/en_tn/src/master/1ki/09/20.md)
* [Exodus 03:7-8](https://git.door43.org/Door43/en_tn/src/master/exo/03/07.md)
* [Genesis 23:10-11](https://git.door43.org/Door43/en_tn/src/master/gen/23/10.md)
* [Genesis 25:9-11](https://git.door43.org/Door43/en_tn/src/master/gen/25/09.md)
* [Joshua 01:4-5](https://git.door43.org/Door43/en_tn/src/master/jos/01/04.md)
* [Nehemiah 09:7-8](https://git.door43.org/Door43/en_tn/src/master/neh/09/07.md)
* [Numbers 13:27-29](https://git.door43.org/Door43/en_tn/src/master/num/13/27.md)

### Word Data:

* Strong's: H2850


## <a id="tw-term-names-hivite"/>Hivite, Hivites

### Facts:

The Hivites were one of seven major people groups living in the land of Canaan.

* All these groups, including the Hivites, were descended from Canaan, who was Noah's grandson.
* Shechem the Hivite raped Jacob's daughter Dinah, and her brothers killed many Hivites in revenge.
* When Joshua led the Israelites to take over the land of Canaan, the Israelites were tricked into making a treaty with the Hivites instead of conquering them.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Canaan](#canaan), [Hamor](#hamor), [Noah](#noah), [Shechem](#shechem))

### Bible References:

* [2 Chronicles 08:7-8](https://git.door43.org/Door43/en_tn/src/master/2ch/08/07.md)
* [Exodus 03:7-8](https://git.door43.org/Door43/en_tn/src/master/exo/03/07.md)
* [Genesis 34:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/34/01.md)
* [Joshua 09:1-2](https://git.door43.org/Door43/en_tn/src/master/jos/09/01.md)
* [Judges 03:1-3](https://git.door43.org/Door43/en_tn/src/master/jdg/03/01.md)

### Word Data:

* Strong's: H2340


## <a id="tw-term-names-horeb"/>Horeb

### Definition:

Mount Horeb is another name for Mount Sinai, where God gave Moses the stone tablets with the ten commandments.

* Mount Horeb is called the "mountain of God."
* Horeb was the place where Moses saw the burning bush when he was tending sheep.
* Mount Horeb was the place where God revealed his covenant to the Israelites by giving them the stone tablets with his commandments written on them.
* It was also the place where God later told Moses to strike a rock to provide water for the Israelites as they were wandering in the desert.
* The exact location of this mountain is not known, but it may  have been in the southern part of what is now the Sinai Peninsula.
* It is possible that "Horeb" was the actual name of the mountain and that "Mount Sinai" simply means "mountain of Sinai," referring to the fact that Mount Horeb was located in the desert of Sinai.

(See also: [covenant](kt.html#covenant), [Israel](kt.html#israel), [Moses](#moses), [Sinai](#sinai), [Ten Commandments](other.html#tencommandments))

### Bible References:

* [1 Kings 08:9-11](https://git.door43.org/Door43/en_tn/src/master/1ki/08/09.md)
* [2 Chronicles 05:9-10](https://git.door43.org/Door43/en_tn/src/master/2ch/05/09.md)
* [Deuteronomy 01:1-2](https://git.door43.org/Door43/en_tn/src/master/deu/01/01.md)
* [Exodus 03:1-3](https://git.door43.org/Door43/en_tn/src/master/exo/03/01.md)
* [Psalms 106:19-21](https://git.door43.org/Door43/en_tn/src/master/psa/106/019.md)

### Word Data:

* Strong's: H2722


## <a id="tw-term-names-hosea"/>Hosea

### Facts:

Hosea was a prophet of Israel who lived and prophesied about 750 years before the time of Christ.

* His ministry lasted for many years through the reigns of several kings, such as Jeroboam, Zechariah, Jotham, Ahaz, Hoshea, Uzziah, and Hezekiah.
* Hosea was told by God to marry a prostitute named Gomer and to continue to love her, even though she was unfaithful to him.
* This was a picture of God's love for his unfaithful people, Israel.
* Hosea prophesied against the people of Israel because of their sin, warning them to turn away from worshipping idols.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Ahaz](#ahaz), [Hezekiah](#hezekiah), [Hoshea](#hoshea), [Jeroboam](#jeroboam), [Jotham](#jotham), [Uzziah](#uzziah), [Zechariah (OT)](#zechariahot))

### Bible References:

* [Hosea 01:1-2](https://git.door43.org/Door43/en_tn/src/master/hos/01/01.md)
* [Hosea 01:3-5](https://git.door43.org/Door43/en_tn/src/master/hos/01/03.md)
* [Hosea 01:6-7](https://git.door43.org/Door43/en_tn/src/master/hos/01/06.md)

### Word Data:

* Strong's: H1954, G5617


## <a id="tw-term-names-hoshea"/>Hoshea

### Facts:

Hoshea was the name of a king of Israel and several other men in the Old Testament.

* Hoshea son of Alah was a king of Israel for nine years during part of the reigns of Ahaz and Hezekiah, kings of Judah.
* Joshua son of Nun was formerly named Hoshea. Moses changed Hoshea's name to Joshua before sending him and eleven other men to spy out the land of the Canaanites.
* After Moses died, Joshua led the people of Israel to take possession of the land of Canaan.
* A different man named Hoshea was a son of Azaziah and was one of the leaders of the Ephraimites.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Ahaz](#ahaz), [Canaan](#canaan), [Ephraim](#ephraim), [Hezekiah](#hezekiah), [Joshua](#joshua), [Moses](#moses))

### Bible References:

* [1 Chronicles 27:19-22](https://git.door43.org/Door43/en_tn/src/master/1ch/27/19.md)
* [2 Kings 15:29-31](https://git.door43.org/Door43/en_tn/src/master/2ki/15/29.md)
* [2 Kings 17:1-3](https://git.door43.org/Door43/en_tn/src/master/2ki/17/01.md)
* [2 Kings 18:1-3](https://git.door43.org/Door43/en_tn/src/master/2ki/18/01.md)
* [2 Kings 18:9-10](https://git.door43.org/Door43/en_tn/src/master/2ki/18/09.md)

### Word Data:

* Strong's: H1954


## <a id="tw-term-names-houseofdavid"/>house of David

### Facts:

The expression "house of David" refers to the family or descendants of King David. 

* This could also be translated as "descendants of David" or "family of David" or "King David's clan."
* Because Jesus was descended from David, he was part of the "house of David."
* Sometimes "house of David" or "household of David" refers to the people in David's family who were still living.
* Other times this term is more general and refers to all his descendants, including those who had already died.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [David](#david), [descendant](other.html#descendant), [house](other.html#house), [Jesus](kt.html#jesus), [king](other.html#king))

### Bible References:

* [2 Chronicles 10:17-19](https://git.door43.org/Door43/en_tn/src/master/2ch/10/17.md)
* [2 Samuel 03:6-7](https://git.door43.org/Door43/en_tn/src/master/2sa/03/06.md)
* [Luke 01:69-71](https://git.door43.org/Door43/en_tn/src/master/luk/01/69.md)
* [Psalms 122:4-5](https://git.door43.org/Door43/en_tn/src/master/psa/122/004.md)
* [Zechariah 12:7-9](https://git.door43.org/Door43/en_tn/src/master/zec/12/07.md)

### Word Data:

* Strong's: H1004, H1732, G1138, G3624


## <a id="tw-term-names-iconium"/>Iconium

### Facts:

Iconium was a city in the south central part of what is now the country of Turkey.

* On Paul's first missionary journey, he and Barnabas went to Iconium after the Jews forced them to leave the city of Antioch.
* Then the unbelieving Jews and Gentiles in Iconium also planned to stone Paul and his coworkers, but they escaped to the nearby city of Lystra.
* After that the people from both Antioch and Iconium came to Lystra and stirred up the people there to stone Paul.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Barnabas](#barnabas), [Lystra](#lystra), [stone](kt.html#stone))

### Bible References:

* [2 Timothy 03:10-13](https://git.door43.org/Door43/en_tn/src/master/2ti/03/10.md)
* [Acts 14:1-2](https://git.door43.org/Door43/en_tn/src/master/act/14/01.md)
* [Acts 14:19-20](https://git.door43.org/Door43/en_tn/src/master/act/14/19.md)
* [Acts 16:1-3](https://git.door43.org/Door43/en_tn/src/master/act/16/01.md)

### Word Data:

* Strong's: G2430


## <a id="tw-term-names-isaac"/>Isaac

### Facts:

Isaac was the only son of Abraham and Sarah. God had promised to give them a son even though they were very old.

 * The name "Isaac" means "he laughs." When God told Abraham that Sarah would give birth to a son, Abraham laughed because they were both very old. Some time later, Sarah also laughed when she heard this news.
 * But God fulfilled his promise and Isaac was born to Abraham and Sarah in their old age.
 * God told Abraham that the covenant he had made with Abraham would also be for Isaac and his descendants forever.
 * When Isaac was a youth, God tested Abraham's faith by commanding him to sacrifice Isaac.
 * Isaac's son Jacob had twelve sons whose descendants later became the twelve tribes of the nation of Israel.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Abraham](#abraham), [descendant](other.html#descendant), [eternity](kt.html#eternity), [fulfill](kt.html#fulfill), [Jacob](#jacob), [Sarah](#sarah), [twelve tribes of Israel](other.html#12tribesofisrael))

### Bible References:

* [Galatians 04:28-29](https://git.door43.org/Door43/en_tn/src/master/gal/04/28.md)
* [Genesis 25:9-11](https://git.door43.org/Door43/en_tn/src/master/gen/25/09.md)
* [Genesis 25:19-20](https://git.door43.org/Door43/en_tn/src/master/gen/25/19.md)
* [Genesis 26:1](https://git.door43.org/Door43/en_tn/src/master/gen/26/01.md)
* [Genesis 26:6-8](https://git.door43.org/Door43/en_tn/src/master/gen/26/06.md)
* [Genesis 28:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/28/01.md)
* [Genesis 31:17-18](https://git.door43.org/Door43/en_tn/src/master/gen/31/17.md)
* [Matthew 08:11-13](https://git.door43.org/Door43/en_tn/src/master/mat/08/11.md)
* [Matthew 22:31-33](https://git.door43.org/Door43/en_tn/src/master/mat/22/31.md)

### Examples from the Bible stories:

  __*[05:04](https://git.door43.org/Door43/en_tn/src/master/obs/05/04.md)__ "Your wife, Sarai, will have a son—he will be the son of promise. Name him __Isaac__."
  __*[05:06](https://git.door43.org/Door43/en_tn/src/master/obs/05/06.md)__ When __Isaac__ was a young man, God tested Abraham's faith by saying, "Take __Isaac__, your only son, and kill him as a sacrifice to me."
  __*[05:09](https://git.door43.org/Door43/en_tn/src/master/obs/05/09.md)__ God had provided the ram to be the sacrifice instead of __Isaac__.
  __*[06:01](https://git.door43.org/Door43/en_tn/src/master/obs/06/01.md)__ When Abraham was very old and his son, __Isaac__, had grown to be a man, Abraham sent one of his servants back to the land where his relatives lived to find a wife for his son, __Isaac.__ 
  __*[06:05](https://git.door43.org/Door43/en_tn/src/master/obs/06/05.md)__ __Isaac__ prayed for Rebekah, and God allowed her to get pregnant with twins.
  __*[07:10](https://git.door43.org/Door43/en_tn/src/master/obs/07/10.md)__ Then __Isaac__ died, and Jacob and Esau buried him. The covenant promises God had promised to Abraham and then to __Isaac__ now passed on to Jacob.

### Word Data:

* Strong's: H3327, H3446, G2464


## <a id="tw-term-names-isaiah"/>Isaiah

### Facts:

Isaiah was a prophet of God who prophesied during the reigns of four kings of Judah: Uzziah, Jotham, Ahaz, and Hezekiah.

* He lived in Jerusalem during the time when the Assyrians were attacking the city, during the reign of Hezekiah.
* The Old Testament book of Isaiah is one of the major books of the Bible.
* Isaiah wrote many prophecies that came true while he was still living.
* Isaiah is especially known for the prophecies he wrote about the Messiah that came true 700 years later when Jesus was living on earth.
* Jesus and his disciples quoted Isaiah's prophecies to teach people about the Messiah. 

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Ahaz](#ahaz), [Assyria](#assyria), [Christ](kt.html#christ), [Hezekiah](#hezekiah), [Jotham](#jotham), [Judah](#kingdomofjudah), [prophet](kt.html#prophet), [Uzziah](#uzziah))

### Bible References:

* [2 Kings 20:1-3](https://git.door43.org/Door43/en_tn/src/master/2ki/20/01.md)
* [Acts 28:25-26](https://git.door43.org/Door43/en_tn/src/master/act/28/25.md)
* [Isaiah 01:1](https://git.door43.org/Door43/en_tn/src/master/isa/01/01.md)
* [Luke 03:4](https://git.door43.org/Door43/en_tn/src/master/luk/03/04.md)
* [Mark 01:1-3](https://git.door43.org/Door43/en_tn/src/master/mrk/01/01.md)
* [Mark 07:6-7](https://git.door43.org/Door43/en_tn/src/master/mrk/07/06.md)
* [Matthew 03:1-3](https://git.door43.org/Door43/en_tn/src/master/mat/03/01.md)
* [Matthew 04:14-16](https://git.door43.org/Door43/en_tn/src/master/mat/04/14.md)

### Examples from the Bible stories:

  __*[21:09](https://git.door43.org/Door43/en_tn/src/master/obs/21/09.md)__ The prophet __Isaiah__ prophesied that the Messiah would be born from a virgin.
  __*[21:10](https://git.door43.org/Door43/en_tn/src/master/obs/21/10.md)__ The prophet __Isaiah__ said the Messiah would live in Galilee, comfort broken-hearted people, and proclaim freedom to captives and release to prisoners. 
  __*[21:11](https://git.door43.org/Door43/en_tn/src/master/obs/21/11.md)__ The prophet __Isaiah__ also prophesied that the Messiah would be hated without reason and rejected.
  __*[21:12](https://git.door43.org/Door43/en_tn/src/master/obs/21/12.md)__ __Isaiah__ prophesied that people would spit on, mock, and beat the Messiah. 
  __*[26:02](https://git.door43.org/Door43/en_tn/src/master/obs/26/02.md)__ They handed him (Jesus) the scroll of the prophet __Isaiah__ so that he would read from it. Jesus opened up the scroll and read part of it to the people.
  __*[45:08](https://git.door43.org/Door43/en_tn/src/master/obs/45/08.md)__ When Philip approached the chariot, he heard the Ethiopian reading from what the prophet __Isaiah__ wrote.
  __*[45:10](https://git.door43.org/Door43/en_tn/src/master/obs/45/10.md)__ Philip explained to the Ethiopian that __Isaiah__ was writing about Jesus.

### Word Data:

* Strong's: H3470, G2268


## <a id="tw-term-names-ishmael"/>Ishmael, Ishmaelite, Ishmaelites

### Facts:

Ishmael was the son of Abraham and the Egyptian slave Hagar. There were several other men in the Old Testament named Ishmael.

* The name "Ishmael" means "God hears."
* God promised to bless Abraham's son Ishmael, but he was not the son God had promised to establish his covenant with.
* God protected Hagar and Ishmael when they were sent into the desert.
* While Ishmael was living in the desert of Paran, he married an Egyptian woman.
* Ishmael son of Nethaniah was an army officer from Judah who led a group of men to kill a governor who had been appointed by the Babylonian king, Nebuchadnezzar.
* There were also four other men named Ishmael in the Old Testament.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Abraham](#abraham), [Babylon](#babylon), [covenant](kt.html#covenant), [desert](other.html#desert), [Egypt](#egypt), [Hagar](#hagar), [Isaac](#isaac), [Nebuchadnezzar](#nebuchadnezzar), [Paran](#paran), [Sarah](#sarah))

### Bible References:

* [1 Chronicles 01:28-31](https://git.door43.org/Door43/en_tn/src/master/1ch/01/28.md)
* [2 Chronicles 23:1-3](https://git.door43.org/Door43/en_tn/src/master/2ch/23/01.md)
* [Genesis 16:11-12](https://git.door43.org/Door43/en_tn/src/master/gen/16/11.md)
* [Genesis 25:9-11](https://git.door43.org/Door43/en_tn/src/master/gen/25/09.md)
* [Genesis 25:13-16](https://git.door43.org/Door43/en_tn/src/master/gen/25/13.md)
* [Genesis 37:25-26](https://git.door43.org/Door43/en_tn/src/master/gen/37/25.md)

### Examples from the Bible stories:

* __[05:02](https://git.door43.org/Door43/en_tn/src/master/obs/05/02.md)__ So Abram married Hagar. Hagar had a baby boy, and Abram named him __Ishmael__.
* __[05:04](https://git.door43.org/Door43/en_tn/src/master/obs/05/04.md)__ "I will make __Ishmael__  a great nation, too, but my covenant will be with Isaac."

### Word Data:

* Strong's: H3458, H3459


## <a id="tw-term-names-issachar"/>Issachar

### Facts:

Issachar was the fifth son of Jacob. His mother was Leah.

* The tribe of Issachar was one of the twelve tribes of Israel.
* Issachar's land was bordered by the lands of Naphtali, Zebulun, Manasseh, and Gad.
* It was located just south of the Sea of Galilee. 

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Gad](#gad), [Manasseh](#manasseh), [Naphtali](#naphtali), [twelve tribes of Israel](other.html#12tribesofisrael), [Zebulun](#zebulun))

### Bible References:

* [Exodus 01:1-5](https://git.door43.org/Door43/en_tn/src/master/exo/01/01.md)
* [Ezekiel 48:23-26](https://git.door43.org/Door43/en_tn/src/master/ezk/48/23.md)
* [Genesis 30:16-18](https://git.door43.org/Door43/en_tn/src/master/gen/30/16.md)
* [Joshua 17:9-10](https://git.door43.org/Door43/en_tn/src/master/jos/17/09.md)

### Word Data:

* Strong's: H3485, G2466


## <a id="tw-term-names-jacob"/>Israel, Israelite, Israelites, Jacob

### Facts:

Jacob was the younger twin son of Isaac and Rebekah.

* Jacob's name means "he grabs the heel" which is an expression meaning "he deceives." As Jacob was being born, he was holding onto the heel of his twin brother Esau.
* Many years later, God changed Jacob's name to "Israel," which means "he struggles with God."
* Jacob was clever and deceptive. He found ways to take the firstborn blessing and inheritance rights from his older brother, Esau.
* Esau was angry and planned to kill him so Jacob left his homeland. But years later Jacob returned with his wives and children to the land of Canaan where Esau was living, and their families lived peacefully near each other.
* Jacob had twelve sons. Their descendants became the twelve tribes of Israel.
* A different man named Jacob is listed as being Joseph's father in Matthew's genealogy.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Canaan](#canaan), [deceive](other.html#deceive), [Esau](#esau), [Isaac](#isaac), [Israel](kt.html#israel), [Rebekah](#rebekah), [twelve tribes of Israel](other.html#12tribesofisrael))

### Bible References:

* [Acts 07:11-13](https://git.door43.org/Door43/en_tn/src/master/act/07/11.md)
* [Acts 07:44-46](https://git.door43.org/Door43/en_tn/src/master/act/07/44.md)
* [Genesis 25:24-26](https://git.door43.org/Door43/en_tn/src/master/gen/25/24.md)
* [Genesis 29:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/29/01.md)
* [Genesis 32:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/32/01.md)
* [John 04:4-5](https://git.door43.org/Door43/en_tn/src/master/jhn/04/04.md)
* [Matthew 08:11-13](https://git.door43.org/Door43/en_tn/src/master/mat/08/11.md)
* [Matthew 22:31-33](https://git.door43.org/Door43/en_tn/src/master/mat/22/31.md)

### Examples from the Bible stories:

* __[07:01](https://git.door43.org/Door43/en_tn/src/master/obs/07/01.md)__ As the boys grew up, Rebekah loved __Jacob__, but Isaac loved Esau. __Jacob__  loved to stay at home, but Esau loved to hunt.
* __[07:07](https://git.door43.org/Door43/en_tn/src/master/obs/07/07.md)__ __Jacob__  lived there for many years, and during that time he married and had twelve sons and a daughter. God made him very wealthy.
* __[07:08](https://git.door43.org/Door43/en_tn/src/master/obs/07/08.md)__ After twenty years away from his home in Canaan, __Jacob__  returned there with his family, his servants, and all his herds of animals.
* __[07:10](https://git.door43.org/Door43/en_tn/src/master/obs/07/10.md)__ The covenant promises God had promised to Abraham and then to Isaac now passed on to __Jacob__.
* __[08:01](https://git.door43.org/Door43/en_tn/src/master/obs/08/01.md)__ Many years later, when __Jacob__  was an old man, he sent his favorite son, Joseph, to check on his brothers who were taking care of the herds.

### Word Data:

* Strong's: H3290, G2384


## <a id="tw-term-names-jamesbrotherofjesus"/>James (brother of Jesus)

### Facts:

James was a son of Mary and Joseph. He was one of Jesus' younger half-brothers.

* Jesus' other half-brothers were named Joseph, Judas, and Simon.
* During Jesus' lifetime, James and his brothers did not believe that Jesus was the Messiah.
* Later, after Jesus was raised from the dead, James believed in him and became a leader of the church in Jerusalem.
* The New Testament book of James is a letter that James wrote to Christians who had fled to other countries to escape persecution.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [apostle](kt.html#apostle), [Christ](kt.html#christ), [church](kt.html#church), [Judas the son of James](#judassonofjames), [persecute](other.html#persecute))

### Bible References:

* [Galatians 01:18-20](https://git.door43.org/Door43/en_tn/src/master/gal/01/18.md)
* [Galatians 02:9-10](https://git.door43.org/Door43/en_tn/src/master/gal/02/09.md)
* [James 01:1-3](https://git.door43.org/Door43/en_tn/src/master/jas/01/01.md)
* [Jude 01:1-2](https://git.door43.org/Door43/en_tn/src/master/jud/01/01.md)
* [Mark 09:1-3](https://git.door43.org/Door43/en_tn/src/master/mrk/09/01.md)
* [Matthew 13:54-56](https://git.door43.org/Door43/en_tn/src/master/mat/13/54.md)

### Word Data:

* Strong's: G2385


## <a id="tw-term-names-jamessonofalphaeus"/>James (son of Alphaeus)

### Facts:

James, the son of Alphaeus, was one of Jesus' twelve apostles.

* His name is given in the lists of Jesus' disciples in the gospels of Matthew, Mark, and Luke.
* He is also mentioned in the book of Acts as one of the eleven disciples who were together praying in Jerusalem after Jesus went back up to heaven.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [apostle](kt.html#apostle), [disciple](kt.html#disciple), [James (brother of Jesus)](#jamesbrotherofjesus), [James (son of Zebedee)](#jamessonofzebedee), [the twelve](kt.html#thetwelve))

### Bible References:

* [Acts 01:12-14](https://git.door43.org/Door43/en_tn/src/master/act/01/12.md)
* [Luke 06:14-16](https://git.door43.org/Door43/en_tn/src/master/luk/06/14.md)
* [Mark 03:17-19](https://git.door43.org/Door43/en_tn/src/master/mrk/03/17.md)
* [Mark 14:32-34](https://git.door43.org/Door43/en_tn/src/master/mrk/14/32.md)
* [Matthew 10:2-4](https://git.door43.org/Door43/en_tn/src/master/mat/10/02.md)

### Word Data:

* Strong's: G2385


## <a id="tw-term-names-jamessonofzebedee"/>James (son of Zebedee)

### Facts:

James, a son of Zebedee, was one of Jesus' twelve apostles. He had a younger brother named John who was also one of Jesus' apostles.

* James and his brother John worked by fishing with their father Zebedee.
* James and John were nicknamed the "Sons of Thunder," perhaps because they got angry quickly.
* Peter, James, and John were Jesus' closest disciples and were with him for amazing events such as when Jesus was on a mountaintop with Elijah and Moses and when Jesus caused a dead little girl to come back to life.
* This is a different James than the one who wrote a book in the Bible. Some languages may have to write their names differently to make it clear that they were two different men.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [apostle](kt.html#apostle), [Elijah](#elijah), [James (brother of Jesus)](#jamesbrotherofjesus), [James (son of Alphaeus)](#jamessonofalphaeus), [Moses](#moses))

### Bible References:

* [Luke 09:28-29](https://git.door43.org/Door43/en_tn/src/master/luk/09/28.md)
* [Mark 01:19-20](https://git.door43.org/Door43/en_tn/src/master/mrk/01/19.md)
* [Mark 01:29-31](https://git.door43.org/Door43/en_tn/src/master/mrk/01/29.md)
* [Mark 03:17-19](https://git.door43.org/Door43/en_tn/src/master/mrk/03/17.md)
* [Matthew 04:21-22](https://git.door43.org/Door43/en_tn/src/master/mat/04/21.md)
* [Matthew 17:1-2](https://git.door43.org/Door43/en_tn/src/master/mat/17/01.md)

### Word Data:

* Strong's: G2385

## <a id="tw-term-names-japheth"/>Japheth

### Facts:

Japheth was one of Noah's three sons.

* During the worldwide flood that covered the whole earth, Japheth and his two brothers were with Noah in the ark, along with their wives.
* Noah's sons are usually listed as, "Shem, Ham, and Japheth." This indicates that Japheth was the youngest brother.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [ark](kt.html#ark), [flood](other.html#flood), [Ham](#ham), [Noah](#noah), [Shem](#shem))

### Bible References:

* [1 Chronicles 01:1-4](https://git.door43.org/Door43/en_tn/src/master/1ch/01/01.md)
* [Genesis 05:32](https://git.door43.org/Door43/en_tn/src/master/gen/05/32.md)
* [Genesis 06:9-10](https://git.door43.org/Door43/en_tn/src/master/gen/06/09.md)
* [Genesis 07:13-14](https://git.door43.org/Door43/en_tn/src/master/gen/07/13.md)
* [Genesis 10:1](https://git.door43.org/Door43/en_tn/src/master/gen/10/01.md)

### Word Data:

* Strong's: H3315


## <a id="tw-term-names-jebusites"/>Jebus, Jebusite, Jebusites

### Facts:

The Jebusites were a people group living in the land of Canaan. They were descended from Ham's son Canaan.

* The Jebusites lived in the city of Jebus, and its name was later changed to Jerusalem when King David conquered it.
* Melchizedek, the king of Salem, was probably of Jebusite origin.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Canaan](#canaan), [Ham](#ham), [Jerusalem](#jerusalem), [Melchizedek](#melchizedek))

### Bible References:

* [1 Chronicles 01:13-16](https://git.door43.org/Door43/en_tn/src/master/1ch/01/13.md)
* [1 Kings 09:20-21](https://git.door43.org/Door43/en_tn/src/master/1ki/09/20.md)
* [Exodus 03:7-8](https://git.door43.org/Door43/en_tn/src/master/exo/03/07.md)
* [Genesis 10:15-18](https://git.door43.org/Door43/en_tn/src/master/gen/10/15.md)
* [Joshua 03:9-11](https://git.door43.org/Door43/en_tn/src/master/jos/03/09.md)
* [Judges 01:20-21](https://git.door43.org/Door43/en_tn/src/master/jdg/01/20.md)

### Word Data:

* Strong's: H2982, H2983


## <a id="tw-term-names-jehoiachin"/>Jehoiachin

### Facts:

Jehoiachin was a king who ruled over the kingdom of Judah.

* Jehoiachin became king when he was 18 years old. He only reigned three months, and after that he was captured by the Babylonian army and taken to Babylon.
* During his short reign, Jehoiachin did evil things like the ones his grandfather King Manasseh and his father King Jehoiakim had done.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Babylon](#babylon), [Jehoiakim](#jehoiakim), [Judah](#kingdomofjudah), [Manasseh](#manasseh))

### Bible References:

* [2 Chronicles 36:8](https://git.door43.org/Door43/en_tn/src/master/2ch/36/08.md)
* [2 Kings 24:15-17](https://git.door43.org/Door43/en_tn/src/master/2ki/24/15.md)
* [Esther 02:5-6](https://git.door43.org/Door43/en_tn/src/master/est/02/05.md)
* [Ezekiel 01:1-3](https://git.door43.org/Door43/en_tn/src/master/ezk/01/01.md)
* [Jeremiah 22:24-26](https://git.door43.org/Door43/en_tn/src/master/jer/22/24.md)
* [Jeremiah 37:1-2](https://git.door43.org/Door43/en_tn/src/master/jer/37/01.md)

### Word Data:

* Strong's: H3078, H3112, H3204, H3659


## <a id="tw-term-names-jehoiada"/>Jehoiada

### Facts:

Jehoiada was a priest who helped hide and protect King Ahaziah's son Joash until he was old enough to be declared king.

* Jehoiada arranged for hundreds of bodyguards to protect young Joash as he was proclaimed king by the people in the temple.
* Jehoiada led the people in getting rid of all the altars of the false god Baal.
* For the rest of his life, Jehoiada the priest advised King Joash to help him obey God and rule the people wisely.
* Another man named Jehoiada was the father of Benaiah.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Ahaziah](#ahaziah), [Baal](#baal), [Benaiah](#benaiah), [Joash](#joash))

### Bible References:

* [2 Kings 11:4-6](https://git.door43.org/Door43/en_tn/src/master/2ki/11/04.md)
* [2 Kings 12:1-3](https://git.door43.org/Door43/en_tn/src/master/2ki/12/01.md)

### Word Data:

* Strong's: H3077, H3111


## <a id="tw-term-names-jehoiakim"/>Jehoiakim

### Facts:

Jehoiakim was an evil king who reigned over the kingdom of Judah, beginning around 608 B.C. He was King Josiah's son. His name was originally Eliakim.

* The Egyptian pharaoh Necho changed Eliakim's name to Jehoiakim and made him king of Judah.
* Necho forced Jehoiakim to pay high taxes to Egypt.
* When Judah was later invaded by King Nebuchadnezzar, Jehioakim was among those who were captured and taken to Babylon.
* Jehoiakim was an evil king who led Judah away from Yahweh. Jeremiah the prophet prophesied against him.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Babylon](#babylon), [Eliakim](#eliakim), [Jeremiah](#jeremiah), [Judah](#kingdomofjudah), [Nebuchadnezzar](#nebuchadnezzar))

### Bible References:

* [1 Chronicles 03:15-16](https://git.door43.org/Door43/en_tn/src/master/1ch/03/15.md)
* [2 Kings 23:34-35](https://git.door43.org/Door43/en_tn/src/master/2ki/23/34.md)
* [2 Kings 24:1-2](https://git.door43.org/Door43/en_tn/src/master/2ki/24/01.md)
* [Daniel 01:1-2](https://git.door43.org/Door43/en_tn/src/master/dan/01/01.md)
* [Jeremiah 01:1-3](https://git.door43.org/Door43/en_tn/src/master/jer/01/01.md)

### Word Data:

* Strong's: H3079


## <a id="tw-term-names-jehoram"/>Jehoram, Joram

### Facts:

"Jehoram" was the name of two kings in the Old Testament. Both kings were also known as "Joram."

* One King Jehoram ruled over the kingdom of Judah for eight years. He was the son of King Jehoshaphat. This is the king that is most commonly known as Jehoram.
* The other King Jehoram ruled over the kingdom of Israel for twelve years. He was the son of King Ahab.
* King Jehoram of Judah reigned during the time that the prophets Jeremiah, Daniel, Obadiah, and Ezekiel were prophesying in the kingdom of Judah.
* The King Jehoram also reigned during some of the time that his father King Jehoshaphat was reigning over Judah.
* Some translations may choose to consistently use the name "Jehoram" when this king of Israel is mentioned and the name "Joram" for the king of Judah.
* Another way to clearly identify each one would be to include the name of his father.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Ahab](#ahab), [Jehoshaphat](#jehoshaphat), [Joram](#joram), [Judah](#judah), [kingdom of Israel](#kingdomofisrael), [Obadiah](#obadiah))

### Bible References:

* [1 Kings 22:48-50](https://git.door43.org/Door43/en_tn/src/master/1ki/22/48.md)
* [2 Chronicles 21:1-3](https://git.door43.org/Door43/en_tn/src/master/2ch/21/01.md)
* [2 Kings 11:1-3](https://git.door43.org/Door43/en_tn/src/master/2ki/11/01.md)
* [2 Kings 12:17-18](https://git.door43.org/Door43/en_tn/src/master/2ki/12/17.md)

### Word Data:

* Strong's: H3088, H3141, G2496


## <a id="tw-term-names-jehoshaphat"/>Jehoshaphat

### Facts:

Jehoshaphat was the name of at least two men in the Old Testament.

* The best known man by this name was King Jehoshaphat who was the fourth king to rule over the kingdom of Judah.
* He restored peace between Judah and Israel and destroyed the altars of false gods.
* Another Jehoshaphat was a "recorder" for David and Solomon. His job included writing documents for the king to sign and recording the history of the important events that happened in the kingdom.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [altar](kt.html#altar), [David](#david), [false god](kt.html#falsegod), [Israel](kt.html#israel), [Judah](#judah), [priest](kt.html#priest), [Solomon](#solomon))

### Bible References:

* [1 Chronicles 03:10-12](https://git.door43.org/Door43/en_tn/src/master/1ch/03/10.md)
* [1 Kings 04:15-17](https://git.door43.org/Door43/en_tn/src/master/1ki/04/15.md)
* [2 Chronicles 17:1-2](https://git.door43.org/Door43/en_tn/src/master/2ch/17/01.md)
* [2 Kings 01:17-18](https://git.door43.org/Door43/en_tn/src/master/2ki/01/17.md)
* [2 Samuel 08:15-18](https://git.door43.org/Door43/en_tn/src/master/2sa/08/15.md)
* [Matthew 01:7-8](https://git.door43.org/Door43/en_tn/src/master/mat/01/07.md)

### Word Data:

* Strong's: H3092, H3146, G2498


## <a id="tw-term-names-jehu"/>Jehu

### Facts:

Jehu was the name of two men in the Old Testament.

* Jehu son of Hanani was a prophet during the reigns of King Ahab of Israel and King Jehoshaphat of Judah.
* Jehu son (or descendant) of Jehoshaphat was a general in the Israelite army who was anointed king by order of the prophet Elisha.
* King Jehu killed two evil kings,  King Joram of Israel and King Ahaziah of Judah.
* King Jehu also killed all the relatives of the former King Ahab and had the evil queen Jezebel killed.
* King Jehu destroyed all the places of Baal worship in Samaria and killed all the prophets of Baal.
* King Jehu served the only true God, Yahweh, and was king over Israel for twenty-eight years.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Ahab](#ahab), [Ahaziah](#ahaziah), [Baal](#baal), [Elisha](#elisha), [Jehoshaphat](#jehoshaphat), [Jehu](#jehu), [Jezebel](#jezebel), [Joram](#joram), [Judah](#kingdomofjudah), [Samaria](#samaria))

### Bible References:

* [1 Chronicles 04:34-38](https://git.door43.org/Door43/en_tn/src/master/1ch/04/34.md)
* [1 Kings 16:1-2](https://git.door43.org/Door43/en_tn/src/master/1ki/16/01.md)
* [2 Chronicles 19:1-3](https://git.door43.org/Door43/en_tn/src/master/2ch/19/01.md)
* [2 Kings 10:8-9](https://git.door43.org/Door43/en_tn/src/master/2ki/10/08.md)
* [Hosea 01:3-5](https://git.door43.org/Door43/en_tn/src/master/hos/01/03.md)

### Word Data:

* Strong's: H3058


## <a id="tw-term-names-jephthah"/>Jephthah

### Facts:

Jephthah was a warrior from Gilead who served as a judge over Israel.

* In Hebrews 11:32, Jephthah is praised as an important leader who delivered his people from their enemies.
* He rescued the Israelites from the Ammonites and led his people to defeat the Ephraimites.
* Jepthah however, made a foolish, hasty vow to God which resulted in the sacrifice of his daughter.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Ammon](#ammon), [deliver](other.html#deliverer), [Ephraim](#ephraim), [judge](other.html#judgeposition), [vow](kt.html#vow))

### Bible References:

* [Hebrews 11:32-34](https://git.door43.org/Door43/en_tn/src/master/heb/11/32.md)
* [Judges 11:1-3](https://git.door43.org/Door43/en_tn/src/master/jdg/11/01.md)
* [Judges 11:34-35](https://git.door43.org/Door43/en_tn/src/master/jdg/11/34.md)
* [Judges 12:1-2](https://git.door43.org/Door43/en_tn/src/master/jdg/12/01.md)

### Word Data:

* Strong's: H3316


## <a id="tw-term-names-jeremiah"/>Jeremiah

### Facts:

Jeremiah was a prophet of God in the kingdom of Judah. The Old Testament book of Jeremiah contains his prophecies.

* Like most of the prophets, Jeremiah often had to warn the people of Israel that God was going to punish them for their sins.
* Jeremiah prophesied that the Babylonians would capture Jerusalem, making some of the people of Judah angry. So they put him in a deep, dry well and left him there to die. But the king of Judah ordered his servants to rescue Jeremiah from the well.
* Jeremiah wrote that he wished his eyes could be a "fountain of tears," to express his deep sadness over the rebellion and sufferings of his people.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Babylon](#babylon), [Judah](#kingdomofjudah), [prophet](kt.html#prophet), [rebel](other.html#rebel), [suffer](other.html#suffer), [well](other.html#well))

### Bible References:

* [2 Chronicles 35:25](https://git.door43.org/Door43/en_tn/src/master/2ch/35/25.md)
* [Jeremiah 01:1-3](https://git.door43.org/Door43/en_tn/src/master/jer/01/01.md)
* [Jeremiah 11:1-2](https://git.door43.org/Door43/en_tn/src/master/jer/11/01.md)
* [Matthew 02:17-18](https://git.door43.org/Door43/en_tn/src/master/mat/02/17.md)
* [Matthew 16:13-16](https://git.door43.org/Door43/en_tn/src/master/mat/16/13.md)
* [Matthew 27:9-10](https://git.door43.org/Door43/en_tn/src/master/mat/27/09.md)

### Examples from the Bible stories:

  __*[19:17](https://git.door43.org/Door43/en_tn/src/master/obs/19/17.md)__ Once, the prophet __Jeremiah__ was put into a dry well and left there to die. He sank down into the mud that was in the bottom of the well, but then the king had mercy on him and ordered his servants to pull __Jeremiah__ out of the well before he died.
  __*[21:05](https://git.door43.org/Door43/en_tn/src/master/obs/21/05.md)__ Through the prophet __Jeremiah__, God promised that he would make a New Covenant, but not like the covenant God made with Israel at Sinai.

### Word Data:

* Strong's: H3414, G2408


## <a id="tw-term-names-jericho"/>Jericho

### Facts:

Jericho was a powerful city in the land of Canaan. It was located just west of the Jordan River and just north of the Salt Sea.

* As all Canaanites did, the people of Jericho worshiped false gods.
* Jericho was the first city in the land of Canaan that God told the Israelites to conquer.
* When Joshua led the Israelites against Jericho, God did a great miracle to help them defeat the city.

(See also: [Canaan](#canaan), [Jordan River](#jordanriver), [Joshua](#joshua), [miracle](kt.html#miracle), [Salt Sea](#saltsea))

### Bible References:

* [1 Chronicles 06:77-79](https://git.door43.org/Door43/en_tn/src/master/1ch/06/77.md)
* [Joshua 02:1-3](https://git.door43.org/Door43/en_tn/src/master/jos/02/01.md)
* [Joshua 07:2-3](https://git.door43.org/Door43/en_tn/src/master/jos/07/02.md)
* [Luke 18:35-37](https://git.door43.org/Door43/en_tn/src/master/luk/18/35.md)
* [Mark 10:46-48](https://git.door43.org/Door43/en_tn/src/master/mrk/10/46.md)
* [Matthew 20:29-31](https://git.door43.org/Door43/en_tn/src/master/mat/20/29.md)
* [Numbers 22:1](https://git.door43.org/Door43/en_tn/src/master/num/22/01.md)

### Examples from the Bible stories:

  __*[15:01](https://git.door43.org/Door43/en_tn/src/master/obs/15/01.md)__ Joshua sent two spies to the Canaanite city of __Jericho__.
  __*[15:03](https://git.door43.org/Door43/en_tn/src/master/obs/15/03.md)__ After the people crossed the Jordan River, God told Joshua how to attack the powerful city of __Jericho__.
  __*[15:05](https://git.door43.org/Door43/en_tn/src/master/obs/15/05.md)__ Then the walls around __Jericho__ fell down! The Israelites destroyed everything in the city as God had commanded.

### Word Data:

* Strong's: H3405, G2410


## <a id="tw-term-names-jeroboam"/>Jeroboam

### Facts:

Jeroboam son of Nebat was the first king of the northern kingdom of Israel around 900-910 BC. Another Jeroboam, son of King Jehoash, ruled over Israel about 120 years later.

* Yahweh gave Jeroboam son of Nebat a prophecy that he would become king after Solomon and that he would rule ten tribes of Israel.
* When Solomon died, the ten northern tribes of Israel rebelled against Solomon's son Rehoboam and instead made Jeroboam their king, leaving Rehoboam as king of only the southern two tribes, Judah and Benjamin.
* Jeroboam became a wicked king who led the people away from worshiping Yahweh and instead set up idols for them to worship. All the other kings of Israel followed Jeroboam's example and were evil like he was.
* Almost 120 years later, another King Jeroboam began ruling the northern kingdom of Israel. This Jeroboam was the son of King Jehoash and was wicked like all the previous kings of Israel had been.
* In spite of the Israelite's wickedness, God had mercy on them and helped this King Jeroboam to gain land and establish boundaries for their territory.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [false god](kt.html#falsegod), [kingdom of Israel](#kingdomofisrael), [Judah](#kingdomofjudah), [Solomon](#solomon))

### Bible References:

* [1 Chronicles 05:16-17](https://git.door43.org/Door43/en_tn/src/master/1ch/05/16.md)
* [1 Kings 12:1-2](https://git.door43.org/Door43/en_tn/src/master/1ki/12/01.md)
* [2 Chronicles 09:29-31](https://git.door43.org/Door43/en_tn/src/master/2ch/09/29.md)
* [2 Kings 03:1-3](https://git.door43.org/Door43/en_tn/src/master/2ki/03/01.md)
* [Amos 01:1-2](https://git.door43.org/Door43/en_tn/src/master/amo/01/01.md)

### Examples from the Bible stories:

* __[18:08](https://git.door43.org/Door43/en_tn/src/master/obs/18/08.md)__ The other ten tribes of the nation of Israel that rebelled against Rehoboam appointed a man named __Jeroboam__  to be their king.
* __[18:09](https://git.door43.org/Door43/en_tn/src/master/obs/18/09.md)__ __Jeroboam__  rebelled against God and caused the people to sin. He built two idols for his people to worship instead of worshiping God at the Temple in the kingdom of Judah.

### Word Data:

* Strong's: H3379


## <a id="tw-term-names-jerusalem"/>Jerusalem

### Facts:

Jerusalem was originally an ancient Canaanite city that later became the most important city in Israel. It is located about 34 kilometers west of the Salt Sea and just north of Bethlehem. It is still the capital city of Israel today.

* The name "Jerusalem" is first mentioned in the book of Joshua. Other Old Testament names for this city include "Salem" "city of Jebus," and "Zion." Both "Jerusalem" and "Salem," have the root meaning of "peace."
* Jerusalem was originally a Jebusite fortress called "Zion" which King David captured and made into his capital city. 
* It was in Jerusalem that David's son Solomon built the first temple in Jerusalem, on Mount Moriah, which was the mountain where Abraham had offered his son Isaac to God. The temple was rebuilt there after it was destroyed by the Babylonians.
* Because the temple was in Jerusalem, the major Jewish festivals were celebrated there.
* People normally referred to going "up" to Jerusalem since it is located in the mountains.

(See also: [Babylon](#babylon), [Christ](kt.html#christ), [David](#david), [Jebusites](#jebusites), [Jesus](kt.html#jesus), [Solomon](#solomon), [temple](kt.html#temple), [Zion](kt.html#zion))

### Bible References:

* [Galatians 04:26-27](https://git.door43.org/Door43/en_tn/src/master/gal/04/26.md)
* [John 02:13-14](https://git.door43.org/Door43/en_tn/src/master/jhn/02/13.md)
* [Luke 04:9-11](https://git.door43.org/Door43/en_tn/src/master/luk/04/09.md)
* [Luke 13:4-5](https://git.door43.org/Door43/en_tn/src/master/luk/13/04.md)
* [Mark 03:7-8](https://git.door43.org/Door43/en_tn/src/master/mrk/03/07.md)
* [Mark 03:20-22](https://git.door43.org/Door43/en_tn/src/master/mrk/03/20.md)
* [Matthew 03:4-6](https://git.door43.org/Door43/en_tn/src/master/mat/03/04.md)
* [Matthew 04:23-25](https://git.door43.org/Door43/en_tn/src/master/mat/04/23.md)
* [Matthew 20:17-19](https://git.door43.org/Door43/en_tn/src/master/mat/20/17.md)

### Examples from the Bible stories:

* __[17:05](https://git.door43.org/Door43/en_tn/src/master/obs/17/05.md)__ David conquered __Jerusalem__  and made it his capital city.
* __[18:02](https://git.door43.org/Door43/en_tn/src/master/obs/18/02.md)__ In __Jerusalem__, Solomon built the Temple for which his father David had planned and gathered materials.
* __[20:07](https://git.door43.org/Door43/en_tn/src/master/obs/20/07.md)__ They (Babylonians) captured the city of __Jerusalem__, destroyed the Temple, and took away all the treasures of the city and the Temple.
* __[20:12](https://git.door43.org/Door43/en_tn/src/master/obs/20/12.md)__ So, after seventy years in exile, a small group of Jews returned to the city of __Jerusalem__  in Judah.
* __[38:01](https://git.door43.org/Door43/en_tn/src/master/obs/38/01.md)__ About three years after Jesus first began preaching and teaching publicly, Jesus told his disciples that he wanted to celebrate this Passover with them in __Jerusalem__, and that he would be killed there.
* __[38:02](https://git.door43.org/Door43/en_tn/src/master/obs/38/02.md)__ After Jesus and the disciples arrived in __Jerusalem__, Judas went to the Jewish leaders and offered to betray Jesus to them in exchange for money.
* __[42:08](https://git.door43.org/Door43/en_tn/src/master/obs/42/08.md)__ "It was also written in the scriptures that my disciples will proclaim that everyone should repent in order to receive forgiveness for their sins. They will do this starting in __Jerusalem__, and then go to all people groups everywhere."
* __[42:11](https://git.door43.org/Door43/en_tn/src/master/obs/42/11.md)__ Forty days after Jesus rose from the dead, he told his disciples, "Stay in __Jerusalem__  until you receive power when the Holy Spirit comes on you."

### Word Data:

* Strong's: H3389, H3390, G2414, G2415, G2419


## <a id="tw-term-names-jesse"/>Jesse

### Facts:

Jesse was the father of King David and the grandson of Ruth and Boaz.

* Jesse was from the tribe of Judah.
* He was an "Ephrathite," which means he was from the town of Ephrathah (Bethlehem).
* The prophet Isaiah prophesied about a "shoot" or "branch" that would come from the "root of Jesse" and bear fruit. This refers to Jesus, who was a descendant of Jesse.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Bethlehem](#bethlehem), [Boaz](#boaz), [descendant](other.html#descendant), [fruit](other.html#fruit), [Jesus](kt.html#jesus), [king](other.html#king), [prophet](kt.html#prophet), [Ruth](#ruth), [twelve tribes of Israel](other.html#12tribesofisrael))

### Bible References:

* [1 Chronicles 02:9-12](https://git.door43.org/Door43/en_tn/src/master/1ch/02/09.md)
* [1 Kings 12:16-17](https://git.door43.org/Door43/en_tn/src/master/1ki/12/16.md)
* [1 Samuel 16:1](https://git.door43.org/Door43/en_tn/src/master/1sa/16/01.md)
* [Luke 03:30-32](https://git.door43.org/Door43/en_tn/src/master/luk/03/30.md)
* [Matthew 01:4-6](https://git.door43.org/Door43/en_tn/src/master/mat/01/04.md)

### Word Data:

* Strong's: H3448, G2421


## <a id="tw-term-names-jethro"/>Jethro, Reuel

### Facts:

The names "Jethro" and "Reuel" both refer to the father of Moses' wife, Zipporah. There were also two other men named "Reuel" in the Old Testament.

* When Moses was a shepherd in the land of Midian, he married the daughter of a Midianite man named Reuel.
* Later on Reuel is referred to as "Jethro, the priest of Midian."  It could be that "Reuel" was his clan name.
* When God spoke to Moses from a flaming bush, Moses was tending Jethro's sheep, 
* Some time later, after God had rescued the Israelites from Egypt, Jethro came out to the Israelites in the wilderness and gave Moses good advice about judging the affairs of the people.
* He believed in God when he heard about all the miracles God had done for the Israelites in Egypt.
* One of Esau's sons was named Reuel.
* Another man named Reuel is mentioned in the genealogy of the Israelites who returned to resettle in Judah after their captivity in Babylon had ended. 

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [captive](other.html#captive), [clan](other.html#clan), [desert](other.html#desert), [Egypt](#egypt), [Esau](#esau), [miracle](kt.html#miracle), [Moses](#moses), [desert](other.html#desert))

### Bible References:

* [1 Chronicles 01:34-37](https://git.door43.org/Door43/en_tn/src/master/1ch/01/34.md)
* [Exodus 02:18-20](https://git.door43.org/Door43/en_tn/src/master/exo/02/18.md)
* [Exodus 03:1-3](https://git.door43.org/Door43/en_tn/src/master/exo/03/01.md)
* [Exodus 18:1-4](https://git.door43.org/Door43/en_tn/src/master/exo/18/01.md)
* [Numbers 10:29-30](https://git.door43.org/Door43/en_tn/src/master/num/10/29.md)

### Word Data:

* Strong's: H3503, H7467


## <a id="tw-term-names-jezebel"/>Jezebel

### Facts:

Jezebel was the wicked wife of King Ahab of Israel.

* Jezebel influenced Ahab and the rest of Israel to worship idols.
* She also killed many of God's prophets.
* Jezebel caused an innocent man named Naboth to be killed so that Ahab could steal Naboth's vineyard.
* Jezebel was finally killed due to all the evil things she had done. Elijah prophesied about how she would die and it happened exactly as he had predicted.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Ahab](#ahab), [Elijah](#elijah), [false god](kt.html#falsegod))

### Bible References:

* [1 Kings 16:31-33](https://git.door43.org/Door43/en_tn/src/master/1ki/16/31.md)
* [1 Kings 19:1-3](https://git.door43.org/Door43/en_tn/src/master/1ki/19/01.md)
* [2 Kings 09:7-8](https://git.door43.org/Door43/en_tn/src/master/2ki/09/07.md)
* [2 Kings 09:30-32](https://git.door43.org/Door43/en_tn/src/master/2ki/09/30.md)
* [Revelation 02:20-21](https://git.door43.org/Door43/en_tn/src/master/rev/02/20.md)

### Word Data:

* Strong's: H348, G2403


## <a id="tw-term-names-jezreel"/>Jezreel, Jezreelite

### Definition:

Jezreel was an important Israelite city in the territory of the Issachar tribe, located southwest of the Salt Sea.

* The city of Jezreel is one of the western points in the Plain of Megiddo, which is also called the "Valley of Jezreel."
* Several kings of Israel had their palaces in the city of Jezreel.
* Naboth's vineyard was located near King Ahab's palace in Jezreel. The prophet Elijah prophesied against Ahab there.
* Ahab's evil wife Jezebel was killed in Jezreel.
* Many other significant events happened in this city, including several battles.

(See also: [Ahab](#ahab), [Elijah](#elijah), [Issachar](#issachar), [Jezebel](#jezebel), [palace](other.html#palace), [Salt Sea](#saltsea))

### Bible References:

* [1 Kings 04:11-14](https://git.door43.org/Door43/en_tn/src/master/1ki/04/11.md)
* [1 Samuel 25:43-44](https://git.door43.org/Door43/en_tn/src/master/1sa/25/43.md)
* [2 Kings 08:28-29](https://git.door43.org/Door43/en_tn/src/master/2ki/08/28.md)
* [2 Samuel 02:1-3](https://git.door43.org/Door43/en_tn/src/master/2sa/02/01.md)
* [Judges 06:33](https://git.door43.org/Door43/en_tn/src/master/jdg/06/33.md)

### Word Data:

* Strong's: H3157, H3158, H3159


## <a id="tw-term-names-joab"/>Joab

### Definition:

Joab was an important military leader for King David throughout David's entire reign. 

* Before David became king, Joab had already been one of his loyal followers.
* Later, during David's reign as king over Israel, Joab became the commander of King David's army.
* Joab was also King David's nephew, since his mother was one of David's sisters.
* When David's son Absalom betrayed him by trying to take over his kingship, Joab killed Absalom in order to protect the king.
* Joab was a very aggressive fighter and killed many people who were enemies of Israel.

(See also: [Absalom](#absalom), [David](#david))

### Bible References:

* [1 Chronicles 02:16-17](https://git.door43.org/Door43/en_tn/src/master/1ch/02/16.md)
* [1 Kings 01:7-8](https://git.door43.org/Door43/en_tn/src/master/1ki/01/07.md)
* [1 Samuel 26:6-8](https://git.door43.org/Door43/en_tn/src/master/1sa/26/06.md)
* [2 Samuel 02:18-19](https://git.door43.org/Door43/en_tn/src/master/2sa/02/18.md)
* [Nehemiah 07:11-14](https://git.door43.org/Door43/en_tn/src/master/neh/07/11.md)

### Word Data:

* Strong's: H3097


## <a id="tw-term-names-joash"/>Joash

### Facts:

Joash was the name of several men in the Old Testament.

* One Joash was the father of the Israelite deliverer Gideon.
* Another man named Joash was a descendant of Jacob's youngest son, Benjamin.
* The most well-known Joash became king of Judah at the age of seven. He was the son of Ahaziah, king of Judah, who had been murdered. 
* When Joash was a very young child, his aunt saved him from being killed by hiding him away until he was old enough to be crowned king.
* King Joash was a good king who at first obeyed God. But he did not remove the high places, and the Israelites started worshiping idols again.   
* King Joash ruled Judah during some of the years that King Jehoash was ruling Israel. They were two distinct kings.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Ahaziah](#ahaziah), [altar](kt.html#altar), [Benjamin](#benjamin), [false god](kt.html#falsegod), [Gideon](#gideon), [high places](other.html#highplaces), [false god](kt.html#falsegod))

### Bible References:

* [1 Chronicles 03:10-12](https://git.door43.org/Door43/en_tn/src/master/1ch/03/10.md)
* [2 Chronicles 18:25-27](https://git.door43.org/Door43/en_tn/src/master/2ch/18/25.md)
* [2 Kings 11:1-3](https://git.door43.org/Door43/en_tn/src/master/2ki/11/01.md)
* [Amos 01:1-2](https://git.door43.org/Door43/en_tn/src/master/amo/01/01.md)
* [Judges 06:11-12](https://git.door43.org/Door43/en_tn/src/master/jdg/06/11.md)

### Word Data:

* Strong's: H3101, H3135


## <a id="tw-term-names-job"/>Job

### Facts:

Job was a man who is described in the Bible as blameless and righteous before God. He is best known for persevering in his faith in God through times of terrible suffering.

* Job lived in the land of Uz, which was located somewhere east of the land of Canaan, possibly near the region of the Edomites.
* It is thought that he lived during the time of Esau and Jacob because one of Job's friends was a "Temanite," which was a people group named after Esau's grandson.
* The Old Testament book of Job tells about how Job and others responded to his suffering. It also gives God's viewpoint as the sovereign creator and ruler of the universe.
* After all the disasters, God eventually healed Job and gave him more children and wealth.
* The book of Job says that he was very old when he died.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Abraham](#abraham), [Esau](#esau), [flood](other.html#flood), [Jacob](#jacob)[Noah](#noah), [people group](other.html#peoplegroup))

### Bible References:

* [Ezekiel 14:12-14](https://git.door43.org/Door43/en_tn/src/master/ezk/14/12.md)
* [James 05:9-11](https://git.door43.org/Door43/en_tn/src/master/jas/05/09.md)
* [Job 01:1-3](https://git.door43.org/Door43/en_tn/src/master/job/01/01.md)
* [Job 03:4-5](https://git.door43.org/Door43/en_tn/src/master/job/03/04.md)

### Word Data:

* Strong's: H347, H3102, G2492


## <a id="tw-term-names-joel"/>Joel

### Facts:

Joel was a prophet who probably lived during the reign of King Joash of Judah. There were also several other men in the Old Testament named Joel.

* The book of Joel is one of twelve short prophetic books in the last section of the Old Testament.
* The only personal information we have about the prophet Joel is that his father's name was Pethuel.
* In his sermon at Pentecost, the apostle Peter quoted from the book of Joel.
* 

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Joash](#joash), [Judah](#kingdomofjudah), [Pentecost](kt.html#pentecost))

### Bible References:

* [1 Chronicles 06:33-35](https://git.door43.org/Door43/en_tn/src/master/1ch/06/33.md)
* [1 Samuel 08:1-3](https://git.door43.org/Door43/en_tn/src/master/1sa/08/01.md)
* [Acts 02:16-17](https://git.door43.org/Door43/en_tn/src/master/act/02/16.md)
* [Ezra 10:41-44](https://git.door43.org/Door43/en_tn/src/master/ezr/10/41.md)
* [Joel 01:1-3](https://git.door43.org/Door43/en_tn/src/master/jol/01/01.md)

### Word Data:

* Strong's: H3100, G2493


## <a id="tw-term-names-johnmark"/>John Mark

### Facts:

John Mark, also known as "Mark," was one of the men who traveled with Paul on his missionary journeys. He is most likely the author of the Gospel of Mark.

* John Mark accompanied his cousin Barnabas and Paul on their first missionary journey.
* When Peter was put in prison in Jerusalem, the believers there were praying for him at John Mark's mother's house.
* Mark was not an apostle, but was taught by both Paul and Peter and worked together with them in ministry.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Barnabas](#barnabas), [Paul](#paul))

### Bible References:

* [2 Timothy 04:11-13](https://git.door43.org/Door43/en_tn/src/master/2ti/04/11.md)
* [Acts 12:24-25](https://git.door43.org/Door43/en_tn/src/master/act/12/24.md)
* [Acts 13:4-5](https://git.door43.org/Door43/en_tn/src/master/act/13/04.md)
* [Acts 13:13-15](https://git.door43.org/Door43/en_tn/src/master/act/13/13.md)
* [Acts 15:36-38](https://git.door43.org/Door43/en_tn/src/master/act/15/36.md)
* [Acts 15:39-41](https://git.door43.org/Door43/en_tn/src/master/act/15/39.md)
* [Colossians 04:10-11](https://git.door43.org/Door43/en_tn/src/master/col/04/10.md)

### Word Data:

* Strong's: G2491, G3138


## <a id="tw-term-names-johntheapostle"/>John (the apostle)

### Facts:

John was one of Jesus' twelve apostles and one of Jesus' closest friends. 

* John and his brother James were sons of a fisherman named Zebedee.
* In the gospel that he wrote about Jesus' life, John referred to himself as "the disciple whom Jesus loved." This seems to indicate that John was an especially close friend of Jesus.
* The apostle John wrote five New Testament books: the gospel of John, the Revelation of Jesus Christ, and three letters written to other believers.
* Note that the apostle John was a different person than John the Baptist.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [apostle](kt.html#apostle), [reveal](kt.html#reveal), [James (son of Zebedee)](#jamessonofzebedee), [John (the Baptist)](#johnthebaptist), [Zebedee](#zebedee))

### Bible References:

* [Galatians 02:9-10](https://git.door43.org/Door43/en_tn/src/master/gal/02/09.md)
* [John 01:19-21](https://git.door43.org/Door43/en_tn/src/master/jhn/01/19.md)
* [Mark 03:17-19](https://git.door43.org/Door43/en_tn/src/master/mrk/03/17.md)
* [Matthew 04:21-22](https://git.door43.org/Door43/en_tn/src/master/mat/04/21.md)
* [Revelation 01:1-3](https://git.door43.org/Door43/en_tn/src/master/rev/01/01.md)

### Examples from the Bible stories:

  __*[36:01](https://git.door43.org/Door43/en_tn/src/master/obs/36/01.md)__ One day, Jesus took three of his disciples, Peter, James, and __John__ with him. (The disciple named __John__ was not the same person who baptized Jesus.) They went up on a high mountain by themselves.\\
  __*[44:01](https://git.door43.org/Door43/en_tn/src/master/obs/44/01.md)__ One day, Peter and __John__ were going to the Temple. As they approached the Temple gate, they saw a crippled man who was begging for money.\\
  __*[44:06](https://git.door43.org/Door43/en_tn/src/master/obs/44/06.md)__ The leaders of the Temple were very upset by what Peter and __John__ were saying. So they arrested them and put them into prison.\\
  __*[44:07](https://git.door43.org/Door43/en_tn/src/master/obs/44/07.md)__ The next day, the Jewish leaders brought Peter and __John__ to the high priest and the other religious leaders. They asked Peter and __John__, "By what power did you heal this crippled man?"\\
  __*[44:09](https://git.door43.org/Door43/en_tn/src/master/obs/44/09.md)__ The leaders were shocked that Peter and __John__ spoke so boldly because they could see that these men were ordinary men who were uneducated. But then they remembered that these men had been with Jesus. After they threatened Peter and __John__, they let them go.

### Word Data:

* Strong's: G2491


## <a id="tw-term-names-johnthebaptist"/>John (the Baptist)

### Facts:

John was the son of Zechariah and Elizabeth. Since "John" was a common name, he is often called "John the Baptist" to distinguish him from the other people named John, such as the Apostle John.

* John was the prophet whom God sent to prepare people to believe in and follow the Messiah. 
* John told people to confess their sins, turn to God, and stop sinning, so that they would be ready to receive the Messiah. 
* John baptized many people in water as a sign that they were sorry for their sins and were turning away from them.  
* John was called "John the Baptist" because he baptized many people. 

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [baptize](kt.html#baptize), [Zechariah (NT)](#zechariahnt))

 
### Bible References:

* [John 03:22-24](https://git.door43.org/Door43/en_tn/src/master/jhn/03/22.md)
* [Luke 01:11-13](https://git.door43.org/Door43/en_tn/src/master/luk/01/11.md)
* [Luke 01:62-63](https://git.door43.org/Door43/en_tn/src/master/luk/01/62.md)
* [Luke 03:7](https://git.door43.org/Door43/en_tn/src/master/luk/03/07.md)
* [Luke 03:15-16](https://git.door43.org/Door43/en_tn/src/master/luk/03/15.md)
* [Luke 07:27-28](https://git.door43.org/Door43/en_tn/src/master/luk/07/27.md)
* [Matthew 03:13-15](https://git.door43.org/Door43/en_tn/src/master/mat/03/13.md)
* [Matthew 11:13-15](https://git.door43.org/Door43/en_tn/src/master/mat/11/13.md)

### Examples from the Bible stories:

  __*[22:02](https://git.door43.org/Door43/en_tn/src/master/obs/22/02.md)__ The angel said to Zechariah, "Your wife will have a son. You will name him __John__. He will be filled with the Holy Spirit, and will prepare the people for Messiah!"
  __*[22:07](https://git.door43.org/Door43/en_tn/src/master/obs/22/07.md)__ After Elizabeth gave birth to her baby boy, Zechariah and Elizabeth named the baby __John__, as the angel had commanded. 
  __*[24:01](https://git.door43.org/Door43/en_tn/src/master/obs/24/01.md)__ __John__, the son of Zechariah and Elizabeth, grew up and became a prophet. He lived in the wilderness, ate wild honey and locusts, and wore clothes made from camel hair.
  __*[24:02](https://git.door43.org/Door43/en_tn/src/master/obs/24/02.md)__ Many people came out to the wilderness to listen to __John__. He preached to them, saying, "Repent, for the kingdom of God is near!"
  __*[24:06](https://git.door43.org/Door43/en_tn/src/master/obs/24/06.md)__ The next day, Jesus came to be baptized by __John__. When __John__ saw him, he said, "Look! There is the Lamb of God who will take away the sin of the world."

### Word Data:

* Strong's: G910 G2491


## <a id="tw-term-names-jonah"/>Jonah

### Definition:

Jonah was a Hebrew prophet in the Old Testament.

* The book of Jonah tells the story of what happened when God sent Jonah to preach to the people of Nineveh.
* Jonah refused to go to Nineveh and instead got on a ship headed for a Tarshish.
* God caused a huge storm to overwhelm that ship.
* He told the men sailing the ship that he wasrunning away from God, and he suggested that they throw him into the sea. When they did the storm stopped.
* Jonah was swallowed by a huge fish, and he was inside the belly of that fish for three days and nights.
* After that, Jonah went to Nineveh and preached to the people there, and they turned from their sins.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [disobey](other.html#disobey), [Nineveh](#nineveh), [turn](other.html#turn))

### Bible References:

* [Jonah 01:1-3](https://git.door43.org/Door43/en_tn/src/master/jon/01/01.md)
* [Luke 11:29-30](https://git.door43.org/Door43/en_tn/src/master/luk/11/29.md)
* [Matthew 12:38-40](https://git.door43.org/Door43/en_tn/src/master/mat/12/38.md)
* [Matthew 16:3-4](https://git.door43.org/Door43/en_tn/src/master/mat/16/03.md)

### Word Data:

* Strong's: H3124, G2495


## <a id="tw-term-names-jonathan"/>Jonathan

### Facts:

Jonathan was the name of at least ten men in the Old Testament. The name means "Yahweh has given."

* David's best friend, Jonathan, is the most well-known Jonathan in the Bible with this name. This Jonathan was King Saul's oldest son.
* Other Jonathans mentioned in the Old Testament include a descendant of Moses; a nephew of King David; several priests, including a son of Abiathar; and an Old Testament scribe in whose house the prophet Jeremiah was imprisoned.

(See also: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Abiathar](#abiathar), [David](#david), [Moses](#moses), [Jeremiah](#jeremiah), [priest](kt.html#priest), [Saul (OT)](#saul), [scribe](kt.html#scribe))

### Bible References:

* [1 Kings 01:41-42](https://git.door43.org/Door43/en_tn/src/master/1ki/01/41.md)
* [1 Samuel 14:1](https://git.door43.org/Door43/en_tn/src/master/1sa/14/01.md)
* [1 Samuel 20:1-2](https://git.door43.org/Door43/en_tn/src/master/1sa/20/01.md)
* [2 Samuel 01:3-5](https://git.door43.org/Door43/en_tn/src/master/2sa/01/03.md)

### Word Data:

* Strong's: H3083, H3129


## <a id="tw-term-names-joppa"/>Joppa

### Facts:

In Bible times, the city of Joppa was an important commercial seaport located on the Mediterranean Sea, south of the Plain of Sharon.

* The ancient site of Joppa is the location of the present-day city of Jaffa, which is now part of the city of Tel Aviv.
* In the Old Testament, Joppa was the city where Jonah got on a boat that was going to Tarshish.
* In the New Testament, a Christian woman named Tabitha died in Joppa, and Peter brought her back to life.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [the sea](#mediterranean), [Jerusalem](#jerusalem), [Sharon](#sharon), [Tarshish](#tarshish)) 

### Bible References:

* [Acts 09:36-37](https://git.door43.org/Door43/en_tn/src/master/act/09/36.md)
* [Acts 10:7-8](https://git.door43.org/Door43/en_tn/src/master/act/10/07.md)
* [Acts 11:4-6](https://git.door43.org/Door43/en_tn/src/master/act/11/04.md)
* [Acts 11:11-14](https://git.door43.org/Door43/en_tn/src/master/act/11/11.md)
* [Jonah 01:1-3](https://git.door43.org/Door43/en_tn/src/master/jon/01/01.md)

### Word Data:

* Strong's: H3305, G2445


## <a id="tw-term-names-joram"/>Joram

### Facts:

Joram son of Ahab was a king of Israel. He was also sometimes referred to as "Jehoram."

* King Joram of Israel reigned at the same time as King Jehoram of Judah.
* Joram was an evil king who worshiped false gods and caused Israel to sin.
* King Joram of Israel also reigned during the time of the prophets Elijah and Obadiah.
* Another man named Joram was the son of King Tou of Hamath when David was king.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Ahab](#ahab), [David](#david), [Elijah](#elijah), [Hamath](#hamath), [Jehoram](#jehoram), [kingdom of Israel](#kingdomofisrael), [Judah](#kingdomofjudah), [Obadiah](#obadiah), [prophet](kt.html#prophet))

### Bible References:

* [1 Chronicles 03:10-12](https://git.door43.org/Door43/en_tn/src/master/1ch/03/10.md)
* [2 Chronicles 22:4-5](https://git.door43.org/Door43/en_tn/src/master/2ch/22/04.md)
* [2 Kings 01:17-18](https://git.door43.org/Door43/en_tn/src/master/2ki/01/17.md)
* [2 Kings 08:16-17](https://git.door43.org/Door43/en_tn/src/master/2ki/08/16.md)

### Word Data:

* Strong's: H3088, H3141, G2496


## <a id="tw-term-names-jordanriver"/>Jordan River, Jordan

### Facts:

The Jordan River is a river that flows from north to south, and forms the eastern boundary of the land that was called Canaan.

* Today, the Jordan River separates Israel on its west from Jordan on its east. 
* The Jordan River flows through the Sea of Galilee and then empties into the Dead Sea.
* When Joshua led the Israelites into Canaan, they had to cross the Jordan River. It was too deep to cross normally, but God miraculously stopped the river from flowing so they could walk across the river bed.
* Often in the Bible the Jordan River is referred to as "the Jordan."

(See also: [Canaan](#canaan), [Salt Sea](#saltsea), [Sea of Galilee](#seaofgalilee))

### Bible References:

* [Genesis 32:9-10](https://git.door43.org/Door43/en_tn/src/master/gen/32/09.md)
* [John 01:26-28](https://git.door43.org/Door43/en_tn/src/master/jhn/01/26.md)
* [John 03:25-26](https://git.door43.org/Door43/en_tn/src/master/jhn/03/25.md)
* [Luke 03:3](https://git.door43.org/Door43/en_tn/src/master/luk/03/03.md)
* [Matthew 03:4-6](https://git.door43.org/Door43/en_tn/src/master/mat/03/04.md)
* [Matthew 03:13-15](https://git.door43.org/Door43/en_tn/src/master/mat/03/13.md)
* [Matthew 04:14-16](https://git.door43.org/Door43/en_tn/src/master/mat/04/14.md)
* [Matthew 19:1-2](https://git.door43.org/Door43/en_tn/src/master/mat/19/01.md)

### Examples from the Bible stories:

  __*[15:02](https://git.door43.org/Door43/en_tn/src/master/obs/15/02.md)__ The Israelites had to cross the __Jordan River__ to enter into the Promised Land. 
  __*[15:03](https://git.door43.org/Door43/en_tn/src/master/obs/15/03.md)__ After the people crossed the __Jordan River__, God told Joshua how to attack the powerful city of Jericho. 
  __*[19:14](https://git.door43.org/Door43/en_tn/src/master/obs/19/14.md)__ Elisha told him (Naaman) to dip himself seven times in the __Jordan River__.

### Word Data:

* Strong's: H3383, G2446


## <a id="tw-term-names-josephnt"/>Joseph (NT)

### Facts:

Joseph was Jesus' earthly father and raised him as his son. He was a righteous man who worked as a carpenter.

* Joseph became engaged to a Jewish girl named Mary, while they were engaged God chose her to become the mother of Jesus the Messiah.
* An angel told Joseph that the Holy Spirit had miraculously caused Mary to be pregnant, and that Mary's baby was the Son of God.
* After Jesus was born, an angel warned Joseph to take the baby and Mary to Egypt in order to escape from Herod.
* Joseph and his family later lived in the city of Nazareth of Galilee, where he earned a living doing carpentry work.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Christ](kt.html#christ), [Galilee](#galilee), [Jesus](kt.html#jesus), [Nazareth](#nazareth), [Son of God](kt.html#sonofgod), [virgin](other.html#virgin))

### Bible References:

* [John 01:43-45](https://git.door43.org/Door43/en_tn/src/master/jhn/01/43.md)
* [Luke 01:26-29](https://git.door43.org/Door43/en_tn/src/master/luk/01/26.md)
* [Luke 02:4-5](https://git.door43.org/Door43/en_tn/src/master/luk/02/04.md)
* [Luke 02:15-16](https://git.door43.org/Door43/en_tn/src/master/luk/02/15.md)
* [Matthew 01:18-19](https://git.door43.org/Door43/en_tn/src/master/mat/01/18.md)
* [Matthew 01:24-25](https://git.door43.org/Door43/en_tn/src/master/mat/01/24.md)
* [Matthew 02:19-21](https://git.door43.org/Door43/en_tn/src/master/mat/02/19.md)
* [Matthew 13:54-56](https://git.door43.org/Door43/en_tn/src/master/mat/13/54.md)

### Examples from the Bible stories:

  __*[22:04](https://git.door43.org/Door43/en_tn/src/master/obs/22/04.md)__ She (Mary) was a virgin and was engaged to be married to a man named __Joseph__.
  __*[23:01](https://git.door43.org/Door43/en_tn/src/master/obs/23/01.md)__ __Joseph__, the man Mary was engaged to, was a righteous man. When he heard that Mary was pregnant, he knew it was not his baby. He did not want to shame her, so he planned to quietly divorce her.
  __*[23:02](https://git.door43.org/Door43/en_tn/src/master/obs/23/02.md)__ The angel said, "__Joseph__, do not be afraid to take Mary as your wife. The baby in her body is from the Holy Spirit. She will give birth to a son. Name him Jesus (which means, 'Yahweh saves'), because he will save the people from their sins."
  __*[23:03](https://git.door43.org/Door43/en_tn/src/master/obs/23/03.md)__ So __Joseph__ married Mary and took her home as his wife, but he did not sleep with her until she had given birth.
  __*[23:04](https://git.door43.org/Door43/en_tn/src/master/obs/23/04.md)__ __Joseph__ and Mary had to make a long journey from where they lived in Nazareth to Bethlehem because their ancestor was David whose hometown was Bethlehem.
  __*[26:04](https://git.door43.org/Door43/en_tn/src/master/obs/26/04.md)__ Jesus said, "The words I just read to you are happening right now." All the people were amazed. "Isn't this the son of __Joseph__?" they said.

### Word Data:

* Strong's: G2501


## <a id="tw-term-names-josephot"/>Joseph (OT)

### Facts:

Joseph was the eleventh son of Jacob and the first son of his mother Rachel.

 * Joseph was his father's favorite son.
 * His brothers were jealous of him and sold him into slavery.
 * While in Egypt, Joseph was falsely accused and put into prison.
 * In spite of his difficulties, Joseph remained faithful to God.
 * God brought him to the second highest place of power in Egypt and used him to save people in a time when there was little food. The people of Egypt, as well as his own family, were kept from starving.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Egypt](#egypt), [Jacob](#jacob))

### Bible References:

* [Genesis 30:22-24](https://git.door43.org/Door43/en_tn/src/master/gen/30/22.md)
* [Genesis 33:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/33/01.md)
* [Genesis 37:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/37/01.md)
* [Genesis 37:23-24](https://git.door43.org/Door43/en_tn/src/master/gen/37/23.md)
* [Genesis 41:55-57](https://git.door43.org/Door43/en_tn/src/master/gen/41/55.md)
* [John 04:4-5](https://git.door43.org/Door43/en_tn/src/master/jhn/04/04.md)

### Examples from the Bible stories:

  __*[08:02](https://git.door43.org/Door43/en_tn/src/master/obs/08/02.md)__ __Joseph's__ brothers hated him because their father loved him most and because Joseph had dreamed that he would be their ruler.
  __*[08:04](https://git.door43.org/Door43/en_tn/src/master/obs/08/04.md)__ The slave traders took __Joseph__ to Egypt.
  __*[08:05](https://git.door43.org/Door43/en_tn/src/master/obs/08/05.md)__ Even in prison, __Joseph__ remained faithful to God, and God blessed him.
  __*[08:07](https://git.door43.org/Door43/en_tn/src/master/obs/08/07.md)__ God had given __Joseph__ the ability to interpret dreams, so Pharaoh had Joseph brought to him from the prison.
  __*[08:09](https://git.door43.org/Door43/en_tn/src/master/obs/08/09.md)__ __Joseph__ told the people to store up large amounts of food during the seven years of good harvests.
  __*[09:02](https://git.door43.org/Door43/en_tn/src/master/obs/09/02.md)__ The Egyptians no longer remembered __Joseph__ and all he had done to help them.

### Word Data:

* Strong's: H3084, H3130, G2500, G2501


## <a id="tw-term-names-joshua"/>Joshua

### Facts:

There were several Israelite men named Joshua in the Bible. The most well-known is Joshua son of Nun who was Moses' helper and who later became an important leader of God's people.

* Joshua was one of the twelve spies whom Moses sent to explore the Promised Land.
* Along with Caleb, Joshua urged the Israelite people to obey God's command to enter the Promised Land and defeat the Canaanites.
* Many years later, after Moses died, God appointed Joshua to lead the people of Israel into the Promised Land.
* In the first and most famous battle against the Canaanites, Joshua led the Israelites to defeat the city of Jericho.
* The Old Testament book of Joshua tells how Joshua led the Israelites in taking control of the Promised Land and how he assigned each tribe of Israel a part of the land to live on.
* Joshua son of Jozadak is mentioned in the books of Haggai and Zechariah; he was a high priest who helped rebuild the walls of Jerusalem.
* There are several other men named Joshua mentioned in the genealogies and elsewhere in the Bible.
  

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Canaan](#canaan), [Haggai](#haggai), [Jericho](#jericho), [Moses](#moses), [Promised Land](kt.html#promisedland), [Zechariah (OT)](#zechariahot))
 
### Bible References:

* [1 Chronicles 07:25-27](https://git.door43.org/Door43/en_tn/src/master/1ch/07/25.md)
* [Deuteronomy 03:21-22](https://git.door43.org/Door43/en_tn/src/master/deu/03/21.md)
* [Exodus 17:8-10](https://git.door43.org/Door43/en_tn/src/master/exo/17/08.md)
* [Joshua 01:1-3](https://git.door43.org/Door43/en_tn/src/master/jos/01/01.md)
* [Numbers 27:18-19](https://git.door43.org/Door43/en_tn/src/master/num/27/18.md)

### Examples from the Bible stories:

  __*[14:04](https://git.door43.org/Door43/en_tn/src/master/obs/14/04.md)__ When the Israelites reached the edge of Canaan, Moses chose twelve men, one from each tribe of Israel. He gave the men instructions to go and spy on the land to see what it was like.
  __*[14:06](https://git.door43.org/Door43/en_tn/src/master/obs/14/06.md)__  Immediately Caleb and __Joshua__, the other two spies, said, "It is true that the people of Canaan are tall and strong, but we can certainly defeat them!"
  __*[14:08](https://git.door43.org/Door43/en_tn/src/master/obs/14/08.md)__ Except for __Joshua__ and Caleb, everyone who is twenty years old or older will die there and never enter the Promised Land."
  __*[14:14](https://git.door43.org/Door43/en_tn/src/master/obs/14/14.md)__ Moses was now very old, so God chose __Joshua__ to help him lead the people.  
  __*[14:15](https://git.door43.org/Door43/en_tn/src/master/obs/14/15.md)__ __Joshua__ was a good leader because he trusted and obeyed God. 
  __*[15:03](https://git.door43.org/Door43/en_tn/src/master/obs/15/03.md)__ After the people crossed the Jordan River, God told __Joshua__ how to attack the powerful city of Jericho.

### Word Data:

* Strong's: H3091, G2424


## <a id="tw-term-names-josiah"/>Josiah

### Facts:

Josiah was a godly king who reigned over the kingdom of Judah for thirty-one years. He led the people of Judah to repent and worship Yahweh.

* After his father King Amon was killed, Josiah became king over Judah at eight years of age.
* In the eighteenth year of his reign, King Josiah ordered Hilkiah the high priest to rebuild the temple of the Lord. While this was being done, the books of the Law were found.
* When the books of the Law were read to Josiah, he was grieved at how his people were disobeying God. He ordered that all the places of idol worship be destroyed and that the priests of the false gods be killed.
* He also ordered the people to start celebrating the Passover feast again.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [false god](kt.html#falsegod), [Judah](#judah), [law](other.html#law), [Passover](kt.html#passover), [temple](kt.html#temple))

### Bible References:

* [1 Chronicles 03:13-14](https://git.door43.org/Door43/en_tn/src/master/1ch/03/13.md)
* [2 Chronicles 33:24-25](https://git.door43.org/Door43/en_tn/src/master/2ch/33/24.md)
* [2 Chronicles 34:1-3](https://git.door43.org/Door43/en_tn/src/master/2ch/34/01.md)
* [Jeremiah 01:1-3](https://git.door43.org/Door43/en_tn/src/master/jer/01/01.md)
* [Matthew 01:9-11](https://git.door43.org/Door43/en_tn/src/master/mat/01/09.md)

### Word Data:

* Strong's: H2977, G2502


## <a id="tw-term-names-jotham"/>Jotham

### Definition:

In the Old Testament, there were three men with the name Jotham.

* One man named Jotham was the youngest son of Gideon. Jotham helped defeat his older brother Abimelech, who had killed all the rest of their brothers.
* Another man named Jotham was a king over Judah for sixteen years following the death of his father Uzziah (Azariah).
* Like his father, King Jotham obeyed God and was a good king.
* However, by not removing the places of idol worship he caused the people of Judah to later turn away from God again.
* Jotham is also one of the ancestors listed in the genealogy of Jesus Christ in the book of Matthew.

(See also: [Abimelech](#abimelech), [Ahaz](#ahaz), [Gideon](#gideon), [Uzziah](#uzziah))

### Bible References:

* [2 Chronicles 26:21](https://git.door43.org/Door43/en_tn/src/master/2ch/26/21.md)
* [2 Kings 15:4-5](https://git.door43.org/Door43/en_tn/src/master/2ki/15/04.md)
* [Isaiah 01:1](https://git.door43.org/Door43/en_tn/src/master/isa/01/01.md)
* [Judges 09:5-6](https://git.door43.org/Door43/en_tn/src/master/jdg/09/05.md)

### Word Data:

* Strong's: H3147


## <a id="tw-term-names-judah"/>Judah

### Facts:

Judah was one of Jacob's older sons. His mother was Leah. His descendants were called the "tribe of Judah."

* It was Judah who told his brothers to sell their younger brother Joseph as a slave instead of leaving him to die in a deep pit.
* King David and all the kings after him were descendants of Judah. Jesus, too, was a descendant of Judah.
* When Solomon's reign ended and the nation of Israel divided, the kingdom of Judah was the southern kingdom.
* In the New Testament book of Revelation, Jesus is called the "Lion of Judah."
* The words "Jew" and "Judea" come from the name "Judah."

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Jacob](#jacob), [Jew](kt.html#jew), [Judah](#kingdomofjudah), [Judea](#judea), [twelve tribes of Israel](other.html#12tribesofisrael))

### Bible References:

* [1 Chronicles 02:1-2](https://git.door43.org/Door43/en_tn/src/master/1ch/02/01.md)
* [1 Kings 01:9-10](https://git.door43.org/Door43/en_tn/src/master/1ki/01/09.md)
* [Genesis 29:35](https://git.door43.org/Door43/en_tn/src/master/gen/29/35.md)
* [Genesis 38:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/38/01.md)
* [Luke 03:33-35](https://git.door43.org/Door43/en_tn/src/master/luk/03/33.md)
* [Ruth 01:1-2](https://git.door43.org/Door43/en_tn/src/master/rut/01/01.md)

### Word Data:

* Strong's: H3063


## <a id="tw-term-names-judasiscariot"/>Judas Iscariot

### Facts:

Judas Iscariot was one of Jesus' apostles. He was the one who betrayed Jesus to the Jewish leaders.

* The name "Iscariot" may mean "from Kerioth," perhaps indicating that Judas grew up in that city.
* Judas Iscariot managed the apostles' money and regularly stole some of it to use for himself.
* Judas betrayed Jesus by telling the religious leaders where Jesus was so they could arrest him.
* After the religious leaders condemned Jesus to die, Judas regretted that he had betrayed Jesus, so he gave the betrayal money back to the Jewish leaders and then killed himself.
* Another apostle was also named Judas, as was one of Jesus' brothers. Jesus' brother was also known as "Jude."

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [apostle](kt.html#apostle), [betray](other.html#betray), [Jewish leaders](other.html#jewishleaders), [Judas the son of James](#judassonofjames))

### Bible References:

* [Luke 06:14-16](https://git.door43.org/Door43/en_tn/src/master/luk/06/14.md)
* [Luke 22:47-48](https://git.door43.org/Door43/en_tn/src/master/luk/22/47.md)
* [Mark 03:17-19](https://git.door43.org/Door43/en_tn/src/master/mrk/03/17.md)
* [Mark 14:10-11](https://git.door43.org/Door43/en_tn/src/master/mrk/14/10.md)
* [Matthew 26:23-25](https://git.door43.org/Door43/en_tn/src/master/mat/26/23.md)

### Examples from the Bible stories:

* __[38:02](https://git.door43.org/Door43/en_tn/src/master/obs/38/02.md)__ One of Jesus' disciples was a man named __Judas__. … After Jesus and the disciples arrived in Jerusalem, __Judas__  went to the Jewish leaders and offered to betray Jesus to them in exchange for money.
* __[38:03](https://git.door43.org/Door43/en_tn/src/master/obs/38/03.md)__ The Jewish leaders, led by the high priest, paid __Judas__  thirty silver coins to betray Jesus.
* __[38:14](https://git.door43.org/Door43/en_tn/src/master/obs/38/14.md)__ __Judas__  came with the Jewish leaders, soldiers, and a large crowd. They were all carrying swords and clubs. __Judas__  came to Jesus and said, "Greetings, teacher," and kissed him.
* __[39:08](https://git.door43.org/Door43/en_tn/src/master/obs/39/08.md)__ Meanwhile, __Judas__, the betrayer, saw that the Jewish leaders had condemned Jesus to die. He became full of sorrow and went away and killed himself.

### Word Data:

* Strong's: G2455, G2469


## <a id="tw-term-names-judassonofjames"/>Judas the son of James

### Facts:

Judas son of James was one of Jesus' twelve apostles. Note that he was not the same man as Judas Iscariot.

* Often in the Bible, men with the same name were distinguished by mentioning whose son they were. Here, Judas was identified as the "son of James."
* Another man named Judas was Jesus' brother. He was also known as "Jude."
* The New Testament book called "Jude" was probably written by Jesus' brother Judas, since the author identified himself as the "brother of James." James was another brother of Jesus.
* It is also possible that the book of Jude was written by Jesus' disciple, Judas, the son of James.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [James (son of Zebedee)](#jamessonofzebedee), [Judas Iscariot](#judasiscariot), [son](kt.html#son), [the twelve](kt.html#thetwelve))

### Bible References:

* [Acts 01:12-14](https://git.door43.org/Door43/en_tn/src/master/act/01/12.md)
* [Luke 06:14-16](https://git.door43.org/Door43/en_tn/src/master/luk/06/14.md)

### Word Data:

* Strong's: G2455


## <a id="tw-term-names-judea"/>Judea

### Facts:

The term "Judea" refers to an area of land in ancient Israel. It is sometimes used in a narrow sense and other times in a broad sense.

 * Sometimes "Judea" is used in a narrow sense to refer only to the province located in the southern part of ancient Israel just west of the Dead Sea. Some translations call this province "Judah."
 * Other times "Judea" has a broad sense and refers to all the provinces of ancient Israel, including Galilee, Samaria, Perea, Idumea and Judea (Judah).
 * If translators want to make the distinction clear, the broad sense of Judea could be translated as "Judea Country" and the narrow sense  could be translated as "Judea Province," or "Judah Province" since this is the part of ancient Israel where the tribe of Judah had originally lived.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Galilee](#galilee), [Edom](#edom), [Judah](#judah), [Judah](#kingdomofjudah), [Samaria](#samaria))

### Bible References:

* [1 Thessalonians 02:14-16](https://git.door43.org/Door43/en_tn/src/master/1th/02/14.md)
* [Acts 02:8-11](https://git.door43.org/Door43/en_tn/src/master/act/02/08.md)
* [Acts 09:31-32](https://git.door43.org/Door43/en_tn/src/master/act/09/31.md)
* [Acts 12:18-19](https://git.door43.org/Door43/en_tn/src/master/act/12/18.md)
* [John 03:22-24](https://git.door43.org/Door43/en_tn/src/master/jhn/03/22.md)
* [Luke 01:5-7](https://git.door43.org/Door43/en_tn/src/master/luk/01/05.md)
* [Luke 04:42-44](https://git.door43.org/Door43/en_tn/src/master/luk/04/42.md)
* [Luke 05:17](https://git.door43.org/Door43/en_tn/src/master/luk/05/17.md)
* [Mark 10:1-4](https://git.door43.org/Door43/en_tn/src/master/mrk/10/01.md)
* [Matthew 02:1-3](https://git.door43.org/Door43/en_tn/src/master/mat/02/01.md)
* [Matthew 02:4-6](https://git.door43.org/Door43/en_tn/src/master/mat/02/04.md)
* [Matthew 02:22-23](https://git.door43.org/Door43/en_tn/src/master/mat/02/22.md)
* [Matthew 03:1-3](https://git.door43.org/Door43/en_tn/src/master/mat/03/01.md)
* [Matthew 19:1-2](https://git.door43.org/Door43/en_tn/src/master/mat/19/01.md)

### Word Data:

* Strong's: H3061, G2453


## <a id="tw-term-names-kadesh"/>Kadesh, Kadesh-Barnea, Meribah Kadesh

### Facts:

The names Kadesh, Kadesh-Barnea, and Meribah Kadesh all refer to an important city in Israel's history which was located in the southern part of Israel, near the region of Edom.

* The city of Kadesh was an oasis, a place where there was water and fertile soil in the middle of a desert named Zin.
* Moses sent twelve spies into the land of Canaan from Kadesh Barnea.
* Israel also encamped at Kadesh during the wandering in the wilderness.
* Kadesh Barnea was where Miriam died.
* It was at Meribah Kadesh where Moses disobeyed God and hit a rock to get water for the Israelites, instead of speaking to it as God had told him to do.
* The name "kadesh" comes from the Hebrew word meaning "holy" or "set apart."

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [desert](other.html#desert), [Edom](#edom), [holy](kt.html#holy))

### Bible References:

* [Ezekiel 48:27-29](https://git.door43.org/Door43/en_tn/src/master/ezk/48/27.md)
* [Genesis 14:7-9](https://git.door43.org/Door43/en_tn/src/master/gen/14/07.md)
* [Genesis 16:13-14](https://git.door43.org/Door43/en_tn/src/master/gen/16/13.md)
* [Genesis 20:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/20/01.md)
* [Joshua 10:40-41](https://git.door43.org/Door43/en_tn/src/master/jos/10/40.md)
* [Numbers 20:1](https://git.door43.org/Door43/en_tn/src/master/num/20/01.md)

### Word Data:

* Strong's: H4809, H6946, H6947


## <a id="tw-term-names-kedar"/>Kedar

### Facts:

Kedar was Ishmael's second son. It was also an important city, which was probably named after the man.

* The city of Kedar is located in the northern part of Arabia near the southern border of Palestine. In Bible times, it was known for its greatness and beauty.
* The descendants of Kedar formed a large people group that is also called "Kedar."
* The phrase "dark tents of Kedar" refers to the black goathair tents the people of Kedar lived in.
* These people raised sheep and goats. They also used camels for transporting things.
* In the Bible, the phrase "the glory of Kedar" refers to the greatness of that city and its people.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Arabia](#arabia), [goat](other.html#goat), [Ishmael](#ishmael), [sacrifice](other.html#sacrifice))

### Bible References:

* [Song of Solomon 01:5-6](https://git.door43.org/Door43/en_tn/src/master/sng/01/05.md)

### Word Data:

* Strong's: H6938


## <a id="tw-term-names-kedesh"/>Kedesh

### Facts:

Kedesh was a Canaanite city that was taken over by the Israelites when they entered the land of Canaan.

* This city was located in the northern part of Israel, in the portion of land that was given to the tribe of Naphtali.
* Kedesh was one of the cities that was chosen as a place where the Levite priests could live, since they did not have any land of their own.
* It was also set apart as a "city of refuge."

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Canaan](#canaan), [Hebron](#hebron), [Levite](#levite), [Naphtali](#naphtali), [priest](kt.html#priest), [refuge](other.html#refuge), [Shechem](#shechem), [twelve tribes of Israel](other.html#12tribesofisrael))

### Bible References:

* [1 Chronicles 06:71-73](https://git.door43.org/Door43/en_tn/src/master/1ch/06/71.md)
* [Joshua 19:35-37](https://git.door43.org/Door43/en_tn/src/master/jos/19/35.md)
* [Judges 04:10](https://git.door43.org/Door43/en_tn/src/master/jdg/04/10.md)

### Word Data:

* Strong's: Kedesh


## <a id="tw-term-names-kidronvalley"/>Kidron Valley

### Facts:

The Kidron Valley is a deep valley just outside the city of Jerusalem, between its eastern wall and the Mount of Olives.

* The valley is over 1,000 meters deep and about 32 kilometers long.
* When King David was fleeing from his son Absalom, he went through the Kidron Valley to get to the Mount of Olives.
* King Josiah and King Asa of Judah ordered that the high places and altars of false gods be smashed and burned; the ashes were thrown into the Kidron Valley.
* During the reign of King Hezekiah, the Kidron Valley was where the priests threw everything impure that they removed from the temple.
* The evil queen Athaliah was killed in this valley because of the wicked things she had done.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Absalom](#absalom), [Asa](#asa), [Athaliah](#athaliah), [David](#david), [false god](kt.html#falsegod), [Hezekiah](#hezekiah), [high places](other.html#highplaces), [Josiah](#josiah), [Judah](#kingdomofjudah), [Mount of Olives](#mountofolives))

### Bible References:

* [John 18:1-3](https://git.door43.org/Door43/en_tn/src/master/jhn/18/01.md)

### Word Data:

* Strong's: H5674, H6939, G2748, G5493


## <a id="tw-term-names-kingdomofisrael"/>kingdom of Israel

### Facts:

What had been the northern part of the nation of Israel became the ingdom of Israel when the twelve tribes of Israel were divided into two kingdoms after Solomon died.

* The kingdom of Israel in the north had ten tribes, and the kingdom of Judah in the south had two tribes.
* The capital city of the kingdom of Israel was Samaria. It was about 50 km from Jerusalem, the capital city of the kingdom of Judah.
* All the kings of the kingdom of Israel were evil. They influenced the people to  to serve idols and false gods.
* God sent the Assyrians to attack the kingdom of Israel. Many Israelites were captured and taken away to live in Assyria.
* The Assyrians brought foreigners to live among the remaining people of the kingdom of Israel. These foreigners intermarried with the Israelites, and their descendants became the Samaritan people.

(See also: [Assyria](#assyria), [Israel](kt.html#israel), [Judah](#kingdomofjudah), [Jerusalem](#jerusalem), [kingdom](other.html#kingdom), [Samaria](#samaria))

### Bible References:

* [2 Chronicles 35:18-19](https://git.door43.org/Door43/en_tn/src/master/2ch/35/18.md)
* [Jeremiah 05:10-13](https://git.door43.org/Door43/en_tn/src/master/jer/05/10.md)
* [Jeremiah 09:25-26](https://git.door43.org/Door43/en_tn/src/master/jer/09/25.md)

### Examples from the Bible stories:

  __*[18:08](https://git.door43.org/Door43/en_tn/src/master/obs/18/08.md)__ The other ten tribes of the nation of Israel that rebelled against Rehoboam appointed a man named Jeroboam to be their king. They set up their kingdom in the northern part of the land and were called the __kingdom of Israel__.
  __*[18:10](https://git.door43.org/Door43/en_tn/src/master/obs/18/10.md)__ The __kingdoms of Judah and Israel__ became enemies and often fought against each other.
  __*[18:11](https://git.door43.org/Door43/en_tn/src/master/obs/18/11.md)__ In the new __kingdom of Israel__, all the kings were evil.
  __*[20:01](https://git.door43.org/Door43/en_tn/src/master/obs/20/01.md)__ The __kingdoms of Israel__ and Judah both sinned against God.
  __*[20:02](https://git.door43.org/Door43/en_tn/src/master/obs/20/02.md)__ The __kingdom of Israel__ was destroyed by the Assyrian Empire, a powerful, cruel nation. The Assyrians killed many people in the __kingdom of Israel__, took away everything of value, and burned much of the country.
  __*[20:04](https://git.door43.org/Door43/en_tn/src/master/obs/20/04.md)__ Then the Assyrians brought foreigners to live in the land where the __kingdom of Israel__ had been. The foreigners rebuilt the destroyed cities and married the Israelites who were left there. The descendants of the Israelites who married foreigners were called Samaritans.

### Word Data:

* Strong's: H3478, H4410, H4467, H4468


## <a id="tw-term-names-kingdomofjudah"/>Judah, kingdom of Judah

### Facts:

The tribe of Judah was the largest of the twelve tribes of Israel. The kingdom of Judah was made up of the tribes of Judah and Benjamin. 

* After King Solomon died, the nation of Israel was divided into two kingdoms: Israel and Judah. The kingdom of Judah was the southern kingdom, located west of the Salt Sea. 
* The capital city of the kingdom of Judah was Jerusalem.
* Eight kings of Judah obeyed Yahweh and led the people to worship him. The other kings of Judah were evil and led the people to worship idols.
* Over 120 years after Assyria defeated Israel (the northern kingdom), Judah was conquered by the nation of Babylon. The Babylonians destroyed the city and the temple, and took most of the people of Judah to Babylon as captives.

(See also: [Judah](#judah), [Salt Sea](#saltsea))

### Bible References:

* [1 Samuel 30:26-28](https://git.door43.org/Door43/en_tn/src/master/1sa/30/26.md)
* [2 Samuel 12:7-8](https://git.door43.org/Door43/en_tn/src/master/2sa/12/07.md)
* [Hosea 05:14-15](https://git.door43.org/Door43/en_tn/src/master/hos/05/14.md)
* [Jeremiah 07:33-34](https://git.door43.org/Door43/en_tn/src/master/jer/07/33.md)
* [Judges 01:16-17](https://git.door43.org/Door43/en_tn/src/master/jdg/01/16.md)

### Examples from the Bible stories:

  __*[18:07](https://git.door43.org/Door43/en_tn/src/master/obs/18/07.md)__ Only two tribes remained faithful to him (Rehoboam). These two tribes became the __kingdom of Judah__.\\
  __*[18:10](https://git.door43.org/Door43/en_tn/src/master/obs/18/10.md)__ The __kingdoms of Judah__ and Israel became enemies and often fought against each other.\\
  __*[18:13](https://git.door43.org/Door43/en_tn/src/master/obs/18/13.md)__ The __kings of Judah__ were descendants of David. Some of these kings were good men who ruled justly and worshiped God. But most of __Judah's__ kings were evil, corrupt, and they worshiped idols.\\
  __*[20:01](https://git.door43.org/Door43/en_tn/src/master/obs/20/01.md)__ The __kingdoms of Israel and Judah__ both sinned against God.\\
  __*[20:05](https://git.door43.org/Door43/en_tn/src/master/obs/20/05.md)__ The people in the __kingdom of Judah__ saw how God had punished the people of the kingdom of Israel for not believing and obeying him. But they still worshiped idols, including the gods of the Canaanites.\\
  __*[20:06](https://git.door43.org/Door43/en_tn/src/master/obs/20/06.md)__ About 100 years after the Assyrians destroyed the kingdom of Israel, God sent Nebuchadnezzar, king of the Babylonians, to attack the __kingdom of Judah__.\\
  __*[20:09](https://git.door43.org/Door43/en_tn/src/master/obs/20/09.md)__ Nebuchadnezzar and his army took almost all of the people of __the kingdom of Judah__ to Babylon, leaving only the poorest people behind to plant the fields.\\

### Word Data:

* Strong's: H4438, H3063


## <a id="tw-term-names-korah"/>Korah, Korahite, Korahites

### Definition:

Korah was the name of three men in the Old Testament.

* One of the sons of Esau was named Korah. He became a leader in his community.
* Korah was also a descendant of Levi and so served in the tabernacle as a priest. He became jealous of Moses and Aaron and led a group of men to rebel against them.
* A third man named Korah is listed as a descendant of Judah.

(See also: [Aaron](#aaron), [authority](kt.html#authority), [Caleb](#caleb), [descendant](other.html#descendant), [Esau](#esau), [Judah](#judah), [priest](kt.html#priest))

### Bible References:

* [1 Chronicles 01:34-37](https://git.door43.org/Door43/en_tn/src/master/1ch/01/34.md)
* [Numbers 16:1-3](https://git.door43.org/Door43/en_tn/src/master/num/16/01.md)
* [Numbers 16:25-27](https://git.door43.org/Door43/en_tn/src/master/num/16/25.md)
* [Psalm 042:1-2](https://git.door43.org/Door43/en_tn/src/master/psa/042/001.md)

### Word Data:

* Strong's: H7141


## <a id="tw-term-names-laban"/>Laban

### Facts:

In the Old Testament, Laban was the uncle and father-in-law of Jacob. 

* Jacob lived with Laban's household in Padan Aram and managed his sheep and goats as a condition of marriage to Laban's daughters.
* Jacob's preference was for Laban's daughter Rachel to be his wife.
* Laban deceived Jacob and made him marry his oldest daughter Leah first before giving Rachel to him as his wife.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Jacob](#jacob), [Nahor](#nahor), [Leah](#leah), [Rachel](#rachel))

### Bible References:

* [Genesis 24:28-30](https://git.door43.org/Door43/en_tn/src/master/gen/24/28.md)
* [Genesis 24:50-51](https://git.door43.org/Door43/en_tn/src/master/gen/24/50.md)
* [Genesis 27:43-45](https://git.door43.org/Door43/en_tn/src/master/gen/27/43.md)
* [Genesis 28:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/28/01.md)
* [Genesis 29:4-6](https://git.door43.org/Door43/en_tn/src/master/gen/29/04.md)
* [Genesis 29:13-14](https://git.door43.org/Door43/en_tn/src/master/gen/29/13.md)
* [Genesis 30:25-26](https://git.door43.org/Door43/en_tn/src/master/gen/30/25.md)
* [Genesis 46:16-18](https://git.door43.org/Door43/en_tn/src/master/gen/46/16.md)

### Word Data:

* Strong's: H3837


## <a id="tw-term-names-lamech"/>Lamech

### Facts:

Lamech was the name of two men mentioned in the book of Genesis.

* The first Lamech mentioned was a descendant of Cain. He boasted to his two wives that he had killed a man for injuring him.
* The second Lamech was a descendant of Seth. He was also the father of Noah.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Cain](#cain), [Noah](#noah), [Seth](#seth))

### Bible References:

* [Genesis 04:18-19](https://git.door43.org/Door43/en_tn/src/master/gen/04/18.md)
* [Genesis 04:23-24](https://git.door43.org/Door43/en_tn/src/master/gen/04/23.md)
* [Genesis 05:25-27](https://git.door43.org/Door43/en_tn/src/master/gen/05/25.md)
* [Genesis 05:28-29](https://git.door43.org/Door43/en_tn/src/master/gen/05/28.md)
* [Genesis 05:30-31](https://git.door43.org/Door43/en_tn/src/master/gen/05/30.md)
* [Luke 03:36-38](https://git.door43.org/Door43/en_tn/src/master/luk/03/36.md)

### Word Data:

* Strong's: H3929, G2984


## <a id="tw-term-names-lazarus"/>Lazarus

### Facts:

Lazarus and his sisters, Mary and Martha, were special friends of Jesus. Jesus often stayed with them in their home in Bethany.

* Lazarus is best known for the fact that Jesus raised him from the dead after he had been buried in a tomb for several days.
* The Jewish leaders were angry at Jesus and jealous that he had done this miracle, and they tried to find a way to kill both Jesus and Lazarus.
* Jesus also told a parable about a poor beggar and a rich man in which the beggar was named "Lazarus."

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [beg](other.html#beg), [Jewish leaders](other.html#jewishleaders), [Martha](#martha), [Mary](#mary), [raise](other.html#raise))

### Bible References:

* [John 11:10-11](https://git.door43.org/Door43/en_tn/src/master/jhn/11/10.md)
* [John 12:1-3](https://git.door43.org/Door43/en_tn/src/master/jhn/12/01.md)
* [Luke 16:19-21](https://git.door43.org/Door43/en_tn/src/master/luk/16/19.md)

### Examples from the Bible stories:

* __[37:01](https://git.door43.org/Door43/en_tn/src/master/obs/37/01.md)__ One day, Jesus received a message that __Lazarus__  was very sick. __Lazarus__  and his two sisters, Mary and Martha, were close friends of Jesus.
* __[37:02](https://git.door43.org/Door43/en_tn/src/master/obs/37/02.md)__ Jesus said, "Our friend __Lazarus__  has fallen asleep, and I must wake him."
* __[37:03](https://git.door43.org/Door43/en_tn/src/master/obs/37/03.md)__ Jesus' disciples replied, "Master, if __Lazarus__  is sleeping, then he will get better." Then Jesus told them plainly, "__Lazarus__  is dead."
* __[37:04](https://git.door43.org/Door43/en_tn/src/master/obs/37/04.md)__ When Jesus arrived at __Lazarus'__  hometown, __Lazarus__  had already been dead for four days.
* __[37:06](https://git.door43.org/Door43/en_tn/src/master/obs/37/06.md)__ Jesus asked them, "Where have you put __Lazarus__?"
* __[37:09](https://git.door43.org/Door43/en_tn/src/master/obs/37/09.md)__ Then Jesus shouted, "__Lazarus__, come out!"
* __[37:10](https://git.door43.org/Door43/en_tn/src/master/obs/37/10.md)__ So __Lazarus__  came out! He was still wrapped in grave clothes.
* __[37:11](https://git.door43.org/Door43/en_tn/src/master/obs/37/11.md)__ But the religious leaders of the Jews were jealous, so they gathered together to plan how they could kill Jesus and __Lazarus__.

### Word Data:

* Strong's: G2976


## <a id="tw-term-names-leah"/>Leah

### Facts:

Leah was one of Jacob's wives. She was the mother of ten of Jacob's sons and their descendants were ten of the twelve tribes of Israel.

 * Leah's father was Laban, who was the brother of Jacob's mother Rebekah.
 * Jacob didn't love Leah as much as he loved his other wife, Rachel, but God abundantly blessed Leah by giving her many children.
 * Leah's son Judah was an ancestor of King David and Jesus.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Jacob](#jacob), [Judah](#judah), [Laban](#laban), [Rachel](#rachel), [Rebekah](#rebekah), [twelve tribes of Israel](other.html#12tribesofisrael))

### Bible References:

* [Genesis 29:15-18](https://git.door43.org/Door43/en_tn/src/master/gen/29/15.md)
* [Genesis 29:28-30](https://git.door43.org/Door43/en_tn/src/master/gen/29/28.md)
* [Genesis 31:4-6](https://git.door43.org/Door43/en_tn/src/master/gen/31/04.md)
* [Ruth 04:11-12](https://git.door43.org/Door43/en_tn/src/master/rut/04/11.md)

### Word Data:

* Strong's: H3812


## <a id="tw-term-names-lebanon"/>Lebanon

### Facts:

Lebanon is a beautiful mountainous region located along the coast of the Mediterranean Sea, north of Israel. In Bible times this region was thickly wooded with fir trees, such as cedar and cypress.

* King Solomon sent workers to Lebanon to harvest cedar trees for use in building God's temple.
* Ancient Lebanon was inhabited by Phoenician people, who were skilled builders of ships that were used for a successful trading industry.
* The cities of Tyre and Sidon were located in Lebanon. It was in these cities that a valuable purple dye was first used.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [cedar](other.html#cedar), [cypress](other.html#cypress), [fir](other.html#fir), [Phoenicia](#phonecia))

### Bible References:

* [1 Kings 04:32-34](https://git.door43.org/Door43/en_tn/src/master/1ki/04/32.md)
* [2 Chronicles 02:8-10](https://git.door43.org/Door43/en_tn/src/master/2ch/02/08.md)
* [Deuteronomy 01:7-8](https://git.door43.org/Door43/en_tn/src/master/deu/01/07.md)
* [Psalms 029:3-5](https://git.door43.org/Door43/en_tn/src/master/psa/029/003.md)
* [Zechariah 10:8-10](https://git.door43.org/Door43/en_tn/src/master/zec/10/08.md)

### Word Data:

* Strong's: H3844


## <a id="tw-term-names-leviathan"/>Leviathan

### Facts:

The term "Leviathan" refers to a very large, extinct animal mentioned in the earliest writings of the Old Testament, the books of Job, Psalms, and Isaiah.

* Leviathan is described as a large, snake-like creature, strong and fierce and able to make the water around it "boil." The descriptions of it were similar to that of a dinosaur.
* Isaiah the prophet refered to Leviathan as "the gliding serpent".
* Job wrote from firsthand knowledge of Leviathan, so the animal was most likely alive during his lifetime.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Isaiah](#isaiah), [Job](#job), [serpent](other.html#serpent))

### Bible References:

* [Job 03:8-10](https://git.door43.org/Door43/en_tn/src/master/job/03/08.md)
* [Psalms 104:25-26](https://git.door43.org/Door43/en_tn/src/master/psa/104/025.md)

### Word Data:

* Strong's: H3882


## <a id="tw-term-names-levite"/>Levi, Levite, Levites, Levitical

### Definition:

Levi was one of the twelve sons of Jacob, or Israel. The term "Levite" refers to a person who is a member of the Israelite tribe whose ancestor was Levi. 

* The Levites were responsible for taking care of the temple and conducting religious rituals, including offering sacrifices and prayers.
* All Jewish priests were Levites, descended from Levi and part of the tribe of Levi. (Not all Levites were priests, however.)
* The Levite priests were set apart and dedicated for the special work of serving God in the temple.
* Two other men named "Levi" were ancestors of Jesus, and their names are in the genealogy in the gospel of Luke.
* Jesus' disciple Matthew was also called Levi.

(See also: [Matthew](#matthew), [priest](kt.html#priest), [sacrifice](other.html#sacrifice), [temple](kt.html#temple), [twelve tribes of Israel](other.html#12tribesofisrael))

### Bible References:

* [1 Chronicles 02:1-2](https://git.door43.org/Door43/en_tn/src/master/1ch/02/01.md)
* [1 Kings 08:3-5](https://git.door43.org/Door43/en_tn/src/master/1ki/08/03.md)
* [Acts 04:36-37](https://git.door43.org/Door43/en_tn/src/master/act/04/36.md)
* [Genesis 29:33-34](https://git.door43.org/Door43/en_tn/src/master/gen/29/33.md)
* [John 01:19-21](https://git.door43.org/Door43/en_tn/src/master/jhn/01/19.md)
* [Luke 10:31-32](https://git.door43.org/Door43/en_tn/src/master/luk/10/31.md)

### Word Data:

* Strong's: H3878, H3879, H3881, G3017, G3018, G3019, G3020


## <a id="tw-term-names-lot"/>Lot

### Facts:

Lot was Abraham's nephew.

* He was the son of Abraham's brother Haran.
* Lot traveled with Abraham to the land of Canaan and settled in the city of Sodom.
* Lot was the ancestor of the Moabites and Ammonites.
* When enemy kings attacked Sodom and captured Lot, Abraham came with several hundred men to rescue Lot and recover his belongings.
* The people living in the city of Sodom were very wicked, so God destroyed that city. But he first told Lot and his family to leave the city so that that they could escape.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Abraham](#abraham), [Ammon](#ammon), [Haran](#haran), [Moab](#moab), [Sodom](#sodom))

### Bible References:

* [2 Peter 02:7-9](https://git.door43.org/Door43/en_tn/src/master/2pe/02/07.md)
* [Genesis 11:27-28](https://git.door43.org/Door43/en_tn/src/master/gen/11/27.md)
* [Genesis 12:4-5](https://git.door43.org/Door43/en_tn/src/master/gen/12/04.md)

### Word Data:

* Strong's: H3876, G3091


## <a id="tw-term-names-luke"/>Luke

### Facts:

Luke wrote two books of the New Testament: the gospel of Luke and the book of Acts.

* In his letter to the Colossians, Paul refers to Luke as a doctor. Paul also mentions Luke in two of his other letters.
* It is thought that Luke was a Greek and a Gentile who came to know Christ. In his gospel, Luke includes several accounts that highlight Jesus' love for all peoples, both Jews and Gentiles.
* Luke accompanied Paul on two of his missionary journeys and helped him in his work.
* In some early church writings, it is said that Luke was born in the city of Antioch in Syria.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Antioch](#antioch), [Paul](#paul), [Syria](#syria))

### Bible References:

* [2 Timothy 04:11-13](https://git.door43.org/Door43/en_tn/src/master/2ti/04/11.md)
* [Colossians 04:12-14](https://git.door43.org/Door43/en_tn/src/master/col/04/12.md)
* [Philemon 01:23-25](https://git.door43.org/Door43/en_tn/src/master/phm/01/23.md)

### Word Data:

* Strong's: Luke


## <a id="tw-term-names-lystra"/>Lystra

### Facts:

Lystra was a city in ancient Asia Minor that Paul visited on one of his missionary journeys. It was located in the region of Lycaonia, which is now in the modern-day country of Turkey.

* Paul and his companions escaped to Derbe and Lystra when they were threatened by the Jews in Iconium.
* In Lystra, Paul met Timothy, who became a fellow evangelist and church planter.
* After Paul healed a crippled man in Lystra, the people there tried to worship Paul and Barnabas as gods, but the apostles rebuked them and stopped them from doing that.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [evangelist](kt.html#evangelism), [Iconium](#iconium), [Timothy](#timothy))

### Bible References:

* [2 Timothy 03:10-13](https://git.door43.org/Door43/en_tn/src/master/2ti/03/10.md)
* [Acts 14:5-7](https://git.door43.org/Door43/en_tn/src/master/act/14/05.md)
* [Acts 14:8-10](https://git.door43.org/Door43/en_tn/src/master/act/14/08.md)
* [Acts 14:21-22](https://git.door43.org/Door43/en_tn/src/master/act/14/21.md)

### Word Data:

* Strong's: G3082


## <a id="tw-term-names-maacah"/>Maacah

### Facts:

Maacah (or Maakah) was one of the sons of Abraham's brother Nahor. Other people in the Old Testament also had this name.

* The city of Maacah or Beth Maacah was located in the far north of Israel, in the region occupied by the tribe of Naphtali.
* It was an important city and was attacked by enemies on several occasions.
* Maacah was the name of several women, including the mother of David's son Absalom.
* King Asa removed his grandmother Maacah from being queen because she had promoted Asherah worship.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Asa](#asa), [Asherah](#asherim), [Nahor](#nahor), [Naphtali](#naphtali), [twelve tribes of Israel](other.html#12tribesofisrael))

### Bible References:

### Word Data:

* Strong's: H4601


## <a id="tw-term-names-macedonia"/>Macedonia

### Facts:

In New Testament times, Macedonia was a Roman province located just north of ancient Greece.

* Some important Macedonian cities mentioned in the Bible were Berea, Philippi and Thessalonica.
* Through a vision, God told Paul to preach the gospel to the people in Macedonia.
* Paul and his coworkers went to Macedonia and taught the people there about Jesus and helped the new believers to grow in their faith.
* In the Bible there are letters that Paul wrote to the believers in the Macedonian cities of Philippi and Thessalonica.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [believe](kt.html#believe), [Berea](#berea), [faith](kt.html#faith), [good news](kt.html#goodnews), [Greece](#greece), [Philippi](#philippi), [Thessalonica](#thessalonica))

### Bible References:

* [1 Thessalonians 01:6-7](https://git.door43.org/Door43/en_tn/src/master/1th/01/06.md)
* [1 Thessalonians 04:9-12](https://git.door43.org/Door43/en_tn/src/master/1th/04/09.md)
* [1 Timothy 01:3-4](https://git.door43.org/Door43/en_tn/src/master/1ti/01/03.md)
* [Acts 16:9-10](https://git.door43.org/Door43/en_tn/src/master/act/16/09.md)
* [Acts 20:1-3](https://git.door43.org/Door43/en_tn/src/master/act/20/01.md)
* [Philippians 04:14-17](https://git.door43.org/Door43/en_tn/src/master/php/04/14.md)

### Word Data:

* Strong's: G3109, G3110


## <a id="tw-term-names-maker"/>Maker

### Facts:

In general, a "maker" is someone who creates or makes things. 

* In the Bible, the term "Maker" is sometimes used as a name or title for Yahweh, because he created everything.
* Usually this term is combined with "his" or "my" or "your."

### Translation Suggestions:

* The term "Maker" can be translated as "the Creator" or "God who creates" or "the One who made everything."
* The phrase "his Maker" could also be translated as "the One who created him" or "God, who created him."
* The phrases "your Maker" and "my Maker" could be translated in a similar way.

(See also: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [create](other.html#creation), [Yahweh](kt.html#yahweh))

### Bible References:

* [Hosea 08:13-14](https://git.door43.org/Door43/en_tn/src/master/hos/08/13.md)

### Word Data:

* Strong's: H2796, H3335, H6213, H6466, H6467, G1217


## <a id="tw-term-names-malachi"/>Malachi

### Facts:

Malachi was one of God's prophets to the kingdom of Judah. He lived around 500 years before Christ was on earth.

* Malachi prophesied during the period when Israel's temple was being rebuilt after returning from the Babylonian captivity.
* Ezra and Nehemiah lived around the same time as Malachi.
* The book of Malachi is the last book of the Old Testament.
* Like all the Old Testament prophets, Malachi urged the people to repent of their sins and to turn back to worshiping Yahweh.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Babylon](#babylon), [captive](other.html#captive), [Ezra](#ezra), [Judah](#kingdomofjudah), [Nehemiah](#nehemiah), [prophet](kt.html#prophet), [repent](kt.html#repent), [turn](other.html#turn))

### Bible References:

* [Malachi 01:1-3](https://git.door43.org/Door43/en_tn/src/master/mal/01/01.md)

### Word Data:

* Strong's: H4401


## <a id="tw-term-names-manasseh"/>Manasseh

### Facts:

There were five men by the name of Manasseh in the Old Testament: 

* Manasseh was the name of Joseph's firstborn son.
* Both Manasseh and his younger brother Ephraim were adopted by Joseph's father, Jacob which gave their descendants the privilege of being among the twelve tribes of Israel.
* The descendants of Manasseh formed one of the tribes of Israel.
* The tribe of Manasseh was often called the "half-tribe of Manasseh" because only part of the tribe settled in the land of Canaan, on the west side of the Jordan River. The other part of the tribe settled on the east side of the Jordan.
 
* One of the kings of Judah was also named Manasseh.
* King Manasseh was an evil king who sacrificed his own children as burnt offerings to false gods.
* God punished King Manasseh by allowing him to be captured by an enemy army. Manasseh turned back to God and destroyed the altars where idols were worshiped.
* Two men named Manasseh lived during the time of Ezra. These men were required to divorce their pagan wives, who had influenced them to worship false gods.
* One other Manasseh was the grandfather of some Danites who were priests for false gods.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [altar](kt.html#altar), [Dan](#dan), [Ephraim](#ephraim), [Ezra](#ezra), [false god](kt.html#falsegod), [Jacob](#jacob), [Judah](#judah), [pagan](other.html#pagan), [twelve tribes of Israel](other.html#12tribesofisrael))

### Bible References:

* [2 Chronicles 15:8-9](https://git.door43.org/Door43/en_tn/src/master/2ch/15/08.md)
* [Deuteronomy 03:12-13](https://git.door43.org/Door43/en_tn/src/master/deu/03/12.md)
* [Genesis 41:50-52](https://git.door43.org/Door43/en_tn/src/master/gen/41/50.md)
* [Genesis 48:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/48/01.md)
* [Judges 01:27-28](https://git.door43.org/Door43/en_tn/src/master/jdg/01/27.md)

### Word Data:

* Strong's: H4519, H4520, G3128


## <a id="tw-term-names-manofgod"/>man of God

### Facts:

The expression "man of God" is a respectful way of referring to a prophet of Yahweh. It is also used to refer to an angel of Yahweh.

* When referring to a prophet, this could also be translated as "man who belongs to God" or "man whom God has chosen" or "man who serves God."
* When referring to an angel this could also be translated as "messenger of God" or "your angel" or "heavenly being from God who looks like a man."

(See also: [angel](kt.html#angel), [honor](kt.html#honor), [prophet](kt.html#prophet))

### Bible References:

* [1 Chronicles 23:12-14](https://git.door43.org/Door43/en_tn/src/master/1ch/23/12.md)
* [1 Kings 12:22-24](https://git.door43.org/Door43/en_tn/src/master/1ki/12/22.md)
* [1 Samuel 09:9-11](https://git.door43.org/Door43/en_tn/src/master/1sa/09/09.md)

### Word Data:

* Strong's: H376, H430, G444, G2316


## <a id="tw-term-names-martha"/>Martha

### Facts:

Martha was a woman from Bethany who followed Jesus.

* Martha had a sister named Mary and a brother named Lazarus, who also followed Jesus.
* One time when Jesus was visiting them in their home, Martha was distracted by meal preparation while her sister Mary sat and listened to Jesus teach.
* When Lazarus died, Martha told Jesus that she believed that Jesus is the Christ, the Son of God.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Lazarus](#lazarus), [Mary (sister of Martha)](#marysisterofmartha))

### Bible References:

* [John 11:1-2](https://git.door43.org/Door43/en_tn/src/master/jhn/11/01.md)
* [John 12:1-3](https://git.door43.org/Door43/en_tn/src/master/jhn/12/01.md)
* [Luke 10:38-39](https://git.door43.org/Door43/en_tn/src/master/luk/10/38.md)

### Word Data:

* Strong's: G3136


## <a id="tw-term-names-mary"/>Mary, the mother of Jesus

### Facts:

Mary was a young woman living in the city of Nazareth who was pledged to be married to a man named Joseph. God chose Mary to be the mother of Jesus the Messiah, the Son of God.

* The Holy Spirit miraculously caused Mary to become pregnant while she was a virgin.
* An angel told Mary that the baby to be born to her was the Son of God and that she must name him Jesus.
* Mary loved God and praised him for being gracious to her.
* Joseph married Mary, but she remained a virgin until after the baby was born.
* Mary thought deeply about the amazing things that the shepherds and wise men said about the baby Jesus.
* Mary and Joseph took the baby Jesus to be dedicated at the temple. Later they took him to Egypt to escape King Herod's plot to kill the baby. Eventually they moved back to Nazareth.
* When Jesus was an adult, Mary was with him when he changed water to wine at a wedding in Cana.
* The gospels also mention that Mary was at the cross when Jesus was dying. He told his disciple John to take care of her like his own mother.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Cana](#cana), [Egypt](#egypt), [Herod the Great](#herodthegreat), [Jesus](kt.html#jesus), [Joseph (NT)](#josephnt), [Son of God](kt.html#sonofgod), [virgin](other.html#virgin))

### Bible References:

* [John 02:3-5](https://git.door43.org/Door43/en_tn/src/master/jhn/02/03.md)
* [John 02:12](https://git.door43.org/Door43/en_tn/src/master/jhn/02/12.md)
* [Luke 01:26-29](https://git.door43.org/Door43/en_tn/src/master/luk/01/26.md)
* [Luke 01:34-35](https://git.door43.org/Door43/en_tn/src/master/luk/01/34.md)
* [Mark 06:1-3](https://git.door43.org/Door43/en_tn/src/master/mrk/06/01.md)
* [Matthew 01:15-17](https://git.door43.org/Door43/en_tn/src/master/mat/01/15.md)
* [Matthew 01:18-19](https://git.door43.org/Door43/en_tn/src/master/mat/01/18.md)

### Examples from the Bible stories:

  __*[22:04](https://git.door43.org/Door43/en_tn/src/master/obs/22/04.md)__ When Elizabeth was six months pregnant, the same angel appeared to Elizabeth's relative, whose name was __Mary__. She was a virgin and was engaged to be married to a man named Joseph. The angel said, "You will become pregnant and give birth to a son. You are to name him Jesus and he will be the Messiah."
  __*[22:05](https://git.door43.org/Door43/en_tn/src/master/obs/22/05.md)__ The angel explained, "The Holy Spirit will come to you, and the power of God will overshadow you. So the baby will be holy, the Son of God." __Mary__ believed and accepted what the angel said.
  __*[22:06](https://git.door43.org/Door43/en_tn/src/master/obs/22/06.md)__ Soon after the angel spoke to __Mary__, she went and visited Elizabeth. As soon as Elizabeth heard __Mary's__ greeting, Elizabeth's baby jumped inside her.
  __*[23:02](https://git.door43.org/Door43/en_tn/src/master/obs/23/02.md)__ The angel said, "Joseph, do not be afraid to take __Mary__ as your wife. The baby in her body is from the Holy Spirit."
  __*[23:04](https://git.door43.org/Door43/en_tn/src/master/obs/23/04.md)__ Joseph and __Mary__ had to make a long journey from where they lived in Nazareth to Bethlehem because their ancestor was David whose hometown was Bethlehem.
  __*[49:01](https://git.door43.org/Door43/en_tn/src/master/obs/49/01.md)__ An angel told a virgin named __Mary__ that she would give birth to God's Son. So while she was still a virgin, she gave birth to a son and named him Jesus. 

### Word Data:

* Strong's: G3137


## <a id="tw-term-names-marymagdalene"/>Mary Magdalene

### Facts:

Mary Magdalene was one of several women who believed in Jesus and followed him in his ministry. She was known as the one whom Jesus had healed from seven demons who had controlled her.

* Mary Magdalene and some other women helped support Jesus and his apostles by giving to them.
* She is also mentioned as one of the women who were the first to see Jesus after he rose from the dead.
* As Mary Magdalene stood outside the empty tomb, she saw Jesus standing there and he told her to go tell the other disciples that he was alive again.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [demon](kt.html#demon), [demon-possessed](kt.html#demonpossessed))

### Bible References:

* [Luke 08:1-3](https://git.door43.org/Door43/en_tn/src/master/luk/08/01.md)
* [Luke 24:8-10](https://git.door43.org/Door43/en_tn/src/master/luk/24/08.md)
* [Mark 15:39-41](https://git.door43.org/Door43/en_tn/src/master/mrk/15/39.md)
* [Matthew 27:54-56](https://git.door43.org/Door43/en_tn/src/master/mat/27/54.md)

### Word Data:

* Strong's: G3094, G3137


## <a id="tw-term-names-marysisterofmartha"/>Mary (sister of Martha)

### Facts:

Mary was a women from Bethany who followed Jesus.

 * Mary had a sister named Martha and a brother named Lazarus who also followed Jesus. 
 * One time Jesus said that Mary had chosen what was best when she chose to listen to him teach rather than being anxious about preparing him a meal as Martha was. 
 * Jesus brought Mary's brother Lazarus back to life.
 * Sometime after that, while Jesus was eating in someone's home in Bethany, Mary poured expensive perfume on his feet in order to worship him.
 * Jesus praised her for doing this and said that she was preparing his body for burial.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Bethany](#bethany), [frankincense](other.html#frankincense), [Lazarus](#lazarus), [Martha](#martha))

### Bible References:

* [John 11:1-2](https://git.door43.org/Door43/en_tn/src/master/jhn/11/01.md)
* [John 12:1-3](https://git.door43.org/Door43/en_tn/src/master/jhn/12/01.md)
* [Luke 10:38-39](https://git.door43.org/Door43/en_tn/src/master/luk/10/38.md)

### Word Data:

* Strong's: G3137


## <a id="tw-term-names-matthew"/>Matthew, Levi

### Facts:

Matthew was one of the twelve men that Jesus chose to be his apostles. He was also known as Levi, son of Alpheus.

 * Levi (Matthew) was a tax-collector from Capernaum before he met Jesus.
 * Matthew wrote the gospel that bears his name.
 * There are several other men named Levi in the Bible.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [apostle](kt.html#apostle), [Levite](#levite), [tax collector](other.html#taxcollector))

### Bible References:

* [Luke 05:27-28](https://git.door43.org/Door43/en_tn/src/master/luk/05/27.md)
* [Luke 06:14-16](https://git.door43.org/Door43/en_tn/src/master/luk/06/14.md)
* [Mark 02:13-14](https://git.door43.org/Door43/en_tn/src/master/mrk/02/13.md)
* [Mark 03:17-19](https://git.door43.org/Door43/en_tn/src/master/mrk/03/17.md)
* [Matthew 09:7-9](https://git.door43.org/Door43/en_tn/src/master/mat/09/07.md)
* [Matthew 10:2-4](https://git.door43.org/Door43/en_tn/src/master/mat/10/02.md)

### Word Data:

* Strong's: G3017, G3156


## <a id="tw-term-names-mede"/>Medes, Media

### Facts:

Media was an ancient empire located east of Assyria and Babylonia, and north of Elam and Persia. The people who lived in the empire of Media were called "Medes."

* The Media empire covered parts of what are present-day Turkey, Iran, Syria, Iraq and Afghanistan.
* The Medes were closely associated with the Persians and the two empires joined forces to conquer the Babylonian empire.
* Babylonia was invaded by Darius the Mede during the time that the prophet Daniel was living there.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Assyria](#assyria), [Babylon](#babylon), [Cyrus](#cyrus), [Daniel](#daniel), [Darius](#darius), [Elam](#elam), [Persia](#persia))

### Bible References:

* [2 Kings 17:4-6](https://git.door43.org/Door43/en_tn/src/master/2ki/17/04.md)
* [Acts 02:8-11](https://git.door43.org/Door43/en_tn/src/master/act/02/08.md)
* [Daniel 05:25-28](https://git.door43.org/Door43/en_tn/src/master/dan/05/25.md)
* [Esther 01:3-4](https://git.door43.org/Door43/en_tn/src/master/est/01/03.md)
* [Ezra 06:1-2](https://git.door43.org/Door43/en_tn/src/master/ezr/06/01.md)

### Word Data:

* Strong's: H4074, H4075, H4076, H4077, G3370


## <a id="tw-term-names-mediterranean"/>the sea, the Great Sea, the western sea, Mediterranean Sea

### Facts:

In the Bible, the "Great Sea" or "western sea" refers to what is now called the "Mediterranean Sea," which was the largest body of water known to the people of Bible times.

* The Mediterranean Sea is bordered by : Israel (east), Europe (north and west), and Africa (south).
* This sea was very important in ancient times for trade and travel since it bordered so many countries. Cities and people groups located on the coast of this sea were very prosperous because of how easy it was to access goods from other countries by boat.
* Since the Great Sea was located to the west of Israel, it was sometimes referred to as the "western sea."

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Israel](kt.html#israel), [people group](other.html#peoplegroup), [prosper](other.html#prosper))

### Bible References:

* [Ezekiel 47:15-17](https://git.door43.org/Door43/en_tn/src/master/ezk/47/15.md)
* [Ezekiel 47:18-20](https://git.door43.org/Door43/en_tn/src/master/ezk/47/18.md)
* [Joshua 15:3-4](https://git.door43.org/Door43/en_tn/src/master/jos/15/03.md)
* [Numbers 13:27-29](https://git.door43.org/Door43/en_tn/src/master/num/13/27.md)

### Word Data:

* Strong's: H314, H1419, H3220


## <a id="tw-term-names-melchizedek"/>Melchizedek
​
### Facts:

During the time when Abram lived, Melchizedek was the king of the city of Salem (later "Jerusalem")

* Melchizedek's name means "king of righteousness" and his title "king of Salem" means "king of peace."
* He was also called a "priest of God Most High."
* Melchizedek is first mentioned in the Bible when he served Abram bread and wine after Abram rescued his nephew Lot from powerful kings. Abram gave Melchizedek one-tenth of the plunder from his victory.
* In the New Testament, Melchizedek is described as someone who had no father or mother. He was called a priest and king who will reign forever. 
* The New Testament also says that Jesus is a priest according to the priestly "order of Melchizedek." Jesus was not descended from Levi as the Israelite priests were. His priesthood is directly from God, as Melchizedek's was.
* Based on these descriptions of him in the Bible, Melchizedek was a human priest who was also chosen by God to represent or point forward to Jesus, the eternal king of peace and righteousness and our great high priest.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Abraham](#abraham), [everlasting](kt.html#eternity), [high priest](kt.html#highpriest), [Jerusalem](#jerusalem), [Levite](#levite), [priest](kt.html#priest), [righteous](kt.html#righteous))

### Bible References:

* [Genesis 14:17-18](https://git.door43.org/Door43/en_tn/src/master/gen/14/17.md)
* [Hebrews 06:19-20](https://git.door43.org/Door43/en_tn/src/master/heb/06/19.md)
* [Hebrews 07:15-17](https://git.door43.org/Door43/en_tn/src/master/heb/07/15.md)
* [Psalm 110:4](https://git.door43.org/Door43/en_tn/src/master/psa/110/004.md)




## <a id="tw-term-names-memphis"/>Memphis

### Definition:

Memphis was an ancient capital city in Egypt, along the Nile River.

* Memphis was located in Lower Egypt, just south of the Nile River delta, where the soil was very fertile and crops were plentiful.
* Its fertile soil and important location between Upper and Lower Egypt caused Memphis to become a major city of trade and commerce.

(Translation suggestions: [Translating Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Egypt](#egypt), [Nile River](#nileriver))

### Bible References:

* [Hosea 09:5-6](https://git.door43.org/Door43/en_tn/src/master/hos/09/05.md)

### Word Data:

* Strong's: H4644, H5297


## <a id="tw-term-names-meshech"/>Meshech

### Facts:

Meshech is the name of two men in the Old Testament.

* One Meshech was a son of Japheth.
* The other Meshech was a grandson of Shem.
* Meshech was also the name of a region of land, which was probably named after one of these men.
* The region of Meshech may have been located in part of what is now the country of Turkey.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Japheth](#japheth), [Noah](#noah), [Shem](#shem))

### Bible References:

* [1 Chronicles 01:5-7](https://git.door43.org/Door43/en_tn/src/master/1ch/01/05.md)
* [Ezekiel 27:12-13](https://git.door43.org/Door43/en_tn/src/master/ezk/27/12.md)
* [Genesis 10:2-5](https://git.door43.org/Door43/en_tn/src/master/gen/10/02.md)
* [Psalms 120:5-7](https://git.door43.org/Door43/en_tn/src/master/psa/120/005.md)

### Word Data:

* Strong's: H4851, H4902


## <a id="tw-term-names-mesopotamia"/>Mesopotamia, Aram Naharaim

### Facts:

Mesopotamia is the area of land between the Tigris and Euphrates Rivers. Its location is in the region of the modern day country of Iraq.

* In the Old Testament, this region was called "Aram Naharaim."
* The word "Mesopotamia" means "between rivers." The phrase "Aram Naharaim" means "Aram of two rivers."
* Abraham lived in the Mesopotamian cities of Ur and Haran before moving on to the land of Canaan.
* Babylon was another important city in Mesopotamia.
* The region called "Chaldea" was also part of Mesopotamia.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Aram](#aram), [Babylon](#babylon), [Chaldea](#chaldeans), [Euphrates River](#euphrates))

### Bible References:

* [Acts 02:8-11](https://git.door43.org/Door43/en_tn/src/master/act/02/08.md)
* [Acts 07:1-3](https://git.door43.org/Door43/en_tn/src/master/act/07/01.md)
* [Genesis 24:10-11](https://git.door43.org/Door43/en_tn/src/master/gen/24/10.md)

### Word Data:

* Strong's: H763, G3318


## <a id="tw-term-names-micah"/>Micah

### Facts:

Micah was a prophet of Judah around 700 years before Christ, when the prophet Isaiah was also ministering to Judah. Another man named Micah lived during the time of the judges.

* The book of Micah is near the end of the Old Testament.
* Micah prophesied about the destruction of Samaria by the Assyrians.
* Micah rebuked the people of Judah for disobeying God and warned them that their enemies would attack them.
* His prophecy ends with a message of hope in God, who is faithful and saves his people.
* In the book of Judges, the story is told of a man named Micah living in Ephraim who made an idol out of silver. A young Levite priest who came to live with him  stole the idol and other things, and took off with a group of Danites. Eventually the Danites and the priest settled in the city of Laish and they set up that same silver idol to worship.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Assyria](#assyria), [Dan](#dan), [Ephraim](#ephraim), [false god](kt.html#falsegod), [Isaiah](#isaiah), [Judah](#kingdomofjudah), [judge](other.html#judgeposition), [Levite](#levite), [priest](kt.html#priest), [prophet](kt.html#prophet), [Samaria](#samaria), [silver](other.html#silver))

### Bible References:

* [Jeremiah 26:18-19](https://git.door43.org/Door43/en_tn/src/master/jer/26/18.md)
* [Micah 01:1](https://git.door43.org/Door43/en_tn/src/master/mic/01/01.md)
* [Micah 06:1-2](https://git.door43.org/Door43/en_tn/src/master/mic/06/01.md)

{{tag>publish ktlink}

### Word Data:

* Strong's: H4316, H4318


## <a id="tw-term-names-michael"/>Michael

### Facts:

Michael is the chief of all God's holy, obedient angels. He is the only angel who is specifically referred to as the "archangel" of God.

* The term "archangel" literally means "chief angel" or "ruling angel."
* Michael is a warrior who fights against God's enemies and protects God's people.
* He led the Israelites in fighting against the Persian army. In the end times he will lead the armies of Israel in the final battle against the forces of evil, as foretold in Daniel.
* There are also several men in the Bible with the name Michael. Several men are identified as being the "son of Michael"

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [angel](kt.html#angel), [Daniel](#daniel), [messenger](other.html#messenger), [Persia](#persia))

### Bible References:

* [Daniel 10:12-13](https://git.door43.org/Door43/en_tn/src/master/dan/10/12.md)
* [Daniel 10:20-21](https://git.door43.org/Door43/en_tn/src/master/dan/10/20.md)
* [Ezra 08:8-11](https://git.door43.org/Door43/en_tn/src/master/ezr/08/08.md)
* [Revelation 12:7-9](https://git.door43.org/Door43/en_tn/src/master/rev/12/07.md)

### Word Data:

* Strong's: H4317, G3413


## <a id="tw-term-names-midian"/>Midian, Midianite, Midianites

### Facts:

Midian was a son of Abraham and his wife Keturah. It is also the name of a people group and region located in the northern Arabian Desert to the south of the land of Canaan. The people of that group were called "Midianites."

* When Moses first left Egypt, he went to the region of Midian where he met the daughters of Jethro and helped them water their flocks. Later Moses married one of Jethro's daughters.
* Joseph was taken to Egypt by a group of Midianite slave traders.
* Many years later the Midianites attacked and raided the Israelites in the land of Canaan. Gideon led the Israelites in defeating them.
* Many of the modern-day Arabian tribes are descendants of this group.

(See also   [Arabia](#arabia), [Egypt](#egypt), [flock](other.html#flock), [Gideon](#gideon), [Jethro](#jethro), [Moses](#moses)) 

### Bible References:

* [Acts 07:29-30](https://git.door43.org/Door43/en_tn/src/master/act/07/29.md)
* [Exodus 02:15-17](https://git.door43.org/Door43/en_tn/src/master/exo/02/15.md)
* [Genesis 25:1-4](https://git.door43.org/Door43/en_tn/src/master/gen/25/01.md)
* [Genesis 36:34-36](https://git.door43.org/Door43/en_tn/src/master/gen/36/34.md)
* [Genesis 37:27-28](https://git.door43.org/Door43/en_tn/src/master/gen/37/27.md)
* [Judges 07:1](https://git.door43.org/Door43/en_tn/src/master/jdg/07/01.md)

### Examples from the Bible stories:

  __*[16:03](https://git.door43.org/Door43/en_tn/src/master/obs/16/03.md)__ But then the people forgot about God and started worshiping idols again. So God allowed the __Midianites__, a nearby enemy people group, to defeat them. 
  __*[16:04](https://git.door43.org/Door43/en_tn/src/master/obs/16/04.md)__ The Israelites were so scared, they hid in caves so the __Midianites__ would not find them. 
  __*[16:11](https://git.door43.org/Door43/en_tn/src/master/obs/16/11.md)__ The man's friend said, "This dream means that Gideon's army will defeat the __Midianite__ army!" 
  __*[16:14](https://git.door43.org/Door43/en_tn/src/master/obs/16/14.md)__ God confused the __Midianites__, so that they started attacking and killing each other. 

### Word Data:

* Strong's: H4080, H4084, H4092


## <a id="tw-term-names-miriam"/>Miriam

### Facts:

Miriam was the older sister of Aaron and Moses.

* When she was young, Miriam was instructed by her mother to watch over her baby brother Moses who was in a basket among the reeds of the Nile River. When the pharaoh's daughter found the baby and needed someone to take care of him for her, Miriam brought her mother to do it.
* Miriam led the Israelites in a dance of joy and thanksgiving after they had escaped from the Egyptians by crossing the Red Sea.
* Years later as the Israelites were wandering in the desert, Miram and Aaron began speaking badly about Moses because he had married a Cushite woman.
* Because of her rebellion in speaking against Moses, God caused Miriam to become sick with leprosy. But later God healed her when Moses interceded for her.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Aaron](#aaron), [Cush](#cush), [intercede](kt.html#intercede), [Moses](#moses), [Nile River](#nileriver), [Pharaoh](#pharaoh), [rebel](other.html#rebel))

### Bible References:

* [1 Chronicles 06:1-3](https://git.door43.org/Door43/en_tn/src/master/1ch/06/01.md)
* [Deuteronomy 24:8-9](https://git.door43.org/Door43/en_tn/src/master/deu/24/08.md)
* [Micah 06:3-5](https://git.door43.org/Door43/en_tn/src/master/mic/06/03.md)
* [Numbers 12:1-3](https://git.door43.org/Door43/en_tn/src/master/num/12/01.md)
* [Numbers 20:1](https://git.door43.org/Door43/en_tn/src/master/num/20/01.md)

### Word Data:

* Strong's: H4813


## <a id="tw-term-names-mishael"/>Mishael

### Facts:

Mishael is the name of three men in the Old Testament.

* One man named Mishael was a cousin of Aaron. When two of Aaron's sons were killed by God after they offered incense in a away that did not follow what God had told them to do, Mishael and his brother were given the task of carrying the dead bodies outside the Israelite camp.
* Another man named Mishael stood beside Ezra when he publicly read the rediscovered law.
* During the time when the people of Israel were in exile in Babylon, a young man named Mishael was also captured and forced to live in Babylon. The Babylonians gave him the name, "Meshach." He, along with his companions, Azariah (Shadrach) and Hananiah (Abednego), refused to worship the king's statue and were thrown into a fiery furnace.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Aaron](#aaron), [Azariah](#azariah), [Babylon](#babylon), [Daniel](#daniel), [Hananiah](#hananiah))

### Bible References:

* [Daniel 01:6-7](https://git.door43.org/Door43/en_tn/src/master/dan/01/06.md)
* [Daniel 02:17-18](https://git.door43.org/Door43/en_tn/src/master/dan/02/17.md)

### Word Data:

* Strong's: H4332, H4333


## <a id="tw-term-names-mizpah"/>Mizpah

### Facts:

Mizpah is the name of several towns mentioned in the Old Testament. It means, "look-out point" or "watchtower."

* When David was being pursued by Saul, he left his parents in Mizpah, under the protection of the king of Moab.
* One city called Mizpah was located on the border between the kingdoms of Judah and Israel. It was a major military center.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [David](#david), [Judah](#kingdomofjudah), [kingdom of Israel](#kingdomofisrael), [Moab](#moab), [Saul (OT)](#saul))

### Bible References:

* [1 Kings 15:20-22](https://git.door43.org/Door43/en_tn/src/master/1ki/15/20.md)
* [1 Samuel 07:5-6](https://git.door43.org/Door43/en_tn/src/master/1sa/07/05.md)
* [1 Samuel 07:10-11](https://git.door43.org/Door43/en_tn/src/master/1sa/07/10.md)
* [Jeremiah 40:5-6](https://git.door43.org/Door43/en_tn/src/master/jer/40/05.md)
* [Judges 10:17-18](https://git.door43.org/Door43/en_tn/src/master/jdg/10/17.md)

### Word Data:

* Strong's: H4708, H4709


## <a id="tw-term-names-moab"/>Moab, Moabite, Moabitess

### Facts:

Moab was the son of Lot's elder daughter. It also became the name of the land where he and his family lived. The term "Moabite" refers to a person who is descended from Moab or who lives in the country of Moab.

* The country of Moab was located east of the Salt Sea.
* Moab was southeast from the town of Bethlehem where Naomi's family lived.
* The people in Bethlehem called Ruth a "Moabitess" because she was a woman from the country of Moab. This term could also be translated as "Moabite woman" or "woman from Moab."

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Bethlehem](#bethlehem), [Judea](#judea), [Lot](#lot), [Ruth](#ruth), [Salt Sea](#saltsea))

### Bible References:

* [Genesis 19:36-38](https://git.door43.org/Door43/en_tn/src/master/gen/19/36.md)
* [Genesis 36:34-36](https://git.door43.org/Door43/en_tn/src/master/gen/36/34.md)
* [Ruth 01:1-2](https://git.door43.org/Door43/en_tn/src/master/rut/01/01.md)
* [Ruth 01:22](https://git.door43.org/Door43/en_tn/src/master/rut/01/22.md)

### Word Data:

* Strong's: H4124, H4125


## <a id="tw-term-names-molech"/>Molech, Moloch

### Facts:

Molech was the name of one of the false gods that the Canaanites worshiped. Other spellings are "Moloch" and "Molek."

* People who worshiped Molech sacrificed their children to him by means of fire.
* Some of the Israelites also worshiped Molech instead of the one true God, Yahweh. They followed the evil practices of Molech worshipers, including sacrificing their children.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Canaan](#canaan), [evil](kt.html#evil), [false god](kt.html#falsegod), [God](kt.html#god), [false god](kt.html#falsegod), [sacrifice](other.html#sacrifice), [true](kt.html#true), [worship](kt.html#worship), [Yahweh](kt.html#yahweh))

### Bible References:

* [1 Kings 11:7-8](https://git.door43.org/Door43/en_tn/src/master/1ki/11/07.md)
* [2 Kings 23:10-11](https://git.door43.org/Door43/en_tn/src/master/2ki/23/10.md)
* [Acts 07:43](https://git.door43.org/Door43/en_tn/src/master/act/07/43.md)
* [Jeremiah 32:33-35](https://git.door43.org/Door43/en_tn/src/master/jer/32/33.md)
* [Leviticus 18:21](https://git.door43.org/Door43/en_tn/src/master/lev/18/21.md)

### Word Data:

* Strong's: H4428, H4432, G3434


## <a id="tw-term-names-mordecai"/>Mordecai

### Facts:

Mordecai was a Jewish man living in the country of Persia. He was the guardian of his cousin Esther, who later became the wife of the Persian king, Ahasuerus.

* While working at the royal palace, Mordecai overheard men plotting together to kill King Ahasuerus. He reported this and the king's life was saved.
* Some time later, Mordecai also found out about a plan to kill all the Jews in the kingdom of Persia. He advised Esther to appeal to the king to save her people.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Ahasuerus](#ahasuerus), [Babylon](#babylon), [Esther](#esther), [Persia](#persia))

### Bible References:

* [Esther 02:5-6](https://git.door43.org/Door43/en_tn/src/master/est/02/05.md)
* [Esther 03:5-6](https://git.door43.org/Door43/en_tn/src/master/est/03/05.md)
* [Esther 08:1-2](https://git.door43.org/Door43/en_tn/src/master/est/08/01.md)
* [Esther 10:1-2](https://git.door43.org/Door43/en_tn/src/master/est/10/01.md)

### Word Data:

* Strong's: H4782


## <a id="tw-term-names-moses"/>Moses

### Facts:

Moses was a prophet and leader of the Israelite people for over 40 years.  

 * When Moses was a baby, Moses' parents put him in a basket in the reeds of the Nile River to hide him from the Egyptian Pharaoh. Moses' sister Miriam watched over him there. Moses' life was spared when the pharaoh's daughter found him and took him to the palace to raise him as her son.
 * God chose Moses to free the Israelites from slavery in Egypt and to lead them to the Promised Land.
 * After the Israelites' escape from Egypt and while they were wandering in the desert, God gave Moses two stone tablets with the Ten Commandments written on them.
 * Near the end of his life, Moses saw the Promised Land, but didn't get to live in it because he disobeyed God.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Miriam](#miriam), [Promised Land](kt.html#promisedland), [Ten Commandments](other.html#tencommandments))

### Bible References:

* [Acts 07:20-21](https://git.door43.org/Door43/en_tn/src/master/act/07/20.md)
* [Acts 07:29-30](https://git.door43.org/Door43/en_tn/src/master/act/07/29.md)
* [Exodus 02:9-10](https://git.door43.org/Door43/en_tn/src/master/exo/02/09.md)
* [Exodus 09:1-4](https://git.door43.org/Door43/en_tn/src/master/exo/09/01.md)
* [Matthew 17:3-4](https://git.door43.org/Door43/en_tn/src/master/mat/17/03.md)
* [Romans 05:14-15](https://git.door43.org/Door43/en_tn/src/master/rom/05/14.md)

### Examples from the Bible stories:

  __*[09:12](https://git.door43.org/Door43/en_tn/src/master/obs/09/12.md)__ One day while __Moses__ was taking care of his sheep, he saw a bush that was on fire.
  __*[12:05](https://git.door43.org/Door43/en_tn/src/master/obs/12/05.md)__ __Moses__ told the Israelites, "Stop being afraid! God will fight for you today and save you."
  __*[12:07](https://git.door43.org/Door43/en_tn/src/master/obs/12/07.md)__ God told __Moses__ to raise his hand over the sea and divide the waters.
  __*[12:12](https://git.door43.org/Door43/en_tn/src/master/obs/12/12.md)__ When the Israelites saw that the Egyptians were dead, they trusted in God and believed that Moses was a prophet of God.
  __*[13:07](https://git.door43.org/Door43/en_tn/src/master/obs/13/07.md)__ Then God wrote these Ten Commandments on two stone tablets and gave them to __Moses__.



\\

### Word Data:

* Strong's: H4872, H4873, G3475


## <a id="tw-term-names-mounthermon"/>Mount Hermon

### Facts:

Mount Hermon is the name of the tallest mountain in Israel at the southern tip of the Lebanon mountain range.

* It is located north of the Sea of Galilee, at the northern border between Israel and Syria.
* Other names given to Mount Hermon by other people groups were "Mount Sirion" and "Mount Senir."
* Mount Hermon has three major peaks. The tallest peak is around 2,800 meters high.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Israel](kt.html#israel), [Sea of Galilee](#seaofgalilee), [Syria](#syria))

### Bible References:

* [1 Chronicles 05:23-24](https://git.door43.org/Door43/en_tn/src/master/1ch/05/23.md)
* [Ezekiel 27:4-5](https://git.door43.org/Door43/en_tn/src/master/ezk/27/04.md)
* [Joshua 11:16-17](https://git.door43.org/Door43/en_tn/src/master/jos/11/16.md)
* [Psalms 042:5-6](https://git.door43.org/Door43/en_tn/src/master/psa/042/005.md)
* [Song of Solomon 04:8](https://git.door43.org/Door43/en_tn/src/master/sng/04/08.md)

### Word Data:

* Strong's: H2022, H2768, H2769, H8149


## <a id="tw-term-names-mountofolives"/>Mount of Olives

### Definition:

The Mount of Olives is a mountain or large hill located near the east side of the city of Jerusalem. It is about 787 meters high.

* In the Old Testament, this mountain is sometimes referred to as "the mountain that is east of Jerusalem."
* The New Testament records several occasions when Jesus and his disciples went to the Mount of Olives to pray and rest.
* Jesus was arrested in the Garden of Gethsemane, which is located on the Mount of Olives.
* This could also be translated as "Olive Hill" or "Olive Tree Mountain."

(See also: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Gethsemane](#gethsemane), [olive](other.html#olive))

### Bible References:

* [Luke 19:29-31](https://git.door43.org/Door43/en_tn/src/master/luk/19/29.md)
* [Luke 19:37-38](https://git.door43.org/Door43/en_tn/src/master/luk/19/37.md)
* [Mark 13:3-4](https://git.door43.org/Door43/en_tn/src/master/mrk/13/03.md)
* [Matthew 21:1-3](https://git.door43.org/Door43/en_tn/src/master/mat/21/01.md)
* [Matthew 24:3-5](https://git.door43.org/Door43/en_tn/src/master/mat/24/03.md)
* [Matthew 26:30-32](https://git.door43.org/Door43/en_tn/src/master/mat/26/30.md)

### Word Data:

* Strong's: H2022, H2132, G3735, G1636


## <a id="tw-term-names-naaman"/>Naaman

### Facts:

In the Old Testament, Naaman was the commander of the army of the king of Aram. 

* Naaman had a terrible skin disease called leprosy that could not be cured.
* A Jewish slave in Naaman's household told him to go ask the prophet Elisha to heal him.
* Elisha told Naaman to wash seven times in the Jordan River. When Naaman obeyed, God healed him of his disease.
* As a result, Naaman came to believe in the only true God, Yahweh.
* Two other men named Naaman were descendants of Jacob's son Benjamin.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Aram](#aram), [Jordan River](#jordanriver), [leprosy](other.html#leprosy), [prophet](kt.html#prophet))

### Bible References:

* [1 Chronicles 08:6-7](https://git.door43.org/Door43/en_tn/src/master/1ch/08/06.md)
* [2 Kings 05:1-2](https://git.door43.org/Door43/en_tn/src/master/2ki/05/01.md)
* [Luke 04:25-27](https://git.door43.org/Door43/en_tn/src/master/luk/04/25.md)

### Examples from the Bible stories:

* __[19:14](https://git.door43.org/Door43/en_tn/src/master/obs/19/14.md)__ One of the miracles happened to __Naaman__, an enemy commander, who had a horrible skin disease.
* __[19:15](https://git.door43.org/Door43/en_tn/src/master/obs/19/15.md)__ At first __Naaman__  was angry and would not do it because it seemed foolish. But later he changed his mind and dipped himself seven times in the Jordan River.
* __[26:06](https://git.door43.org/Door43/en_tn/src/master/obs/26/06.md)__ "He (Elisha) only healed the skin disease of __Naaman__, a commander of Israel's enemies."

### Word Data:

* Strong's: H5283, G3497


## <a id="tw-term-names-nahor"/>Nahor

### Facts:

Nahor was the name of two relatives of Abraham, his grandfather and his brother.

* Abraham's brother Nahor was the grandfather of Isaac's wife Rebekah.
* The phrase "city of Nahor" could mean  "the city named Nahor" or "the city where Nahor had lived" or "Nahor's city." 

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Abraham](#abraham), [Rebekah](#rebekah))

### Bible References:

* [1 Chronicles 01:24-27](https://git.door43.org/Door43/en_tn/src/master/1ch/01/24.md)
* [Genesis 31:51-53](https://git.door43.org/Door43/en_tn/src/master/gen/31/51.md)
* [Joshua 24:1-2](https://git.door43.org/Door43/en_tn/src/master/jos/24/01.md)
* [Luke 03:33-35](https://git.door43.org/Door43/en_tn/src/master/luk/03/33.md)

### Word Data:

* Strong's: H5152, G3493


## <a id="tw-term-names-nahum"/>Nahum

### Facts:

Nahum was a prophet who preached during the time when the evil King Manasseh was ruling over Judah.

* Nahum was from the town of Elkosh, which was about 20 miles from Jerusalem. 
* The Old Testament book of Nahum records his prophecies about the destruction of the Assyrian city of Nineveh.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Assyria](#assyria), [Manasseh](#manasseh), [prophet](kt.html#prophet), [Nineveh](#nineveh))

### Bible References:

* [Nahum 01:1](https://git.door43.org/Door43/en_tn/src/master/nam/01/01.md)

### Word Data:

* Strong's: H5151, G3486


## <a id="tw-term-names-naphtali"/>Naphtali

### Facts:

Naphtali was the sixth son of Jacob. His descendants formed the tribe of Naphtali, which was one of the twelve tribes of Israel.

* Sometimes the name Naphtali was used to refer to the land where the tribe lived. (See: [synecdoche](https://git.door43.org/Door43/en_man/src/master/translate/figs-synecdoche/01.md))
* The land of Naphtali was located in the northern part of Israel, next to the tribes of Dan and Asher. its eastern border was on the western shoreline of the Sea of Chinnereth.
* This tribe was mentioned in both the Old and New Testaments of the Bible.
 

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Asher](#asher), [Dan](#dan), [Jacob](#jacob), [Sea of Galilee](#seaofgalilee), [twelve tribes of Israel](other.html#12tribesofisrael))

### Bible References:

* [1 Kings 04:15-17](https://git.door43.org/Door43/en_tn/src/master/1ki/04/15.md)
* [Deuteronomy 27:13-14](https://git.door43.org/Door43/en_tn/src/master/deu/27/13.md)
* [Ezekiel 48:1-3](https://git.door43.org/Door43/en_tn/src/master/ezk/48/01.md)
* [Genesis 30:7-8](https://git.door43.org/Door43/en_tn/src/master/gen/30/07.md)
* [Judges 01:33](https://git.door43.org/Door43/en_tn/src/master/jdg/01/33.md)
* [Matthew 04:12-13](https://git.door43.org/Door43/en_tn/src/master/mat/04/12.md)

### Word Data:

* Strong's: H5321, G3508


## <a id="tw-term-names-nathan"/>Nathan

### Facts:

Nathan was a faithful prophet of God who lived while David was king over Israel.

* God sent Nathan to confront David after David sinned grievously against Uriah.
* Nathan rebuked David in spite of the fact that David was the king.
* David repented of his sin after Nathan confronted him.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [David](#david), [faithful](kt.html#faithful), [prophet](kt.html#prophet), [Uriah](#uriah))

### Bible References:

* [1 Chronicles 17:1-2](https://git.door43.org/Door43/en_tn/src/master/1ch/17/01.md)
* [2 Chronicles 09:29-31](https://git.door43.org/Door43/en_tn/src/master/2ch/09/29.md)
* [2 Samuel 12:1-3](https://git.door43.org/Door43/en_tn/src/master/2sa/12/01.md)
* [Psalm 051:1-2](https://git.door43.org/Door43/en_tn/src/master/psa/051/001.md)

### Examples from the Bible stories:

  __*[17:07](https://git.door43.org/Door43/en_tn/src/master/obs/17/07.md)__ God sent the prophet __Nathan__ to David with this message, "Because you are a man of war, you will not build this Temple for me."
  __*[17:13](https://git.door43.org/Door43/en_tn/src/master/obs/17/13.md)__ God was very angry about what David had done, so he sent the prophet __Nathan__ to tell David how evil his sin was. 

### Word Data:

* Strong's: H5416, G3481


## <a id="tw-term-names-nazareth"/>Nazareth, Nazarene

### Facts:

Nazareth is a town in the region of Galilee in northern Israel. It is about 100 kilometers north of Jerusalem, and it took about three to five days to travel on foot.

* Joseph and Mary were from Nazareth, and this is where they raised Jesus. That is why Jesus was known as "the Nazarene."
* Many of the Jews living in Nazareth did not respect Jesus' teaching because he had grown up among them, and they thought he was just an ordinary person.
* Once, when Jesus was teaching in Nazareths synagogue, the Jews there tried to kill him because he claimed to be the Messiah and had rebuked them for rejecting him.
* The remark Nathaniel made when he heard that Jesus was from Nazareth indicated that this city was not thought of very highly.

(See also: [Christ](kt.html#christ), [Galilee](#galilee), [Joseph (NT)](#josephnt), [Mary](#mary))

### Bible References:

* [Acts 26:9-11](https://git.door43.org/Door43/en_tn/src/master/act/26/09.md)
* [John 01:43-45](https://git.door43.org/Door43/en_tn/src/master/jhn/01/43.md)
* [Luke 01:26-29](https://git.door43.org/Door43/en_tn/src/master/luk/01/26.md)
* [Mark 16:5-7](https://git.door43.org/Door43/en_tn/src/master/mrk/16/05.md)
* [Matthew 02:22-23](https://git.door43.org/Door43/en_tn/src/master/mat/02/22.md)
* [Matthew 21:9-11](https://git.door43.org/Door43/en_tn/src/master/mat/21/09.md)
* [Matthew 26:71-72](https://git.door43.org/Door43/en_tn/src/master/mat/26/71.md)

### Examples from the Bible stories:

  __*[23:04](https://git.door43.org/Door43/en_tn/src/master/obs/23/04.md)__ Joseph and Mary had to make a long journey from where they lived in __Nazareth__ to Bethlehem because their ancestor was David whose hometown was Bethlehem.
  __*[26:02](https://git.door43.org/Door43/en_tn/src/master/obs/26/02.md)__ Jesus went to the town of __Nazareth__ where he had lived during his childhood.
  __*[26:07](https://git.door43.org/Door43/en_tn/src/master/obs/26/07.md)__ The people of __Nazareth__ dragged Jesus out of the place of worship and brought him to the edge of a cliff to throw him off of it in order to kill him.

### Word Data:

* Strong's: G3478, G3479, G3480


## <a id="tw-term-names-nebuchadnezzar"/>Nebuchadnezzar

### Facts:

Nebuchadnezzar was a king of the Babylonian Empire whose powerful army conquered many people groups and nations.

* Under Nebuchadnezzar's leadership, the Babylonian army attacked and conquered the kingdom of Judah, and took most of the people of Judah to Babylon as captives. The captives were forced to live there for a period of 70 years known as the "Babylonian Exile.
* One of the exiles, Daniel, interpreted some of King Nebuchadnezzar's dreams.
* Three other captured Israelites, Hananiah, Mishael, and Azariah, were thrown into a fiery furnace when they refused to bow down to a gigantic gold statue that Nebuchadnezzar had made.
* King Nebuchadnezzar was very arrogant and worshiped false gods. When he conquered Judah, he stole many gold and silver objects from the temple in Jerusalem.
* Because Nebuchadnezzar was proud and refused to turn away from worshiping false gods, Yahweh caused him to be destitute for seven years, living like an animal. After the seven years, God restored Nebuchadnezzar when he humbled himself and praised the one true God, Yahweh.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [arrogant](other.html#arrogant), [Azariah](#azariah), [Babylon](#babylon), [Hananiah](#hananiah), [Mishael](#mishael))

### Bible References:

* [1 Chronicles 06:13-15](https://git.door43.org/Door43/en_tn/src/master/1ch/06/13.md)
* [2 Kings 25:1-3](https://git.door43.org/Door43/en_tn/src/master/2ki/25/01.md)
* [Daniel 01:1-2](https://git.door43.org/Door43/en_tn/src/master/dan/01/01.md)
* [Daniel 04:4-6](https://git.door43.org/Door43/en_tn/src/master/dan/04/04.md)
* [Ezekiel 26:7-8](https://git.door43.org/Door43/en_tn/src/master/ezk/26/07.md)

### Examples from the Bible stories:

  __*[20:06](https://git.door43.org/Door43/en_tn/src/master/obs/20/06.md)__ About 100 years after the Assyrians destroyed the kingdom of Israel, God sent __Nebuchadnezzar__, king of the Babylonians, to attack the kingdom of Judah.
  __*[20:06](https://git.door43.org/Door43/en_tn/src/master/obs/20/06.md)__ The king of Judah agreed to be __Nebuchadnezzar's__ servant and pay him a lot of money every year.
  __*[20:08](https://git.door43.org/Door43/en_tn/src/master/obs/20/08.md)__  To punish the king of Judah for rebelling, __Nebuchadnezzar's__ soldiers killed the king's sons in front of him and then made him blind.
  __*[20:09](https://git.door43.org/Door43/en_tn/src/master/obs/20/09.md)__ __Nebuchadnezzar__ and his army took almost all of the people of the kingdom of Judah to Babylon, leaving only the poorest people behind to plant the fields.

### Word Data:

* Strong's: H5019, H5020


## <a id="tw-term-names-negev"/>Negev

### Facts:

The Negev is a desert region in the southern part of Israel, southwest of the Salt Sea.

* The original word means "the South," and some English versions translate it this way.
* It could be that the "South" is not located where the Negev Desert is today.
* When Abraham lived in the city of Kadesh, he was in the Negev or southern region.
* Isaac was living in the Negev when Rebekah traveled to meet him and become his wife.
* The Jewish tribes of Judah and Simeon lived in this southern region.
* The largest city in the Negev region was Beersheba.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Abraham](#abraham), [Beersheba](#beersheba), [Israel](kt.html#israel), [Judah](#judah), [Kadesh](#kadesh), [Salt Sea](#saltsea), [Simeon](#simeon))

### Bible References:

* [Genesis 12:8-9](https://git.door43.org/Door43/en_tn/src/master/gen/12/08.md)
* [Genesis 20:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/20/01.md)
* [Genesis 24:61-62](https://git.door43.org/Door43/en_tn/src/master/gen/24/61.md)
* [Joshua 03:14-16](https://git.door43.org/Door43/en_tn/src/master/jos/03/14.md)
* [Numbers 13:17-20](https://git.door43.org/Door43/en_tn/src/master/num/13/17.md)

### Word Data:

* Strong's: H5045, H6160


## <a id="tw-term-names-nehemiah"/>Nehemiah

### Facts:

Nehemiah was an Israelite forced to move to the Babylonian empire when the people of Israel and Judah were taken captive by the Babylonians.

* While he was the cupbearer to the Persian king, Artaxerxes, Nehemiah asked the king for permission to return to Jerusalem.
* Nehemiah led the Israelites in rebuilding the walls of Jerusalem which had been destroyed by the Babylonians.
* For twelve years Nehemiah was the governor of Jerusalem before returning to the king's palace.
* The Old Testament book of Nehemiah tells the story of Nehemiah's work in rebuilding the walls and his governing of the people in Jerusalem.
* There were also other men named Nehemiah in the Old Testament. Usually the name of the father was added, to distinguish which Nehemiah was being talked about.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Artaxerxes](#artaxerxes), [Babylon](#babylon), [Jerusalem](#jerusalem), [son](kt.html#son))

### Bible References:

* [Ezra 02:1-2](https://git.door43.org/Door43/en_tn/src/master/ezr/02/01.md)
* [Nehemiah 01:1-2](https://git.door43.org/Door43/en_tn/src/master/neh/01/01.md)
* [Nehemiah 10:1-3](https://git.door43.org/Door43/en_tn/src/master/neh/10/01.md)
* [Nehemiah 12:46-47](https://git.door43.org/Door43/en_tn/src/master/neh/12/46.md)

### Word Data:

* Strong's: H5166


## <a id="tw-term-names-nileriver"/>Nile River, River of Egypt, the Nile

### Facts:

The Nile is a very long and wide river in northeastern Africa. It is especially well known as the main river of Egypt.

* The Nile River flows north through Egypt and into the Mediterranean Sea.
* Crops grow well in the fertile land on either side of the Nile River.
* Most Egyptians live near the Nile River since it is an important source of water for food crops.
* The Israelites lived in the land of Goshen, which was very fertile because it was located along the Nile River.
* When Moses was a baby, his parents placed him in a basket among the reeds of the Nile to hide him from Pharaoh's men.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Egypt](#egypt), [Goshen](#goshen), [Moses](#moses))

### Bible References:

* [Amos 08:7-8](https://git.door43.org/Door43/en_tn/src/master/amo/08/07.md)
* [Genesis 41:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/41/01.md)
* [Jeremiah 46:7-9](https://git.door43.org/Door43/en_tn/src/master/jer/46/07.md)

### Examples from the Bible stories:

  __*[08:04](https://git.door43.org/Door43/en_tn/src/master/obs/08/04.md)__ Egypt was a large, powerful country located along the __Nile River__.
  __*[09:04](https://git.door43.org/Door43/en_tn/src/master/obs/09/04.md)__ Pharaoh saw that the Israelites were having many babies, so he ordered his people to kill all Israelite baby boys by throwing them into the __Nile River__.
  __*[09:06](https://git.door43.org/Door43/en_tn/src/master/obs/09/06.md)__ When the boy's parents could no longer hide him, they put him in a floating basket among the reeds along the edge of the __Nile River__ in order to save him from being killed. 
  __*[10:03](https://git.door43.org/Door43/en_tn/src/master/obs/10/03.md)__ God turned the __Nile River__ into blood, but Pharaoh still would not let the Israelites go.

### Word Data:

* Strong's: H2975, H4714, H5104


## <a id="tw-term-names-nineveh"/>Nineveh, Ninevite

### Facts:

Nineveh was the capital city of Assyria.  A "Ninevite" was a person who lived in Nineveh.

 * God sent the prophet Jonah to warn the Ninevites to turn from their wicked ways. The people repented and God did not destroy them.
 * The Assyrians later stopped serving God. They conquered the kingdom of Israel and carried the people away to Nineveh.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Assyria](#assyria), [Jonah](#jonah), [repent](kt.html#repent), [turn](other.html#turn))

### Bible References:

* [Genesis 10:11-14](https://git.door43.org/Door43/en_tn/src/master/gen/10/11.md)
* [Jonah 01:1-3](https://git.door43.org/Door43/en_tn/src/master/jon/01/01.md)
* [Jonah 03:1-3](https://git.door43.org/Door43/en_tn/src/master/jon/03/01.md)
* [Luke 11:32](https://git.door43.org/Door43/en_tn/src/master/luk/11/32.md)
* [Matthew 12:41](https://git.door43.org/Door43/en_tn/src/master/mat/12/41.md)


### Word Data:

* Strong's: H5210, G3535, G3536


## <a id="tw-term-names-noah"/>Noah

### Facts:

Noah was a man who lived over 4,000 years ago, at the time when God sent a worldwide flood to destroy all the evil people in the world. God told Noah to build a gigantic ark in which he and his family could live while the flood waters covered the earth.

* Noah was a righteous man who obeyed God in everything.
* When God told Noah how to build the gigantic ark, Noah built it exactly the way God told him to.
* Inside the ark, Noah and his family were kept safe, and later their children and grandchildren filled the earth with people again.
* Everyone born since the time of the flood is a descendant of Noah.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [descendant](other.html#descendant), [ark](kt.html#ark))

### Bible References:

* [Genesis 05:30-31](https://git.door43.org/Door43/en_tn/src/master/gen/05/30.md)
* [Genesis 05:32](https://git.door43.org/Door43/en_tn/src/master/gen/05/32.md)
* [Genesis 06:7-8](https://git.door43.org/Door43/en_tn/src/master/gen/06/07.md)
* [Genesis 08:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/08/01.md)
* [Hebrews 11:7](https://git.door43.org/Door43/en_tn/src/master/heb/11/07.md)
* [Matthew 24:37-39](https://git.door43.org/Door43/en_tn/src/master/mat/24/37.md)

### Examples from the Bible stories:

 * __[03:02](https://git.door43.org/Door43/en_tn/src/master/obs/03/02.md)__ But __Noah__  found favor with God.
 * __[03:04](https://git.door43.org/Door43/en_tn/src/master/obs/03/04.md)__ __Noah__  obeyed God. He and his three sons built the boat just the way God had told them.
 * __[03:13](https://git.door43.org/Door43/en_tn/src/master/obs/03/13.md)__ Two months later God said to __Noah__, "You and your family and all the animals may leave the boat now. Have many children and grandchildren and fill the earth." So __Noah__ and his family came out of the boat.

### Word Data:

* Strong's: H5146, G3575


## <a id="tw-term-names-obadiah"/>Obadiah

### Facts:

Obadiah was an Old Testament prophet who prophesied against the people of Edom, who were the descendants of Esau. There were also many other men named Obadiah in the Old Testament.

* The book of Obadiah is the shortest book in the Old Testament and tells a prophecy that Obadiah received through a vision from God.
* It is not clear when Obadiah lived and prophesied. It may have been during the paeriods that Jehoram, Ahaziah, Joash, and Athaliah, reigned in Judah. The prophets Daniel, Ezekiel, and Jeremiah would also have been prophesying during part of this time.
* Obadiah may also have lived at a later time period, during the reign of King Zedekiah and the Babylonian captivity. 
* Other men named Obadiah included a descendant of Sau,; a Gadite who became one of David's men, a palace administrator for King Ahab, an official of King Jehoshaphat, a man who helped with repairs to the temple during the time of King Josiah, and a Levite who was also a gatekeeper during the time of Nehemiah.
* It could be that the writer of the book of Obadiah was one of these men.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Ahab](#ahab), [Babylon](#babylon), [David](#david), [Edom](#edom), [Esau](#esau), [Ezekiel](#ezekiel), [Daniel](#daniel), [Gad](#gad), [Jehoshaphat](#jehoshaphat), [Josiah](#josiah), [Levite](#levite), [Saul (OT)](#saul), [Zedekiah](#zedekiah))

### Bible References:

* [1 Chronicles 03:19-21](https://git.door43.org/Door43/en_tn/src/master/1ch/03/19.md)
* [1 Chronicles 08:38-40](https://git.door43.org/Door43/en_tn/src/master/1ch/08/38.md)
* [Ezra 08:8-11](https://git.door43.org/Door43/en_tn/src/master/ezr/08/08.md)
* [Obadiah 01:1-2](https://git.door43.org/Door43/en_tn/src/master/oba/01/01.md)

### Word Data:

* Strong's: H5662


## <a id="tw-term-names-omri"/>Omri

### Facts:

Omri was an army commander who became the sixth king of Israel.

* King Omri reigned for 12 years in the city of Tirzah. 
* Like all the kings of Israel before him, Omri was a very evil king who led the people of Israel into more idol worship.
* Omri was also the father of King Ahab.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Ahab](#ahab), [Israel](kt.html#israel), [Jeroboam](#jeroboam), [Tirzah](#tirzah))

### Bible References:

* [2 Chronicles 22:1-3](https://git.door43.org/Door43/en_tn/src/master/2ch/22/01.md)

### Word Data:

* Strong's: H6018


## <a id="tw-term-names-paddanaram"/>Paddan Aram

### Facts:

Paddan Aram was the name of a region where Abraham's family lived before moving to the land of Canaan. It means "plain of Aram."

* When Abraham left Haran in Paddan Aram to travel to the land of Canaan, most of the rest of his family stayed behind in Haran.
* Many years later, Abraham's servant went to Paddan Aram to find a wife for Isaac among his relatives there and found Rebekah, grand-daughter of Bethuel.
* Isaac and Rebekah's son Jacob also traveled to Paddan Aram and married two daughters of Rebekah's brother Laban who was living in Haran.
* Aram, Paddan-Aram, and Aram-Nahariam were all part of the same region that is now where the modern-day country of Syria is located.
 

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Abraham](#abraham), [Aram](#aram), [Bethuel](#bethuel), [Canaan](#canaan), [Haran](#haran), [Jacob](#jacob), [Laban](#laban), [Rebekah](#rebekah), [Syria](#syria))

### Bible References:

* [Genesis 28:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/28/01.md)
* [Genesis 35:9-10](https://git.door43.org/Door43/en_tn/src/master/gen/35/09.md)
* [Genesis 46:12-15](https://git.door43.org/Door43/en_tn/src/master/gen/46/12.md)

### Word Data:

* Strong's: H6307


## <a id="tw-term-names-paran"/>Paran

### Facts:

Paran was a desert or wilderness area east of Egypt and south of the land of Canaan. There was also a Mount Paran, which may have been another name for Mount Sinai.

* The slave Hagar and her son Ishmael went to live in the wilderness of Paran after Sarah ordered Abraham to send them away.
* When Moses led the Israelites out of Egypt, they passed through the wilderness of Paran.
* It was from Kadesh-Barnea in the wilderness of Paran that Moses sent twelve men to spy out the land of Canaan and bring back a report.
* The wilderness of Zin was north of Paran and the wilderness of Sin was south of Paran.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Canaan](#canaan), [desert](other.html#desert), [Egypt](#egypt), [Kadesh](#kadesh), [Sinai](#sinai))

### Bible References:

* [1 Kings 11:18-19](https://git.door43.org/Door43/en_tn/src/master/1ki/11/18.md)
* [1 Samuel 25:1](https://git.door43.org/Door43/en_tn/src/master/1sa/25/01.md)
* [Genesis 21:19-21](https://git.door43.org/Door43/en_tn/src/master/gen/21/19.md)
* [Numbers 10:11-13](https://git.door43.org/Door43/en_tn/src/master/num/10/11.md)
* [Numbers 13:3-4](https://git.door43.org/Door43/en_tn/src/master/num/13/03.md)

### Word Data:

* Strong's: H364, H6290


## <a id="tw-term-names-paul"/>Paul, Saul

### Facts:

Paul was a leader of the early church who was sent by Jesus to take the good news to many other people groups.

 * Paul was a Jew who was born in the Roman city of Tarsus, and was therefore also a Roman citizen.
 * Paul was originally called by his Jewish name, Saul.
 * Saul became a Jewish religious leader and arrested Jews who became Christians because he thought they were dishonoring God by believing in Jesus.
 * Jesus revealed himself to Saul in a blinding light and told him to stop hurting Christians.
 * Saul believed in Jesus and began teaching his fellow Jews about him.
 * Later, God sent Saul to teach non-Jewish people about Jesus and started churches in different cities and provinces of the Roman empire. At this time he started being called by the Roman name "Paul."
 * Paul also wrote letters to encourage and teach Christians in the churches in these cities. Several of these letters are in the New Testament.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [christian](kt.html#christian), [jewish leaders](other.html#jewishleaders), [rome](#rome))

### Bible References:

* [1 Corinthians 01:1-3](https://git.door43.org/Door43/en_tn/src/master/1co/01/01.md)
* [Acts 08:1-3](https://git.door43.org/Door43/en_tn/src/master/act/08/01.md)
* [Acts 09:26-27](https://git.door43.org/Door43/en_tn/src/master/act/09/26.md)
* [Acts 13:9-10](https://git.door43.org/Door43/en_tn/src/master/act/13/09.md)
* [Galatians 01:1-2](https://git.door43.org/Door43/en_tn/src/master/gal/01/01.md)
* [Philemon 01:8-9](https://git.door43.org/Door43/en_tn/src/master/phm/01/08.md)

### Examples from the Bible stories:

 * __[45:06](https://git.door43.org/Door43/en_tn/src/master/obs/45/06.md)__ A young man named __Saul__ agreed with the people who killed Stephen and guarded their robes while they threw stones at him. 
 * __[46:01](https://git.door43.org/Door43/en_tn/src/master/obs/46/01.md)__ __Saul__ was the young man who guarded the robes of the men who killed Stephen. He did not believe in Jesus, so he persecuted the believers. 
 * __[46:02](https://git.door43.org/Door43/en_tn/src/master/obs/46/02.md)__ While __Saul__ was on his way to Damascus, a bright light from heaven shone all around him, and he fell to the ground. __Saul__ heard someone say, "__Saul__! __Saul__! Why do you persecute me?" 
 * __[46:05](https://git.door43.org/Door43/en_tn/src/master/obs/46/05.md)__ So Ananias went to __Saul__, placed his hands on him, and said, "Jesus who appeared to you on your way here, sent me to you so that you can regain your sight and be filled with the Holy Spirit." __Saul__ immediately was able to see again, and Ananias baptized him. 
 * __[46:06](https://git.door43.org/Door43/en_tn/src/master/obs/46/06.md)__ Right away, __Saul__ began preaching to the Jews in Damascus, saying, "Jesus is the Son of God!" 
 * __[46:09](https://git.door43.org/Door43/en_tn/src/master/obs/46/09.md)__ Barnabas and __Saul__ went there (Antioch) to teach these new believers more about Jesus and to strengthen the church. 
 * __[47:01](https://git.door43.org/Door43/en_tn/src/master/obs/47/01.md)__ As __Saul__ traveled throughout the Roman Empire, he began to use his Roman name, "__Paul__." 
 * __[47:14](https://git.door43.org/Door43/en_tn/src/master/obs/47/14.md)__ __Paul__ and other Christian leaders traveled to many cities, preaching and teaching people the good news about Jesus.

### Word Data:

* Strong's: G3972, G4569


## <a id="tw-term-names-peor"/>Peor, Mount Peor, Baal Peor

### Definition:

The terms "Peor" and "Mount Peor" refer to a mountain located northeast of the Salt Sea, in the region of Moab.

* The name "Beth Peor" was the name of a city, probably located on that mountain or near it. This was where Moses died after God showed him the Promised Land.
* "Baal Peor" was a false god of the Moabites that they worshiped at Mount Peor. The Israelites also started worshiping this idol and God punished them for it.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Baal](#baal), [false god](kt.html#falsegod), [Moab](#moab), [Salt Sea](#saltsea), [worship](kt.html#worship))

### Bible References:

* [Numbers 23:28-30](https://git.door43.org/Door43/en_tn/src/master/num/23/28.md)
* [Numbers 31:16-17](https://git.door43.org/Door43/en_tn/src/master/num/31/16.md)
* [Psalms 106:28-29](https://git.door43.org/Door43/en_tn/src/master/psa/106/028.md)

### Word Data:

* Strong's: H1047, H1187, H6465


## <a id="tw-term-names-perizzite"/>Perizzite

### Facts:

​The Perizzites were one of several people groups in the land of Canaan. Little is known about this group as to who their ancestors were or what part of Canaan they lived in.

* The Perizzites are mentioned most frequently in the Old Testament Book of Judges, where it is recorded that the Perizzites intermarried with the Israelites and influenced them to worship false gods.
* Note that the clan of Perez, called the "Perezites," was a different people group from the Perizzites. It may be necessary to spell the names very differently to make this clear.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Canaan](#canaan), [false god](kt.html#falsegod))

### Bible References:

* [1 Kings 09:20-21](https://git.door43.org/Door43/en_tn/src/master/1ki/09/20.md)
* [2 Chronicles 08:7-8](https://git.door43.org/Door43/en_tn/src/master/2ch/08/07.md)
* [Exodus 03:16-18](https://git.door43.org/Door43/en_tn/src/master/exo/03/16.md)
* [Genesis 13:5-7](https://git.door43.org/Door43/en_tn/src/master/gen/13/05.md)
* [Joshua 03:9-11](https://git.door43.org/Door43/en_tn/src/master/jos/03/09.md)

### Word Data:

* Strong's: H6522


## <a id="tw-term-names-persia"/>Persia, Persians

### Definition:

Persia was a country that also became a powerful empire founded by Cyrus the Great in 550 BC. The country of Persia was located southeast of Babylonia and Assyria in a region that is now the modern-day country of Iran. 

* The people of Persia were called "Persians."
* Under King Cyrus' decree, the Jews were freed from their captivity in Babylon and allowed to go home, and the temple in Jerusalem was rebuilt, with funds provided by the Persian Empire.
* King Artaxerxes was the ruler of the Persian Empire when Ezra and Nehemiah went back to Jerusalem to rebuild the walls of Jerusalem.
* Esther became a queen of the Persian empire when she married King Ahasuerus.

(See also: [Ahasuerus](#ahasuerus), [Artaxerxes](#artaxerxes), [Assyria](#assyria), [Babylon](#babylon), [Cyrus](#cyrus), [Esther](#esther), [Ezra](#ezra), [Nehemiah](#nehemiah))

### Bible References:

* [2 Chronicles 36:20-21](https://git.door43.org/Door43/en_tn/src/master/2ch/36/20.md)
* [Daniel 10:12-13](https://git.door43.org/Door43/en_tn/src/master/dan/10/12.md)
* [Esther 01:3-4](https://git.door43.org/Door43/en_tn/src/master/est/01/03.md)
* [Ezekiel 27:10-11](https://git.door43.org/Door43/en_tn/src/master/ezk/27/10.md)

### Word Data:

* Strong's: H6539, H6540, H6542, H6543


## <a id="tw-term-names-peter"/>Peter, Simon Peter, Cephas

### Facts:

Peter was one of Jesus' twelve apostles. He was an important leader of the early Church.

* Before Jesus called him to be his disciple, Peter's name was Simon.
* Later, Jesus also named him "Cephas," which means "stone" or "rock" in the Aramaic language. The name Peter also means "stone" or "rock" in the Greek language.
* God worked through Peter to heal people and to preach the good news about Jesus.
* Two books in the New Testament are letters that Peter wrote to encourage and teach fellow believers.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [disciple](kt.html#disciple), [apostle](kt.html#apostle))

### Bible References:

* [Acts 08:25](https://git.door43.org/Door43/en_tn/src/master/act/08/25.md)
* [Galatians 02:6-8](https://git.door43.org/Door43/en_tn/src/master/gal/02/06.md)
* [Galatians 02:11-12](https://git.door43.org/Door43/en_tn/src/master/gal/02/11.md)
* [Luke 22:56-58](https://git.door43.org/Door43/en_tn/src/master/luk/22/56.md)
* [Mark 03:13-16](https://git.door43.org/Door43/en_tn/src/master/mrk/03/13.md)
* [Matthew 04:18-20](https://git.door43.org/Door43/en_tn/src/master/mat/04/18.md)
* [Matthew 08:14-15](https://git.door43.org/Door43/en_tn/src/master/mat/08/14.md)
* [Matthew 14:28-30](https://git.door43.org/Door43/en_tn/src/master/mat/14/28.md)
* [Matthew 26:33-35](https://git.door43.org/Door43/en_tn/src/master/mat/26/33.md)

### Examples from the Bible stories:

  __*[28:09](https://git.door43.org/Door43/en_tn/src/master/obs/28/09.md)__ __Peter__ said to Jesus, "We have left everything and followed you. What will be our reward?"
  __*[29:01](https://git.door43.org/Door43/en_tn/src/master/obs/29/01.md)__ One day __Peter__ asked Jesus, "Master, how many times should I forgive my brother when he sins against me? As many as seven times?"
  __*[31:05](https://git.door43.org/Door43/en_tn/src/master/obs/31/05.md)__ Then __Peter__ said to Jesus, "Master, if it is you, command me to come to you on the water." Jesus told __Peter__, "Come!"
  __*[36:01](https://git.door43.org/Door43/en_tn/src/master/obs/36/01.md)__ One day, Jesus took three of his disciples, __Peter__, James, and John with him.
  __*[38:09](https://git.door43.org/Door43/en_tn/src/master/obs/38/09.md)__ __Peter__ replied, "Even if all the others abandon you, I will not!" Then Jesus said to __Peter__, "Satan wants to have all of you, but I have prayed for you, __Peter__, that your faith will not fail. Even so, tonight, before the rooster crows, you will deny that you even know me three times."
  __*[38:15](https://git.door43.org/Door43/en_tn/src/master/obs/38/15.md)__ As the soldiers arrested Jesus, __Peter__ pulled out his sword and cut off the ear of the servant of the high priest.
  __*[43:11](https://git.door43.org/Door43/en_tn/src/master/obs/43/11.md)__ __Peter__ answered them, "Every one of you should repent and be baptized in the name of Jesus Christ so that God will forgive your sins."
  __*[44:08](https://git.door43.org/Door43/en_tn/src/master/obs/44/08.md)__ __Peter__ answered them, "This man stands before you healed by the power of Jesus the Messiah."

### Word Data:

* Strong's: G2786, G4074, G4613


## <a id="tw-term-names-pharaoh"/>Pharaoh, king of Egypt

### Facts:

In ancient times, the kings who ruled over the country of Egypt were called pharaohs.

* Altogether, over 300 pharaohs ruled Egypt for more than 2,000 years.
* These Egyptians kings were very powerful and wealthy.
* Several of these pharaohs are mentioned in the Bible.
* Often this title is used as a name rather than as a title. In these cases, it is capitalized and written as "Pharaoh."

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [egypt](#egypt), [king](other.html#king))

### Bible References:

* [Acts 07:9-10](https://git.door43.org/Door43/en_tn/src/master/act/07/09.md)
* [Acts 07:11-13](https://git.door43.org/Door43/en_tn/src/master/act/07/11.md)
* [Acts 07:20-21](https://git.door43.org/Door43/en_tn/src/master/act/07/20.md)
* [Genesis 12:14-16](https://git.door43.org/Door43/en_tn/src/master/gen/12/14.md)
* [Genesis 40:6-8](https://git.door43.org/Door43/en_tn/src/master/gen/40/06.md)
* [Genesis 41:25-26](https://git.door43.org/Door43/en_tn/src/master/gen/41/25.md)

### Examples from the Bible stories:

* __[08:06](https://git.door43.org/Door43/en_tn/src/master/obs/08/06.md)__ One night, the __Pharaoh__, which is what the Egyptians called their kings, had two dreams that disturbed him greatly.
* __[08:08](https://git.door43.org/Door43/en_tn/src/master/obs/08/08.md)__ __Pharaoh__  was so impressed with Joseph that he appointed him to be the second most powerful man in all of Egypt!
* __[09:02](https://git.door43.org/Door43/en_tn/src/master/obs/09/02.md)__ So the __Pharaoh__  who was ruling over Egypt at that time made the Israelites slaves to the Egyptians.
* __[09:13](https://git.door43.org/Door43/en_tn/src/master/obs/09/13.md)__ "I will send you to __Pharaoh__  so that you can bring the Israelites out of their slavery in Egypt."
* __[10:02](https://git.door43.org/Door43/en_tn/src/master/obs/10/02.md)__ Through these plagues, God showed __Pharaoh __  that he is more powerful than __Pharaoh__  and all of Egypt's gods.

### Word Data:

* Strong's: H4428, H4714, H6547, G5328


## <a id="tw-term-names-philip"/>Philip, the evangelist

### Facts:

In the early Christian church in Jerusalem, Philip was one of seven leaders chosen to care for the poor and needy Christians, especially the widows.

* God used Philip to share the gospel with people in many different towns in the provinces of Judea and Galilee, including an Ethiopian man he met on the desert road to Gaza from Jerusalem.
* Years later Philip was living in Caesarea when Paul and his companions stayed at his house on their way back to Jerusalem.
* Most Bible scholars think that Philip the evangelist was not the same man as Jesus' apostle by that name. Some languages may prefer to use slightly different spellings for the names of these two men to make it clear they are different men.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Philip](#philiptheapostle))

### Bible References:

* [Acts 06:5-6](https://git.door43.org/Door43/en_tn/src/master/act/06/05.md)
* [Acts 08:6-8](https://git.door43.org/Door43/en_tn/src/master/act/08/06.md)
* [Acts 08:12-13](https://git.door43.org/Door43/en_tn/src/master/act/08/12.md)
* [Acts 08:29-31](https://git.door43.org/Door43/en_tn/src/master/act/08/29.md)
* [Acts 08:36-38](https://git.door43.org/Door43/en_tn/src/master/act/08/36.md)
* [Acts 08:39-40](https://git.door43.org/Door43/en_tn/src/master/act/08/39.md)

### Word Data:

* Strong's: G5376


## <a id="tw-term-names-philippi"/>Philippi, Philippians

### Facts:

Philippi was a major city and Roman colony located in Macedonia in the northern part of ancient Greece.

 * Paul and Silas traveled to Philippi to preach about Jesus to the people there.
 * While in Philippi, Paul and Silas were arrested, but God miraculously freed them.
 * The New Testament book of Philippians is a letter that the apostle Paul wrote to the Christians in the church at Philippi.
 * Note that this is a different city from Caesarea Philippi which was located in northeastern Israel near Mount Hermon.
 
(See also: [Caesarea](#caesarea), [Christian](kt.html#christian), [church](kt.html#church), [Macedonia](#macedonia), [Paul](#paul), [Silas](#silas))

### Bible References:

* [1 Thessalonians 02:1-2](https://git.door43.org/Door43/en_tn/src/master/1th/02/01.md)
* [Acts 16:11-13](https://git.door43.org/Door43/en_tn/src/master/act/16/11.md)
* [Matthew 16:13-16](https://git.door43.org/Door43/en_tn/src/master/mat/16/13.md)
* [Philippians 01:1-2](https://git.door43.org/Door43/en_tn/src/master/php/01/01.md)

### Examples from the Bible stories:

 * __[47:01](https://git.door43.org/Door43/en_tn/src/master/obs/47/01.md)__ One day, Paul and his friend Silas went to the town of __Philippi__ to proclaim the good news about Jesus. 
 * __[47:13](https://git.door43.org/Door43/en_tn/src/master/obs/47/13.md)__ The next day the leaders of the city released Paul and Silas from prison and asked them to leave __Philippi__.

### Word Data:

* Strong's: G5374, G5375


## <a id="tw-term-names-philiptheapostle"/>Philip, the apostle

### Facts:

Philip the apostle was one of the original twelve disciples of Jesus. He was from the town of Bethsaida.

* Philip brought Nathanael to meet Jesus.
* Jesus questioned Philip about how to provide food for a crowd of over 5,000 people.
* At the last Passover supper that Jesus ate with his disciples, he talked to them about God, his Father. Philip asked Jesus to show them the Father.
* Some languages may prefer to spell this Philip's name in a different way from the other Philip (the evangelist) to avoid confusion.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Philip](#philip))

### Bible References:

* [Acts 01:12-14](https://git.door43.org/Door43/en_tn/src/master/act/01/12.md)
* [John 01:43-45](https://git.door43.org/Door43/en_tn/src/master/jhn/01/43.md)
* [John 06:4-6](https://git.door43.org/Door43/en_tn/src/master/jhn/06/04.md)
* [Luke 06:14-16](https://git.door43.org/Door43/en_tn/src/master/luk/06/14.md)
* [Mark 03:17-19](https://git.door43.org/Door43/en_tn/src/master/mrk/03/17.md)

### Word Data:

* Strong's: Philip


## <a id="tw-term-names-philistia"/>Philistia

### Definition:

Philistia is the name of a large region in the land of Canaan, located along the coast of the Mediterranean Sea.

* The region was located along the very fertile coastal plain reaching from Joppa in the north to Gaza in the south. It was about 64 km long and 16 km wide.
* Philistia was occupied by the "Philistines," a powerful people group who were frequent enemies of the Israelites.

(See also: [Philistines](#philistines), [Gaza](#gaza), [Joppa](#joppa))

### Bible References:

* [1 Chronicles 10:9-10](https://git.door43.org/Door43/en_tn/src/master/1ch/10/09.md)
* [Joel 03:4-6](https://git.door43.org/Door43/en_tn/src/master/jol/03/04.md)
* [Psalms 060:8-9](https://git.door43.org/Door43/en_tn/src/master/psa/060/008.md)

### Word Data:

* Strong's: H776 H6429 H06430


## <a id="tw-term-names-philistines"/>Philistines

### Facts:

The Philistines were a people group who occupied a region known as Philistia​ along the coast of the Mediterranean Sea. Their name means "people of the sea."

* There were five main Philistine cities: Ashdod, Ashkelon, Ekron, Gath, and Gaza.
* The city of Ashdod was in the northern part of Philistia, and the city of Gaza was in the southern part.
* The Philistines are probably best known for the many years they were at war against the Israelites.
* The judge Samson was a famous warrior against the Philistines, using supernatural strength from God.
* King David often led battles against the Philistines, including the time as a youth when he defeated the Philistine warrior, Goliath.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Ashdod](#ashdod), [Ashkelon](#ashkelon), [David](#david), [Ekron](#ekron), [Gath](#gath), [Gaza](#gaza), [Goliath](#goliath), [Salt Sea](#saltsea))

### Bible References:

* [1 Chronicles 18:9-11](https://git.door43.org/Door43/en_tn/src/master/1ch/18/09.md)
* [1 Samuel 13:3-4](https://git.door43.org/Door43/en_tn/src/master/1sa/13/03.md)
* [2 Chronicles 09:25-26](https://git.door43.org/Door43/en_tn/src/master/2ch/09/25.md)
* [Genesis 10:11-14](https://git.door43.org/Door43/en_tn/src/master/gen/10/11.md)
* [Psalm 056:1-2](https://git.door43.org/Door43/en_tn/src/master/psa/056/001.md)

### Word Data:

* Strong's: H6429, H6430


## <a id="tw-term-names-phinehas"/>Phinehas

### Facts:

Phineas was the name of two men in the Old Testament.

* One of Aaron's grandsons was a priest named Phinehas, who strongly opposed the worship of false gods in Israel.
* Phineas saved the Israelites from a plague that Yahweh had sent to punish them for marrying Midianite women and worshiping their false gods.
* On several occasions Phinehas went with the Israelite army to destroy the Midianites.
* The other Phinehas mentioned in the Old Testament was one of the evil sons of Eli the priest during the time of the prophet Samuel.
* Phinehas and his brother Hophni were both killed when the Philistines attacked Israel and stole the Ark of the Covenant.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [ark of the covenant](kt.html#arkofthecovenant), [Jordan River](#jordanriver), [Midian](#midian), [Philistines](#philistines), [Samuel](#samuel))

### Bible References:

* [1 Samuel 04:3-4](https://git.door43.org/Door43/en_tn/src/master/1sa/04/03.md)
* [Ezra 08:1-3](https://git.door43.org/Door43/en_tn/src/master/ezr/08/01.md)
* [Joshua 22:13-14](https://git.door43.org/Door43/en_tn/src/master/jos/22/13.md)
* [Numbers 25:6-7](https://git.door43.org/Door43/en_tn/src/master/num/25/06.md)

### Word Data:

* Strong's: H6372


## <a id="tw-term-names-phonecia"/>Phoenicia

### Facts:

In ancient times, Phoenicia was a wealthy nation located in Canaan along the coast of the Mediterranean Sea, north of Israel.

* Phoenicia occupied an area of land that was in the western region of what is the present-day country of Lebanon.
* In New Testament times, the capital of Phoenicia was Tyre. Another important Phoenician city was Sidon.
* Phoenicians were well-known for their woodworking skills using their country's plentiful cedar trees, for their production of a costly purple dye, and for their ability to travel and trade by sea. They were also highly skilled boat builders.
* One of the earliest alphabets was created by the Phoenician people. Their alphabet was widely used because of their contact with many people groups through trading.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [cedar](other.html#cedar), [purple](other.html#purple), [Sidon](#sidon), [Tyre](#tyre))

### Bible References:

* [Acts 11:19-21](https://git.door43.org/Door43/en_tn/src/master/act/11/19.md)
* [Acts 15:3-4](https://git.door43.org/Door43/en_tn/src/master/act/15/03.md)
* [Acts 21:1-2](https://git.door43.org/Door43/en_tn/src/master/act/21/01.md)
* [Isaiah 23:10-12](https://git.door43.org/Door43/en_tn/src/master/isa/23/10.md)

### Word Data:

* Strong's: H3667, G4949, G5403


## <a id="tw-term-names-pilate"/>Pilate

### Facts:

Pilate was the governor of the Roman province of Judea who sentenced Jesus to death.

* Because Pilate was the governor, he had the authority to put criminals to death.
* The Jewish religious leaders wanted Pilate to crucify Jesus, so they lied and said that Jesus was a criminal.
* Pilate realized that Jesus was not guilty, but he was afraid of the crowd and wanted to please them, so he ordered his soldiers to crucify Jesus.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [crucify](kt.html#crucify), [governor](other.html#governor), [guilt](kt.html#guilt), [Judea](#judea), [Rome](#rome))

### Bible References:

* [Acts 04:27-28](https://git.door43.org/Door43/en_tn/src/master/act/04/27.md)
* [Acts 13:28-29](https://git.door43.org/Door43/en_tn/src/master/act/13/28.md)
* [Luke 23:1-2](https://git.door43.org/Door43/en_tn/src/master/luk/23/01.md)
* [Mark 15:1-3](https://git.door43.org/Door43/en_tn/src/master/mrk/15/01.md)
* [Matthew 27:11-14](https://git.door43.org/Door43/en_tn/src/master/mat/27/11.md)
* [Matthew 27:57-58](https://git.door43.org/Door43/en_tn/src/master/mat/27/57.md)

### Examples from the Bible stories:

  __*[39:09](https://git.door43.org/Door43/en_tn/src/master/obs/39/09.md)__ Early the next morning, the Jewish leaders brought Jesus to __Pilate__, the Roman governor. They hoped that __Pilate__ would condemn Jesus as guilty and sentenced him to be killed. __Pilate__ asked Jesus, "Are you the King of the Jews?"
  __*[39:10](https://git.door43.org/Door43/en_tn/src/master/obs/39/10.md)__ __Pilate__ said, "What is truth?"
  __*[39:11](https://git.door43.org/Door43/en_tn/src/master/obs/39/11.md)__ After speaking with Jesus, __Pilate__ went out to the crowd and said, "I find no guilt in this man." But the Jewish leaders and the crowd shouted, "Crucify him!" __Pilate__ replied, "He is not guilty." But they shouted even louder. Then __Pilate__ said a third time, "He is not guilty!"
  __*[39:12](https://git.door43.org/Door43/en_tn/src/master/obs/39/12.md)__ __Pilate__ became afraid that the crowd would begin to riot, so he ordered his soldiers to crucify Jesus.
  __*[40:02](https://git.door43.org/Door43/en_tn/src/master/obs/40/02.md)__ __Pilate__ commanded that a sign be put above Jesus' head that read, "King of the Jews."
  __*[41:02](https://git.door43.org/Door43/en_tn/src/master/obs/41/02.md)__ __Pilate__ said, "Take some soldiers and make the tomb as secure as you can."

### Word Data:

* Strong's: G4091, G4194


## <a id="tw-term-names-pontus"/>Pontus

### Facts:

Pontus was a Roman province during the time of the Roman Empire and the early Church. It was located along the southern coast of the Black Sea, in the northern part of what is now the country of Turkey.

* As recorded in the book of Acts, people from the province of Pontus were in Jerusalem when the Holy Spirit first came to the apostles on the Day of Pentecost.
* A believer named Aquila was from Pontus.
* When Peter was writing to Christians who were scattered into different regions, Pontus was one of the regions he mentioned.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Aquila](#aquila), [Pentecost](kt.html#pentecost)) 

### Bible References:

* [1 Peter 01:1-2](https://git.door43.org/Door43/en_tn/src/master/1pe/01/01.md)
* [Acts 02:8-11](https://git.door43.org/Door43/en_tn/src/master/act/02/08.md)

### Word Data:

* Strong's: G4193, G4195


## <a id="tw-term-names-potiphar"/>Potiphar

### Facts:

Potiphar was an important official for the pharaoh of Egypt during the time that Joseph was sold as a slave to some Ishmaelites.

* Potiphar bought Joseph from the Ishmaelites and appointed him to be in charge of his household.
* When Joseph was falsely accused of doing wrong, Potiphar had Joseph put in prison.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Egypt](#egypt), [Joseph (OT)](#josephot), [Pharaoh](#pharaoh))

### Bible References:

* [Genesis 37:34-36](https://git.door43.org/Door43/en_tn/src/master/gen/37/34.md)
* [Genesis 39:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/39/01.md)
* [Genesis 39:13-15](https://git.door43.org/Door43/en_tn/src/master/gen/39/13.md)

### Word Data:

* Strong's: H6318


## <a id="tw-term-names-priscilla"/>Priscilla

### Facts:

Priscilla and her husband Aquila were Jewish Christians who worked with the apostle Paul in his missionary work.

* Priscilla and Aquila had left Rome because the emperor had forced the Christians to leave there.
* Paul met Aquila and Priscilla in Corinth. They were tentmakers and Paul joined them in this work.
* When Paul left Corinth to go to Syria, Priscilla and Aquila went with him.
* From Syria, the three of them went to Ephesus. When Paul left Ephesus, Priscilla and Aquila stayed behind and continued the work of preaching the gospel there.
* They especially taught a man named Apollos in Ephesus who believed in Jesus and was a gifted speaker and teacher.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [believe](kt.html#believe), [Christian](kt.html#christian), [Corinth](#corinth), [Ephesus](#ephesus), [Paul](#paul), [Rome](#rome), [Syria](#syria))

### Bible References:

* [1 Corinthians 16:19-20](https://git.door43.org/Door43/en_tn/src/master/1co/16/19.md)
* [2 Timothy 04:19-22](https://git.door43.org/Door43/en_tn/src/master/2ti/04/19.md)
* [Acts 18:1-3](https://git.door43.org/Door43/en_tn/src/master/act/18/01.md)
* [Acts 18:24-26](https://git.door43.org/Door43/en_tn/src/master/act/18/24.md)

### Word Data:

* Strong's: Priscilla


## <a id="tw-term-names-rabbah"/>Rabbah

### Definition:

Rabbah was the most important city of the Ammonite people.

* In battles against the Ammonites, the Israelites often attacked Rabbah.
* Israel's King David captured Rabbah as one of his last conquests.
* The modern-day city Amman Jordan is now where Rabbah used to be located.

(See also: [Ammon](#ammon), [David](#david))

### Bible References:

* [1 Chronicles 20:1](https://git.door43.org/Door43/en_tn/src/master/1ch/20/01.md)
* [2 Samuel 12:26-28](https://git.door43.org/Door43/en_tn/src/master/2sa/12/26.md)
* [Deuteronomy 03:11](https://git.door43.org/Door43/en_tn/src/master/deu/03/11.md)
* [Ezekiel 25:3-5](https://git.door43.org/Door43/en_tn/src/master/ezk/25/03.md)
* [Jeremiah 49:1-2](https://git.door43.org/Door43/en_tn/src/master/jer/49/01.md)

### Word Data:

* Strong's: H7237


## <a id="tw-term-names-rachel"/>Rachel

### Facts:

Rachel was one of Jacob's wives. She and her sister Leah were the daughters of Laban, Jacob's uncle.

* Rachel was the mother of Joseph and Benjamin, whose descendants became two of the tribes of Israel.
* For many years, Rachel was not able to have any children. Then God enabled her to give birth to Joseph.
* Years later, as she gave birth to Benjamin, Rachel died, and Jacob buried her near Bethlehem.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Bethlehem](#bethlehem), [Jacob](#jacob), [Laban](#laban), [Leah](#leah), [Joseph (OT)](#josephot), [twelve tribes of Israel](other.html#12tribesofisrael))

### Bible References:

* [Genesis 29:4-6](https://git.door43.org/Door43/en_tn/src/master/gen/29/04.md)
* [Genesis 29:19-20](https://git.door43.org/Door43/en_tn/src/master/gen/29/19.md)
* [Genesis 29:28-30](https://git.door43.org/Door43/en_tn/src/master/gen/29/28.md)
* [Genesis 31:4-6](https://git.door43.org/Door43/en_tn/src/master/gen/31/04.md)
* [Genesis 33:1-3](https://git.door43.org/Door43/en_tn/src/master/gen/33/01.md)
* [Matthew 02:17-18](https://git.door43.org/Door43/en_tn/src/master/mat/02/17.md)

### Word Data:

* Strong's: H7354, G4478


## <a id="tw-term-names-rahab"/>Rahab

### Facts:

Rahab was a woman who lived in Jericho when Israel attacked the city. She was a prostitute.

* Rahab hid the two Israelites who came to spy on Jericho before the Israelites attacked it. She helped the spies escape back to the Israelite camp.
* Rahab became a believer in Yahweh.
* She and her family were spared when, Jericho was destroyed and they all came to live with the Israelites.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Israel](kt.html#israel), [Jericho](#jericho), [prostitute](other.html#prostitute))

### Bible References:

* [Hebrews 11:29-31](https://git.door43.org/Door43/en_tn/src/master/heb/11/29.md)
* [James 02:25-26](https://git.door43.org/Door43/en_tn/src/master/jas/02/25.md)
* [Joshua 02:20-21](https://git.door43.org/Door43/en_tn/src/master/jos/02/20.md)
* [Joshua 06:17-19](https://git.door43.org/Door43/en_tn/src/master/jos/06/17.md)
* [Matthew 01:4-6](https://git.door43.org/Door43/en_tn/src/master/mat/01/04.md)

### Examples from the Bible stories:

  __*[15:01](https://git.door43.org/Door43/en_tn/src/master/obs/15/01.md)__ In that city there lived a prostitute named __Rahab__ who hid the spies and later helped them to escape. She did this because she believed God. They promised to protect __Rahab__ and her family when the Israelites would destroy Jericho. 
  __*[15:05](https://git.door43.org/Door43/en_tn/src/master/obs/15/05.md)__ The Israelites destroyed everything in the city as God had commanded. __Rahab__ and her family were the only people in the city that they did not kill. They became part of the Israelites.

### Word Data:

* Strong's: H7343, G4460


## <a id="tw-term-names-ramah"/>Ramah

### Facts:

Ramah was an ancient Israelite city located about 8 km from Jerusalem. It was in the region where the tribe of Benjamin lived.

* Ramah was where Rachel died after giving birth to Benjamin.
* When the Israelites were taken captive to Babylon, they were first brought to Ramah before being moved to Babylon.
* Ramah was the home of Samuel's mother and father.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Benjamin](#benjamin), [twelve tribes of Israel](other.html#12tribesofisrael))

### Bible References:

* [1 Chronicles 27:25-27](https://git.door43.org/Door43/en_tn/src/master/1ch/27/25.md)
* [1 Samuel 02:11](https://git.door43.org/Door43/en_tn/src/master/1sa/02/11.md)
* [2 Chronicles 16:1](https://git.door43.org/Door43/en_tn/src/master/2ch/16/01.md)
* [Jeremiah 31:15](https://git.door43.org/Door43/en_tn/src/master/jer/31/15.md)
* [Joshua 18:25-28](https://git.door43.org/Door43/en_tn/src/master/jos/18/25.md)
* [Matthew 02:17-18](https://git.door43.org/Door43/en_tn/src/master/mat/02/17.md)

### Word Data:

* Strong's: H7414, G4471


## <a id="tw-term-names-ramoth"/>Ramoth

### Facts:

Ramoth was an important city in the mountains of Gilead near the Jordan River. It was also called Ramoth Gilead.

* Ramoth belonged to the Israelite tribe of Gad and was designated as a city of refuge.
* King Ahab of Israel and King Jehoshaphat of Judah waged war against the king of Aram at Ramoth. Ahab was killed in that battle.
* Sometime later, King Ahaziah and King Joram tried to take the city of Ramoth from the king of Aram.
* Ramoth Gilead was where Jehu was anointed king over Israel.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Ahab](#ahab), [Ahaziah](#ahaziah), [Aram](#aram), [Gad](#gad), [Jehoshaphat](#jehoshaphat), [Jehu](#jehu), [Joram](#joram), [Jordan River](#jordanriver), [Judah](#kingdomofjudah), [refuge](other.html#refuge))

### Bible References:

* [1 Chronicles 06:71-73](https://git.door43.org/Door43/en_tn/src/master/1ch/06/71.md)
* [1 Kings 22:3-4](https://git.door43.org/Door43/en_tn/src/master/1ki/22/03.md)
* [2 Chronicles 18:1-3](https://git.door43.org/Door43/en_tn/src/master/2ch/18/01.md)
* [2 Kings 08:28-29](https://git.door43.org/Door43/en_tn/src/master/2ki/08/28.md)

### Word Data:

* Strong's: H7216, H7418, H7433


## <a id="tw-term-names-rebekah"/>Rebekah

### Facts:

Rebekah was a grand-daughter of Abraham's brother Nahor.

 * God chose Rebekah to be the wife of Abraham's son Isaac. 
 * Rebekah left the region of Aram Naharaim where she lived and went with Abraham's servant to the region of the Negev where Isaac was living.
 * For a long time Rebekah did not have any children, but finally God blessed her with twin boys, Esau and Jacob.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Abraham](#abraham), [Aram](#aram), [Esau](#esau), [Isaac](#isaac), [Jacob](#jacob), [Nahor](#nahor), [Negev](#negev))

### Bible References:

* [Genesis 24:15-16](https://git.door43.org/Door43/en_tn/src/master/gen/24/15.md)
* [Genesis 24:45-46](https://git.door43.org/Door43/en_tn/src/master/gen/24/45.md)
* [Genesis 24:56-58](https://git.door43.org/Door43/en_tn/src/master/gen/24/56.md)
* [Genesis 24:63-65](https://git.door43.org/Door43/en_tn/src/master/gen/24/63.md)
* [Genesis 25:27-28](https://git.door43.org/Door43/en_tn/src/master/gen/25/27.md)
* [Genesis 26:6-8](https://git.door43.org/Door43/en_tn/src/master/gen/26/06.md)

### Examples from the Bible stories:

  __*[06:02](https://git.door43.org/Door43/en_tn/src/master/obs/06/02.md)__ After a very long journey to the land where Abraham's relatives lived, God led the servant to __Rebekah__. She was the granddaughter of Abraham's brother.
  __*[06:06](https://git.door43.org/Door43/en_tn/src/master/obs/06/06.md)__ God told __Rebekah__, "There are two nations inside of you."
  __*[07:01](https://git.door43.org/Door43/en_tn/src/master/obs/07/01.md)__ As the boys grew up, __Rebekah__ loved Jacob, but Isaac loved Esau.
  __*[07:03](https://git.door43.org/Door43/en_tn/src/master/obs/07/03.md)__ Isaac wanted to give his blessing to Esau. But before he did, __Rebekah__ and Jacob tricked him by having Jacob pretend to be Esau.
  __*[07:06](https://git.door43.org/Door43/en_tn/src/master/obs/07/06.md)__ But __Rebekah__ heard of Esau's plan. So she sent Jacob far away to live with her relatives.

### Word Data:

* Strong's: H7259


## <a id="tw-term-names-redsea"/>Sea of Reeds, Red Sea

### Facts:

The "Sea of Reeds" was the name of a body of water located between Egypt and Arabia. It is now called the "Red Sea."
 
* The Red Sea is long and narrow. It is larger than a lake or river, but much smaller than an ocean.
* The Israelites had to cross the Red Sea when they were fleeing from Egypt. God performed a miracle and caused the waters of the sea to divide so that the people could walk across on dry land.
* The land of Canaan was north of this sea.
* This could also be translated as "Reed Sea."

(See also: [Arabia](#arabia)**.** [Canaan](#canaan), [Egypt](#egypt))

### Bible References:

* [Acts 07:35-37](https://git.door43.org/Door43/en_tn/src/master/act/07/35.md)
* [Exodus 13:17-18](https://git.door43.org/Door43/en_tn/src/master/exo/13/17.md)
* [Joshua 04:22-24](https://git.door43.org/Door43/en_tn/src/master/jos/04/22.md)
* [Numbers 14:23-25](https://git.door43.org/Door43/en_tn/src/master/num/14/23.md)

### Examples from the Bible stories:

  __*[12:04](https://git.door43.org/Door43/en_tn/src/master/obs/12/04.md)__  When the Israelites saw the Egyptian army coming, they realized they were trapped between Pharaoh's army and the __Red Sea__.
  __*[12:05](https://git.door43.org/Door43/en_tn/src/master/obs/12/05.md)__  Then God told Moses, "Tell the people to move toward the __Red Sea__."
  __*[13:01](https://git.door43.org/Door43/en_tn/src/master/obs/13/01.md)__  After God led the Israelites through the __Red Sea__, he led them through the wilderness to a mountain called Sinai.

### Word Data:

* Strong's: H3220, H5488, G2063, G2281


## <a id="tw-term-names-rehoboam"/>Rehoboam

### Facts:

Rehoboam was one of the sons of King Solomon, and he became the king of the nation of Israel after Solomon died.

* At the beginning of his reign, Rehoboam was severe with his people, so ten of the tribes of Israel rebelled against him and formed the "kingdom of Israel" in the north.
* Rehoboam continued as king of the southern kingdom of Judah, which consisted of the remaining two tribes, Judah and Benjamin.
* Rehoboam was a wicked king who did not obey Yahweh, but worshiped false gods.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [kingdom of Israel](#kingdomofisrael), [Judah](#kingdomofjudah), [Solomon](#solomon))

### Bible References:

* [1 Chronicles 03:10-12](https://git.door43.org/Door43/en_tn/src/master/1ch/03/10.md)
* [1 Kings 11:41-43](https://git.door43.org/Door43/en_tn/src/master/1ki/11/41.md)
* [1 Kings 14:21-22](https://git.door43.org/Door43/en_tn/src/master/1ki/14/21.md)
* [Matthew 01:7-8](https://git.door43.org/Door43/en_tn/src/master/mat/01/07.md)

### Examples from the Bible stories:

  __*[18:05](https://git.door43.org/Door43/en_tn/src/master/obs/18/05.md)__ After Solomon died, his son, __Rehoboam__, became king. __Rehoboam__ was a foolish man.
  __*[18:06](https://git.door43.org/Door43/en_tn/src/master/obs/18/06.md)__ __Rehoboam__ answered foolishly and told them, "You thought my father Solomon made you work hard, but I will make you work harder than he did, and I will punish you more harshly than he did."
  __*[18:07](https://git.door43.org/Door43/en_tn/src/master/obs/18/07.md)__ Ten of the tribes of the nation of Israel rebelled against __Rehoboam__. Only two tribes remained faithful to him.

### Word Data:

* Strong's: H7346, G4497


## <a id="tw-term-names-reuben"/>Reuben

### Facts:

Reuben was the firstborn son of Jacob. His mother was Leah.

 * When his brothers were planning to kill their younger brother Joseph, Reuben spared Joseph's life by telling them to put him into a pit instead.
 * Reuben came back later to rescue Joseph, but the other brothers had sold him as a slave to merchants passing by.
 * Reuben's descendants became one of the twelve tribes of Israel.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Jacob](#jacob), [Joseph (OT)](#josephot), [Leah](#leah), [twelve tribes of Israel](other.html#12tribesofisrael))

### Bible References:

* [Genesis 29:31-32](https://git.door43.org/Door43/en_tn/src/master/gen/29/31.md)
* [Genesis 35:21-22](https://git.door43.org/Door43/en_tn/src/master/gen/35/21.md)
* [Genesis 42:21-22](https://git.door43.org/Door43/en_tn/src/master/gen/42/21.md)
* [Genesis 42:37-38](https://git.door43.org/Door43/en_tn/src/master/gen/42/37.md)

### Word Data:

* Strong's: H7205, H7206, G4502


## <a id="tw-term-names-rimmon"/>Rimmon

### Facts:

Rimmon was the name of a man and of several places mentioned in the Bible. It was also the name of a false god.

* A man named Rimmon was a Benjamite from the city of Beeroth in Zebulun. This man's sons murdered Ishbosheth, the crippled son of Jonathan.
* Rimmon was a town in the southern part of Judah, in the region occupied by the tribe of Benjamin.
* The "rock of Rimmon" was a place of safety where the Benjamites went to escape from being killed in a battle.
* Rimmon Perez was an unknown location in the Judean wilderness.
* The Syrian commander Naaman spoke of the temple of the false god Rimmon, where the king of Syria worshiped.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Benjamin](#benjamin), [Judea](#judea), [Naaman](#naaman), [Syria](#syria), [Zebulun](#zebulun))

### Bible References:

* [2 Kings 05:17-19](https://git.door43.org/Door43/en_tn/src/master/2ki/05/17.md)
* [2 Samuel 04:5-7](https://git.door43.org/Door43/en_tn/src/master/2sa/04/05.md)
* [Judges 20:45-46](https://git.door43.org/Door43/en_tn/src/master/jdg/20/45.md)
* [Judges 21:13-15](https://git.door43.org/Door43/en_tn/src/master/jdg/21/13.md)

### Word Data:

* Strong's: H7417


## <a id="tw-term-names-rome"/>Rome, Roman

### Facts:

In New Testament times, the city of Rome was the center of the Roman Empire. It is now the capital city of the modern-day country of Italy.

 * The Roman Empire ruled over all the regions around the Mediterranean Sea, including Israel.
 * The term "Roman" referred to anything relating to the regions that the government in Rome controlled, including Roman citizens and Roman officials.
 * The apostle Paul was taken to the city of Rome as a prisoner because he preached the good news about Jesus.
 * The New Testament book of "Romans" is a letter that Paul wrote to the Christians in Rome.

(See also: [good news](kt.html#goodnews), [the sea](#mediterranean), [Pilate](#pilate), [Paul](#paul))

### Bible References:

* [2 Timothy 01:15-18](https://git.door43.org/Door43/en_tn/src/master/2ti/01/15.md)
* [Acts 22:25-26](https://git.door43.org/Door43/en_tn/src/master/act/22/25.md)
* [Acts 28:13-15](https://git.door43.org/Door43/en_tn/src/master/act/28/13.md)
* [John 11:47-48](https://git.door43.org/Door43/en_tn/src/master/jhn/11/47.md)

### Examples from the Bible stories:

  __*[23:04](https://git.door43.org/Door43/en_tn/src/master/obs/23/04.md)__ When the time was near for Mary to give birth, the __Roman__ government told everyone to go for a census to the town where their ancestors had lived. 
  __*[32:06](https://git.door43.org/Door43/en_tn/src/master/obs/32/06.md)__ Then Jesus asked the demon, "What is your name?" He replied, "My name is Legion, because we are many." (A "legion" was a group of several thousand soldiers in the __Roman__ army.)
  __*[39:09](https://git.door43.org/Door43/en_tn/src/master/obs/39/09.md)__ Early the next morning, the Jewish leaders brought Jesus to the __Roman__ governor, Pilate, hoping to have Jesus killed.
  __*[39:12](https://git.door43.org/Door43/en_tn/src/master/obs/39/12.md)__ The __Roman__ soldiers whipped Jesus and put a royal robe and a crown made of thorns on him. Then they mocked him by saying, "Look, the King of the Jews!"

### Word Data:

* Strong's: G4514, G4516


## <a id="tw-term-names-ruth"/>Ruth

### Facts:

Ruth was a Moabite woman who lived during the time when judges were leading Israel. She married an Israelite man in Moab after he had moved there with his family because of a famine during the time when judges were leading Israel.

* Ruth's husband died, and some time after that she left Moab to travel with her mother-in-law Naomi, who was returning to her hometown, Bethlehem in Israel.
* Ruth was loyal to Naomi and worked hard to provide food for her.
* She also committed herself to serving the one true God of Israel.
* Ruth married an Israelite man named Boaz and gave birth to a son who became the grandfather of King David. Because King David was an ancestor of Jesus Christ so was Ruth.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Bethlehem](#bethlehem), [Boaz](#boaz), [David](#david), [judge](other.html#judgeposition)])

### Bible References:

* [Matthew 01:4-6](https://git.door43.org/Door43/en_tn/src/master/mat/01/04.md)
* [Ruth 01:3-5](https://git.door43.org/Door43/en_tn/src/master/rut/01/03.md)
* [Ruth 03:8-9](https://git.door43.org/Door43/en_tn/src/master/rut/03/08.md)
* [Ruth 04:5-6](https://git.door43.org/Door43/en_tn/src/master/rut/04/05.md)

### Word Data:

* Strong's: H7327, G4503


## <a id="tw-term-names-saltsea"/>Salt Sea, Dead Sea

### Facts:

The Salt Sea (also called the Dead Sea) was located between southern Israel on its west and Moab on its east.

* The Jordan River flows south into the Salt Sea.
* Because it is smaller than most seas, it could be called "Salt Lake."
* This sea has such a high concentration of minerals (or "salts") that nothing can live in its waters. Its lack of plants and animals is the cause of the name "Dead Sea."
* In the Old Testament, this sea is also called the "Sea of Arabah" and the "Sea of Negev" because of its location near the regions of Arabah and Negev.


(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Ammon](#ammon), [Arabah](#arabah), , [Jordan River](#jordanriver), [Moab](#moab), [Negev](#negev))

### Bible References:

* [2 Chronicles 20:1-2](https://git.door43.org/Door43/en_tn/src/master/2ch/20/01.md)
* [Deuteronomy 03:17](https://git.door43.org/Door43/en_tn/src/master/deu/03/17.md)
* [Joshua 03:14-16](https://git.door43.org/Door43/en_tn/src/master/jos/03/14.md)
* [Numbers 34:1-3](https://git.door43.org/Door43/en_tn/src/master/num/34/01.md)

### Word Data:

* Strong's: H3220, H4417


## <a id="tw-term-names-samaria"/>Samaria, Samaritan

### Facts:

Samaria was the name of a city and its surrounding region in the northern part of Israel. The region was located between the Plain of Sharon on its west and the Jordan River on its east.

* In the Old Testament, Samaria was the capital city of the northern kingdom of Israel. Later the region surrounding it was also called Samaria.
* When the Assyrians conquered the northern kingdom of Israel, they captured the city of Samaria and forced most of the northern Israelites to leave the region, moving them far away to different cities in Assyria.
* The Assyrians also brought many foreigners into the region of Samaria to replace the Israelites who had been moved.
* Some of the Israelites who remained in that region married the foreigners who had moved there, and their descendants were called Samaritans.
* The Jews despised the Samaritans because they were only partly Jewish and because their ancestors had worshiped pagan gods.
* In New Testament times, the region of Samaria was bordered by the region of Galilee on its north and the region of Judea on its south.

(See also: [Assyria](#assyria), [Galilee](#galilee), [Judea](#judea), [Sharon](#sharon), [kingdom of Israel](#kingdomofisrael))

### Bible References:

* [Acts 08:1-3](https://git.door43.org/Door43/en_tn/src/master/act/08/01.md)
* [Acts 08:4-5](https://git.door43.org/Door43/en_tn/src/master/act/08/04.md)
* [John 04:4-5](https://git.door43.org/Door43/en_tn/src/master/jhn/04/04.md)
* [Luke 09:51-53](https://git.door43.org/Door43/en_tn/src/master/luk/09/51.md)
* [Luke 10:33-35](https://git.door43.org/Door43/en_tn/src/master/luk/10/33.md)

### Examples from the Bible stories:

  __*[20:04](https://git.door43.org/Door43/en_tn/src/master/obs/20/04.md)__ Then the Assyrians brought foreigners to live in the land where the kingdom of Israel had been. The foreigners rebuilt the destroyed cities and married the Israelites who were left there. The descendants of the Israelites who married foreigners were called __Samaritans__.
  __*[27:08](https://git.door43.org/Door43/en_tn/src/master/obs/27/08.md)__ "The next person to walk down that road was a __Samaritan__. (__Samaritans__ were the descendants of Jews who had married people from other nations. __Samaritans__ and Jews hated each other.)"
  __*[27:09](https://git.door43.org/Door43/en_tn/src/master/obs/27/09.md)__ "The __Samaritan__ then lifted the man onto his own donkey and took him to a roadside inn where he took care of him."
  __*[45:07](https://git.door43.org/Door43/en_tn/src/master/obs/45/07.md)__ He (Philip) went to __Samaria__ where he preached about Jesus and many people were saved.

### Word Data:

* Strong's: H8111, H8115, H8118, G4540, G4541, G4542


## <a id="tw-term-names-samson"/>Samson

### Facts:

Samson was one of the judges, or deliverers, of Israel. He was from the tribe of Dan.

* God gave Samson superhuman strength, which he used to fight against Israel's enemies, the Philistines.
* Samson was put under a vow to never cut his hair and to never drink wine or any other fermented drink. As long as he kept this vow, God continued to give him strength.
* He finally broke his vow and allowed his hair to be cut, enabling the Philistines to capture him.
* While Samson was in captivity, God enabled him to regain his strength and gave him the opportunity to destroy the temple of the false god Dagon, along with many Philistines.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [deliver](other.html#deliverer), [Philistines](#philistines), [twelve tribes of Israel](other.html#12tribesofisrael))

### Bible References:

* [Hebrews 11:32-34](https://git.door43.org/Door43/en_tn/src/master/heb/11/32.md)
* [Judges 13:24-25](https://git.door43.org/Door43/en_tn/src/master/jdg/13/24.md)
* [Judges 16:1-2](https://git.door43.org/Door43/en_tn/src/master/jdg/16/01.md)
* [Judges 16:30-31](https://git.door43.org/Door43/en_tn/src/master/jdg/16/30.md)

### Word Data:

* Strong's: H8123, G4546


## <a id="tw-term-names-samuel"/>Samuel

### Facts:

Samuel was a prophet and the last judge of Israel. He anointed both Saul and David as kings over Israel.

* Samuel was born to Elkanah and Hannah in the town of Ramah.
* Hannah had been barren, so she had prayed earnestly that God would give her a son. Samuel was the answer to that prayer.
* Hannah promised that if, in answer to her desperate prayer that God would give her a male child, her request was granted, she would dedicate her son to Yahweh.
* To fulfill her promise to God, when Samuel was a young boy, Hannah sent him to live with and help Eli the priest in the temple.
* God raised up Samuel to be a great prophet.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Hannah](#hannah), [judge](kt.html#judge), [prophet](kt.html#prophet), [Yahweh](kt.html#yahweh))

### Bible References:

* [1 Samuel 01:19-20](https://git.door43.org/Door43/en_tn/src/master/1sa/01/19.md)
* [1 Samuel 09:23-24](https://git.door43.org/Door43/en_tn/src/master/1sa/09/23.md)
* [1 Samuel 12:16-18](https://git.door43.org/Door43/en_tn/src/master/1sa/12/16.md)
* [Acts 03:24-26](https://git.door43.org/Door43/en_tn/src/master/act/03/24.md)
* [Acts 13:19-20](https://git.door43.org/Door43/en_tn/src/master/act/13/19.md)
* [Hebrews 11:32-34](https://git.door43.org/Door43/en_tn/src/master/heb/11/32.md)

### Word Data:

* Strong's: H8050, G4545


## <a id="tw-term-names-sarah"/>Sarah, Sarai

### Facts:

 * Sarah was Abraham's wife.
 * Her name was originally "Sarai," but God changed it to "Sarah."
 * Sarah gave birth to Isaac, the son God had promised to give her and Abraham.
 
(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))
   
(See also: [Abraham](#abraham), [Isaac](#isaac))

### Bible References:

* [Genesis 11:29-30](https://git.door43.org/Door43/en_tn/src/master/gen/11/29.md)
* [Genesis 11:31-32](https://git.door43.org/Door43/en_tn/src/master/gen/11/31.md)
* [Genesis 17:15-16](https://git.door43.org/Door43/en_tn/src/master/gen/17/15.md)
* [Genesis 25:9-11](https://git.door43.org/Door43/en_tn/src/master/gen/25/09.md)

### Examples from the Bible stories:

  __*[05:01](https://git.door43.org/Door43/en_tn/src/master/obs/05/01.md)__ "So Abram's wife, __Sarai__, said to him, "Since God has not allowed me to have children and now I am too old to have children, here is my servant, Hagar. Marry her also so she can have a child for me."
  __*[05:04](https://git.door43.org/Door43/en_tn/src/master/obs/05/04.md)__ "'Your wife, __Sarai__, will have a son--he will be the son of promise.'"
  __*[05:04](https://git.door43.org/Door43/en_tn/src/master/obs/05/04.md)__ "God also changed __Sarai's__ name to __Sarah__, which means "princess."
  __*[05:05](https://git.door43.org/Door43/en_tn/src/master/obs/05/05.md)__ "About a year later, when Abraham was 100 years old and __Sarah__ was 90, __Sarah__ gave birth to Abraham's son. They named him Isaac as God had told them to do."

### Word Data:

* Strong's: H8283, H8297, G4564


## <a id="tw-term-names-saul"/>Saul (OT)

### Facts:

Saul was an Israelite man whom God chose to become the first king of Israel.

* Saul was tall and handsome, and a powerful soldier. He was the kind of man that the Israelites wanted to be their king.
* Although he served God at first, Saul later became proud and disobeyed God. As a result, God appointed David to take Saul's place as king and allowed Saul to be killed in battle.
* In the New Testament, there was a Jew named Saul who was also known as Paul and who became an apostle of Jesus Christ.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [king](other.html#king))

### Bible References:

* [1 Chronicles 10:1-3](https://git.door43.org/Door43/en_tn/src/master/1ch/10/01.md)
* [1 Samuel 09:1-2](https://git.door43.org/Door43/en_tn/src/master/1sa/09/01.md)
* [2 Samuel 01:1-2](https://git.door43.org/Door43/en_tn/src/master/2sa/01/01.md)
* [Acts 13:21-22](https://git.door43.org/Door43/en_tn/src/master/act/13/21.md)
* [Psalm 018:1](https://git.door43.org/Door43/en_tn/src/master/psa/018/001.md)

### Examples from the Bible stories:

  __*[17:01](https://git.door43.org/Door43/en_tn/src/master/obs/17/01.md)__ __Saul__ was the first king of Israel. He was tall and handsome, just like the people wanted. __Saul__ was a good king for the first few years that he ruled over Israel. But then he became a wicked man who did not obey God, so God chose a different man who would one day be king in his place.
  __*[17:04](https://git.door43.org/Door43/en_tn/src/master/obs/17/04.md)__ __Saul__ became jealous of the people's love for David. __Saul__ tried many times to kill him, so David hid from __Saul__. 
  __*[17:05](https://git.door43.org/Door43/en_tn/src/master/obs/17/05.md)__ Eventually, __Saul__ died in battle, and David became king of Israel.

### Word Data:

* Strong's: H7586, G4549


## <a id="tw-term-names-seaofgalilee"/>Sea of Galilee, Sea of Kinnereth, lake of Gennesaret, Sea of Tiberias

### Facts:

The "Sea of Galilee" is a lake in eastern Israel. In the Old Testament it was called the "Sea of Kinnereth."

 * The water of this lake flows south through the Jordan River down to the Salt Sea.
 * Capernaum, Bethsaida, Gennesaret, and Tiberias were some of the towns located on the Sea of Galilee during New Testament times.
 * Many events of Jesus' life took place on or near the Sea of Galilee.
 * The Sea of Galilee was also referred to as the "Sea of Tiberias" and the "lake of Gennesaret."
 * This term could also be translated as "lake in the region of Galilee" or "Lake Galilee" or "lake near Tiberias (Gennesaret)."

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Capernaum](#capernaum), [Galilee](#galilee), [Jordan River](#jordanriver), [Salt Sea](#saltsea))

### Bible References:

* [John 06:1-3](https://git.door43.org/Door43/en_tn/src/master/jhn/06/01.md)
* [Luke 05:1-3](https://git.door43.org/Door43/en_tn/src/master/luk/05/01.md)
* [Mark 01:16-18](https://git.door43.org/Door43/en_tn/src/master/mrk/01/16.md)
* [Matthew 04:12-13](https://git.door43.org/Door43/en_tn/src/master/mat/04/12.md)
* [Matthew 04:18-20](https://git.door43.org/Door43/en_tn/src/master/mat/04/18.md)
* [Matthew 08:18-20](https://git.door43.org/Door43/en_tn/src/master/mat/08/18.md)
* [Matthew 13:1-2](https://git.door43.org/Door43/en_tn/src/master/mat/13/01.md)
* [Matthew 15:29-31](https://git.door43.org/Door43/en_tn/src/master/mat/15/29.md)

### Word Data:

* Strong's: H3220, H3672, G1056, G1082, G2281, G3041, G5085


## <a id="tw-term-names-sennacherib"/>Sennacherib

### Facts:

Sennacherib was a powerful king of Assyria who caused Nineveh to become a rich, important city.

* King Sennacherib is known for his wars against Babylon and the kingdom of Judah.
* He was a very arrogant king and he ridiculed Yahweh.
* Sennacherib attacked Jerusalem during the time of King Hezekiah.
* Yahweh caused Sennacherib's army to be destroyed.
* The Old Testament books of Kings and Chronicles record some of the events of Sennacherib's reign. 
 

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Assyria](#assyria), [Babylon](#babylon), [Hezekiah](#hezekiah), [Judah](#kingdomofjudah), [mock](other.html#mock), [Nineveh](#nineveh))

### Bible References:

* [2 Chronicles 32:1](https://git.door43.org/Door43/en_tn/src/master/2ch/32/01.md)
* [2 Chronicles 32:16-17](https://git.door43.org/Door43/en_tn/src/master/2ch/32/16.md)
* [2 Kings 18:13-15](https://git.door43.org/Door43/en_tn/src/master/2ki/18/13.md)

### Word Data:

* Strong's: Sennacherib


## <a id="tw-term-names-seth"/>Seth

### Facts:

In the book of Genesis, Seth was the third son of Adam and Eve.

* Eve said that Seth was given to her in place of her son Abel, who was murdered by his brother Cain.
* Noah was one of Seth's descendants, so everyone who has lived since the time of the Flood is also a descendant of Seth.
* Seth and his family were the first people to "call on the name of the Lord."

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Abel](#abel), [Cain](#cain), [call](kt.html#call), [descendant](other.html#descendant), [ancestor](other.html#father), [flood](other.html#flood), [Noah](#noah))

### Bible References:

* [1 Chronicles 01:1-4](https://git.door43.org/Door43/en_tn/src/master/1ch/01/01.md)
* [Luke 03:36-38](https://git.door43.org/Door43/en_tn/src/master/luk/03/36.md)
* [Numbers 24:17](https://git.door43.org/Door43/en_tn/src/master/num/24/17.md)

### Word Data:

* Strong's: H8352, G4589


## <a id="tw-term-names-sharon"/>Sharon, Plain of Sharon

### Facts:

Sharon was the name of a flat, fertile area of land along the coast of the Mediterranean Sea, south of Mount Carmel. It is also known as the "Plain of Sharon."

* Several cities mentioned in the Bible were located on the Plain of Sharon, including Joppa, Lydda, and Caesarea.
* This could be translated as "the plain called Sharon" or "Sharon Plain."
* People who lived in the region of Sharon were called "Sharonites."

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Caesarea](#caesarea), [Carmel](#carmel), [Joppa](#joppa), [the sea](#mediterranean))

### Bible References:

* [1 Chronicles 05:16-17](https://git.door43.org/Door43/en_tn/src/master/1ch/05/16.md)
* [Acts 09:33-35](https://git.door43.org/Door43/en_tn/src/master/act/09/33.md)
* [Isaiah 33:9](https://git.door43.org/Door43/en_tn/src/master/isa/33/09.md)

### Word Data:

* Strong's: H8289, H8290


## <a id="tw-term-names-sheba"/>Sheba

### Facts:

In ancient times, Sheba was an ancient civilization or region of land that was located somewhere in southern Arabia.

* The region or country of Sheba was probably located near what are now the present-day countries of Yemen and Ethiopia.
Its inhabitants were probably descendants of Ham.
* The Queen of Sheba came to visit King Solomon when she heard the fame of his riches and wisdom.
* There were also several men named "Sheba" listed in genealogies in the Old Testament. It is possible that the name of the region of Sheba came from one of these men.
* The city of Beersheba was shortened to Sheba one time in the Old Testament.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Arabia](#arabia), [Beersheba](#beersheba), [Ethiopia](#ethiopia), [Solomon](#solomon))

### Bible References:

* [1 Chronicles 01:8-10](https://git.door43.org/Door43/en_tn/src/master/1ch/01/08.md)
* [1 Kings 10:1-2](https://git.door43.org/Door43/en_tn/src/master/1ki/10/01.md)
* [Isaiah 60:6-7](https://git.door43.org/Door43/en_tn/src/master/isa/60/06.md)
* [Psalms 072:8-10](https://git.door43.org/Door43/en_tn/src/master/psa/072/008.md)

### Word Data:

* Strong's: H5434, H7614


## <a id="tw-term-names-shechem"/>Shechem

### Facts:

Shechem was a town in Canaan located about 40 miles north of Jerusalem. Shechem was also the name of a man in the Old Testament.

* The town of Shechem was where Jacob settled after being reconciled to his brother Esau.
* Jacob bought land from the sons of Hamor the Hivite in Shechem. This land later became his family burial ground and the place where his sons buried him.
* Hamor's son Shechem raped Jacob's daughter Dinah, resulting in Jacob's sons killing all the men in the town of Shechem.

(Translation suggestions: [Hamor](#hamor)

(See also: [Canaan](#canaan), [Esau](#esau), [Hamor](#hamor), [Hivite](#hivite), [Jacob](#jacob))

### Bible References:

* [Acts 07:14-16](https://git.door43.org/Door43/en_tn/src/master/act/07/14.md)
* [Genesis 12:6-7](https://git.door43.org/Door43/en_tn/src/master/gen/12/06.md)
* [Genesis 33:18-20](https://git.door43.org/Door43/en_tn/src/master/gen/33/18.md)
* [Genesis 37:12-14](https://git.door43.org/Door43/en_tn/src/master/gen/37/12.md)

### Word Data:

* Strong's: H7928, H7930


## <a id="tw-term-names-shem"/>Shem

### Facts:

Shem was one of Noah's three sons, all of whom went with him into the ark during the worldwide flood described in the book of Genesis.

* Shem was the ancestor of Abraham and his descendants.
* The descendants of Shem were known as "Semites"; they spoke "Semitic" languages such as Hebrew and Arabic.
* The Bible indicates that Shem lived nearly 600 years.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Abraham](#abraham), [Arabia](#arabia), [ark](kt.html#ark), [flood](other.html#flood), [Noah](#noah))

### Bible References:

* [Genesis 05:32](https://git.door43.org/Door43/en_tn/src/master/gen/05/32.md)
* [Genesis 06:9-10](https://git.door43.org/Door43/en_tn/src/master/gen/06/09.md)
* [Genesis 07:13-14](https://git.door43.org/Door43/en_tn/src/master/gen/07/13.md)
* [Genesis 10:1](https://git.door43.org/Door43/en_tn/src/master/gen/10/01.md)
* [Genesis 10:30-31](https://git.door43.org/Door43/en_tn/src/master/gen/10/30.md)
* [Genesis 11:10-11](https://git.door43.org/Door43/en_tn/src/master/gen/11/10.md)
* [Luke 03:36-38](https://git.door43.org/Door43/en_tn/src/master/luk/03/36.md)

### Word Data:

* Strong's: H8035, G4590


## <a id="tw-term-names-shiloh"/>Shiloh

### Facts: ##

Shiloh was a walled Canaanite city that was conquered by the Israelites under the leadership of Joshua.

* The city of Shiloh was located west of the Jordan River and northeast of the city of Bethel.
* During the time that Joshua was leading Israel, the city of Shiloh was a meeting place for the people of Israel.
* The twelve tribes of Israel met together at Shiloh to hear Joshua tell them which portion of the land of Canaan had been assigned to each of them.
* Before any temple was built in Jerusalem, Shiloh was the place where the Israelites came to sacrifice to God.
* When Samuel was a young boy, his mother Hannah took him to live in Shiloh to be trained by the priest Eli to serve Yahweh.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Bethel](#bethel), [dedicate](other.html#dedicate), [Hannah](#hannah), [Jerusalem](#jerusalem), [Jordan River](#jordanriver), [priest](kt.html#priest), [sacrifice](other.html#sacrifice), [Samuel](#samuel), [temple](kt.html#temple))

### Bible References:

* [1 Kings 02:26-27](https://git.door43.org/Door43/en_tn/src/master/1ki/02/26.md)
* [1 Samuel 01:9-10](https://git.door43.org/Door43/en_tn/src/master/1sa/01/09.md)
* [Joshua 18:1-2](https://git.door43.org/Door43/en_tn/src/master/jos/18/01.md)
* [Judges 18:30-31](https://git.door43.org/Door43/en_tn/src/master/jdg/18/30.md)

### Word Data:

* Strong's: H7886, H7887


## <a id="tw-term-names-shimei"/>Shimei

### Definition:

Shimei was the name of several men in the Old Testament.

* Shimei son of Gera was a Benjamite who cursed King David and threw stones at him as he was fleeing Jerusalem to escape being killed by his son Absalom.
* There were also several Levite priests in the Old Testament who were named Shimei.

(See also: [Absalom](#absalom), [Benjamin](#benjamin), [Levite](#levite), [priest](kt.html#priest))

### Bible References:

* [1 Chronicles 06:16-18](https://git.door43.org/Door43/en_tn/src/master/1ch/06/16.md)
* [1 Kings 01:7-8](https://git.door43.org/Door43/en_tn/src/master/1ki/01/07.md)
* [2 Samuel 16:13-14](https://git.door43.org/Door43/en_tn/src/master/2sa/16/13.md)
* [Zechariah 12:12-14](https://git.door43.org/Door43/en_tn/src/master/zec/12/12.md)

### Word Data:

* Strong's: H8096, H8097


## <a id="tw-term-names-shinar"/>Shinar

### Facts:

Shinar means "country of two rivers" and was the name of a plain or region in southern Mesopotamia.

* Shinar later became known as "Chaldea" and then, "Babylonia."
* Ancient peoples living in the city of Babel in the Plain of Shinar built a tall tower to try to make themselves great.
* Generations later, the Jewish patriarch Abraham lived in the city of Ur in this region, which by that time was called "Chaldea."

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Abraham](#abraham), [Babel](#babel), [Babylon](#babylon), [Chaldea](#chaldeans), [Mesopotamia](#mesopotamia), [patriarchs](other.html#patriarchs), [Ur](#ur))

### Bible References:

* [Genesis 10:8-10](https://git.door43.org/Door43/en_tn/src/master/gen/10/08.md)
* [Genesis 14:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/14/01.md)
* [Genesis 14:7-9](https://git.door43.org/Door43/en_tn/src/master/gen/14/07.md)
* [Isaiah 11:10-11](https://git.door43.org/Door43/en_tn/src/master/isa/11/10.md)
* [Zechariah 05:10-11](https://git.door43.org/Door43/en_tn/src/master/zec/05/10.md)

### Word Data:

* Strong's: H8152


## <a id="tw-term-names-sidon"/>Sidon, Sidonians

### Facts:

Sidon was the oldest son of Canaan. There is also a Canaanite city called Sidon, probably named after Canaan's son.
 
 * The city of Sidon was located northwest of Israel on the coast of the Mediterranean Sea in a region that is part of the present-day country of Lebanon.
 * The "Sidonians" were a Phoenician people group who lived in ancient Sidon and the region surrounding it.
 * In the Bible, Sidon is closely associated with the city of Tyre, and both cities were known for their wealth and for immoral behavior of their people.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Canaan](#canaan), [Noah](#noah), [Phoenicia](#phonecia), [the sea](#mediterranean), [Tyre](#tyre))

### Bible References:

* [Acts 12:20-21](https://git.door43.org/Door43/en_tn/src/master/act/12/20.md)
* [Acts 27:3-6](https://git.door43.org/Door43/en_tn/src/master/act/27/03.md)
* [Genesis 10:15-18](https://git.door43.org/Door43/en_tn/src/master/gen/10/15.md)
* [Genesis 10:19-20](https://git.door43.org/Door43/en_tn/src/master/gen/10/19.md)
* [Mark 03:7-8](https://git.door43.org/Door43/en_tn/src/master/mrk/03/07.md)
* [Matthew 11:20-22](https://git.door43.org/Door43/en_tn/src/master/mat/11/20.md)
* [Matthew 15:21-23](https://git.door43.org/Door43/en_tn/src/master/mat/15/21.md)

### Word Data:

* Strong's: H6721, H6722, G4605, G4606


## <a id="tw-term-names-silas"/>Silas, Silvanus

### Facts:

Silas was a leader among the believers in Jerusalem.

 * The elders of the church in Jerusalem appointed Silas to go with Paul and Barnabas to take a letter to the city of Antioch.
 * Silas later traveled with Paul to other cities to teach people about Jesus.
 * Paul and Silas were put in jail in the city of Philippi. They sang praises to God while they were there and God released them from the jail. The jailer became a Christian as a result of their testimony.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Antioch](#antioch), [Barnabas](#barnabas), [Jerusalem](#jerusalem), [Paul](#paul), [Philippi](#philippi), [prison](other.html#prison), [testimony](kt.html#testimony))

### Bible References:

* [1 Peter 05:12-14](https://git.door43.org/Door43/en_tn/src/master/1pe/05/12.md)
* [1 Thessalonians 01:1](https://git.door43.org/Door43/en_tn/src/master/1th/01/01.md)
* [2 Thessalonians 01:1-2](https://git.door43.org/Door43/en_tn/src/master/2th/01/01.md)
* [Acts 15:22-23](https://git.door43.org/Door43/en_tn/src/master/act/15/22.md)

### Examples from the Bible stories:

 * __[47:01](https://git.door43.org/Door43/en_tn/src/master/obs/47/01.md)__ One day, Paul and his friend __Silas__ went to the town of Philippi to proclaim the good news about Jesus. 
 * __[47:02](https://git.door43.org/Door43/en_tn/src/master/obs/47/02.md)__ She (Lydia) invited Paul and __Silas__ to stay at her house, so they stayed with her and her family.
 * __[47:03](https://git.door43.org/Door43/en_tn/src/master/obs/47/03.md)__ Paul and __Silas__ often met with people at the place of prayer. 
 * __[47:07](https://git.door43.org/Door43/en_tn/src/master/obs/47/07.md)__ So the owners of the slave girl took Paul and __Silas__ to the Roman authorities, who beat them  and threw them into jail.
 * __[47:08](https://git.door43.org/Door43/en_tn/src/master/obs/47/08.md)__ They put Paul and __Silas__ in the most secure part of the prison and even locked up their feet. 
 * __[47:11](https://git.door43.org/Door43/en_tn/src/master/obs/47/11.md)__ The jailer trembled as he came to Paul and __Silas__ and asked, "What must I do to be saved?" 
 * __[47:13](https://git.door43.org/Door43/en_tn/src/master/obs/47/13.md)__ The next day the leaders of the city released Paul and __Silas__ from prison and asked them to leave Philippi. Paul and __Silas__ visited Lydia and some other friends and then left the city.

### Word Data:

* Strong's: G4609, G4610


## <a id="tw-term-names-simeon"/>Simeon

### Facts:

In the Bible, there were several men named Simeon.

* In the Old Testament, the second son of Jacob (Israel) was named Simeon. His mother was Leah. His descendants became one of the twelve tribes of Israel.
* The tribe of Simeon occupied part of the southernmost territory in the promised land of Canaan. Its land was entirely surrounded by the land that belonged to Judah.
* When Joseph and Mary brought the baby Jesus to the temple in Jerusalem to dedicate him to God, an elderly man named Simeon praised God for allowing him to see the Messiah.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Canaan](#canaan), [Christ](kt.html#christ), [dedicate](other.html#dedicate), [Jacob](#jacob), [Judah](#judah), [temple](kt.html#temple))

### Bible References:

* [Genesis 29:33-34](https://git.door43.org/Door43/en_tn/src/master/gen/29/33.md)
* [Genesis 34:24-26](https://git.door43.org/Door43/en_tn/src/master/gen/34/24.md)
* [Genesis 42:35-36](https://git.door43.org/Door43/en_tn/src/master/gen/42/35.md)
* [Genesis 43:21-23](https://git.door43.org/Door43/en_tn/src/master/gen/43/21.md)
* [Luke 02:25-26](https://git.door43.org/Door43/en_tn/src/master/luk/02/25.md)

### Word Data:

* Strong's: H8095, H8099, G4826


## <a id="tw-term-names-simonthezealot"/>Simon the Zealot

### Facts:

Simon the Zealot was one of Jesus' twelve disciples.

* Simon is mentioned three times in the listing of Jesus' disciples, but little else is known about him.
* Simon was one of the Eleven who met to pray together in Jerusalem after Jesus went back up into heaven.
* The term "zealot" may mean that Simon was a member of "the Zealots," a Jewish religious party that was very zealous in upholding the Law of Moses while strongly opposing the Roman government.
* Or, "zealot" may simply mean "the zealous one," referring to Simon's religious zeal.


(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [apostle](kt.html#apostle), [disciple](kt.html#disciple), [the twelve](kt.html#thetwelve))

### Bible References:

* [Acts 01:12-14](https://git.door43.org/Door43/en_tn/src/master/act/01/12.md)
* [Luke 06:14-16](https://git.door43.org/Door43/en_tn/src/master/luk/06/14.md)
* [Mark 03:17-19](https://git.door43.org/Door43/en_tn/src/master/mrk/03/17.md)

### Word Data:

* Strong's: G2208, G2581, G4613


## <a id="tw-term-names-sinai"/>Sinai, Mount Sinai

### Facts:

Mount Sinai is a mountain that was probably located in the southern part of what is now called the Sinai Peninsula. It was also known as "Mount Horeb."

* Mount Sinai is part of a large, rocky desert.
* The Israelites came to Mount Sinai as they were traveling from Egypt to the Promised Land.
* God gave Moses the Ten Commandments on Mount Sinai.

(See also: [desert](other.html#desert), [Egypt](#egypt), [Horeb](#horeb), [Promised Land](kt.html#promisedland), [Ten Commandments](other.html#tencommandments))

### Bible References:

* [Acts 07:29-30](https://git.door43.org/Door43/en_tn/src/master/act/07/29.md)
* [Exodus 16:1-3](https://git.door43.org/Door43/en_tn/src/master/exo/16/01.md)
* [Galatians 04:24-25](https://git.door43.org/Door43/en_tn/src/master/gal/04/24.md)
* [Leviticus 27:34](https://git.door43.org/Door43/en_tn/src/master/lev/27/34.md)
* [Numbers 01:17-19](https://git.door43.org/Door43/en_tn/src/master/num/01/17.md)

### Examples from the Bible stories:

  __*[13:01](https://git.door43.org/Door43/en_tn/src/master/obs/13/01.md)__ After God led the Israelites through the Red Sea, he led them through the wilderness to a mountain called __Sinai__.
  __*[13:03](https://git.door43.org/Door43/en_tn/src/master/obs/13/03.md)__ Three days later, after the people had prepared themselves spiritually, God came down on top of __Mount Sinai__ with thunder, lightning, smoke, and a loud trumpet blast.
  __*[13:11](https://git.door43.org/Door43/en_tn/src/master/obs/13/11.md)__ For many days, Moses was on top of __Mount Sinai__ talking with God.
  __*[15:13](https://git.door43.org/Door43/en_tn/src/master/obs/15/13.md)__ Then Joshua reminded the people of their obligation to obey the covenant that God had made with the Israelites at __Sinai__.

### Word Data:

* Strong's: H2022, H5514, G3735, G4614


## <a id="tw-term-names-sodom"/>Sodom

### Definition:

Sodom was a city in the southern part of Canaan where Abraham's nephew Lot lived with his wife and children.

* The land of the region surrounding Sodom was very well watered and fertile, so Lot chose to live there when he first settled in Canaan.
* The exact location of this city is not known because Sodom and the nearby city of Gomorrah were completely destroyed by God as punishment for the evil things the people there were doing.
* The most significant sin that the people of Sodom and Gomorrah were practicing was homosexuality.

(See also: [Canaan](#canaan), [Gomorrah](#gomorrah))

### Bible References:

* [Genesis 10:19-20](https://git.door43.org/Door43/en_tn/src/master/gen/10/19.md)
* [Genesis 13:12-13](https://git.door43.org/Door43/en_tn/src/master/gen/13/12.md)
* [Matthew 10:14-15](https://git.door43.org/Door43/en_tn/src/master/mat/10/14.md)
* [Matthew 11:23-24](https://git.door43.org/Door43/en_tn/src/master/mat/11/23.md)

### Word Data:

* Strong's: H5467, G4670


## <a id="tw-term-names-solomon"/>Solomon

### Facts:

Solomon was one of King David's sons. His mother was Bathsheba.

* When Solomon became king, God told him to ask for anything he wanted. So Solomon asked for wisdom to rule the people justly and well. God was pleased with Solomon's request and gave him both wisdom and much wealth.
* Solomon is also well known for having a magnificent temple built in Jerusalem.
* Although Solomon ruled wisely in the first years of his reign, later on he foolishly married many foreign women and started worshiping their gods. 
* Because of Solomon's unfaithfulness, after his death God divided the Israelites into two kingdoms, Israel and Judah. These kingdoms often fought against each other.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Bathsheba](#bathsheba), [David](#david), [Israel](kt.html#israel), [Judah](#kingdomofjudah), [kingdom of Israel](#kingdomofisrael), [temple](kt.html#temple))

### Bible References:

* [Acts 07:47-50](https://git.door43.org/Door43/en_tn/src/master/act/07/47.md)
* [Luke 12:27-28](https://git.door43.org/Door43/en_tn/src/master/luk/12/27.md)
* [Matthew 01:7-8](https://git.door43.org/Door43/en_tn/src/master/mat/01/07.md)
* [Matthew 06:27-29](https://git.door43.org/Door43/en_tn/src/master/mat/06/27.md)
* [Matthew 12:42](https://git.door43.org/Door43/en_tn/src/master/mat/12/42.md)

### Examples from the Bible stories:

  __*[17:14](https://git.door43.org/Door43/en_tn/src/master/obs/17/14.md)__ Later,  David and Bathsheba had another son, and they named him __Solomon__.
  __*[18:01](https://git.door43.org/Door43/en_tn/src/master/obs/18/01.md)__ After many years, David died, and his son __Solomon__ began to rule. God spoke to __Solomon__ and asked him what he wanted most. When __Solomon__ asked for wisdom, God was pleased and made him the wisest man in the world. __Solomon__ learned many things and was a very wise judge. God also made him very wealthy.
  __*[18:02](https://git.door43.org/Door43/en_tn/src/master/obs/18/02.md)__ In Jerusalem, __Solomon__ built the Temple for which his father David had planned and gathered materials.
  __*[18:03](https://git.door43.org/Door43/en_tn/src/master/obs/18/03.md)__ But __Solomon__ loved women from other countries. ... When __Solomon__ was old, he also worshiped their gods.
  __*[18:04](https://git.door43.org/Door43/en_tn/src/master/obs/18/04.md)__ God was angry with __Solomon__ and, as a punishment for __Solomon's__ unfaithfulness, he promised to divide the nation of Israel into two kingdoms after __Solomon's__ death.

### Word Data:

* Strong's: H8010, G4672


## <a id="tw-term-names-stephen"/>Stephen

### Facts:

Stephen is most remembered as the first Christian martyr, that is, the first person to be killed because of his faith in Jesus. The facts about his life and death are recorded in the book of Acts.

* Stephen was appointed by the early Church in Jerusalem to serve the Christians as a deacon by providing food for widows and other Christians in need.
* Certain Jews falsely accused Stephen of speaking against God and against the laws of Moses.
* Stephen boldly spoke the truth about Jesus the Messiah, beginning with the history of God's dealings with the people of Israel.
* The Jewish leaders were furious and executed Stephen by stoning him to death outside the city.
* His execution was witnessed by Saul of Tarsus, who later became the apostle Paul.
* Stephen is also well-known for his last words before he died, "Lord, please do not hold this sin against them," which showed the love he had for others.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [appoint](kt.html#appoint), [deacon](kt.html#deacon), [Jerusalem](#jerusalem), [Paul](#paul), [stone](kt.html#stone), [true](kt.html#true))

### Bible References:

* [Acts 06:5-6](https://git.door43.org/Door43/en_tn/src/master/act/06/05.md)
* [Acts 06:8-9](https://git.door43.org/Door43/en_tn/src/master/act/06/08.md)
* [Acts 06:10-11](https://git.door43.org/Door43/en_tn/src/master/act/06/10.md)
* [Acts 06:12-15](https://git.door43.org/Door43/en_tn/src/master/act/06/12.md)
* [Acts 07:59-60](https://git.door43.org/Door43/en_tn/src/master/act/07/59.md)
* [Acts 11:19-21](https://git.door43.org/Door43/en_tn/src/master/act/11/19.md)
* [Acts 22:19-21](https://git.door43.org/Door43/en_tn/src/master/act/22/19.md)

### Word Data:

* Strong's: G4736


## <a id="tw-term-names-succoth"/>Succoth

### Definition:

Succoth was the name of two Old Testament cities. The word, "succoth" (or "sukkoth") means "shelters."

* The first city called Succoth was located on the east side of the Jordan River.
* Jacob stayed at Succoth with his family and flocks, building shelters for them there.
* Hundreds of years later, Gideon and his exhausted men stopped at Succoth as they were chasing the Midanites, but the people there refused to give them any food.
* The second Succoth was located on the northern border of Egypt and was a place where the Israelites stopped after they crossed the Red Sea as they were escaping from slavery in Egypt.

### Bible References:

* [1 Kings 07:46-47](https://git.door43.org/Door43/en_tn/src/master/1ki/07/46.md)
* [Exodus 12:37-40](https://git.door43.org/Door43/en_tn/src/master/exo/12/37.md)
* [Joshua 13:27-28](https://git.door43.org/Door43/en_tn/src/master/jos/13/27.md)
* [Judges 08:4-5](https://git.door43.org/Door43/en_tn/src/master/jdg/08/04.md)

### Word Data:

* Strong's: H5523, H5524


## <a id="tw-term-names-syria"/>Syria

### Facts:

Syria is a country located northeast of Israel. During the time of the New Testament, it was a province under the rule of the Roman Empire.

* In the Old Testament time period, the Syrians were strong military enemies of the Israelites.
* Naaman was a commander of the Syrian army who was cured of leprosy by the prophet Elisha.
* Many inhabitants of Syria are descendants of Aram, who was descended from Noah's son Shem.
* Damascus, the capital city of Syria, was mentioned many times in the Bible.
* Saul went to the city of Damascus with plans to persecute Christians there, but Jesus stopped him.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Aram](#aram), [commander](other.html#commander), [Damascus](#damascus), [descendant](other.html#descendant), [Elisha](#elisha), [leprosy](other.html#leprosy), [Naaman](#naaman), [persecute](other.html#persecute), [prophet](kt.html#prophet))

### Bible References:

* [Acts 15:22-23](https://git.door43.org/Door43/en_tn/src/master/act/15/22.md)
* [Acts 15:39-41](https://git.door43.org/Door43/en_tn/src/master/act/15/39.md)
* [Acts 20:1-3](https://git.door43.org/Door43/en_tn/src/master/act/20/01.md)
* [Galatians 01:21-24](https://git.door43.org/Door43/en_tn/src/master/gal/01/21.md)
* [Matthew 04:23-25](https://git.door43.org/Door43/en_tn/src/master/mat/04/23.md)

### Word Data:

* Strong's: H130, H726, H758, H761, H762, H804, H1834, H4601, H7421, G4947, G4948


## <a id="tw-term-names-tamar"/>Tamar

### Facts:

Tamar was the name of several women in the Old Testament. It was also the name of several cities or other places in the Old Testament.
* Tamar was the daughter-in-law of Judah. She gave birth to Perez who was an ancestor of Jesus Christ.
* One of King David's daughters was named Tamar; she was the sister of Absalom. Her half-brother Amnon raped her and left her desolate.
* Absalom also had a daughter named Tamar.
* A city called "Hazezon Tamar" was the same as the city of Engedi on the western shore of the Salt Sea. There is also a "Baal Tamar," and general references to a place called "Tamar" which may have been different from the cities.

(See also: [Absalom](#absalom), [ancestor](other.html#father), [Amnon](#amnon), [David](#david), [ancestor](other.html#father), [Judah](#judah), [Salt Sea](#saltsea))

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

### Bible References:

* [1 Chronicles 02:3-4](https://git.door43.org/Door43/en_tn/src/master/1ch/02/03.md)
* [2 Samuel 13:1-2](https://git.door43.org/Door43/en_tn/src/master/2sa/13/01.md)
* [2 Samuel 14:25-27](https://git.door43.org/Door43/en_tn/src/master/2sa/14/25.md)
* [Genesis 38:6-7](https://git.door43.org/Door43/en_tn/src/master/gen/38/06.md)
* [Genesis 38:24-26](https://git.door43.org/Door43/en_tn/src/master/gen/38/24.md)
* [Matthew 01:1-3](https://git.door43.org/Door43/en_tn/src/master/mat/01/01.md)

### Word Data:

* Strong's: H1193, H2688, H8412, H8559


## <a id="tw-term-names-tarshish"/>Tarshish

### Facts:

Tarshish was the name of two men in the Old Testament. It was also the name of a city.

* One of Japheth's grandsons was named Tarshish.
* Tarshish was also the name of one of the wise men of King Ahashuerus. 
* The city of Tarshish was a very prosperous port city, whose ships carried valuable products to buy, sell, or trade.
* This city was associated with Tyre and is thought to have been a Phoenician city that was somewhat distant from Israel, perhaps on the southern coast of Spain.
* The Old Testament prophet Jonah boarded a ship bound for the city of Tarshish instead of obeying God's command to go preach to Nineveh.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Esther](#esther), [Japheth](#japheth), [Jonah](#jonah), [Nineveh](#nineveh), [Phoenicia](#phonecia), [wise men](other.html#wisemen))

### Bible References:

* [Genesis 10:2-5](https://git.door43.org/Door43/en_tn/src/master/gen/10/02.md)
* [Isaiah 02:14-16](https://git.door43.org/Door43/en_tn/src/master/isa/02/14.md)
* [Jeremiah 10:8-10](https://git.door43.org/Door43/en_tn/src/master/jer/10/08.md)
* [Jonah 01:1-3](https://git.door43.org/Door43/en_tn/src/master/jon/01/01.md)
* [Psalms 048:7-8](https://git.door43.org/Door43/en_tn/src/master/psa/048/007.md)

### Word Data:

* Strong's: H8659


## <a id="tw-term-names-tarsus"/>Tarsus

### Facts:

Tarsus was a prosperous city in the Roman province of Cilicia, in what is now south central Turkey.

* Tarsus was located along a major river and near the Mediterranean Sea, so it was part of an important trade route.
* At one time it was the capital of Cilicia.
* In the New Testament, Tarsus was best known as the hometown of Paul the apostle.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Cilicia](#cilicia), [Paul](#paul), [province](other.html#province), [the sea](#mediterranean))

### Bible References:

* [Acts 09:10-12](https://git.door43.org/Door43/en_tn/src/master/act/09/10.md)
* [Acts 09:28-30](https://git.door43.org/Door43/en_tn/src/master/act/09/28.md)
* [Acts 11:25-26](https://git.door43.org/Door43/en_tn/src/master/act/11/25.md)

### Word Data:

* Strong's: G5018, G5019


## <a id="tw-term-names-terah"/>Terah

### Facts:

Terah was a descendant of Noah's son Shem. He was the father of Abram, Nahor and Haran.

* Terah left his home in Ur in order to go to the land of Canaan with his son Abram, his nephew Lot, and Abram's wife Sarai.
* On the way to Canaan, Terah and his family lived for years in the city of Haran in Mesopotamia. Terah died in Haran at the age of 205.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Abraham](#abraham), [Canaan](#canaan), [Haran](#haran), [Lot](#lot), [Mesopotamia](#mesopotamia), [Nahor](#nahor), [Sarah](#sarah), [Shem](#shem), [Ur](#ur))

### Bible References:

Genesis 11:31-32

* [1 Chronicles 01:24-27](https://git.door43.org/Door43/en_tn/src/master/1ch/01/24.md)
* [Luke 03:33-35](https://git.door43.org/Door43/en_tn/src/master/luk/03/33.md)

\\




## <a id="tw-term-names-thessalonica"/>Thessalonica, Thessalonian, Thessalonians

### Facts:

In New Testament times, Thessalonica was the capital city of Macedonia in the ancient Roman empire. The people living in that city were called the "Thessalonians."

* The city of Thessalonica was an important seaport and was also located along a major road that connected Rome to the eastern part of the Roman empire.
* Paul, along with Silas and Timothy, visited Thessalonica on his second missionary journey and as a result, a church was established there. Later, Paul also visited this city on his third missionary journey.
* Paul wrote two letters to the Christians in Thessalonica. These letters (1 Thessalonians and 2 Thessalonians) are included in the New Testament.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Macedonia](#macedonia), [Paul](#paul), [Rome](#rome))

### Bible References:

* [1 Thessalonians 01:1](https://git.door43.org/Door43/en_tn/src/master/1th/01/01.md)
* [2 Thessalonians 01:1-2](https://git.door43.org/Door43/en_tn/src/master/2th/01/01.md)
* [2 Timothy 04:9-10](https://git.door43.org/Door43/en_tn/src/master/2ti/04/09.md)
* [Acts 17:1-2](https://git.door43.org/Door43/en_tn/src/master/act/17/01.md)
* [Philippians 04:14-17](https://git.door43.org/Door43/en_tn/src/master/php/04/14.md)

### Word Data:

* Strong's: G2331, G2332


## <a id="tw-term-names-thomas"/>Thomas

### Facts:

Thomas was one of twelve men whom Jesus chose to be his disciples and later, apostles. He was also known as "Didymus," which means "twin."

* Near the end of Jesus' life, he told his disciples that he was going away to be with the Father and would prepare a place for them to be with him. Thomas asked Jesus how they could know the way to get there when they didn't even know where he was going.
* After Jesus died and came back to life, Thomas said he would not believe that Jesus was really alive again unless he could see and feel the scars where Jesus had been wounded. 

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [apostle](kt.html#apostle), [disciple](kt.html#disciple), [God the Father](kt.html#godthefather), [the twelve](kt.html#thetwelve))

### Bible References:

* [Acts 01:12-14](https://git.door43.org/Door43/en_tn/src/master/act/01/12.md)
* [John 11:15-16](https://git.door43.org/Door43/en_tn/src/master/jhn/11/15.md)
* [Luke 06:14-16](https://git.door43.org/Door43/en_tn/src/master/luk/06/14.md)
* [Mark 03:17-19](https://git.door43.org/Door43/en_tn/src/master/mrk/03/17.md)
* [Matthew 10:2-4](https://git.door43.org/Door43/en_tn/src/master/mat/10/02.md)

### Word Data:

* Strong's: G2381


## <a id="tw-term-names-timothy"/>Timothy

### Facts:

Timothy was a young man from Lystra. He later joined Paul on several missionary trips and helped shepherd new communities of believers.

* Timothy's father was a Greek, but both his grandmother Lois and his mother Eunice were Jews and believers in Christ.
* The elders and Paul formally appointed Timothy for the ministry by placing their hands on him and praying for him.
* Two books in the New Testament (I Timothy and 2 Timothy) are letters written by Paul that provide guidance to Timothy as a young leader of local churches.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [appoint](kt.html#appoint), [believe](kt.html#believe), [church](kt.html#church), [Greek](#greek), [minister](kt.html#minister))

### Bible References:

* [1 Thessalonians 03:1-3](https://git.door43.org/Door43/en_tn/src/master/1th/03/01.md)
* [1 Timothy 01:1-2](https://git.door43.org/Door43/en_tn/src/master/1ti/01/01.md)
* [Acts 16:1-3](https://git.door43.org/Door43/en_tn/src/master/act/16/01.md)
* [Colossians 01:1-3](https://git.door43.org/Door43/en_tn/src/master/col/01/01.md)
* [Philemon 01:1-3](https://git.door43.org/Door43/en_tn/src/master/phm/01/01.md)
* [Philippians 01:1-2](https://git.door43.org/Door43/en_tn/src/master/php/01/01.md)
* [Philippians 02:19-21](https://git.door43.org/Door43/en_tn/src/master/php/02/19.md)

### Word Data:

* Strong's: G5095


## <a id="tw-term-names-tirzah"/>Tirzah

### Facts:

Tirzah was an important Canaanite city that was conquered by the Israelites. It was also the name of a daughter of Gilead, a descendant of Manasseh.

* The city Tirzah was located in the region occupied by the tribe of Manasseh. It is thought that the city was about 10 miles north of the city of Shechem.
* Years later, Tirzah became a temporary capital city of the northern kingdom of Israel, during the reigns of four kings of Israel.
* Tirzah was also the name of one of Manasseh's granddaughters. They asked to be given a portion of the land since their father had died and he had no sons to inherit it as would normally be the custom.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Canaan](#canaan), [inherit](kt.html#inherit), [kingdom of Israel](#kingdomofisrael), [Manasseh](#manasseh), [Shechem](#shechem))

### Bible References:

* [Numbers 27:1](https://git.door43.org/Door43/en_tn/src/master/num/27/01.md)
* [Numbers 36:10-12](https://git.door43.org/Door43/en_tn/src/master/num/36/10.md)
* [Song of Solomon 06:4](https://git.door43.org/Door43/en_tn/src/master/sng/06/04.md)

### Word Data:

* Strong's: H8656


## <a id="tw-term-names-titus"/>Titus

### Facts:

Titus was a Gentile. He was trained by Paul to be a leader in the early churches.

* A letter written to Titus by Paul is one of the books of the New Testament.
* In this letter Paul instructed Titus to appoint elders for the churches on the island of Crete.
* In some of his other letters to Christians, Paul mentions Titus as someone who encouraged him and brought him joy.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [appoint](kt.html#appoint), [believe](kt.html#believe), [church](kt.html#church), [circumcise](kt.html#circumcise), [Crete](#crete), [elder](other.html#elder), [encourage](other.html#encourage), [instruct](other.html#instruct), [minister](kt.html#minister))

### Bible References:

* [2 Timothy 04:9-10](https://git.door43.org/Door43/en_tn/src/master/2ti/04/09.md)
* [Galatians 02:1-2](https://git.door43.org/Door43/en_tn/src/master/gal/02/01.md)
* [Galatians 02:3-5](https://git.door43.org/Door43/en_tn/src/master/gal/02/03.md)
* [Titus 01:4-5](https://git.door43.org/Door43/en_tn/src/master/tit/01/04.md)

### Word Data:

* Strong's: G5103


## <a id="tw-term-names-troas"/>Troas

### Facts:

The city of Troas was a seaport located on the northwest coast of the ancient Roman province of Asia.

* Paul visited Troas at least three times during his trips to different regions to preach the gospel.
* On one occasion in Troas, Paul preached long into the night and a young man named Eutychus fell asleep while he was listening. Because he had been sitting in an open window, Eutychus fell down a long way and died. Through God's power, Paul raised this young man back to life.
* When Paul was in Rome, he asked Timothy to bring him his scrolls and his cloak, which he had left behind in Troas.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Asia](#asia), [preach](other.html#preach), [province](other.html#province), [raise](other.html#raise), [Rome](#rome), [scroll](other.html#scroll), [Timothy](#timothy))

### Bible References:

* [2 Corinthians 02:12-13](https://git.door43.org/Door43/en_tn/src/master/2co/02/12.md)
* [2 Timothy 04:11-13](https://git.door43.org/Door43/en_tn/src/master/2ti/04/11.md)
* [Acts 16:6-8](https://git.door43.org/Door43/en_tn/src/master/act/16/06.md)
* [Acts 20:4-6](https://git.door43.org/Door43/en_tn/src/master/act/20/04.md)

### Word Data:

* Strong's: G5174


## <a id="tw-term-names-tubal"/>Tubal

### Facts:

There were several men in the Old Testament who had the name "Tubal."

* One man named Tubal was one of the sons of Japheth.
* A man named "Tubal-Cain" was a son of Lamech and descendant of Cain.
* Tubal was also the name of a people group mentioned by the prophets Isaiah and Ezekiel.


(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Cain](#cain), [descendant](other.html#descendant), [Ezekiel](#ezekiel), [Isaiah](#isaiah), [Japheth](#japheth), [Lamech](#lamech), [people group](other.html#peoplegroup), [prophet](kt.html#prophet))

### Bible References:

* [1 Chronicles 01:5-7](https://git.door43.org/Door43/en_tn/src/master/1ch/01/05.md)
* [Ezekiel 27:12-13](https://git.door43.org/Door43/en_tn/src/master/ezk/27/12.md)
* [Genesis 10:2-5](https://git.door43.org/Door43/en_tn/src/master/gen/10/02.md)

### Word Data:

* Strong's: H8422, H8423


## <a id="tw-term-names-tychicus"/>Tychicus

### Facts:

Tychicus was one of Paul's fellow ministers of the gospel.

* Tychicus accompanied Paul on at least one of his missionary journeys to Asia.
* Paul described him as "beloved" and "faithful."
* Tychicus carried Paul's letters to Ephesus and Colosse.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Asia](#asia), [beloved](kt.html#beloved), [Colossae](#colossae), [Ephesus](#ephesus), [faithful](kt.html#faithful), [good news](kt.html#goodnews), [minister](kt.html#minister))

### Bible References:

* [2 Timothy 04:11-13](https://git.door43.org/Door43/en_tn/src/master/2ti/04/11.md)
* [Colossians 04:7-9](https://git.door43.org/Door43/en_tn/src/master/col/04/07.md)
* [Titus 03:12-13](https://git.door43.org/Door43/en_tn/src/master/tit/03/12.md)

{{tag>publish ktlink}

### Word Data:

* Strong's: G5190


## <a id="tw-term-names-tyre"/>Tyre, Tyrians

### Facts:

Tyre was an ancient Canaanite city located on the coast of the Mediterranean Sea in a region that is now part of the modern-day country of Lebanon. Its people were called "Tyrians."

* Part of the city was located on an island in the sea, about one kilometer from the mainland.
* Because of its location and its valuable natural resources, such as cedar trees, Tyre had a prosperous trading industry and was very wealthy.
* King Hiram of Tyre sent wood from cedar trees and skilled laborers to help build a palace for King David.
* Years later, Hiram also sent King Solomon wood and skilled laborers to help build the temple. Solomon paid him with large amounts of wheat and olive oil.
* Tyre was often associated with the nearby ancient city of Sidon. These were the most important cities of the region of Canaan called Phoenicia.


(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Canaan](#canaan), [cedar](other.html#cedar), [Israel](kt.html#israel), [the sea](#mediterranean), [Phoenicia](#phonecia), [Sidon](#sidon))

### Bible References:

* [Acts 12:20-21](https://git.door43.org/Door43/en_tn/src/master/act/12/20.md)
* [Mark 03:7-8](https://git.door43.org/Door43/en_tn/src/master/mrk/03/07.md)
* [Matthew 11:20-22](https://git.door43.org/Door43/en_tn/src/master/mat/11/20.md)
* [Matthew 15:21-23](https://git.door43.org/Door43/en_tn/src/master/mat/15/21.md)

### Word Data:

* Strong's: H6865, H6876, G5183, G5184


## <a id="tw-term-names-ur"/>Ur

### Facts:

Ur was an important city along the Euphrates River in the ancient region of Chaldea, which was part of Mesopotamia. This region was located in what is now the modern-day country of Iraq.

* Abraham was from the city of Ur and it was from there that God called him to leave to go to the land of Canaan.
* Haran, the brother of Abraham and father of Lot, died in Ur. This was probably a factor that influenced Lot to leave Ur with Abraham.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Abraham](#abraham), [Canaan](#canaan), [Chaldea](#chaldeans), [Euphrates River](#euphrates), [Haran](#haran), [Lot](#lot), [Mesopotamia](#mesopotamia))

### Bible References:

* [Genesis 11:27-28](https://git.door43.org/Door43/en_tn/src/master/gen/11/27.md)
* [Genesis 11:31-32](https://git.door43.org/Door43/en_tn/src/master/gen/11/31.md)

### Word Data:

* Strong's: H218


## <a id="tw-term-names-uriah"/>Uriah

### Facts:

Uriah was a righteous man and one of King David's best soldiers. He is often referred to as "Uriah the Hittite."

* Uriah had a very beautiful wife named Bathsheba.
* David committed adultery with Uriah's wife, and she became pregnant with David's child.
* To cover up this sin, David caused Uriah to be killed in battle. Then David married Bathsheba.
* Another man named Uriah was a priest during the time of King Ahaz.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Ahaz](#ahaz), [Bathsheba](#bathsheba), [David](#david), [Hittite](#hittite))

### Bible References:

* [1 Kings 15:4-6](https://git.door43.org/Door43/en_tn/src/master/1ki/15/04.md)
* [2 Samuel 11:2-3](https://git.door43.org/Door43/en_tn/src/master/2sa/11/02.md)
* [2 Samuel 11:26-27](https://git.door43.org/Door43/en_tn/src/master/2sa/11/26.md)
* [Nehemiah 03:3-5](https://git.door43.org/Door43/en_tn/src/master/neh/03/03.md)

### Examples from the Bible stories:

  __*[17:12](https://git.door43.org/Door43/en_tn/src/master/obs/17/12.md)__ Bathsheba's husband, a man named __Uriah__, was one of David's best soldiers. David called __Uriah__ back from the battle and told him to go be with his wife. But __Uriah__ refused to go home while the rest of the soldiers were in battle. So David sent __Uriah__ back to the battle and told the general to place him where the enemy was strongest so that he would be killed.
  __*[17:13](https://git.door43.org/Door43/en_tn/src/master/obs/17/13.md)__ After __Uriah__ was killed, David married Bathsheba.

### Word Data:

* Strong's: H223, G3774


## <a id="tw-term-names-uzziah"/>Uzziah, Azariah

### Facts:

Uzziah became king of Judah at the age of 16 and reigned 52 years, which was an unusually long reign. Uzziah was also known as "Azariah."

* King Uzziah was well-known for his organized and skilled military. He had towers built to protect the city and had specially-designed weapons of war mounted on them to hurl arrows and large stones.
* As long as Uzziah served the Lord, he prospered. Toward the end of his reign, however, he became proud and he disobeyed the Lord by burning incense in the temple, which only the priest was permitted to do.
* Because of this sin, Uzziah became sick with leprosy and had to live separately from other people until the end of his reign.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Judah](#kingdomofjudah), [king](other.html#king), [leprosy](other.html#leprosy), [reign](other.html#reign), [watchtower](other.html#watchtower))

### Bible References:

* [2 Kings 14:20-22](https://git.door43.org/Door43/en_tn/src/master/2ki/14/20.md)
* [Amos 01:1-2](https://git.door43.org/Door43/en_tn/src/master/amo/01/01.md)
* [Hosea 01:1-2](https://git.door43.org/Door43/en_tn/src/master/hos/01/01.md)
* [Isaiah 06:1-2](https://git.door43.org/Door43/en_tn/src/master/isa/06/01.md)
* [Matthew 01:7-8](https://git.door43.org/Door43/en_tn/src/master/mat/01/07.md)

### Word Data:

* Strong's: H5814, H5818, H5838, H5839


## <a id="tw-term-names-vashti"/>Vashti

### Facts:

In the Old Testament book of Esther, Vashti was the wife of Ahasuerus, king of Persia.

* King Ahasuerus sent Queen Vashti away when she refused to obey his order to come to his dinner party and show off her beauty to his drunken guests.
* As a result, a search went out for a new queen and eventually Esther was chosen to be the king's new wife.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Ahasuerus](#ahasuerus), [Esther](#esther), [Persia](#persia))

### Bible References:

* [Esther 01:9-11](https://git.door43.org/Door43/en_tn/src/master/est/01/09.md)
* [Esther 02:1-2](https://git.door43.org/Door43/en_tn/src/master/est/02/01.md)
* [Esther 02:17-18](https://git.door43.org/Door43/en_tn/src/master/est/02/17.md)

### Word Data:

* Strong's: H2060


## <a id="tw-term-names-zacchaeus"/>Zacchaeus

### Facts:

Zacchaeus was a tax collector from Jericho who climbed a tree in order to be able to see Jesus who was surrounded by a large crowd of people.

* Zacchaeus was completely changed when he believed in Jesus.
* He repented of his sin of cheating people and promised to give half his possessions to the poor.
* He also promised that he would pay people back four times the amount that he had overcharged them for their taxes.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [believe](kt.html#believe), [promise](kt.html#promise), [repent](kt.html#repent), [sin](kt.html#sin), [tax](other.html#tax), [tax collector](other.html#taxcollector))

### Bible References:

* [Luke 19:1-2](https://git.door43.org/Door43/en_tn/src/master/luk/19/01.md)
* [Luke 19:5-7](https://git.door43.org/Door43/en_tn/src/master/luk/19/05.md)

### Word Data:

* Strong's: G2195


## <a id="tw-term-names-zadok"/>Zadok

### Facts:

Zadok was the name of an important high priest in Israel during the reign of King David.

* When Absalom rebelled against King David, Zadok supported David and helped bring the ark of the covenant back into Jerusalem.
* Years later, he also took part in the ceremony to anoint David's son Solomon as king.
* Two different men by the name of Zadok helped rebuild the walls of Jerusalem during Nehemiah's time.
* Zadok was also the name of King Jotham's grandfather.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [ark of the covenant](kt.html#arkofthecovenant), [David](#david), [Jotham](#jotham), [Nehemiah](#nehemiah), [reign](other.html#reign), [Solomon](#solomon))

### Bible References:

* [1 Chronicles 24:1-3](https://git.door43.org/Door43/en_tn/src/master/1ch/24/01.md)
* [1 Kings 01:26-27](https://git.door43.org/Door43/en_tn/src/master/1ki/01/26.md)
* [2 Samuel 15:24-26](https://git.door43.org/Door43/en_tn/src/master/2sa/15/24.md)
* [Matthew 01:12-14](https://git.door43.org/Door43/en_tn/src/master/mat/01/12.md)

### Word Data:

* Strong's: H6659, G4524


## <a id="tw-term-names-zebedee"/>Zebedee

### Facts:

Zebedee was a fisherman from Galilee who is known because of his sons, James and John, who were Jesus' disciples. They are often identified in the New Testament as the "sons of Zebedee."

* Zebedee's sons were also fishermen and worked with him to catch fish.
* James and John quit their fishing work with their father Zebedee and left to go follow Jesus.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [disciple](kt.html#disciple), [fishermen](other.html#fisherman), [James (son of Zebedee)](#jamessonofzebedee), [John (the apostle)](#johntheapostle))

### Bible References:

* [John 21:1-3](https://git.door43.org/Door43/en_tn/src/master/jhn/21/01.md)
* [Luke 05:8-11](https://git.door43.org/Door43/en_tn/src/master/luk/05/08.md)
* [Mark 01:19-20](https://git.door43.org/Door43/en_tn/src/master/mrk/01/19.md)
* [Matthew 04:21-22](https://git.door43.org/Door43/en_tn/src/master/mat/04/21.md)
* [Matthew 20:20-21](https://git.door43.org/Door43/en_tn/src/master/mat/20/20.md)
* [Matthew 26:36-38](https://git.door43.org/Door43/en_tn/src/master/mat/26/36.md)

### Word Data:

* Strong's: G2199


## <a id="tw-term-names-zebulun"/>Zebulun

### Facts:

Zebulun was the last son born to Jacob and Leah and is the name of one of the twelve tribes of Israel.

* The Israelite tribe of Zebulun was given the land directly west of the Salt Sea.
* Sometimes the name "Zebulun" is also used to refer to the land where this Israelite tribe lived.
  
(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Jacob](#jacob), [Leah](#leah), [Salt Sea](#saltsea), [twelve tribes of Israel](other.html#12tribesofisrael))

### Bible References:

* [Exodus 01:1-5](https://git.door43.org/Door43/en_tn/src/master/exo/01/01.md)
* [Genesis 30:19-21](https://git.door43.org/Door43/en_tn/src/master/gen/30/19.md)
* [Isaiah 09:1-2](https://git.door43.org/Door43/en_tn/src/master/isa/09/01.md)
* [Judges 04:10](https://git.door43.org/Door43/en_tn/src/master/jdg/04/10.md)
* [Matthew 04:12-13](https://git.door43.org/Door43/en_tn/src/master/mat/04/12.md)
* [Matthew 04:14-16](https://git.door43.org/Door43/en_tn/src/master/mat/04/14.md)

### Word Data:

* Strong's: H2074, H2075, G2194


## <a id="tw-term-names-zechariahnt"/>Zechariah (NT)

### Facts:

In the New Testament, Zechariah was a Jewish priest who became the father of John the Baptist.

 * Zechariah loved God and obeyed him.
 * For many years Zechariah and his wife, Elizabeth, prayed earnestly to have a child, but did not have one. Then when they were very old, God answered their prayers and gave them a son.
 * Zechariah prophesied that his son John would be the prophet who would announce and prepare the way for the Messiah.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Christ](kt.html#christ), [Elizabeth](#elizabeth), [prophet](kt.html#prophet))

### Bible References:

* [Luke 01:5-7](https://git.door43.org/Door43/en_tn/src/master/luk/01/05.md)
* [Luke 01:21-23](https://git.door43.org/Door43/en_tn/src/master/luk/01/21.md)
* [Luke 01:39-41](https://git.door43.org/Door43/en_tn/src/master/luk/01/39.md)
* [Luke 03:1-2](https://git.door43.org/Door43/en_tn/src/master/luk/03/01.md)

### Examples from the Bible stories:

  __*[22:01](https://git.door43.org/Door43/en_tn/src/master/obs/22/01.md)__ Suddenly an angel came with a message from God to an old priest named __Zechariah__. __Zechariah__ and his wife, Elizabeth, were godly people, but she had not been able to have any children.
  __*[22:02](https://git.door43.org/Door43/en_tn/src/master/obs/22/02.md)__ The angel said to __Zechariah__, "Your wife will have a son. You will name him John."
  __*[22:03](https://git.door43.org/Door43/en_tn/src/master/obs/22/03.md)__ Immediately, __Zechariah__ was unable to speak.
  __*[22:07](https://git.door43.org/Door43/en_tn/src/master/obs/22/07.md)__ Then God allowed __Zechariah__ to speak again.

### Word Data:

* Strong's: G2197


## <a id="tw-term-names-zechariahot"/>Zechariah (OT)

### Facts:

Zechariah was a prophet who prophesied during the reign of King Darius I of Persia. The Old Testament book of Zechariah contains his prophecies, which urged the returning exiles to rebuild the temple.

* The prophet Zechariah lived during the same time period as Ezra, Nehemiah, Zerrubbabel and Haggai. He was also mentioned by Jesus as the last of the prophets who were murdered during Old Testament times.
* Another man named Zechariah was a gatekeeper at the temple during the time of David.
* One of King Jehoshaphat's sons who was named Zechariah was murdered by his brother Jehoram.
* Zechariah was the name of a priest who was stoned by the people of Israel when he rebuked them for their idol worship.
* King Zechariah was the son of Jeroboam and he reigned over Israel for only six months before being murdered.

(Translation Suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Darius](#darius), [Ezra](#ezra), [Jehoshaphat](#jehoshaphat), [Jeroboam](#jeroboam), [Nehemiah](#nehemiah), [Zerubbabel](#zerubbabel))

### Bible References:

* [Ezra 05:1-2](https://git.door43.org/Door43/en_tn/src/master/ezr/05/01.md)
* [Matthew 23:34-36](https://git.door43.org/Door43/en_tn/src/master/mat/23/34.md)
* [Zechariah 01:1-3](https://git.door43.org/Door43/en_tn/src/master/zec/01/01.md)

### Word Data:

* Strong's: H2148


## <a id="tw-term-names-zedekiah"/>Zedekiah

### Facts:

Zedekiah, son of Josiah, was the last king of Judah (597-587 B.C.). There are also several other men named Zedekiah in the Old Testament.

* King Nebuchadnezzar made Zedekiah king of Judah after capturing King Jehoiachin and taking him away to Babylon. Zedekiah later rebelled and as a result Nebuchadnezzar captured him and destroyed all of Jerusalem.
* Zedekiah, son of Kenaanah, was a false prophet during the time of King Ahab of Israel.
* A man named Zedekiah was one of those who signed an agreement to the Lord during the time of Nehemiah.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Ahab](#ahab), [Babylon](#babylon), [Ezekiel](#ezekiel), [kingdom of Israel](#kingdomofisrael), [Jehoiachin](#jehoiachin), [Jeremiah](#jeremiah), [Josiah](#josiah), [Judah](#kingdomofjudah), [Nebuchadnezzar](#nebuchadnezzar), [Nehemiah](#nehemiah))

### Bible References:

* [1 Chronicles 03:15-16](https://git.door43.org/Door43/en_tn/src/master/1ch/03/15.md)
* [Jeremiah 37:1-2](https://git.door43.org/Door43/en_tn/src/master/jer/37/01.md)
* [Jeremiah 39:1-3](https://git.door43.org/Door43/en_tn/src/master/jer/39/01.md)

### Word Data:

* Strong's: H6667


## <a id="tw-term-names-zephaniah"/>Zephaniah

### Facts:

Zephaniah, son of Cushi, was a prophet who lived in Jerusalem and prophesied during the reign of King Josiah. He lived during the same time period as Jeremiah.

* He rebuked the people of Judah for worshipping false gods. His prophecies are written in the book of Zephaniah in the Old Testament.
* There were several other men in the Old Testament named Zephaniah, most of whom were priests.

(Translation suggestions: [Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Jeremiah](#jeremiah), [Josiah](#josiah), [priest](kt.html#priest))

### Bible References:

* [2 Kings 25:18-19](https://git.door43.org/Door43/en_tn/src/master/2ki/25/18.md)
* [Jeremiah 52:24-25](https://git.door43.org/Door43/en_tn/src/master/jer/52/24.md)
* [Zechariah 06:9-11](https://git.door43.org/Door43/en_tn/src/master/zec/06/09.md)
* [Zephaniah 01:1-3](https://git.door43.org/Door43/en_tn/src/master/zep/01/01.md)

### Word Data:

* Strong's: H6846


## <a id="tw-term-names-zerubbabel"/>Zerubbabel

### Facts:

Zerubbabel was the name of two Israelite men in the Old Testament.

* One of these was a descendant of Jehoiakim and Zedekiah.
* A different Zerubbabel, son of Shealtiel, was the head of the tribe of Judah during the time of Ezra and Nehemiah, when Cyrus king of Persia released the Israelites from their captivity in Babylon.
* Zerubbabel and the high priest Joshua were among those who helped rebuild the temple and altar of God. 

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Babylon](#babylon), [captive](other.html#captive), [Cyrus](#cyrus), [Ezra](#ezra), [high priest](kt.html#highpriest), [Jehoiakim](#jehoiakim), [Joshua](#joshua), [Judah](#judah), [Nehemiah](#nehemiah), [Persia](#persia), [Zedekiah](#zedekiah))

### Bible References:

* [1 Chronicles 03:19-21](https://git.door43.org/Door43/en_tn/src/master/1ch/03/19.md)
* [Ezra 02:1-2](https://git.door43.org/Door43/en_tn/src/master/ezr/02/01.md)
* [Ezra 03:8-9](https://git.door43.org/Door43/en_tn/src/master/ezr/03/08.md)
* [Luke 03:27-29](https://git.door43.org/Door43/en_tn/src/master/luk/03/27.md)
* [Matthew 01:12-14](https://git.door43.org/Door43/en_tn/src/master/mat/01/12.md)

### Word Data:

* Strong's: H2216, H2217, G2216


## <a id="tw-term-names-zoar"/>Zoar

### Facts:

Zoar was a small city where Lot fled when God destroyed Sodom and Gomorrah.

* It was formerly known as "Bela" but was renamed "Zoar" when Lot asked God to spare this "small" city.
* Zoar is thought to have been located in the plain of the Jordan River or at the southern end of the Dead Sea.

(Translation suggestions: [How to Translate Names](https://git.door43.org/Door43/en_man/src/master/translate/translate-names/01.md))

(See also: [Lot](#lot), [Sodom](#sodom), [Gomorrah](#gomorrah))

### Bible References:

* [Deuteronomy 34:1-3](https://git.door43.org/Door43/en_tn/src/master/deu/34/01.md)
* [Genesis 13:10-11](https://git.door43.org/Door43/en_tn/src/master/gen/13/10.md)
* [Genesis 14:1-2](https://git.door43.org/Door43/en_tn/src/master/gen/14/01.md)
* [Genesis 19:21-22](https://git.door43.org/Door43/en_tn/src/master/gen/19/21.md)
* [Genesis 19:23-25](https://git.door43.org/Door43/en_tn/src/master/gen/19/23.md)

### Word Data:

* Strong's: H6820


