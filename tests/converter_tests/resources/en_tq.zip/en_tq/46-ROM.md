# By what means had God promised the gospel before Paul's time?

God had promised the gospel before by his prophets in the holy scriptures. 

# By what means had God promised the gospel before Paul's time?

God had promised the gospel before by his prophets in the holy scriptures. 

# God's Son was born out of which descendants according to the flesh?

God's Son was born out of the descendants of David according to the flesh. 

# By what event was Jesus Christ declared to be the Son of God?

Jesus Christ was declared to be the Son of God by the resurrection from the dead. 

# For what purpose did Paul receive grace and apostleship from Christ?

Paul received grace and apostleship for obedience of faith among all the nations. 

# For what does Paul thank God concerning the believers in Rome?

Paul thanks God because their faith is proclaimed throughout the whole world. 

# Why does Paul desire to see the believers in Rome?

Paul desires to see them in order to give them some spiritual gift in order to establish them. 

# Why had Paul been unable to visit the believers in Rome until now?

Paul had been unable to visit because he was hindered until now. 

# What does Paul say the gospel is?

Paul says the gospel is the power of God for salvation for every one who believes. 

# What scripture does Paul quote concerning how the righteous will live?

Paul quotes the scripture, "The righteous will live by faith". 

# What do the ungodly and unrighteous do even though that which is known about God is visible to them?

The ungodly and unrighteous hold back the truth even though that which is known about God is visible to them. 

# What do the ungodly and unrighteous do even though that which is known about God is visible to them?

The ungodly and unrighteous hold back the truth even though that which is known about God is visible to them. 

# How are the unseen things about God clearly visible?

The unseen things about God are clearly visible through the created things. 

# What characteristics of God are clearly visible?

God's everlasting power and divine nature are clearly visible. 

# What happens to the thoughts and hearts of those who do not glorify God nor give him thanks?

Those who do not glorify God nor give him thanks become foolish in their thoughts and their hearts are darkened. 

# What does God do to those who exchange his glory for the images of perishable men and animals?

God gives them over to the lusts of their hearts for uncleanness, for their bodies to be dishonored among themselves. 

# For what dishonorable passions do these women and men burn in their lust?

The women burn in their lust for one another, and the men burn in their lust for one another. 

# For what dishonorable passions do these women and men burn in their lust?

The women burn in their lust for one another, and the men burn in their lust for one another. 

# What does God do to those who do not approve of having him in their awareness?

God gives them up to a depraved mind, to do those things that are not proper. 

# What are some of the characteristics of those who have a depraved mind?

Those who have a depraved mind are full of envy, murder, strife, deceit, and evil intentions. 

# What do those with a depraved mind understand about God's requirements?

Those with a depraved mind understand that those who practice such things are worthy of death. 

# Even though those with a depraved mind understand God's requirements, what do they do anyway?

They do unrighteous things anyway, and approve of those who practice them. 

# Why are some people without excuse in their judging?

Some people are without excuse in their judging because what they judge in another they practice themselves. 

# How does God judge when he judges those who practice unrighteousness?

God judges according to truth when he judges those who practice unrighteousness. 

# What is God's patience and goodness meant to do?

God's patience and goodness is meant to lead a person to repentance. 

# What are those with hard, unrepentant hearts toward God storing up for themselves?

Those with hard, unrepentant hearts are storing up for themselves wrath for the day of God's righteous judgment. 

# What do those receive who have done consistent, good actions?

Those who have done consistent, good actions will receive eternal life. 

# What do those receive who obey unrighteousness?

Those who obey unrighteousness receive wrath, fierce anger, tribulation, and distress. 

# What do those receive who obey unrighteousness?

Those who obey unrighteousness receive wrath, fierce anger, tribulation, and distress. 

# How does God show no partiality in his judgment between Jew and Greek?

God shows no partiality because those who sin, either Jew or Greek, will perish. 

# Who is justified before God?

The doers of the Law are justified before God. 

# How do Gentiles show that they do have a law to themselves?

Gentiles show that they have a law to themselves when they do by nature the things of the Law. 

# What challenge does Paul give to those Jews who rest upon the Law and teach others?

Paul challenges them that if they teach others the Law, they should also teach themselves. 

# Which sins does Paul mention that the Jewish teachers of the Law should stop doing?

Paul mentions the sins of stealing, adultery, and the robbery of temples. 

# Which sins does Paul mention that the Jewish teachers of the Law should stop doing?

Paul mentions the sins of stealing, adultery, and the robbery of temples. 

# Why is the name of God dishonored among the Gentiles because of the Jewish teachers of the Law?

God's name is being dishonored because the Jewish teachers of the Law are transgressing the Law. 

# Why is the name of God dishonored among the Gentiles because of the Jewish teachers of the Law?

God's name is being dishonored because the Jewish teachers of the Law are transgressing the Law. 

# How does Paul say a Jewish person's circumcision can become uncircumcision?

Paul says that a Jewish person's circumcision can become uncircumcision if that person is a violator of the Law. 

# How does Paul say that a Gentile person's uncircumcision can be considered circumcision?

Paul says that a Gentile person's uncircumcision can be considered circumcision if that person keeps the requirements of the Law. 

# Who does Paul say is a true Jew?

Paul says that a true Jew is a Jew inwardly, with a circumcision of the heart. 

# Who does Paul say is a true Jew?

Paul says that a true Jew is a Jew inwardly, with a circumcision of the heart. 

# From whom does a true Jew receive praise?

A true Jew receives praise from God. 

# What is first of all among the advantages of the Jew?

First of all among the advantages of the Jew is that they were entrusted with revelation from God. 

# What is first of all among the advantages of the Jew?

First of all among the advantages of the Jew is that they were entrusted with revelation from God. 

# Even though every man is a liar, what is God found to be?

Even though every man is a liar, God is found to be true. 

# Because God is righteous, what is he able to do?

Because God is righteous, he is able to judge the world. 

# Because God is righteous, what is he able to do?

Because God is righteous, he is able to judge the world. 

# What comes on those who say, "Let us do evil, that good may come."?

Judgment comes on those who say, "Let us do evil, that good may come". 

# What is written in the Scriptures about the righteousness of all, both Jews and Greeks?

It is written that there is none righteous, not one. 

# What is written in the Scriptures about the righteousness of all, both Jews and Greeks?

It is written that there is none righteous, not one. 

# According to what is written, who understands and seeks after God?

According to what is written, none understand and none seek after God. 

# Who will be justifed by the works of the Law?

No flesh will be justified by the works of the Law. 

# What comes through the Law?

The knowledge of sin comes through the Law. 

# By what witnesses has a righteousness without the Law now been made known?

By the witnesses of the Law and the Prophets has a righteousness without the Law now been made known. 

# What is the righteousness without the Law that has now been made known?

The righteousness without the Law is the righteousness of God through faith in Jesus Christ for all those who believe. 

# How is a person justified before God?

A person is justified before God freely by his grace through the redemption that is in Christ Jesus. 

# For what purpose did God provide Christ Jesus?

God provided Christ Jesus as a propitiation through faith in his blood. 

# What did God show by all that happened through Jesus Christ?

God showed that he is the one who justifies anyone because of faith in Jesus. 

# What role do the works of the Law have in justification?

A person is justified by faith without the works of the Law. 

# How does God justify the circumcised Jew and the uncircumcised Gentile?

God justifies both by faith. 

# What do we do with the Law through faith?

We uphold the Law through faith. 

# What would have given Abraham reason to boast?

Abraham would have had reason to boast if he had been justified by works. 

# What do the scriptures say about how Abraham was justified?

The scriptures say that Abraham believed God, and it was counted to him as righteousness. 

# What kind of people does God justify?

God justifies the ungodly. 

# According to David, in what way is a man blessed by God?

According to David, blessed is the man whose sins are forgiven and whose sins are not counted by the Lord. 

# According to David, in what way is a man blessed by God?

According to David, blessed is the man whose sins are forgiven and whose sins are not counted by the Lord. 

# According to David, in what way is a man blessed by God?

According to David, blessed is the man whose sins are forgiven and whose sins are not counted by the Lord. 

# Was Abraham's faith counted as righteousness before or after he was circumcised?

Abraham's faith was counted as righteousness before he was circumcised. 

# Was Abraham's faith counted as righteousness before or after he was circumcised?

Abraham's faith was counted as righteousness before he was circumcised. 

# Abraham is the father of which groups of people?

Abraham is the father of all who believe, both the uncircumcised and the circumcised. 

# Abraham is the father of which groups of people?

Abraham is the father of all who believe, both the uncircumcised and the circumcised. 

# What promise was given to Abraham and his descendants through the righteousness of faith?

It was promised to Abraham and his descendants that they would be heirs of the world. 

# What would be true if the promise to Abraham had come through the law?

If the promise had come through the law, then faith would be empty and the promise not true. 

# For what reasons is the promise given by faith?

The promise is given by faith so that it is by grace, and so that it is sure. 

# What two things does Paul say God does?

Paul says that God gives life to the dead and calls things that do not exist into existence. 

# What outward circumstances made it difficult for Abraham to believe God's promise that he would be the father of many nations?

When God made the promise to Abraham, Abraham was about a hundred years old and Sarah's womb was dead. 

# How did Abraham respond to God's promise even with these outward circumstances?

Abraham confidently trusted God and did not hesitate in unbelief. 

# What outward circumstances made it difficult for Abraham to believe God's promise that he would be the father of many nations?

When God made the promise to Abraham, Abraham was about a hundred years old and Sarah's womb was dead. 

# How did Abraham respond to God's promise even with these outward circumstances?

Abraham confidently trusted God and did not hesitate in unbelief. 

# For whom was the account of Abraham written?

The account of Abraham was written for his benefit, and for our benefit. 

# For whom was the account of Abraham written?

The account of Abraham was written for his benefit, and for our benefit. 

# What do we believe God has done for us?

We believe God has raised Jesus from the dead, who was delivered up for our sins and raised for our justification. 

# What do believers have because they are justified by faith?

Because they are justified by faith, believers have peace with God through the Lord Jesus Christ. 

# What are three things that suffering produces?

Suffering produces endurance, approval, and confidence. 

# What are three things that suffering produces?

Suffering produces endurance, approval, and confidence. 

# How does God prove his love toward us?

God proves his love toward us, because while we were still sinners, Christ died for us. 

# Being justified by Christ's blood, from what are believers saved?

Being justified by Christ's blood, believers are saved from the wrath of God. 

# What relationship do unbelievers have with God before they are reconciled to God through Jesus?

Unbelievers are enemies of God before they are reconciled to God through Jesus. 

# What happened because of one man's sin?

Because of one man's sin, sin entered the world, death entered through sin, and death spread to all people. 

# Who was the one man through whom sin entered the world?

Adam was the one man through whom sin entered the world. 

# How is God's free gift different than Adam's sins?

By Adam's sin many died, but by God's free gift many abounded. 

# What resulted from Adam's sin, and what resulted from God's free gift?

The judgment of condemnation resulted from Adam's sin, but justification resulted from God's free gift. 

# What ruled from Adam's sin, and what ruled through God's gift of righteousness?

Death ruled from Adam's sin, and those who receive God's gift rule through the life of Jesus Christ. 

# What were many made through Adam's disobedience, and what will many be made through the obedience of Christ?

Many were made sinners through Adam's disobedience, and many will be made righteous through the obedience of Christ. 

# Why did the Law come in alongside?

The Law came alongside in order that the trespass might abound. 

# What abounded more than the trespass?

God's grace abounded more than the trespass. 

# Should believers continue in sin so that God's grace may abound?

May it never be. 

# Should believers continue in sin so that God's grace may abound?

May it never be. 

# Into what were people baptized who were baptized into Christ Jesus?

People baptized into Christ Jesus were baptized into Christ's death. 

# What should believers do since Christ was raised from the dead?

Believers should walk in newness of life. 

# In what two ways are believers united to Christ through baptism?

Believers are united to Christ in his death and resurrection. 

# What was done for us so that we should no longer be slaves to sin?

Our old man was crucified with Christ, so that we should no longer be slaves to sin. 

# How do we know that death no longer rules over Christ?

We know that death no longer rules over Christ because Christ has been raised from the dead. 

# How many times did Christ die to sin, and for how many people did he die?

Christ died to sin once for all. 

# How should a believer think of himself with respect to sin?

A believer should think of himself as dead to sin. 

# For whom does a believer live his life?

A believer lives his life for God. 

# How should a believer think of himself with respect to sin?

A believer should think of himself as dead to sin. 

# For whom does a believer live his life?

A believer lives his life for God. 

# To whom should a believer present his body parts, and for what purpose?

A believer should present his body parts to God as tools for righteousness. 

# What does a believer live under, which allows him to rule over sin?

A believer lives under grace, which allows him to rule over sin. 

# What is the end result for a person who makes himself a servant of sin?

The end result of a person who makes himself a servant of sin is death. 

# What is the end result for a person who makes himself a servant of God?

The end result of a person who makes himself a servant of God is righteousness. 

# What is the end result for a person who makes himself a servant of God?

The end result of a person who makes himself a servant of God is righteousness. 

# What is the end result for a person who makes himself a servant of God?

The end result of a person who makes himself a servant of God is righteousness. 

# What is the end result for a person who makes himself a servant of sin?

The end result of a person who makes himself a servant of sin is death. 

# Slaves of God have their fruit for what purpose?

Slaves of God have their fruit for sanctification. 

# What are the wages of sin?

The wages of sin are death. 

# What is the free gift of God?

The free gift of God is eternal life. 

# How long does the law control a person?

The law controls a person for as long as he lives. 

# How long is a married woman bound by the law of marriage?

A married woman is bound by the law of marriage until her husband dies. 

# What may a woman do once she is free from the law of marriage?

Once she is free from the law of marriage, a woman may marry another man. 

# How are believers made dead to the Law?

Believers are made dead to the Law through the body of Christ. 

# Having been made dead to the Law, what are believers able to do?

Having been made dead to the Law, believers are able to be joined to Christ. 

# What function does the Law perform?

The Law makes sin known. 

# Is the Law sin?

No, the Law is not sin. 

# What does sin do through the commandment of the Law?

Sin, through the commandment of the Law, brings about every lust in a person. 

# Is the Law holy?

The Law is holy, and the commandment is holy, righteous, and good. 

# What does Paul say sin does to him?

Paul says that sin, through the Law, brings about death in him. 

# What causes Paul to agree with the Law that the Law is good?

When Paul does that which he does not want, then he agrees with the Law that the Law is good. 

# Who is doing the things that Paul does, but does not wish to do?

Sin that lives in Paul does the things that he does not wish to do. 

# What lives in Paul's flesh?

No good thing lives in Paul's flesh. 

# What principle does Paul find at work in him?

Paul finds the principle in him that he wants to do what is good, but evil is actually present in him. 

# What attitude does Paul's inner man have toward the law of God?

Paul's inner man rejoices in the law of God. 

# What principle does Paul find in his body parts?

Paul finds that in his body parts the principle of sin takes him captive. 

# Who will deliver Paul from his body of death?

Paul thanks God through Jesus Christ for his deliverance. 

# What has made Paul free from the principle of sin and death?

The principle of the Spirit of life in Christ Jesus has made Paul free from the principle of sin and death. 

# Why was the Law unable to set people free from the principle of sin and death?

The Law was unable because it was weak through the flesh. 

# Those who walk according to the Spirit pay attention to what?

Those who walk according to the Spirit pay attention to the things of the Spirit. 

# Those who walk according to the Spirit pay attention to what?

Those who walk according to the Spirit pay attention to the things of the Spirit. 

# What is the flesh's relationship to God and the Law?

The flesh is hostile toward God and is not able to be subject to the Law. 

# What are people lacking who do not belong to God?

People who do not belong to God lack the Spirit of Christ living in them. 

# How does God give life to the believer's mortal body?

God gives life to the believer's mortal body through his Spirit, who lives in the believer. 

# How are the sons of God led to live?

The sons of God are led by the Spirit of God. 

# How is a believer included into God's family?

A believer is included into God's family by adoption. 

# As children of God, what other benefit do believers receive in God's family?

As children of God, believers are also heirs of God and joint heirs with Christ. 

# Why are the sufferings of the present time to be endured by believers?

The sufferings of the present time are to be endured so that believers may be glorified with Christ when the sons of God are revealed. 

# Why are the sufferings of the present time to be endured by believers?

The sufferings of the present time are to be endured so that believers may be glorified with Christ when the sons of God are revealed. 

# At the present time, under what kind of slavery is the creation?

At the present time, the creation is under the slavery of decay. 

# Into what will the creation be delivered?

The creation will be delivered into the liberty of the glory of the children of God. 

# How are believers to wait for the redemption of the body?

Believers are to wait with confidence and patience for the redemption of the body. 

# How are believers to wait for the redemption of the body?

Believers are to wait with confidence and patience for the redemption of the body. 

# How are believers to wait for the redemption of the body?

Believers are to wait with confidence and patience for the redemption of the body. 

# What does the Spirit himself do to help in the saints' weakness?

The Spirit himself intercedes in behalf of the saints according to the will of God. 

# What does the Spirit himself do to help in the saints' weakness?

The Spirit himself intercedes in behalf of the saints according to the will of God. 

# How does God work all things together for those who love God and are called according to his purpose?

God works all things together for good for those who love God and are called according to his purpose. 

# What is the destiny that God has predetermined for those whom he foreknew?

God has predestined those whom he foreknew to be conformed to the image of his Son. 

# What else did God do for those he predestined?

Those he predestined, God also called, justified, and glorified. 

# How do believers know that God will freely give them all things?

Believers know that God will freely give them all things because God gave up his own Son on behalf of all believers. 

# What is Christ Jesus doing at the right hand of God?

Christ Jesus is interceding on behalf of the saints at the right hand of God. 

# How are believers more than conquerors over tribulation, persecution, or even death?

Believers are more than conquerors through the one who loved them. 

# What is Paul convinced that no created thing can do to the believer?

Paul is convinced that no created thing can separate the believer from the love of God. 

# What would Paul be willing to do for the sake of his brothers according to the flesh, the Israelites?

Paul would be willing to be cursed by God for the sake of his brothers. 

# What do the Israelites have in their history?

The Israelites have adoption, the glory, the covenants, the Law, the worship of God, and the promises. 

# What does Paul say is not true about everyone in Israel and all of Abraham's descendants?

Paul says that not everyone in Israel truly belongs to Israel, and not all of Abraham's descendants are truly his children. 

# What does Paul say is not true about everyone in Israel and all of Abraham's descendants?

Paul says that not everyone in Israel truly belongs to Israel, and not all of Abraham's descendants are truly his children. 

# Who are not counted as the children of God?

The children of the flesh are not counted as the children of God. 

# Who are counted as the children of God?

The children of the promise are counted as the children of God. 

# What was the cause behind the statement given to Rebecca, "The older will serve the younger," before her children were born?

The purpose of God according to choice was the cause behind the statement given to Rebecca. 

# What was the cause behind the statement given to Rebecca, "The older will serve the younger," before her children were born?

The purpose of God according to choice was the cause behind the statement given to Rebecca. 

# What was the cause behind the statement given to Rebecca, "The older will serve the younger," before her children were born?

The purpose of God according to choice was the cause behind the statement given to Rebecca. 

# What is the cause behind God's gifts of mercy and compassion?

The cause behind God's gifts of mercy and compassion is God's choice. 

# What is the cause behind God's gifts of mercy and compassion?

The cause behind God's gifts of mercy and compassion is God's choice. 

# What is the cause behind God's gifts of mercy and compassion?

The cause behind God's gifts of mercy and compassion is God's choice. 

# What is not the cause behind God's gifts of mercy and compassion?

The cause behind God's gifts of mercy and compassion is not the will or actions of the person receiving the gifts. 

# What is Paul's reply to those who would question if God is righteous because he finds fault in men?

Paul replies, "Who are you who answers against God?" 

# What did God do with those prepared for destruction?

God endured with much patience those prepared for destruction. 

# What did God do with those prepared for glory?

God made known to them the riches of his glory. 

# From which peoples has God called those on whom he is having mercy?

God has called from both Jews and Gentiles those on whom he is having mercy. 

# From all the children of Israel, how many will be saved?

From all the children of Israel, a remnant will be saved. 

# How did the Gentiles, who were not pursuing righteousness, attain it?

The Gentiles attained it through the righteousness by faith. 

# Why did Israel, although pursuing a law of righteousness, not arrive at it?

Israel did not arrive at it because they pursued it by works, and not by faith. 

# Over what did the Israelites stumble?

The Israelites stumbled over the stone of stumbling and the rock of offense. 

# Over what did the Israelites stumble?

The Israelites stumbled over the stone of stumbling and the rock of offense. 

# What happens to those who do not stumble, but believe?

Those who do not stumble, but believe, will not be ashamed. 

# What is Paul's desire for his brothers, the Israelites?

Paul's desire is for the Israelites' salvation. 

# What are the Israelites seeking to establish?

The Israelites are seeking to establish their own righteousness. 

# Of what do the Israelites not know?

The Israelites do not know of God's righteousness. 

# What has Christ done with respect to the Law?

Christ is the fulfillment of the Law for righteousness for everyone who believes. 

# Where is the word of faith which Paul is proclaiming?

The word of faith is near, in the mouth and in the heart. 

# What does Paul say a person does to be saved?

Paul says a person must acknowledge with the mouth Jesus as Lord, and believe in the heart that God raised him from the dead. 

# Everyone who does what will be saved?

Everyone who calls upon the name of the Lord will be saved. 

# What does Paul say is the series of steps which brings the good news to a person, so he can call on the name of the Lord?

Paul says that first a preacher is sent, and the good news is heard and believed, so that a person can call on the name of the Lord. 

# What does Paul say is the series of steps which brings the good news to a person, so he can call on the name of the Lord?

Paul says that first a preacher is sent, and the good news is heard and believed, so that a person can call on the name of the Lord. 

# What is heard which brings faith?

The word of Christ is heard, which brings faith. 

# Did Israel hear the gospel?

Yes, Israel heard the gospel. 

# How did God say he would provoke Israel to jealousy?

God said he would provoke Israel to jealousy by appearing to those who were without understanding. 

# What did God find when he reached out to Israel?

When God reached out to Israel, he found a disobedient and resistant people. 

# Has God then rejected the Israelites?

May it never be. 

# Does Paul say if there are any faithful Israelites remaining, and if so, how have they been preserved?

Paul says that there is a remnant remaining that has been preserved because of the choice of grace. 

# Who among the Israelites obtained salvation, and what happened to the rest?

The chosen among the Israelites obtained salvation, and the rest were hardened. 

# What did the spirit of dullness given by God do to those who received it?

The spirit of dullness made their eyes unable to see and their ears unable to hear. 

# What good has happened because of Israel's refusal to receive the gospel?

Salvation has come to the Gentiles. 

# What effect will the salvation of the Gentiles have on the Israelites?

The salvation of the Gentiles will provoke the Israelites to jealousy. 

# In Paul's analogy of the olive tree root and the wild branches, who is the root and who are the wild branches?

The root is Israel, and the wild branches are the Gentiles. 

# In Paul's analogy of the olive tree root and the wild branches, who is the root and who are the wild branches?

The root is Israel, and the wild branches are the Gentiles. 

# In Paul's analogy of the olive tree root and the wild branches, who is the root and who are the wild branches?

The root is Israel, and the wild branches are the Gentiles. 

# What attitude does Paul say the wild branches must avoid?

Paul says the wild branches must avoid the attitude of boasting over the natural branches that were broken off. 

# What warning does Paul give the wild branches?

Paul warns the wild branches that if God did not spare the natural branches, neither will he spare the wild branches if they fall into unbelief. 

# What warning does Paul give the wild branches?

Paul warns the wild branches that if God did not spare the natural branches, neither will he spare the wild branches if they fall into unbelief. 

# What can God do with natural branches if they do not continue in their unbelief?

God can graft back into the olive tree natural branches that do not continue in their unbelief. 

# What can God do with natural branches if they do not continue in their unbelief?

God can graft back into the olive tree natural branches that do not continue in their unbelief. 

# How long will the partial hardening of Israel last?

The partial hardening of Israel will last until the completion of the Gentiles comes in. 

# Despite their disobedience, why do the Israelites continue to be loved by God?

The Israelites continue to be loved by God because of the ancestors, and because the call of God is unchangeable. 

# Despite their disobedience, why do the Israelites continue to be loved by God?

The Israelites continue to be loved by God because of the ancestors, and because the call of God is unchangeable. 

# What have both Jew and Gentile been shown to be by God?

Both Jew and Gentile have been shown to be disobedient. 

# What has God shown to the disobedient?

God has shown mercy to the disobedient, both Jew and Gentile. 

# What have both Jew and Gentile been shown to be by God?

Both Jew and Gentile have been shown to be disobedient. 

# What has God shown to the disobedient?

God has shown mercy to the disobedient, both Jew and Gentile. 

# What have both Jew and Gentile been shown to be by God?

Both Jew and Gentile have been shown to be disobedient. 

# What has God shown to the disobedient?

God has shown mercy to the disobedient, both Jew and Gentile. 

# Who is able to search God's judgments and give him advice?

No person can search God's judgments and give him advice. 

# Who is able to search God's judgments and give him advice?

No person can search God's judgments and give him advice. 

# What are the three ways all things are related to God?

All things are from God, through God, and to God. 

# What is the spiritual service to God for a believer?

A believer's spiritual service is to present himself a living sacrifice to God. 

# What does a transformed mind in the believer enable him to do?

A transformed mind enables a believer to know what is the good, acceptable, and perfect will of God. 

# How should a believer not think of himself?

A believer should not think of himself more highly than he ought to think. 

# How are the many believers related to each other in Christ?

The many believers are one body in Christ, and individually members of each other. 

# How are the many believers related to each other in Christ?

The many believers are one body in Christ, and individually members of each other. 

# What should each believer do with the gifts God has given him?

Each believer should exercise his gifts according to the proportion of his faith. 

# How should believers treat one another?

Believers should be affectionate to one another and respect one another. 

# How should believers respond to the needs of the saints?

Believers should share in the needs of the saints. 

# How should believers respond to those who persecute them?

Believers should bless, and not curse, those who persecute them. 

# How should believers treat lowly people?

Believers should accept lowly people. 

# As much as is possible, what should believers seek with all people?

As much as is possible, believers should seek peace with all people. 

# Why should believers not avenge themselves?

Believers should not avenge themselves because vengeance belongs to the Lord. 

# How should believers overcome evil?

Believers should overcome evil with good. 

# From where do earthly authorities get their authority?

Earthly authorities are appointed by God, and get their authority from God. 

# What will those receive who oppose the earthly authority?

Those who oppose the earthly authority will receive judgment upon themselves. 

# What does Paul tell believers to do so that they can be unafraid of the ruling authority?

Paul tells believers to do what is good so that they can be unafraid of the ruling authority. 

# What authority has God given rulers in order to suppress evil?

God has given rulers the authority to carry the sword and to punish the one who does evil. 

# What authority has God given rulers regarding money?

God has given rulers the authority to require payment of taxes. 

# What is the one thing Paul says believers should owe to others?

Paul says that believers should owe love to others. 

# How does a believer fulfill the Law?

A believer fulfills the Law by loving his neighbor. 

# Which commandments does Paul list as part of the Law?

Paul lists the commandments to not commit adultery, not kill, not steal, and not covet as part of the Law. 

# How does a believer fulfill the Law?

A believer fulfills the Law by loving his neighbor. 

# What does Paul say believers should put aside, and put on?

Paul says believers should put aside the works of darkness, and put on the armor of light. 

# In what activities are believers not to walk?

Believers are not to walk in wild celebrations, drunkenness, sexual immorality, uncontrolled lust, strife, or jealousy. 

# What should be the believer's attitude toward the lusts of the flesh?

The believer should make no provision for the lusts of the flesh. 

# What kind of food does a person with stronger faith eat, and what does a person with weaker faith eat?

A person who is stronger in faith eats anything, but a person who is weaker in faith eats only vegetables. 

# What attitude should believers who differ on what they eat have toward one another?

Believers who differ on what they eat should not despise or judge each other. 

# Who has received both the one who eats anything and the one who eats only vegetables?

God has received both the one who eats anything and the one who eats only vegetables. 

# Who has received both the one who eats anything and the one who eats only vegetables?

God has received both the one who eats anything and the one who eats only vegetables. 

# What other issue does Paul mention as being an issue of personal conviction?

Paul mentions as an issue of personal conviction whether one day is valued over another or all days are valued equally. 

# For what do believers live and die?

Believers live and die for the Lord. 

# For what do believers live and die?

Believers live and die for the Lord. 

# Where will all believers ultimately stand?

All believers will ultimately stand before the judgment seat of God. 

# What attitude should a brother have toward another brother on issues of personal conviction?

A brother should not place a stumbling block or a snare for another brother on issues of personal conviction. 

# Paul is persuaded in the Lord Jesus that which foods are unclean?

Paul is persuaded that no foods are unclean. 

# About what is the kingdom of God?

The kingdom of God is about righteousness, peace, and joy in the Holy Spirit. 

# What does Paul say a brother should do in the presence of another brother who does not eat meat or drink wine?

Paul says it is good if the brother does not eat meat or drink wine in the presence of the other brother. 

# What is the result if a person does not act from faith?

Whatever actions are not taken from faith are sin. 

# What attitude should believers with strong faith have toward those with weak faith?

Believers with strong faith should bear the weaknesses of those with weak faith, in order to build them up. 

# What attitude should believers with strong faith have toward those with weak faith?

Believers with strong faith should bear the weaknesses of those with weak faith, in order to build them up. 

# Who is the example Paul uses of one who did not live to please himself, but served others?

Christ did not live to please himself, but served others. 

# What was one of the purposes of the scriptures written previously?

The scriptures written previously were written for our instruction. 

# What does Paul desire for the believers through their exercise of patience and encouragement with each other?

Paul desires that the believers be of the same mind with each other. 

# Who is the example Paul uses of one who did not live to please himself, but served others?

Christ did not live to please himself, but served others. 

# Who is the example Paul uses of one who did not live to please himself, but served others?

Christ did not live to please himself, but served others. 

# What do the scriptures say the Gentiles will do because of God's mercy toward them?

The scriptures say the Gentiles will rejoice and praise the Lord. 

# What do the scriptures say the Gentiles will do because of God's mercy toward them?

The scriptures say the Gentiles will rejoice and praise the Lord. 

# What does Paul say the believers will be able to do by the power of the Holy Spirit?

The believers will be filled with joy and peace, and will abound in confidence. 

# What gift did God give Paul, which is Paul's mission?

Paul's mission is to be a servant of Christ Jesus sent to the Gentiles. 

# By what means has Christ worked through Paul to bring about the obedience of the Gentiles?

Christ has worked through Paul by word and action, by the power of signs and wonders, and by the power of the Holy Spirit. 

# By what means has Christ worked through Paul to bring about the obedience of the Gentiles?

Christ has worked through Paul by word and action, by the power of signs and wonders, and by the power of the Holy Spirit. 

# Where does Paul desire to proclaim the gospel?

Paul desires to proclaim the gospel where Christ is not known by name. 

# Where does Paul desire to proclaim the gospel?

Paul desires to proclaim the gospel where Christ is not known by name. 

# Where does Paul plan to travel that will also allow him to come to Rome?

Paul plans to travel to Spain, which will also allow him to come to Rome. 

# Why is Paul now going to Jerusalem?

Paul is now going to Jerusalem to serve the believers there. 

# Why does Paul say the Gentile believers owe the Jewish believers material things?

The Gentiles believers owe the Jewish believers material things because the Gentile believers have shared in the spiritual things of the Jewish believers. 

# From whom does Paul wish to be delivered?

Paul wishes to be delivered from those who are disobedient in Judea. 

# What has sister Phoebe become to Paul?

Sister Phoebe has become a helper of Paul, and of many others. 

# What has sister Phoebe become to Paul?

Sister Phoebe has become a helper of Paul, and of many others. 

# What have Prisca and Aquila done for Paul in the past?

Prisca and Aquila have risked their lives for Paul in the past. 

# Where is one place the believers are meeting in Rome?

The believers in Rome are meeting in the house of Prisca and Aquila. 

# What experience have Andronicus and Junias shared with Paul in the past?

Andronicus and Junias have been fellow prisoners with Paul in the past. 

# How do the believers greet one another?

The believers greet one another with a holy kiss. 

# What are some doing, which is causing divisions and stumbling?

Some are going beyond the teaching they have learned, deceiving the hearts of the innocent. 

# What does Paul tell the believers to do with those causing divisions and stumbling?

Paul tells the believers to turn away from those causing divisions and stumbling. 

# What are some doing, which is causing divisions and stumbling?

Some are going beyond the teaching they have learned, deceiving the hearts of the innocent. 

# What attitude does Paul want the believers to have toward good and evil?

Paul wants the believers to be wise to that which is good, and innocent to that which is evil. 

# What will the God of peace be doing soon?

The God of peace will soon be crushing Satan under the believers' feet. 

# Who actually wrote down this epistle?

Tertius actually wrote down this epistle. 

# What occupation does the believer Erastus have?

Erastus is the treasurer of the city. 

# What revelation that had been kept secret from long ago is Paul now preaching?

Paul is now preaching the revelation of the gospel of Jesus Christ. 

# What revelation that had been kept secret from long ago is Paul now preaching?

Paul is now preaching the revelation of the gospel of Jesus Christ. 

# For what purpose is Paul preaching?

Paul is preaching for the obedience of faith among all the Gentiles. 

