# During what period of time in Jewish history did the story of Ruth occur?

It occurred in the days when the judges ruled. 

# Why did Elimelech move to Moab with his family?

He moved because there was a famine in Judah. 

# Why did Elimelech move to Moab with his family?

He moved because there was a famine in Judah. 

# What happened to Naomi's family in Moab?

Her husband and two sons died, leaving behind two daughters-in-law. 

# What happened to Naomi's family in Moab?

Her husband and two sons died, leaving behind two daughters-in-law. 

# What happened to Naomi's family in Moab?

Her husband and two sons died, leaving behind two daughters-in-law. 

# Why did Naomi decide to return to Judah?

She heard that Yahweh had given the people of Judah food. 

# Want did Naomi want her two daughters-in-law to do?

She wanted them to return to their mothers' houses and find other husbands. 

# Want did Naomi want her two daughters-in-law to do?

She wanted them to return to their mothers' houses and find other husbands. 

# Who did Naomi believe was the source of her trouble?

She believed that Yahweh was the source of her trouble. 

# When Ruth stayed with Naomi, what promise did Ruth make to Naomi?

She said, "Where you go, I will go; and where you stay, I will stay; your people shall be my people, and your God shall be my God; where you die, I will die." 

# When Ruth stayed with Naomi, what promise did Ruth make to Naomi?

She said, "Where you go, I will go; and where you stay, I will stay; your people shall be my people, and your God shall be my God; where you die, I will die." 

# To which town did Naomi return?

She returned to Bethlehem. 

# What name did Naomi want to be called and why?

She asked to be called, "Bitter," because she believed that Yahweh had dealt bitterly with her. 

# What time of the year did Naomi and Ruth arrive in Bethlehem?

It was at the beginning of the barley harvest. 

# What was the relationship between Naomi's dead husband and Boaz?

They were kinsmen. 

# As Ruth went out to glean for the first time, who did Ruth say she would follow while gleaning grain?

She would follow anyone in whose eyes she found favor. 

# What was the relationship between Naomi's dead husband and Boaz?

They were kinsmen. 

# What greeting did Boaz give to his workers?

He said, "May Yahweh be with you." 

# What did Boaz want to know about Ruth?

He wanted to know to what man she belonged. 

# What instructions did Boaz give Ruth concerning her gleaning?

He said, "Stay and work in my field with my women workers." 

# What instructions did Boaz give Ruth concerning her gleaning?

He said, "Stay and work in my field with my women workers." 

# After receiving the favorable instructions, what question did Ruth ask Boaz?

She asked, "Why have I found favor in your sight?" 

# What good deed of Ruth had Boaz heard about?

He had heard that Ruth had left her home to follow Naomi. 

# Under whose wings did Boaz say Ruth had found protection?

Ruth had found protection under Yahweh's wings. 

# What additional favor did Boaz show to Ruth when they returned to work after mealtime?

He allowed Ruth to glean among the sheaves, and commanded the reapers to pull out sheaves for her from the bundles. 

# What additional favor did Boaz show to Ruth when they returned to work after mealtime?

He allowed Ruth to glean among the sheaves, and commanded the reapers to pull out sheaves for her from the bundles. 

# When Naomi saw the large amount of grain that Ruth brought back, what question did she ask Ruth?

She asked, "Where have you gleaned today?" 

# What was the relationship between Naomi's dead husband and Boaz?

They were kinsmen. 

# What did Naomi wish for Boaz when she heard that Boaz had helped Ruth?

She said, "May he be blessed by Yahweh" 

# To whom did Naomi attribute the good things that were now happening to her?

She attributed them to Yahweh. 

# Why did Naomi think it was good for Ruth to work with Boaz's women workers?

By doing that, Ruth would not come to harm in any other field. 

# What did Ruth do for the rest of the barley harvest?

She gleaned with Boaz's workers and lived with Naomi. 

# What did Naomi say her desire was for Ruth?

She desired that Ruth have a place of rest, and that things would go well for her. 

# What did Naomi tell Ruth to do before going down to the threshing floor?

She told her to clean up, put on perfume, and change clothes. 

# What was Ruth to do when she went to where Boaz was sleeping?

She was to uncover his feet and to lie down there. 

# What was Ruth's attitude toward Naomi's instructions?

She was ready to follow all of Naomi's instructions. 

# At midnight, what was Boaz startled to find?

He was startled to find that a woman lay at his feet! 

# What was Ruth's request to Boaz?

She said, "Spread your cloak over your servant, for you are a near kinsman." 

# Why did Boaz ask a blessing from Yahweh for Ruth?

Because Ruth had pursued Boaz and not younger men. 

# What did Boaz say he would do about Ruth's request?

He said that he would do all that she asked. 

# What obstacle prevented Boaz from immediately performing the part of a kinsman for Ruth?

There was another kinsman nearer than Boaz. 

# How was Boaz going to determine who would act as kinsman for Ruth?

If the nearest kinsman was willing, then he would perform the part of the kinsman, but if he was not willing, then Boaz would be the kinsman. 

# Why did Ruth leave the threshing floor early before anyone could recognize her?

Because Boaz had said that it should not be known that she came to the threshing floor. 

# What gift did Boaz give Ruth before she left the threshing floor?

He gave her six large measures of barley. 

# Naomi was sure that Boaz would resolve the issue by what time?

He would resolve it by the end of that same day. 

# Where did Boaz go to resolve the issue of who would be the kinsman for Ruth?

He went to the gate of the city. 

# Who did Boaz ask to sit as witnesses?

He asked ten men of the elders of the city. 

# What did Boaz first ask the other kinsman to redeem if he wished?

He asked him to redeem the parcel of land owned by Elimelech. 

# What did Boaz first ask the other kinsman to redeem if he wished?

He asked him to redeem the parcel of land owned by Elimelech. 

# What was the other kinsman's answer?

He said, "I will redeem it." 

# About what additional requirement did Boaz then tell the other kinsman?

He told him that he would also have to take Ruth in order that Elimelech's name would continue with his inheritance. 

# After this, what was the other kinsman's answer?

He said, "I cannot redeem it." 

# Why did the other kinsman say he could not be the redeemer?

Because it would damage his own inheritance. 

# What did the other kinsman do to show that he agreed Boaz should be the redeemer?

He took off his shoe and gave it to Boaz. 

# Boaz reminded the elders that they had witnessed what two agreements?

They had witnessed that Boaz had bought all that was Elimelech's, and that he had acquired Ruth as his wife. 

# Boaz reminded the elders that they had witnessed what two agreements?

They had witnessed that Boaz had bought all that was Elimelech's, and that he had acquired Ruth as his wife. 

# What blessing did the people desire for Boaz?

They desired for him offspring through Ruth. 

# Why did the women say that Ruth was better for Naomi than seven sons?

Because of Ruth's love for Naomi, and because Ruth had given birth to a grandson for Naomi. 

# What was Naomi's relationship with Ruth's son?

Naomi became his guardian. 

# What was Ruth's son's name?

His name was Obed. 

# Of whom was Obed the father and grandfather?

Obed was the father of Jesse and the grandfather of David. 

