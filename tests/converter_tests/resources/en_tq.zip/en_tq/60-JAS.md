# To whom did James write this letter?

James wrote this letter to the twelve tribes that were scattered. 

# When experiencing troubles, what attitude does James say his readers should have?

James says to consider it all joy when experiencing troubles. 

# What does the testing of our faith produce?

The testing of our faith produces endurance. 

# For what should we ask from God if we need it?

We should ask God for wisdom if we need it. 

# What should someone who asks with doubting expect to receive?

Someone who asks with doubting should not expect to receive anything from the Lord. 

# What should someone who asks with doubting expect to receive?

Someone who asks with doubting should not expect to receive anything from the Lord. 

# What should someone who asks with doubting expect to receive?

Someone who asks with doubting should not expect to receive anything from the Lord. 

# Why should a rich brother be humble?

A rich brother should be humble because he will pass away just like the flowers. 

# Why should a rich brother be humble?

A rich brother should be humble because he will pass away just like the flowers. 

# Those who pass the test of faith will receive what?

Those who pass the test of faith will receive the crown of life. 

# What causes a person to be tempted by evil?

A person's own evil desires cause him to be tempted by evil. 

# What is the result of full grown sin?

The result of full grown sin is death. 

# What comes down from the Father of lights?

Every good gift and every perfect gift comes down from the Father of lights. 

# By what means did God choose to give us life?

God chose to give us life by the word of truth. 

# What does James tell us to do about our hearing, speaking, and emotions?

James tells us to be swift to hear, slow to speak, and slow to anger. 

# How does James say that we can deceive ourselves?

James says that we can deceive ourselves by hearing the word and not doing it. 

# What must be controlled in order for us to be truly religious?

The tongue must be controlled in order for us to be truly religious. 

# What is pure and undefiled religion before God?

Pure and undefiled religion before God is to visit the fatherless and widows, and to protect ourselves from the world's corruption. 

# What does James tell the brothers not to do when someone enters the meeting?

James tells them not to favor certain people because of their appearance. 

# What does James tell the brothers not to do when someone enters the meeting?

James tells them not to favor certain people because of their appearance. 

# What does James tell the brothers not to do when someone enters the meeting?

James tells them not to favor certain people because of their appearance. 

# What does James tell the brothers not to do when someone enters the meeting?

James tells them not to favor certain people because of their appearance. 

# What does James say about God's choice of the poor?

James says that God chose the poor to be rich in faith and to inherit the kingdom. 

# What does James say the rich have been doing?

James says the rich have been oppressing the brothers and blaspheming God's name. 

# What does James say the rich have been doing?

James says the rich have been oppressing the brothers and blaspheming God's name. 

# What is the royal law of the scriptures?

The royal law is, "You shall love your neighbor as yourself". 

# Whoever breaks one point of God's law is guilty of what?

Whoever breaks one point of God's law is guilty of breaking all the law. 

# What comes to those who have not shown mercy?

Judgment without mercy comes to those who have not shown mercy. 

# What does James say about those who claim to have faith, but do not help those in need?

James says that those who claim to have faith, but do not help those in need have a faith that cannot save them. 

# What does James say about those who claim to have faith, but do not help those in need?

James says that those who claim to have faith, but do not help those in need have a faith that cannot save them. 

# What does James say about those who claim to have faith, but do not help those in need?

James says that those who claim to have faith, but do not help those in need have a faith that cannot save them. 

# What is faith by itself, if it has no works?

Faith by itself, if it has no works, is dead. 

# How does James say we must show our faith?

James says we must show our faith by our works. 

# What do those who claim to have faith and demons both believe?

Those who claim to have faith and demons both believe there is one God. 

# How did Abraham demonstrate his faith by his works?

Abraham demonstrated his faith by his works when he offered up Isaac upon the altar. 

# How did Abraham demonstrate his faith by his works?

Abraham demonstrated his faith by his works when he offered up Isaac upon the altar. 

# What scripture was fulfilled with Abraham's faith and works?

The scripture was fulfilled which says, "Abraham believed God, and it was credited to him as righteousness". 

# How did Rahab demonstrate her faith by her works?

Rahab demonstrated her faith by her works when she welcomed the messengers and sent them away by another road. 

# What is a body apart from the spirit?

A body apart from the spirit is dead. 

# Why does James say that not many should become teachers?

Not many should become teachers because they will receive greater judgment. 

# Who stumbles, and in how many ways?

We all stumble in many ways. 

# What kind of person is able to control his whole body?

A person who does not stumble in his words is also able to control his whole body. 

# What two examples does James use to illustrate how a small thing can control a large thing?

James uses the examples of a horse's bit and the rudder of a ship. 

# What two examples does James use to illustrate how a small thing can control a large thing?

James uses the examples of a horse's bit and the rudder of a ship. 

# What is the sinful tongue able to do to the whole body?

The sinful tongue is able to defile the whole body. 

# What has no one among man been able to tame?

No one among man has been able to tame the tongue. 

# What two things come out of the same mouth?

Both blessing and cursing come out of the same mouth. 

# What two things come out of the same mouth?

Both blessing and cursing come out of the same mouth. 

# How does a person demonstrate wisdom and understanding?

A person demonstrates wisdom and understanding by his works done in humility. 

# What attitudes reflect a wisdom that is earthly, unspiritual, and demonic?

A person with bitter jealousy and selfish ambition has wisdom that is earthly, unspiritual, and demonic. 

# What attitudes reflect a wisdom that is earthly, unspiritual, and demonic?

A person with bitter jealousy and selfish ambition has wisdom that is earthly, unspiritual, and demonic. 

# What attitudes reflect a wisdom from above?

A person that is peace-loving, gentle, warm-hearted, full of mercy and good fruit, without favoritism, and sincere has wisdom from above. 

# What does James say is the source of quarreling and disputing among the believers?

The source is the evil desires that war among them. 

# Why do the believers not receive their requests to God?

They do not receive because they ask for bad things to be spent on their evil desires. 

# If a person decides to be a friend of the world, what is that person's relationship with God?

A person who decides to be a friend of the world makes himself an enemy of God. 

# Who does God resist, and to whom does he give grace?

God resists the proud, but gives grace to the humble. 

# What will the devil do when a believer subjects himself to God and resists the devil?

The devil will flee. 

# What will God do for those who draw near to him?

God will draw near to those who draw near to him. 

# What does James tell the believers not to do?

James tells the believers not to speak against one another. 

# What does James tell the believers to say about what will happen in the future?

James tells the believers to say that if the Lord allows, we will live and do this or that. 

# What does James say about those who boast about their plans?

James says that those who boast about their plans are doing evil. 

# What is it if someone knows to do good, but does not do it?

It is sin if someone knows to do good, but does not do it. 

# What have the rich, about whom James is talking, done in the last days which will testify against them?

The rich have hoarded their treasure. 

# How have these rich treated their workers?

These rich have not paid their workers. 

# How have these rich treated the righteous man?

These rich have condemned and killed the righteous man. 

# What does James say the believer's attitude should be toward the coming of the Lord?

The believers should wait patiently for the coming of the Lord. 

# What does James say the believer's attitude should be toward the coming of the Lord?

The believers should wait patiently for the coming of the Lord. 

# What character traits does James say the Old Testament prophets demonstrated to us?

The Old Testament prophets demonstrated patience and perseverance in suffering. 

# What character traits does James say the Old Testament prophets demonstrated to us?

The Old Testament prophets demonstrated patience and perseverance in suffering. 

# What does James say about the reliability of a believer's "Yes" and "No?"

A believer's "Yes" must mean "Yes" and his "No" must mean "No". 

# What should those who are sick do?

The sick should call for the elders so they can pray over him and anoint him with oil. 

# What two things does James say believers should do with each other in order to be healed?

Believers should confess to one another and pray for one another. 

# What does James say the example of Elijah shows us about prayer?

The example of Elijah shows us that the prayer of a righteous man produces great effects. 

# What does James say the example of Elijah shows us about prayer?

The example of Elijah shows us that the prayer of a righteous man produces great effects. 

# What does James say the example of Elijah shows us about prayer?

The example of Elijah shows us that the prayer of a righteous man produces great effects. 

# What does someone accomplish who leads a sinner out of the error of his way?

The person who leads a sinner out of the error of his way saves a soul from death and covers a multitude of sins. 

