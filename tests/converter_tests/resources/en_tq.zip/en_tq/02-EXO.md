# Into what country did the sons of Israel come with Jacob?

The sons of Israel came into Egypt with Jacob. 

# How many descendants of Jacob were there?

All of the descendants of Jacob were seventy in number. 

# Who did not care for the memory of Joseph?

A new king arose over Egypt, who did not care for the memory of Joseph. 

# What did the king of the Egyptians think would happen if they did not deal wisely with the Israelites?

The king of the Egyptians was afraid that the Israelites would continue to multiply, and if war would break out, they would join the Egyptians' enemies, fight against them and leave the land. 

# How did the taskmasters oppress the Israelites?

The taskmasters oppressed the Israelites with hard labor. 

# What happened the more the Egyptians oppressed the Israelites?

The more the Egyptians oppressed the Israelites, the more the Israelites increased in number and spread. 

# What did the king of Egypt tell the midwives to do if the baby was a male?

The king of Egypt told them that if the baby was male, then they must kill him. 

# Why did the midwives not do as the king of Egypt ordered them?

The midwives feared God and did not do as the king of Egypt ordered them. 

# How did the midwives say the Hebrew women were not like the Egyptian women?

They said Hebrew women were vigorous and finished giving birth before a midwife came to them. 

# What did Pharaoh order all his people to do to the male babies?

Pharaoh ordered all his people, "You must throw every male that is born into the river". 

# For how long did the woman of Levi hide her son?

The woman of Levi hid her son for three months. 

# With what did the woman of Levi seal the papyrus basket?

She sealed the papyrus basket with bitumen and pitch. 

# Why did the baby's sister stand at a distance?

The baby's sister stood at a distance to see what would happen to him. 

# What did Pharaoh's daughter do while her attendants walked along by the riverside?

Pharaoh's daughter came down to bathe at the river while her attendants walked along by the riverside. 

# Who did the young girl get to nurse the child for Pharaoh's daughter?

The young girl went and got the child's mother to nurse the child for Pharaoh's daughter. 

# Who did the young girl get to nurse the child for Pharaoh's daughter?

The young girl went and got the child's mother to nurse the child for Pharaoh's daughter. 

# Who named the child Moses?

Pharaoh's daughter named the child Moses. 

# Where did Moses hide the body of the Egyptian whom he killed?

Moses killed the Egyptian and hid his body in the sand. 

# When two Hebrew men were fighting, whom did Moses ask, "Why are you hitting your companion?"

When two Hebrew men were fighting, Moses said to the one who was in the wrong, "Why are you hitting your companion?" 

# Why did Pharaoh not kill Moses?

Pharaoh tried to kill Moses. But Moses fled from Pharaoh and stayed in the land of Midian. 

# Who tried to drive away the daughters of the priest of Midian?

The shepherds came and tried to drive away the daughters of the priest of Midian. 

# When did God call to mind his covenant with Abraham, with Isaac, and with Jacob?

When God heard their groaning, God called to mind his covenant with Abraham, with Isaac, and with Jacob. 

# Who was Moses' father-in-law?

Jethro, the priest of Midian, was Moses' father-in-law 

# How did the angel of the Lord appear to Moses?

The angel of Yahweh appeared to Moses in a flame of fire in a bush. 

# Who called to Moses out of the bush?

God called to Moses out of the bush 

# Why did God tell Moses to take off his shoes from his feet?

God said, "Do not come any closer! Take off your shoes from your feet, for the place where you are standing is ground consecrated for my own purpose". 

# Why did Yahweh come down?

Yahweh came down to free the Israelites from the Egyptians' power and to bring them up from that land to a good, large land, to a land flowing with milk and honey. 

# Why did Yahweh send Moses to Pharaoh?

Yahweh sent Moses to Pharaoh so that Moses would bring Yahweh's people, the Israelites, out of Egypt. 

# What would be a sign to Moses that Yahweh was sending him?

The sign to Moses that Yahweh has sent him would be that when Moses had brought the people out of Egypt, he would worship Yahweh on this mountain. 

# When the Israelites would ask Moses what God's name is, what should he say to them?

When the Israelites would ask Moses what God's name is, he should say, "I AM THAT I AM." 

# How long will the Israelites go into the wilderness, in order that they may sacrifice to Yahweh, their God?

The Israelites will go three days' journey into the wilderness, in order that they might sacrifice to Yahweh, their God. 

# The king of Egyptian would not let the Israelites go unless what happens?

The king of Egyptian would not let the Israelites go unless his hand would be forced. 

# What was in Moses' hand?

A staff was in Moses' hand. 

# What did Moses' staff become when he threw it on the ground?

Moses' staff became a snake when he threw it on the ground. 

# By what should Moses take hold of the snake?

Moses should take the snake by the tail. 

# When Moses first brought his hand out from inside his robe, what happened?

When Moses first brought his hand out from inside his robe, it was leprous. 

# Who will be Moses' mouth and teach him what to say?

Yahweh will be Moses' mouth and teach him what to say. 

# When Aaron sees Moses, how will he feel?

When Aaron sees Moses, he will be glad in his heart. 

# Like who will Moses be to Aaron?

Moses will be like God to Aaron. 

# Why can Moses return to Egypt?

Moses can return to Egypt, for all the men who were trying to take his life are dead. 

# Why will Yahweh harden Pharaoh's heart?

Yahweh will harden Pharaoh's heart, and Pharaoh will not let the people go. 

# Since Pharaoh has refused to let Yahweh's firstborn son go, what will Yahweh do to Pharaoh's firstborn son?

Since Pharaoh has refused to let Yahweh's firstborn son go, Yahweh will certainly kill Pharaoh's firstborn son. 

# Since Pharaoh has refused to let Yahweh's firstborn son go, what will Yahweh do to Pharaoh's firstborn son?

Since Pharaoh has refused to let Yahweh's firstborn son go, Yahweh will certainly kill Pharaoh's firstborn son. 

# When they stopped for the night, what did Yahweh try to do to Moses?

When they stopped for the night, Yahweh met Moses and tried to kill him. 

# Where did Aaron meet Moses?

Aaron met Moses at the mountain of God. 

# Who displayed the signs of Yahweh's power in the sight of the people?

Aaron displayed the signs of Yahweh's power in the sight of the people. 

# Why should Pharaoh let Yahweh's people go?

They should let Yahweh's people go, so they can have a festival for him in the wilderness. 

# Why should the Israelites go on a three-day journey into the wilderness and sacrifice to Yahweh their God ?

The Israelites should go on a three-day journey into the wilderness and sacrifice to Yahweh their God so that he does not attack them with plague or with the sword. 

# To whom did Pharaoh give a command to no longer give the Israelites straw to make bricks?

Pharaoh gave a command to the people's taskmasters and foremen to no longer give the Israelites straw to make bricks. 

# To whom did Pharaoh give a command to no longer give the Israelites straw to make bricks?

Pharaoh gave a command to the people's taskmasters and foremen to no longer give the Israelites straw to make bricks. 

# Although the Israelites must go and get straw wherever they can find it, what will not be reduced?

Although the Israelites must go and get straw wherever they can find it, their workload will not be reduced. 

# Who did Pharaoh's taskmasters beat?

Pharaoh's taskmasters beat the Israelite foremen, those same men whom they had put in charge of the workers. 

# Whose fault was it that the Israelite foremen were beaten?

It was the fault of Pharaoh's own people that the Israelite foremen were beaten. 

# Whose fault was it that the Israelite foremen were beaten?

It was the fault of Pharaoh's own people that the Israelite foremen were beaten. 

# Where were Moses and Aaron as they went away from Pharaoh?

Moses and Aaron were standing outside the palace as they went away from Pharaoh. 

# Who did Moses say caused trouble for the people of Israel?

Moses said the Lord caused trouble for the people of Israel. 

# Why will Pharaoh let the people of Israel go?

Pharoah will let the people of Israel go because of Yahweh's strong hand. 

# How did Yahweh appear to Abraham, to Isaac, and to Jacob?

Yahweh appeared to Abraham, to Isaac, and to Jacob as God Almighty. 

# What has Yahweh heard, and what has he called to mind?

Yahweh has heard the groaning of the Israelites whom the Egyptians have enslaved, and he has called to mind his covenant. 

# What will Yahweh give to the Israelites as a possession?

Yahweh will give the land that he swore to give to Abraham, to Isaac, and to Jacob to the Israelites as a possession. 

# Why does Moses think Pharaoh will not listen to him?

Moses thinks Pharaoh will not listen to him, since he is not good at speaking. 

# How long did Kohath live?

Kohath lived until he was 133 years old 

# Who did Amram marry?

Amram married Jochebed, his father's sister. 

# Who bore Nadab and Abihu?

Elisheba bore Nadab and Abihu. 

# How should Aaron and Moses bring out the Israelites from the land of Egypt?

Aaron and Moses should bring out the Israelites from the land of Egypt by their groups of fighting men. 

# What has Yahweh made Moses like to Pharaoh?

Yahweh has made Moses like a god to Pharaoh. 

# What will Yahweh do to Pharaoh's heart?

Yahweh will harden Pharaoh's heart. 

# When will the Egyptians know who Yahweh is?

The Egyptians will know who Yahweh is when he reaches out with his hand on Egypt and brings out the Israelites from among them. 

# What will Moses' staff become?

Moses' staff will become a snake. 

# How did the staffs of Pharaoh's wiseman and sorcerers become snakes?

The staffs of Pharaoh's wiseman and sorcerers became snakes by their magic. 

# Where should Moses stand to meet Pharaoh?

Moses should stand on the riverbank to meet Pharaoh. 

# To what will the river be turned?

The river will be turned to blood. 

# What water will turn to blood?

The Egyptians' rivers, streams, pools, and all their ponds, and even the water in containers of wood and stone will be turned to blood. 

# What happened to Pharaoh's heart?

Pharaoh's heart was hardened. 

# How did the Egyptians try to get water to drink?

The Egyptians dug around the river for water to drink. 

# What would Yahweh do if Pharaoh refused to let Yahweh's people go?

If Pharaoh refused to let Yahweh's people go, Yahweh would afflict all Pharaoh's country with frogs. 

# Where will the frogs from the river go?

The frogs will come up and go into Egyptians' houses, bedrooms, and beds. They will go into their servants' houses. They will go onto the people, into their ovens, and into their kneading bowls. 

# Where did Aaron reach out with his hand?

Aaron reached out with his hand over Egypt's waters. 

# What privilege did Moses give Pharaoh?

Moses gave Pharaoh the privilege of telling him when he should pray for Pharaoh, his servants, and his people, so that the frogs may be removed from them and their houses and stay only in the river. 

# What did Pharoah do after he saw that there was relief from the frogs?

When Pharaoh saw that there was relief from the frogs, he hardened his heart and did not listen to Moses and Aaron. 

# What did the dust on the ground become?

All the dust on the ground became gnats throughout the whole land of Egypt. 

# When the magicians tried with their magic to produce gnats, what happened?

The magicians tried with their magic to produce gnats, but they could not. 

# What will be full of flies?

The Egyptians' houses will be full of swarms of flies, and even the ground on which they stand will be full of flies. 

# Why will there be no flies in Goshen?

Yahweh would treat the land of Goshen differently, so that no swarms of flies would be there. This would happen so that Pharaoh would know that Yahweh is in the midst of this land. 

# Why do the Israelites not sacrifice in Egypt?

The sacrifices the Israelites make to Yahweh their God are something disgusting to the Egyptians. 

# Why do the Israelites not sacrifice in Egypt?

The sacrifices the Israelites make to Yahweh their God are something disgusting to the Egyptians. 

# Who hardened Pharaoh's heart after the flies left?

Pharaoh hardened his heart this time also. 

# On what will Yahweh's hand be?

Yahweh's hand will be on the Egyptians' cattle in the fields and on the horses, donkeys, camels, herds, and flocks. 

# Even after the cattle died, why did Pharaoh not let the people of Israel go?

Pharaoh's heart was stubborn, so he did not let the people go. 

# What will become fine dust over all the land of Egypt?

Ashes from a kiln will become fine dust over all the land of Egypt. 

# What will become fine dust over all the land of Egypt?

Ashes from a kiln will become fine dust over all the land of Egypt. 

# Why could the magicians not resist Moses?

The magicians could not resist Moses because of the blisters. 

# Why did Yahweh not reach out with his hand and attack Pharaoh and his people with disease and eradicate them from the land?

Yahweh did not attack Pharaoh and his people in order to show them His power, so that His name may be spread throughout all the earth. 

# Why did Yahweh not reach out with his hand and attack Pharaoh and his people with disease and eradicate them from the land?

Yahweh did not attack Pharaoh and his people in order to show them His power, so that His name may be spread throughout all the earth. 

# What warning did Yahweh give about the hail?

Yahweh said that every man and animal that is in the field and is not brought home—the hail will come down on them, and they will die. 

# Who brought their slaves and cattle into their houses?

Those of Pharaoh's servants who believed in Yahweh's message hurried to bring their slaves and cattle into the houses. 

# Throughout all the land of Egypt, what did the hail strike?

Throughout all the land of Egypt, the hail struck everything in the fields, both people and animals. It struck every plant in the fields and broke every tree. 

# During the hail, what did Pharaoh admit?

He said he has sinned this time. Yahweh is righteous, and he and his people are wicked. 

# What plants were not harmed by the hail? Why?

The wheat and the spelt were not harmed because they were later crops. 

# Why did Yahweh harden the hearts of Pharaoh and his servants?

Yahweh hardened the hearts of Pharaoh and his servants to show these signs of his power among them. He also did this so that the Israelites might tell their children and grandchildren the things he has done. 

# Why did Yahweh harden the hearts of Pharaoh and his servants?

Yahweh hardened the hearts of Pharaoh and his servants to show these signs of his power among them. He also did this so that the Israelites might tell their children and grandchildren the things he has done. 

# What animal will cover the surface of the ground so that no one will be able to see the earth?

Locusts will cover the surface of the ground so that no one will be able to see the earth. 

# What did Pharaoh say when Moses told him the Israelites will go with their young and with their old, with their sons and their daughters?

Pharaoh said, "No! Go, just the men among you,". 

# What did Pharaoh say when Moses told him the Israelites will go with their young and with their old, with their sons and their daughters?

Pharaoh said, "No! Go, just the men among you,". 

# What did Pharaoh say when Moses told him the Israelites will go with their young and with their old, with their sons and their daughters?

Pharaoh said, "No! Go, just the men among you,". 

# What brought the locusts?

The east wind brought the locusts. 

# What did Pharaoh say he has done against Yahweh?

Pharaoh said he has sinned against Yahweh, Moses' God. 

# How many locusts remained in all the territory of Egypt after Yahweh brought a very strong west wind?

Not a single locust remained in all the territory of Egypt after Yahweh brought a very strong west wind. 

# What happened to the Egyptians during the three days of darkness?

During the three days of darkness no one could see anyone else; no one left his home for three days. 

# After the darkness, what did Pharaoh say must remain behind when the Israelites go worship Yahweh?

Pharaoh said the flocks and herds must remain behind when the Israelites go worship Yahweh. 

# What did Pharaoh say would happen to Moses if Pharaoh would see his face again?

Pharaoh said on the day Moses see his face, Moses would die. 

# For what should every Israelite man and woman ask of his or her neighbor after the final plague?

Every Israelite man and woman should ask of his or her neighbor for jewels of silver, and jewels of gold after the final plague. 

# For what should every Israelite man and woman ask of his or her neighbor after the final plague?

Every Israelite man and woman should ask of his or her neighbor for jewels of silver, and jewels of gold after the final plague. 

# In the sight of whom was Moses was very impressive?

Moses was very impressive in the sight of Pharaoh's servants and the people of Egypt. 

# Which of the firstborns would die?

All the firstborns in the land of Egypt would die, from the firstborn of Pharaoh, who sits on his throne, to the firstborn of the slave girl who is behind the handmill grinding it, and to all the firstborn of the cattle. 

# When has there been such a great cry throughout all the land of Egypt like the one caused by the last plague?

There has never been such a great cry, nor ever will be again. 

# What must each Israelite family do on the tenth day of this first month?

On the tenth day of this month each family must take a lamb or young goat for themselves. 

# If the household is too small for a lamb, what should they do?

If the household is too small for a lamb, the man and his next door neighbor are to take lamb or young goat meat that will be enough for the number of the people. 

# When must the whole assembly of Israel kill these animals?

The whole assembly of Israel must kill these animals at twilight. 

# With what must the Israelites eat the lamb or goat?

They must eat it with bread made without yeast, along with bitter herbs. 

# What must the Israelites do if any of the lamb is left over?

They must not let any of it be left over until morning. They must burn whatever is left over in the morning. 

# What will happen when Yahweh sees the blood on the houses?

When Yahweh sees the blood, he will pass over them. 

# What must happen to whoever eats leavened bread from the first day until the seventh day?

Whoever eats leavened bread from the first day until the seventh day, that person must be cut off from Israel. 

# What is the only work the Israelites can do during the seven days of unleavened bread?

No work will be done on these days, except the cooking for everyone to eat. 

# When must the Israelites eat unleavened bread?

The Israelites must eat unleavened bread from twilight of the fourteenth day in the first month of the year, until twilight of the twenty-first day of the month. 

# Where should the Israelites apply the blood in the basin?

The Israelites should apply the blood in the basin to the top of the door frame and the two doorposts. 

# When will Yahweh pass over someone's door?

Yahweh will pass over someone's door when he sees the blood on the top of the doorframe and on the two doorposts. 

# When the Israelites' children ask them, 'What does this act of worship mean?' what must they say?

When the Israelites' children ask them, 'What does this act of worship mean?' then they must say, 'It is the sacrifice of Yahweh's Passover, because Yahweh passed over the Israelites' houses in Egypt when he attacked the Egyptians. He set our households free.' 

# When the Israelites' children ask them, 'What does this act of worship mean?' what must they say?

When the Israelites' children ask them, 'What does this act of worship mean?' then they must say, 'It is the sacrifice of Yahweh's Passover, because Yahweh passed over the Israelites' houses in Egypt when he attacked the Egyptians. He set our households free.' 

# Why was there was a great outcry in Egypt?

There was a great outcry in Egypt, for there was not a house where there was not someone dead. 

# For what did the Israelites ask the Egyptians?

The Israelites asked the Egyptians for jewels of silver, jewels of gold, and clothing. 

# Why was the bread without yeast?

The bread was without yeast because the Israelites had been driven out of Egypt and could not delay to prepare food. 

# How long had the Israelites been in Egypt?

They had been in Egypt 430 years. 

# Who may not share in eating the Passover?

No foreigner may share in eating the Passover. 

# If a foreigner lives with the Israelites and wants to observe the Passover for Yahweh, what must all his male relatives do?

If a foreigner lives with the Israelites and wants to observe the Passover for Yahweh, all his male relatives must be circumsized. 

# To whom does the firstborn belong?

The firstborn belongs to Yahweh. 

# In what month did the Israelites go out of Egypt?

The Israelites went out of Egypt in the month of Abib. 

# Why will this rescue become reminders for the Israelites on their hands, and reminders on their forehead?

This rescue will become reminders for the Israelites on their hands, and reminders on their forehead, so that Yahweh's Law may be in their speech. 

# With what must the Israelites buy back every firstborn donkey?

Every firstborn donkey the Israelites must buy back with a lamb. 

# Why did God not lead the Israelites by way of the land of the Philistines?

God did not lead them by way of the land of the Philistines. For God said, "Perhaps the people will change their minds when they experience war and will then return to Egypt. 

# What had Joseph made the Israelites solemnly swear?

Joseph had made the Israelites solemnly swear, "You must carry away my bones with you". 

# How did Yahweh go before the Israelites by night? Why?

By night he went in a pillar of fire to give them light. In this way they could travel by day and by night. 

# When the king of Egypt was told that the Israelites had fled, what happened to the minds of Pharaoh and his servants?

When the king of Egypt was told that the Israelites had fled, the minds of Pharaoh and his servants turned against the Israelites. 

# Where did the Egyptians overtake the Israelites?

The Egyptians overtook the Israelites camping by the sea beside Pi Hahiroth, before Baal Zephon. 

# What did the Israelites say would have been better than to die in the wilderness?

They said it would have been better for them to work for the Egyptians than to die in the wilderness. 

# Because Yahweh will fight for the Israelites, what will they have to do?

Yahweh will fight for the Israelites, and they will only have to stand still. 

# Why would the Egyptians go after the Israelites into the sea?

Yahweh would harden the Egyptians' hearts so they will go after the Israelites. 

# How did the cloud hinder the Egyptians, but help the Israelites?

The cloud was a dark cloud to the Egyptians, but it lit the night for the Israelites, so one side did not come near the other all night. 

# For how long did Yahweh drive the sea back by a strong east wind?

Yahweh drove the sea back by a strong east wind all that night. 

# When did Yahweh look down on the Egyptian army through the pillar of fire and cloud?

In the early morning hours, Yahweh looked down on the Egyptian army through the pillar of fire and cloud. 

# How many soldiers of Pharaoh's army survived crossing the sea?

No one survived crossing the sea. 

# What did Israel do when they saw the great power that Yahweh used against the Egyptians?

When Israel saw the great power that Yahweh used against the Egyptians, the people honored Yahweh, and they trusted in Yahweh and in his servant Moses. 

# Whom has Yahweh thrown into the sea?

Yahweh has thrown the horse and its rider into the sea. 

# How did the Egyptians go down into the depths?

They went down into the depths like a stone. 

# How were the waters piled up?

By the blast of Yahweh's nostrils, the waters were piled up. 

# In what has Yahweh led the people he rescued?

In his covenant loyalty Yahweh has led the people he has rescued. In his strength he has led them to the holy place where he lives. 

# What will the people do when they hear of Yahweh rescuing the Israelites?

The peoples will hear, and they will tremble. 

# Where will Yahweh bring the Israelites?

Yahweh will bring the Israelites and plant them on the mountain of his inheritance, the place Yahweh has made to live in. 

# Who played tambourines?

Miriam the prophetess and all the women played tambourines. 

# Why could the Israelites not drink the water at Marah?

The Israelites could not drink the water at Marah because it was bitter. 

# How did the bitter water at Marah become sweet?

Yahweh showed Moses a tree. Moses threw it into the water, and the water became sweet to drink. 

# Where is the wilderness of Sin?

The wilderness of Sin is between Elim and Sinai. 

# According to the Israelites, why did Moses bring them out into the wilderness?

They said Moses brought them out into this wilderness to kill their whole community with hunger. 

# Why will the people go out and gather a day's portion every day?

The people will go out and gather a day's portion every day so that Yahweh may test them to see whether or not they will walk in his law. 

# How will the Israelites know Yahweh has brought them out from the land of Egypt?

The Israelites will know Yahweh has brought them out from the land of Egypt when Yahweh gives them meat in the evening and bread in the morning to the full. 

# How will the Israelites know Yahweh has brought them out from the land of Egypt?

The Israelites will know Yahweh has brought them out from the land of Egypt when Yahweh gives them meat in the evening and bread in the morning to the full. 

# What appeared in the cloud?

Yahweh's glory appeared in the cloud. 

# What size was the bread that Yahweh has given the Israelites to eat?

The bread that Yahweh has given the Israelites to eat was a small round thing as thin as hoarfrost. 

# What size was the bread that Yahweh has given the Israelites to eat?

The bread that Yahweh has given the Israelites to eat was a small round thing as thin as hoarfrost. 

# When the Israelites measured the bread from Yahweh, how much did each person have?

When they measured it with an omer measure, those who had gathered much had nothing over, and those who had gathered little had no lack. Each person gathered enough to meet their need. 

# What happened to the bread from Yahweh that some of the Israelites left until morning?

The bread from Yahweh that some of the Israelites left until morning bred worms and became foul. 

# How much bread did the Israelites gather on the sixth day?

On the sixth day they gathered twice as much bread, two omers for each person. 

# What happened to the bread of Yahweh that was set aside until the seventh day?

The bread of Yahweh that was set aside until the seventh day did not become foul, nor was there any worm in it. 

# How much manna did the Israelites find on the seventh day?

When some of the people went out to gather manna on the seventh day, they found none. 

# What must each of the Israelites do on the seventh day?

Each of them must stay in his own place; no one must go out from his place on the seventh day. 

# What was manna?

Manna was white like coriander seed, and its taste was like wafers made with honey. 

# Why will an omer of manna be kept?

An omer of manna will be kept throughout the people's generations so that their descendants might see the bread with which Yahweh fed them in the wilderness. 

# Where will an omer of manna be kept?

An omer of manna will be kept in a pot and stored beside the covenant decrees in the ark. 

# Where will an omer of manna be kept?

An omer of manna will be kept in a pot and stored beside the covenant decrees in the ark. 

# For how long did the people of Israel eat manna?

The people of Israel ate manna forty years until they came to inhabited land. 

# Why did the people blame Moses for their situation?

There was no water for the people to drink. So the people blamed Moses for their situation. 

# Why did the people blame Moses for their situation?

There was no water for the people to drink. So the people blamed Moses for their situation. 

# What was Moses afraid the people would do to him?

Moses was afraid that the Israelites were ready to stone him. 

# What did Yahweh tell Moses to do to provide water for the people to drink?

Yahweh told Moses to strike the rock with his staff. Water would come out of the rock for the people to drink. 

# Where did Moses stand when the Amalek people attacked Israel?

Moses stood on top of the hill with the staff of God in his hand. 

# What happened while Moses was holding his hands up, and when he let his hands rest?

While Moses was holding his hands up, Israel was winning. When he let his hands rest, Amalek would begin to win. 

# How did Aaron and Hur help Moses hold his hands up?

Aaron and Hur took a stone and put it under him for him to sit on. At the same time, Aaron and Hur held his hands up, one person on one side of him, and the other person on the other side. 

# Why did Yahweh tell Moses write about the battle against the Amalek?

Yahweh told Moses to write about the battle in a book, because Yahweh will completely blot out the memory of Amalek from under the skies. 

# Who was Jethro?

Jethro was the priest of Midian, Moses' father-in-law. 

# What were the names of the two sons of Moses?

The sons of Moses were Gershom and Eliezer. 

# Where was Moses when Jethro brought his wife and sons?

Moses was camped in the wilderness at the mountain of God when Jethro brought Moses' sons and his wife to him. 

# How did Moses greet his father-in-law?

He bowed down, and kissed him. 

# Over what did Jethro rejoice?

Jethro rejoiced over all the good that Yahweh had done for Israel, in that he had rescued them from the Egyptians' power. 

# How did Jethro know that Yahweh was greater than all the gods?

Jethro knew that Yahweh was greater than all the gods, because when the Egyptians treated the Israelites arrogantly, God rescued his people. 

# Who ate the meal before God?

Aaron and all the elders of Israel came to eat a meal before God with Moses' father-in-law. 

# How long did the people stand around Moses as he sat down to judge the people?

The people stood around Moses from morning until evening . 

# Why did the people come to Moses?

The people came to Moses to ask for God's direction. When they had a dispute, they came to him. 

# Why did the people come to Moses?

The people came to Moses to ask for God's direction. When they had a dispute, they came to him. 

# Why did Jethro say that what Moses was doing was not good?

Jethro said that what Moses was doing was not very good because he would certainly wear out himself and the people who came to him, because the burden was too heavy for him. He could not do it himself alone. 

# Why did Jethro say that what Moses was doing was not good?

Jethro said that what Moses was doing was not very good because he would certainly wear out himself and the people who came to him, because the burden was too heavy for him. He could not do it himself alone. 

# What kind of men did Jethro tell Moses to choose to put over the people?

Jethro told Moses to choose capable men from all the people, men who honor God, men of truth who hate unjust gain. 

# What cases would the capable men judge?

The capable men would judge the people in all routine cases, but the difficult cases they would bring to Moses. As for all the small cases, they could judge those themselves. 

# When did the people of Israel come to the wilderness of Sinai?

In the third month after the people of Israel had gone out from the land of Egypt, on the same day, they came to the wilderness of Sinai. 

# What must the Israelites do if they want to be Yahweh's special possesssion?

The Israelites must obediently listen to Yahweh's voice and keep his covenant, then they would be his special possession from among all peoples. 

# Why did Yahweh come to the people in a thick cloud?

Yahweh came to them in a thick cloud so that the people might hear when he spoke with them and might also believe Moses forever. 

# How were the people to consecrate themselves?

They were to consecrate themselves by preparing for Yahweh's coming, and by washing their garments. 

# What would happen to anyone who touched the mountain?

Whoever touched the mountain would surely be put to death. 

# How were the people to put to death anyone who touched the mountain?

They were to stone or shoot the person who touched the mountain. 

# Why did the people tremble?

There was thunder and lightning bolts and a thick cloud on the mountain, and the sound of a very loud trumpet. So, all the people in the camp trembled. 

# What should the priests do so Yahweh would not attack them?

The priests who come near to Yahweh should set themselves apart—prepare themselves for Yahweh's coming—so that Yahweh would not attack them. 

# Who could come up the mountain with Moses?

Only Aaron could come up the mountain with Moses. 

# What must the Israelites not have before Yahweh?

They must have no other gods before him. 

# Why must the Israelites not make carved figures or bow down to them?

The Israelties must not make carved figures or bow down to them because Yahweh is a jealous God. 

# Why must the Israelites not make carved figures or bow down to them?

The Israelties must not make carved figures or bow down to them because Yahweh is a jealous God. 

# For how long does Yahweh punish the ancestors' wickedness?

Yahweh punishes the ancestors' wickedness by bringing punishment on their descendants, to the third and the fourth generation of those who hate him. 

# Whose name must the Isralites not take in vain?

They must not take the name of Yahweh their God in vain. 

# Why must the Israelites keep the Sabbath day holy and rest on it?

The Israelites must keep the Sabbath day holy and rest on it, for in six days Yahweh, made the heavens, earth, and sea, and everything that is in them, and then rested on the seventh day. 

# Who should keep the Sabbath day holy and rest on it?

The Israelites must not do any work, you, nor their son, nor their daughter, nor their male servant, nor their female servant, nor their cattle, nor the foreigner who is within their gates. 

# Why must the Israelites keep the Sabbath day holy and rest on it?

The Israelites must keep the Sabbath day holy and rest on it, for in six days Yahweh, made the heavens, earth, and sea, and everything that is in them, and then rested on the seventh day. 

# What is the result of the Israelites' honoring their father and mother?

The Israelites must honor their father and your mother, so that they might live a long time in the land which Yahweh their God was giving them. 

# Why did the people tremble?

All the people saw the thundering and the lightning, and heard the voice of the trumpet, and saw the mountain smoking. When the people saw it, they trembled and stood far off. 

# What did the Israelites think would happen if God spoke to them?

They thought that if God spoke to them, they would die. 

# What would have happened if the Israelites used their tools on the stone altar?

If they used their tools on the stone altar, they would defile it. 

# Who must set the decrees before the Israelites?

Moses must set the decrees before the Israelites. 

# If a master gave a servant a wife and she bore him sons or daughters, what would happen to them if the servant went free?

If a master gave a servant a wife and she bore him sons or daughters, the wife and her children would belong to her master, and he must go free by himself 

# If the servant would not go free, what would happen?

If the servant would not go free, the master must bring him to a door or doorpost, and his master must bore his ear through with an awl. Then the servant would serve him for the rest of his life. 

# To whom can a master not sell a female servant?

A master has no right to sell a female servant to a foreign people. 

# When can a female servant go free without paying money?

If a master's son marries a female servant and then takes another wife for himself, he can not diminish her food, clothing, or her marital rights. But if he does not provide these three things for her, then she can go free without paying any money. 

# When can a female servant go free without paying money?

If a master's son marries a female servant and then takes another wife for himself, he can not diminish her food, clothing, or her marital rights. But if he does not provide these three things for her, then she can go free without paying any money. 

# When can a female servant go free without paying money?

If a master's son marries a female servant and then takes another wife for himself, he can not diminish her food, clothing, or her marital rights. But if he does not provide these three things for her, then she can go free without paying any money. 

# What did Yahweh provide for a man who killed someone by accident?

If the man killed someone by accident, Yahweh would fix a place where he could flee. 

# What must happen to whoever curses his father or his mother?

Whoever curses his father or his mother must surely be put to death. 

# If men fight and one hits the other with a stone or with his fist and the other is confined to his bed, what must the man who struck him do?

If men fight and one hits the other with a stone or with his fist and the other is confined to his bed, the man who struck him must pay for the loss of his time. 

# If men fight and one hits the other with a stone or with his fist and the other is confined to his bed, what must the man who struck him do?

If men fight and one hits the other with a stone or with his fist and the other is confined to his bed, the man who struck him must pay for the loss of his time. 

# If a man hits his male servant or his female servant with a staff, and if the servant lives for a day or two, how will the the master be punished?

If a man hits his male servant or his female servant with a staff, and if the servant lives for a day or two, the master must not be punished, for he will have suffered the loss of the servant.. 

# If a man hits his male servant or his female servant with a staff, and if the servant lives for a day or two, how will the the master be punished?

If a man hits his male servant or his female servant with a staff, and if the servant lives for a day or two, the master must not be punished, for he will have suffered the loss of the servant.. 

# If men fight together and hurt a pregnant woman so that she miscarries, but there is no other injury to her, what must happen to the guilty man?

If men fight together and hurt a pregnant woman so that she miscarries, but there is no other injury to her, then the guilty man must surely be fined, if the woman's husband demands it from him, and he must pay as the judges determine. 

# What must the guilty man give if there is serious injury?

If there is serious injury, then the guilty man must give a life for a life, an eye for an eye, a tooth for a tooth, a hand for a hand, a foot for a foot, a burn for a burn, a wound for a wound, or a bruise for a bruise. 

# What must the guilty man give if there is serious injury?

If there is serious injury, then the guilty man must give a life for a life, an eye for an eye, a tooth for a tooth, a hand for a hand, a foot for a foot, a burn for a burn, a wound for a wound, or a bruise for a bruise. 

# What must the guilty man give if there is serious injury?

If there is serious injury, then the guilty man must give a life for a life, an eye for an eye, a tooth for a tooth, a hand for a hand, a foot for a foot, a burn for a burn, a wound for a wound, or a bruise for a bruise. 

# If a man hits the eye of his male servant or of his female servant and destroys it, or if he knocks out a tooth of his male servant or female servant, what is the compensation?

If a man hits the eye of his male servant or of his female servant and destroys it, or if he knocks out a tooth of his male servant or female servant, he must let the servant go free as compensation for the tooth. 

# If a man hits the eye of his male servant or of his female servant and destroys it, or if he knocks out a tooth of his male servant or female servant, what is the compensation?

If a man hits the eye of his male servant or of his female servant and destroys it, or if he knocks out a tooth of his male servant or female servant, he must let the servant go free as compensation for the tooth. 

# If an ox had a habit of goring in the past, and its owner was warned but did not keep it in, and the ox kills a man or a woman, what must happen to the ox and its owner?

If an ox had a habit of goring in the past, and its owner was warned but did not keep it in, and the ox kills a man or a woman, that ox must be stoned, and its owner also must be put to death. 

# If a man opens a pit, or if a man digs a pit and does not cover it, and an ox or a donkey falls into it, what must the owner of the pit do?

If a man opens a pit, or if a man digs a pit and does not cover it, and an ox or a donkey falls into it, the owner of the pit must repay the loss. 

# If a man opens a pit, or if a man digs a pit and does not cover it, and an ox or a donkey falls into it, what must the owner of the pit do?

If a man opens a pit, or if a man digs a pit and does not cover it, and an ox or a donkey falls into it, the owner of the pit must repay the loss. 

# If one man's ox hurts another man's ox so that it dies, what must happen to the oxen?

If one man's ox hurts another man's ox so that it dies, then they must sell the live ox and divide its price, and they must also divide the dead ox. 

# If someone kills a thief after the sun has risen, who is guilty?

If the sun has risen before a thief breaks in, guilt for murder will attach to the person who kills him. 

# If someone kills a thief after the sun has risen, who is guilty?

If the sun has risen before a thief breaks in, guilt for murder will attach to the person who kills him. 

# If a thief has nothing, what is his restitution?

If a thief has nothing, then he must be sold for his theft. 

# If a man gives money or goods to his neighbor for safe keeping, and if it is stolen out of the man's house, but the thief is not found, what will happen?

If a man gives money or goods to his neighbor for safe keeping, and if it is stolen out of the man's house, if the thief is found, that thief must pay double. But if the thief is not found, then the owner of the house must come before the judges to see whether he has put his own hand on his neighbor's property. 

# If a man gives money or goods to his neighbor for safe keeping, and if it is stolen out of the man's house, but the thief is not found, what will happen?

If a man gives money or goods to his neighbor for safe keeping, and if it is stolen out of the man's house, if the thief is found, that thief must pay double. But if the thief is not found, then the owner of the house must come before the judges to see whether he has put his own hand on his neighbor's property. 

# If a man gives his neighbor a donkey, an ox, a sheep, or any animal to keep, and if it dies or is hurt or is carried away without anyone seeing it, what is the restitution?

If a man gives his neighbor a donkey, an ox, a sheep, or any animal to keep, and if it dies or is hurt or is carried away without anyone seeing it, the other will make no restitution. 

# If a man gives his neighbor a donkey, an ox, a sheep, or any animal to keep, and if it dies or is hurt or is carried away without anyone seeing it, what is the restitution?

If a man gives his neighbor a donkey, an ox, a sheep, or any animal to keep, and if it dies or is hurt or is carried away without anyone seeing it, the other will make no restitution. 

# If a man seduces a virgin who is not engaged, and if he sleeps with her, how must he make her his wife?

If a man seduces a virgin who is not engaged, and if he sleeps with her, he must surely make her his wife by paying the bride wealth required for this. 

# Why must the Israelites not wrong a foreigner?

The Israelites must not wrong a foreigner or oppress him, for they were foreigners in the land of Egypt. 

# What would happen if the Israelites mistreat any widow or fatherless child?

If the Israelites mistreats them at all, and if they cry out to Yahweh, he will surely hear their cry. His anger will burn, and he will kill them with the sword; their wives will become widows, and their children will become fatherless. 

# What would happen if the Israelites mistreat any widow or fatherless child?

If the Israelites mistreats them at all, and if they cry out to Yahweh, he will surely hear their cry. His anger will burn, and he will kill them with the sword; their wives will become widows, and their children will become fatherless. 

# What would happen if the Israelites mistreat any widow or fatherless child?

If the Israelites mistreats them at all, and if they cry out to Yahweh, he will surely hear their cry. His anger will burn, and he will kill them with the sword; their wives will become widows, and their children will become fatherless. 

# If someone takes his neighbor's garment in pledge, when must he return it to the owner?

If someone takes his neighbor's garment in pledge, he must return it to him before the sun goes down. 

# What meat must the Israelites not eat? What should they do with it?

The Israelites must not eat any meat that was torn by animals in the field. Instead, they must throw it to the dogs. 

# If the Israelites see the donkey of someone who hates them fallen to the ground under its load, what must they do?

If the Israelites see the donkey of someone who hates them fallen to the ground under its load, they must not leave that person. They must surely help him with his donkey. 

# Why should the Israelites not take a bribe?

They should not take a bribe, for a bribe blinds those who see, and perverts honest people's words. 

# Why should the Israelites leave their fields unplowed in the seventh year?

In the seventh year the Isralites should leave the fields unplowed and fallow, so that the poor among their people may eat. 

# Why must the Israelites rest on the seventh day?

On the seventh day they must rest so that their ox and their donkey may have rest, and so that their female slave's son and any foreigner may rest and be refreshed. 

# In what month was the Festival of Unleavened Bread to be observed?

The Festival of Unleavened Bread was to be observed in the month of Abib. 

# In what month did the Israelites come out of Egypt?

They came out of Egypt in the month of Abib. 

# When were the Festival of Harvest and the Festival of Ingathering to be observed?

You must observe the Festival of Harvest, with the first fruits of your labors when you sowed seed in the fields. Also you must observe the Festival of Ingathering at the end of the year, when you gather in your produce from the fields. 

# For how long can the fat from the sacrifices at Yahweh's festivals remain?

The fat from the sacrifices at Yahweh's festivals must not remain all night until the morning. 

# What would happen if the Israelites provoke Yahweh's angel?

If they provoke him, he will not pardon their transgressions. 

# What must the Israelites do to foreign gods?

They must completely overthrow them and smash their sacred stone pillars in pieces. 

# Why wouldn't Yahweh drive out the foreign nations before the Israelites in one year?

Yahweh would not drive them out in one year, or the land would become abandoned, and the wild animals would become too many for them. 

# Why must foreign nations not live in the Israelites' land?

They must not live in the Israelites' land, or they would make the Israelites sin against Yahweh. 

# How many elders should come up to worship Yahweh at a distance?

70 elders should come up to worship Yahweh at a distance. 

# What would the twelve stones represent?

The twelve stones would represent the twelve tribes of Israel. 

# Where did Moses put the blood of the oxen from the fellowship offerings to Yahweh?

Moses took half of the blood of the oxen from the fellowship offerings to Yahweh and put it into basins; he splashed the other half onto the altar. 

# Where did Moses put the blood of the oxen from the fellowship offerings to Yahweh?

Moses took half of the blood of the oxen from the fellowship offerings to Yahweh and put it into basins; he splashed the other half onto the altar. 

# How did Yahweh make a covenant with the Israelites?

Yahweh made the covenant with the Israelites by giving them the promise with all the words. 

# Who saw Yahweh?

Moses, Aaron, Nadab, Abihu, and seventy of Israel's elders saw Yahweh. 

# Who saw Yahweh?

Moses, Aaron, Nadab, Abihu, and seventy of Israel's elders saw Yahweh. 

# Why did Yahweh give Moses the tablets of stone and the law and commandments?

Yahweh gave Moses the tablets of stone and the law and commandments that he had written, so that Moses might teach them. 

# If anyone had a dispute, to whom should he go?

If anyone had a dispute, he should go to Aaron and Hur. 

# What was the appearance of Yahweh's glory like?

The appearance of Yahweh's glory was like a devouring fire on the top of the mountain in the eyes of the Israelites. 

# From whom should the Israelites take an offering?

The Israelites should take an offering from every person who is motivated by a willing heart. 

# For what were the onyx stones and other precious stones to be set?

The onyx stones and other precious stones were to be set for the ephod and breast piece. 

# Why would the Israelites make Yahweh a sanctuary?

The Israelites would make Yahweh a sanctuary so that he might live among them. 

# With what must Moses cover the acacia wood?

He must cover it inside and out with pure gold. 

# With what must Moses cover the acacia wood?

He must cover it inside and out with pure gold. 

# Into what must Moses put the poles? Why?

He must put the poles into the rings on the ark's sides, in order to carry the ark. 

# Where must the poles remain?

The poles must remain in the rings of the ark. They must not be taken from it. 

# Which direction must the cherubim face?

The cherubim must face one another and look toward the center of the atonement lid. 

# From where would Yahweh speak to Moses?

Yahweh would speak with him from above the atonement lid, from between the two cherubim over the ark of the covenant decrees 

# What border must Moses put around the top of the table of acacia wood?

He must put a border of gold around the top of the table of acacia wood. 

# What border must Moses put around the top of the table of acacia wood?

He must put a border of gold around the top of the table of acacia wood. 

# Why must the rings be attached to the frame?

The rings must be attached to the frame to provide places for the poles, in order to carry the table. 

# What was to be used to pour out drink offerings?

The dishes, spoons, pitchers, and bowls were to be used to pour out drink offerings. 

# How many branches must extend out from the sides of the lampstand of pure hammered gold?

Six branches must extend out from its sides—three branches must extend from one side, and three branches of the lampstand must extend from the other side. 

# How many branches must extend out from the sides of the lampstand of pure hammered gold?

Six branches must extend out from its sides—three branches must extend from one side, and three branches of the lampstand must extend from the other side. 

# On which part of the lampstand must there be four cups made like almond blossoms?

On the lampstand itself, the central shaft, there must be four cups made like almond blossoms. 

# On which part of the lampstand must there be four cups made like almond blossoms?

On the lampstand itself, the central shaft, there must be four cups made like almond blossoms. 

# What must be under each pair of branches?

There must be a leafy base under each pair of branches. 

# How much gold should Moses use to make the lampstand and its accessories?

He must use one talent of pure gold to make the lampstand and its accessories. 

# Who would Moses have to make the tabernacle with ten curtains made from fine linen and blue, purple, and scarlet wool with the designs of cherubim?

Moses must have a very skilled craftsman make the tabernacle with ten curtains made from fine linen and blue, purple, and scarlet wool with the designs of cherubim. 

# Why must Moses make fifty loops on the first curtain and fifty loops on the end curtain in the second set?

He must make fifty loops on the first curtain and fifty loops on the end curtain in the second set so that the loops will be opposite to each other. 

# Of what must Moses make curtains for a tentlike covering over the tabernacle?

He must make curtains of goats' hair for a tentlike covering over the tabernacle. 

# Where must the overhanging part remaining from the tent's curtains hang?

The overhanging part remaining from the tent's curtains must hang at the back of the tabernacle. 

# What must be in each board for joining them to each other?

There must be two projections in each board for joining the boards to each other. 

# Why must there be two bases under each board?

There must be two bases under each board to be its two pedestals. 

# How must Moses set up the tabernacle?

He must set up the tabernacle by following the plan God showed him on the mountain. 

# What is the purpose of the curtain?

The curtain is to separate the holy place from the most holy place. 

# On what side of the tabernacle is the lampstand?

The lampstand is opposite the table on the south side of the tabernacle. 

# How must Moses make extensions of the altar's four corners?

He must make extensions of its four corners shaped like ox horns. 

# With what must Moses make all the utensils for the altar?

He must make all the utensils with bronze. 

# What kind of hangings must be on the south side of the courtyard?

There must be hangings of fine twined linen one hundred cubits long on the south side of the courtyard. 

# Of what must all the equipment to be used in the tabernacle, and all the tent pegs for the tabernacle and courtyard be made?

All the equipment to be used in the tabernacle, and all the tent pegs for the tabernacle and courtyard must be made of bronze. 

# What would be a lasting ordinance forever throughout the generations of the Israelite nation?

Aaron and his sons must maintain the lamps from evening to morning before Yahweh. This requirement would be a lasting ordinance forever throughout the generations of the Israelite nation. 

# Who would serve Yahweh as priests?

Aaron and his sons—Nadab, Abihu, Eleazar, and Ithamar—would serve Yahweh as priests. 

# What material must craftsmen use for the priests' clothing?

Craftsmen must use fine linen that is gold, blue, purple, and scarlet. 

# What must be engraved on two onyx stones?

The names of Israel's twelve sons must be engraved on two onyx stones. 

# In what order must the names of Israel's twelve sons be on the two onyx stones?

The names of Israel's twelve sons must be on the two onyx stones in order of the sons' births. 

# Why would Aaron carry the names of the Israel's twelve sons on his two shoulders?

Aaron would carry their names on his two shoulders as a reminder to Yahweh. 

# What shape must the breastpiece for decision making be?

The breastpiece for decision making must be square. 

# What shape must the breastpiece for decision making be?

The breastpiece for decision making must be square. 

# How must the precious stones be mounted?

They must be mounted in gold settings. 

# How must the precious stones be mounted?

They must be mounted in gold settings. 

# Where must Moses attach the two golden chains?

He must attach the two golden chains to the two corners of the breastpiece. 

# Why must Moses tie the breastpiece by its rings to the ephod's rings?

He must tie the breastpiece by its rings to the ephod's rings so that the breastplate might not become unattached from the ephod. 

# What must Moses put in the breastpiece for decision making?

He must put in the breastpiece for decision making the Urim and the Thummim. 

# Who must make the robe of the ephod?

A weaver must make the robe of the ephod. 

# Who must make the robe of the ephod?

A weaver must make the robe of the ephod. 

# Why is the robe to be on Aaron when he serves?

The robe is to be on Aaron when he serves, so that its sound can be heard when he goes into the holy place before Yahweh and when he leaves. This is so that he does not die. 

# How would Aaron bear any guilt that might attach to the offering of the holy gifts that the Israelites consecrated?

He would bear any guilt that might attach to the offering of the holy gifts that the Israelites consecrated by wearing the engraved plate on his turban. 

# How would Aaron bear any guilt that might attach to the offering of the holy gifts that the Israelites consecrated?

He would bear any guilt that might attach to the offering of the holy gifts that the Israelites consecrated by wearing the engraved plate on his turban. 

# How would Aaron bear any guilt that might attach to the offering of the holy gifts that the Israelites consecrated?

He would bear any guilt that might attach to the offering of the holy gifts that the Israelites consecrated by wearing the engraved plate on his turban. 

# What must Moses make for the honor and splendor of Aaron's sons?

He must make coats, sashes, and headbands for the honor and splendor of Aaron's sons. 

# How much would the undergarments cover?

The undergarments would cover from the waist to the thighs. 

# What must be brought to dedicate Aaron and his sons?

The following were to be brought to dedicate Aaron and his sons: One young bull and two rams without blemish, bread without yeast, and cakes without yeast mixed with oil, and wafers made with fine wheat flour without yeast rubbed with oil. 

# What must be brought to dedicate Aaron and his sons?

The following were to be brought to dedicate Aaron and his sons: One young bull and two rams without blemish, bread without yeast, and cakes without yeast mixed with oil, and wafers made with fine wheat flour without yeast rubbed with oil. 

# In what must Moses wash Aaron and his sons?

Moses must wash Aaron and his sons in water. 

# To whom would the work of the priesthood belong?

The work of the priesthood would belong to Aaron and his sons. 

# What must Moses do with the fat and the covering of the liver and the two kidneys?

He must burn the fat that covers the inner parts, and the covering of the liver and the two kidneys with the fat that is on them, on the altar. 

# What would a burning ram produce for Yahweh?

It would produce a sweet aroma for Yahweh. 

# What must Moses do with blood from the second ram?

He must put it on the tip of Aaron's right ear, and on the tip of his sons' right ears, on the thumb of their right hands, and on the great toe of their right feet. Then he must splash against the altar on every side. 

# What was Moses to splash on Aaron, his garments, Aaron's sons and their garments?

Moses was to splash some of the blood from the altar and some of the anointing oil on Aaron, his sons and their garments. 

# What was the ram for?

The ram was for the priest's consecration to Yahweh. 

# What must forever belong to Aaron and his descendants?

The breast of the offering that is raised high and the thigh of the offering that is presented must forever belong to Aaron and his descendants. 

# What must forever belong to Aaron and his descendants?

The breast of the offering that is raised high and the thigh of the offering that is presented must forever belong to Aaron and his descendants. 

# What must forever belong to Aaron and his descendants?

The breast of the offering that is raised high and the thigh of the offering that is presented must forever belong to Aaron and his descendants. 

# From among whom would the next priest come?

The next priest would come from among Aaron's sons. 

# How must the ram for the consecration be cooked?

The ram for the consecration must be boiled in a holy place. 

# After the altar is consecrated, what happens to anything that touches it?

Whatever touches the altar will be the holy, the same as the altar. 

# When must Moses offer each of the lambs?

He must offer one lamb in the morning, and the other lamb about sundown. 

# What must be offered with the first lamb?

With the first lamb a tenth of an ephah of fine flour mixed with the fourth part of a hin of oil from pressed olives, and the fourth part of a hin of wine as a drink offering, must be offered. 

# Where were the lambs to be offered?

The lambs had to be offered at the entrance to the tent of meeting before Yahweh. 

# Where would Yahweh live?

Yahweh would live among the Israelites and be their God. 

# What is the purpose of the rings?

The rings must be holders for poles to carry the altar. 

# Where must Moses put the incense altar?

Moses must put the incense altar before the curtain that is by the ark of the covenant decree. 

# What is the only incense that can be burned on the incense altar?

When Aaron lights the lamps again in the evening, he must burn incense on the incense altar. But no other incense must be offered on the incense altar. 

# What is the only incense that can be burned on the incense altar?

When Aaron lights the lamps again in the evening, he must burn incense on the incense altar. But no other incense must be offered on the incense altar. 

# How often must Aaron make atonement on the horns of the incense altar?

Aaron must make atonement on the horns of the incense altar once a year. 

# Why must each person give a ransom for his life to Yahweh?

Each person must give a ransom for his life to Yahweh, so that there would be no plague among them when Moses counted them. 

# After Moses received the atonement money from the Israelites, how must he allocate it?

After Moses received the atonement money from the Israelites, he must allocate it to the work of the tent of meeting. 

# Where must Moses put the large bronze basin?

Moses must put it between the tent of meeting and the altar. 

# What must Aaron and his sons do when they go into the tent of meeting or when they go near to the altar to serve Yahweh by burning an offering?

When they go into the tent of meeting or when they go near to the altar to serve Yahweh by burning an offering, they must wash with water. 

# What are the ingredients in holy anointing oil?

The ingredients in holy anointing oil are five hundred shekels of flowing myrrh, 250 shekels of sweet-smelling cinnamon, 250 shekels of sweet-smelling cane, five hundred shekels of cassia, measured by the weight of the shekel of the sanctuary, and one hin of olive oil. 

# What are the ingredients in holy anointing oil?

The ingredients in holy anointing oil are five hundred shekels of flowing myrrh, 250 shekels of sweet-smelling cinnamon, 250 shekels of sweet-smelling cane, five hundred shekels of cassia, measured by the weight of the shekel of the sanctuary, and one hin of olive oil. 

# What are the ingredients in holy anointing oil?

The ingredients in holy anointing oil are five hundred shekels of flowing myrrh, 250 shekels of sweet-smelling cinnamon, 250 shekels of sweet-smelling cane, five hundred shekels of cassia, measured by the weight of the shekel of the sanctuary, and one hin of olive oil. 

# What must not be done with the holy anointing oil?

It must not be applied to people's skin, nor must any oil like it with the same formula be made because it is consecrated. 

# What must happen to the person who makes anything like the incense or holy anointing oil to use as a perfume?

Whoever makes anything like it to use as a perfume must be cut off from his people. 

# What must happen to the person who makes anything like the incense or holy anointing oil to use as a perfume?

Whoever makes anything like it to use as a perfume must be cut off from his people. 

# What abilities would Bezabel have because Yahweh filled him with his spirit?

Yahweh filled Bezalel with his spirit to give him wisdom, understanding, and knowledge, for all kinds of craftsmanship, to make artistic designs and to work in gold, silver, and bronze; also to cut and set stones and to carve wood—to do all kinds of craftsmanship. 

# What abilities would Bezabel have because Yahweh filled him with his spirit?

Yahweh filled Bezalel with his spirit to give him wisdom, understanding, and knowledge, for all kinds of craftsmanship, to make artistic designs and to work in gold, silver, and bronze; also to cut and set stones and to carve wood—to do all kinds of craftsmanship. 

# What abilities would Bezabel have because Yahweh filled him with his spirit?

Yahweh filled Bezalel with his spirit to give him wisdom, understanding, and knowledge, for all kinds of craftsmanship, to make artistic designs and to work in gold, silver, and bronze; also to cut and set stones and to carve wood—to do all kinds of craftsmanship. 

# Why did Yahweh put skill into the hearts of all who were wise?

Yahweh put skill into the hearts of all who were wise so that they may make all that he commanded them. 

# What would happen to anyone who defiled or worked on the Sabbath?

Everyone who defiled the Sabbath must surely be put to death. Anyone who worked on the Sabbath must surely be cut off from his people. 

# Why would the Sabbath always be a sign between Yahweh and the Israelites?

The Sabbath would always be a sign between Yahweh and the Israelites, for in six days Yahweh made heaven and earth, and on the seventh day he rested and was refreshed. 

# Who wrote the on two tablets of covenant decrees?

Yahweh gave Moses two tablets of covenant decrees, written on by Yahweh's own hand. 

# When did the people gather around Aaron and ask him to make an idol?

When the people saw that Moses delayed in coming down the mountain, they gathered around Aaron and asked him to make an idol. 

# Who received the gold from the people, fashioned it in a mold, and made it into a molded calf?

Aaron received the gold from them, fashioned it in a mold, and made it into a molded calf. 

# After the people offered burnt offerings and brought fellowship offerings, what did they do?

After the people offered burnt offerings and brought fellowship offerings, they sat down to eat and to drink, and then got up to carouse in wild celebration. 

# What did the people say was the god who brought them up out of the land of Egypt?

The people said the golden calf was the god who brought them up out of the land of Egypt. 

# After Yahweh became angry, what did Moses do?

Moses tried to calm down Yahweh his God. 

# From what did Yahweh relent?

Yahweh relented from the punishment that he had said he would inflict on his people. 

# On which parts of the tablets did Yahweh write?

The tablets were written on both their sides, on both the front and the back. 

# When Joshua heard the noise of the people as they shouted, what did he think was the problem?

When Joshua heard the noise of the people as they shouted, he thought there was the noise of combat in the camp. 

# After Moses saw the calf, what did he do to the tablets?

He threw the tablets out of his hands and broke them at the bottom of the mountain. 

# What did Moses do to the calf?

Moses took the calf that the people had made, burned it, ground it to powder, and poured it into the water. Then he made the people of Israel drink it. 

# According to Aaron, how was the calf made?

According to Aaron, the people gave him gold and he threw it into the fire, and out came the calf. 

# Who had let the people get out of control?

Aaron had let them get out of control. 

# Who gathered around Moses when he commanded everyone on Yahweh's side to come to him?

When Moses commanded everyone on Yahweh's side to come to him, all the Levites gathered around him. 

# What did the Levites do?

The Levites did what Moses ordered and about three thousand men  out of the people died. 

# Why were the Levites placed into Yahweh's service?

They were placed into Yahweh's service, for each of them acted against his brother. 

# What did Moses want Yahweh to do if Yahweh would not forgive the people's sin?

Moses wanted Yahweh to blot him out of the book Yahweh had written if Yahweh would not forgive the people's sin. 

# How did Yahweh punish the people because they had made the calf?

Yahweh sent a plague on the people because they had made the calf. 

# What did Yahweh say he would send before Moses?

Yahweh would send an angel before Moses. 

# Why would Yahweh not go up with Moses?

Yahweh would not go up with him, because they were a stubborn people. Yahweh might destroy them on the way. 

# What did Yahweh command the Israelites to take off?

They must take off their jewelry. 

# What would happen whenever Moses entered the tent of meeting?

Whenever Moses entered the tent of meeting, the pillar of cloud would come down and stand at the tent entrance, and Yahweh would speak with Moses. 

# How would Yahweh speak to Moses?

Yahweh would speak to Moses face to face, as a man speaks to his friend. 

# What did Moses want Yahweh to show him? Why?

Moses wanted Yahweh to show him his ways so that Moses might know him and continue to find favor in his sight. 

# How would it be known that Moses found favor in Yahweh's sight?

It would be known that Moses found favor in Yahweh's sight if Yahweh went with them so that they were different from all the other peoples that were on the surface of the earth. 

# Who did Yahweh say he would be gracious and merciful to?

Yahweh said he would be gracious to whom he would be gracious and that he would show mercy on whom he would show mercy. 

# Why could Moses not see Yahweh's face?

Moses could not see Yahweh's face, for no one could see him and live. 

# When Yahweh would take away his hand, what would Moses see?

When Yahweh would take away his hand, Moses would see his back, but Yahweh's face would not be seen. 

# What would Yahweh write on the new tablets?

Yahweh would write on the new tablets the words that were on the first tablets, the tablets that Moses broke. 

# Who was allowed anywhere on the mountain?

No one besides Moses was allowed anywhere on the mountain. 

# When Yahweh came down in the cloud and stood with Moses, what did he pronounce?

When Yahweh came down in the cloud and stood with Moses, he pronounced the name "Yahweh". 

# Would Yahweh clear the guilty?

Yahweh would by no means clear the guilty. 

# What was Yahweh about to make?

Yahweh was about to make a covenant. 

# What would happen if the Israelites made a covenant with the inhabitants of the land where they were going?

If they made a covenant with the inhabitants of the land where they were going, the inhabitants would become a trap among the Israelites. 

# Why must the Israelites worship no other god?

They must worship no other god, for Yahweh, whose name is 'Jealous,' is a jealous God. 

# What would happen if the Israelites ate some of the sacrifices of the inhabitants of the land?

If the Israelites ate some of the sacrifices of the inhabitants of the land, they would even take some of their daughters for their sons, and their daughters would commit adultery and go after their own gods, and they would make their sons commit adultery and go after their gods. 

# What would happen if the Israelites ate some of the sacrifices of the inhabitants of the land?

If the Israelites ate some of the sacrifices of the inhabitants of the land, they would even take some of their daughters for their sons, and their daughters would commit adultery and go after their own gods, and they would make their sons commit adultery and go after their gods. 

# Why must the Israelites eat bread without yeast for seven days at the fixed time in the month of Abib?

The Israelites must eat bread without yeast for seven days at the fixed time in the month of Abib, for it was in the month of Abib that the Israelites came out from Egypt. 

# What must happen if the Israelites did not buy back the firstborn of a donkey with a lamb?

If the Israelites did not buy back the firstborn of a donkey with a lamb, then they must break its neck. 

# What must the Israelites do on the seventh day, even at plowing time and in harvest?

On the seventh day, the Israelites must rest. Even at plowing time and in harvest, they must rest. 

# How often must all the men appear before Yahweh?

All the men must appear before Yahweh three times every year. 

# Who would desire to invade the land and take it when the Israelites went up to appear before Yahweh three times every year?

No one would desire to invade the land and take it when the Israelites went up to appear before Yahweh three times every year. 

# What must the Israelites bring to Yahweh's house?

They must bring the best of the first fruits from their fields to Yahweh's house. 

# What did Moses not do when he was with Yahweh for forty days and nights?

When Moses was with Yahweh for forty days and nights; he did not eat any food nor drink any water. 

# When Aaron and the Israelites saw Moses, why were they afraid to come near him?

When Aaron and the Israelites saw Moses, the skin of his face was shining, and they were afraid to come near him. 

# When Moses finished speaking with them, what did he put over his face?

When Moses finished speaking with them, he put a veil over his face. 

# When did Moses remove the veil?

Whenever Moses went before Yahweh to speak with him, he would remove the veil. 

# When must the Israelites not light a fire?

They must not light a fire in any of their homes on the Sabbath day. 

# Who should take an offering for Yahweh?

All who have a willing heart should take an offering for Yahweh. 

# Where did all the tribes of Israel go?

All the tribes of Israel left and went away from Moses's presence. 

# Who came and brought an offering to Yahweh for the construction of the tabernacle?

Everyone whose heart stirred him up and whom his spirit made willing came and brought an offering to Yahweh for the construction of the tabernacle. 

# What were to be set into the ephod and the breastpiece?

Onyx stones and other gems were to be set into the ephod and the breastpiece. 

# On whom did Yahweh call by name?

Yahweh called by name on Bezalel, son of Uri, son of Hur, from the tribe of Judah. 

# Who would do the work of building the sanctuary?

Bezalel and Oholiab would work, as well as every wise hearted person in whom Yahweh put skill and understanding to know how to build the sanctuary. 

# What were the people still doing?

The people were still bringing freewill offerings every morning to Moses. 

# What did Moses instruct the people to do?

Moses instructed that no one in the camp should bring any more offerings for the construction of the sanctuary. 

# Where did Bezalel make loops?

He made loops of blue along the outer edge of the end curtain of one set, and he did the same along the outer edge of the end curtain in the second set. 

# How did Bezalel join the curtains together?

He made fifty gold clasps and joined the curtains together with them. 

# Why did Bezalel make fifty bronze clasps?

Bezalel made fifty bronze clasps to join the tentlike covering together so that it might be one. 

# How many bases were under each of the boards?

There were two bases under each of the boards. 

# Where did Bezalel make the crossbar?

He made the crossbar in the center of the boards, that is, halfway up, to reach from end to end. 

# With what did Bezalel cover the hanging's five pillars?

Bezalel covered the hanging's five pillars with gold. 

# Of what material did Bezalel make the ark?

Bezalel made the ark of acacia wood. 

# Why did Bezalel put the poles into the rings on the ark's sides?

He put the poles into the rings on the ark's sides in order to carry the ark. 

# Which direction did the cherubim face?

The cherubim faced each another and looked toward the center of the atonement lid. 

# What objects would be on the table?

The dishes, spoons, the bowls, and pitchers to be used to pour out the offerings would be on the table. 

# What was located on each branch extending out from the lampstand?

Each branch had three cups made like almond blossoms, with a leafy base and a flower, and three cups made like almond blossoms in the other branch, with a leafy base and a flower. 

# How much gold did Bezalel use to make the the lampstand and its accessories?

He made the lampstand and its accessories with one talent of pure gold. 

# What surrounded the incense altar?

A border of gold surrounded the incense altar. 

# Who made the holy anointing oil and the pure fragrant incense?

Bezalel made the holy anointing oil and the pure fragrant incense. 

# How long and wide was the altar for burnt offerings?

The altar for burnt offerings was five cubits long and five cubits wide. 

# How did Bezalel make the altar?

He made the altar hollow, out of planks. 

# To whom did the mirrors belong?

The mirrors belonged to the women who served at the entrance to the tent of meeting. 

# Of what were all the hangings around the courtyard made?

All the hangings around the courtyard were made of fine linen. 

# How many courtyard posts were covered with silver?

All the courtyard posts were covered with silver. 

# Who directed the Levites?

Ithamar, son of Aaron the priest, directed the Levites. 

# How much gold was used for the project?

All the gold that was used for the project was twenty-nine talents and 730 shekels, measured by the standard of the sanctuary shekel. 

# How many men twenty years old and older were counted in the census?

There were 603,550 men twenty years old and older counted in the census. 

# What was made of one piece with the ephod?

The waistband was made of one piece with the ephod. 

# What was engraved with the names of Israel's twelve sons?

The onyx stones were engraved with the names of Israel's twelve sons. 

# How many rows of precious stones were on the breastpiece?

There were four rows of precious stones on the breastpiece. 

# What did the braided chains connect?

The braided chains connected the corners of the breastpiece to the two settings, which were attached to the shoulder pieces of the ephod at its front. 

# What did the braided chains connect?

The braided chains connected the corners of the breastpiece to the two settings, which were attached to the shoulder pieces of the ephod at its front. 

# Why did they tie the breastpiece by its rings to the ephod's rings with a blue cord?

They tied the breastpiece by its rings to the ephod's rings with a blue cord, so that it might be attached just above the ephod's finely woven waistband. This was so that the breastpiece might not become unattached from the ephod. 

# What was in the middle of the robe of the ephod?

The robe of the ephod had an opening for the head in the middle. 

# What was in the middle of the robe of the ephod?

The robe of the ephod had an opening for the head in the middle. 

# What did they put between the pomegranates all around on the bottom edge the robe?

They put the bells between the pomegranates all around on the bottom edge the robe. 

# What did they engrave on the plate of the holy crown of pure gold?

They engraved "HOLY TO YAHWEH" on the plate of the holy crown of pure gold. 

# What did Moses find when he examined all the work?

Moses examined all the work, and, behold, they had done it as Yahweh had commanded, in that way they did it. 

# When must Moses set up the tabernacle?

On the first day of the first month of the new year Moses must set up the tabernacle. 

# How must Moses shield the ark?

Moses must shield the ark with the curtain. 

# Where must Moses put the large basin?

Moses must put the large basin between the tent of meeting and the altar. 

# Why must Moses anoint the bronze basin and its base?

Moses must anoint the bronze basin and its base to prepare it for service to Yahweh. 

# Where did Moses put the covenant decrees?

Moses put the covenant decrees into the ark. 

# Where did Moses put the golden incense altar?

Moses put the golden incense altar into the tent of meeting in front of the curtain. 

# How often did Moses, Aaron, and his sons wash their hands and their feet from the basin?

Moses, Aaron, and his sons washed their hands and their feet from the basin whenever they would go into the tent of meeting and whenever they would go up to the altar. 

# How often did Moses, Aaron, and his sons wash their hands and their feet from the basin?

Moses, Aaron, and his sons washed their hands and their feet from the basin whenever they would go into the tent of meeting and whenever they would go up to the altar. 

# Why was Moses not able to enter the tent of meeting?

Moses was not able to enter the tent of meeting because the cloud had settled on it, and because Yahweh's glory filled the tabernacle. 

# When would the people of Israel set out on their journey?

Whenever the cloud was taken up from over the tabernacle, the people of Israel would set out on their journey. 

