# When did the word of Yahweh come by the hand of Haggai the prophet?

The word came in the second year of Darius the king, in the sixth month, on the first day of the month. 

# To whom did the word of Yahweh come?

The word came to Zerubbabel the governor and Joshua the high priest. 

# What did Yahweh claim the people said?

He claimed that they said it was not time for them to come or to build Yahweh's house. 

# What was the condition of Yahweh's house while the people lived in their finished houses?

Yahweh's house laid ruined. 

# Although the people sowed much seed and looked for much, why did Yahweh blow it away and bring drought upon all the labor of their hands?

Yahweh blew it away and brought drought because Yahweh's house laid in ruins while every man took pleasure in his own house. 

# What did Yahweh command the people to do?

Yahweh commanded them to build his house so that he would take pleasure in it and be glorified. 

# How did Zerubbabel the governor, Joshua the priest, and all the remnant of the people respond to Yahweh's voice and the words of Haggai the prophet, whom Yahweh had sent?

They obeyed Yahweh's voice and Haggai's words and feared the face of Yahweh. 

# How did Yahweh respond to the people's obedience?

He sent a message through Haggai his messenger to tell them, "I am with you!" 

# When did Yahweh stir up Zerubbabel the governor, Joshua the priest, and all the remnant of the people's spirits to go and work on the house of Yahweh of hosts, their God?

He stirred them up in the twenty-fourth day of the sixth month, in the second year of Darius the king. 

# When did Yahweh stir up Zerubbabel the governor, Joshua the priest, and all the remnant of the people's spirits to go and work on the house of Yahweh of hosts, their God?

He stirred them up in the twenty-fourth day of the sixth month, in the second year of Darius the king. 

# When did the word of Yahweh come by the hand of Haggai the prophet?

The word came in the seventh month on the twenty-first day of the month. 

# Although the house of Yahweh was like nothing in the eyes of those who saw it in its former glory, why did Yahweh declare that Zerubbabel the governor, Joshua the high priest, and all the people should be strong and work?

Yahweh declared that they should be strong and work because because he was with them. 

# Although the house of Yahweh was like nothing in the eyes of those who saw it in its former glory, why did Yahweh declare that Zerubbabel the governor, Joshua the high priest, and all the people should be strong and work?

Yahweh declared that they should be strong and work because because he was with them. 

# By Yahweh's established covenant, what were Zerubbabel, Joshua, and all the people not to do?

They were not to fear. 

# When Yahweh shook the heavens, earth, and every nation, and they brought their precious things to him, what would Yahweh do?

He would fill the house with glory and give peace in the place of the house. 

# When Yahweh shook the heavens, earth, and every nation, and they brought their precious things to him, what would Yahweh do?

He would fill the house with glory and give peace in the place of the house. 

# According to the priests, if the folds of a man's garment in which consecrated meat is carried touches other food, does the other food become holy?

According to the priests, food that is touched by the folds of a man's garment in which consecrated meat is carried does not become holy. 

# According to the priests, if the folds of a man's garment in which consecrated meat is carried touches other food, does the other food become holy?

According to the priests, food that is touched by the folds of a man's garment in which consecrated meat is carried does not become holy. 

# According to the priests, if someone who is unclean because of death touches any food, does that food become unclean?

According to the priests, food that is touched by someone who is unclean because of death also becomes unclean. 

# What were the offerings of the people and the nation before Yahweh like?

They were unclean like the food that is touched by someone who is unclean because of death. 

# Before any stone was laid on another stone in the temple of Yahweh, what had happened?

Ten measures of grain would be present when twenty measures were needed; twenty measures of wine would be found when fifty were needed, and Yahweh afflicted the people and all their work. 

# Before any stone was laid on another stone in the temple of Yahweh, what had happened?

Ten measures of grain would be present when twenty measures were needed; twenty measures of wine would be found when fifty were needed, and Yahweh afflicted the people and all their work. 

# Before any stone was laid on another stone in the temple of Yahweh, what had happened?

Ten measures of grain would be present when twenty measures were needed; twenty measures of wine would be found when fifty were needed, and Yahweh afflicted the people and all their work. 

# When Yahweh afflicted the people before any stone was laid on another stone in the temple of Yahweh, did the people turn to him?

No, the people did not turn to Yahweh. 

# What were the people to consider from the twenty-fourth day of the ninth month forward, the same day on which the foundation of Yahweh's temple was laid?

They were to consider that there was no seed in the storehouse, and that the vine, the fig tree, the pomegranate, and the olive tree had still not produced. 

# What were the people to consider from the twenty-fourth day of the ninth month forward, the same day on which the foundation of Yahweh's temple was laid?

They were to consider that there was no seed in the storehouse, and that the vine, the fig tree, the pomegranate, and the olive tree had still not produced. 

# What did Yahweh promise would happen from that day forward?

Yahweh promised that he would bless them from that day forward. 

# What did Yahweh declare would happen on the day he shook, overthrew, and destroyed the heavens, the earth, and kingdoms?

The horses and their riders would fall down, each one one because of his brother's sword, and Yahweh would take Zerubbabel as his servant. 

# What did Yahweh declare would happen on the day he shook, overthrew, and destroyed the heavens, the earth, and kingdoms?

The horses and their riders would fall down, each one one because of his brother's sword, and Yahweh would take Zerubbabel as his servant. 

# Why would Yahweh set Zerubbabel like the seal on his ring?

Yahweh would set him like a seal on his ring because Yahweh had chosen him. 

