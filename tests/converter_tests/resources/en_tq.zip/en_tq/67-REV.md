# From whom did this revelation first come, and to whom is the revelation being shown?

The revelation of Jesus Christ came from God, and is being shown to his servants. 

# When would the events of the revelation take place?

The events of the revelation would take place soon. 

# Who will be blessed by this book?

Those who read aloud, hear, and obey this book will be blessed. 

# Who wrote this book, and to whom did he write?

John wrote this book, and he wrote to the seven churches in Asia. 

# What three titles does John give to Jesus Christ?

John gives Jesus Christ the titles of faithful witness, firstborn of the dead, and ruler of the kings of the earth. 

# What has Jesus made the believers?

Jesus has made the believers a kingdom and priests to God the Father. 

# Who will see Jesus when he comes?

Every eye will see Jesus when he comes, including those who pierced him. 

# How does the Lord God describe himself?

The Lord God describes himself as the Alpha and the Omega, the one who is, and who was, and who is to come, the Almighty. 

# Why was John on the island of Patmos?

John was on the island of Patmos because of the word of God and the testimony about Jesus. 

# What did the loud voice behind John tell him to do?

The loud voice told John to write in a book what he saw and send it to the seven churches. 

# What kind of hair and eyes did the man have who John saw?

The man John saw had hair as white as wool, and eyes like a fiery flame. 

# What was in the right hand of the man, and what was coming out of his mouth?

The man had seven stars in his right hand, and a sharp two-edged sword coming out of his mouth. 

# What did John do when he saw the man?

John fell at the man's feet like a dead man. 

# What keys did the man say he had?

The man said he had the keys of Death and of Hades. 

# What was the meaning of the seven stars and the seven golden lampstands?

The seven stars were the angels of the seven churches, and the seven lampstands were the seven churches. 

# To which angel is the next portion of the book written?

The next portion of the book is written to the angel of the church in Ephesus. 

# What has the church in Ephesus done regarding those who are evil and regarding the false prophets?

The church in Ephesus has not put up with those who are evil and has tested the false prophets. 

# What does Christ have against the church in Ephesus?

Christ has against the church in Ephesus that they have left behind their first love. 

# What does Christ say he will do if they do not repent?

Christ says he will come and remove their lampstand from its place if they do not repent. 

# What does Christ promise to those who conquer?

Christ promises that those who conquer will eat from the tree of life in the paradise of God. 

# To which angel is the next portion of the book written?

The next portion of the book is written to the angel of the church in Smyrna. 

# What has the church in Smyrna experienced?

The church in Smyrna has experienced sufferings, poverty, and slander. 

# What does Christ promise to those who are faithful until death and who conquer?

Christ promises that those who are faithful until death and conquer will receive the crown of life and will not be hurt by the second death. 

# What does Christ promise to those who are faithful until death and who conquer?

Christ promises that those who are faithful until death and conquer will receive the crown of life and will not be hurt by the second death. 

# To which angel is the next portion of the book written?

The next portion of the book is written to the angel of the church in Pergamum. 

# Where does the church in Pergamum live?

The church in Pergamum lives where Satan's throne is. 

# What did the church in Pergamum do in the days when Antipas was killed?

The church in Pergamum held tightly to Christ's name and did not deny the faith in the days when Antipas was killed. 

# To what two teachings have some in the church in Pergamum held?

Some in the church in Pergamum have held to the teachings of Balaam and to the teachings of the Nicolaitans. 

# To what two teachings have some in the church in Pergamum held?

Some in the church in Pergamum have held to the teachings of Balaam and to the teachings of the Nicolaitans. 

# What does Christ warn he will do if those who hold to these false teachings do not repent?

Christ warns he will come and make war against those who hold to these false teachings. 

# What does Christ promise to those who conquer?

Christ promises that those who conquer will eat the hidden manna and will receive a white stone with a new name. 

# To which angel is the next portion of the book written?

The next portion of the book is written to the angel of the church in Thyatira. 

# What good things does Christ know the church in Thyatira has done?

Christ knows the church in Thyatira has shown love, faith, service, and patient endurance. 

# What does Christ have against the church in Thyatira?

Christ has against the church in Thyatira that they tolerate the immoral false prophetess Jezebel. 

# What does Christ warn he will do if Jezebel does not repent?

Christ warns that he will throw Jezebel into a sickbed and strike her children dead if she does not repent. 

# What does Christ warn he will do if Jezebel does not repent?

Christ warns that he will throw Jezebel into a sickbed and strike her children dead if she does not repent. 

# What does Christ tell those who have not held to the teaching of Jezebel to do?

Christ tells them to hold on tightly until he comes. 

# What does Christ promise those who conquer?

Christ promises those who conquer authority over the nations and the morning star. 

# What does Christ promise those who conquer?

Christ promises those who conquer authority over the nations and the morning star. 

# To what does Christ say the reader of this book should listen?

Christ says the reader should listen to what the Spirit is saying to the churches. 

# To which angel is the next portion of the book written?

The next portion of the book is written to the angel of the church in Sardis. 

# What is the reputation of the church in Sardis, but what is the truth about them?

The reputation of the church in Sardis is that they are alive, but the truth is that they are dead. 

# What does Christ warn the church in Sardis to do?

Christ warns them to wake up and strengthen what remains. 

# What does Christ promise those who conquer?

Those who conquer will be clothed in white, will remain in the book of life, and will have their name spoken before God the Father. 

# To which angel is the next portion of the book written?

The next portion of the book is written to the angel of the church in Philadelphia. 

# What has the church in Philadelphia done even though they have little strength?

The church in Philadelphia has obeyed Christ's word and has not denied his name. 

# What will Christ make those of the synagogue of Satan do?

Christ will make those of the synagogue of Satan bow down before the saints' feet. 

# What does Christ tell the church of Philadelphia to do since he is coming soon?

Christ tells them to hold tight to what they have so no one can take away their crown. 

# What does Christ promise to those who conquer?

Those who conquer will be a pillar in the temple of God, will have the name of God, the name of the city of God, and Christ's new name written on them. 

# To which angel is the next portion of the book written?

The next portion of the book is written to the angel of the church in Laodicea. 

# What does Christ wish the church in Laodicea was?

Christ wishes the church in Laodicea was either cold or hot. 

# What is Christ about to do to the church in Laodicea, and why?

Christ is about to vomit the church in Laodicea out of his mouth because they are lukewarm. 

# What does the church in Laodicea say about itself?

The church in Laodicea says that it is rich and in need of nothing. 

# What does Christ say about the church in Laodicea?

Christ says the church in Laodicea is miserable, pitiable, poor, blind, and naked. 

# What does Christ do for everyone he loves?

Christ trains and teaches everyone he loves. 

# What does Christ promise to those who conquer?

Those who conquer will sit with Christ on his throne. 

# To whom does Christ say the reader of the book should listen?

Christ says the reader should listen to what the Spirit says to the churches. 

# What did John see opened?

John saw a door opened in heaven. 

# What did the voice say he would show John?

The voice said he would show John what must happen after these things. 

# What was someone sitting on in heaven?

Someone was sitting on a throne in heaven. 

# What was around the throne in heaven?

Around the throne were twenty-four thrones with twenty-four elders seated on them. 

# What were the seven lamps burning in front of the throne?

The seven lamps were the seven Spirits of God. 

# What four things were around the throne?

Four living creatures were around the throne. 

# What three words do the four living creatures repeat night and day?

Night and day the four living creatures do not stop saying, "Holy, holy, holy." 

# What do the twenty-four elders do when the living creatures give glory to God?

The twenty-four elders prostrate themselves before the throne and bow down, throwing down their crowns. 

# What do the elders say about God's role in creation?

The elders say God created all things and by his will all things existed and were created. 

# What did John see in the right hand of the one seated on the throne?

John saw a scroll sealed with seven seals. 

# Who on the earth was worthy to open the scroll or read it?

No one was worthy to open the scroll or read it. 

# Who on the earth was worthy to open the scroll or read it?

No one was worthy to open the scroll or read it. 

# Who was able to open the scroll and its seven seals?

The Lion of the tribe of Judah, the Root of David, was able to open the scroll. 

# Who was standing among the elders before the throne?

A Lamb, looking as though he had been killed, was standing among the elders before the throne. 

# What were the seven horns and seven eyes on the Lamb?

The seven horns and seven eyes were the seven Spirits of God sent out over all the earth. 

# What were the gold bowls full of incense which the elders had?

The gold bowls full of incense were the prayers of the saints. 

# Why was the Lamb worthy to open the scroll?

The Lamb was worthy because he purchased for God people from every tribe, language, people, and nation with his blood. 

# Where will the priests of God reign?

The priests of God will reign on the earth. 

# What did the angels say the Lamb was worthy to receive?

The angels said the Lamb was worthy to receive power, wealth, wisdom, strength, honor, glory, and praise. 

# Who said that the one on the throne and the Lamb should be praised forever and ever?

Every created thing said that the one on the throne and the Lamb should be praised forever and ever. 

# What did the elders do when they heard the four living creatures say, "Amen!"?

The elders laid down on the ground and worshiped. 

# What did the Lamb do with the scroll?

The Lamb opened one of the seven seals on the scroll. 

# What did John see after the first seal was opened?

John saw a white horse, with a rider going out to conquer. 

# What did John see after the second seal was opened?

John saw a fiery red horse, whose rider took peace away from the earth. 

# What did John see after the third seal was opened?

John saw a black horse, whose rider held a pair of scales in his hand. 

# What did John see after the fourth seal was opened?

John saw a pale horse, whose rider was named Death. 

# What did John see after the fifth seal was opened?

John saw the souls of those who had been killed because of the word of God. 

# What did the souls under the altar want to know from God?

The souls wanted to know how long until God avenged their blood. 

# How long were the souls told they would have to wait?

The souls were told they would have to wait until the full number of fellow servants were killed. 

# What did John see after the sixth seal was opened?

John saw an earthquake, the sun becoming black, the moon becoming like blood, and the stars falling to the earth. 

# What did John see after the sixth seal was opened?

John saw an earthquake, the sun becoming black, the moon becoming like blood, and the stars falling to the earth. 

# What did John see the kings, generals, rich, powerful, and everyone else doing?

John saw them hiding in caves and asking the rocks to fall on them and hide them. 

# What did John see the kings, generals, rich, powerful, and everyone else doing?

John saw them hiding in caves and asking the rocks to fall on them and hide them. 

# From what did the kings, generals, rich, powerful, and everyone else want to be hid?

They wanted to be hid from the one seated on the throne and from the anger of the Lamb. 

# What day had come?

The great day of the wrath of the one on the throne and the Lamb had come. 

# What were the four angels standing on the four corners of the earth doing when John saw them?

The four angels were holding back the four winds of the earth. 

# What did the angel from the east say must be done before the earth was harmed?

The angel said that a seal must be put on the foreheads of the servants of God before the earth was harmed. 

# What did the angel from the east say must be done before the earth was harmed?

The angel said that a seal must be put on the foreheads of the servants of God before the earth was harmed. 

# How many people from what tribe were sealed?

The number of people sealed was 144,000 from every tribe of the people of Israel. 

# What did John then see before the throne of God and in front of the Lamb?

John saw a great multitude from every nation, tribe, people, and language before the throne. 

# According to those before the throne, to whom does salvation belong?

Those before the throne called out that salvation belongs to God and to the Lamb. 

# In what bodily position were the angels, elders, and living creatures as they worshiped God?

They laid down on the ground and put their faces on the ground as they worshiped God. 

# Who did the elder say were the ones clothed in white robes before the throne?

The elder said they were the ones who had come out of the Great Tribulation. 

# How had the ones before the throne made their robes white?

They had made their robes white by washing them in the blood of the Lamb. 

# What did the elder say God would do for those who are clothed in white robes?

God will spread his tent over them so they will suffer no more. 

# What did the elder say God would do for those who are clothed in white robes?

God will spread his tent over them so they will suffer no more. 

# What did the elder say the Lamb would do for those who are clothed in white robes?

The Lamb will shepherd them and guide them to springs of living water. 

# What caused there to be silence in heaven?

When the Lamb opened the seventh seal, there was silence in heaven. 

# What was given to the seven angels who stand before God?

Seven trumpets were given to the seven angels who stand before God. 

# What rose up before God?

The smoke of incense with the prayers of the saints rose up before God. 

# What happened when the angel threw down to earth the fire from the altar?

When the angel threw down the fire, there was thunder, rumblings, lightning, and an earthquake. 

# What happened when the first trumpet was blown?

When the first trumpet was blown, a third of the earth was burned up, a third of the trees, and all grass. 

# What happened when the second trumpet was blown?

When the second trumpet was blown, a third of the sea became blood, a third of the creatures of the sea died, and a third of the ships were destroyed. 

# What happened when the second trumpet was blown?

When the second trumpet was blown, a third of the sea became blood, a third of the creatures of the sea died, and a third of the ships were destroyed. 

# What happened when the third trumpet was blown?

When the third trumpet was blown, a third of the waters became wormwood, and many people died. 

# What happened when the third trumpet was blown?

When the third trumpet was blown, a third of the waters became wormwood, and many people died. 

# What happened when the fourth trumpet was blown?

When the fourth trumpet was blown, a third of the day and a third of the night had no light. 

# Why did the eagle say "Woe, woe, woe" to those on the earth?

The eagle said, "Woe, woe, woe" to those on the earth because of the remaining three trumpet blasts. 

# What kind of star did John see when the fifth trumpet was blown?

When the fifth trumpet was blown, John saw a star from heaven that had fallen to earth. 

# What did the star do?

The star opened the shaft of the deep and endless pit. 

# What were the locusts from the pit told to do?

The locusts were told not to damage the earth, but only the people who did not have the seal of God. 

# What were the locusts from the pit told to do?

The locusts were told not to damage the earth, but only the people who did not have the seal of God. 

# What would the people tortured by the locusts seek but not find?

The people tortured by the locusts would seek death, but would not find it. 

# What sound did the wings of the locusts make?

The sound of the locusts' wings was like the sound made by many chariots and horses running into battle. 

# Who was the king over the locusts?

The king over the locusts was Abaddon, or in Greek, Apollyon, the angel of the pit. 

# What was past after the fifth trumpet was blown?

The first woe was past after the fifth trumpet was blown. 

# What voice did John hear when the sixth trumpet was blown?

When the sixth trumpet was blown, John heard a voice coming from the golden altar that is present before God. 

# What did the four angels do when they heard the voice?

When they heard the voice, the four angels were released to kill a third of humanity. 

# How many soldiers on horseback did John see?

John saw 200,000,000 soldiers on horseback. 

# What plagues killed a third of the people?

The plagues of fire, smoke, and sulfur from the mouths of the horses killed a third of the people. 

# How did the people not killed by the plagues respond?

The people not killed by the plagues did not repent of their works, nor did they stop worshiping demons. 

# What did the face and feet of the mighty angel that John saw look like?

The angel had a face like the sun and feet like pillars of fire. 

# Where did the angel stand?

The angel stood with his right foot on the sea and his left foot on the land. 

# What was John told not to write?

John was told not to write what the seven thunders said. 

# By whom did the mighty angel swear?

The mighty angel swore by him who lives forever and ever, who created heaven, the earth, and the sea. 

# What did the mighty angel say would no longer be delayed?

The angel said that when the seventh trumpet was blown, there would be no more delay, but the mystery of God would be accomplished. 

# What was John told to take from the mighty angel?

John was told to take an open scroll from the angel. 

# What did the angel say would happen when John ate the scroll?

The angel said that the scroll would be sweet in John's mouth, but bitter in his stomach. 

# After he ate the scroll, about what was John told to prophesy?

John was told to prophesy about many peoples, nations, languages, and kings. 

# What was John told to measure?

John was told to measure the temple of God and the altar, and those who worship in it. 

# How long would the Gentiles trample the holy city?

The Gentiles would trample the holy city for forty-two months. 

# What were the two witnesses given authority to do to those who choose to harm them?

The two witnesses were given authority to kill their enemies with fire. 

# Where will the bodies of the two witnesses lie?

Their bodies will lie in the street of the city symbolically called Sodom and Egypt, where their Lord was crucified. 

# How will the people of the earth react when the two witnesses are killed?

The people of the earth will rejoice and celebrate when the two witnesses are killed. 

# What will happen to the two witnesses after three and a half days?

After three and a half days, the two witnesses will stand on their feet and go up to heaven. 

# What will happen to the two witnesses after three and a half days?

After three and a half days, the two witnesses will stand on their feet and go up to heaven. 

# After the two witnesses and the earthquake are finished, what is past?

After the two witnesses and the earthquake, the second woe is past. 

# When the seventh trumpet was blown, what was spoken in heaven?

When the seventh trumpet was blown, it was spoken that the kingdom of the world had become the kingdom of our Lord and of his Christ. 

# What did the elders say that the Lord God had now begun to do?

The elders said that the Lord God had now begun to reign. 

# According to the elders, what time had now come?

The time had now come for the dead to be judged, for God's servants to be rewarded, and for God to destroy those who were destroying the earth. 

# What was then opened in heaven?

God's temple was then opened in heaven. 

# What great sign was seen in heaven?

In heaven was seen a pregnant woman clothed with the sun, with the moon under her feet, and with twelve stars on her head crying out in birth pains. 

# What great sign was seen in heaven?

In heaven was seen a pregnant woman clothed with the sun, with the moon under her feet, and with twelve stars on her head crying out in birth pains. 

# What other great sign was seen in heaven?

In heaven was seen a huge red dragon with seven heads and ten horns, with seven crowns on his heads. 

# What did the dragon do with his tail?

The dragon swept away a third of the stars in heaven and hurled them down to earth. 

# What did the dragon desire to do?

The dragon desired to devour the child of the woman. 

# What was the male child going to do?

The male child was going to rule all the nations with an iron rod. 

# Where did the male child go?

The male child was snatched away to God and to his throne. 

# Where did the woman go?

The woman fled into the wilderness. 

# Who fought in heaven?

Michael and his angels fought against the dragon and his angels. 

# What happened to the dragon and his angels after the battle?

The dragon and his angels were thrown down to the earth. 

# Who is the dragon?

The dragon is the old serpent, the devil, or Satan. 

# How did the brothers conquer the dragon?

The brothers conquered the dragon by the blood of the Lamb and by the word of their testimony. 

# How much time does the dragon know he has?

The dragon knows he has only a little time. 

# What was done for the woman when the dragon pursued her?

The woman was given wings to fly to the place prepared for her where she would be taken care of. 

# What was done for the woman when the dragon pursued her?

The woman was given wings to fly to the place prepared for her where she would be taken care of. 

# When the dragon could not sweep away the woman, what did the dragon do?

The dragon went off to make war with those who obey God's commandments and who hold to the testimony about Jesus. 

# When the dragon could not sweep away the woman, what did the dragon do?

The dragon went off to make war with those who obey God's commandments and who hold to the testimony about Jesus. 

# When the dragon could not sweep away the woman, what did the dragon do?

The dragon went off to make war with those who obey God's commandments and who hold to the testimony about Jesus. 

# From where did the beast come that John saw?

The beast came up out of the sea. 

# What did the dragon give to the beast?

The dragon gave to the beast his power, a throne, and authority to rule. 

# Why did the whole earth marvel and follow the beast?

The whole earth marveled and followed the beast because he had a lethal wound that had been healed. 

# What did the beast speak with his mouth?

The beast spoke proud words and insults against God, his name, the place where he lived, and those who live in heaven. 

# What did the beast speak with his mouth?

The beast spoke proud words and insults against God, his name, the place where he lived, and those who live in heaven. 

# What was the beast permitted to do with the holy people?

The beast was permitted to make war with the holy people and to conquer them. 

# Who will not worship the beast?

Those whose name is written in the book of life will not worship the beast. 

# To what are those who are holy called?

Those who are holy are called to patient endurance and faith. 

# From where did the other beast come that John saw?

The other beast came up out of the earth. 

# What kind of horns and speaking did the other beast have?

The other beast had horns like a lamb and spoke like a dragon. 

# What did the other beast cause those who live on the earth to do?

The other beast caused those who live on the earth to worship the first beast. 

# What happened to those who refused to worship the beast?

Those who refused to worship the beast were killed. 

# What did everyone receive from the other beast?

Everyone received a mark on the right hand or on the forehead. 

# What is the number of the beast?

The number of the beast is 666. 

# Who did John see standing before him?

John saw the Lamb standing before him on Mount Zion. 

# Who was able to learn the new song being sung before the throne?

Only the 144,000 who had been redeemed from the earth were able to learn the new song. 

# Who was redeemed as firstfruits to God and to the Lamb?

The 144,000 who were blameless were redeemed as firsfruits to God and to the Lamb. 

# Who was redeemed as firstfruits to God and to the Lamb?

The 144,000 who were blameless were redeemed as firsfruits to God and to the Lamb. 

# To whom did the angel give the eternal message of good news?

The angel gave the eternal message of good news to every nation, tribe, language, and people on the earth. 

# What did the angel tell those who live on the earth to do?

The angel told them to fear God and to give him glory. 

# What time did the angel say had come?

The angel said the hour of God's judgment had come. 

# What did the second angel announce?

The second angel announced that Babylon the great had fallen. 

# What did the third angel say would happen to those who received the mark of the beast?

Those who received the mark of the beast would be tormented with fire and sulfur. 

# To what were the saints called?

The saints were called to patient endurance. 

# Who did John see seated on the cloud?

John saw one like a Son of Man seated on the cloud. 

# What did the one sitting on the cloud do?

The one sitting on the cloud swung his sickle to harvest the earth. 

# What did the angel with the sickle do?

The angel with the sickle gathered the grape harvest of the earth and threw it into the wine vat of God's wrath. 

# What happened at the winepress of God?

The winepress was stomped and blood poured out from it. 

# What did the seven angels that John saw have with them?

The seven angels had seven plagues, which are the final plagues. 

# Who was standing by the sea?

Those who had been victorious over the beast and his image were standing by the sea. 

# Whose song were those standing by the sea singing?

Those standing by the sea were singing the song of Moses and the song of the Lamb. 

# How were God's ways described in the song?

God's ways were described as just and true. 

# In the song, who will come and worship God?

All nations will come and worship God. 

# What then came out of the most holy place?

The seven angels with the seven plagues then came out of the most holy place. 

# What was given to the seven angels?

The seven angels were given seven bowls full of the wrath of God. 

# Until when could no one enter the most holy place?

Until the seven plagues were completed, no one could enter the most holy place. 

# What were the seven angels told to do?

The seven angels were told to go and pour out on the earth the seven bowls of God's wrath. 

# What happened when the first bowl of God's wrath was poured out?

Ugly and painful sores came on the people who had the mark of the beast. 

# What happened when the second bowl of God's wrath was poured out ?

The sea became like the blood of a dead person. 

# What happened when the third bowl of God's wrath was poured out ?

The rivers and springs of water became blood. 

# Why was it true and just that God gave these people blood to drink?

It was true and just because these people had poured out the blood of God's saints and prophets. 

# What happened when the fourth bowl of God's wrath was poured out ?

The sun scorched the people with fire. 

# How did the people respond to these plagues?

The people did not repent or give God glory. 

# What happened when the fifth bowl of God's wrath was poured out ?

Darkness covered the kingdom of the beast. 

# What happened when the sixth bowl of God's wrath was poured out ?

The water of the Euphrates river was dried up to prepare the way for the kings from the east. 

# What were the three unclean spirits going out to do?

The three unclean spirits were going out to gather the kings of the world for the battle on the great day of God. 

# What were the three unclean spirits going out to do?

The three unclean spirits were going out to gather the kings of the world for the battle on the great day of God. 

# What was the name of the place where the kings of the world were brought together?

The name of the place was Armageddon. 

# What happened when the seventh bowl of God's wrath was poured out ?

A loud voice said, "It is done!" and there was lightning, thunder, and an earthquake. 

# What happened when the seventh bowl of God's wrath was poured out ?

A loud voice said, "It is done!" and there was lightning, thunder, and an earthquake. 

# At this time, what did God call to mind and do?

At this time, God called to mind Babylon the great, and he gave Babylon the cup filled with his wrath. 

# How did the people respond to these plagues?

The people cursed God. 

# What did the angel say he would show John?

The angel said he would show John the condemnation of the great prostitute. 

# On what was the woman sitting?

The woman was sitting on a beast with seven heads and ten horns. 

# What was in the cup which the woman held in her hand?

The cup was full of detestable things and the impurities of her sexual immorality. 

# What was the woman's name?

The woman's name was, "Babylon the Great, the Mother of Prostitutes and of the Detestable Things of the Earth". 

# With what was the woman drunk?

The woman was drunk with the blood of the saints and martyrs for Jesus. 

# From where did the beast come on which the woman sat?

The beast came up from the deep, bottomless pit. 

# To where was the beast going?

The beast was going to destruction. 

# What were the seven heads of the beast?

The seven heads were seven hills on which the woman was seated, and were also seven kings. 

# What were the seven heads of the beast?

The seven heads were seven hills on which the woman was seated, and were also seven kings. 

# To where was the beast going?

The beast was going to destruction. 

# What were the ten horns of the beast?

The ten horns were ten kings. 

# What would the kings and the beast do when they were of one mind?

When they were of one mind, they would make war against the Lamb. 

# What were the waters where the prostitute was seated?

The waters were peoples, multitudes, nations, and languages. 

# What would the kings and the beast do to the woman?

They would make the woman desolate and naked, devour her flesh, and burn her with fire. 

# What was the woman that John saw?

The woman that John saw was the great city that rules over the kings of the earth. 

# What announcement did the angel with great authority make?

The angel announced that Babylon the great had fallen. 

# What announcement did the angel with great authority make?

The angel announced that Babylon the great had fallen. 

# What did the voice from heaven tell God's people to do?

The voice told God's people to come out from Babylon and to not share in her sins. 

# What amount of payment did God give back to Babylon for what she had done?

God paid back Babylon double for what she had done. 

# What plagues overtook Babylon in one day?

Death, mourning, and famine overtook Babylon in one day and she was consumed with fire. 

# How did the kings and merchants of the earth respond when they saw Babylon's judgment?

When the kings and merchants of the earth saw Babylon's judgment, they wept and wailed over her. 

# Why did the kings, merchants and ship's captains stand at a distance from Babylon at her time of judgment?

They stood at a distance because they were afraid of her torment. 

# Why did the kings, merchants and ship's captains stand at a distance from Babylon at her time of judgment?

They stood at a distance because they were afraid of her torment. 

# For what did Babylon long, which vanished in a single hour?

Babylon longed for luxury and splendor, which vanished in a single hour. 

# Why did the kings, merchants and ship's captains stand at a distance from Babylon at her time of judgment?

They stood at a distance because they were afraid of her torment. 

# Why did the kings, merchants and ship's captains stand at a distance from Babylon at her time of judgment?

They stood at a distance because they were afraid of her torment. 

# What question did the ship's captains ask about Babylon?

The ship's captains asked, "What city is like the great city?" 

# What were the saints, apostles, and prophets told to do when Babylon was judged by God?

The saints, apostles, and prophets were told to rejoice when Babylon was judged by God. 

# After her judgment, when would Babylon be seen again?

After her judgment, Babylon would be seen no more. 

# What was found in the great city Babylon for which she was judged?

The blood of prophets, saints, and all who have been killed on the earth was found. 

# What did the loud voice in heaven say about God's judgments?

The loud voice in heaven said that God's judgments were true and just. 

# What did the loud voice in heaven say about God's judgments?

The loud voice in heaven said that God's judgments were true and just. 

# Why did God judge the great prostitute?

God judged the great prostitute because she corrupted the earth with her sexual immorality and shed the blood of God's servants. 

# What will happen to the great prostitute forever and ever?

Smoke will rise from the great prostitute forever and ever. 

# What were the servants of God who fear him told to do?

The servants of God were told to praise him. 

# Why did the voice say that the servants of God should rejoice and be very happy?

The servants of God were told to rejoice because the wedding celebration of the Lamb had come. 

# With what is the bride of the Lamb dressed?

The bride is dressed in fine linen, which is the righteous acts of God's holy people. 

# What did the angel say that the testimony about Jesus was?

The angel said that the testimony about Jesus was the spirit of prophecy. 

# What is the name of the one John saw riding the white horse?

John saw the Word of God riding the white horse. 

# What is the name of the one John saw riding the white horse?

John saw the Word of God riding the white horse. 

# What is the name of the one John saw riding the white horse?

John saw the Word of God riding the white horse. 

# How does the Word of God strike down the nations?

Out of the mouth of the Word of God goes a sharp sword which strikes down the nations. 

# What is written on the Word of God's robe and thigh?

On his robe and thigh is written, "King of Kings and Lord of Lords". 

# What were the birds flying overhead called to eat at the great supper?

The birds were called to eat the flesh of kings, commanders, mighty men, horses and their riders, and all men. 

# What were the beast and the kings of the earth setting out to do?

They were setting out to make war with the Word of God and his army. 

# What happened to the beast and the false prophet?

The beast and the false prophet were both thrown alive into the fiery lake of burning sulfur. 

# What happened to the rest of those fighting against the Word of God?

The rest were killed by the sword coming out of the mouth of the Word of God. 

# What did the angel coming down from heaven have with him?

The angel had the key to the endless pit and a great chain in his hand. 

# How long would Satan remain bound?

Satan would remain bound for a thousand years. 

# What did the angel do with Satan?

The angel threw Satan into the bottomless pit. 

# How long would Satan remain bound?

Satan would remain bound for a thousand years. 

# What would Satan not be able to do while he was bound?

Satan would not be able to deceive the nations while he was bound. 

# What happened to those who had refused to receive the mark of the beast?

Those who had refused to receive the mark of the beast came to life and reigned with Christ for a thousand years. 

# When would the rest of the dead come to life?

The rest of the dead would come to life when the thousand years were ended. 

# What would those who took part in the first resurrection do?

Those who took part in the first resurrection would be priests of God and Christ and would reign with him for a thousand years. 

# What will Satan do at the end of the thousand years?

At the end of the thousand years, Satan will be released to go out to deceive the nations. 

# What happened when the camp of the saints was surrounded?

When the camp of the saints was surrounded, fire came down from heaven and devoured Gog and Magog. 

# What was done with the devil at this time?

The devil was thrown into the lake of fire to be tormented forever. 

# By what were the dead judged before the great white throne?

The dead were judged by what was recorded in the books, the result of what they had done. 

# What is the second death?

The second death is the lake of fire. 

# What happened to all who were not written in the Book of Life?

All who were not found written in the Book of Life were thrown into the lake of fire. 

# What did John see had happened to the first heaven and earth?

John saw that the first heaven and earth had passed away. 

# What had replaced the first heaven and earth?

A new heaven and earth had replaced the first heaven and earth. 

# What came down from heaven?

The holy city, new Jerusalem, came down from heaven. 

# Where did the voice from the throne say that God would now dwell?

The voice said that God would now dwell with human beings. 

# What had now passed away?

Death, grieving, crying, and pain had now passed away. 

# What name did the one seated on the throne call himself?

The one seated on the throne called himself the Alpha and the Omega, the beginning and the end. 

# What happens to the faithless, sexually immoral, and idolaters?

The faithless, sexually immoral, and idolaters have their place in the fiery lake of burning sulfur. 

# What is the bride, the wife of the Lamb?

The bride, the wife of the Lamb, is the holy city, Jerusalem, coming down out of heaven from God. 

# What was written on the gates of new Jerusalem?

The names of the twelve tribes of the children of Israel were written on the gates of new Jerusalem. 

# What was written on the foundations of new Jerusalem?

The names of the twelve apostles of the Lamb were written on the foundations of new Jerusalem. 

# In what shape was new Jerusalem laid out?

New Jerusalem was laid out in a square. 

# Of what was the city built?

The city was built of pure gold, like clear glass. 

# What is the temple in new Jerusalem?

The temple in new Jerusalem is the Lord God and the Lamb. 

# What is the source of light in new Jerualem?

The source of light in new Jerusalem is the glory of God and the Lamb. 

# What will never enter new Jerusalem?

Nothing unclean will ever enter new Jerusalem. 

# What did John see flowing from the throne of God?

John saw the river of the water of life flowing from the throne of God. 

# For what are the leaves of the tree of life?

The leaves of the tree of life are for the healing of the nations. 

# What will there no longer be in the city?

There will no longer be any curse, and there will be no more night. 

# Where will the throne of God and of the Lamb be?

The throne of God and of the Lamb will be in the city. 

# What will there no longer be in the city?

There will no longer be any curse, and there will be no more night. 

# What must a person do to be blessed by this book?

A person must obey the words of the prophecy of this book to be blessed. 

# What did the angel tell John to do when John prostrated himself at the feet of the angel?

The angel told John to worship God. 

# What did the angel tell John to do when John prostrated himself at the feet of the angel?

The angel told John to worship God. 

# Why was John told not to seal up the words of the prophecy of this book?

John was told not to seal up the words of the prophecy of this book because the time was near. 

# What did the Lord say he was bringing with him when he comes?

The Lord said he was bringing his reward with him when he comes. 

# What must those do who want to have the right to eat from the tree of life?

Those who want to have the right to eat from the tree of life must wash their robes. 

# How does Jesus say he is related to King David?

Jesus says he is the root and descendant of King David. 

# What will happen to anyone who adds to the prophecy of this book?

Anyone who adds to the prophecy of this book will receive the plagues written about in this book. 

# What will happen to anyone who takes away from the prophecy of this book?

Anyone who takes away from the prophecy of this book will have his share of the tree of life taken away. 

# What are Jesus' last words in this book?

Jesus' last words are, "Yes! I am coming soon". 

# What is the last word in this book?

The last word in this book is "Amen". 

