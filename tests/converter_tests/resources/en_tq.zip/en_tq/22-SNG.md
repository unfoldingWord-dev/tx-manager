# Who is the writer of Song of Songs?

Solomon is the writer of Song of Songs. 

# For what does the young woman ask her lover to do?

The young woman asks her lover to kiss her with the kisses of his mouth. 

# What does the young woman say is better than wine?

The young woman says her lover's love is better than wine. 

# What does the young woman say her lover's name is like?

The young woman says his name is like flowing perfume. 

# Where has the king brought the young woman?

The king has brought the young woman into his rooms. 

# How does the young woman describe her skin?

The young woman describes her skin as dark but lovely like tents of Kedar, like curtains of Solomon. 

# Why does she not want the other women to stare at her?

She does not want the other women to stare at her because her skin is scorched. 

# What did the young woman's brothers do when they were angry with her?

The young woman's brothers made her a keeper of the vineyards. 

# What does the woman ask her lover? 

She asks him where he feeds his flock and where he rests his flock at noontime. 

# How does her lover say the young woman can find him?

He tells her to follow the tracks of his flock to the shepherds' tents. 

# To what does the young woman's lover compare her?

He compares her to a mare among Pharaoh's chariots. 

# What does her lover say is on her cheeks and neck?

He says ornaments are on her cheeks and strings of jewels are on her neck. 

# What does her lover say he will make for her?

He says he will make for her gold ornaments with silver studs. 

# Where was the king lying while the woman was speaking to herself?

The king was lying on his couch while the woman was speaking to herself. 

# Where does her beloved spend the night?

Her beloved spends the night lying between her breasts. 

# To what does the young woman liken her beloved?

Her beloved is like a cluster of henna flowers in the vineyards of En Gedi. 

# How does her lover describe her eyes?

He says her eyes are like doves. 

# What does the woman say serves as their bed?

Lush plants serve as their bed. 

# Of what does the woman say the beams and rafters are made?

The beams and rafters are made of cedar tree branches and fir branches. 

# How did the woman describe herself?

She described herself as just a flower of in a plain, just a lily in a valley. 

# What does the man say she was like among the daughters of his countrymen?

He said she was like a lily among thorns. 

# How did the woman describe her beloved among the young men?

The woman described her young man as the apricot tree among the trees of the forest. 

# Where did the woman sit?

She sat down under his shadow with great delight. 

# What was sweet to her taste?

His fruit was sweet to her taste. 

# Where did her young man bring her?

Her young man brought her to the banqueting hall. 

# What was his banner over her?

His banner over her was love. 

# What did the young woman want to revive and refresh herself?

The young woman wanted raisin cakes to revive her and apricots to refresh her. 

# Where were the young man's left and right hands?

His left hand was under her head and his right hand embraced her. 

# What did the young woman want the daughters of Jerusalem's men to swear?

The young woman wanted the young women to swear that they would not interrupt the young woman and her beloved's lovemaking until it was over. 

# What sound did the young woman hear?

The young woman heard the sound of her beloved. 

# What did she say her beloved was doing?

He was leaping over the mountains and jumping over the hills. 

# What did she say her beloved was like?

She said her beloved was like a gazelle or a young stag. 

# What did her beloved want her to do with him?

He wanted her to get up and go away with him. 

# What did he say was past and what was over and gone?

He said he winter was past and the rain was over and gone. 

# What had appeared in the land?

Flowers had appeared in the land. 

# For what was it time?

It was time for pruning and the singing of birds. 

# What ripened and was in blossom?

The green figs ripened and the vines were in blossom. 

# What did her beloved want his beautiful one to do?

He wanted her to arise and come away. 

# What does her beloved call her?

Her beloved calls her his dove. 

# What does her beloved want to see and hear?

Her beloved wanted to see her lovely face and hear her sweet voice. 

# What did the woman want him to catch?

The woman wanted him to catch the jackals. 

# To whom did the woman's beloved belong?

Her beloved belonged to her. 

# To whom did the woman belong?

She belonged to her beloved. 

# What did her beloved do among the lilies?

He grazed among the lilies with pleasure. 

# What did she want her beloved to do?

She wanted her beloved to go away. 

# When did she want her beloved to go away?

She wanted her beloved to go away before the soft winds of dawn blew and the shadows fled away. 

# What did she want him to be like?

She wanted him to like a gazelle or a young stag on the rugged mountains. 

# For whom was the woman longing but could not find?

The woman was longing for the one whom she loved but could not find him. 

# For whom was the woman searching through the streets and squares but could not find?

The woman was searching through the streets and squares but could not find her beloved. 

# What did the woman ask the watchmen when they found her?

She asked them, "Have you seen my beloved?" 

# When did she find the one whom her soul loved?

She found the one whom her soul loved a little while after she passed the watchmen in the city. 

# What did she do with her beloved?

She held him and would not let him go until she had brought him into her mother's house. 

# What did the woman want the daughters of Jerusalem's men to promise?

The woman wanted the daughters of Jerusalem's men to promise they would not interrupt their lovemaking until they were finished. 

# What did the young woman see coming from the wilderness that was perfumed with myrrh and frankincense and powders?

She saw the portable litter of Solomon with 60 warriors around it. 

# What did the young woman see coming from the wilderness that was perfumed with myrrh and frankincense and powders?

She saw the portable litter of Solomon with 60 warriors around it. 

# At what were the warriors good?

The warriors were good with the sword and in warfare. 

# What did King Solomon make for himself?

King Solomon made a sedan chair from wood from Lebanon. 

# What did King Solomon's sedan chair look like?

The chair had posts of silver, a back of gold, a seat of purple cloth, and was decorated with love. 

# At what did the young woman want the women of Jerusalem to look?

She wanted them to look at King Solomon. 

# What was King Solomon wearing on his marriage day?

He wore a crown with which his mother crowned him on his marriage day. 

# How did the woman's lover describe her eyes?

Her eyes were as doves behind her veil. 

# How did the woman's lover describe her hair?

Her hair was like a flock of goats going down Mount Gilead. 

# How did her lover describe her teeth.

Her teeth were like newly shorn and washed female sheep. 

# What did the woman's beloved say about her lips and mouth.

He said her lips were like a thread of scarlet and that her mouth was lovely. 

# How did the woman's beloved describe her cheeks. 

He described her cheeks like pomegranate halves behind her veil. 

# How did the woman's beloved describe her neck?

He described her neck as the tower of David built in rows of stone with a thousand soldiers' shields hanging on it. 

# How did the woman's beloved describe her two breasts?

He described her two breasts as two fawns, twins of a gazelle, grazing among the lilies. 

# Where would her lover go until dawn comes and the shadows flee?

He said he would go to the mountain of myrrh and the hill of frankincense. 

# In what way was his love beautiful?

His love was beautiful in every way. 

# What did his beautiful love not have?

His beautiful love did not have any blemish. 

# What did Solomon call his bride? 

Solomon called her his sister. 

# What did Solomon tell his bride she had stolen from him?

He said she had stolen his heart. 

# What did Solomon say was beautiful and what was it better than?

Solomon said her love was beautiful and better than wine. 

# What was the smell of her perfume better than?

The smell of her perfume better than any spice. 

# With what did he say his bride's lips dripped and what was under her tongue?

He said his bride's lips dripped with honey and she had honey and milk under her tongue. 

# What did the woman's clothes smell like?

Her clothes smelled like the fragrance of Lebanon. 

# What kind of garden and what kind of spring did Solomon say his sister, his bride, was like?

Solomon said she was like a garden locked up and a spring that was sealed. 

# To what did he liken the woman's branches? 

He likened her branches to a grove of pomegranate trees with choice fruit and plants and all the finest spices. 

# To what did he liken the woman's branches? 

He likened her branches to a grove of pomegranate trees with choice fruit and plants and all the finest spices. 

# With what kinds of water does Solomon describe his lover?

He described her as a garden spring, a well of fresh water, and streams flowing down from Lebanon. 

# On what does the young woman want the north and south winds to blow and why?

She wanted the north and south winds to blow on her garden so that its spices would give off their fragrance. 

# What did she want her beloved to do and to eat?

She wanted her beloved to come into his garden and to eat some of its choice fruit. 

# Where had Solomon come?

Solomon had come into his garden. 

# Of what was Solomon's bride dreaming?

She was dreaming of her beloved's knocking and talking. 

# What had Solomon's love already done?

She had already taken off her robe and washed her feet. 

# Where had Solomon put his hand?

Solomon had put his hand through the opening of the door latch. 

# With what were the bride's hands dipping when she opened the door?

Her hands were dripping with moist myrrh. 

# What did the bride find when she opened the door and how did she feel?

She found that her beloved had turned and gone, so her heart sank and she became sad. 

# What did the watchmen do when they found Solomon's bride?

They struck and wounded her and took away her cloak. 

# What did the bride ask the women of Jerusalem to promise?

She asked the women of Jerusalem to promise that they would tell her if they found her beloved. 

# How did the young woman's beloved make her feel?

The young woman's beloved made her feel sick with love. 

# What did the young women ask of the bride?

They asked her how and why her beloved is better than another. 

# How did the young woman describe her beloved?

She described him as radiant, ruddy, and outstanding. 

# How did the woman describe her beloved's head and hair?

She described his head as pure gold and his hair as curly and black. 

# How did the woman describe her beloved's eyes? 

She described his eyes like doves washed in milk. 

# How did Solomon's bride describe his cheeks and lips?

She described his cheeks like spice gardens and his lips as myrrh soaked lilies. 

# How did the woman describe her beloved's arms and abdomen?

She described his arms as gold with jewels and his abdomen as ivory covered with sapphires. 

# How did the woman describe her beloved's legs and his appearance?

She described his legs as marble pillars with gold bases and his appearance like Lebanon, as special as the cedars. 

# How did Solomon's bride describe her beloved's mouth and Solomon to Jerusalem's daughters? 

She described his mouth as most sweet and that Solomon was completely lovely. 

# What questions do the women of Jerusalem ask of the young woman? 

They ask her where her beloved has gone and in what direction has he gone? 

# For what did the young women want to seek?

The young women wanted to seek for the young woman's beloved. 

# What does the young woman say her beloved was doing?

The young woman said he was in his spice gardens to graze in the garden and gather lilies? 

# To whom did the young woman and her lover belong?

The young woman and her lover belonged to each other. 

# Where did the young woman's lover graze?

The young woman's lover grazed among the lilies. 

# What two cities did the woman's lover use to describe her?

He described her as two cities, Tirzah and Jerusalem. 

# How did her beloved feel about her?

He felt that she was completely fascinating. 

# Why did the woman's lover want her to turn her eyes away from him?

The woman's lover wanted her to turn her eyes away from him because her eyes overwhelmed him. 

# How did the woman's lover describe her hair?

He described her hair as a flock of goats on the slopes of Mount Gilead. 

# How did her lover describe her teeth? 

He described her teeth as a flock of ewes coming up from the washing place. 

# How did her lover describe her cheeks?

Her lover described her cheeks as pomegranate halves behind her veil. 

# How many other women did the woman's lover say there were?

He said there were 60 queens, 80 concubines, and young women without number. 

# How did the woman's lover describe his dove?

The woman's lover described her as his undefiled, the only one, and the special and favorite daughter of her mother. 

# What did the queens and the concubines say about her when they saw her? 

The queens and concubines praised her. 

# How did the woman's lover describe her?

The woman's lover described her like the dawn, the moon, the sun, and completely fascinating. 

# Why did the woman's lover go into the grove of nut trees?

The woman's lover went into the grove of nut trees to see if the vines had budded and the pomegranates were in bloom. 

# How did the woman's lover feel.

The woman's lover felt as though he were riding in the chariot of a prince. 

# What did the woman's lover want her to do?

The woman's lover wanted her to turn back to him. 

# Why did the woman's lover want her to turn to him?

The woman's lover wanted her to turn to him so that he may gaze on her. 

# What did the young woman say about herself?

The young woman described herself as the perfect woman who seemed to be dancing between two rows of dancers. 

# How did Solomon describe his lover's feet in her sandals and the curves of her thighs?

He described her feet in her sandals as beautiful and the curves of her thighs like jewels. 

# How did Solomon describe his love's navel and belly?

Solomon described his love's navel as a round bowl which never lacks mixed wine and her belly as mound of wheat surrounded with lilies. 

# How did Solomon describe his lover's two breasts?

Solomon described her two breasts like two fawns, twins of a gazelle. 

# How did Solomon describe his lover's neck, eyes, and nose?

Solomon described her neck as an ivory tower, her eyes like a pool, and her nose like the tower in Lebanon. 

# How did Solomon describe his lover's head and hair?

Solomon described her head like Mount Carmel and her hair as dark. 

# How did Solomon describe his lover and her breasts?

He described her as a date palm tree and her breasts as clusters of fruit. 

# What did he also want his lover's breasts and breath to be like?

He also wanted his lover's breasts to be like grape clusters and her breath to be sweet like the smell of apricot fruit. 

# What did he want his lover's mouth to be like?

He wanted her mouth to be like the best wine. 

# To whom did the young woman belong and whom did he desire?

The young woman belonged to her beloved and her beloved desired her. 

# Where did the young woman want her beloved to go with her?

She wanted him to go into the countryside to spend the night in the villages. 

# Why did she want her beloved to rise early?

She wanted him to rise early to see if the vines in the vineyards and the pomegranates had budded. 

# What did she say she would give her beloved when they got to the vineyards?

She said she would give him her love. 

# What did she say the mandrakes would do?

She said the mandrakes would give off their fragrance. 

# What did she say was at the door where she and her lover were staying?

She said that at the door where they were staying there were all sorts of choice fruits, new and old, that she had stored up for him. 

# What did the woman wish that her lover was like and why?

She wished he were like her brother so that she could kiss her lover at any time and no one would despise her. 

# Where would the woman have liked to bring her lover?

She would have liked to bring him to her mother's house so he could teach her. 

# What were her lover's left and right hands doing?

His left hand was holding his head and his right hand is hugging her. 

# What did the woman want Jerusalem's women to promise?

The woman wanted Jerusalem's women to promise that they would not interrupt her and her lover's lovemaking until they were finished. 

# What did the women of Jerusalem ask?

They asked who was coming up from the wilderness, leaning on her beloved. 

# What did the young woman tell her lover when she woke him under the apricot tree?

She told him that his mother had conceived and given birth to him under the apricot tree. 

# What did the young woman want her lover to do and why?

She wanted him to set her as a seal over his heart because love is as strong as death and a hot flame. 

# What couldn't stop love?

Huge amounts of moving water could not stop love. 

# What did the woman's brothers say about their little sister?

They said that her breasts had not yet grown and that they wondered what they would do for her when she was promised in marriage. 

# What would the woman's brothers do if she were a wall?

If she were a wall, they would build a tower of silver on her. 

# What would the woman's brothers do if she were a door?

If she were a door, they would adorn her with boards of cedar. 

# How did the young woman describe herself? 

She described herself as a wall with breasts like fortress towers and completely mature. 

# What did the young woman say that Solomon did with his vineyard at Baal Hamon?

Solomon leased his vineyard to those who would take care of it. 

# What does the young woman say about her own vineyard and those who maintained it?

She said the 1000 shekels that it brought belonged to Solomon and that those who maintained it would get 200 shekels. 

# What did the woman's lover say to her who lived in the gardens about what his friends, as well as he, wanted to hear?

He said that his friends, as well as he, wanted to be the ones to hear her voice. 

# What did the young woman want her beloved to do and be like?

She wanted her beloved to hurry and to be like a deer. 

