# How did Paul become an apostle of Christ Jesus?

Paul became an apostle of Christ Jesus through the will of God. 

# To whom did Paul write this letter?

Paul wrote to those set apart for God and the faithful brothers at Colossae. 

# From where did the Colossians hear about the confident expectation that they now have?

The Colossians heard about their confident expectation in the word of truth, the gospel. 

# What does Paul say the gospel has been doing in the world?

Paul says the gospel has been bearing fruit and growing in all the world. 

# Who presented the gospel to the Colossians?

Epaphras, the faithful servant of Christ, presented the gospel to the Colossians. 

# With what does Paul pray that the Colossians be filled?

Paul prays that the Colossians be filled with the knowledge of God's will in all wisdom and spiritual understanding. 

# How does Paul pray that the Colossians will walk in their lives?

Paul prays that the Colossians will walk worthy of the Lord, bearing fruit with good deeds, growing in the knowledge of God. 

# For what have those set apart for God been qualified?

Those set apart for God have been qualified for a share in the inheritance in light. 

# From what has the Father rescued those set apart for him?

He rescued them from the dominion of darkness and transferred them to the kingdom of his Son. 

# In Christ, we have redemption, which is what?

In Christ we have redemption, which is the forgiveness of sins. 

# The Son is the image of who?

The Son is the image of the invisible God. 

# What was created through Jesus Christ and for him?

All things were created through Jesus Christ and for him. 

# How did God reconcile all things to himself?

God reconciled all things to himself when he made peace through his Son's blood. 

# What relationship did the Colossians have with God before they believed the gospel?

Before believing the gospel, the Colossians were strangers from God and were his enemies. 

# What must the Colossians continue to do?

The Colossians must continue to be settled in the faith and confident of the gospel. 

# For whose sake is Paul suffering, and what is his attitude?

Paul is suffering for the sake of the church, and he rejoices in it. 

# What is the mystery that was hidden for ages but now has been revealed?

The mystery that was hidden for ages but now has been revealed is Christ in you, the confidence of glory. 

# What is the goal of Paul's admonishing and teaching?

Paul's goal is to present every person complete in Christ. 

# What is the mystery of God?

The mystery of God is Christ. 

# What is hidden in Christ?

All the hidden treasures of wisdom and knowledge are hidden in Christ. 

# What is Paul concerned might happen to the Colossians?

Paul is concerned that the Colossians might be deluded with persuasive speech. 

# What does Paul call the Colossians to do now that they have received Christ Jesus?

Paul calls the Colossians to walk in Christ Jesus in the same way that they received him. 

# Upon what are the empty deceits that Paul is concerned about based?

The empty deceits are based upon human tradition and the sinful belief systems of the world. 

# What lives in Christ?

All the fullness of God's nature lives in Christ. 

# Who is the head of all rule and authority?

Christ is the head of all rule and authority. 

# What is removed through the circumcision of Christ?

The sinful body of flesh is removed through the circumcision of Christ. 

# What happens in baptism?

A person is buried with Christ in baptism. 

# What is a person's condition before Christ makes him alive?

A person is dead in his sins before Christ makes him alive. 

# What did Christ do with the record of debts charged against us?

Christ removed the record of debts and nailed it to the cross. 

# What did Christ do with the rulers and authorities?

Christ removed the rulers and authorities, openly exposed them, and led them in a victory procession. 

# What does Paul say are a shadow of the things to come?

Paul says that food, drink, feast days, and Sabbaths are a shadow of the things to come. 

# To what reality do the shadows point?

The shadows point to the reality of Christ. 

# How is the whole body supplied and held together?

The whole body is supplied and held together by the head, Christ. 

# What kinds of commandments does Paul say are part of the world's beliefs?

Commandments to not handle, not taste, and not touch are part of the world's beliefs. 

# What kinds of commandments does Paul say are part of the world's beliefs?

Commandments to not handle, not taste, and not touch are part of the world's beliefs. 

# What kinds of commandments does Paul say are part of the world's beliefs?

Commandments to not handle, not taste, and not touch are part of the world's beliefs. 

# Against what do the rules of man-made religion have no value?

The rules of man-made religion have no value against the indulgence of the flesh. 

# To where has Christ been raised?

Christ has been raised to sit at the right hand of God. 

# What should believers seek and what should they not seek?

Believers should seek the things above, and not the things of the earth. 

# What should believers seek and what should they not seek?

Believers should seek the things above, and not the things of the earth. 

# Where has God put the believer's life?

God has hidden the believer's life in Christ. 

# What will happen to the believer when Christ is revealed?

When Christ is revealed, the believer will also be revealed with him in glory. 

# What must the believer put to death?

The believer must put to death the sinful desires of the earth. 

# What happens to those who are disobedient to God?

The wrath of God comes upon those who are disobedient to God. 

# What are some of the things that Paul says the believers must get rid of, which are part of the old self?

The believers must get rid of wrath, anger, evil intentions, insults, and obscene speech. 

# In whose image is the believer's new self created?

The believer's new self is created in the image of Christ. 

# What are some of the things that Paul says the believers must put on, which are part of the new self?

The believers must put on a heart of compassion, kindness, lowliness, meekness, and patience. 

# In what way should the believer forgive?

The believer should forgive in the same way that the Lord has forgiven him. 

# What is the bond of perfection among believers?

Love is the bond of perfection. 

# What should rule in the believer's heart?

The peace of Christ should rule in the believer's heart. 

# What should the believer give to God in his attitude, song, word, and deed?

In his attitude, song, word, and deed the believer should give thanks to God. 

# What should live in the believer richly?

The word of Christ should live in the believer richly. 

# What should the believer give to God in his attitude, song, word, and deed?

In his attitude, song, word, and deed the believer should give thanks to God. 

# What should the believer give to God in his attitude, song, word, and deed?

In his attitude, song, word, and deed the believer should give thanks to God. 

# How should a wife respond to her husband?

A wife should submit to her husband. 

# How should a husband treat his wife?

A husband should love his wife and not be bitter against her. 

# How should a child treat his parents?

A child should obey his parents in all things. 

# What should a father not do to his children?

A father should not provoke his children. 

# For whom are believers working in whatever they do?

Believers are working for the Lord in whatever they do. 

# For whom are believers working in whatever they do?

Believers are working for the Lord in whatever they do. 

# What will those receive who serve the Lord in whatever they do?

Those who serve the Lord in whatever they do will receive the reward of the inheritance. 

# What will those receive who do unrighteousness?

Those who do unrighteousness will receive the penalty for what they did. 

# What does Paul remind earthly masters that they also have?

Paul reminds earthly masters that they also have a master in heaven. 

# In what does Paul want the Colossians to continue steadfastly?

Paul wants the Colossians to continue steadfastly in prayer. 

# For what does Paul want the Colossians to pray?

Paul wants the Colossians to pray that he has an open door to speak the word, the mystery of Christ. 

# How does Paul instruct the Colossians to treat those who are outsiders?

Paul instructs them to live in wisdom, and speak with grace toward those who are outsiders. 

# How does Paul instruct the Colossians to treat those who are outsiders?

Paul instructs them to live in wisdom, and speak with grace toward those who are outsiders. 

# What task had Paul given Tychicus and Onesimus?

Paul gave them the task of making everything known concerning him to the Colossians. 

# What task had Paul given Tychicus and Onesimus?

Paul gave them the task of making everything known concerning him to the Colossians. 

# What task had Paul given Tychicus and Onesimus?

Paul gave them the task of making everything known concerning him to the Colossians. 

# What instructions did Paul give concerning Mark, the cousin of Barnabus?

Paul told the Colossians to receive Mark if he comes to them. 

# For what does Epaphras pray for the Colossians?

He prays that the Colossians will stand complete and fully assured in all the will of God. 

# What is the name of the physician that is with Paul?

The physician's name is Luke. 

# In what kind of place was the church in Laodicea meeting?

The church in Laodicea was meeting in a house. 

# To what other church had Paul also written a letter?

Paul also had written a letter to the church in Laodicea. 

# How did Paul show that this letter was actually from him?

Paul wrote his name in his own handwriting at the end of the letter. 

