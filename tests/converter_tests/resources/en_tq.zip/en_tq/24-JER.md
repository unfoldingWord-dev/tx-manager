# What kind of work did Jeremiah do?

Jeremiah was a priest. 

# Who was king when the word of Yahweh first came to Jeremiah?

The word of Yahweh came to Jeremiah when Josiah was king. 

# When did Yahweh choose Jeremiah to be a prophet?

Yahweh chose Jeremiah before Jeremiah was born. 

# Why did Jeremiah say he was not qualified?

He said he was very young. 

# What did Yahweh command Jeremiah to say?

Yahweh commanded him to say whatever Yahweh commanded him to say. 

# Why should Jeremiah not be afraid?

He should not be afraid because Yahweh was going to be with him and rescue him. 

# What did Yahweh place in Jeremiah's mouth?

Yahweh placed his word in Jeremiah's mouth. 

# What did Jeremiah see?

He saw an almond branch. 

# What will Yahweh do with his word?

He will carry it out. 

# What was the meaning of the pot that Jeremiah saw?

The pot was a picture of coming disaster. 

# What will all the tribes of the northern kingdom do when Yahweh calls?

They will come and set up thrones all around Jerusalem and Judah. 

# Why will Yahweh pronounce sentence against Jerusalem and Judah?

He will pronounce sentence against them because they have disobeyed him. 

# What will the people do after Jeremiah speaks to them?

The people will fight against him. 

# What does Yahweh remember about the people of Jerusalem?

Yahweh remembers that the people of Jerusalem loved him in the past. 

# What will happen to the people of Israel?

Evil will come on them. 

# What does Yahweh want the house of Jacob to tell him?

Yahweh wants the house of Jacob to tell him what he did that was wrong. 

# What does Yahweh want the house of Jacob to tell him?

Yahweh wants the house of Jacob to tell him what he did that was wrong. 

# What did the people do when God brought them to the land of Carmel?

They defiled the land. 

# For whom did the prophets prophesy?

The prophets prophesied for Baal. 

# For what have Yahweh's people exchanged their glory?

Yahweh's people have exchanged their glory for things that cannot help them. 

# What two evils have Yahweh's people committed?

His people have abandoned the springs of living waters and dug out cisterns. 

# What did Israel's enemies do to Israel?

They made Israel become slaves. 

# What happened to Israel's cities?

His cities are destroyed without any inhabitants. 

# What did the people say after Yahweh broke their yoke and tore their fetters?

They said, "I will not serve!" 

# What animal does Yahweh say the people are like?

He says they are like camels and wild donkeys. 

# What animal does Yahweh say the people are like?

He says they are like camels and wild donkeys. 

# What sin will the house of Israel be ashamed of?

They will be ashamed of worshiping trees and stones. 

# What sin will the house of Israel be ashamed of?

They will be ashamed of worshiping trees and stones. 

# What sin will the house of Israel be ashamed of?

They will be ashamed of worshiping trees and stones. 

# What is Yahweh's declaration?

All of you have sinned against me. 

# Why does Yahweh say he has punished the people in vain?

He has punished them because they do not accept discipline. 

# What have the people done to the innocent and the poor?

They have killed the innocent and the poor. 

# Why do the people think that Yahweh's anger will turn from them?

The people think that they have not sinned. 

# What kind of woman does the prophet compare the people to?

He compares them to a woman who has left her husband. 

# Why did the rains not come?

The rains did not come because the people were not ashamed of their sins. 

# Why did the rains not come?

The rains did not come because the people were not ashamed of their sins. 

# Why did the rains not come?

The rains did not come because the people were not ashamed of their sins. 

# What did Israel do on the mountains and under the trees?

Israel acted like a promiscuous woman by worshiping idols. 

# What did God do to Israel?

He divorced her. 

# What did Judah do after Yahweh divorced Israel?

Judah did the same things Israel had done. 

# What did Judah do after Yahweh divorced Israel?

Judah did the same things Israel had done. 

# What did Judah do after Yahweh divorced Israel?

Judah did the same things Israel had done. 

# What does Yahweh invite Israel to do?

He invites them to return. 

# What must the people do when they return?

They must acknowledge their sin. 

# What will Yahweh give them if they return?

He will give them shepherds after his heart. 

# How will they think about the ark of the covenant?

They will no longer think about it. 

# What will happen in Jerusalem?

All the other nations will gather at Jerusalem. 

# Will Judah and Israel still be enemies?

No, they will come together. 

# How does Yahweh want to honor the people?

He wants to honor them the way a father honors his son. 

# What noise is heard on the plains?

The weeping and pleading of the people of Israel is heard on the plains. 

# What has happened to the things the ancestors worked for?

Idols have consumed the things that the ancestors worked for. 

# What have the people and their ancestors done?

They have not listened to the voice of Yahweh their God. 

# What will happen if Israel returns to Yahweh?

The nations will ask for Yahweh's blessing. 

# What will happen because of the people's wickedness?

Yahweh will be furious with them and bring disaster from the north. 

# What will happen because of the people's wickedness?

Yahweh will be furious with them and bring disaster from the north. 

# What will happen because of the people's wickedness?

Yahweh will be furious with them and bring disaster from the north. 

# What will the lion do to the people?

He will destroy their cities. 

# Why would the people wrap themselves in sackcloth?

They would do it to show that they were sorry for their sins. 

# Why does Jeremiah think Yahweh has deceived the people?

Yahweh has promised the people peace, but someone is attacking them. 

# How can the people of Jerusalem be saved?

They must cleanse their hearts from wickedness. 

# Why are the watchmen coming from a distant land?

They are coming because Judah has rebelled against Yahweh. 

# Why is Jeremiah in anguish?

He hears the alarm for battle. 

# What is the foolishness of the people?

They do not know Yahweh. 

# Why was the land that Jeremiah saw empty?

The land was empty because Yahweh was angry. 

# What will the people in every city do?

They will run away from the attackers and leave the cities empty. 

# What kind of people dress in scarlet and gold jewelry?

Rich people dress this way. 

# What will happen to those who are now rich?

They will be killed. 

# At what point will God forgive Jerusalem?

God will forgive Jerusalem if the prophet can find anyone who is acting justly. 

# Even though God has completely defeated the people, what do they still do?

They still refuse to receive discipline. 

# Why does the prophet say that these are only poor, foolish people?

They do not know Yahweh's ways. 

# Do the important people know Yahweh's ways?

No, they have rebelled against him. 

# What did Jeremiah say about the people's transgressions and acts of faithlessness?

Jeremiah said their transgressions were increasing and their acts of faithlessness were unlimited.  

# What have the people said about God?

They have said that he is not real. 

# What is Yahweh about to do to the house of Israel?

He is about to bring a nation against them from far away. 

# What will the enemies do to the Israelites?

The enemies will kill the Israelites' children and eat their food. 

# Why will God harm Israel and Judah?

He will harm them because they abandoned Yahweh and worshiped foreign gods. 

# What do the eyes and ears of idols do?

They do nothing. 

# What does Yahweh want to do for those who fear him?

He wants to bring the rains at the right time so the harvest can be good. 

# Are the wicked among Yahweh's people rich or poor?

They are rich. 

# Are the wicked among Yahweh's people rich or poor?

They are rich. 

# How will Yahweh treat the wicked?

He will punish them. 

# How do the people feel about what the prophets and priests do?

They love it that way. 

# Why should the people of Benjamin find safety by leaving Jerusalem?

Yahweh will destroy Jerusalem. 

# When will the enemies attack?

They will attack at noon and at night. 

# When will the enemies attack?

They will attack at noon and at night. 

# Why does Yahweh want the enemies to attack Jerusalem?

He wants them to attack because the city is filled with oppression and wickedness. 

# What will happen if Jerusalem does not accept discipline?

Yahweh will destroy Jerusalem. 

# Why can Yahweh not warn the Israelites?

They are not able to pay attention. 

# What will happen to the houses, fields, and women?

They will be turned over to others. 

# How did the people feel when they committed abominations?

They were not ashamed at all. 

# Why is Yahweh about to bring disaster to this people?

They paid no attention to his word or his law. 

# What do the frankincense and sweet smells mean to Yahweh?

They mean nothing to him. He does not like them. 

# What will the stumbling block do to the people?

It will destroy them. 

# What kind of people are coming?

Cruel people, fighting men, are coming. 

# Why should the daughter of the people perform a bitter funeral for herself?

She should do this because the enemy will destroy her people. 

# What will Jeremiah do as a refiner of God's people?

He will inspect and test their ways. 

# What are the people like?

They are stubborn like bronze and iron are hard. 

# What does Yahweh promise to do for the people if they will make their ways and practices good?

He will continue to let them live in that place. 

# What does Yahweh promise to do for the people if they will make their ways and practices good?

He will continue to let them live in that place. 

# What must the people do in order for Yahweh to let them stay in the land?

They must make their ways and practices good by practicing justice. 

# What must the people not do if they want Yahweh to let them stay in the land?

They must not exploit the weak or kill the innocent or worship false gods. 

# What must the people do in order for Yahweh to let them stay in the land?

They must make their ways and practices good by practicing justice. 

# What must the people not do if they want Yahweh to let them stay in the land?

They must not exploit the weak or kill the innocent or worship false gods. 

# What must the people do in order for Yahweh to let them stay in the land?

They must make their ways and practices good by practicing justice. 

# What must the people not do if they want Yahweh to let them stay in the land?

They must not exploit the weak or kill the innocent or worship false gods. 

# What do the people say after they do things they know God hates?

They go to the temple and say that they are saved. 

# Why did Yahweh want the people to think about Shiloh?

He wanted them to remember that he would do to them what he had done to Shiloh because they were guilty of the same sins the people of Shiloh were guilty of. 

# Why did Yahweh want the people to think about Shiloh?

He wanted them to remember that he would do to them what he had done to Shiloh because they were guilty of the same sins the people of Shiloh were guilty of. 

# Why did Yahweh want the people to think about Shiloh?

He wanted them to remember that he would do to them what he had done to Shiloh because they were guilty of the same sins the people of Shiloh were guilty of. 

# Why will Yahweh not listen to Jeremiah's prayers?

He will not listen because he has decided to destroy the Israelites. 

# Why will Yahweh destroy the people?

Because they are worshiping other gods. 

# What command did Yahweh give the people when they left Egypt?

He commanded them to listen to his voice. 

# What did the people do when Yahweh sent prophets?

They did not listen or pay attention. They did evil. 

# What is the prophet to say to them?

He is to say to them that this is a nation that does not listen to the voice of Yahweh. 

# Why does Yahweh tell Jeremiah to shave off all his hair?

Jeremiah was to show that Yahweh had rejected the Israelites. 

# Why did the people build the shrine of Topheth in the valley of Ben Hinnom?

They built it so they could burn their sons and daughters in fire there. 

# What will become of the corpses of this people?

Birds and wild animals will eat them. 

# What will Yahweh do to the cities of Judah and the streets of Jerusalem?

He will make it so there are no happy people there. 

# What will happen to the bones of the people?

People will spread the bones all over the ground. 

# Will those who are alive wish they could live or wish they could die?

They will wish they could die. 

# What do people who are lost try to do?

They try to find a way to return. 

# How did the people feel about their wickedness?

No one was sorry for his wickedness. 

# How are Yahweh's people not like birds?

Birds know what they are supposed to do, but his people do not know Yahweh's decrees. 

# What have the scribes done?

They have written things that deceive the people. 

# What will Yahweh do with their wives and their fields?

He will give their wives and fields to other people. 

# Were the people ashamed because of their sins?

No, they were not ashamed. 

# What will Yahweh do because they were not ashamed?

He will have their enemies kill them. 

# What do the people decide to do?

They decide to go to the cities and die. 

# What will Yahweh's strong horses do?

They will come and consume the land and its wealth, the city and the ones living in it. 

# What is Yahweh sending to harm them?

He is sending snakes to harm them. 

# Where are the people who are screaming?

They are in a land far away. 

# Where is Yahweh?

Yahweh is in Zion. 

# Why does the prophet want to weep?

He wants to weep because so many of his people have been killed. 

Why will Yahweh punish the Israelites?

He will punish the Israelites because they are circumcised only in their body and not in their heart. 

# Why does he want to abandon his people?

He wants to abandon them because they are adulterers and traitors. 

# What do the sinful people say?

They say false things. 

# Why should each of them guard against their neighbors and brothers?

They should guard against them because every brother and neighbor is a deceiver. 

# Why are the people exhausted?

They are exhausted from committing iniquity. 

# Why does Yahweh want to test his people?

He wants to test them because they lie to their neighbors. 

# What will the prophet sing?

He will sing funeral songs and mourning songs for the mountains and the meadows. 

# What will Yahweh make of Jerusalem and Judah?

He will turn them into ruined places. 

# What will the land be like after it has perished?

It will be like the wilderness, and no one will pass through it. 

# What have the people done to displease Yahweh?

They have abandoned his law and they do not listen to him. 

# What does Yahweh say he will do to the Israelites?

He will make them as unhappy as people who have nothing but bitter things to eat and drink. Then he will drive them from their homes and have them killed. 

# What should the women who are skilled at lamenting do?

They should sing sad songs so that the people will cry. 

# What should the women who are skilled at lamenting do?

They should sing sad songs so that the people will cry. 

# How do the wailing people in Zion feel?

They are greatly ashamed. 

# What should the women teach their daughters?

They should teach their daughters a mourning song. 

# Who does the prophet say are going to die?

Children and young men are going to die. 

# In what way will the corpses be like dung and grain stalks?

There will be no one to bury them. 

# What should people be proud of?

People should be proud that they know Yahweh. 

# With what does Yahweh say that he acts?

He acts with covenant loyalty, justice, and righteousness. 

# Why will Yahweh punish the other people?

He will punish them because even their bodies are uncircumcised. 

# What does Yahweh not want the people of Israel to do?

He does not want them to learn the ways of the nations. 

# What does Yahweh not want the people of Israel to do?

He does not want them to learn the ways of the nations. 

# What custom is worthless?

Making an idol is worthless. 

# What custom is worthless?

Making an idol is worthless. 

# Why should the people not fear idols?

Idols cannot do anything either good or bad. 

# Who is like Yahweh?

No one is like Yahweh. 

# What will happen to the gods that did not make the earth?

They will perish. 

# What did the true God do?

He established dry land and spread the heavens. 

# What is the difference idols and the true God?

Idols are not alive, but God made all things. 

# What is the difference idols and the true God?

Idols are not alive, but God made all things. 

# What should the people who have been living under the siege do?

They should gather their bundles and leave the land. 

# Why is there no longer anyone to spread out the prophet's tent?

They have taken his children away from him. 

# Why have the shepherds become stupid?

They do not seek Yahweh. 

# What will happen when the earthquake comes?

The cities of Judah will become ruins. 

# How does the prophet ask Yahweh to discipline him?

He asks Yahweh to discipline him with justice, not in anger. 

# On whom does the prophet ask Yahweh to pour his fury?

He asks Yahweh to pour his fury on the nations that do not know him. 

# Why should they receive Yahweh's fury?

They should receive Yahweh's fury because they have destroyed Jacob and Jacob's land. 

# To whom did Yahweh tell Jeremiah to declare the words of this covenant?

Yahweh said to declare them to each man of Judah and to the inhabitants of Jerusalem. 

# Why would the people be cursed?

They would be cursed if they did not listen to the words of the covenant. 

# To whom was this covenant given?

The covenant was given to Israel's ancestors. 

# When was the covenant given?

It was given the day Yahweh brought the Israelites out of Egypt. 

# What is the oath God swore to the ancestors?

He swore that he would give them the land flowing with milk and honey. 

# Why did God bring all the curses in the covenant against the people?

He brought them because the people did not obey the covenant. 

# Why did God bring all the curses in the covenant against the people?

He brought them because the people did not obey the covenant. 

# What was the conspiracy among the people of Judah and Jerusalem?

They refused to listen to Yahweh and worshiped other gods. 

# When Yahweh brings disaster on the people and they call out to him, how will he answer them?

He will not listen to them. 

# How many incense altars to Baal were made in Jerusalem?

The people made an altar to Baal on every street. 

# Why does Yahweh command Jeremiah not to pray for the people?

He was not to pray because Yahweh would not listen. 

# Why will the people's sacrifices not help them?

The sacrifices cannot help them because they have done evil and then been happy about it. 

# What wicked act have the people committed?

They have given offerings to Baal. 

# What part of man does Yahweh examine?

He examines the heart and the mind. 

# What were the people of Anathoth telling Jeremiah they would do if he kept prophesying in the name of Yahweh?

They said they would kill him. 

# What did Yahweh say would happen to the people who wanted to kill Jeremiah?

He said he would kill their young people by war and famine. 

# What is Jeremiah's complaint about wicked people?

Things go well for them. 

# What is Jeremiah's complaint about wicked people?

Things go well for them. 

# What does Jeremiah want Yahweh to do to the people?

He wants Yahweh to take the people away. 

# Why do the plants wither?

The plants wither because of the people's wickedness. 

# Who has betrayed Jeremiah?

Jeremiah's brothers and his father's family have betrayed him. 

# Why does God hate his people?

They have set themselves against him. 

# What have the shepherds done to the delightful portion?

They have turned it into a wilderness. 

# What have the shepherds done to the delightful portion?

They have turned it into a wilderness. 

# Where in the land is there safety for living creatures?

There is no safety in the land. 

# Why should the workers be ashamed of their gain?

They should be ashamed because of Yahweh's anger. 

# What will happen to the house of Judah when Yahweh has compassion on them?

Yahweh will bring them back to their land. 

# What is Yahweh's promise to those nations who learn to swear, "As Yahweh lives"?

They will be built up in the midst of Yahweh's people. 

# What will happen if those nations do not listen?

Yahweh will uproot them. 

# What does Yahweh tell Jeremiah to do with the linen undergarment?

He tells Jeremiah to put the undergarment on and then take it to the Euphrates and hide it. 

# What does Yahweh tell Jeremiah to do with the linen undergarment?

He tells Jeremiah to put the undergarment on and then take it to the Euphrates and hide it. 

# What does Yahweh tell Jeremiah to do with the linen undergarment?

He tells Jeremiah to put the undergarment on and then take it to the Euphrates and hide it. 

# What does Yahweh tell Jeremiah to do with the linen undergarment?

He tells Jeremiah to put the undergarment on and then take it to the Euphrates and hide it. 

# What was the quality of the undergarment when Jeremiah dug it out from where he had hidden it?

It was no good at all. 

# How are the wicked people like the undergarment?

They are good for nothing because they refuse to listen to Yahweh's word. 

# What three things does Yahweh want his people to bring to him?

He wants them to bring him fame, praise, and honor. 

# What will Yahweh fill all the people with?

He will fill them with drunkenness. 

# What will Yahweh do after he fills the people with drunkenness?

He will destroy them. 

# What will happen if the people do not give honor to Yahweh?

He will bring darkness. 

# Why should the king and queen mother humble themselves?

Their crowns have fallen off. 

# Whom will God place over the people?

He will place over them those whom they had taught to be their friends. 

# Why are bad things happening to the people?"

Bad things are happening because the people have committed many iniquities 

# What will Yahweh do about the bad things the people have done in secret?

He will show them to everyone. 

# What happens when the servants search for water?

They do not find any. 

# What happens when there is no rain?

There is no grass or vegetation. 

# What happens when there is no rain?

There is no grass or vegetation. 

# What happens when there is no rain?

There is no grass or vegetation. 

# When does Yahweh save Israel?

He saves Israel in the time of distress. 

# What does Yahweh tell Jeremiah not to do for the people?

Yahweh tells Jeremiah not to pray for good for the people. 

# From where do the deceitful words of the false prophets come?

They come from the hearts of the false prophets. 

# What will happen to the false prophets?

They will die from war and famine. 

# Where will people die of war?

They will die of war in the fields. 

# Where will people die of famine?

They will die of famine in the city. 

# What does Jeremiah admit to Yahweh is the iniquity of the ancestors?

They had sinned against Yahweh. 

# Why should the people hope in Yahweh?

Yahweh has made the heavens and given the spring rain. 

# What did Yahweh say he would not change even if Moses or Samuel pled for the people?

He would still not be in favor of this people. 

# What will happen to the people of Judah and Jerusalem?

Some will die, some will be killed, some will die from being hungry, and some will be taken far from home. 

# What four things will happen to the people?

Some will die in war, dogs will drag some away, birds will eat some, and beasts will eat some. 

# Who will care about Jerusalem?

No one will care about Jerusalem. 

# What is Yahweh tired of doing for Jerusalem?

He is tired of having mercy on Jerusalem. 

# What will make the mother of seven children ashamed and embarrassed?

Yahweh will have the enemy kill her children. 

# When will Yahweh make Jeremiah's enemies beg for help?

He will make them beg for help in the time of calamity and distress. 

# Why will Yahweh give the people's wealth to their enemies?

He will give it because of all the people's sins. 

# What did Jeremiah do with Yahweh's words?

He consumed them. 

# What does Jeremiah need to do to be restored?

He needs to repent. 

# What kinds of people will Yahweh rescue Jeremiah from?

He will rescue him from the wicked and the tyrant. 

# What command does Yahweh give to Jeremiah?

Yahweh commands Jeremiah not to take a wife. 

# What will happen to the children that are born in that place?

They will all die. 

# What will happen to the children that are born in that place?

They will all die. 

# What will happen to their corpses?

Their corpses will be like dung on the ground and will be food for the birds and beasts. 

# Why does Yahweh command Jeremiah not to go into houses where people are mourning?

He commands Jeremiah because both the great people and the small people will die, but no one will mourn for them. 

# Why does Yahweh command Jeremiah not to go into houses where people are mourning?

He commands Jeremiah because both the great people and the small people will die, but no one will mourn for them. 

# Why does Yahweh command Jeremiah not to go into houses where people are celebrating?

Yahweh commands him because he is going to put an end to celebrations. 

# What will be the people's question when Jeremiah reports his word to them?

The people will ask Jeremiah why Yahweh has decreed disaster against them. 

# Who was more wicked, these people or their ancestors?

These people were more wicked than their ancestors were. 

# Why will Yahweh pay back double Israel's iniquity and sin?

He will do it because they have polluted the land with their idols. 

# What will the nations say about their ancestors when they go to Yahweh?

They will say that their ancestors inherited deceit. 

# Where is the sin of Judah engraved?

It is engraved on their hearts. 

# Where are the people's Asherah poles located?

The Asherah poles are by the leafy trees on the high hills. 

# Where will Judah be enslaved?

Judah will be enslaved in a land that they do not know. 

# Who does Yahweh say is accursed?

Yahweh says that the person who trusts in mankind is accursed. 

# What is the heart like?

The heart is more deceitful than anything else, it is sick, and no one can understand it. 

# What will happen to those who abandon Yahweh?

All who abandon Yahweh will be ashamed and cut off. 

# From what job did Jeremiah not run away?

Jeremiah did not run from being a shepherd following Yahweh. 

# What did Yahweh want Jeremiah to do when he stood by the gates?

He wanted Jeremiah to tell the people to listen to the word of Yahweh. 

# What did Yahweh want the people to stop doing?

He wanted them to stop carrying burdens on the Sabbath. 

# What will happen to the city if the people will listen and not do any work on the Sabbath?

If they will listen and obey, then the city will remain forever. 

# What will happen if the people do not listen?

If the people do not listen, Yahweh will burn Jerusalem up. 

# Where does Yahweh tell Jeremiah to go to hear a word from him?

Yahweh tells Jeremiah to go to the potter's house. 

# What happened to the object of clay that the potter molded while Jeremiah was watching?

It was ruined in his hand. 

# What will Yahweh do to a nation that turns from evil after it hears his proclamation?

He will relent from the disaster that he was planning to bring upon it. 

# What will Yahweh do to a nation that does not listen to his voice?

He will not do the good that he had said he would do for them. 

# Why will Yahweh form disaster against the people of Judah and Jerusalem?

They are doing wicked things. 

# What will the men of Judah and Jerusalem do after Jeremiah warns them?

They will not listen or stop doing evil things. 

# Why will Israel become a horror?

The Israelites have forgotten Yahweh and made offerings to idols. 

# Why will everyone who passes by shudder and shake his head?

They will do that because Yahweh has made the land a horror. 

# What is the people's plot against Jeremiah?

They plan to attack him with their words and no longer pay attention to anything he says. 

# What does Jeremiah ask Yahweh to remember him for?

Jeremiah asks Yahweh to remember how Jeremiah had spoken for the people's welfare. 

# What does Jeremiah ask Yahweh to do to his enemies?

He asks Yahweh to kill all the men and not forgive their sin. 

# What did Yahweh tell Jeremiah to purchase?

He told Jeremiah to go and purchase a potter's clay flask,. 

# What did Yahweh tell Jeremiah he would bring on the kings of Judah and the inhabitants of Jerusalem?

Yahweh said he would bring disaster on that place, and make their ears tingle." 

# Why is God bringing disaster on Jerusalem?

He is bringing disaster because the people have abandoned God and profaned his place, and approached other gods, and filled the place with innocent blood. 

# Why did the people build shrines to Baal?

They built shrines to Baal in order to burn their sons in the fire as burnt offerings to him. 

# What will the Valey of Ben Hinnom be called?

It will be called the Valley of Slaughter. 

# What was Jeremiah to do with the clay flask?

He was to break the clay flask in the sight of the men who went with him. 

# What were the unclean people doing on the rooftops?

The unclean people were worshipping the stars on the rooftops and pouring out drink offerings to other gods. 

# Why did Yahweh bring disaster on the city and all of its towns?

God brought disaster on them because they stiffened their neck and refused to listen to God's words. 

# Why did Yahweh bring disaster on the city and all of its towns?

God brought disaster on them because they stiffened their neck and refused to listen to God's words. 

# Why did Pashur beat Jeremiah and place him in stocks?

He punished Jeremiah because Jeremiah prophesied these words before Yahweh's house. 

# Why did Pashur beat Jeremiah and place him in stocks?

He punished Jeremiah because Jeremiah prophesied these words before Yahweh's house. 

# What will Yahweh give to the king of Babylon?

Yahweh will give him all the wealth of this city and all of its riches, all of its precious items and all the treasures of the kings of Judah. 

# What will happen to Pashur and all the inhabitants of his house?

They will go to Babylon and die there. 

# What happened when Jeremiah tried not to proclaim Yahweh's name anymore?

His word became like a fire in Jeremiah's heart, a burning in his bones, and he could contain it. 

# What message did Jeremiah call out and proclaim?

He called out and proclaimed, "Violence and destruction." 

# What happened when Jeremiah tried not to proclaim Yahweh's name anymore?

His word became like a fire in Jeremiah's heart, a burning in his bones, and he could contain it. 

# What happened when Jeremiah tried not to proclaim Yahweh's name anymore?

His word became like a fire in Jeremiah's heart, a burning in his bones, and he could contain it. 

# What will happen to those who watch for Jeremiah to fall?

They will stagger, they will not defeat him, and they will have unending shame. 

# What will happen to those who watch for Jeremiah to fall?

They will stagger, they will not defeat him, and they will have unending shame. 

# Why does Jeremiah say to sing and praise Yahweh?

Everyone should sing and praise Yahweh because he examines the righteous, sees their mind and heart, does vengeance, and rescues the oppressed person. 

# Why does Jeremiah say to sing and praise Yahweh?

Everyone should sing and praise Yahweh because he examines the righteous, sees their mind and heart, does vengeance, and rescues the oppressed person. 

# How does Jeremiah say about the day he was born?

He curses the day he was born and asks that it not be blessed. 

# What did Pashhur and Zephaniah ask Jeremiah?

They asked him to seek advice from Yahweh. 

# Why did they want Jeremiah to seek advice from Yahweh?

They were hoping Yahweh would do miracles for them. 

# What did Pashhur and Zephaniah ask Jeremiah?

They asked him to seek advice from Yahweh. 

# Why did they want Jeremiah to seek advice from Yahweh?

They were hoping Yahweh would do miracles for them. 

# What is the message that Jeremiah give Zedekiah?

The message is that Yahweh will fight against Zedekiah. 

# What is the message that Jeremiah give Zedekiah?

The message is that Yahweh will fight against Zedekiah. 

# What is the message that Jeremiah give Zedekiah?

The message is that Yahweh will fight against Zedekiah. 

# How will Yahweh fight against King Zedekiah?

Yahweh will fight against King Zedekiah with sickness, war, and hunger. 

# How will Yahweh fight against King Zedekiah?

Yahweh will fight against King Zedekiah with sickness, war, and hunger. 

# What did people who wanted to live need to do?

They needed to go out of the city and surrender to the Chaldeans. 

# What would happen to the people who stayed in the city?

They would die. 

# What did people who wanted to live need to do?

They needed to go out of the city and surrender to the Chaldeans. 

# What would happen to the people who stayed in the city?

They would die. 

# What would happen to the people who stayed in the city?

They would die. 

# What does Yahweh want the king of Judah to do?

He wants the king to listen to Yahweh's word, to bring about justice, and to rescue the oppressed. 

# What does Yahweh want the king of Judah to do?

He wants the king to listen to Yahweh's word, to bring about justice, and to rescue the oppressed. 

# Who is Yahweh against?

Yahweh is against the people who live in the valley and on the plain. 

# What will Yahweh do because of what the people are doing?

He will light a fire in the thickets that will burn everything up. 

# Who is Yahweh against?

Yahweh is against the people who live in the valley and on the plain. 

# What will Yahweh do because of what the people are doing?

He will light a fire in the thickets that will burn everything up. 

# What does Yahweh tell the King of Judah, his servants, and his people to do?

They are to listen to the word of Yahweh, act justly, help those who have been robbed, and rescue the oppressed. They are not to mistreat foreigners, orphans, or widows, and they are not to be violent or kill innocent people. 

# What does Yahweh tell the King of Judah, his servants, and his people to do?

They are to listen to the word of Yahweh, act justly, help those who have been robbed, and rescue the oppressed. They are not to mistreat foreigners, orphans, or widows, and they are not to be violent or kill innocent people. 

# What does Yahweh tell the King of Judah, his servants, and his people to do?

They are to listen to the word of Yahweh, act justly, help those who have been robbed, and rescue the oppressed. They are not to mistreat foreigners, orphans, or widows, and they are not to be violent or kill innocent people. 

# What happens if they do not listen to these words of Yahweh's declaration?

The royal palace will become a ruin. 

# How will the palace become a wilderness?

Yahweh will choose people to come and destroy it. 

# How will the palace become a wilderness?

Yahweh will choose people to come and destroy it. 

# Why has Yahweh done these things to the great city?

He has done them because the people abandoned the covenant and worshiped other gods. 

# Why has Yahweh done these things to the great city?

He has done them because the people abandoned the covenant and worshiped other gods. 

# Why should the people weep for those who go into captivity?

They should weep because the captives will never return or see the land again. 

# What should a good king do?

He should do justice even for the poor and needy, do righteousness, and know Yahweh. 

# What should a good king do?

He should do justice even for the poor and needy, do righteousness, and know Yahweh. 

# Why will the people not lament for king Jehoiakim?

They will not lament because he steals, he kills innocent people, and he oppresses people. 

# What kind of burial will they give Jehoiakim?

They will bury him as they bury donkeys. 

# What has been the custom of the people since they were young?

They have not listened to Yahweh's voice. 

# What will happen to them when they do not listen?

They will lose their shepherds, their friends will become captives, and they will be ashamed and humiliated. 

# What will happen to Jehoiachin?

Yahweh will give Jehoiachin to the king of Babylon, and he will die far away from the land. 

# What will happen to Jehoiachin?

Yahweh will give Jehoiachin to the king of Babylon, and he will die far away from the land. 

# What will happen to Jehoiachin?

Yahweh will give Jehoiachin to the king of Babylon, and he will die far away from the land. 

# What does Yahweh say about Jehoiachin?

Jehoiachin will be childless and will not prosper. 

# What do the shepherds of Jeremiah's day do to the sheep?

The shepherds destroy and scatter the sheep, drive them away, and do not care for them. 

# What do the shepherds of Jeremiah's day do to the sheep?

The shepherds destroy and scatter the sheep, drive them away, and do not care for them. 

# What does Yahweh declare he will do for his flock?

He will gather them, give them a place to graze, and give them good shepherds. 

# What does Yahweh declare he will do for his flock?

He will gather them, give them a place to graze, and give them good shepherds. 

# What will Yahweh do in the coming days?

He will raise up a righteous king. 

# What will Yahweh do in the coming days?

He will raise up a righteous king. 

# What will the people say Yahweh has done for them?

They will say Yahweh has brought them back from other lands so they can live in their own land. 

# What will the people say Yahweh has done for them?

They will say Yahweh has brought them back from other lands so they can live in their own land. 

# Why is Jeremiah's heart broken?

His heart is broken because Yahweh's words are holy, but the prophets are liars and the land is full of adulterers. 

# What will happen to the prophets and priests?

Yahweh will push them down and disaster will come against them. 

# What will happen to the prophets and priests?

Yahweh will push them down and disaster will come against them. 

# What are the offensives of the prophets?

They prophesied by Baal, led Yahweh's people off the right path, committed adultery, deceived the people, and encouraged the people to do evil. 

# What are the offensives of the prophets?

They prophesied by Baal, led Yahweh's people off the right path, committed adultery, deceived the people, and encouraged the people to do evil. 

# What does Yahweh make these prophets do?

He makes them eat wormwood and drink poisonous water. 

# Why does Yahweh say, "Do not listen to the prophets"?

They have lied to the people. 

# Why does Yahweh say, "Do not listen to the prophets"?

They have lied to the people. 

# What is Yahweh's fury like?

His fury is like a storm. 

# What is wrong with the prophets?

Yahweh did not send them. 

# What is wrong with the prophets?

Yahweh did not send them. 

# Where can people go to get away from Yahweh?

There is nowhere people can get away from him. He nearby and far away, he can see in every secret place, and he is everywhere in the heavens and the earth. 

# Where can people go to get away from Yahweh?

There is nowhere people can get away from him. He nearby and far away, he can see in every secret place, and he is everywhere in the heavens and the earth. 

# What do the prophets want the people to do?

They want the people to stop worshiping Yahweh. 

# What do the prophets want the people to do?

They want the people to stop worshiping Yahweh. 

# What do the prophets want the people to do?

They want the people to stop worshiping Yahweh. 

# How is the prophet of Yahweh to declare what he hears from Yahweh?

He is to declare Yahweh's word truthfully and not steal words from other people. 

# How is the prophet of Yahweh to declare what he hears from Yahweh?

He is to declare Yahweh's word truthfully and not steal words from other people. 

# Why is Yahweh against the prophets?

He is against them because they deceive people by saying that their own thoughts are the words of Yahweh. 

# Why is Yahweh against the prophets?

He is against them because they deceive people by saying that their own thoughts are the words of Yahweh. 

# What does Yahweh want Jeremiah to tell those who ask him for a word from Yahweh?

He is to say that there is no word from Yahweh because Yahweh has abandoned the people. 

# Whom will Yahweh punish?

He will punish those who say they have a message from Yahweh. 

# Why must the people not talk to each other about Yahweh's declaration?

They must not do it because each man is using his own words, and they have perverted the words of the living God. 

# Why must the people not talk to each other about Yahweh's declaration?

They must not do it because each man is using his own words, and they have perverted the words of the living God. 

# How does Jeremiah test any prophet?

He asks questions to see if they falsely say that they have received a declaration from Yahweh. 

# How does Jeremiah test any prophet?

He asks questions to see if they falsely say that they have received a declaration from Yahweh. 

# What happens to the prophets who give false reports?

Yahweh will throw them away and put everlasting shame on them. 

# What happens to the prophets who give false reports?

Yahweh will throw them away and put everlasting shame on them. 

# What is the vision Yahweh gave Jeremiah?

Yahweh showed him a basket of very good figs and a basket of very bad figs. 

# What is the vision Yahweh gave Jeremiah?

Yahweh showed him a basket of very good figs and a basket of very bad figs. 

# What is the vision Yahweh gave Jeremiah?

Yahweh showed him a basket of very good figs and a basket of very bad figs. 

# Who are the people Yahweh says are like the good figs?

Yahweh says the exiles are like the good figs. 

# Who are the people Yahweh says are like the good figs?

Yahweh says the exiles are like the good figs. 

# What will Yahweh do to the people who are like the good figs?

He will restore them to the land 

# Who are the people Yahweh says are like the bad figs?

Zedekiah, the people who remain in the land, and the people who go to Egypt are like the bad figs. 

# What will Yahweh do to the people he says are like the bad figs?

He will make things go badly for them, and he will kill them by war, famine, and sickness. 

# What will Yahweh do to the people he says are like the bad figs?

He will make things go badly for them, and he will kill them by war, famine, and sickness. 

# What will Yahweh do to the people he says are like the bad figs?

He will make things go badly for them, and he will kill them by war, famine, and sickness. 

# Who did Jeremiah the prophet proclaim this word to?

He proclaimed the word to all the people of Judah and all the inhabitants of Jerusalem. 

# Who did Jeremiah the prophet proclaim this word to?

He proclaimed the word to all the people of Judah and all the inhabitants of Jerusalem. 

# How long had Jeremiah been proclaiming Yahweh's words?

He had been proclaiming them for 23 years. 

# How had the people received the words Jeremiah had proclaimed?

They had not listened. 

# How long had Jeremiah been proclaiming Yahweh's words?

He had been proclaiming them for 23 years. 

# What did the prophets tell each man?

They told each man to turn from his wicked way, not to worship other gods, and not to provoke Yahweh with what they did. 

# What did the prophets tell each man?

They told each man to turn from his wicked way, not to worship other gods, and not to provoke Yahweh with what they did. 

# What harm did Yahweh do because they did not listen?

Yahweh sent the people of the north with Nebuchadnezzar to destroy them. 

# What harm did Yahweh do because they did not listen?

Yahweh sent the people of the north with Nebuchadnezzar to destroy them. 

# What harm did Yahweh do because they did not listen?

Yahweh sent the people of the north with Nebuchadnezzar to destroy them. 

# What sounds will disappear from these nations when they serve the king of Babylon for seventy years?

The sound of celebration and the sound of work will disappear. 

# What sounds will disappear from these nations when they serve the king of Babylon for seventy years?

The sound of celebration and the sound of work will disappear. 

# What will happen in seventy years?

Yahweh will punish the people of Babylon for their iniquity. 

# What will happen in seventy years?

Yahweh will punish the people of Babylon for their iniquity. 

# What will happen in seventy years?

Yahweh will punish the people of Babylon for their iniquity. 

# What will all the nations do when Yahweh gives them his cup of fury?

They will drink it, stumble about, and rant madly. 

# What will all the nations do when Yahweh gives them his cup of fury?

They will drink it, stumble about, and rant madly. 

# What happened after Jerusalem, the cities of Judah, and her kings and officials drank from the cup that Jeremiah gave them?

They turned into ruins. 

# What happened after Jerusalem, the cities of Judah, and her kings and officials drank from the cup that Jeremiah gave them?

They turned into ruins. 

# What was the final nation to drink of the cup of Yahweh's fury? 

Babylon was the last to drink of the cup of Yahweh's fury. 

# What will happen if the nations refuse to take the cup from Jeremiah's hand?

They will be punished anyway. 

# What will happen if the nations refuse to take the cup from Jeremiah's hand?

They will be punished anyway. 

# What will happen if the nations refuse to take the cup from Jeremiah's hand?

They will be punished anyway. 

# Whom will the disaster from Yahweh kill?

It will kill everyone from one end of the earth to the other. 

# Whom will the disaster from Yahweh kill?

It will kill everyone from one end of the earth to the other. 

# Why are the shepherds wailing?

It is their day to die. 

# Why are the shepherds wailing?

It is their day to die. 

# Why are the shepherds wailing?

It is their day to die. 

# Why were the peaceful pastures destroyed?

Yahweh was angry. 

# Why were the peaceful pastures destroyed?

Yahweh was angry. 

# What does Yahweh tell Jeremiah to proclaim in the courtyard?

He tells him to proclaim all of Yahweh's words. 

# What does Yahweh tell Jeremiah to proclaim in the courtyard?

He tells him to proclaim all of Yahweh's words. 

# What can the people do to get Yahweh not to bring disaster on them?

If the people listen and turn from their wicked ways, Yahweh will not bring disaster on them. 

# If the people do not listen to the words of Yahweh, what will Yahweh do to their city?

Yahweh will turn their city into a curse. 

# If the people do not listen to the words of Yahweh, what will Yahweh do to their city?

Yahweh will turn their city into a curse. 

# If the people do not listen to the words of Yahweh, what will Yahweh do to their city?

Yahweh will turn their city into a curse. 

# What happens to Jeremiah after he announces Yahweh's words?

The priests, prophets, and people seize him and tell him he will die. 

# What happens to Jeremiah after he announces Yahweh's words?

The priests, prophets, and people seize him and tell him he will die. 

# What happens to Jeremiah after he announces Yahweh's words?

The priests, prophets, and people seize him and tell him he will die. 

# Where do the people take him to judge him?

They take him to the gateway of the New Gate of the temple. 

# Where do the people take him to judge him?

They take him to the gateway of the New Gate of the temple. 

# Where do the people take him to judge him?

They take him to the gateway of the New Gate of the temple. 

# What will happen if the officials kill Jeremiah?

If they kill him, they will be guilty of killing an innocent man. 

# What will happen if the officials kill Jeremiah?

If they kill him, they will be guilty of killing an innocent man. 

# What will happen if the officials kill Jeremiah?

If they kill him, they will be guilty of killing an innocent man. 

# What do the officials, people, and elders say about killing Jeremiah?

They say that it would be wrong to kill him. 

# What do the officials, people, and elders say about killing Jeremiah?

They say that it would be wrong to kill him. 

# What did Micah prophesy?

Micah prophesied that Zion, Jerusalem, and the temple mount would become ruins. 

# What does the king try to do to Uriah?

The king tries to kill Uriah. 

# What does Uriah do?

He goes to Egypt. 

# How was Jehoiakim able to kill Uriah?

Jehoiakim sent men to Egypt to bring Uriah back, then Jehoiakim killed Uriah with the sword. 

# How was Jehoiakim able to kill Uriah?

Jehoiakim sent men to Egypt to bring Uriah back, then Jehoiakim killed Uriah with the sword. 

# Who keeps Jeremiah from being killed?

Ahikam son of Shaphan keeps Jeremiah from being killed. 

# Which kings does Jeremiah get a word from Yahweh for?

He gets a message for the kings of Edom, Moab, Ammon, Tyre, and Sidon. 

# Which kings does Jeremiah get a word from Yahweh for?

He gets a message for the kings of Edom, Moab, Ammon, Tyre, and Sidon. 

# What is the message for the kings?

All their nations will serve Nebuchadnezzar, king of Babylon. 

# What is the message for the kings?

All their nations will serve Nebuchadnezzar, king of Babylon. 

# What is the message for the kings?

All their nations will serve Nebuchadnezzar, king of Babylon. 

# What will happen to the nations that do not serve Nebuchadnezzar?

Yahweh will punish nations that do not serve Nebuchadnezzar with sword, famine, and plague. 

# What will happen to the people who listen to deceitful prophecy?

Yahweh will send them away from their land, and they will die. 

# What will happen to the people who listen to deceitful prophecy?

Yahweh will send them away from their land, and they will die. 

# What will the nation that takes the yoke of the king of Babylon receive?

They will stay in their land, cultivate it, and make homes. 

# What does King Zedekiah need to do if he wants to live?

He needs to serve the King of Babylon. 

# What will happen to Zedekiah if he listens to his prophets?

Yahweh will drive him out and he will die. 

# What will happen to Zedekiah if he listens to his prophets?

Yahweh will drive him out and he will die. 

# What does Jeremiah say to the priests and the people?

They are not to listen to the prophets. They are to serve the king of Babylon and live. 

# What does Jeremiah say to the priests and the people?

They are not to listen to the prophets. They are to serve the king of Babylon and live. 

# What did Nebuchadnezzar take from Judah and Jerusalem?

He took Jehoiachin and all the nobles. 

# What did Nebuchadnezzar take from Judah and Jerusalem?

He took Jehoiachin and all the nobles. 

# What will happen to the objects in the temple?

Nebuchadnezzar will take them to Babylon. 

# What will happen to the objects in the temple?

Nebuchadnezzar will take them to Babylon. 

# Briefly what did Hananiah say to Jeremiah in front of the priests and people?

Hananiah said that Yahweh had broken the yoke imposed by the king of Babylon. 

# Briefly what did Hananiah say to Jeremiah in front of the priests and people?

Hananiah said that Yahweh had broken the yoke imposed by the king of Babylon. 

# How does one know if a prophet is a true prophet sent by Yahweh?

The prophet's words will come true. 

# Why does Hananiah break the yoke off Jeremiah?

He wants the people to believe that they will be free from Babylon. 

# Why does Hananiah break the yoke off Jeremiah?

He wants the people to believe that they will be free from Babylon. 

# Are Hananiah's words true?

No, the people will not be free from Babylon. 

# Are Hananiah's words true?

No, the people will not be free from Babylon. 

# Are Hananiah's words true?

No, the people will not be free from Babylon. 

# What is Yahweh's message through Jeremiah to Hananiah?

Yahweh will kill Hananiah this year because Hananiah told the people to rebel against Yahweh. 

# What is Yahweh's message through Jeremiah to Hananiah?

Yahweh will kill Hananiah this year because Hananiah told the people to rebel against Yahweh. 

# What is Yahweh's message through Jeremiah to Hananiah?

Yahweh will kill Hananiah this year because Hananiah told the people to rebel against Yahweh. 

# Who did Jeremiah send his scroll to?

It was sent to all the people exiled to Babylon. 

# Why did Yahweh tell the captives to seek the peace of the city where they were exiled and to intercede with Yahweh on behalf of that city?

He told them to do this because the exiles would have peace if the city was at peace. 

# What is Yahweh's warning through Jeremiah to the captives?

He warns them not to listen to dreams or to prophets whom Yahweh did not send. 

# What is Yahweh's warning through Jeremiah to the captives?

He warns them not to listen to dreams or to prophets whom Yahweh did not send. 

# What is Yahweh's plan for the captives after seventy years?

He will bring them back to Judah and give them peace. 

# What is Yahweh's plan for the captives after seventy years?

He will bring them back to Judah and give them peace. 

# When will they find Yahweh?

They will find him when they call to him, pray to him, and seek him with all their heart. 

# When will they find Yahweh?

They will find him when they call to him, pray to him, and seek him with all their heart. 

# When will they find Yahweh?

They will find him when they call to him, pray to him, and seek him with all their heart. 

# What was Yahweh going to do to the people who stayed in the city and did not go out into captivity?

Yahweh said he was about to send sword, famine, and disease on them. 

# What was Yahweh going to do to the people who stayed in the city and did not go out into captivity?

Yahweh said he was about to send sword, famine, and disease on them. 

# What does Yahweh say he will do to Ahab and Zedekiah?

He will hand them over to Nebuchadnezzar, who will kill them. 

# What does Yahweh say he will do to Ahab and Zedekiah?

He will hand them over to Nebuchadnezzar, who will kill them. 

# What curse will the captives of Judah in Babylon speak?

They will say, "May Yahweh make you like Zedekiah and Ahab, whom the king of Babylon roasted in fire." 

# Why will Yahweh have Ahab and Zedekiah killed?

He will have them killed because of the shameful things they did. 

# Where was Shemaiah when he wrote the letters?

He was in Babylon. 

# Where were the people to whom Shemaiah wrote the letters?

They were in Jerusalem. 

# What did Shemaiah want Zephaniah to do?

He wanted Zephaniah to make prisoners of the prophets. 

# Why did Shemaiah want Zephaniah to rebuke Jeremiah?

Jeremiah had said that the people would be in Babylon for a long time. 

# Why will Yahweh punish Shemaiah and his descendants?

He will do it because Shemaiah prophesied lies to the people so they would rebel against Yahweh. 

# Why will Yahweh punish Shemaiah and his descendants?

He will do it because Shemaiah prophesied lies to the people so they would rebel against Yahweh. 

# What will Yahweh do for his people?

He will restore their fortunes and bring them back to the land. 

# What will Yahweh do for his people?

He will restore their fortunes and bring them back to the land. 

# What will Yahweh do for his people?

He will restore their fortunes and bring them back to the land. 

# Who heard the "trembling voice of dread"?

Yahweh, speaking of himself as "we," was the one who heard the voice. 

# Who heard the "trembling voice of dread"?

Yahweh, speaking of himself as "we," was the one who heard the voice. 

# Why do the young men have their hands on their loins and have pale faces?

The descendants of Jacob will have a time of anxiety. 

# Why do the young men have their hands on their loins and have pale faces?

The descendants of Jacob will have a time of anxiety. 

# How will the Israelites celebrate being freed from enslavement?

They will worship Yahweh their God and serve David their king. 

# How will the Israelites celebrate being freed from enslavement?

They will worship Yahweh their God and serve David their king. 

# Why should the descendants of Jacob not be dismayed?

Yahweh will bring them back from where he had scattered them to be captives. 

# How can Israel's wound be cured?

It cannot be healed. 

# How can Israel's wound be cured?

It cannot be healed. 

# Why does Yahweh discipline the Israelites?

Yahweh disciplines the Israelites because of their iniquities and sins. 

# Why does Yahweh discipline the Israelites?

Yahweh disciplines the Israelites because of their iniquities and sins. 

# What will Yahweh do to those who harmed Israel?

He will have their enemies consume and capture and plunder them. 

# What will Yahweh do to those who harmed Israel?

He will have their enemies consume and capture and plunder them. 

# What will Yahweh do for Israel?

Yahweh will heal Israel's wounds. 

# What will the people do after the city has been rebuilt?

They will sing songs of praise, they will increase in number, and Yahweh will honor them. 

# What will Yahweh do after he establishes Israel's assembly?

He will appoint a leader for Israel. 

# What will Yahweh do after he establishes Israel's assembly?

He will appoint a leader for Israel. 

# Whose God will Yahweh be?

He will be the God of all the clans of Israel. 

# Why did the people of Israel who survived the sword find Yahweh's favor?

They found favor because Yahweh loved them with an everlasting love. 

# Why did the people of Israel who survived the sword find Yahweh's favor?

They found favor because Yahweh loved them with an everlasting love. 

# What will virgin Israel do after Yahweh builds her up?

She will go out with happy dances and have good crops. 

# What will virgin Israel do after Yahweh builds her up?

She will go out with happy dances and have good crops. 

# Whom has Yahweh rescued?

He has rescued the remnant of Israel. 

# Where will Yahweh bring the remnant of Israel back from?

He will bring them back from the northern lands and the farthest parts of the earth. 

# Who is "the one who scattered Israel"?

Yahweh scattered Israel. 

# Who is "the one who scattered Israel"?

Yahweh scattered Israel. 

# What will be the signs of Yahweh's goodness?

The people will have plenty of food, wine, oil, and livestock. 

# What will the people do when they stop mourning?

They will celebrate 

# Why is there wailing and bitter weeping in Ramah?

There is wailing and weeping because Rachel's children have died. 

# Why should the people stop weeping?

Yahweh will bring their descendants back from the enemy's land. 

# Why should the people stop weeping?

Yahweh will bring their descendants back from the enemy's land. 

# Why will Yahweh have compassion on Ephraim?

He will have compassion because Ephraim was ashamed of his sins. 

# Why will Yahweh have compassion on Ephraim?

He will have compassion because Ephraim was ashamed of his sins. 

# Why will Yahweh have compassion on Ephraim?

He will have compassion because Ephraim was ashamed of his sins. 

# Why will the people say, "May Yahweh bless you"?

They will say that because people will live in the cities and farmers and shepherds will live in the country. 

# What will Yahweh do to the houses of Israel and Judah that he uprooted and tore down?

Yahweh will watch over them so he can build them up and plant them. 

# What will Yahweh do to the houses of Israel and Judah that he uprooted and tore down?

Yahweh will watch over them so he can build them up and plant them. 

# What is the saying that the people of Israel and Judah will no longer use?

The saying is, "Fathers have eaten sour grapes and the children's teeth are dulled." 

# What is the saying that the people of Israel and Judah will no longer use?

The saying is, "Fathers have eaten sour grapes and the children's teeth are dulled." 

# Why will the people no longer use that saying?

Each man will die for his own sin. 

# What is the new covenant that Yahweh will establish with the house of Israel and Judah?

The new covenant is this: Yahweh will write his law on their hearts. 

# What is the new covenant that Yahweh will establish with the house of Israel and Judah?

The new covenant is this: Yahweh will write his law on their hearts. 

# Israel will be a nation as long as what has not vanished?

They will be a nation as long as the sun, moon, stars, and sea have not vanished. 

# Israel will be a nation as long as what has not vanished?

They will be a nation as long as the sun, moon, stars, and sea have not vanished. 

# Yahweh will reject Israel's descendants only when what two things have happened?

They will be a nation as long as no one has measured the highest heavens or discovered the earth's foundation. 

# When the city is rebuilt, will it be bigger or smaller than it was?

It will be bigger. 

# When the city is rebuilt, will it be bigger or smaller than it was?

It will be bigger. 

# When the city is rebuilt, will it be bigger or smaller than it was?

It will be bigger. 

# Where was Jeremiah when Yahweh gave a message to him?

Jeremiah was imprisoned in the courtyard of the house of the king of Judah. 

# Where was Jeremiah when Yahweh gave a message to him?

Jeremiah was imprisoned in the courtyard of the house of the king of Judah. 

# What was the Babylonian army doing?

It was attacking Jerusalem. 

# Why did Zedekiah imprison Jeremiah?

Zedekiah imprisoned him because Jeremiah prophesied that Jerusalem and Zedekiah would be captured by the Babylonians. 

# Why did Zedekiah imprison Jeremiah?

Zedekiah imprisoned him because Jeremiah prophesied that Jerusalem and Zedekiah would be captured by the Babylonians. 

# Why did Zedekiah imprison Jeremiah?

Zedekiah imprisoned him because Jeremiah prophesied that Jerusalem and Zedekiah would be captured by the Babylonians. 

# What did Yahweh say, to Jeremiah, was going to happen?

Yahweh told Jeremiah that Hanamel son of Shallum your uncle was coming to Jeremiah and would say, "Buy my field that is in Anathoth for yourself, for the right to buy it belongs to you.". 

# What did Yahweh say, to Jeremiah, was going to happen?

Yahweh told Jeremiah that Hanamel son of Shallum your uncle was coming to Jeremiah and would say, "Buy my field that is in Anathoth for yourself, for the right to buy it belongs to you.". 

# How did Jeremiah go about buying the field?

Jeremiah signed and sealed the deed of purchase, weighed the silver in the scales, and gave the sealed scroll to Baruch in the presence of the witnesses. 

# How did Jeremiah go about buying the field?

Jeremiah signed and sealed the deed of purchase, weighed the silver in the scales, and gave the sealed scroll to Baruch in the presence of the witnesses. 

# How did Jeremiah go about buying the field?

Jeremiah signed and sealed the deed of purchase, weighed the silver in the scales, and gave the sealed scroll to Baruch in the presence of the witnesses. 

# What did Jeremiah tell Baruch to do with the sealed scroll?

Jeremiah told Baruch to take the scrolls with the receipt of the purchase and place them in a new jar. 

# What did Jeremiah tell Baruch to do with the sealed scroll?

Jeremiah told Baruch to take the scrolls with the receipt of the purchase and place them in a new jar. 

# What message of hope did Yahweh want to give through this purchase of land?

Yahweh wanted all the people to know that people would again buy houses, fields, and vineyards in the land. 

# How did Yahweh make the heavens and the earth?

He made the heavens and the earth by his great strength and with his raised arm. 

# How did Yahweh make the heavens and the earth?

He made the heavens and the earth by his great strength and with his raised arm. 

# How did Yahweh make his name famous?

He brought the people of Israel out of the land of Egypt. 

# What did the people of Israel do after Yahweh gave them the land?

They did not obey him. 

# What did Yahweh tell Jeremiah to do when the city of Jerusalem was being given into the hand of the Babylonians?

He told him to buy a field. 

# Why will Nebuchadnezzar be able to capture the city?

Yahweh will give him the city. 

# How long had Jerusalem been a provocation to Yahweh?

Jerusalem had been a provocation of Yahweh's wrath since the day that they built it. 

# How long had Jerusalem been a provocation to Yahweh?

Jerusalem had been a provocation of Yahweh's wrath since the day that they built it. 

# What did the people of Israel do to provoke Yahweh?

They turned their backs on Yahweh, placed wicked things in the temple, built shrines for Baal, and sacrificed their children to Molech. 

# What did the people of Israel do to provoke Yahweh?

They turned their backs on Yahweh, placed wicked things in the temple, built shrines for Baal, and sacrificed their children to Molech. 

# What did the people of Israel do to provoke Yahweh?

They turned their backs on Yahweh, placed wicked things in the temple, built shrines for Baal, and sacrificed their children to Molech. 

# What does Yahweh promise to do for the people of Judah even though they have been wicked?

He promises to gather them from where they are and bring them back to the land. 

# What does Yahweh promise to do for the people of Judah even though they have been wicked?

He promises to gather them from where they are and bring them back to the land. 

# How will Yahweh provide for the people of Judah?

He will give them one heart and one way to honor him, and he will establish a perpetual covenant with them. 

# How will Yahweh provide for the people of Judah?

He will give them one heart and one way to honor him, and he will establish a perpetual covenant with them. 

# How will Yahweh provide for the people of Judah?

He will give them one heart and one way to honor him, and he will establish a perpetual covenant with them. 

# Just as Yahweh brought disaster on his people, what else was he going to do with them in the future?

Yahweh said he would bring on them all the good things that he had said he would do for them. 

# What does Yahweh tell Jeremiah to do?

Yahweh tells Jeremiah to call to him. 

# What does Yahweh tell Jeremiah to do?

Yahweh tells Jeremiah to call to him. 

# What does Yahweh tell Jeremiah to do?

Yahweh tells Jeremiah to call to him. 

# What are the Chaldeans (Babylonians) going to do to the houses in the city?

They are going to fill the houses with corpses. 

# What are the Chaldeans (Babylonians) going to do to the houses in the city?

They are going to fill the houses with corpses. 

# What good news does Jeremiah share with the people of Judah?

Yahweh will pardon all the iniquities of the people, heal them, and give them peace. 

# What good news does Jeremiah share with the people of Judah?

Yahweh will pardon all the iniquities of the people, heal them, and give them peace. 

# What good news does Jeremiah share with the people of Judah?

Yahweh will pardon all the iniquities of the people, heal them, and give them peace. 

# What will the city of Jerusalem become for Yahweh?

Jerusalem will become for Yahweh an object of joy. 

# How will the cities of Judah change?

The cities are desolate now, but shepherds will lead their flocks in them. 

# How will the cities of Judah change?

The cities are desolate now, but shepherds will lead their flocks in them. 

# What has Yahweh promised to do for the people of Judah and Jerusalem?

Yahweh has promised to make a descendant of David their king so that he can carry out justice and righteousness in the land. 

# What has Yahweh promised to do for the people of Judah and Jerusalem?

Yahweh has promised to make a descendant of David their king so that he can carry out justice and righteousness in the land. 

# What has Yahweh promised to do for the people of Judah and Jerusalem?

Yahweh has promised to make a descendant of David their king so that he can carry out justice and righteousness in the land. 

# What does Yahweh promise Jeremiah?

He promises that there will always be a man from David's line to rule Israel and a Leviticus priest to offer sacrifices. 

# What does Yahweh promise Jeremiah?

He promises that there will always be a man from David's line to rule Israel and a Leviticus priest to offer sacrifices. 

# When will Yahweh break his covenant with David?

He will never break it. 

# When will Yahweh break his covenant with David?

He will never break it. 

# How many descendants will David have?

David will have more descendants than anyone can count. 

# What have the people declared about Yahweh's punishment of Judah?

The people have declared that Yahweh has now rejected the two clans that he chose, so they are no longer a nation. 

# What have the people declared about Yahweh's punishment of Judah?

The people have declared that Yahweh has now rejected the two clans that he chose, so they are no longer a nation. 

# When will Yahweh reject the descendants of Jacob?

He will never reject them. 

# When will Yahweh reject the descendants of Jacob?

He will never reject them. 

# When did Jeremiah receive the word from Yahweh?

Jeremiah received Yahweh's word when Nebuchadnezzar king of Babylon and all of his army were waging war against Jerusalem and her cities. 

# What did Yahweh say to Jeremiah?

He said that he was going to give the city to Nebuchadnezzar. 

# What did Yahweh say to Jeremiah?

He said that he was going to give the city to Nebuchadnezzar. 

# What did Yahweh tell Zedekiah king of Judah?

He told Zedekiah that he would die in peace. 

# What did Yahweh tell Zedekiah king of Judah?

He told Zedekiah that he would die in peace. 

# What happened after the leaders and the people in Jerusalem set the Israelite servants free?

The people freed all of their servants but later changed their minds and made their servants slaves once again. 

# What happened after the leaders and the people in Jerusalem set the Israelite servants free?

The people freed all of their servants but later changed their minds and made their servants slaves once again. 

# What did Yahweh command the ancestors of the Israelites to do every seven years?

He commanded them to free their slaves every seven years. 

# What did Yahweh command the ancestors of the Israelites to do every seven years?

He commanded them to free their slaves every seven years. 

# What did Yahweh command the ancestors of the Israelites to do every seven years?

He commanded them to free their slaves every seven years. 

# What evil did the people of Judah do?

They set their slaves free, but then they forced them to become slaves again. 

# What evil did the people of Judah do?

They set their slaves free, but then they forced them to become slaves again. 

# How will Yahweh punish them?

They will die by the sword, plague, and famine. 

# How did the people show that they agreed to the covenant?

They cut a bull in half and walked between the pieces. 

# How did the people show that they agreed to the covenant?

They cut a bull in half and walked between the pieces. 

# How will Yahweh show he is angry with the people of Judah?

He will hand them over to their enemies, who will kill them. 

# What will happen to the city of Jerusalem?

Yahweh will bring the army of the king of Babylon back to wage war against Jerusalem and burn it so that there will be no inhabitants. 

# What will happen to the city of Jerusalem?

Yahweh will bring the army of the king of Babylon back to wage war against Jerusalem and burn it so that there will be no inhabitants. 

# What did Yahweh ask Jeremiah to do?

Yahweh asked Jeremiah to bring Rechabites to the temple and give them wine to drink. 

# What did Yahweh ask Jeremiah to do?

Yahweh asked Jeremiah to bring Rechabites to the temple and give them wine to drink. 

# How did the clan of the Rechabites respond when they were offered wine to drink?

When offered wine to drink the Rechabites refused to drink it. 

# How did the clan of the Rechabites respond when they were offered wine to drink?

When offered wine to drink the Rechabites refused to drink it. 

# Why did the Rechabites refuse to drink wine?

The Rechabites refused to drink any wine, for their ancestor, Jonadab son of Rechab, commanded them, 'Do not drink any wine, neither you nor your descendants, forever. 

# Why did Jonadab command the Rechabites to not build houses, sow seeds, or plant vineyards?

Jonadab gave them this command because they were to live in tents. 

# How did the Rechabites respond to Jonadab's command?

The Rechabites had never drunk wine or built houses. 

# How did the Rechabites respond to Jonadab's command?

The Rechabites had never drunk wine or built houses. 

# How did the Rechabites respond to Jonadab's command?

The Rechabites had never drunk wine or built houses. 

# How did the Rechabites respond to Jonadab's command?

The Rechabites had never drunk wine or built houses. 

# Why were the Rechabites living in Jerusalem

They were escaping the Chaldean and Aramean armies. 

# How did Yahweh use the Rechabites as a positive example for the men of Judah?

Yahweh wanted the men of Judah to obey him the same way the Rechabites obeyed Jonadab. 

# How did Yahweh use the Rechabites as a positive example for the men of Judah?

Yahweh wanted the men of Judah to obey him the same way the Rechabites obeyed Jonadab. 

# How did Yahweh use the Rechabites as a positive example for the men of Judah?

Yahweh wanted the men of Judah to obey him the same way the Rechabites obeyed Jonadab. 

# What did the prophets tell the men of Judah?

The prophets told them to stop doing evil, start doing good, stop worshiping other gods, and come back to the land. 

# What will Yahweh do because the men of Judah have not obeyed him?

Yahweh will bring on them all the disasters he has proclaimed against them. 

# What promise does Yahweh give to the family of the Rechabites through Jeremiah?

Yahweh promises that there will always be someone from their family to serve him. 

# What promise does Yahweh give to the family of the Rechabites through Jeremiah?

Yahweh promises that there will always be someone from their family to serve him. 

# Why did Yahweh want Jeremiah to write his words on a scroll?

Yahweh wanted Jeremiah to write his words on a scroll so that the people of Judah would listen to Yahweh and Yahweh could forgive their sin. 

# Why did Yahweh want Jeremiah to write his words on a scroll?

Yahweh wanted Jeremiah to write his words on a scroll so that the people of Judah would listen to Yahweh and Yahweh could forgive their sin. 

# Why did Yahweh want Jeremiah to write his words on a scroll?

Yahweh wanted Jeremiah to write his words on a scroll so that the people of Judah would listen to Yahweh and Yahweh could forgive their sin. 

# What did Jeremiah command Baruch to do?

Jeremiah commanded Baruch to take the scroll with Jeremiah's words and read it to Baruch's family and to the people of Judah. 

# What did Jeremiah command Baruch to do?

Jeremiah commanded Baruch to take the scroll with Jeremiah's words and read it to Baruch's family and to the people of Judah. 

# What did Jeremiah command Baruch to do?

Jeremiah commanded Baruch to take the scroll with Jeremiah's words and read it to Baruch's family and to the people of Judah. 

# Why did Jeremiah want Baruch to read the scroll?

Jeremiah hoped that the people would listen and turn from their wicked ways. 

# Why did Jeremiah want Baruch to read the scroll?

Jeremiah hoped that the people would listen and turn from their wicked ways. 

# What happened during the fast that was proclaimed in honor of Yahweh?

Baruch read Jeremiah's words in the temple so all the people could hear them. 

# What happened during the fast that was proclaimed in honor of Yahweh?

Baruch read Jeremiah's words in the temple so all the people could hear them. 

# What did Micaiah do when he heard Baruch read from the scroll?

He went to the secretary's office in the palace. 

# What did the officials do when they heard Micaiah's report?

They sent Jehudi to bring Baruch to them, and they had Baruch read the scroll to them. 

# What did the officials do when they heard Micaiah's report?

They sent Jehudi to bring Baruch to them, and they had Baruch read the scroll to them. 

# What happened after Baruch read from the scroll?

The men who had heard Baruch read were afraid and decided they must report his words to the king. 

# What advice did the officials give to Baruch after he told them that he had written Jeremiah's words on the scroll?

They told him that he and Jeremiah needed to hide and not let anyone know where they were. 

# What advice did the officials give to Baruch after he told them that he had written Jeremiah's words on the scroll?

They told him that he and Jeremiah needed to hide and not let anyone know where they were. 

# What advice did the officials give to Baruch after he told them that he had written Jeremiah's words on the scroll?

They told him that he and Jeremiah needed to hide and not let anyone know where they were. 

# How did the king respond to the reading of the scroll by Jehudi?

The king cut off the parts Jehudi had read and threw them in the fire until all the scroll was destroyed. 

# How did the king and his servants show that they would not obey the words in the scroll?

They were not frightened, nor did they tear their clothes. 

# What did the king do when several men urged him not to burn the scroll?

He did not listen to them. 

# What did Yahweh tell Jeremiah to do after the king had burned the scroll?

He told Jeremiah to have Baruch write on a new scroll all the words that were on the original scroll. 

# What did Yahweh tell Jeremiah to do after the king had burned the scroll?

He told Jeremiah to have Baruch write on a new scroll all the words that were on the original scroll. 

# What did Yahweh tell Jeremiah to do after the king had burned the scroll?

He told Jeremiah to have Baruch write on a new scroll all the words that were on the original scroll. 

# What did Yahweh say he would do to Jehoiakim?

He said he would not let any of Jehoiakim's descendants be king, and he would make sure no one buried Jehoiakim's corpse. 

# What did Yahweh say he would do to Jehoiakim?

He said he would not let any of Jehoiakim's descendants be king, and he would make sure no one buried Jehoiakim's corpse. 

# Who made Zedekiah king?

Nebuchadnezzar made him king. 

# How did King Zedekiah respond to Jeremiah when he proclaimed the words of Yahweh?

Zedekiah did not listen to the words of Yahweh. 

# How did King Zedekiah respond to Jeremiah when he proclaimed the words of Yahweh?

Zedekiah did not listen to the words of Yahweh. 

# What did King Zedekiah and Zephaniah ask Jeremiah to do?

They asked him to pray to Yahweh for them. 

# Why did the Chaldeans (Babylonians) leave Jerusalem?

They wanted to get away from Pharaoh's army, which was coming out of Egypt. 

# What did Yahweh tell Jeremiah would happen after Pharaoh's army returned to Egypt?

He said that the Chaldeans would return, fight against the city, capture it, and burn it. 

# Why was Pharaoh's army coming out of Egypt?

They were going to help the people of Judah by fighting the Chaldeans. 

# What did Yahweh tell Jeremiah would happen after Pharaoh's army returned to Egypt?

He said that the Chaldeans would return, fight against the city, capture it, and burn it. 

# What did Yahweh tell Jeremiah would happen after Pharaoh's army returned to Egypt?

He said that the Chaldeans would return, fight against the city, capture it, and burn it. 

# Why did Jeremiah leave Jerusalem?

He left to take possession of some land. 

# Why did Jeremiah leave Jerusalem?

He left to take possession of some land. 

# What did Jeriah think that Jeremiah was going to do?

Jeriah thought that Jeremiah was deserting to the Chaldeans(Babylonians). 

# What did Jeriah do when Jeremiah told him that he was not deserting to the Chaldeans?

Jeriah took Jeremiah to the officials, who beat him and put him in prison. 

# What did Jeriah do when Jeremiah told him that he was not deserting to the Chaldeans?

Jeriah took Jeremiah to the officials, who beat him and put him in prison. 

# How did Jeremiah answer King Zedekiah when Zedekiah asked if Jeremiah has a word from Yahweh?

Jeremiah told Zedekiah that Yahweh would give Zedekiah to the king of Babylon. 

# How did Jeremiah answer King Zedekiah when Zedekiah asked if Jeremiah has a word from Yahweh?

Jeremiah told Zedekiah that Yahweh would give Zedekiah to the king of Babylon. 

# Why did Jeremiah not want to return to the house of Jonathan the scribe?

He was afraid that he would die there. 

# Why did Jeremiah not want to return to the house of Jonathan the scribe?

He was afraid that he would die there. 

# Why did Jeremiah not want to return to the house of Jonathan the scribe?

He was afraid that he would die there. 

# How did King Zedekiah respond to Jeremiah's request?

He had his servants put Jeremiah in the courtyard of the guard. 

# What will happen to the people who stay in the city?

They will die from the sword, famine, and plague. 

# How can people stay alive?

They can stay alive by going out to the Chaldeans. 

# What will happen to the city?

The Chaldeans (Babylonians) will capture it. 

# Why did the officials want Jeremiah to die?

They wanted him to die because he was telling the soldiers to desert to the Chaldeans. 

# What did the officials do to Jeremiah?

They put him in a cistern. 

# What did Ebed Melech tell the king concerning Jeremiah?

He told the king, the officials had done evil with the way they treated Jeremiah the prophet. They threw him into a cistern for him to die in it from hunger. 

# What did Ebed Melech tell the king concerning Jeremiah?

He told the king, the officials had done evil with the way they treated Jeremiah the prophet. They threw him into a cistern for him to die in it from hunger. 

# What did king Zedekiah command Ebed Melech concerning Jeremiah?

King Zedekiah commanded Ebed Melech to take thirty men and get Jeremiah out of the cistern before Jeremiah died. 

# What did Jeremiah think Zedekiah would do if Jeremiah tells him the truth?

He thought Zedekiah would kill him. 

# How did Zedekiah persuade Jeremiah to give him an answer?

Zedekiah swore by Yahweh that he would not kill him. 

# What did Jeremiah say to Zedekiah?

Jeremiah told Zedekiah that if he went out to the Chaldeans he would live, but if he did not, he and the city would be destroyed. 

# What did Jeremiah say to Zedekiah?

Jeremiah told Zedekiah that if he went out to the Chaldeans he would live, but if he did not, he and the city would be destroyed. 

# Why was King Zedekiah afraid of the people of Judah who had deserted to the Chaldeans?

He was afraid that Nebuchadnezzar would allow them to treat him badly. 

# What assurance did Jeremiah give to King Zedekiah?

He told King Zedekiah that if Zedekiah obeyed the message from Yahweh, Nebuchadnezzar would not allow the people to treat Zedekiah badly. 

# What would the women do if Zedekiah refused to go out?

They would rebuke and taunt him. 

# What would the women do if Zedekiah refused to go out?

They would rebuke and taunt him. 

# What did Zedekiah tell Jeremiah to say to anyone who asked him what he and Zedekiah talked about?

He told Jeremiah to tell them that Jeremiah went to plead with him not to return Jeremiah to Jonathan's house to die. 

# What did Zedekiah tell Jeremiah to say to anyone who asked him what he and Zedekiah talked about?

He told Jeremiah to tell them that Jeremiah went to plead with him not to return Jeremiah to Jonathan's house to die. 

# What did Zedekiah tell Jeremiah to say to anyone who asked him what he and Zedekiah talked about?

He told Jeremiah to tell them that Jeremiah went to plead with him not to return Jeremiah to Jonathan's house to die. 

# What happened when the officials from the house of Judah questioned Jeremiah?

Jeremiah told them what Zedekiah told him to say. 

# What happened when the officials from the house of Judah questioned Jeremiah?

Jeremiah told them what Zedekiah told him to say. 

# Who came with his army against Jerusalem and attacked it?

Nebuchadnezzar did. 

# What city was broken into?

The city of Jerusalem was broken into. 

# Who came and sat in the middle gate?

All the officials of the king of Babylon came and sat in the middle gate. 

# What did Zedekiah and all his fighting men do when they saw the officials of the king of Babylon in the middle gate?

They fled at night from the city. 

# What did the army of the Chaldeans (Babylonians) do when they caught up with Zedekiah?

They captured him and brought him to Nebuchadnezzar. 

# What did Nebuchadnezzar do when Zedekiah was brought to him?

He slaughtered Zedekiah's sons and also slaughtered all the noblemen of Judah. 

# What did the king of Babylon do to Zedekiah?

He put out Zedekiah's eyes and bound him so he could take Zedekiah to Babylon. 

# What did the Chaldeans (Babylonians) do to the houses and walls of Jerusalem?

They burned them. 

# Whom did Nebuzaradan take into exile?

He took into exile the rest of the people who were left in the city and the people who had deserted to the Chaldeans. 

# What people did Nebuzaradan allow to stay in the land of Judah?

He allowed the poorest people to remain. 

# What did Nebuzaradan give to the people who remained?

Nebuzaradan gave vineyards and fields to the people who remained. 

# What did Nebuchadnezzar command Nebuzaradan to do about Jeremiah?

Nebuchadnezzar told Nebuzaradan to take care of Jeremiah and to do anything Jeremiah told him to do. 

# What did Nebuchadnezzar command Nebuzaradan to do about Jeremiah?

Nebuchadnezzar told Nebuzaradan to take care of Jeremiah and to do anything Jeremiah told him to do. 

# What did Nebuzaradan, Nergal Sharezer, and the most important officials of the king of Babylon do to Jeremiah?

They took Jeremiah from the courtyard of the guard and entrusted him to Gedaliah to take Jeremiah home. 

# What did Yahweh tell Jeremiah to say to Ebed Melech the Cushite?

Yahweh told Jeremiah to say to Ebed Melech the Cushite that Yahweh was about to bring disaster on the city. 

# What did Yahweh tell Jeremiah to say to Ebed Melech the Cushite?

Yahweh told Jeremiah to say to Ebed Melech the Cushite that Yahweh was about to bring disaster on the city. 

# What did Yahweh say would happen to Ebed Melech on the day that Yahweh carried out his words against the city?

He said that he would rescue Ebed Melech. 

# For what reason would Yahweh rescue Ebed Melech from the sword?

He would rescue Ebed Melech because he trusted in Yahweh. 

# What came to Jeremiah after Nebuzaradan had sent him away from Ramah?

The word from Yahweh came to Jeremiah after Nebuzaradan had sent him away from Ramah. 

# What was Nebuzaradan going to do with the people of Jerusalem and Judah?

He was going to send them to Babylon. 

# Why did the chief guard tell Jeremiah concerning Yahweh and Jerusalem?

The chief guard said that Yahweh had decreed the disaster against that place. 

# Where did the chief guard say that Jeremiah could go?

He said that Jeremiah could go with him to Babylon or go wherever he wanted to in the land. 

# To whom did the chief guard say that Jeremiah should go?

He said that Jeremiah should go to Gedaliah, who was in charge of the cities of Judah. 

# Where did Jeremiah go and live?

Jeremiah went to Gedaliah and lived among the people who were left behind in the land. 

# What did the commanders of the Judean soldiers and their men do when they heard that Gedaliah had been put in charge of those who had not been exiled to Babylon?

They went to Gedaliah at Mizpah. 

# What did the commanders of the Judean soldiers and their men do when they heard that Gedaliah had been put in charge of those who had not been exiled to Babylon?

They went to Gedaliah at Mizpah. 

# What did Gedaliah tell the commanders of the Judean soldiers and their men to do?

He said that if they would serve the Chaldean officials and the king of Babylon and live in the land it would go well with them. 

# What did Gedaliah tell the commanders of the Judean soldiers and their men to do so they could harvest wine, summer fruit, and oil?

He told them that they should live in the cities that they had occupied. 

# What did the Judeans do when they heard that the king of Babylon had allowed a remnant of Judah to stay?

The Judeans returned to Judah from every place where they had been scattered, and they harvested wine and summer fruit in great abundance. 

# What did the Judeans do when they heard that the king of Babylon had allowed a remnant of Judah to stay?

The Judeans returned to Judah from every place where they had been scattered, and they harvested wine and summer fruit in great abundance. 

# What did Johanan and all the army commanders ask Gedaliah at Mizpah?

They asked him if he realized that Baalis king of Ammon had sent Ishmael to murder him. 

# What did Johanan and all the army commanders ask Gedaliah at Mizpah?

They asked him if he realized that Baalis king of Ammon had sent Ishmael to murder him. 

# What did Gedaliah think about what Jonathan and the army commanders told him?

He did not believe them. 

# What did Johanan tell Gedaliah he wanted to do?

He wanted kill Ishmael. 

# What did Gedaliah think of Jonathan's words about Ishmael?

Gedaliah thought that Jonathan was telling lies about Ishmael. 

# Why did Ishmael and the ten men with him come to eat with Gedaliah?

They wanted to kill Gedaliah. 

# Why did Ishmael and the ten men with him come to eat with Gedaliah?

They wanted to kill Gedaliah. 

# Whom did Ishmael and his men kill?

They killed Gedaliah, all the Judeans who were with him, and the Chaldean soldiers who were there. 

# Why did Ishmael and the ten men with him come to eat with Gedaliah?

They wanted to kill Gedaliah. 

# Whom did Ishmael and his men kill?

They killed Gedaliah, all the Judeans who were with him, and the Chaldean soldiers who were there. 

# Who came on the second day after Ishmael had killed Gedaliah?

Eighty men came from Shechem, Shiloh, and Samaria. 

# Who came on the second day after Ishmael had killed Gedaliah?

Eighty men came from Shechem, Shiloh, and Samaria. 

# Where were they going?

They were going to the temple. 

# What did Ishmael say to the eighty men?

He invited them to visit Gedaliah. 

# What did Ishmael and his men do to the eighty men when they came into the city?

They slaughtered the men and threw them into a pit. 

# Why did they not kill ten of the eighty men?

The ten men told them that they had provisions. 

# Where did Ishmael throw the corpses of all the people he had killed??

He threw them in the pit that King Asa had dug. 

# What did Ishmael do with all the other people who were in Mizpah?

Ishmael captured all the other people who were in Mizpah and started to take them to Ammon. 

# What did Johanan and all the army commanders with him do when they heard of what Ishmael had done?

They took all their men and went to fight against Ishmael. 

# What did Johanan and all the army commanders with him do when they heard of what Ishmael had done?

They took all their men and went to fight against Ishmael. 

# What did all the people who were with Ishmael do when they saw Johanan and all the army commanders who were with him?

They were very happy and went to Johanan. 

# What did all the people who were with Ishmael do when they saw Johanan and all the army commanders who were with him?

They were very happy and went to Johanan. 

# Where did Ishmael and his men go to get away from Johanan?

They went to the people of Ammon. 

# Where did Johanan and the people go after they left Mizpah?

They went to Geruth Chimham, which is near Bethlehem. 

# Where did Johanan and the people want to go?

They wanted to go to Egypt. 

# Why did they want to go to Egypt?

They were afraid of the Chaldeans. 

# Why were Johanan and the people afraid of the Chaldeans?

They were afraid because Ishmael had killed Gedaliah. 

# What did all the army commanders and all the people say to Jeremiah?

They asked him to pray for them and to tell them the way they should go and what they should do. 

# What did all the army commanders and all the people say to Jeremiah?

They asked him to pray for them and to tell them the way they should go and what they should do. 

# What did all the army commanders and all the people say to Jeremiah?

They asked him to pray for them and to tell them the way they should go and what they should do. 

# How did Jeremiah answer them?

He said he would pray for them and tell them whatever Yahweh answers. 

# Then what did the people say to Jeremiah?

They said they would do everything Yahweh told them to do. 

# Then what did the people say to Jeremiah?

They said they would do everything Yahweh told them to do. 

# What happened after ten days?

After ten days, the word of Yahweh came to Jeremiah. 

# What did Yahweh say he would do because he was with them?

He said that he would save them, give them mercy and compassion, and bring them back to their land. 

# What did Yahweh say he would do because he was with them?

He said that he would save them, give them mercy and compassion, and bring them back to their land. 

# What did Yahweh say would happen if the people actually went to Egypt to live there?

If they went to live in Egypt, Yahweh said they would all die there by sword, famine, and plague. 

# What did Yahweh say would happen if the people actually went to Egypt to live there?

If they went to live in Egypt, Yahweh said they would all die there by sword, famine, and plague. 

# What did Yahweh say would happen if the people actually went to Egypt to live there?

If they went to live in Egypt, Yahweh said they would all die there by sword, famine, and plague. 

# What will become of them if they go to Egypt?

They will become an object of cursing and they will never return. 

# Why will the people never see the land again?

Yahweh has told them not to go to Egypt, and he will be angry with them if they go. 

# Why will the people pay for their lives for going to Egypt?

They will pay with their lives because they asked Jeremiah to give them Yahweh's message, but they will not do what Yahweh tells them to do. 

# Why will the people pay for their lives for going to Egypt?

They will pay with their lives because they asked Jeremiah to give them Yahweh's message, but they will not do what Yahweh tells them to do. 

# Why will the people pay for their lives for going to Egypt?

They will pay with their lives because they asked Jeremiah to give them Yahweh's message, but they will not do what Yahweh tells them to do. 

# What did Jeremiah finish proclaiming to all the people?

He finished proclaiming all the words that Yahweh had told him to say. 

# Of what did Azariah, Johanan, and all the arrogant men accuse Jeremiah?

They accused him of telling them lies so that Jeremiah could have the Chaldeans kill them and make them captives in Babylon. 

# What did Johanan and the others do instead of what Yahweh had told them to do?

They all went to Egypt. 

# What did Johanan and the others do instead of what Yahweh had told them to do?

They all went to Egypt. 

# What did Johanan and the others do instead of what Yahweh had told them to do?

They all went to Egypt. 

# What did Johanan and the others do instead of what Yahweh had told them to do?

They all went to Egypt. 

# What did Yahweh tell Jeremiah to do with the stones?

He told him to bury them near Pharaoh's house in Tahpanhes to show that Nebuchadnezzar would sit on a throne there. 

# What did Yahweh tell Jeremiah to do with the stones?

He told him to bury them near Pharaoh's house in Tahpanhes to show that Nebuchadnezzar would sit on a throne there. 

# What did Yahweh tell Jeremiah to do with the stones?

He told him to bury them near Pharaoh's house in Tahpanhes to show that Nebuchadnezzar would sit on a throne there. 

# What does Yahweh say will happen to the people when Nebuchadnezzar comes and attacks the land of Egypt?

Yahweh says that Nebuchadnezzar will kill some people and take others into captivity. 

# What does Yahweh say Nebuchadnezzar will do to the temples of Egypt's gods?

Yahweh says he will burn them or capture them. 

# What does Yahweh say Nebuchadnezzar will do to the temples of Egypt's gods?

Yahweh says he will burn them or capture them. 

# Why does Jeremiah say Yahweh brought disaster on Jerusalem and the cities of Judah?

Jeremiah says did it because the people worshiped other gods. 

# Why does Jeremiah say Yahweh brought disaster on Jerusalem and the cities of Judah?

Jeremiah says did it because the people worshiped other gods. 

# What had Yahweh's prophets said to the people?

The prophets had told the people to stop doing things that Yahweh hates. 

# What did the people do after the prophets spoke to them?

They did not listen. 

# What did Yahweh do when the Judeans did not listen to the prophets?

Yahweh poured out his fury and his wrath, and he destroyed Judah and Jerusalem. 

# How many of the people who went to Egypt will Yahweh allow to live?

He will not allow any of them to live. 

# How did they offend Yahweh?

They offended Yahweh with the deeds of their hands, by burning incense to other gods in the land of Egypt. 

# What does Yahweh say is going to happen to them in Egypt?

He says he will destroy them. 

# Who does Yahweh say has committed wickedness?

He says that the people and their ancestors have committed wickedness. 

# What does Yahweh say will happen to the people who went to Egypt?

Yahweh says that he will set his face against them and bring disaster to them and destroy all of them just as he punished Jerusalem: with sword and famine and plague. 

# What does Yahweh say will happen to the people who went to Egypt?

Yahweh says that he will set his face against them and bring disaster to them and destroy all of them just as he punished Jerusalem: with sword and famine and plague. 

# What does Yahweh say about the remnant of Judah?

He says that none of them who want to return to Judah will return, though a few will escape from Egypt. 

# What did the people think would happen if they continued to burned incense and pour out drink offerings to the Queen of Heaven?

The people thought they would be filled with food and would prosper, without experiencing any disaster if they burned incense and poured out drink offerings to the Queen of Heaven. 

# What was it that Yahweh could no longer bear?

He could no longer bear what the people did. 

# What happened to their land after Yahweh could no longer bear what the people did?

Their land became a desolation, a horror, and a curse. 

# Why did this disaster happen to them?

Because they burned incense to worship idols and sinned against Yahweh, and because they would not listen to him. 

# What did Jeremiah tell those who wanted to fulfill their vows to the Queen of Heaven?

He told them to fulfill their vows. 

# What did Jeremiah say the people would do after they fulfilled their vows?

He told them that they would never again worship Yahweh, but they would all perish by sword and famine. 

# What did Jeremiah say the people would do after they fulfilled their vows?

He told them that they would never again worship Yahweh, but they would all perish by sword and famine. 

# What will happen to those who do not die by the sword?

They will return from Egypt to Judah. 

# What will the people understand when Hophra dies?

They will understand that Yahweh will do to them everything he said he would do. 

# What does Yahweh say he will do with Pharaoh Hophra?

He says he will give Pharaoh Hophra to his enemies. 

# Why did Yahweh give Jeremiah a message for Baruch?

He did it because Baruch was saying that Yahweh was making him sad. 

# Why did Yahweh give Jeremiah a message for Baruch?

He did it because Baruch was saying that Yahweh was making him sad. 

# Why did Yahweh give Jeremiah a message for Baruch?

He did it because Baruch was saying that Yahweh was making him sad. 

# What does Yahweh plan to do to Baruch's nation?

He plans to destroy it. 

# What should Baruch not desire?

He should not desire people to honor him in a special way. 

# What does Yahweh promise to do for Baruch?

Yahweh promises to protect Baruch wherever he goes. 

# What does Yahweh tell the army of Egypt to do?

He tells them to get their shields, horses, spears, and armor ready and go forward to fight. 

# Who are the two kings who are going to have a war?

Nebuchadnezzar king of Babylon and Neco king of Egypt were going to war. 

# What does Yahweh tell the army of Egypt to do?

He tells them to get their shields, horses, spears, and armor ready and go forward to fight. 

# What does Yahweh tell the army of Egypt to do?

He tells them to get their shields, horses, spears, and armor ready and go forward to fight. 

# What does Yahweh tell the army of Egypt to do?

He tells them to get their shields, horses, spears, and armor ready and go forward to fight. 

# What does Yahweh see the Egyptian army doing?

He sees the Egyptian soldiers running for safety but defeated at the Euphrates River. 

# What does Yahweh see the Egyptian army doing?

He sees the Egyptian soldiers running for safety but defeated at the Euphrates River. 

# What does Yahweh compare the Egyptian army to?

The army is like the Nile River when it floods and destroys cities and inhabitants. 

# What does Yahweh compare the Egyptian army to?

The army is like the Nile River when it floods and destroys cities and inhabitants. 

# How will Yahweh get his vengeance?

He will get his vengeance when the sword devours and is satisfied. That will be like a sacrifice to Yahweh. 

# What does Yahweh tell Egypt to do?

They are to go to Gilead for medicine, but it will not cure them. 

# What does Yahweh tell Egypt to do?

They are to go to Gilead for medicine, but it will not cure them. 

# What did Yahweh tell the people of Migdol and Memphis to do?

He told them to got to Tahpanhes and fight there. 

# What did Yahweh tell the people of Migdol and Memphis to do?

He told them to got to Tahpanhes and fight there. 

# What has happened to Egypt's gods?

Apis the bull-god has run away and Yahweh has thrown him down. 

# What do the soldiers want to do?

They want to go to their homes. 

# What do the soldiers want to do?

They want to go to their homes. 

# What does Yahweh say Egypt needs to prepare for?

He says Egypt needs to prepare for captivity. 

# What animals does the writer say Egypt is like before the battle?

Egypt is a beautiful young cow, and the hired soldiers are like a fattened bull. 

# What animals does the writer say Egypt is like before the battle?

Egypt is a beautiful young cow, and the hired soldiers are like a fattened bull. 

# What animal does the writer say Egypt is like after the battle?

He says Egypt is like a snake. 

# Who will kill the soldiers of Egypt?

People from the north will cut them down. 

# Who will kill the soldiers of Egypt?

People from the north will cut them down. 

# To whom will Yahweh give Egypt?

He will give Egypt to Nebuchadnezzar. 

# To whom will Yahweh give Egypt?

He will give Egypt to Nebuchadnezzar. 

# What does Yahweh say he will do for his people Israel?

He will bring them out of captivity, return them to their land where they will find peace and be secure, bring destruction to the nations where they were scattered, discipline them justly, but not destroy them completely. 

# What does Yahweh say he will do for his people Israel?

He will bring them out of captivity, return them to their land where they will find peace and be secure, bring destruction to the nations where they were scattered, discipline them justly, but not destroy them completely. 

# What does Yahweh say will happen to the people of Philistia?

They will be attacked from the north and they will all lament(weep). 

# What does Yahweh say will happen to the people of Philistia?

They will be attacked from the north and they will all lament(weep). 

# How will the people of Philistia know the enemy is coming to destroy them?

They will hear the sound of horses' hooves and the rumble of the chariots. Men will run away, they will not stop to help their children, and they will be weak and helpless. 

# How will the people of Philistia know the enemy is coming to destroy them?

They will hear the sound of horses' hooves and the rumble of the chariots. Men will run away, they will not stop to help their children, and they will be weak and helpless. 

# What are the people of Philistia asking Yahweh to do?

They are asking him to stop killing them. 

# What are the people of Philistia asking Yahweh to do?

They are asking him to stop killing them. 

# Why will Yahweh not stop the killing?

Because he intends to attack all people living in Ashkelon and the cities along the coast. 

# What does Yahweh say about Moab?

Devastation will happen to the cities, no one will honor Moab, and their enemies will try to destroy her as a nation. 

# What does Yahweh say about Moab?

Devastation will happen to the cities, no one will honor Moab, and their enemies will try to destroy her as a nation. 

# Why are people screaming, weeping, and crying?

They are doing these things because Moab has been destroyed. 

# Why are people screaming, weeping, and crying?

They are doing these things because Moab has been destroyed. 

# Why are people screaming, weeping, and crying?

They are doing these things because Moab has been destroyed. 

# Why will Chemosh and his priests and leaders go away into captivity?

They were putting their trust in their practices and their wealth. 

# What does Yahweh say will happen to the towns in Moab?

They will all be destroyed, none of them will escape. 

# What is to happen to their cities?

They will become a wasteland where no one lives. 

# What will Yahweh do to anyone who will not kill Moabites for him?

Yahweh will curse him. 

# What does Yahweh say will happen to the Moabites?

He says he will send enemies to attack them and get rid of them. 

# What does Yahweh say will happen to the Moabites?

He says he will send enemies to attack them and get rid of them. 

# What does Yahweh say will happen to the country of Moab?

It will very soon be destroyed. 

# What does Yahweh say will happen to the country of Moab?

It will very soon be destroyed. 

# What should the people who live near Moab do after Moab is destroyed?

They should wail for Moab because their power has been broken. 

# What should the people in the city of Dibon and Aroer do instead of being proud?

They should notice they are being attacked and take notice of people who are escaping. They should howl, lament, and shout for help because Moab has been devastated. 

# What should the people in the city of Dibon and Aroer do instead of being proud?

They should notice they are being attacked and take notice of people who are escaping. They should howl, lament, and shout for help because Moab has been devastated. 

# What should the people in the city of Dibon and Aroer do instead of being proud?

They should notice they are being attacked and take notice of people who are escaping. They should howl, lament, and shout for help because Moab has been devastated. 

# What punishment has come to all the cities in the land of Moab?

Yahweh has punished many cities. The horn of Moab has been hacked off; its arm has been broken. 

# What punishment has come to all the cities in the land of Moab?

Yahweh has punished many cities. The horn of Moab has been hacked off; its arm has been broken. 

# What punishment has come to all the cities in the land of Moab?

Yahweh has punished many cities. The horn of Moab has been hacked off; its arm has been broken. 

# What punishment has come to all the cities in the land of Moab?

Yahweh has punished many cities. The horn of Moab has been hacked off; its arm has been broken. 

# What punishment has come to all the cities in the land of Moab?

Yahweh has punished many cities. The horn of Moab has been hacked off; its arm has been broken. 

# The Moabites thought they were powerful against Yahweh, but what will Yahweh do to them?

Yahweh will judge Moab and their enemies will laugh at them. 

# The Moabites thought they were powerful against Yahweh, but what will Yahweh do to them?

Yahweh will judge Moab and their enemies will laugh at them. 

# What should the inhabitants do because of their pride?

They should abandon the cities and camp on the cliffs in the rocks. 

# What should the inhabitants do because of their pride?

They should abandon the cities and camp on the cliffs in the rocks. 

# Why does Yahweh lament, shout in sorrow, and weep for the people in Moab?

Yahweh laments because he knows Moab's defiant speech amounts to nothing. 

# Why does Yahweh lament, shout in sorrow, and weep for the people in Moab?

Yahweh laments because he knows Moab's defiant speech amounts to nothing. 

# Why does Yahweh lament, shout in sorrow, and weep for the people in Moab?

Yahweh laments because he knows Moab's defiant speech amounts to nothing. 

# What has Yahweh done to Moab?

He has taken away their celebration and rejoicing. 

# What does Yahweh say he will do to the people of Moab who offer sacrifices and burn incense to their gods?

He will get rid of those people. 

# How do the people of Kir Heres express their sorrow because their riches are gone?

They shave their heads and beards, cut their hands, and wear sackcloth around their waists. 

# How do the people of Kir Heres express their sorrow because their riches are gone?

They shave their heads and beards, cut their hands, and wear sackcloth around their waists. 

# Why is there mourning everywhere on the roofs and in the plazas?

Because Yahweh has destroyed Moab as people destroy pots that no one wants. 

# Why is there mourning everywhere on the roofs and in the plazas?

Because Yahweh has destroyed Moab as people destroy pots that no one wants. 

# What does Yahweh say the capture of Kerioth will be like?

It will happen quickly, like when an eagle gets its prey. The enemy will seize the strongholds, and the soldiers will be afraid. 

# What does Yahweh say the capture of Kerioth will be like?

It will happen quickly, like when an eagle gets its prey. The enemy will seize the strongholds, and the soldiers will be afraid. 

# How will Yahweh destroy Moab?

Yahweh will cause the people to be terrified and fall into pits and traps. 

# How will Yahweh destroy Moab?

Yahweh will cause the people to be terrified and fall into pits and traps. 

# How will Yahweh destroy Moab?

Yahweh will cause the people to be terrified and fall into pits and traps. 

# Why will the people flee only as far as the city of Heshbon?

Because a fire will be burning in Heshbon, and it will burn up all the people in Moab who boasted. 

# What does Jeremiah say will happen to the Moabites?

The Moabites will be destroyed and their sons and daughters will be captured and taken to other countries, but someday Yahweh will allow them to return to their land. 

# What does Jeremiah say will happen to the Moabites?

The Moabites will be destroyed and their sons and daughters will be captured and taken to other countries, but someday Yahweh will allow them to return to their land. 

# Why should Molech not occupy the land of Gad?

Molech should not occupy Gad because it belongs to the children of Israel. 

# What will happen to Rabbah?

It will become a deserted heap. 

# What will happen to Molech?

The cities will be destroyed and the people will go into captivity. 

# What does the faithless daughter trust in?

She trusts in her wealth. 

# Why will the people be terrified?

They will be terrified because they will all be forced by the enemy who surround them to scatter to other countries. 

# What will Yahweh do for the Ammon people-group in the future?

Yahweh will restore their fortunes. 

# What has happened to the wise people of Edom?

The wise people of Edom have gone away. 

# What should the people of Edom do now that their wise people are gone?

They should flee and live in holes in the ground. 

# What is Yahweh going to do to Esau?

He is going to bring disaster on Esau. 

# What does Yahweh say about the orphans and widows in Edom?

He says that he will take care of the orphans and widows. 

# Why should the Edomites already know that Yahweh will punish them?

They have seen that even those whom Yahweh is not punishing have suffered. 

# What Yahweh said he will do to Bozrah?

He will destroy it. 

# What was Yahweh's messenger going to tell the nations to do?

The messenger went out to the nations telling them to get ready for battle and attack Edom. 

# What does Yahweh say to the people of Edom?

He says that he has made their nation of Edom small compared to other nations and that people will despise them. 

# Because the Edomites have deceived themselves and think they have safety in the cliff, what will Yahweh do to them?

He will bring them down. 

# What does Yahweh compare the horror of Edom to?

He compares it to Sodom and Gomorrah and their neighbors, where no one lives. 

# What does Yahweh compare the horror of Edom to?

He compares it to Sodom and Gomorrah and their neighbors, where no one lives. 

# What will Yahweh do to the Edomites after he takes them from their land?

He will choose someone to be in charge of them. 

# What are the plans that Yahweh has against Edom?

He has plans to drag away the inhabitants of Teman and to turn their pasturelands into ruined places. 

# What will it be like when Edom is destroyed?

The earth will shake, and people as far away as the Red Sea will hear the shouts of distress. Even the strongest warriors will be afraid. 

# What will it be like when Edom is destroyed?

The earth will shake, and people as far away as the Red Sea will hear the shouts of distress. Even the strongest warriors will be afraid. 

# What does Yahweh say will happen to the people of Damascus?

They will be ashamed and weak. They will turn away and flee in distress. 

# What does Yahweh say will happen to the people of Damascus?

They will be ashamed and weak. They will turn away and flee in distress. 

# What will happen when Yahweh lights a fire on the wall of Damascus?

The fire will devour Benhadad's strongholds, and the young men and all the fighting men will die. 

# What will happen when Yahweh lights a fire on the wall of Damascus?

The fire will devour Benhadad's strongholds, and the young men and all the fighting men will die. 

# What does Yahweh tell Nebuchadnezzar to do to Kedar?

He tells Nebuchadnezzar to attack the people, destroy them, and take their possessions. 

# What does Yahweh tell Nebuchadnezzar to do to Kedar?

He tells Nebuchadnezzar to attack the people, destroy them, and take their possessions. 

# Why will this be an easy attack for Nebuchadnezzar?

It will be easy for him because the people have no gates or bars, and they live by themselves. 

# Where will the people of Kedar live after Nebuchadnezzar attacks them?

They will live in holes in the ground. 

# Why will this be an easy attack for Nebuchadnezzar?

It will be easy for him because the people have no gates or bars, and they live by themselves. 

# What will Yahweh do to the people of Hazor when Nebuchadnezzar takes their camels and property as war plunder?

He will scatter them and disaster will come on them. 

# Who will live in the city after Nebuchadnezzar attacks it?

Only jackals will live in it. 

# When did Jeremiah receive the prophecy about Elam?

He got it when King Zedekiah ruled Judah. 

# When Yahweh breaks the bowmen of Elam, where will the people go?

The people will go to all parts of the earth. 

# When Yahweh breaks the bowmen of Elam, where will the people go?

The people will go to all parts of the earth. 

# When Yahweh breaks the bowmen of Elam, where will the people go?

The people will go to all parts of the earth. 

# What is Yahweh going to do because he is angry with the people of Elam?

Yahweh is going to enable their enemies to smash them and bring disaster to them, kill them, and completely get rid of all of them. 

# What is Yahweh going to do because he is angry with the people of Elam?

Yahweh is going to enable their enemies to smash them and bring disaster to them, kill them, and completely get rid of all of them. 

# What will Yahweh do for the people of Elam some day?

He will allow them to return to their land. 

# What will happen to Babylon?

Babylon is taken. Bel and the idols are put to shame. 

# Who will arise against Babylon?

A nation from the north. 

# What will the people of Israel do when Babylon is attacked?

The people will come together with weeping and seek Yahweh. They will set off toward Zion to renew their eternal covenant with Yahweh. 

# What will the people of Israel do when Babylon is attacked?

The people will come together with weeping and seek Yahweh. They will set off toward Zion to renew their eternal covenant with Yahweh. 

# Why does Yahweh describe his people as a lost flock?

He describes them as a lost flock because their shepherds led them astray and they forgot their homeland. 

# What did their adversaries say about why they were able to devour Yahweh's people?

The adversaries said it was because Yahweh's people sinned against Yahweh. 

# Why are the Israelites to leave Babylon before Babylon is captured?

They are to leave because great nations from the north are coming to capture Babylon. 

# Why are the Israelites to leave Babylon before Babylon is captured?

They are to leave because great nations from the north are coming to capture Babylon. 

# Why are the Israelites to leave Babylon before Babylon is captured?

They are to leave because great nations from the north are coming to capture Babylon. 

# What will happen to Babylon because they took Yahweh's inheritance as plunder?

Babylon will be the least of nations, an uninhabited wilderness. 

# What will happen to Babylon because they took Yahweh's inheritance as plunder?

Babylon will be the least of nations, an uninhabited wilderness. 

# What will happen to Babylon because they took Yahweh's inheritance as plunder?

Babylon will be the least of nations, an uninhabited wilderness. 

# Because Babylon has sinned against Yahweh what will happen to her?

Everyone will shoot at Babylon, Babylon will surrender her power, her towers will fall, her walls will be torn down, and others will do to her just as she had done to other nations. 

# Because Babylon has sinned against Yahweh what will happen to her?

Everyone will shoot at Babylon, Babylon will surrender her power, her towers will fall, her walls will be torn down, and others will do to her just as she had done to other nations. 

# What should people who came from other countries do when Babylon is attacked?

They should all run away back to their own countries. 

# What does Yahweh say he will do to the nations of Assyria and Babylon?

He says he will punish the king of Babylon and his people the same way he punished the king of Assyria. 

# What does Yahweh say he will do to the nations of Assyria and Babylon?

He says he will punish the king of Babylon and his people the same way he punished the king of Assyria. 

# What will Yahweh do for this remnant of people that he spares?

Yahweh will restore Israel to his homeland, and he will forgive the people's sins. 

# What will Yahweh do for this remnant of people that he spares?

Yahweh will restore Israel to his homeland, and he will forgive the people's sins. 

# What does Yahweh encourage the enemies of Babylon to do?

Yahweh wants them to sound the battle cry and bring enormous destruction on Babylon. 

# What does Yahweh encourage the enemies of Babylon to do?

Yahweh wants them to sound the battle cry and bring enormous destruction on Babylon. 

# Why will the Babylonian army be seized?

It will be seized because it challenged Yahweh. 

# Why will the Babylonian army be seized?

It will be seized because it challenged Yahweh. 

# What is the work that Yahweh has to do?

Yahweh opens his armory, brings out the weapons, and encourages the enemies to attack Babylon, open her granaries, and bring her to destruction. They are to leave no remnant of her. 

# What is the work that Yahweh has to do?

Yahweh opens his armory, brings out the weapons, and encourages the enemies to attack Babylon, open her granaries, and bring her to destruction. They are to leave no remnant of her. 

# What will the Israelite survivors of Babylon talk about?

They will talk about how Yahweh punished Babylon by having the warriors slaughtered for what was done to his temple in Zion. 

# What will the Israelite survivors of Babylon talk about?

They will talk about how Yahweh punished Babylon by having the warriors slaughtered for what was done to his temple in Zion. 

# What will happen to because she defied Yahweh?

No one will escape the destruction the enemies of Babylon will bring on her. The enemy is to destroy all of her fighting men because of what she has done to Yahweh. 

# What will happen to because she defied Yahweh?

No one will escape the destruction the enemies of Babylon will bring on her. The enemy is to destroy all of her fighting men because of what she has done to Yahweh. 

# What does Yahweh declare will happen to the proud people?

He declares that they will stumble and fall. 

# What does Yahweh declare will happen to the proud people?

He declares that they will stumble and fall. 

# Who rescues the oppressed people of Israel?

Yahweh of hosts rescues Israel. 

# Who rescues the oppressed people of Israel?

Yahweh of hosts rescues Israel. 

# What will enemy soldiers do to Babylonia?

They will strike the inhabitants, the officials, the wise men, and all the people. They will strike their false prophets, their strongest warriors, and their horses and chariots. 

# What will enemy soldiers do to Babylonia?

They will strike the inhabitants, the officials, the wise men, and all the people. They will strike their false prophets, their strongest warriors, and their horses and chariots. 

# What will enemy soldiers do to Babylonia?

They will strike the inhabitants, the officials, the wise men, and all the people. They will strike their false prophets, their strongest warriors, and their horses and chariots. 

# What will Babylon become like?

Babylon will become like Sodom and Gomorrah. 

# What will Babylon become like?

Babylon will become like Sodom and Gomorrah. 

# What will Babylon become like?

Babylon will become like Sodom and Gomorrah. 

# What does the king of Babylon hear about the people from the north?

The kings hears that they are cruel and have no compassion. 

# What does the king of Babylon hear about the people from the north?

The kings hears that they are cruel and have no compassion. 

# How does the king of Babylon feel after hearing this report from Jeremiah that an army from the north is coming to overtake Babylon?

After hearing the report the king feels like a woman in labor. 

# What will Yahweh do to Babylon?

He will chase the people from Babylon and appoint someone to be in charge of it. 

# What does Yahweh plan to do to the people of Babylon?

Yahweh plans to completely destroy the people of Babylon. 

# What does Yahweh plan to do to the people of Babylon?

Yahweh plans to completely destroy the people of Babylon. 

# What will the foreigners do to Babylon?

They will come and destroy Babylon. 

# What will the foreigners do to Babylon?

They will come and destroy Babylon. 

# What type of attack will come on Babylon's army?

A surprise attack will come so quickly that Babylon's soldiers will not have time to put on their armor. The attackers will destroy the army and the people. 

# What type of attack will come on Babylon's army?

A surprise attack will come so quickly that Babylon's soldiers will not have time to put on their armor. The attackers will destroy the army and the people. 

# What does Yahweh remind his people of?

Yahweh reminds them that even though his people sinned he is still their God and he has not abandoned them. 

# What does Yahweh tell the people of Israel to do?

Yahweh tells his people to run, so they will escape the punishment coming to Babylon. 

# What did Yahweh use Babylon to do to the nations?

He used it to make them drunk. 

# What will happen to Babylon?

It will fall and be destroyed. 

# What will happen to Babylon?

It will fall and be destroyed. 

# What will the Israelites do because Babylon will not be healed?

The Israelites will leave and go to their land and tell others in Zion that Yahweh has forgiven them of their sins. 

# What will the Israelites do because Babylon will not be healed?

The Israelites will leave and go to their land and tell others in Zion that Yahweh has forgiven them of their sins. 

# Who is going to march into battle against Babylon because Babylon destroyed Yahweh's temple in Jerusalem?

The armies of Media and Persia are going to destroy Babylon. 

# What has Yahweh sworn he will do to the rich people of Babylon?

Yahweh will raise a battle cry against them. Their end has come. 

# What has Yahweh sworn he will do to the rich people of Babylon?

Yahweh will raise a battle cry against them. Their end has come. 

# What has Yahweh done by his power, wisdom, and understanding?

He has made the earth, set it in place, and stretched out the heavens. 

# What happens when Yahweh speaks?

He brings thunder, rain, lightning, and wind to come upon the earth. 

# What happens when Yahweh speaks?

He brings thunder, rain, lightning, and wind to come upon the earth. 

# Will making idols satisfy people?

No, idols can do nothing for them. They are worthless. 

# Will making idols satisfy people?

No, idols can do nothing for them. They are worthless. 

# Who is the God of Israel?

He is the one who created everything. His name is Yahweh. 

# What did God say Israel was?

God said Israel was his war hammer, his weapon for battle. 

# What does Yahweh say to the people in Babylon?

Yahweh says he will repay the people for all the evil things they did in Jerusalem. 

# What will Yahweh do to Babylon because of how they plundered people all over the earth?

Yahweh will completely destroy Babylon, and no one will ever live there again. 

# What will Yahweh do to Babylon because of how they plundered people all over the earth?

Yahweh will completely destroy Babylon, and no one will ever live there again. 

# What is Jeremiah to tell the nations of Media and Persia?

These nations are to summon their armies and prepare to attack Babylon. 

# What is Jeremiah to tell the nations of Media and Persia?

These nations are to summon their armies and prepare to attack Babylon. 

# What is Yahweh's plan against Babylon?

Yahweh's plan is to make the land of Babylon a wasteland with no inhabitants. 

# How will the Babylonian warriors respond to the battle against them?

The warriors will remain confused in their strongholds because places of escape will be blocked, and the city will be set on fire. 

# How will the Babylonian warriors respond to the battle against them?

The warriors will remain confused in their strongholds because places of escape will be blocked, and the city will be set on fire. 

# How will the Babylonian warriors respond to the battle against them?

The warriors will remain confused in their strongholds because places of escape will be blocked, and the city will be set on fire. 

# What does Yahweh say Babylon is like?

Babylon is like a threshing floor during the time of harvest. 

# What do the people of Jerusalem want Yahweh to do to the people of Babylon?

They want Yahweh to cause the Babylonians to suffer like they suffered under King Nebuchadnezzar. 

# What do the people of Jerusalem want Yahweh to do to the people of Babylon?

They want Yahweh to cause the Babylonians to suffer like they suffered under King Nebuchadnezzar. 

# What is Yahweh's response to the Israelites?

He will plead their case and bring vengeance on Babylon. He will make her springs dry and make her a wasteland where no one lives. 

# What is Yahweh's response to the Israelites?

He will plead their case and bring vengeance on Babylon. He will make her springs dry and make her a wasteland where no one lives. 

# What is Yahweh going to do to the people of Babylon?

He is going to prepare a different kind of feast where they become drunk with wine and then are all slaughtered. 

# What is Yahweh going to do to the people of Babylon?

He is going to prepare a different kind of feast where they become drunk with wine and then are all slaughtered. 

# What kind of place will Babylon become?

Babylon will become a place of ruin among all nations. 

# What will Yahweh do to the god Bel?

Yahweh will punish Bel and make the people of Babylon give back the offerings that were given to Bel, and the walls of Babylon will fall. 

# What will Yahweh do to the god Bel?

Yahweh will punish Bel and make the people of Babylon give back the offerings that were given to Bel, and the walls of Babylon will fall. 

# What does Yahweh tell his people who are in Babylon to do?

He tells them to run and save their lives from all the violence that will be in the land. 

# What does Yahweh tell his people who are in Babylon to do?

He tells them to run and save their lives from all the violence that will be in the land. 

# What happens that causes the heavens and earth to rejoice?

The heavens and earth will rejoice because Babylon is destroyed by an army from the north. 

# What happens that causes the heavens and earth to rejoice?

The heavens and earth will rejoice because Babylon is destroyed by an army from the north. 

# What does Jeremiah tell the Israelite people to do?

They are to get out of Babylon, return to Jerusalem, and turn back to Yahweh. 

# What had the Israelites heard about Yahweh's house?

They had heard that foreigners had entered the holy places of Yahweh's house. 

# What does Yahweh tell the people that he will do?

He tells them that he will send armies to destroy Babylon. 

# What does Yahweh tell the people that he will do?

He tells them that he will send armies to destroy Babylon. 

# What do the people hear from Babylon?

They hear a shout of distress as Yahweh destroys Babylon. 

# What do the people hear from Babylon?

They hear a shout of distress as Yahweh destroys Babylon. 

# What do the people hear from Babylon?

They hear a shout of distress as Yahweh destroys Babylon. 

# What will happen to everything that the nations try to do for Babylon?

It will all be useless. 

# Who was King Zedekiah's chief officer?

Seraiah was his chief officer. 

# What did Jeremiah write in a scroll?

Jeremiah wrote all the disasters that were going to come to Babylon. 

# What were Jeremiah's instructions to Seraiah?

Jeremiah told Seraiah that when he arrived in Babylon he was to read all the words on the scroll, tie a stone to it, and throw it into the Euphrates River. 

# What was written on the scroll?

Yahweh made a declaration that Babylon will be destroyed, have no inhabitants, and become a permanent wasteland. 

# What were Jeremiah's instructions to Seraiah?

Jeremiah told Seraiah that when he arrived in Babylon he was to read all the words on the scroll, tie a stone to it, and throw it into the Euphrates River. 

# Why was Seraiah to throw the scroll in the river?

When he threw the scroll in the river, the people would understand that Babylon will sink like the scroll because of the disaster Yahweh is sending on her. 

# Why was Seraiah to throw the scroll in the river?

When he threw the scroll in the river, the people would understand that Babylon will sink like the scroll because of the disaster Yahweh is sending on her. 

# What kind of king was Zedekiah?

Zedekiah was an evil king just like Jehoiakim. 

# What kind of king was Zedekiah?

Zedekiah was an evil king just like Jehoiakim. 

# What did king Nebuchadnezzar do while he was near Jerusalem?

He camped opposite it and attacked the city for two years. 

# What did king Nebuchadnezzar do while he was near Jerusalem?

He camped opposite it and attacked the city for two years. 

# Where did the Chaldeans (Babylonians) catch Zedekiah and his men?

They caught them in the plains of the Jordan River near Jericho. 

# Where did the Chaldeans (Babylonians) catch Zedekiah and his men?

They caught them in the plains of the Jordan River near Jericho. 

# Where did the Chaldeans (Babylonians) catch Zedekiah and his men?

They caught them in the plains of the Jordan River near Jericho. 

# What did the king of Babylon do to Zedekiah and his sons?

The king slaughtered Zedekiah's sons before his eyes and then put out Zedekiah's eyes, bound him in chains, and took him to Babylon. 

# What did the king of Babylon do to Zedekiah and his sons?

The king slaughtered Zedekiah's sons before his eyes and then put out Zedekiah's eyes, bound him in chains, and took him to Babylon. 

# What did the king of Babylon do to Zedekiah and his sons?

The king slaughtered Zedekiah's sons before his eyes and then put out Zedekiah's eyes, bound him in chains, and took him to Babylon. 

# What did Nebuzaradan do in Jerusalem?

He burned the house of Yahweh, the king's palace, and all the houses and important buildings, and he destroyed the walls around Jerusalem. 

# What did Nebuzaradan do in Jerusalem?

He burned the house of Yahweh, the king's palace, and all the houses and important buildings, and he destroyed the walls around Jerusalem. 

# What did Nebuzaradan do in Jerusalem?

He burned the house of Yahweh, the king's palace, and all the houses and important buildings, and he destroyed the walls around Jerusalem. 

# What did Nebuzaradan do to the poorest people in Jerusalem?

He took some of them into exile and left some to work the vineyards and fields. 

# What did Nebuzaradan do to the poorest people in Jerusalem?

He took some of them into exile and left some to work the vineyards and fields. 

# What became of the bronze, gold, and silver in the house of Yahweh?

The Chaldeans (Babylonians) took it all away. 

# What became of the bronze, gold, and silver in the house of Yahweh?

The Chaldeans (Babylonians) took it all away. 

# What became of the bronze, gold, and silver in the house of Yahweh?

The Chaldeans (Babylonians) took it all away. 

# What did Nebuzaradan do to Zephaniah and other city officials?

He put them in prison. 

# What did Nebuzaradan do to Zephaniah and other city officials?

He put them in prison. 

# What did the king of Babylon do with the prisoners that Nebuzaradan brought to him?

He put them to death. 

# What did the king of Babylon do with the prisoners that Nebuzaradan brought to him?

He put them to death. 

# How many Judean people were exiled?

There were 4,600 people exiled from Jerusalem. 

# How many Judean people were exiled?

There were 4,600 people exiled from Jerusalem. 

# How many Judean people were exiled?

There were 4,600 people exiled from Jerusalem. 

# Who released Jehoiachin king of Judah from prison?

Evil Merodach, king of Babylon, released him. 

# How did Evil Merodach treat Jehoiachin when he was released from prison?

He spoke kindly to him and gave him a seat of honor. He removed Jehoiachin's prison clothes and had him eat at his table and gave him a regular food allowance for the rest of his life. 

# How did Evil Merodach treat Jehoiachin when he was released from prison?

He spoke kindly to him and gave him a seat of honor. He removed Jehoiachin's prison clothes and had him eat at his table and gave him a regular food allowance for the rest of his life. 

# How did Evil Merodach treat Jehoiachin when he was released from prison?

He spoke kindly to him and gave him a seat of honor. He removed Jehoiachin's prison clothes and had him eat at his table and gave him a regular food allowance for the rest of his life. 

