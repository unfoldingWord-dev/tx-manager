# Where is Paul as he writes this letter?

Paul is in prison as he writes this letter. 

# To whom is this letter written?

This letter is written to Philemon, Paul's beloved brother and fellow-worker. 

# In what kind of place is the church meeting?

The church is meeting in a house. 

# Of what good characteristics has Paul heard about Philemon?

Paul has heard about Philemon's love, faith in the Lord, and faithfulness toward all the saints. 

# According to Paul, what has Philemon done for the saints?

Philemon has refreshed the hearts of the saints. 

# Where is Paul as he writes this letter?

Paul is in prison as he writes this letter. 

# Why is Paul asking Philemon for something instead of commanding him?

Paul is asking Philemon for love's sake. 

# When was Onesimus fathered by Paul?

Onesimus was fathered by Paul while Paul was in prison. 

# What has Paul done with Onesimus?

Paul has sent Onesimus back to Philemon. 

# Where is Paul as he writes this letter?

Paul is in prison as he writes this letter. 

# What would Paul like Onesimus to be able to do?

Paul would like Onesimus to be able to help him. 

# What would Paul like Philemon to do with Onesimus?

Paul would like Philemon to release Onesimus from being a slave, and agree to have Onesimus return to Paul. 

# What would Paul like Philemon to do with Onesimus?

Paul would like Philemon to release Onesimus from being a slave, and agree to have Onesimus return to Paul. 

# What would Paul like Philemon to do with Onesimus?

Paul would like Philemon to release Onesimus from being a slave, and agree to have Onesimus return to Paul. 

# How does Paul now want Philemon to consider Onesimus?

Paul wants Philemon to consider Onesimus as a beloved brother. 

# What does Paul want Philemon to do about anything that Onesimus owes Philemon?

Paul wants Philemon to charge anything owed by Onesimus to Paul's account. 

# What does Philemon owe Paul?

Philemon owes Paul his very life. 

# Does Paul expect Philemon to send Onesimus back to him?

Yes, Paul is confident that Philemon will send Onesimus back. 

# Where will Paul come if he is released from prison?

Paul will come and visit Philemon if he is released from prison. 

