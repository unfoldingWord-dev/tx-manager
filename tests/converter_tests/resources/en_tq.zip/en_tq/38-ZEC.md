# During whose reign did Zechariah prophesy?

Zechariah prophesied during the reign of Darius. 

# Who was Zechariah?

Zechariah was the son of Berechiah, the son of Iddo the prophet. 

# What did Yahweh of hosts say he would do if the people would turn to him?

Yahweh of hosts said if the people would turn to him, he would return to them. 

# What did their fathers do when Yahweh told them to turn from their evil ways and wicked practices?

Their fathers would not hear and did not pay attention to Yahweh. 

# What did the people say when they repented?

When they repented the people said, "Yahweh of hosts's plans are made in keeping with his word and practice, and he has carried them out." 

# What did Zechariah see when the word of Yahweh came to him in the night?

Zechariah saw a man riding on a red horse among the myrtle trees in the valley. Behind him were red, reddish-brown, and white horses. 

# What were the horses that Zechariah saw?

The horses were those Yahweh had sent out to roam throughout the earth. 

# What did the horses who roamed throughout the earth find?

The horses found all the earth sitting still and at rest. 

# What question did the angel of Yahweh have for Yahweh concerning Jerusalem and the cities of Judah?

The angel of Yahweh asked Yahweh how long he would show no compassion to Jerusalem and the cities of Judah. 

# What did Yahweh of hosts say concerning Jerusalem and the cities of Judah?

Yahweh said he had returned to Jerusalem with mercies, that his house would be built within her and the measuring line would be stretched out over Jerusalem. Yahweh also said his cities would once again overflow with goodness and Yahweh would again comfort Zion and once again choose Jerusalem. 

# What did Yahweh of hosts say concerning Jerusalem and the cities of Judah?

Yahweh said he had returned to Jerusalem with mercies, that his house would be built within her and the measuring line would be stretched out over Jerusalem. Yahweh also said his cities would once again overflow with goodness and Yahweh would again comfort Zion and once again choose Jerusalem. 

# What were the four horns that Zechariah saw?

The four horns were those who had scattered Judah, Israel, and Jerusalem. 

# Who were the four blacksmiths that Zechariah saw and what were they going to do?

The blacksmiths were people who were going to drive out and cast down the horns of the nations who had lifted up any horn against the land of Judah to scatter her. 

# Who were the four blacksmiths that Zechariah saw and what were they going to do?

The blacksmiths were people who were going to drive out and cast down the horns of the nations who had lifted up any horn against the land of Judah to scatter her. 

# What was the young man going to do with the measuring line in his hand?

He was going to measure Jerusalem, to determine its width and its length. 

# Why did the second angel say that Jerusalem would sit in the open country?

The second angel said this because of the multitudes of men and beasts that would be within her. 

# What did Yahweh say he would become for Jerusalem?

Yahweh said he would become a wall of fire around her and he would be the glory in her midst. 

# What was Yahweh's declaration to those who lived with the daughter of Babylon?

Yahweh told them to escape to Zion. 

# How were they supposed to know that Yahweh of hosts had sent the second angel?

The second angel said Judah and Israel would know Yahweh had sent him when he shook his hand over the nations that plundered them and when the nations that plundered Judah and Israel were plundered for their slaves. 

# What will happen when Yahweh comes and encamps in Zion?

When that happens great nations will join themselves to Yahweh and those of Zion will become his people. 

# Why is all flesh told to be silent before Yahweh?

All flesh is told to be silent before Yahweh because Yahweh has been roused from out of the heavens. 

# Who was near Joshua the high priest?

Joshua was standing before Yahweh and Satan was standing at his right hand. 

# What was Satan doing at Joshua's right hand?

Satan was accusing Joshua of sin. 

# What was Joshua wearing as he stood before the angel?

Joshua was dressed in filthy garments. 

# What did the angel of Yahweh say he had done for Joshua?

The angel said he had caused Joshua's iniquity to pass from Joshua. 

# What happened concerning Joshua's clothing?

The angel commanded the filthy garments to be removed from Joshua and for Joshua to be clothed with fine clothing; a clean turban and clean garments. 

# What happened concerning Joshua's clothing?

The angel commanded the filthy garments to be removed from Joshua and for Joshua to be clothed with fine clothing; a clean turban and clean garments. 

# What did Yahweh promise Joshua, the high priest, if he would walk in Yahweh's ways and keep his commandments?

Yahweh promised Joshua that he would govern Yahweh's house and keep Yahweh's courts. Yahweh also promised that he would allow Joshua to come and go before those who stand before Yahweh. 

# What was the servant called that Yahweh himself was going to bring up?

That servant was called "the Branch." 

# What was the first part of the message to be engraved on the seven sided stone?

The first part of the message was that Yahweh would remove the sin from that land in one day. 

# According to Yahweh when will each man invite his neighbor to relax under his vine and under his fig tree?

Yahweh said this would occur "in that day". 

# What did Zechariah see when he was roused?

Zechariah saw a gold lampstand with a bowl on top, with seven lamps and two olive trees by the bowl. 

# What did Zechariah see when he was roused?

Zechariah saw a gold lampstand with a bowl on top, with seven lamps and two olive trees by the bowl. 

# Did Zechariah understand what the things in the vision meant?

No, Zechariah told the angel who was talking with him that he did not understand the meaning of those things in the vision. 

# Did Zechariah understand what the things in the vision meant?

No, Zechariah told the angel who was talking with him that he did not understand the meaning of those things in the vision. 

# What was the word of Yahweh to Zerubbabel about how things were going to get done?

The word of Yahweh to Zerubbabel was, "Not by might nor by power, but only by my Spirit." 

# What will be shouted when Zerubbabel brings out the top stone?

They will shout, "It is beautiful! May God bless it!" 

# How will the people know that Yahweh sent Zechariah to them?

The people will know when they see the prophecy fulfilled; the hand of Zerubbabel lay the foundation of that house and his hands finish it. 

# What will the people see in the hand of Zerubbabel?

The people will see the plumb stone in Zerubbabel's hand. 

# What did the the seven lamps mean?

The seven lamps are the eyes of Yahweh that roam over the whole earth. 

# What are the two olive branches?

The two olive branches are the two sons of oil who stand beside the Lord of the whole earth. 

# How big was the scroll that Zechariah saw?

The scroll was twenty cubits long and ten cubits wide. 

# What did the angel say the flying scroll was?

The angel said the flying scroll was the curse that goes out over the face of the whole land. 

# Who did the scroll curse?

The scroll was a curse to every thief and to everyone who swears a false oath. 

# What did the curse do to the thief and to the one who swears falsely by Yahweh's name?

The curse will enter their houses and remain there and consume the timber and stones of their houses. 

# What was in the basket that Zechariah saw and what did the angel say it was?

An ephah was in the basket that Zechariah saw, and the angel said the ephah "is their iniquity in the whole land." 

# What did the angel say the woman in the basket was?

The angel said of the woman in the basket, "This is Wickedness!" 

# What did the two women, who had wings like a stork's wings, do with the basket?

The two women lifted up the basket between earth and heaven. 

# Where were the women taking the basket and for what purpose?

The women took the basket to build a temple in Shinar for it, so that when the temple is ready, the basket will be set there on its prepared base. 

# What did Zechariah see coming out from between two bronze mountains?

Zechariah saw four chariots coming out from between two bronze mountains. 

# What color were the horses of each chariot?

The first chariot had red horses, the second had black horses, the third had white horses, and the fourth had spotted gray horses. 

# What color were the horses of each chariot?

The first chariot had red horses, the second had black horses, the third had white horses, and the fourth had spotted gray horses. 

# What did the angel say the chariots were?

The angel said the chariots were the four winds of heaven. 

# Where had these four chariots been?

These four chariots had been standing before the Lord of all the earth. 

# Where were the three chariots with the black, the white and the spotted gray horses going?

The chariot with the black horses went out to the north country. The chariot with white horses went out to the west country. The chariot with the spotted gray horses went out to the south country. 

# What was the chariot with the black horses that went out to the north country going to accomplish?

That chariot with the black horses was going to appease the angel's spirit concerning the north country. 

# What was Zechariah supposed to do with the offering he collected from Heldai, Tobijah, and Jedaiah?

Zechariah was told to take the offering into the house of Josiah, son of Zephaniah. Zechariah was to take the silver and gold, make a crown and set it upon the head of Joshua the son of Jehozadak, the high priest. 

# What was Zechariah supposed to do with the offering he collected from Heldai, Tobijah, and Jedaiah?

Zechariah was told to take the offering into the house of Josiah, son of Zephaniah. Zechariah was to take the silver and gold, make a crown and set it upon the head of Joshua the son of Jehozadak, the high priest. 

# What did Yahweh of hosts say Joshua son of Jehozadak, the high priest, would do?

Yahweh said Joshua would grow up where he is and build the temple of Yahweh, raise up its splendor, and then sit and rule on his throne. 

# What did Yahweh of hosts say Joshua son of Jehozadak, the high priest, would do?

Yahweh said Joshua would grow up where he is and build the temple of Yahweh, raise up its splendor, and then sit and rule on his throne. 

# Why was a crown to be placed in the temple of Yahweh?

A crown was to be placed in the temple of Yahweh to Heldai, Tobijah, and Jedaiah and as a memorial to the generosity of the son of Zephaniah. 

# What must the people do for these prophetic events to come true?

Yahweh said these events would happen "if you truly listen to the voice of Yahweh your God!" 

# Why did the people of Bethel send Sharezer, Regem Melech, and their men?

The people of Bethel sent them to beg for Yahweh's favor. 

# What did Sharezer, Melech, and their men ask the priest and the prophets?

They asked, "Should I mourn in the fifth month by means of a fast, as I have done these many years?" 

# What two questions did Yahweh ask the people of the land and the priests through Zechariah concerning fasting, eating and drinking?

The first question Yahweh asked was, "When you fasted and mourned in the fifth and seventh month for these seventy years, were you truly fasting for me?" The second question was, "And when you ate and drank, did you not eat and drink for yourselves?" 

# What two questions did Yahweh ask the people of the land and the priests through Zechariah concerning fasting, eating and drinking?

The first question Yahweh asked was, "When you fasted and mourned in the fifth and seventh month for these seventy years, were you truly fasting for me?" The second question was, "And when you ate and drank, did you not eat and drink for yourselves?" 

# Briefly, what was the last question Yahweh asked the priests and people of the land?

In brief, Yahweh asked if these were not the same words Yahweh told the people while they still inhabited Jerusalem, the surrounding cities, the Negev, and the western foothills. 

# What did Yahweh through Zechariah tell the people to do?

Yahweh said to judge with true justice, covenant faithfulness, and mercy. He said not to oppress the widow, the orphan, the foreigner or the poor person and not to do evil to one another. 

# What did Yahweh through Zechariah tell the people to do?

Yahweh said to judge with true justice, covenant faithfulness, and mercy. He said not to oppress the widow, the orphan, the foreigner or the poor person and not to do evil to one another. 

# What did Yahweh through Zechariah tell the people to do?

Yahweh said to judge with true justice, covenant faithfulness, and mercy. He said not to oppress the widow, the orphan, the foreigner or the poor person and not to do evil to one another. 

# What was the response of the people to Yahweh's instructions?

The people refused to pay attention to Yahweh's words. 

# What did Yahweh say he would do when those who formerly refused to listen to Yahweh called out to him?

Yahweh said he would not listen to them and, furthermore, he would scatter those people with a whirlwind to all the nations they had not seen. 

# What did Yahweh say he would do when those who formerly refused to listen to Yahweh called out to him?

Yahweh said he would not listen to them and, furthermore, he would scatter those people with a whirlwind to all the nations they had not seen. 

# How does Yahweh express his passion for Zion?

Yahweh expresses his passion for Zion with great zeal and great anger. 

# What will Jerusalem and the mountain of Yahweh be called when Yahweh returns to live in the midst of Jerusalem?

Jerusalem will be called "The City of Truth" and the mountain of Yahweh will be called "The Holy Mountain" when Yahweh returns to live in the midst of Jerusalem. 

# Who will again be found in the streets of Jerusalem?

Old men and old women will be in the streets, and the streets will be full of boys and girls playing in them. 

# Who will again be found in the streets of Jerusalem?

Old men and old women will be in the streets, and the streets will be full of boys and girls playing in them. 

# Where was Yahweh going to rescue his people from?

Yahweh was going to rescue his people from the land of the sunrise and from the land of the setting sun. 

# Why did Yahweh want the people to strengthen their hands?

Yahweh wanted the people to strengthen their hands so the temple could be rebuilt. 

# What happened before those days when the foundation of Yahweh's house was laid?

In those days, no crops were gathered in, there was no profit, and there was no peace from enemies. Yahweh set every person each against his neighbor. 

# How did Yahweh say it would be during Zechariah's time?

Yahweh said it would not be as in former days. He said seeds of peace would be sown. The climbing vine would give its fruit, and the earth would give its produce. The skies would give their dew. Yahweh would make the remnant of that people inherit all those things. 

# How did Yahweh say it would be during Zechariah's time?

Yahweh said it would not be as in former days. He said seeds of peace would be sown. The climbing vine would give its fruit, and the earth would give its produce. The skies would give their dew. Yahweh would make the remnant of that people inherit all those things. 

# How does Yahweh command the people to behave and why?

Yahweh said the people must all speak truth with his neighbor, and judge with truth, justice, and peace in their gates. He said let no one plot evil in their heart against their neighbor nor be attracted to false oaths. Yahweh commanded these things because they were things he hates. 

# How does Yahweh command the people to behave and why?

Yahweh said the people must all speak truth with his neighbor, and judge with truth, justice, and peace in their gates. He said let no one plot evil in their heart against their neighbor nor be attracted to false oaths. Yahweh commanded these things because they were things he hates. 

# In light of the fact that the fasts of the fourth, fifth, seventh and tenth months were going to be times of joy, gladness and happy festivals for the house of Judah, what were they told to do by Yahweh?

They were told to love truth and peace. 

# Who did Yahweh say would come to seek him and beg his favor?

Yahweh said many people from many different cities and mighty nations would come to seek Yahweh and beg his favor. 

# Who did Yahweh say would come to seek him and beg his favor?

Yahweh said many people from many different cities and mighty nations would come to seek Yahweh and beg his favor. 

# Who did Yahweh say would come to seek him and beg his favor?

Yahweh said many people from many different cities and mighty nations would come to seek Yahweh and beg his favor. 

# In those days, why will ten men from every language and nation ask to go up to Jerusalem with Yahweh's people?

They will ask to go up to Jerusalem with Yahweh's people for they will have heard that God is with them. 

# What does Yahweh's declaration concern?

Yahweh's declaration concerns the land of Hadrach and Damascus, Hamath, and Tyre and SIdon. 

# What does Yahweh's declaration concern?

Yahweh's declaration concerns the land of Hadrach and Damascus, Hamath, and Tyre and SIdon. 

# What does Yahweh say the Lord will do to Tyre?

Yahweh says, "The Lord will dispossess her and destroy her strength on the sea, so she will be devoured by fire. 

# What did Yahweh say he would do to the Philistines and what would become of them?

Yahweh said he would cut off the pride of the Philistines. Yahweh also said they would become a remnant for God like a clan in Judah. 

# What did Yahweh say he would do to the Philistines and what would become of them?

Yahweh said he would cut off the pride of the Philistines. Yahweh also said they would become a remnant for God like a clan in Judah. 

# What is one reason Yahweh gives for camping around his land?

Yahweh said he would camp around his land against enemy armies so no one could pass through or return, for he said no oppressor would pass through it any more. 

# Why is the daughter of Zion told to shout with great joy and the daughter of Jerusalem told to shout with happiness?

They are told to do this because their king is coming to them with righteousness and is going to rescue them. 

# How will their king come to them?

Their king will be humble and will ride on a donkey, on the colt of a donkey. 

# What will this king speak to the nations?

That king will speak peace to the nations. 

# What will be the extent of that king's dominion?

That king's dominion will be from sea to sea, and from the river to the ends of the earth. 

# Why has Yahweh set free their prisoners from the pit where there is no water?

Yahweh says he has done this because of the blood of his covenant with them. 

# Against whom has Yahweh roused the sons of Zion?

Yahweh has roused the sons of Zion against the sons of Greece. 

# What has Yahweh made Zion like?

Yahweh has made Zion like a warrior's sword. 

# What will Zion be on that day when Yahweh, their God, rescues them?

On that day, Zion will be the jewels of a crown raised up over Yahweh's land. 

# What will Yahweh do for Zion?

Yahweh will provide rain showers for Zion when they ask him, and plants in the field. 

# What causes the people to wander like sheep and suffer?

The people wander like sheep and suffer because the household idols speak falsely, the diviners envision a lie, they tell empty dreams and give empty comfort. The people also have no shepherd. 

# Who did Yahweh say he would punish?

Yahweh said he would punish the male goats – the leaders. 

# What did Yahweh say would come from the house of Judah?

Yahweh said the cornerstone, the tent peg, the war bow, and every leader would come from the house of Judah. 

# What did Yahweh say he would do for the houses of Judah and Joseph?

Yahweh said he would strengthen the house of Judah and save the house of Joseph. Yahweh said he would restore them, have mercy on them. 

# What will Judah and Ephraim do when they remember Yahweh in the distant countries where Yahweh has sown them?

They and their children will live and return when they remember Yahweh in the distant countries where he has sown them. 

# What did Yahweh say he would do to Egypt and Assyria after he gathers those of the house of Judah from those places?

Yahweh said he would bring down the majesty of Assyria and make the scepter of Egypt go away from the Egyptians. 

# Why do the shepherds howl?

The shepherds howl because their glory has been destroyed. 

# What did Yahweh tell Zechariah to do?

Yahweh told Zechariah to, "Shepherd the flock meant for slaughter!" 

# What did Yahweh say he would do to the inhabitants of Judah?

Yahweh said he would no longer pity them but cause each man to fall into his shepherd's hands and into his king's hands, and they would crush the land. 

# What were the names of the two staffs that Zechariah used to shepherd the flock meant for the slaughter?

The names of the two staffs were "Favor" and "Unity." 

# Why did Zechariah destroy three shepherds in one month?

Zechariah did this because he grew weary with the shepherds and they also hated him. 

# Why did Zechariah break his staff, "Favor"?

He broke it to break the covenant that he had made with all his tribes. 

# How much was Zechariah paid?

Zechariah was paid thirty pieces of silver. 

# What did Yahweh tell Zechariah to do with his thirty pieces of silver?

Zechariah was told to deposit the silver in the treasury. 

# What did breaking the second staff, "Unity," do?

Breaking the second staff broke the brotherhood between Judah and Israel. 

# Yahweh said he would raise up a shepherd in the land. What will that shepherd do?

That shepherd will not care for the sheep. He will not seek the sheep who have gone astray, nor heal the crippled sheep. He will not feed the steadfast sheep, but will eat the fattened sheep and tear off their hooves. 

# What curse is pronounced upon the worthless shepherd who forsakes the flock?

This is the curse: "May the sword come against his right arm and his right eye! May his right arm wither away and his right eye be blind!" 

# Who is Yahweh who makes this declaration concerning Israel?

Yahweh is the one who stretched out the skies and laid the foundation of the earth, who fashions the spirit of mankind within him. 

# Who is going to gather against Jerusalem?

All the nations of the earth are going to gather against Jerusalem.. 

# On the day when all the nations gather against Judah, what specific things did Yahweh say he would do to the horses and riders of the enemy armies?

Yahweh said he would strike every horse with terror and each rider with madness. Yahweh also said he would strike every horse of the armies blind. 

# In that day, what will the leaders of Judah be like?

In that day, the leaders will be like fire pots among wood and like a flaming torch to standing grain. 

# Why will Yahweh save the tents of Judah first?

Yahweh will save the tents of Judah first so that the honor of the house of David and the honor of those who live in Jerusalem may not be greater than the rest of Judah. 

# What is Yahweh determined to do on that day?

Yahweh said that on that day he is determined to destroy all the nations who come against Jerusalem. 

# On that day, what will Yahweh pour out on the house of David and the inhabitants of Jerusalem?

Yahweh will pour out a spirit of compassion and supplication. 

# What will the house of David and the inhabitants of Jerusalem do when they look upon him whom they have pierced?

When they look on him whom they have pierced, they will lament and mourn for him as one mourns and laments for an only son or over the death of a firstborn son. 

# How will the land mourn in that day?

In that day, each family will mourn separately from other families and in each family they will mourn separately, their wives will be separate from the men. 

# How will the land mourn in that day?

In that day, each family will mourn separately from other families and in each family they will mourn separately, their wives will be separate from the men. 

# How will the land mourn in that day?

In that day, each family will mourn separately from other families and in each family they will mourn separately, their wives will be separate from the men. 

# For what will the spring be that is opened for the house of David on that day?

The spring will be for their sin and impurity. 

# What will Yahweh cut off from the land and why?

Yahweh will cut off the names of idols from the land so they will no longer be remembered. 

# What will Yahweh cause to pass out of the land?

Yahweh will cause the false prophets and their unclean spirits to pass out of the land. 

# If any man continues to prophesy, what will his father and mother do to him?

His father and mother who bore him will impale him when he prophesies. 

# In that day, why will he who prophesies no longer wear a hairy cloak?

He who prophesies will no longer wear a hairy cloak so that he might deceive the people. 

# Who is the shepherd?

The shepherd is "the man who stands close to me." 

# What will happen to the flock when the shepherd is killed?

When the shepherd is killed the flock will scatter. 

# What does Yahweh declare will happen throughout all the land?

Yahweh declares that two portions of it will be cut off. They will perish; only a third will remain there. 

# What will happen to the third that remain there?

The third that remain there will be brought through the fire, refined and tested. 

# What will the third that remain there say?

The third that remain there will say, "Yahweh is my God!" 

# Why will Jerusalem's plunder be divided in their midst?

Jerusalem's plunder will be divided in their midst because Yahweh will gather every nation against Jerusalem for battle, and the city will be captured. The houses will be plundered. 

# What will happen to the nations that fought against Jerusalem?

Yahweh will go out and wage war against those nations as when he wages war on the day of battle. 

# What will happen to the Mount of Olives when Yahweh stands on it?

The Mount of Olives will be split in half with a very great valley between the two halves. 

# When will Yahweh and the holy ones come?

Yahweh and the holy ones will come after the inhabitants of Jerusalem flee down the valley between Yahweh's mountains. 

# Where will the running water go that flows from Jerusalem?

Half of the water will go to the eastern sea, and half will flow toward the western sea. 

# Who will be king over all the earth?

Yahweh will be king over all the earth. 

# Will God destroy Jerusalem?

There will be no more destruction from God against them; Jersusalem will live in safety. 

# With what plague will Yahweh attack all the peoples that waged war against Jerusalem?

The flesh, eyes, and tongues of all the people that waged war against Jerusalem will rot. 

# What will happen when that great fear from Yahweh comes among them?

Each man will seize his neighbor's hand; each hand will be raised against its neighbor's hand. 

# What will all who remain in those nations that came against Jerusalem do?

All those who remain in those nations will go up from year to year to worship the king, Yahweh of hosts, and to keep the Festival of Shelters. 

# What will happen if anyone from all the nations of the earth does not go up to Jerusalem to worship the king, Yahweh of hosts?

If anyone does not go up to Jerusalem, Yahweh will not bring rain on them. A plague from Yahweh will attack the nations that do not go up to keep the Festival of Shelters. 

# What will happen if anyone from all the nations of the earth does not go up to Jerusalem to worship the king, Yahweh of hosts?

If anyone does not go up to Jerusalem, Yahweh will not bring rain on them. A plague from Yahweh will attack the nations that do not go up to keep the Festival of Shelters. 

# On that day who will no longer be in the house of Yahweh of hosts?

On that day traders will no longer be in the house of Yahweh of hosts. 

