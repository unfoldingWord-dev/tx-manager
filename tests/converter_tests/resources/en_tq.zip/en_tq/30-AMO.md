# How did Amos receive the things he spoke concerning Israel?

Amos received the things he spoke concerning Israel in revelation. 

# What was Amos' occupation?

Amos was a shepherd. 

# Why did Yahweh declare punishment against Damascus?

Yahweh declared punishment against Damascus because they threshed Gilead with instruments of iron. 

# Why did Yahweh declare punishment against Gaza?

Yahweh declared punishment against Gaza because they carried away captive a whole people to hand them over to Edom. 

# What did Yahweh declare he would do to the fortresses of Ben Hadad, Gaza, and Tyre?

Yahweh declared he would devour the fortresses of Ben Hadad, Gaza, and Tyre. 

# Why did Yahweh declare punishment against Tyre?

Yahweh declared punishment against Tyre because they handed over whole people groups to Edom and broke their treaty of brotherhood. 

# Why did Yahweh declare punishment against Edom?

Yahweh declared punishment against Edom because he pursued his brother with the sword. 

# Why did Yahweh declare punishment against Ammon?

Yahweh declared punishment against Ammon because they ripped open the pregnant women of Gilead. 

# What did Yahweh declare he would do to the palaces of Rabbah?

Yahweh declared he would devour the palaces of Rabbah. 

# What did Yahweh declare would happen to the king of Ammon?

Yahweh declared the king of Ammon would go into captivity. 

# Why did Yahweh declare punishment against Moab?

Yahweh declared punishment against Moab because Moab burned the bones of the king of Edom. 

# Why did Yahweh declare punishment against Judah?

Yahweh declared punishment against Judah because Judah rejected the law of Yahweh. 

# What did Yahweh declare he would do to the fortresses of Moab and Judah?

Yahweh declared he would devour the fortresses of Moab and Judah. 

# Why did Yahweh declare punishment against Israel?

Yahweh declared punishment against Israel because Israel trampled the heads of the poor. 

# How had the Israelites been able to defeat the Amorites?

The Israelites had been able to defeat the Amorites because Yahweh destroyed the Amorites before them. 

# What did the Israelites do with the prophets Yahweh had raised up among them?

The Israelites commanded the prophets not to prophesy. 

# What did the Israelites do with the Nazarites Yahweh had raised up among them?

The Israelites persuaded the Nazarites to drink wine. 

# What will the swift person and the strong person not be able to do?

The swift person will find no escape and the strong will not add to his own strength. 

# What did Yahweh declare concerning the archer, the fast runner, the horseman, and the bravest warriors?

Yahweh declared the archer will not stand, the fast runner will not escape, the horseman will not save himself, and even the bravest warriors will flee naked in that day. 

# What did Yahweh declare concerning the archer, the fast runner, the horseman, and the bravest warriors?

Yahweh declared the archer will not stand, the fast runner will not escape, the horseman will not save himself, and even the bravest warriors will flee naked in that day. 

# Against whom is this word of Yahweh?

This word of Yahweh is against the people of Israel, the whole family Yahweh brought up out of Egypt. 

# Who did Yahweh choose from all the families of the earth?

Yahweh chose Israel from all the families of the earth. 

# What must two persons do in order to walk together?

Two persons must agree in order to walk together. 

# When disaster comes on a city, who has sent it?

When disaster comes on a city, Yahweh has sent it. 

# What does Yahweh do before he takes action?

Yahweh reveals his plan to his prophets before he takes action. 

# What would Egypt see if they saw what was happening in Samaria?

Egypt would see great confusion and oppression in Samaria. 

# What was Israel storing up in their fortresses?

Israel was storing up violence and destruction in their fortresses. 

# What punishment does Yahweh declare against Israel?

Yahweh declares that an enemy will plunder the fortresses of Israel. 

# Who will escape Yahweh's punishment?

Only a few will escape Yahweh's punishment. 

# In the day Yahweh punishes the sins of Israel, who else will he punish?

Yahweh will also punish the altars of Bethel, of the house of Jacob. 

# In the day Yahweh punishes the sins of Israel, who else will he punish?

Yahweh will also punish the altars of Bethel, of the house of Jacob. 

# What name does Yahweh give the wives of the rich who live in Samaria?

Yahweh calls the wives of the rich, "cows of Bashan". 

# What are the wives of the rich in Samaria doing to the poor?

The wives of the rich are oppressing the poor and crushing the needy. 

# What does Yahweh declare will happen to the wives of the rich in Samaria?

Yahweh declares the wives will be taken away with hooks and driven out from the city. 

# What pleases the people of Israel?

The people of Israel are pleased to sin in Bethel and multiply sin in Gilgal, to bring sacrifices and tithes, to offer a thanksgiving sacrifice, and proclaim freewill offerings. 

# What pleases the people of Israel?

The people of Israel are pleased to sin in Bethel and multiply sin in Gilgal, to bring sacrifices and tithes, to offer a thanksgiving sacrifice, and proclaim freewill offerings. 

# What did Yahweh do to the rain so that the people of Israel would return to him?

Yahweh withheld rain from Israel so that the people of Israel would return to him. 

# What did Yahweh do to the gardens, vineyards, and trees so that the people of Israel would return to him?

Yahweh afflicted the gardens, vineyards, and trees with blight and mildew, and devoured them with locusts. 

# What did Yahweh do to the young men so that the people of Israel would return to him?

Yahweh killed the young men with the sword so that the people of Israel would return to him. 

# What did Yahweh do to the cities so that the people of Israel would return to him?

Yahweh overthrew the cities so that the people of Israel would return to him. 

# How did the people of Israel respond to Yahweh's attempts to cause them to return?

The people of Israel did not return to Yahweh. 

# What does Yahweh tell the people of Israel they must now prepare to do?

Yahweh tells the people of Israel they must now prepare to meet their God. 

# Who formed the mountains and revealed his thoughts to mankind?

Yahweh, God of hosts, formed the mountains and revealed his thoughts to mankind. 

# Who has fallen in this lament?

The virgin Israel has fallen in this lament. 

# Who has fallen in this lament?

The virgin Israel has fallen in this lament. 

# What does Yahweh tell the house of Israel to do?

Yahweh tells the house of Israel to seek him and live. 

# What does Yahweh bring on the strong?

Yahweh brings sudden destruction on the strong. 

# Who do the strong hate and abhor?

The strong hate those who correct them, and abhor anyone who speaks the truth. 

# What had the strong done, for which Yahweh will punish them?

The strong had trampled down the poor, for which Yahweh will punish them. 

# What does a prudent person do at such an evil time?

A prudent person is silent at such an evil time. 

# What should the people do so that Yahweh is really with them?

The people should seek good and not evil, so that Yahweh is really with them. 

# What will be heard in the streets when Yahweh passes through the people's midst?

Wailing and woes will be heard in the streets when Yahweh passes through the people's midst. 

# What will be heard in the streets when Yahweh passes through the people's midst?

Wailing and woes will be heard in the streets when Yahweh passes through the people's midst. 

# What will the day of Yahweh be?

The day of Yahweh will be darkness and gloom. 

# What does Yahweh think about the solemn assemblies of the people?

Yahweh takes no delight in the solemn assemblies of the people. 

# What does Yahweh want to see flowing from the people?

Yahweh wants to see justice and righteousness flowing from the people. 

# What had the people made for themselves?

The people had made for themselves idols. 

# Where will Yahweh send the people?

Yahweh will exile the people beyond Damascus. 

# On whom does Yahweh declare a woe?

Yahweh declares a woe on those at ease in Zion, and those secure in Samaria. 

# What are those receiving Yahweh's woe doing with their time?

Those receiving Yahweh's woe are using their time lounging, feasting, singing songs, and drinking. 

# What are those receiving Yahweh's woe doing with their time?

Those receiving Yahweh's woe are using their time lounging, feasting, singing songs, and drinking. 

# What are those receiving Yahweh's woe not doing with their time?

Those receiving Yahweh's woe are not using their time grieving over the ruin of Joseph. 

# Where are those receiving Yahweh's woe now going?

Those receiving Yahweh's woe are now going into exile. 

# What does Yahweh hate about these people of Jacob?

Yahweh hates the pride and fortresses of these people of Jacob. 

# What will happen to the houses of these people of Jacob?

Their houses will be smashed to bits. 

# What have these people of Jacob done to justice and righteousness?

These people of Jacob have turned justice into poison and righteousness into bitterness. 

# What does Yahweh declare he will do against the house of Israel?

Yahweh declares he will raise up a nation against the house of Israel. 

# What will this nation do against the house of Israel?

This nation will afflict the house of Israel. 

# In his vision, what did Amos see Yahweh forming in the spring?

Amos saw Yahweh forming a locust swarm in the spring to eat the vegetation of the land. 

# When Amos asked Yahweh to forgive Jacob and not bring this disaster on them, what did Yahweh answer?

Yahweh answered that this disaster would not happen. 

# When Amos asked Yahweh to forgive Jacob and not bring this disaster on them, what did Yahweh answer?

Yahweh answered that this disaster would not happen. 

# In his vision, on what did Amos see Yahweh calling?

Amos saw Yahweh calling on fire to judge. 

# When Amos asked Yahweh to forgive Jacob and not bring this disaster on them, what did Yahweh answer?

Yahweh answered that this disaster also would not happen. 

# When Amos asked Yahweh to forgive Jacob and not bring this disaster on them, what did Yahweh answer?

Yahweh answered that this disaster also would not happen. 

# In his vision, what did Amos see the Lord standing and doing?

Amos saw the Lord standing beside a wall with a plumb line in his hand. 

# What did the Lord say was the meaning of the plumb line?

The Lord said the plumb line meant Israel would be spared no longer. 

# What did Yahweh declare he would do to Israel?

Yahweh declared he would destroy the high places and sanctuaries of Israel. 

# Of what was Amos accused by Amaziah, priest of Bethel?

Amos was accused of conspiring against Jeroboam, king of Israel. 

# What had Amos prophesied about Jeroboam?

Amos had prophesied that Jeroboam would die by the sword. 

# To where was Amos told to return and prophesy?

Amos was told to return to the land of Judah and prophesy there. 

# What was Amos' work before Yahweh took him to be his prophet?

Amos was a herdsman and keeper of sycamore fig trees. 

# What was Amos' work before Yahweh took him to be his prophet?

Amos was a herdsman and keeper of sycamore fig trees. 

# What did Yahweh declare against Amaziah, priest of Bethel?

Yahweh declared that Amaziah would die in an unclean land, his wife would be a prostitute, his sons and daughters would be killed, and his land would be divided up. 

# What did Yahweh declare he would do with Israel?

Yahweh declared he would exile Israel from its land. 

# What did Yahweh show Amos?

Yahweh showed Amos a basket of summer fruit. 

# What did Yahweh show Amos?

Yahweh showed Amos a basket of summer fruit. 

# What did Yahweh say had come for his people Israel?

Yahweh said the end had come for his people Israel. 

# What sins had the people of Israel committed?

The people of Israel had trampled the needy and removed the poor of the land. 

# Why were the people anxious for the new moon and Sabbath to be over?

The people were anxious because they wanted to sell grain again and cheat the poor. 

# Why were the people anxious for the new moon and Sabbath to be over?

The people were anxious because they wanted to sell grain again and cheat the poor. 

# What did Yahweh say he would never do with any of the people's actions?

Yahweh said he would never forget any of the people's actions. 

# In that day, what did Yahweh say he would do to the sun?

In that day, Yahweh said he would make the sun set at noon. 

# What would the people wear on that day?

The people would wear sackcloth on that day. 

# What famine did Yahweh say he would send in the land?

Yahweh said he would send a famine in the land for hearing the words of Yahweh. 

# In that day, who would faint from thirst?

In that day, the virgins and young men would faint from thirst. 

# Who does Yahweh say would never rise again?

Those who swear by the sin of Samaria would never rise again. 

# Who will escape the Lord's judgment of Israel?

Not one of them will escape the Lord's judgment. 

# What will the Lord do to those who would hide in the bottom of the sea?

The Lord will give orders to the serpent to bite them. 

# For what purpose will the Lord keep his eyes on Israel?

The Lord will keep his eyes on Israel for harm. 

# What do the people do when Yahweh touches the land to melt it?

The people mourn when Yahweh touches the land to melt it. 

# From where did Yahweh bring up Israel?

Yahweh brought up Israel from the land of Egypt. 

# From where did Yahweh bring the Philistines?

Yahweh brought the Philistines from Crete. 

# Does Yahweh say he will totally destroy the people of Israel?

No, Yahweh says he will not totally destroy the people of Israel. 

# What were the sinners in Israel saying, those that Yahweh will kill?

The sinners were saying that disaster would not overtake them. 

# In that day, what does Yahweh say he will raise up?

In that day, Yahweh says that he will raise up the tent of David that has fallen. 

# With what does Yahweh say the mountains will drip and the hills will flow in the coming days?

In the coming days, the mountains will drip and the hills will flow with sweet wine. 

# From what does Yahweh promise to bring Israel back?

Yahweh promises to bring Israel back from captivity. 

# After Yahweh brings back Israel, how long will Israel remain in the land?

After Yahweh brings back Israel, Israel will remain in the land forever. 

