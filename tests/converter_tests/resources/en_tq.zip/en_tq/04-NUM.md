# Who did Yahweh tell Moses to count in the census?

He told Moses to count all the men of Israel, every male who was twenty years old or older. 

# Who did Yahweh tell Moses to count in the census?

He told Moses to count all the men of Israel, every male who was twenty years old or older. 

# Who did Yahweh tell Moses to count in the census?

He told Moses to count all the men of Israel, every male who was twenty years old or older. 

# Who would serve Moses as tribe leaders?

A man from every tribe, a clan head, would serve as his tribe's leader. 

# How did each man identify his ancestry?

He had to name the clans and families descended from his ancestors. 

# How many men from the tribes twenty years old or older who could fight in a war were recorded?

There were 603,550 men from the tribes. 

# The men from what tribe were not to be counted?

The men from the tribe of Levi were not counted. 

# For what were the Levites assigned to care?

They were assigned to care for the tabernacle, for all the furnishings in the tabernacle, and for everything in it. 

# What were the Levites to do to any stranger who came near the tabernacle?

The Levites were to kill strangers that came near the tabernacle. 

# Where were the people of Israel to set up their tents?

Each man was to set up his tent near the banner that belonged to his armed group. 

# Where were the Levities to set up their tents?

They were to set up their tents around the tabernacle of the covenant decrees. 

# Did the people do what Yahweh commanded?

Yes, they did everything commanded by Yahweh through Moses. 

# Where did Yahweh tell Moses and Aaron for the tribes to put their tents?

Yahweh told the tribes to put their tents around the banner of their armed group and around a smaller flag indicating their tribe. Their camps were to face the tent of meeting. 

# Where did Yahweh tell Moses and Aaron for the tribes to put their tents?

Yahweh told the tribes to put their tents around the banner of their armed group and around a smaller flag indicating their tribe. Their camps were to face the tent of meeting. 

# Where did Moses say the 74,600 men of the army of the tribe of Judah must camp, and who must lead their army?

They must camp around Judah's banner to the east of the tent of meeting where the sun rises, and that Nahshon must lead their army. 

# Where did Moses say the 74,600 men of the army of the tribe of Judah must camp, and who must lead their army?

They must camp around Judah's banner to the east of the tent of meeting where the sun rises, and that Nahshon must lead their army. 

# Where must the 54,400 men of the tribe of Issachar camp, and who must lead their army?

They must camp next to Judah, and Nethanel must lead the army. 

# Where must the 54,400 men of the tribe of Issachar camp, and who must lead their army?

They must camp next to Judah, and Nethanel must lead the army. 

# Where must the 57,400 men of the tribe of Zebulun camp and who must lead their army?

They must camp next to Issachar, and Eliab must lead the army. 

# Where must the 57,400 men of the tribe of Zebulun camp and who must lead their army?

They must camp next to Issachar, and Eliab must lead the army. 

# Who is to go first out of the camp?

All the armies that camp with Judah would go first out of the camp. 

# Where must the 46,500 men of the tribe of Reuben camp, and who must lead their army?

They must camp around the banner of Rueben on the south side, and Elizur must lead the army. 

# Where must the 46,500 men of the tribe of Reuben camp, and who must lead their army?

They must camp around the banner of Rueben on the south side, and Elizur must lead the army. 

# Where must the 59,300 men of the tribe of Simeon camp, and who must lead their army?

They must camp next to Rueben, and Shelumiel must lead their army. 

# Where must the 59,300 men of the tribe of Simeon camp, and who must lead their army?

They must camp next to Rueben, and Shelumiel must lead their army. 

# Where must the 45,650 men of the tribe of Gad camp, and who must lead their army?

They must camp next, and Eliasaph must lead their army. 

# Where must the 45,650 men of the tribe of Gad camp, and who must lead their army?

They must camp next, and Eliasaph must lead their army. 

# Who is to go second out of the camp?

All the armies that camp together with Reuben must go out second. 

# How many people were numbered in the camp of Ephraim?

There were 108,100 people numbered in the camp of Ephraim. 

# When was the camp of Ephraim supposed to set out in relation to the other camps?

The camp of Ephraim was supposed to set out third. 

# Who was the leader of the people of Dan?

The leader of the people of Dan was Ahiezer son of Ammishaddai. 

# Whom did Moses and Aaron not count among the people of Israel and why?

Moses did not count the Levites among the people of Israel because this was as Yahweh had commanded Moses. 

# Whom did Moses and Aaron not count among the people of Israel and why?

Moses did not count the Levites among the people of Israel because this was as Yahweh had commanded Moses. 

# What did the people of Israel do?

The people of Israel did everything that Yahweh commanded Moses—camped by their banners and went out from camp by their clans in the order of their ancestor's families. 

# Of what was this the history?

This was the history of the descendants of Aaron and Moses. 

# What were the names of Aaron's sons?

The names of Aaron's sons were Nadab, Abihu, Eleazar, and Ithamar. 

# Why did Nadab and Abihu fall dead before Yahweh?

Nadab and Abihu fell dead before Yahweh when they offered unacceptable fire to him. 

# Which of Aaron's sons served as priests with Aaron?

Eleazar and Ithamar served with their father Aaron as priests. 

# Which tribe did Yahweh say was to help Aaron serve as priest?

The tribe of Levi was to help Aaron. 

# What were the duties of the tribe of Levi?

They were to perform the duties on behalf of Aaron and the whole community, care for all furnishings, and help the tribes with the tabernacle service. 

# What were the duties of the tribe of Levi?

They were to perform the duties on behalf of Aaron and the whole community, care for all furnishings, and help the tribes with the tabernacle service. 

# Whom did Yahweh give to help Aaron and his sons?

Yahweh gave the Levites to Aaron and his sons to serve as priests for the people of Israel. 

# Whom did Yahweh give to help Aaron and his sons?

Yahweh gave the Levites to Aaron and his sons to serve as priests for the people of Israel. 

# Whom did Yahweh set apart for himself?

Yahweh set apart for himself the Levites and all the firstborn in Israel, both people and animals. 

# Whom did Yahweh set apart for himself?

Yahweh set apart for himself the Levites and all the firstborn in Israel, both people and animals. 

# Whom did Yahweh set apart for himself?

Yahweh set apart for himself the Levites and all the firstborn in Israel, both people and animals. 

# When did God set apart all the firstborn of Israel?

He set apart for himself all the firstborn in Israel on the day that he attacked all the firstborn in the land of Egypt. 

# Whom did Yahweh command Moses to count in the tribe of Levi?

Yahweh commanded Moses to count every male in Levi who was one month old and older. 

# Whom did Yahweh command Moses to count in the tribe of Levi?

Yahweh commanded Moses to count every male in Levi who was one month old and older. 

# Who were the sons of Levi?

The sons of Levi were Gershon, Kohath, and Merari. 

# Where were the clans of the Gershonites to camp?

The clans of the Gershonites were to camp on the west side of the tabernacle. 

# Who was to lead the clans of the descendants of the Gershonites?

Eliasaph the son of Lael was to lead the clans of the descendants of the Gershonites. 

# Who was to care for the tabernacle curtains, the tent, the tent covering, the entrance curtain, the courtyard hangings, the courtyard entrance curtain, and the courtyard, ropes, and all that was in the tent of meeting?

The clans of the Gershonites who camped on the west side of the tabernacle were to care for the tabernacle coverings, curtain, and ropes. 

# Who was to care for the tabernacle curtains, the tent, the tent covering, the entrance curtain, the courtyard hangings, the courtyard entrance curtain, and the courtyard, ropes, and all that was in the tent of meeting?

The clans of the Gershonites who camped on the west side of the tabernacle were to care for the tabernacle coverings, curtain, and ropes. 

# What were the clans from Kohath who camped on the south side of the tabernacle do?

They were to take care of the sanctuary, the sanctuary curtain, and everything in the sanctuary. 

# Who was Eleazar the son of Aaron the priest to supervise?

He was to supervise the men who led the Levites and the men who cared for the sanctuary. 

# Who was to lead the clans of Merari who camped on the north side of the tabernacle?

Zuriel son of Abihail was to lead the clans of Merari. 

# What were the clans from Merari who camped on the north side of the tabernacle do?

They were to care for the boards of the tabernacle, the crossbars, posts, bases, all of the hardware, and everything that went with them. 

# What were the clans from Merari who camped on the north side of the tabernacle do?

They were to care for the boards of the tabernacle, the crossbars, posts, bases, all of the hardware, and everything that went with them. 

# What were Moses and Aaron and sons who were camped on the east of the tabernacle do?

They were to do the duties of the sanctuary and the duties of the people of Israel. 

# What was to happen to any foreigner who approached the sanctuary?

Any foreigner who approached the sanctuary was to be put to death. 

# Whom did Moses and Aaron count?

Moses and Aaron counted all the males in the clans of Levi who were one month old and older. 

# Whom did Moses take for Yahweh instead of the firstborn of Israel and instead of their livestock?

Moses took the Levites and their livestock instead of Israel's firstborn men and livestock. 

# Then whom did Moses count?

Moses counted all the firstborn males of Israel by name, aged one month old and older. 

# To whom did all the Levites belong?

The Levites belonged to Yahweh. 

# How many sanctuary shekels did Moses collect per firstborn to buy back each of the 273 firstborn people of Israel who exceeded the number of the Levites?

Moses collected 5 shekels each to buy back each of the 273 firstborn people of Israel who exceeded the number of the Levites. 

# To whom did Moses give the money to buy back the first born of the people of Israel?

He gave the money to Aaron and his sons as Yahweh had commanded him. 

# How much did Moses do of what he was told to do by Yahweh's word?

Moses did everything he was told to do by Yahweh's word. 

# What were Moses and Aaron to conduct?

Moses and Aaron were to conduct a census of the male descendants of Kohath from among the Levites who were 30 to 50 years old. 

# What were Moses and Aaron to conduct?

Moses and Aaron were to conduct a census of the male descendants of Kohath from among the Levites who were 30 to 50 years old. 

# What were Moses and Aaron to conduct?

Moses and Aaron were to conduct a census of the male descendants of Kohath from among the Levites who were 30 to 50 years old. 

# What were the descendants of Kohath to do to serve in the tent of meeting?

They were to care for the most holy things reserved for Yahweh in the tent of meeting. 

# What were Aaron and his sons to take down when the camp moved forward?

They were to go into the tent to take down the curtain that separated the most holy place from the holy place, cover the ark of the covenant with sea cow skins and a blue cloth, and then insert poles to carry it. 

# What were Aaron and his sons to take down when the camp moved forward?

They were to go into the tent to take down the curtain that separated the most holy place from the holy place, cover the ark of the covenant with sea cow skins and a blue cloth, and then insert poles to carry it. 

# On what were Aaron and his sons to spread a blue cloth and then put on that the dishes, spoons, bowls, and jars for pouring?

They were to spread a blue cloth on the bread of presence and then put on that the dishes, spoons, bowls, and jars for pouring. 

# What was always to be on the table?

Bread was always to be on the table of the bread of the presence. 

# How were the lampstands and all its accessories to be prepared for moving?

They put a blue cloth cover over the lampstand with all its accessories, covered it with sea cow skins, and put it on a carrying frame. 

# How were the lampstands and all its accessories to be prepared for moving?

They put a blue cloth cover over the lampstand with all its accessories, covered it with sea cow skins, and put it on a carrying frame. 

# Then what were they to use after that to cover the bread of presence and what were they to insert in it to carry the table?

They were cover the bread of presence then with a scarlet cloth and again with sea cow skins, and then they were to insert poles with which to carry it. 

# How was the gold altar and its equipment prepared for moving?

The gold altar and all of its equipment were to be wrapped in blue cloth, covered with sea cow skins, and then insert the carrying poles. 

# How was all the equipment for the work in the sanctuary to be prepared?

All the equipment for the work in the sanctuary was to be wrapped in a blue cloth, covered with sea cow skins, and then put on the carrying frame. 

# What did they remove from the altar, and what must they spread on the altar?

They removed the ashes from the altar and spread a purple cloth on it. 

# Where was all the equipment that they used in the work of the altar placed?

All the equipment that they used in the work of the altar was placed on the carrying frame. 

# With what would was the altar covered before they inserted the carrying poles?

The altar was covered with sea cow skins before they inserted the carrying poles. 

# Who came to carry the sanctuary after Aaron and his sons completed covering the sanctuary and all its equipment when the camp was ready to move forward?

The descendants of Kohath came to carry the sanctuary after Aaron and his sons completed covering it and the camp was ready to move forward. 

# For what did Eleazar son of Aaron have to care and supervise?

He had to care for the oil and the light as well as supervise the care of the sweet incense, the regular grain offering, the anointing oil, the entire tabernacle and all that was in it. 

# From among whom could the Kohathite clans not be removed that they would live and not die?

The Kohathite clans could not be removed from among the Levites that they would live and not die. 

# From among whom could the Kohathite clans not be removed that they would live and not die?

The Kohathite clans could not be removed from among the Levites that they would live and not die. 

# About what did Yahweh warn Moses and Aaron that the Kohathite tribal clans could not go in to see or they would die?

The Kohathites tribal clans could not go in to see the sanctuary or they would die. 

# Who only was allowed to go into the sanctuary?

Only Aaron and his sons were allowed to go into the sanctuary. 

# What does Yahweh tell Moses to do concerning counting of those who served in the tent of meeting from the Gershon clans?

Moses was to conduct a census counting those who are thirty years old to fifty years old. 

# What does Yahweh tell Moses to do concerning counting of those who served in the tent of meeting from the Gershon clans?

Moses was to conduct a census counting those who are thirty years old to fifty years old. 

# What was the work of the Gershonites?

The work of the Gershonites was to carry all the curtains and coverings of the tabernacle and the tent of meeting and its covering of sea cow skin as well as the curtains of the court and its doorway and their ropes and all the instruments for their service. 

# What was the work of the Gershonites?

The work of the Gershonites was to carry all the curtains and coverings of the tabernacle and the tent of meeting and its covering of sea cow skin as well as the curtains of the court and its doorway and their ropes and all the instruments for their service. 

# What was the work of the Gershonites?

The work of the Gershonites was to carry all the curtains and coverings of the tabernacle and the tent of meeting and its covering of sea cow skin as well as the curtains of the court and its doorway and their ropes and all the instruments for their service. 

# Who was to direct all service of the descendants of the Gershonites who were being led by Ithamar the priest?

Aaron and his sons must direct all the service of the descendants of the Gershonites. 

# Who was to direct all service of the descendants of the Gershonites who were being led by Ithamar the priest?

Aaron and his sons must direct all the service of the descendants of the Gershonites. 

# What was the Merari clan to do in their service for the tent of meeting?

They were to care for the framing of the tabernacle, along with the posts, their hardware, and their ropes plus make a list of what they must carry. 

# What was the Merari clan to do in their service for the tent of meeting?

They were to care for the framing of the tabernacle, along with the posts, their hardware, and their ropes plus make a list of what they must carry. 

# What did Moses, Aaron, and the leaders of Israel do to obey Yahweh?

They counted all the men of the Kohathites who were thirty to fifty years old by the type of work he was assigned to do in the tabernacle, and they counted who would carry and care for the items in the tent of meeting. 

# What did Moses, Aaron, and the leaders of Israel do to obey Yahweh?

They counted all the men of the Kohathites who were thirty to fifty years old by the type of work he was assigned to do in the tabernacle, and they counted who would carry and care for the items in the tent of meeting. 

# Who else was counted in their clans from 30-50 years old?

The descendants of Gershon were counted in their clans. 

# Who else did Moses and Aaron count in their clans from 30-50 years old?

The descendants of Merari were counted in their clans. 

# Who else did Moses and Aaron count in their clans from 30-50 years old?

The descendants of Merari were counted in their clans. 

# Who else did Moses and Aaron count in their clans from 30-50 years old?

The descendants of Merari were counted in their clans. 

# When Moses counted each Levite by clans from 30-50 years old, of what did he keep count?

Moses kept count of each man who would work in the tabernacle and who would carry and care for the items in the tent of meeting. 

# When Moses counted each man and kept count of each man's type of work and responsibility, who did he obey?

When Moses counted each man and kept count of each man's type of work and responsibility, he obeyed Yahweh. 

# For what problems did Yahweh say that Moses should send both men and women away from the camp?

Yahweh said that Moses should send away everyone who had infectious skin diseases or oozing sores and everyone who had touched a dead body and therefore were unclean. 

# For what problems did Yahweh say that Moses should send both men and women away from the camp?

Yahweh said that Moses should send away everyone who had infectious skin diseases or oozing sores and everyone who had touched a dead body and therefore were unclean. 

# What did Yahweh say to Moses that men and women who commit sins to another person should do?

Everyone who had committed sins to another person was to confess the sin, pay back the price of his guilt to the one he had wronged, and add one fifth more. 

# What was the payment and what did he do with the payment if the wronged person had no relative to receive the payment?

He had to present the price along with a ram to a priest who would then own it. 

# What was the payment and what did he do with the payment if the wronged person had no relative to receive the payment?

He had to present the price along with a ram to a priest who would then own it. 

# What was the payment and what did he do with the payment if the wronged person had no relative to receive the payment?

He had to present the price along with a ram to a priest who would then own it. 

# What did Yahweh tell Moses to do with a wife whose husband thought she had sinned against him?

The man brought his wife to the priest with a drink offering for her and a grain offering of barley flour as a possible indicator of sin. 

# What did the priest do first?

He had to place the woman before Yahweh, then take a jar of holy water and mix dust from the floor of the tabernacle into the water. 

# What did the priest do first?

He had to place the woman before Yahweh, then take a jar of holy water and mix dust from the floor of the tabernacle into the water. 

# Then what did the priest do?

The priest uncovered and untied her hair and put the grain offering of jealousy in her hands. The priest, holding the bitter water, caused her to swear an oath that brought down a curse on her if she had been unfaithful. 

# Then what did the priest do?

The priest uncovered and untied her hair and put the grain offering of jealousy in her hands. The priest, holding the bitter water, caused her to swear an oath that brought down a curse on her if she had been unfaithful. 

# What did the curse cause if she were guilty?

The curse caused her thigh to waste away and her abdomen to swell. 

# What was the priest to do with the bitter water that had the curses in it?

The priest was to make the woman drink the bitter water. 

# What did the priest do with the grain offering?

The priest took the grain offering from the woman's hand, held it up to Yahweh, gave a portion of it to Yahweh, and burned it on the altar. 

# What did the priest do with the grain offering?

The priest took the grain offering from the woman's hand, held it up to Yahweh, gave a portion of it to Yahweh, and burned it on the altar. 

# What did the priest do with the bitter water?

He gave the bitter water to the woman to drink. 

# What happened to the woman if she had committed a sin against her husband?

The woman's abdomen swelled, her thigh wasted away, and she was cursed among her people. 

# What will happen to the woman if she had not been defiled?

She was free and was able to conceive children. 

# What is the law of jealousy?

It is a law for a woman who strays away from her husband and is defiled. It is also a law for a man with a spirit of jealousy when he is jealous of his wife. 

# What is the law of jealousy?

It is a law for a woman who strays away from her husband and is defiled. It is also a law for a man with a spirit of jealousy when he is jealous of his wife. 

# Who separated himself with the vow of a Nazirite to Yaweh?

A man or woman gave a vow of a Nazirite to separate himself to Yahweh. 

# What did a person who had made the vow of the Nazirite not eat during the days of his separation to Yahweh?

He did not eat wine, strong drink, vinegar, grape juice, grapes, and raisins—any thing that had grapes in it. 

# What did a person who had made the vow of the Nazirite not eat during the days of his separation to Yahweh?

He did not eat wine, strong drink, vinegar, grape juice, grapes, and raisins—any thing that had grapes in it. 

# What did he not use during the days of his separation?

During the days of his separation he did not use a razor on his head. 

# During the days of his separation to Yahweh what must the one who takes a Nazirite vow not come near to?

One who takes a Nazirite vow must not come near a dead body. 

# To whom was he reserved during the days he was separated and holy.

During the time of his separation he was holy, reserved for Yahweh. 

# What did a Nazirite do seven days after he was defiled by a dead body?

After seven days a Nazirite shaved his head. 

# What did a defiled Nazirite first need to bring for an atonement on the eighth to the priest at the entrance to the tent of meeting on the day he consecrated himself?

On the eighth day he needed to bring for an atonement two doves or two young pigeons to the priest at the entrance to the tent of meeting. Then he had to consecrate himself on that same day. 

# What did a defiled Nazirite first need to bring for an atonement on the eighth to the priest at the entrance to the tent of meeting on the day he consecrated himself?

On the eighth day he needed to bring for an atonement two doves or two young pigeons to the priest at the entrance to the tent of meeting. Then he had to consecrate himself on that same day. 

# For what were the two offerings?

The two offering were as a sin offering and a burnt offering for atonement. 

# What guilt offering did he have bring to rededicate himself to Yahweh for the time of his separation?

To rededicate himself to Yahweh for the time of his separation, he had to bring a male lamb one year old as a guilt offering. 

# What sin offering did the defiled Nazirite need to bring to the entrance of the tent of meeting with his male lamb for a guilt offering?

He needed to bring a sin offering of a female one year old lamb without blemish, a ram without blemish as a fellowship offering, a basket of bread without leaven, a grain offering, and a drink offering to Yahweh. 

# What sin offering did the defiled Nazirite need to bring to the entrance of the tent of meeting with his male lamb for a guilt offering?

He needed to bring a sin offering of a female one year old lamb without blemish, a ram without blemish as a fellowship offering, a basket of bread without leaven, a grain offering, and a drink offering to Yahweh. 

# Who had to present the offerings to Yahweh for the Nazirite?

The priest had to present them before Yahweh. 

# Who had to present the offerings to Yahweh for the Nazirite?

The priest had to present them before Yahweh. 

# What did the Nazirite have to do with the hair that he shaved from his head?

He had to take the hair and put it on the fire under the fellowship offerings. 

# What did the priest put in the Nazirite's hands to lift high as an offering before Yahweh to present to Yahweh?

In the Nazirite's hands, the priest put the boiled shoulder of the ram, one loaf of bread without yeast out of the basket, and one wafer without yeast to present to Yahweh. 

# What did the priest put in the Nazirite's hands to lift high as an offering before Yahweh to present to Yahweh?

In the Nazirite's hands, the priest put the boiled shoulder of the ram, one loaf of bread without yeast out of the basket, and one wafer without yeast to present to Yahweh. 

# To whom was this offering, plus the breast and thigh that was raised, reserved afterwards?

This offering, plus the breast and thigh that were raised, were reserved for the priest. 

# What could the Nazirite drink after that?

The Nazirite could drink wine. 

# What blessings were Aaron and his sons to give the people from Yahweh?

Aaron and his sons were to give the people a blessing of Yahweh's light and peace. 

# What blessings were Aaron and his sons to give the people from Yahweh?

Aaron and his sons were to give the people a blessing of Yahweh's light and peace. 

# What did Moses anoint and sanctify for Yahweh on the day that the tabernacle and altar were completed?

He anointed and sanctified the tabernacle, all its furnishings, the altar and all it's utensils for Yahweh. 

# What did the leaders of Israel bring as sacrifices in front of the tabernacle?

They brought six covered carts and twelve oxen as sacrifices in front of the tabernacle. 

# To whom did Moses give the offerings?

Moses gave the offerings to the Levites, to each one as his work needed them. 

# What did Gershon and his descendants receive because of what their work needed?

Gershon and his descendants received two carts and four oxen. 

# What did Merari and his descendants receive because of what their work needed? 

Merari and his descendants received four carts and eight oxen. 

# Why didn't the descendants of Kohath receive any of the carts and oxen given as offerings?

The descendants of Kohath didn't receive any of the carts and oxen given as offering because they carried the equipment and objects reserved for the tabernacle on their shoulders. 

# When was each leader to offer their goods for the dedication of the altar?

On their own day each leader offered their sacrifices in front of the altar. 

# Who was the first of the 12 tribes of Israel that offered sacrifices for the dedication of the altar?

Judah was the first of the 12 tribes of Israel that offered sacrifices for the dedication of the altar. 

# On the 2nd day, which of the 12 tribes of Israel offered sacrifices for the dedication of the altar?

On the 2nd day, Issachar of the 12 tribes of Israel offered sacrifices for the dedication of the altar. 

# On the 3rd day, which of the 12 tribes of Israel offered sacrifices for the dedication of the altar?

On the 3rd day, Zebulun of the 12 tribes of Israel offered sacrifices for the dedication of the altar. 

# On the 4th day, which of the 12 tribes of Israel offered sacrifices for the dedication of the altar?

On the 4th day, Reuben of the 12 tribes of Israel offered sacrifices for the dedication of the altar. 

# On the 5th day, which of the 12 tribes of Israel offered sacrifices for the dedication of the altar?

On the 5th day, Simeon of the 12 tribes of Israel offered sacrifices for the dedication of the altar. 

# On the 6th day, which of the 12 tribes of Israel offered sacrifices for the dedication of the altar?

On the 6th day, Gad of the 12 tribes of Israel offered sacrifices for the dedication of the altar. 

# On the 8th day, which of the 12 tribes of Israel offered sacrifices for the dedication of the altar?

On the 8th day, Manasseh of the 12 tribes of Israel offered sacrifices for the dedication of the altar. 

# On the 9th day, which of the 12 tribes of Israel offered sacrifices for the dedication of the altar?

On the 9th day, Benjamin of the 12 tribes of Israel offered sacrifices for the dedication of the altar. 

# On the 11th day, which of the 12 tribes of Israel offered sacrifices for the dedication of the altar?

On the 11th day, Asher of the 12 tribes of Israel offered sacrifices for the dedication of the altar. 

# On the 12th day, which of the 12 tribes of Israel offered sacrifices for the dedication of the altar?

On the 12th day, Naphtali of the 12 tribes of Israel offered sacrifices for the dedication of the altar. 

# On the 10th day, which of the 12 tribes of Israel offered sacrifices for the dedication of the altar?

On the 10th day, Dan of the 12 tribes of Israel offered sacrifices for the dedication of the altar. 

# From what place did Yahweh speak to Moses when he was in the tent of meeting?

Yahweh spoke to Moses from above the atonement lid on the ark of the covenant decrees, between the two cherubims. 

# What was Yahweh's command to Aaron about the seven lamps?

Yahweh commanded that the lamps must give light in front of the lampstand. 

# Who showed Moses the pattern for the lamp?

Yahweh showed Moses the pattern for the lamp. 

# What did Yahweh ask Moses do to the Levites?

Yahweh told Moses to take the Levites from among the people of Israel and purify them." 

# What did Moses do to the Levites to purify them?

Moses sprinkled them with water of atonement, shaved their entire bodies, and washed their clothes. 

# What was the offering that the Levites brought?

The Levites brought two young bulls and a grain offering with fine flour mixed with oil. 

# What did Yahweh tell Moses to ask the people of Israel to do to the Levites to purify them?

Yahweh told the people of Israel to lay their hands on the Levites. 

# Why did they present the Levites as though they were raised high before Yaweh?

They presented the Levites on behalf of the people so that the Levites might serve Yahweh. 

# What kinds of offerings were the bulls for the Levites?

The bulls were a sin offering and a burnt offering to atone for the Levites. 

# Where did the Levites place their hands?

The Levites placed their hands on the heads of the bulls. 

# What tribe was separated, purified, and lifted up as an offering to Yahweh so they could serve in the tent of meeting?

The Levite tribe was separated, purified, and lifted up as an offering to Yahweh so they could serve in the tent of meeting. 

# What tribe was separated, purified, and lifted up as an offering to Yahweh so they could serve in the tent of meeting?

The Levite tribe was separated, purified, and lifted up as an offering to Yahweh so they could serve in the tent of meeting. 

# When did Yahweh set apart all the firstborn people and animals for himself?

Yahweh set apart all the firstborn of people and animals for himself since the day he took the lives of all the firstborn of the Egyptians in the land of Egypt. 

# Whom did Yahweh give to the people of Israel to atone for the people so that no plague would harm them when they came near the sanctuary?

He gave the Levites, instead of the firstborn, to Aaron and his sons to do the work and to atone for the people in the tent of meeting. 

# Did Moses, Aaron, and the whole community do everything that Yahweh had commanded concerning Levites?

Yes, they did everything that Yahweh had commanded Moses concerning the Levites. 

# What did Yahweh say to Moses about the age limits of serving in the tent meeting?

Levites who were twenty-five years old could serve until they were fifty years. 

# What could they do when they could not serve in the tabernacle after 50? 

Levites after 50 years old could help their brothers. 

# Who spoke to Moses in the wilderness of Sinai?

Yahweh spoke to Moses in the wilderness of Sinai. 

# When did Yahweh spoke to Moses?

Yahweh spoke to Moses in the first month of the second year after they came out from the land of Egypt. 

# When were the people of Israel to observe the Passover while they were in the wilderness of Sinai?

Every year they were to observe the Passover on the fourteenth day of the first month. 

# With what question did Moses go to Yahweh?

Moses went to Yahweh with a question because there were men who were unclean but wanted to keep the Passover. 

# What was the answer to Moses' question to Yahweh?

Yahweh told Moses that if a man was unclean because of a dead body or because he was on a long journey, he could still keep the Passover. 

# When were those men to keep the Passover rather than on the 14th day of the 1st month?

Those men who were unclean or on a long journey kept the Passover on the 14th day of the 2nd month. 

# What were some rules for keeping the Passover?

They ate the Passover with bread without yeast and bitter herbs and left none of it until morning while not breaking a bone of the animal. 

# What were some rules for keeping the Passover?

They ate the Passover with bread without yeast and bitter herbs and left none of it until morning while not breaking a bone of the animal. 

# What caused a man to be cut off from his people?

A person who was clean and not on a journey but failed to keep the Passover that Yahweh required would be cut off from his people. 

# What was the Passover law for a stranger in the land of Israel?

He had to keep the Passover, do all the commands, and obey the laws required. 

# What happened to the cloud over the tabernacle at night?

The cloud appeared as a fire at night. 

# What happened to the cloud over the tabernacle at night?

The cloud appeared as a fire at night. 

# How did the people know to go or to stop traveling?

When the cloud was taken up from over the tent, the people would travel; when the cloud stopped, the people stayed in their camp. 

# What would the people do when the cloud remained on the tabernacle for many days?

The people would obey Yahweh's instructions and not travel. 

# When was the only time the people could journey?

The people could only journey when the cloud lifted at Yahweh's command. 

# When was the only time the people could journey?

The people could only journey when the cloud lifted at Yahweh's command. 

# When did the people of Israel stay in their camp and not travel?

When the cloud stayed on the tabernacle, the people of Israel stayed in their camp and did not travel. 

# How did the people of Israel find out Yahweh's commands?

The people of Israel found out Yahweh's commands through Moses. 

# Why did Yahweh tell Moses to make two silver trumpets?

Yahweh told Moses to make two silver trumpets to call the community together or to move their camps. 

# Who was to blow the trumpets?

The priests were to blow the trumpets. 

# What was the signal for only the leaders to gather to Moses?

When the priests blew only one trumpet, that was the signal for only the leaders to gather to Moses. 

# What was the signal for people on the east side to begin their journey?

The signal for people on the east side to begin their journey was a loud trumpet blow. 

# What was the signal for the camps on the south side to begin their journey?

The signal for the camps on the south side to begin their journey was a second loud signal. 

# What did a soft blow of the trumpet signal?

The community was to gather together. 

# Who was always to blow the trumpets?

The sons of Aaron, the priests, were the only ones to blow the trumpets. 

# When they went to war and sounded an alarm with the trumpets, what would Yahweh do?

When they went to war and sounded an alarm with the trumpet, Yahweh would remember them and save them from their enemies. 

# What was a reminder to God, at the times of celebration, that Yahweh was their God?

They would blow the trumpets in honor of their burnt offerings and fellowship offerings. 

# What happened in the second year, in the second month, on the twentieth day of the month?

In the second year, in the second month, on the twentieth day of the month, the cloud lifted from the tabernacle. 

# Where did the people of Israel go after leaving the wilderness of Sinai?

The people went from the wilderness of Sinai to the wilderness of Paran. 

# What camp moved first?

The camp of Judah moved out first. 

# Who cared for the tabernacle?

The descendants of Gershon and of Merari. 

# Who carried the sanctuary's holy equipment?

The Kohathites carried the holy equipment. 

# Under what banner were the next armies to set out?

The armies under the banner of Ephraim were the next to set out. 

# Under what banner was the last army that set out?

The armies that camped under the banner of Dan's descendants were the last that set out. 

# Who was Reuel?

Reuel was the father of Moses' wife. 

# Who did Moses invite to come with the people of Israel?

Moses invited Hobab his wife's father's son. 

# Where did Hobab want to go instead?

Hobab wanted to go to his own land and to his own people. 

# Why did Moses want Hobab to go with them?

Moses wanted Hobab to go with them because he knew how to camp in the wilderness. 

# What was over them as they journeyed in the daylight with the ark of the covenant?

Yahweh's cloud was over as they journeyed in the daylight with the ark of the covenant. 

# What was over them as they journeyed in the daylight with the ark of the covenant?

Yahweh's cloud was over as they journeyed in the daylight with the ark of the covenant. 

# What did Moses ask Yahweh to do as they set out on their journey?

He asked Yahweh to scatter his enemies and make those who hated him run from him. 

# What did Moses say to Yahweh when they stopped?

He asked Yahweh to return to Israel's many tens of thousands. 

# To what words of the people was Yahweh listening?

The people complained about their troubles as Yahweh listened. 

# What did Moses do when the people called out to him about the fire?

When they called out to Moses, he prayed to Yahweh, and the fire stopped. 

# What were the people of Israel asking for when they began to weep?

The people of Israel wept and said, "Who will give us meat to eat?" 

# Where did the people find manna?

The people walked through the camp ground and gathered manna. 

# When would the manna fall on the camp?

When the dew fell on the camp in the night, the manna also fell. 

# How did Moses say Yahweh had treated him?

Moses said Yahweh had treated his servant so badly. 

# For what were the people asking when they wept in front of Moses?

They wept in front of Moses and asked for meat to eat. 

# Who did Yahweh tell Moses to bring to him?

Yahweh told Moses to bring to him seventy of Israel's elders. 

# What did Yahweh say the leaders would do after he put some of the Spirit on them?

Yahweh said that the leaders would bear the burden of the people with Moses. 

# Who would supply the meat for the people to eat?

Yahweh would give them meat, and they would eat it. 

# For how long did Yahweh say the people would eat meat?

The people would eat meat for a whole month. 

# What did Yahweh say Moses would see about Yahweh's word?

Yahweh said Moses would see whether or not Yahweh's word was true. 

# What did the seventy elders do when the Spirit rested on them?

When the Spirit rested on the seventy elders, they prophesied. 

# What happened to the two men who remained in the camp?

The Spirit also rested on the men who had remained in the camp. 

# What did Joshua ask Moses to do about the two men who were prophesying in the camp?

Joshua asked Moses to stop them from prophesying. 

# How far from the camp did the quail fall?

The quail fell near the camp, about a day's journey on one side and a day's journey on the other side. 

# How long were the people busy gathering the quail?

The people were busy gathering quails all that day, all the night, and all the next day. 

# How did Yahweh act in anger, while the people were still chewing the meat?

While the people were chewing, Yahweh became angry at them and attacked them with a very great disease. 

# Why did Miriam and Aaron speak against Moses?

Miriam and Aaron spoke against Moses because of the Cushite woman whom he had married. 

# What is said to emphasize that Moses was humble?

The man Moses was very humble, more humble than anyone else on earth. 

# To where did Yahweh call Moses, Aaron, and Miriam?

Yahweh called Moses, Aaron, and Miriam out to the tent of meeting. 

# In what and where did Yahweh appear to talk with them?

Yahweh came down in a pillar of cloud and stood at the entrance to the tent. 

# How did Yahweh reveal himself to his prophets among the people?

When a prophet of Yahweh was with the people, Yahweh revealed himself to the prophet in visions and dreams. 

# How did Yahweh speak differently to Moses than to other prophets?

Yahweh spoke to Moses directly, not with visions or riddles. 

# How did God react to Aaron and Miriam?

His anger burned against them. 

# What did Aaron notice about Miriam when Yahweh left and the cloud rose from over the tent?

When the cloud rose from over the tent, Miriam was suddenly leprous—she was as white as snow. 

# What did Aaron say about what they had said to Moses?

Aaron said that they had spoken foolishly and sinned. 

# How did Aaron describe what Miriam's leprous body was like?

He described her like a dead newborn whose flesh was half consumed. 

# What did Yahweh say was normal punishment if a father spat in a daughter's face.

Yahweh says that if her father had spit in her face, she would be disgraced for seven days. 

# Where did Miriam have to stay for 7 days and what did the people not do until Miriam return to camp?

Miriam was shut outside the camp for 7 days and the people did not journey until Miriam had returned to the camp. 

# Where did Yahweh tell Moses to send some men?

Yahweh told Moses to send some men to examine the land of Canaan, which he had given to the people of Israel. 

# What was the rank of the men who were sent from among the people of Israel?

All of the men were leaders from every tribe among the people of Israel. 

# What name did Moses use for Hoshea son of Nun who was chosen?

Moses called Hoshea son of Nun by the name of Joshua. 

# What did Moses tell the men to observe about the people who lived in the land?

Moses told the men to observe the people who lived there, whether they were strong or weak, few or many. 

# What did Moses tell the men to notice about the cities in the land?

Moses told them to see if the cities were like camps or fortified cities. 

# What did Moses tell the leaders to find out about the land and what were they to bring back?

Moses told the leaders to see whether the land was good for growing crops, whether there were trees, and to bring back samples of produce. 

# What did the men cut down in the Valley of Eschol?

When the men reached the Valley of Eshcol, they cut down a branch with a cluster of grapes. 

# How many men did it take to bring back the cluster of grapes, and what else did the people bring back?

It took two men to carry the grapes on a staff; their group also brought pomegranates and figs. 

# How long did the men spend examining the land?

The men returned from examining the land after forty days. 

# To whom did they bring back word besides Moses and Aaron?

They also brought back word to all the community of the people of Israel. 

# What did the men report about the people in the land?

The men reported that the people who made their homes in the land were strong. 

# What word did the men return about the cities in the land?

The men returned word that the cities were fortified and very large. 

# When did Caleb encourage the people to attack the land?

Caleb encouraged the people to attack it at once. 

# Why did the other men who had gone with Caleb say they were not able to attack the people?

The other men who had gone with Caleb said they were not able to attack the people because they were stronger than they were. 

# How did the men describe how small they felt compared to the giants of the land?

The men said that in their own sight they were like grasshoppers in comparison with the giants of the land. 

# How did the community react to the news about the giants in the land? 

That night all the community wept loudly. 

# What did the whole community of Israel wish had happened when they criticized Moses and Aaron?

They said to Moses and Aaron that they wished they had died in the land of Egypt or in the wilderness. 

# What did they think would have better instead of going into the land to which Yahweh had brought them?

They thought it would have been better to return to Egypt with their wives and little ones. 

# What did the people talk with each other about doing?

They talked about choosing another leader and returning to Egypt. 

# What did Moses and Aaron do in front of the assembly?

Moses and Aaron lay face down in front of the assembly. 

# How did Joshua and Caleb react?

Joshua and Caleb tore their clothes and spoke to all the people. 

# How did Joshua and Caleb react?

Joshua and Caleb tore their clothes and spoke to all the people. 

# What did Joshua and Caleb tell the community would happen if Yahweh was pleased with them?

They said that if Yahweh was pleased with them he would take them into that land and give it to them. 

# How did Joshua and Caleb describe the land?

Joshua and Caleb described the land as a land that flowed with milk and honey. 

# Why did Joshua and Caleb say protection would be removed from the people of the land?

They said that the protection of the people of the land would be removed from those people because Yahweh was with the people of Israel. 

# What did all the community want do do with Joshua and Caleb, and where did Yahweh's glory appear?

All the community wanted to stone Joshua and Caleb to death. Yahweh's glory appeared at the tent of meeting. 

# How did Yahweh offer to bless the clan of Moses after attacking them with plague and disinheriting the people of Israel?

Yahweh told Moses he would make his clan a nation that would be greater and mightier than the people of Israel were. 

# What did Moses say the Egyptians would do when they heard about Yahweh's destroying Israel?

Moses said the Egyptians would tell the inhabitants in this land. 

# What did Moses say the nations would say if Yahweh killed the people of Israel in the wilderness?

He said they would say that because Yahweh could not take this people into the land that he swore to give them, he killed them in the wilderness. 

# Why does Moses plead with Yahweh to pardon the people's sin?

Moses pleaded with Yahweh to pardon the people's sin because of the greatness of his covenant faithfulness. 

# What did Yahweh say would happen because he had pardoned them in keeping with Moses' request?

Yahweh said that as He lived, all the earth would be filled with his glory. 

# What did Yahweh say would happen because he had pardoned them in keeping with Moses' request?

Yahweh said that as He lived, all the earth would be filled with his glory. 

# What had all those people done who had seen Yahweh's glory and the signs of his power that he had done in Egypt and in the wilderness?

All the people who had seen his glory and signs had tempted him 10 times and had not listened to his voice. 

# What was going to happen to those people who had despised Yahweh?

The people who had despised Yahweh would not see the land about which Yahweh had made an oath to their ancestors. 

# What did Caleb do because he had another spirit, and what would happen to Caleb?

Caleb had another spirit so he followed Yahweh fully; therefore he would go into the land that he had examined and his descendants would possess it. 

# Where did Yahweh tell the people to go the next day?

Yahweh told the people to turn tomorrow and go to the wilderness by the way of the Red Sea. 

# What age of people did Yahweh say would fall dead in the wilderness?

Yahweh said that the dead bodies of the people from twenty years old and upward would fall in the wilderness. 

# Who were the only two men over 20 that Yahweh said he would take into the land that he had promised for their home?

He said he would only take Caleb and Joshua into the land that he had promised for their home. 

# Whom else did Yahweh say he would take into the land?

He said that he would take into the land the little ones whom the parents had said would be victims. 

# How many years would the people to bear the consequence of their sin and why that number?

They would bear the consequences of their sins for forty years because the men had examined the land for 40 days. 

# What happened to the men who had gone to look at the land?

The men whom Moses had sent to look at the land all died by Yahweh's plague. 

# What happened to the men who had gone to look at the land?

The men whom Moses had sent to look at the land all died by Yahweh's plague. 

# Who remained alive of the men that went to look at the land?

Of the men who had gone to look at the land, only Joshua and Caleb remained alive. 

# Why did Moses tell the people not to go into the land?

Moses told them not to go because they were violating Yahweh's command and because Yahweh was not with them to stop their enemies from defeating them. 

# Why did Moses tell the people not to go into the land?

Moses told them not to go because they were violating Yahweh's command and because Yahweh was not with them to stop their enemies from defeating them. 

# Who did not leave the camp to go up into the hill country with the people?

Neither Moses nor the ark of the covenant of Yahweh left the camp when they went up into the hill country. 

# What did the offerings at the feasts produce for Yahweh?

The offering at the feasts produced a sweet aroma for Yahweh. 

# What grain offering were they to bring with the offering of a ram?

With the offering of a ram, they were to bring a grain offering of flour mixed with oil. 

# What drink offering were the people to bring with their burnt offering or with the sacrifice of each lamb?

The people were told to prepare wine as the drink offering with their burnt offering or with the sacrifice of each lamb. 

# Who was told to follow those laws about offerings?

All who were native-born Israelites were told to prepare the sacrifices and offerings as Yahweh had described here. 

# Who was told to follow those laws about offerings?

All who were native-born Israelites were told to prepare the sacrifices and offerings as Yahweh had described here. 

# How did the law and decree apply to the foreigner who stayed with the people of Israel?

The same law and decree applied to the traveler and foreigner who stayed with the people of Israel. 

# How did the law and decree apply to the foreigner who stayed with the people of Israel?

The same law and decree applied to the traveler and foreigner who stayed with the people of Israel. 

# What were the people to do with the first of their dough?

The people were to raise up a loaf from the first of their dough? 

# How often did Yahweh command the people to raise up an offering from the first dough?

He said that they must give a raised offering throughout the people's generations. 

# What was the community to do about an unintentional sin?

All the community had to offer one young bull, a grain offering and drink offering, and one male goat as a sin offering. 

# For whom did the priest need to make an atonement and why?

The priest had to make an atonement for all the community of the people because the sin was an unintentional error. 

# For whom did the priest need to make an atonement and why?

The priest had to make an atonement for all the community of the people because the sin was an unintentional error. 

# What had to be done to the person who did anything in defiance and why?

The person who did anything in defiance had to be be cut off from among his people because he had despised Yahweh's word and broken his commandment. 

# What had to be done to the person who did anything in defiance and why?

The person who did anything in defiance had to be be cut off from among his people because he had despised Yahweh's word and broken his commandment. 

# What did the community do to the man found gathering wood on the Sabbath?

The community brought him outside the camp and stoned him to death. 

# What did the community do to the man found gathering wood on the Sabbath?

The community brought him outside the camp and stoned him to death. 

# What were the descendants of Israel commanded to make for themselves on their clothes?

The descendants of Israel were commanded to make tassels to hang on the borders of their clothes with a blue cord. 

# Of what would the tassels be a reminder to do?

The tassels would be a reminder that they wold keep all of Yahweh's commandments and not follow after their own hearts and eyes. 

# Of what else would the tassels would be a reminder?

The tassels would be a reminder to obey all of Yahweh's commands and that they would be holy, reserved for God. 

# What did Yahweh say he did to become the people of Israel's God?

Yahweh said that he had brought them out of the land of Egypt, to become their God. 

# Who—along with Dathan, Abiram, and On—gathered some men against Moses?

Korah gathered some men against Moses? 

# Who joined Korah, Dathan, Abiram, and On to rise up against Moses?

Two hundred and fifty leaders of the Israelite people rose up with them against Moses. 

# Which two men did Korah and the others think were lifting themselves above the rest of Yahweh's community?

They thought that Moses and Aaron were lifting themselves above the rest of Yahweh's community. 

# What did Moses do when he heard what the leaders had said to him?

Moses lay face down when he heard what the leaders had said to him. 

# Whom did Moses say would show Korah and those with him had been chosen to be Yahweh's priest, by bringing him up to himself in the morning?

Moses told Korah and those with him that Yahweh would show whom he had chosen as a priest, by bringing that man up to himself in the morning. 

# Whom did Moses instruct to bring censers to show whom Yahweh had chosen to be the holy one, and what were they to do with their censers?

Moses instructed Korah all his group to bring censers on the next day and put fire and incense in them before Yahweh to show whom Yahweh had chosen to be the holy one. 

# Whom did Moses instruct to bring censers to show whom Yahweh had chosen to be the holy one, and what were they to do with their censers?

Moses instructed Korah all his group to bring censers on the next day and put fire and incense in them before Yahweh to show whom Yahweh had chosen to be the holy one. 

# What was the work that Yahweh had separated the Levites from the community of Israel to do?

Yahweh of Israel had separated the Levites from the community of Israel to bring them near to himself, to do work in Yahweh's tabernacle, and to stand before the community to serve them. 

# What was the work that Yahweh had separated the Levites from the community of Israel to do?

Yahweh of Israel had separated the Levites from the community of Israel to bring them near to himself, to do work in Yahweh's tabernacle, and to stand before the community to serve them. 

# Whom were Korah and the Levites gathered against when they demanded Aaron's priesthood and complained against Aaron?

Korah and the Levites were gathered against Yahewh when they demanded Aaron's priesthood and complained against Aaron. 

# Whom were Korah and the Levites gathered against when they demanded Aaron's priesthood and complained against Aaron?

Korah and the Levites were gathered against Yahewh when they demanded Aaron's priesthood and complained against Aaron. 

# What did Dathan and Abiram say when Moses called them to come, and what did they say about Moses?

Dathan and Abiram said they would not come to Moses. They said that Moses had brought them out of a land flowing with milk and honey to kill them in the wilderness, and that he wanted to rule them. 

# What did Dathan and Abiram say when Moses called them to come, and what did they say about Moses?

Dathan and Abiram said they would not come to Moses. They said that Moses had brought them out of a land flowing with milk and honey to kill them in the wilderness, and that he wanted to rule them. 

# What did Moses ask in anger to Yahweh about Dathan and Abiram's offering, and what did Moses say he had not taken from them nor done?

Moses asked Yahweh in anger that he not accept their offering, and Moses said he had not taken one donkey from them nor harmed any of them. 

# What did Moses tell the 250 men and Aaron to bring with them next day and where were they to come?

Moses told Aaron and the 250 men with him to come before Yahweh with their censors. 

# What did Moses tell the 250 men and Aaron to bring with them next day and where were they to come?

Moses told Aaron and the 250 men with him to come before Yahweh with their censors. 

# What appeared when Korah his followers assembled against Moses and Aaron and they stood at the entrance to the tent of meeting?

When Korah his followers assembled against Moses and Aaron and stood at the entrance to the tent of meeting, the glory of Yahweh appeared to all the community. 

# What did Yahweh want Moses and Aaron to do?

Yahweh wanted Moses and Aaron to separate themselves from among that community that he might consume the community immediately. 

# What did Yahweh want Moses and Aaron to do?

Yahweh wanted Moses and Aaron to separate themselves from among that community that he might consume the community immediately. 

# What did Aaron and Moses do and say when the God of the spirits of all humanity instructed them to get away from the people who had gathered at the entrance of the tent?

Moses and Aaron lay face down and asked the God of the spirits of all humanity if he had to be angry with all the community when one man had sinned. 

# What did Yahweh tell Moses to tell the community to do?

Yahweh told Moses to tell the community to get away from the tents of Korah, Dathan, and Abiram. 

# What did Yahweh tell Moses to tell the community to do?

Yahweh told Moses to tell the community to get away from the tents of Korah, Dathan, and Abiram. 

# Who followed Moses when he went to Dathan and Abiram and told the community to leave the tents of those wicked men and touch nothing of theirs?

The elders followed Moses when he went to Dathan and Abiram and told the community to leave the tents of those wicked men and touch nothing of theirs. 

# What did he tell them would happen to the community if they stayed near their tents?

He said the community would be consumed by all their sins. 

# Who followed Moses when he went to Dathan and Abiram and told the community to leave the tents of those wicked men and touch nothing of theirs?

The elders followed Moses when he went to Dathan and Abiram and told the community to leave the tents of those wicked men and touch nothing of theirs. 

# What did he tell them would happen to the community if they stayed near their tents?

He said the community would be consumed by all their sins. 

# Who came out of their tents and stood in the entrances to their tents with their wives, sons, and their little ones?

Dathan and Abiram came out and stood at the entrance to their tents, with their wives, sons, and their little ones. 

# How would the people know that Yahweh had sent Moses to do all those works and that he hadn't done them by his accord?

If the men died a natural death, then Yahweh had not sent Moses. If Yahweh created and opening in the ground and swallowed them up to go down alive into sheol, then the all people would understand that those men had despised Yahweh. 

# How would the people know that Yahweh had sent Moses to do all those works and that he hadn't done them by his accord?

If the men died a natural death, then Yahweh had not sent Moses. If Yahweh created and opening in the ground and swallowed them up to go down alive into sheol, then the all people would understand that those men had despised Yahweh. 

# How would the people know that Yahweh had sent Moses to do all those works and that he hadn't done them by his accord?

If the men died a natural death, then Yahweh had not sent Moses. If Yahweh created and opening in the ground and swallowed them up to go down alive into sheol, then the all people would understand that those men had despised Yahweh. 

# What happened as soon as Moses stopped speaking to Korah and his men?

As soon as Moses stopped speaking, the ground opened and swallowed Korah, the men, their families, and their possessions. 

# What happened as soon as Moses stopped speaking to Korah and his men?

As soon as Moses stopped speaking, the ground opened and swallowed Korah, the men, their families, and their possessions. 

# What happened to everyone in their families?

Everyone in their families went down alive into sheol, the earth closed over them, and they perished from the midst of the community. 

# What did all Israel do, and of what were they afraid?

All Israel fled because they were afraid the earth might swallow them up. 

# What happened to the 250 men who had offered incense to the Lord?

Fire flashed out from Yahweh and devoured the 250 men who had offered incense. 

# What did Yahweh tell Moses to tell Eleazar, son of Aaron the priest, to do and why?

Yahweh told Moses to tell Eleazar to take the censors out of the smoldering remains and scatter the embers because the censers were holy, reserved for him. 

# What did Moses tell Eleazar to do with the metal of the censers of those that had lost their lives because of their sin?

Eleazar was to hammer the metal from the censors to make a covering over the altar because they were set apart for Yahweh. 

# Of what would the covering for the altar be a sign?

The covering for the altar would be a sign of Yahweh's presence to the people of Israel. 

# What reminder did the bronze censors become?

They would become a reminder to the people of Israel, so that no person, not descended from Aaron, would come up to burn incense before Yahweh. 

# What reminder did the bronze censors become?

They would become a reminder to the people of Israel, so that no person, not descended from Aaron, would come up to burn incense before Yahweh. 

# What did all the community of the people of Israel say the next morning to complain against Moses and Aaron?

The next morning all the community of the people of Israel complained against Moses and Aaron saying that Moses and Aaron had killed Yahweh's people. 

# What happened when the community looked toward the tent of meeting?

The cloud was covering the tent of meeting and Yahweh's glory appeared. 

# Where did Moses and Aaron go?

Moses and Aaron went to the front of the tent of meeting. 

# What did Yahweh tell Moses as they stood in front of the sacred tent?

Yahweh told Moses that they should get away from the community so that he could consume the community immediately. 

# What did Aaron and Moses do when they were told by Yahweh to get away from the people?

Aaron and Moses lay face down on the ground when they were told to get away from the people. 

# What did Moses tell Aaron to do to stop the plague because of Yahweh's anger?

Moses told Aaron to take the censer, put fire in it from the altar, put incense in it, and carry it quickly to the community for the people. 

# Where did Aaron run to make atonement as the plague spread, and what did he stand between?

Aaron ran to the middle of the community as the plague spread to make atonement, and he stood between the dead and the living. 

# Where did Aaron run to make atonement as the plague spread, and what did he stand between?

Aaron ran to the middle of the community as the plague spread to make atonement, and he stood between the dead and the living. 

# Besides those who had died in the matter of Korah, how many died by the plague?

Besides those who had died in the matter of Korah, those who died by the plague were 14,700. 

# What happened when Aaron returned to the entrance of the tent?

The plague ended when Aaron returned to the entrance of the sacred tent. 

# What did Yahweh tell the people of Israel to take from each tribe and to do with that which they took?

Yahweh instructed Moses to tell the people of Israel to take twelve staffs, one from each leader of a tribe, and write the name of the leader on his staff. 

# Whose name did Yahweh instruct Moses to put on the staff of Levi?

Yahweh instructed Moses to write Aaron's name on Levi's staff. 

# What was Moses to do with the twelve staffs?

Moses was to place the staffs in the tent of meeting in front of the covenant decrees. 

# What did Yahweh say would happen to the staff of the man whom Yahweh chose?

The staff of the man, whom Yahweh chose, would bud. 

# What would happen when Yahweh caused the staff to bud?

Yahweh would cause the complaints which the people of Israel were speaking against Moses to stop. 

# When Moses talked to the people of Israel, who gave their staffs to Moses?

All the tribal leaders gave him their staffs, including Aaron. 

# What happened to one of the staffs when Moses deposited the staffs before Yahweh in the tent of the covenant decrees?

When Moses put the staffs before Yahweh in the tent of the covenant decrees, Aaron's staff budded and produced blossoms and ripe almonds. 

# What did Moses do with all the staffs?

Moses brought out all the staffs from before Yahweh, and each man found his rod and took it. 

# What did Yahweh tell Moses to do with Aaron's staff?

Yahweh told Moses to put Aaron's staff in front of the covenant decrees. 

# Why did Yahweh tell Moses to put Aaron's staff in front of the covenant decrees? 

Yahweh told Moses to put Aaron's staff in front of the covenant decrees to keep it as a sign of guilt against the people who rebelled so that Moses would end complaints against Yahweh. 

# Of what were the people of Israel afraid?

The people of Israel were afraid they would die when everyone approached Yahweh's tabernacle. 

# Of what were the people of Israel afraid?

The people of Israel were afraid they would die when everyone approached Yahweh's tabernacle. 

# For what did Yahweh say that only Aaron, his sons, and his ancestor's clan would be responsible?

Yahweh told Aaron that he, his sons, and his ancestor's clan would be responsible for all sins committed against the sanctuary. 

# Who did God say would be responsible for all sins committed by anyone in the priesthood? 

Only Aaron and his sons would be responsible for all sins committed by anyone in the priesthood. 

# Which tribe would help Aaron and his sons when they served in front of the tent of the covenant decrees?

The tribe of Levi, the tribe of Aaron's ancestors, would join to help Aaron and his sons when they served in front of the tent of the covenant decrees. 

# Where could the Levites not go as they served Aaron and the tent?

The Levites could not go near anything in the sanctuary nor in the altar. 

# What would happen if the Levites came near to anything in the sanctuary or altar?

If the Levites came near to anything in the sanctuary or altar, they and Aaron would die. 

# Who could not come near Aaron?

A foreigner could not come near Aaron. 

# For what would the Levites take responsibility?

The Levites would join Aaron to take care of the tent of meeting and all the work connected with the tent. 

# Why did Aaron and his sons have to take care of the sanctuary and the altar?

Aaron and his sons had to take care of the sanctuary and the altar so that Yahweh's anger did not come on the people of Israel again. 

# What gifts did Yahweh give to Aaron and his sons and why did he give them?

Yahweh chose the Levites as a gift to Aaron, given to Yahweh, to do the work connected to the tent of meeting. 

# Who only were allowed to exercise the priesthood regarding everything connected with the altar and everything inside the curtain?

Only Aaron and his sons could exercise the priesthood regarding everything connected with the altar and everything inside the curtain. 

# What would happen to any foreigner who approached the altar of Yahweh inside the curtain?

Any foreigner who approached the altar of Yahweh inside the curtain would be put to death. 

# What holy offerings to Yahweh would be given to Aaron and his sons as their ongoing share?

The things from the most holy offerings that people of Israel gave to Yahweh that were not completely burned up would be Aaron and his sons' ongoing share. 

# What holy offerings to Yahweh would be given to Aaron and his sons as their ongoing share?

The things from the most holy offerings that people of Israel gave to Yahweh that were not completely burned up would be Aaron and his sons' ongoing share. 

# What other offerings would be for him and his sons?

Every sacrifice that the people brought—including every grain offering, every sin offering, and every guilt offering—would be for Aaron and his sons. 

# How was every male Levite to eat those offerings?

Every male Levite was to eat those offerings as something most holy, solemnly reserved for Yahweh. 

# To whom did Yahweh give, as their ongoing share, the gifts set apart from all the raised offerings of the people of Israel?

Yahweh gave the gifts set apart from all the raised offerings of the people of Israel to Aaron's ritually clean sons and daughters as their ongoing share. 

# What other things was given to Aaron's family?

All the best of the oil, the new wine, the grain, the first fruits, and the first ripe produce of their land that the people brought to Yahweh would belong to Aaron and those that were clean in his family. 

# What other things was given to Aaron's family?

All the best of the oil, the new wine, the grain, the first fruits, and the first ripe produce of their land that the people brought to Yahweh would belong to Aaron and those that were clean in his family. 

# What would the people have to buy back?

The people had to buy back every firstborn son and firstborn male of unclean animals. 

# At what time were the people to buy back the firstborn males?

The people were to buy back the firstborn males after they became one month old. 

# What animals were not to be bought back but were holy, reserved for Yahweh as a sacrifice which Aaron and his sons would eat?

Firstborn cows, sheep, or goats were not to be bought back because they were holy, reserved for Yahweh and their meat would be for Aaron and his sons. 

# What animals were not to be bought back but were holy, reserved for Yahweh as a sacrifice which Aaron and his sons would eat?

Firstborn cows, sheep, or goats were not to be bought back because they were holy, reserved for Yahweh and their meat would be for Aaron and his sons. 

# What did Yahweh say would be given to Aaron and his sons and to his daughters as an ongoing share because those offerings stood as a covenant of salt, a binding covenant forever before Yahweh with Aaron and his descendants?

Yahweh gave all the presented offerings of holy things to Aaron and his sons and daughters, as an ongoing share, as a covenant of salt as a binding covenant forever, before Yahweh with Aaron and Aaron's descendants. 

# Why does Yahweh tell Aaron he would not have an inheritance in the land among the people?

Yahweh told Aaron he would have no inheritance in the land because Yahweh was his share and inheritance. 

# What else had Yahweh given the descendants of Levi as their inheritance in return for their service at the tent of meeting?

Yahweh had given all the tithes of Israel to the descendants of Levi as their inheritance in return for their service at the tent of meeting. 

# Whom did Yahweh say would die from then on if the people came near Yahweh's tent of meeting?

Yahweh told Aaron that from now on the people of Israel could not come near the tent of meeting, or they would die. 

# What was the offering that the Levites gave to Yahweh when they received an offering of grain or wine from the people of Israel?

The offering that the Levites gave back to Yahweh was a tenth of the grain or wine offering. 

# To whom did the Levites give a presented offering to Yahweh from all the tithes that they had received from the people of Israel?

The Levites gave to Aaron a presented offering to Yahweh from all the tithes that they had received from the people of Israel. 

# What would happen if the Levites profaned the holy offerings of the people of Israel?

If the Levites profaned the holy offerings of the people of Israel, they would die. 

# What statute or law did Yahweh command the Israelite people?

Yahweh commanded the Israelite people to bring a red heifer without blemish which had never carried a yoke. 

# Where did Eleazar the priest take the heifer which someone killed in front of him?

Eleazar the priest had to take the heifer, which someone would kill in front of him, outside the camp. 

# What did Eleazar do with the blood of the heifer?

Eleazar took some of the blood on his finger and sprinkled it seven times toward the front of the tent of meeting. 

# What did another priest have to do with the heifer?

Another priest had to burn the heifer's hide, flesh, blood, and dung in front of Eleazar. 

# Where did the priest throw cedar wood, hyssop, and scarlet wool?

The priest had to throw cedar wood, hyssop, and scarlet wool into the middle of the burning heifer. 

# How long did Eleazar stay unclean after he had washed his clothes, bathed in water, and gone back to the camp?

Eleazar stayed unclean until the evening after he had washed his clothes, bathed in water, and gone back to the camp. 

# How long did the priest who had burned the heifer stay unclean after he had washed his clothes, bathed in water, and gone back to the camp?

The priest who had burned the heifer remained unclean until the evening after he had washed his clothes, bathed in water, and gone back to the camp. 

# What did someone who was clean do with the ashes from the heifer?

Someone who was clean gathered the heifer's ashes and put them outside the camp in a clean place. 

# What happened to the ashes that were placed outside the camp in a clean place?

These ashes were kept for the community of Israel to mix with water for purification from sin since they came from a sin offering. 

# What was the permanent law about the one who gathered the heifer's ashes? 

The one who gathered the heifer's ashes washed his clothes and remained unclean until the evening. 

# How long would anyone who touched a dead body of a man be unclean?

Anyone who touched a dead body would be unclean until the seventh day. 

# How did the person who touched a dead body purify himself?

Anyone who touched a dead body purified himself on the third and seventh days in order to be clean the seventh day. 

# What happened to anyone who touched a dead body and did not purify himself on the third day?

The person who did not purify himself on the third day after touching a dead body would not be clean on the seventh day. 

# Why would the person who touched a dead body, but did not purify himself, remain unclean; and what would happen to that man?

The person who touched a dead body and did not purify himself would remain unclean because he had defiled Yahweh's tabernacle. That man would be cut off from Israel and he would remain unclean. 

# What happened to any person who went into a tent where someone had died or who was already in the tent when someone died?

Both those who went into the tent where someone had died and those who were already in the tent would be unclean for seven days. 

# What happened to containers that were uncovered when someone died inside a tent?

Every open container became unclean when someone died inside a tent. 

# What was the law for anyone outside a tent who touched someone who had been killed with a sword or who had touched another a dead body, a human bone, or a grave?

The Israelite who touched someone who had been killed with a sword or who had touched a dead body, a human bone, or a grave would be unclean for seven days. 

# What had to be used for the unclean person, and in what was it mixed?

Ashes from the burnt sin offering had to be used and were mixed in a jar with fresh water. 

# What did someone do with the ashes from the burnt sin offering that were mixed in a jar with fresh water.

Using hyssop, someone who was clean had to sprinkle some of that water on the tent and on the things and people who were in the tent where someone had died. This water was also sprinkled on the person who had touched a human bone, a dead body, or a grave. 

# What happened to the one who sprinkled the water for impurity, and how long was he unclean?

The one who sprinkled the water for impurity had to wash his clothes, and he was unclean until evening. 

# What happened to anyone who touched something that the unclean person had touched?

Anyone who touched something that the unclean person had touched would be unclean until that evening. 

# Who went into the wilderness of Sin in the first month and stayed at Kadesh?

The people of Israel went into the wilderness of Sin. 

# What happened to Miriam at Kadesh?

Miriam died and was buried at Kadesh. 

# What happened to make the people complain against Moses and Aaron?

There was no water for the people. 

# What happened to make the people complain against Moses and Aaron?

There was no water for the people. 

# What did the people, the community of Yahweh, ask Moses and Aaron?

The people asked Moses and Aaron why they brought them and their animals into the wilderness to die. 

# What did the people not have in this wilderness of Sin?

The people did not have seed, figs, vines, pomegranates or water to drink. 

# What appeared to Moses and Aaron when they went to the entrance of the tent of meeting and lay face down?

Yahweh's brilliant glory appeared to them when they lay face down at the entrance of the tent. 

# Why did Yahweh tell Moses to take his staff, assemble the community and speak to the rock before the eyes of the people?

Yahweh told Moses to do this so that the rock would produce water for the people and their cattle to drink. 

# Why did Yahweh tell Moses to take his staff, assemble the community and speak to the rock before the eyes of the people?

Yahweh told Moses to do this so that the rock would produce water for the people and their cattle to drink. 

# Why did Yahweh tell Moses to take his staff, assemble the community and speak to the rock before the eyes of the people?

Yahweh told Moses to do this so that the rock would produce water for the people and their cattle to drink. 

# What did Moses call the people before he struck the rock?

Moses called the people rebels. 

# What happen when Moses struck the rock twice with his staff?

When Moses struck the rock much water came out of the rock and the community and their cattle drank the water. 

# What happen when Moses struck the rock twice with his staff?

When Moses struck the rock much water came out of the rock and the community and their cattle drank the water. 

# What did Yahweh tell Moses and Aaron would happen because they did not trust Yahweh or sanctify him in the eyes of the people of Israel?

Yahweh told them they would not bring the assembly of the people into the land Yahweh had given to them. 

# What did Yahweh tell Moses and Aaron would happen because they did not trust Yahweh or sanctify him in the eyes of the people of Israel?

Yahweh told them they would not bring the assembly of the people into the land Yahweh had given to them. 

# To whom did Moses send messengers telling of the difficulties the people had encountered?

Moses sent messengers to the king of Edom. 

# To whom did Moses send messengers telling of the difficulties the people had encountered?

Moses sent messengers to the king of Edom. 

# To whom did Moses send messengers telling of the difficulties the people had encountered?

Moses sent messengers to the king of Edom. 

# What did Moses ask of the king of Edom to allow the people to do?

Moses asked the king if he would allow the people of Israel to pass through the land. 

# What did Moses say the people not do until they had passed through the king's border?

Moses said the people would not turn to the right or to the left until they had passed the king's border. 

# What was the king's reply to Moses?

The king's reply was that the people of Israel could not pass through his land and he would attack them with the sword if they tried to pass through it. 

# What was the reply of the people of Israel to the king of Edom?

The people of Israel replied that they would just go along the highway, pay for any water that their livestock might drink and they would only walk through and not do anything else. 

# What did the king of Edom do after he refused to let the people of Israel pass through his land?

The king of Edom came against Israel with a strong hand with many soldiers. 

# What did the king of Edom do after he refused to let the people of Israel pass through his land?

The king of Edom came against Israel with a strong hand with many soldiers. 

# What did Israel do when the king of Edom refused to allow them to cross over the border?

Israel turned away from the land of Edom. 

# Where did the people of Israel go when they journered from Kadesh?

The people of Israel journeyed to Mount Hor. 

# What did Yahweh tell Moses and Aaron at Mount Hor about the consequence of their rebellion?

Yahweh told them that Aaron must be gathered to his people and Aaron would not enter the land given to the people of Israel because they both rebelled against Yahweh's word at the Waters of Meribah. 

# What did Yahweh tell Moses and Aaron at Mount Hor about the consequence of their rebellion?

Yahweh told them that Aaron must be gathered to his people and Aaron would not enter the land given to the people of Israel because they both rebelled against Yahweh's word at the Waters of Meribah. 

# Who did Yahweh say Moses and Aaron should bring with them to Mount Hor?

Yahweh told Moses and Aaron to bring Eleazar, Aaron's son, with them to Mount Hor. 

# Why did Yahweh tell them to take Aaron's priestly garment off him and put them on Eleazar his son?

Yahweh told them that Aaron must die and be gathered to his people. 

# What did the community do after Moses did as Yahweh commanded and they saw that Aaron was dead?

When all the community saw that Aaron was dead, the entire nation wept for Aaron for thirty days. 

# What did the community do after Moses did as Yahweh commanded and they saw that Aaron was dead?

When all the community saw that Aaron was dead, the entire nation wept for Aaron for thirty days. 

# What did the community do after Moses did as Yahweh commanded and they saw that Aaron was dead?

When all the community saw that Aaron was dead, the entire nation wept for Aaron for thirty days. 

# What did the Canaanite king of Arad do when he heard that Israel was traveling by the road to Atharim?

The king of Arad fought against Israel and took some of them captive. 

# What did Yahweh do in response to Israel's vow that they would destroy the cities of the king of Arad completely if Yahweh would give Israel victory over them?

Yahweh listened to Israel and gave them victory over the Canaanites. 

# What did Yahweh do in response to Israel's vow that they would destroy the cities of the king of Arad completely if Yahweh would give Israel victory over them?

Yahweh listened to Israel and gave them victory over the Canaanites. 

# What was name of the place called where Israel destroyed the Canaanites and their cities?

The name of the place was called Hormah. 

# What happened to the people's hearts as they traveled from Mount Hor by the road to the Red Sea to go around the land of Edom?

The people's hearts became very discouraged. 

# What was the complaint of the people against God and Moses?

The people complained against God and Moses and asked why they had been brought out of Egypt to die in the wilderness because they had no bread, they had no water, and they hated the food. 

# What happened to the people when Yahweh sent poisonous snakes among the people?

The snakes bit the people and many people died. 

# What did the people ask Moses to do after they confessed that they had sinned and had spoken against Yahweh and Moses?

The people asked Moses to pray to Yahweh to take the snakes away from them. 

# What did Yahweh tell Moses to do after Moses prayed for the people?

Yahweh told Moses to make a snake and attach it to a pole. 

# What happened if a person looked at the bronze snake after he was bitten by a snake?

The person survived who looked at the bronze snake after he was bitten. 

# What did the people find at Beer? 

There was a well there where Yahweh had told Moses to gather the people together for Yahweh to give them water. 

# About what did Israel sing?

They sang about the well that the leaders had dug to give them water. 

# About what did Israel sing?

They sang about the well that the leaders had dug to give them water. 

# To whom did the Israelites send messengers?

The Israelites sent messengers to Sihon king of the Amorites. 

# What did Israelite's messengers request of Sihon?

The Israelites requested that they pass through his land without drinking from his wells and staying on the king's highway. 

# How did the king respond to the request of the Israelites?

The king refused to allow Israel to pass through his border. He gathered his army and attacked Israel in the wilderness. 

# What did Israel do in response to Sihon's attack?

The Israelites attacked the army of Sihon with the edge of the sword and took their land. 

# Where did Israel begin to live?

Israel began to live in the land of the Amorites. 

# What happened after Moses sent men to look at Jazer?

The Israel took its villages and drove out the Amorites who were there. 

# What did Og do when Israel turned and went up by the road of Bashan?

Og and all his army went out to fight the Israelites at Edrei. 

# What did Yahweh say to Moses about Og and his army?

Yahweh told Moses not to fear Og and to do to him as the Israelites did to Sihon king of the Amorites because Yahweh had given them victory over him, his army, and his land. 

# How did Moses and the people of Israel respond to Yahweh's instructions?

Moses and the people killed Og, his sons, his army and his people and then took over his land. 

# What city was near the place where the people of Israel camped in the plains of Moab on the other side of Jordan River?

The city of Jericho was on the other side of the Jordan River near the place where they camped. 

# Why were the people of Moab afraid of the people of Israel?

The people of Moab were afraid of the people of Israel because they had seen all that they had done to the Amorites, and because there were many people. 

# Why were the people of Moab afraid of the people of Israel?

The people of Moab were afraid of the people of Israel because they had seen all that they had done to the Amorites, and because there were many people. 

# Of what country was Balak king?

Balak was the king of Moab. 

# What did Balak want Balaam to do to the nation that came from Egypt?

Balak wanted Balaam to curse the nation that came from Egypt. 

# Why did Balak want Balaam to curse the nation that had come from Egypt?

He wanted Balaam to curse that nation because they covered the face of the earth, they were next to him, and they were too strong for him. 

# What did Balak want Balaam to do to the nation that came from Egypt?

Balak wanted Balaam to curse the nation that came from Egypt. 

# Why did Balak want Balaam to curse the nation that had come from Egypt?

He wanted Balaam to curse that nation because they covered the face of the earth, they were next to him, and they were too strong for him. 

# What did Balak know that Balaam could do?

Balak knew that whomever Balaam blessed would be blessed, and whomever he cursed would be cursed. 

# What Balaam say when he heard Balak's message?

Balaam said that the messengers should stay there overnight and he would bring to them what Yahweh said to him. 

# What did Balaam tell Yahweh about the request of those men who came to him from Balak?

Balaam told God that Balak asked him to curse the people of Israel so Balak could fight them and drive them out. 

# What did God tell Balaam to do about going with the messengers and about cursing the people of Israel?

God told Balaam that he was not to go with the men and that he was not to curse the people of Israel. 

# What did Balaam tell Balak's leaders in the morning?

Balaam told Balak's leaders to go back to their land because Yahweh refused to allow him to go with them. 

# What did the leaders tell Balak when they went back to him?

The leaders told Balak that Balaam refused to come with them. 

# How did Balak try to get Balaam to come to him when he sent more honorable leaders to Balaam?

Balak tried to get Balaam to curse Israel by paying him extremely well, giving him great honor, and doing whatever he told him to do. 

# What did Balaam say to Balak's men in reply to their request?

Balaam told them that he could not go beyond the word of Yahweh, his God, and could do neither less nor more than what he old me. 

# Why did Balaam tell Balak's men they should wait overnight?

Balaam told Balak's men to wait there that night so that he might learn anything further that Yahweh said to him. 

# What did God tell Balaam to do when he came to Balaam at night?

When God came to Balaam that night, he told Balaam to get up and go with Balak's men but to do only what God told him to do. 

# What did Balaam do in the morning?

Balaam got up, saddled his donkey, and went with the leaders of Moab in the morning. 

# Why did God's anger kindled?

God's anger was kindled because Balaam went with them. 

# What did the angel of Yahweh do?

The angel of Yahweh placed himself in the road as someone hostile to Balaam. 

# What did Balaam's donkey see standing in the road?

Balaam's donkey saw the angel of Yahweh standing in the road with his drawn sword in his hand. 

# What did Balaam's donkey do when he saw the angel of Yahweh, and what did Balaam do to his donkey?

Balaam's donkey turned off the road and went into a field; Balaam struck the donkey to turn her back to the road. 

# What was on the right and left of the angel of Yahweh when he stood in a narrow part of the road between some vineyards?

A wall was on the angel's right side and another wall was on his left side. 

# What did the donkey do when he saw the angel of Yahweh with the drawn sword in the narrow place of the road, and then how did Balaam respond to what his donkey did?

When the donkey saw the angel of Yahweh, she struck the wall and pinned Balaam's foot against it; then Balaam struck her again. 

# What did the donkey do when she saw the angel of Yahweh in another narrow place where there was no way to turn to either side, and what did Balaam do?

The donkey laid down under Balaam; Balaam struck the donkey with his staff. 

# What did the donkey ask Balaam when Yahweh opened her mouth so she could talk?

The donkey asked Balaam what she had done to him that made him strike her three times. 

# How did Balaam reply to the donkey, and what did he wish he could do to her?

Balaam replied to the donkey that he had struck her because she acted so stupidly, and he wished that he had a sword in his hand so that he could kill her. 

# What did Balaam see and do when Yahweh opened his eyes?

Balaam saw the angel of Yahweh standing in the road with his drawn sword in his hand so Balaam lowered his head and lay face down. 

# Why did the angel of Yahweh tell Balaam about why his donkey acted the way she did?

The angel told Balaam that when his donkey saw the angel she turned away three times. 

# Why did the angel of Yahweh tell Balaam about why his donkey acted the way she did?

The angel told Balaam that when his donkey saw the angel she turned away three times. 

# What did the angel say would have happened to Balaam if his donkey had not turned away?

The angel told Balaam that if his donkey had not turned away the angel would have killed Balaam and spared the donkey's life. 

# What did Balaam confess to the angel, and what did he offer to do?

Balaam confessed that he had sinned and offered to return to the place from which he had come. 

# How did the angel reply to Balaam?

The angel replied that Balaam should go ahead with the men but only speak the words that the angel told him to speak. 

# What did Balak do when he heard that Balaam had come?

Balak went out to meet Balaam. 

# What did Balak ask Balaam when he met him at the city of Aron, a city on Moab's border?

Balak asked Balaam why he had not come when Balak summoned him, and did Balaam not think Balak was able to honor him. 

# What did Balaam tell Balak that he could only say?

Balam told Balak that he could only say the words that God put into his mouth. 

# What did Balak do when he and Balaam arrived at Kiriath Huzoth?

When they arrived at Kiriath Huzoth, Balak sacrificed oxen and sheep and gave some meat to Balaam and the leaders who were with him. 

# What did Balak do when he and Balaam arrived at Kiriath Huzoth?

When they arrived at Kiriath Huzoth, Balak sacrificed oxen and sheep and gave some meat to Balaam and the leaders who were with him. 

# What could Balaam see when Balak took him up to the shrines of Baal?

Balaam could see only a part of the Israelites in their camp. 

# What did Balaam the prophet tell Balak the king to do?

Balaam told Balak to build seven altars for him and prepare seven bulls and seven rams. 

# What did Balak do about Balaam's request?

Balak did as Balaam requested, and they offered a bull and a ram on each altar. 

# What did Balaam tell Balak that Yahweh might do when Balaam went aside?

Balaam told Balak that Yahweh might come to meet him and then he would tell Balak whatever Yahweh showed him. 

# What did Yahweh tell Balaam to do?

Yahweh told Balaam to return to Balak to speak a message to him. 

# What two questions did Balaam ask in the first part of the message God gave him?

Balaam asked, "How can I curse those whom God has not cursed? How can I oppose those whom Yahweh does not oppose?" 

# What two questions did Balaam ask in the first part of the message God gave him?

Balaam asked, "How can I curse those whom God has not cursed? How can I oppose those whom Yahweh does not oppose?" 

# What did Balaam say about how Israel considered themselves?

Balaam said that the Israel did not consider themselves to be just an ordinary nation. 

# What did Balaam say about the size of Israel?

He said no one could number even one fourth of Israel. 

# What kind of death did Balaam wish to die?

Balaam wished to die the death of a righteous person, and that he wanted his life's end to be like Israel's end. 

# What did Balak say that Balaam had done instead of cursing his enemies?

Balak said that Balaam had blessed his enemies instead of cursing them. 

# How did Balaam reply when Balak said he had blessed his enemies instead of cursing them?

Balaam answered that he was careful to say only what Yahweh put in his mouth. 

# What did Balak want Balaam to do when Balak took Balaam to another place where he could see the nearest part of Israel, Balak's enemies?

Balak wanted Balaam to curse Balak's enemies. 

# Where did Balak take Balaam, and what did he do there?

Balak took Balaam to the top of Mount Pisgah and he built seven more altars there and offered up a bull and a ram on each altar. 

# What did Balaam tell Balak he was going to do while Balak stood by his burnt offering?

Balaam said that he was going to meet with Yahweh. 

# What was the message that Yahweh put in Balaam's mouth?

Balaam said that God does not lie and he does not change his mind. 

# What did Balaam say that he could not do about God's command to bless Israel?

Balaam said that he could not reverse God's command to bless Israel. 

# Who did Balaam say was with the Israelites?

Balaam said that Yahweh was with the Israelites. 

# What did Balaam say God's strength is like?

He said God's strength is like the strength of a wild ox. 

# What things could not work against nor harm Israel?

Sorcery and fortune telling could not work against nor harm Israel. 

# What had to be said about Jacob and Israel?

It had to be said, "Look what God has done!" 

# How did Balaam describe what the people of Israel were like?

The people of Israel were like lions that attackrd and ate their victims. 

# What did Balak say to Balaam after Balaam gave his prophecy?

Balak said to Balaam that he should neither curse nor bless the Israelites at all. 

# What did Balaam tell Balak was the only thing that he could say?

Balaam told Balak that he could say only what Yahweh told him to say. 

# What did Balak think Balaam might be able to do if he took Balaam to another place?

Balak thought God might allow Balaam to curse the Israelites from another place. 

# So now where did Balak take Balaam?

Balak took Balaam to the top of Mount Peor. 

# What did Balaam tell Balak to do this time and what did Balak do?

Balaam told Balak to build seven altars so Balak did as Balaam said and offered a bull and a ram on each altar. 

# What did Balaam tell Balak to do this time and what did Balak do?

Balaam told Balak to build seven altars so Balak did as Balaam said and offered a bull and a ram on each altar. 

# What did Balaam the prophet not do when he saw that blessing Israel pleased Yahweh?

Balaam did not use sorcery but looked toward the wilderness. 

# What happened when Balaam raised his eyes and saw Israel camped, each in their own tribe?

When Balaam raised his eyes and saw Israel camped, the Spirit of God came on Balaam and he received a prophecy. 

# What happened when Balaam raised his eyes and saw Israel camped, each in their own tribe?

When Balaam raised his eyes and saw Israel camped, the Spirit of God came on Balaam and he received a prophecy. 

# What did Balaam do when he saw a vision from the Almighty?

Balaam bowed down with his eyes open. 

# What did Balaam say about Jacob's tents?

Balaam said that the tents of Jacob were beautiful. 

# How did Balaam describe the beauty of the place where Israel lived?

Balaam described valleys like gardens by the riverside, like aloes planted by Yahweh, and like cedars beside the waters. 

# With what did God bless Israel in the land in which they lived?

God blessed Israel with flowing water that would also water the seeds they planted. 

# What would happen to the kingdom of Israel?

Their kingdom would be honored. 

# From what place did God bring his people?

God brought his people out of Egypt. 

# What did Balaam say about the strength of Israel?

Balaam said the Israel's strength was like a wild ox. 

# What would happen to the nations who fought against Israel?

Balaam said Israel would eat up the nations who fought against him, break their bones to pieces, and shoot them with his arrows 

# What did Balaam prophesy would happen to those who blessed or cursed Israel?

Those who blessed Israel would be blessed and those who cursed Israel would be cursed. 

# How did Balak show his anger against Balaam?

Balak struck his hands together in anger. 

# Who did Balak say kept Balaam from getting the promised reward?

Balak said that Yahweh kept Balaam from getting his reward. 

# What did Balaam tell Balak he could not do even if Balak gave him his palace full of silver and gold?

Balaam told Balak that he could not go beyond Yahweh's word to say anything bad or good, or to say anything that he might want to say. 

# What did Balaam say was the only thing that he could say?

Balaam said that he could only say what Yahweh told him to say. 

# About what did Balaam warn Balak before he returned to his own people?

Balaam warned Balak what Israel was going to do to Balak's people in the days that were coming. 

# From whom did Balaam say that his prophecy, words, knowledge, and visions came?

Balaam said that his prophecy, words, knowledge, and visions came from God, the Most High, the Almighty. 

# What did Balaam say would come out of Jacob and rise out of Israel?

Balaam said that a star would come out of Jacob, and a scepter would rise out of Israel. 

# What did Balaam say that star and scepter would do to Moab's leaders and all the descendants of Seth?

Balaam said that that star and scepter would shatter and destroy Moab's leaders and all the descendants of Seth. 

# What would happen to Edom and Seir when Israel conquered them with force?

Edom and Seir would become possessions of Israel, and Israel would conquer them with force. 

# What would come out of Jacob and what would he do? 

A king who would have dominion would come out of Jacob and he would destroy the survivors of their city. 

# What would happen to Amalek, the greatest of nations?

The final end of Amalek, the greatest of nations, would be destruction. 

# What did Balaam prophesy would happen to Kain and the Kenites who lived in a strong place in the rocks?

Kain would be ruined when Assyria carried them away captive. 

# What did Balaam prophesy would happen to Kain and the Kenites who lived in a strong place in the rocks?

Kain would be ruined when Assyria carried them away captive. 

# What would come from the coast of Kittim which would attack Assyria and conquer Eber, and then what would happen to them?

Ships would come from the coast Kittim which would attack Assyria and conquer Eber; but they, too, would end in destruction. 

# When Balaam ended his final prophecy, what did he do and what did Balak do?

Balaam got up and returned to his home. Balak also went away. 

# What caused Yahweh's anger to be kindled against Israel?

The men began to sleep with the women of Moab and people ate and bowed down to the Moabite gods. 

# What caused Yahweh's anger to be kindled against Israel?

The men began to sleep with the women of Moab and people ate and bowed down to the Moabite gods. 

# What did Yahweh tell Moses to do to Israel's leaders who worshiped Baal of Peor?

Yahweh told Moses to kill all the Israelite leaders who had joined in worshiping Baal of Peor and to hang those leaders up before Yahweh. 

# Where was the community of the people of Israel when one of the men brought a Midianite woman among his family?

When one of the men brought a Midianite woman among his family, the people of Israel were weeping at the entrance to the tent of meeting. 

# What did Phinehas, son of Eleazar do when he saw the Israelite man and the Midianite woman?

When Phinehas saw the Israelite man and the Midianite woman, he rose up from among the community and took a spear in his hand. 

# What happened to the Israelite who brought a Midianite woman into the camp in the sight of Moses?

Phineas the priest took a spear and thrust a spear into the bodies of both the man and the woman. 

# What did God do to stop them from sleeping with the Moabite women and worshiping Baal of Peor, and how many died ?

God sent a plague so that those who died were 24,000 in number. 

# What did God do to stop them from sleeping with the Moabite women and worshiping Baal of Peor, and how many died ?

God sent a plague so that those who died were 24,000 in number. 

# Why was Yahweh's rage turned away from the people of Israel?

Yahweh's rage was turned away because Phinehas was passionate with Yahweh's zeal. 

# What was the first name Yahweh called his a covenant of everlasting priesthood? 

Yahweh called his covenant of everlasting priesthood, his covenant of peace. 

# Why did Yahweh make a covenant of everlasting priesthood with Phinehas?

Yahweh made a covenant with Phinehas because he was zealous for Yahweh and had atoned for the people of Israel. 

# Why did Yahweh tell Moses to treat the Midianites as enemies and attack them?

God told Moses to treat the Midianites as enemies and attack them because they had treated Israel like enemies with their deceitfulness. 

# Why did Yahweh tell Moses to treat the Midianites as enemies and attack them?

God told Moses to treat the Midianites as enemies and attack them because they had treated Israel like enemies with their deceitfulness. 

# How did Yahweh refer to Cozbi, the daughter of a leader in Midian who was killed on the day of the plague?

He referred to Cozbi, the daughter of a leader in Midian who was killed on the day of the plague, as their sister. 

# What did Yahweh tell Moses and Eleazar to do after the plague?

Yahweh told them to count all the people of Israel from twenty years old and up, by their tribes, who were able to go to war. 

# What did Moses and Eleazar tell the people Yahweh had commanded them to do?

They told the people they needed to count the people from 20 years old and up, who had come out of the land of Egypt. 

# Who was the firstborn of Israel?

The firstborn of Israel was Reuben. 

# How many men did the clans of Reuben's descendants number?

The clans of Reuben's descendants numbered 43,730 men. 

# Who were the sons of Eliab, descendant of Reuben, and what did his sons do?

Eliab's sons were Nemuel, Dathan and Abiram. Dathan and Abiram rebelled against Yahweh by following Korah who had challenged Moses and Aaron. 

# What happened to all the followers of Korah that became a warning sign?

The earth swallowed them up and fire devoured 250 men. 

# Whose line did not die out?

Korah's line did not die out. 

# Who was listed next of Israel's sons, and how many did their descendants number?

The clans of Simon was the next of Israel's sons; they numbered 22,200 total men. 

# How many did the male descendants of Gad number?

The male descendants of gad numbered 40,500 men. 

# What happened to Judah's sons, Er and Onan?

They died in the land of Canaan. 

# How many men were in the other descendants of Judah?

The other descendants of Judah numbered 76,500 men. 

# What was the number of the men of the clans from Issachar's descendants?

The number of the men of the clans from Issachar's descendants was 64,300 men. 

# What was the number of the men from Zebulun's descendants?

The number of the men from Zebulun's descendants were 60,500 men. 

# Who were Joseph's children?

The children of Joseph were Manasseh and Ephraim. 

# How many daughters did Zelophehad son of Hepher have although he had no sons?

Zelophehad son of Hepher had no sons and had five daughters. 

# How many men came from the descendants of Manasseh?

The men that came from the descendants of Manasseh numbered 52,700 men. 

# How many men came from the descendants of Ephraim?

The men that came from the descendants of Ephraim numbered 32,500 men. 

# How many men came from the descendants of Benjamin?

The men that came from the descendants of Benjamin numbered 45,600 men. 

# How many men came from the descendants of Dan?

The men that came from the descendants of Dan were numbered 64,400 men. 

# How many men came from the descendants of Asher?

The men that came from the descendants of Asher numbered 53,400 men. 

# How many men were numbered from the descendants of Naphtali?

The men that came from the descendants of Naphtali were numbered 45,400 men. 

# What was the complete count of the men of the people of Israel?

The complete count of men from among the people of Israel was 601,730. 

# How did Yahweh say the land would be divided?

Yahweh said to divide the land among those men as an inheritance according to the number of their names. 

# Who would get more and who would get less land for their inheritance?

The clans who were larger in number would be given more inheritance and the clans who were smaller in number would be given less inheritance. 

# What way would be used to divide the land?

The land would be divided by random lots from among their ancestor's tribes. 

# From what clan were Gershon, Kohath, and Marari?

Gershon, Kohath, and Marari were from the Levite clans. 

# From what clan did the Libnites, Hebronites, Mahlites, Mushites, and Korahites descend?

The Libnites, Hebronites, Mahlites, Mushites, and Korahites were descended from Levi. 

# Who was Amran's ancestor?

Amram's ancestor was Kohath. 

# Who were the children of Amram and Jochebed, a descendant of Levi who was born in Egypt?

Their children were Aaron, Moses, and Miriam, their sister. 

# Who was the father of Nadab, Abihu, Eleazar, and Ithamar?

Aaron was the father of Nadab, Abihu, Eleazar, and Ithamar. 

# What happened to Nadab and Abihu and why did they die?

Nadab and Abihu died when they offered unacceptable fire before Yahweh. 

# What was the number of males from Levi that were one month old and older?

The number of males from Levi who were one month old and older was 23,000. 

# Why was the number of males one month old and up not counted among Israel's descendants?

The males one month old and up were not counted among Israel's descendants because they had no land inheritance among the people of Israel. 

# Where did Moses and Eleazar the priest count the people of Israel? 

Moses and Eleazar counted the people of Israel in the plains of Moab by the Jordan at Jericho. 

# How many men were found who had been counted by Moses and Aaron the priest when the descendants of Israel had been counted in the wilderness of Sinai?

There was no man counted that had been counted by Moses and Aaron when the descendants of Israel had been counted in the wilderness of Sinai. 

# Why wasn't Moses and Aaron able to count these descendants?

Yahweh had said that those people would die in the wilderness, except for Caleb and Joshua. 

# Why did Zelophehad die in the wilderness?

Zelophehad died in the wilderness not because he was one of those who gathered against Yahweh in the company of Korah, but he died because of his own sin. 

# What did the daughters of Zelophehad want Moses to give them?

The daughters of Zelophehad wanted Moses to give them land among their father's relatives. 

# What did Yahweh say should happen to the inheritance of a man when he dies and has no son?

When a man died without a son, then his inheritance must pass to his daughter. 

# If a man died and has no son or daughter, who received his inheritance next?

If a man had no son or daughters, his inheritance passed to his brothers. 

# Why was Moses to be gathered with his people instead of going into the land which Yahweh had given them?

Moses was to be gathered with his people because he and Aaron rebelled against the command of Yahweh by striking the rock in anger. 

# Why was Moses to be gathered with his people instead of going into the land which Yahweh had given them?

Moses was to be gathered with his people because he and Aaron rebelled against the command of Yahweh by striking the rock in anger. 

# Why was Moses to be gathered with his people instead of going into the land which Yahweh had given them?

Moses was to be gathered with his people because he and Aaron rebelled against the command of Yahweh by striking the rock in anger. 

# Why did Moses ask Yahweh to appoint a man over the community?

Moses asked that Yahweh appoint a man over the community so they would not be like sheep that have no shepherd. 

# Why did Moses ask Yahweh to appoint a man over the community?

Moses asked that Yahweh appoint a man over the community so they would not be like sheep that have no shepherd. 

# Why did Moses ask Yahweh to appoint a man over the community?

Moses asked that Yahweh appoint a man over the community so they would not be like sheep that have no shepherd. 

# Why did Yahweh instruct Moses to lay his hand on Joshua, son of Nun?

Yahweh instructed Moses to choose Joshua because he was a man in whom Yahweh's spirit lived. 

# Why did Yahweh instruct Moses to lay his hand on Joshua, son of Nun?

Yahweh instructed Moses to choose Joshua because he was a man in whom Yahweh's spirit lived. 

# How much authority did Yahweh command Moses to give to Joshua?

Moses was to give Joshua the authority to seek Yahweh's will by the decisions of the Urim and command all Israel to obey him. 

# How much authority did Yahweh command Moses to give to Joshua?

Moses was to give Joshua the authority to seek Yahweh's will by the decisions of the Urim and command all Israel to obey him. 

# How did Moses respond to Yahweh's command?

Moses placed Joshua before Eleazar the priest and all the community and laid his hands on him as he commanded him to lead as Yahweh had instructed him. 

# How did Moses respond to Yahweh's command?

Moses placed Joshua before Eleazar the priest and all the community and laid his hands on him as he commanded him to lead as Yahweh had instructed him. 

# What did Yahweh say the sacrifices produced for him?

Yahweh said the sacrifices produced a sweet aroma for him. 

# What two animals, one in the morning and one in the evening, were to be offered in the regular burnt offerings each day?

The sacrifices in the regular burnt offerings in the mornings and in the evenings were to be male lambs without blemish. 

# What two animals, one in the morning and one in the evening, were to be offered in the regular burnt offerings each day?

The sacrifices in the regular burnt offerings in the mornings and in the evenings were to be male lambs without blemish. 

# What else did they have to offer with the regular burnt offering?

They had to offer a tenth of an ephah of fine flour as a grain offering mixed with a fourth of a hin of beaten oil. 

# What was the drink offering to Yahweh that had to be added to those regular burnt offerings and what did they do with it?

One fourth of a hin of strong drink had to be added to these sacrifices and poured out in the holy place. 

# What was the drink offering to Yahweh that had to be added to those regular burnt offerings and what did they do with it?

One fourth of a hin of strong drink had to be added to these sacrifices and poured out in the holy place. 

# What had to be offered on the Sabbath day?

On the Sabbath day, two male lambs, each a year old without blemish and fine flour mixed with oil, and a drink offering had to be offered. 

# What had to be offered on the Sabbath day?

On the Sabbath day, two male lambs, each a year old without blemish and fine flour mixed with oil, and a drink offering had to be offered. 

# What special animal sacrifices had to be made at the beginning of each month?

At the beginning of the month the animals of the special sacrifices were two young bulls, one ram, and seven one year old male lambs without blemish. 

# What were the grain offerings given with the two bulls and for the one ram?

The grain offerings for each of the two bulls was three tenths of an ephah of fine flour mixed with oil, and the grain offering for one ram was two tenths of fine flour mixed with oil. 

# What was the grain offering for each lamb?

Each lamb had a grain offering of a tenth of an ephah of fine flour mixed with oil. 

# How often were these special burnt offerings to be given?

These special burnt offerings were to be given every month throughout the year. 

# What was offered with the regular burnt offering and the drink offering?

One male goat was offered as a sin offering to Yahweh. 

# When did Yahweh's Passover come?

Yahweh's Passover came during the first month, on the fourteenth day of the month. 

# On what day was the feast to be held and what kind of bread was eaten for seven days?

The feast was to be held on the fifteenth day of the first month, and they ate bread without yeast for seven days. 

# On what day was the feast to be held and what kind of bread was eaten for seven days?

The feast was to be held on the fifteenth day of the first month, and they ate bread without yeast for seven days. 

# What did they do to honor Yahweh on the first day of the Passover, and what did they not do that day?

They had a holy assembly to honor Yahweh; on that day they did no normal work. 

# What animal sacrifices had to be made during the seven days of the Passover?

They offered two young bulls, one ram, and seven one year old male lambs without blemish. 

# What grain offerings did they give with the two young bulls and with the ram?

With the bulls they offered three tenths of an ephah of fine flour mixed with oil and with the ram they offered two tenths. 

# What did they offer with the lambs?

With each lamb they offered a tenth of an ephah of fine flour mixed with oil. 

# Why was the male goat given? 

The male goat was given as a sin offering to make atonement for themselves. 

# What happened on the seventh day of the feast of the Passover?

On the seventh day of the feast of the Passover they had to have a holy assembly to honor Yahweh and do no normal work on that day. 

# What did they have to offer of the day of the first fruits in their Festival of Weeks and what did they do on that day?

On the day of the first fruits, they offered a new grain offering to Yahweh in their Festival of Weeks, and had a holy assembly to honor Yahweh and did no normal work on that day. 

# Why did the people of Israel have a holy assembly on the first day of the seventh month; what did they not do and what did they do on that day?

On the first day of the seventh month the people of Israel had a holy assembly to honor Yahweh; they did no normal work and they blew trumpets. 

# On that day, what animals did they offer and why did they offer it?

On that day, they offered a burnt offering of one young bull, one ram, and seven male lambs a year old—each without blemish—to produce a sweet aroma for Yahweh. 

# What was the grain offering that they offered with the animals?

With the animals they offered a grain offering of fine flour mixed with oil. 

# Why did they offer one male goat?

They offered one male goat as a sin offering to make atonement for themselves. 

# When were they to make this sin offering, in addition to all of the usual offerings they were to make each month?

They were to make this sin offering in the seventh month, in addition to all of the usual offerings they were to make each month. 

# What did Yahweh say the people of Israel had do on the tenth day of the seventh month?

On the tenth day of the seventh month the people of Israel had to have a holy assembly to honor Yahweh, humble themselves, and do no work. 

# What animals did they have to offer as a burnt offering to produce a sweet aroma for Yahweh on the fifteenth day of the seventh month?

On the fifteenth day of the seventh month the people of Israel had to offer offer one young bull, one ram, and seven male lambs a year old—without any blemish. 

# What did the people of Israel have to put with each of the animals?

The people of Israel had to put flour mixed with oil with each of the animals. 

# What did the people of Israel have to put with each of the animals?

The people of Israel had to put flour mixed with oil with each of the animals. 

# Why was the male goat given? 

The male goat was given as a sin offering. 

# On what day was there another holy assembly to honor Yahweh in which they did no normal work and this time kept the festival for him for seven days?

On the fifteenth day of the seventh month there was another holy assembly to honor Yahweh in which they did no normal work and kept the festival for him seven days. 

# On this day how many bulls, rams and male lambs a year old without any blemishes did they offer?

On this day they offered thirteen young bulls, two rams, and fourteen male lambs a year old, each without blemish. 

# In addition to the grain offerings, drink offerings, and other animal sacrifices, what other animal was offered as a sin offering?

In addition to the grain offerings, drink offerings, and other animal sacrifices, a male goat was offered as a sin offering. 

# How many bulls did they offer on the second day of the assembly?

On the second day of the assembly, they offered twelve young bulls. 

# How many bulls did they offer on the third day of the assembly?

On the third day of the assembly they offered eleven bulls, and all the sacrifices of the previous day. 

# How many bulls did they offer on the third day of the assembly?

On the third day of the assembly they offered eleven bulls, and all the sacrifices of the previous day. 

# How many bulls did they offer on the third day of the assembly?

On the third day of the assembly they offered eleven bulls, and all the sacrifices of the previous day. 

# How many bulls did they offer on the fourth day of the assembly in addition to all the sacrifices of the previous day?

On the fourth day of the assembly the people of Israel had to offer ten bulls as well as all the sacrifices of the previous day. 

# How many bulls did they offer on the fourth day of the assembly in addition to all the sacrifices of the previous day?

On the fourth day of the assembly the people of Israel had to offer ten bulls as well as all the sacrifices of the previous day. 

# How many bulls did they offer on the fourth day of the assembly in addition to all the sacrifices of the previous day?

On the fourth day of the assembly the people of Israel had to offer ten bulls as well as all the sacrifices of the previous day. 

# How did the people of the Israel have to celebrate the fifth day of the assembly?

On the fifth day of the assembly the people of Israel had offer nine bulls and all the sacrifices of the previous day. 

# How did the people of the Israel have to celebrate the fifth day of the assembly?

On the fifth day of the assembly the people of Israel had offer nine bulls and all the sacrifices of the previous day. 

# How did the people of the Israel have to celebrate the fifth day of the assembly?

On the fifth day of the assembly the people of Israel had offer nine bulls and all the sacrifices of the previous day. 

# How did the people of Israel celebrate the sixth day of the assembly?

On the sixth day of the assembly the people of Israel had to offer eight bulls and all the sacrifices of the previous day. 

# How did the people of Israel celebrate the sixth day of the assembly?

On the sixth day of the assembly the people of Israel had to offer eight bulls and all the sacrifices of the previous day. 

# How did the people of Israel celebrate the sixth day of the assembly?

On the sixth day of the assembly the people of Israel had to offer eight bulls and all the sacrifices of the previous day. 

# How were the people of Israel to celebrate the seventh day of the assembly?

On the seventh day of the assembly the people of Israel were to offer seven bulls and all the sacrifices of the previous day. 

# How were the people of Israel to celebrate the seventh day of the assembly?

On the seventh day of the assembly the people of Israel were to offer seven bulls and all the sacrifices of the previous day. 

# How were the people of Israel to celebrate the seventh day of the assembly?

On the seventh day of the assembly the people of Israel were to offer seven bulls and all the sacrifices of the previous day. 

# How were the people of Israel to celebrate the eighth day of the assembly?

On the eighth day of the assembly the people of Israel were to have another solemn assembly and do no normal work. 

# What animals were they to offer on the eighth day for their burnt offering by fire to produce a sweet aroma for Yahweh?

They had to offer one bull, one ram, and seven male lambs a year old, each without blemish. 

# What else did they have to offer in addition to the bull, ram, and seven male lambs a year old and without blemish? 

In addition to the bull, ram, and seven male lambs which were a year old and without blemish, they were to offer grain offerings and drink offerings as well as one male goat as a sin offering. 

# What else did they have to offer in addition to the bull, ram, and seven male lambs a year old and without blemish? 

In addition to the bull, ram, and seven male lambs which were a year old and without blemish, they were to offer grain offerings and drink offerings as well as one male goat as a sin offering. 

# Besides their burnt offerings, grain offerings, drink offerings, and fellowship offerings, what other offerings did they have?

Besides their burnt offerings, grain offerings, drink offerings, and fellowship offerings, they had vows and freewill offerings. 

# What did Moses tell the people of Israel?

Moses told the people of Israel everything that Yahweh had commanded him to say. 

# What must a person who makes a vow not do?

He must not break his word. 

# What must a person who makes a vow not do?

He must not break his word. 

# If a young woman who lives in her father's house makes a vow to Yahweh and her father hears her vow but says nothing to reverse the vow, is the vow in force?

Yes, it is in force. 

# If a young woman who lives in her father's house makes a vow to Yahweh and her father hears her vow but says nothing to reverse the vow, is the vow in force?

Yes, it is in force. 

# If a young woman who lives in her father's house makes a vow to Yahweh and her father stops her on the day that he hears of it, is the vow in force?

No, the vow is not in force. 

# If a young woman who is married makes her vows and her husband hears about it and does nothing to stop her, are the vows in force?

Yes, the vows are in force. 

# If a young woman who is married makes her vows and her husband hears about it and does nothing to stop her, are the vows in force?

Yes, the vows are in force. 

# If a young woman's husband stops her on the day that he hears about her vows, are the vows in force?

No, the vows are not in force. 

# If a widow or a divorced woman makes a vow to Yahweh, is the vow in force?

Yes, the vow is in force. 

# If a woman in her husband's family makes a vow and her husband hears of it and says nothing to her, is the vow in force?

Yes, her vows must remain in force. 

# If a woman in her husband's family makes a vow and her husband cancels it on the day that he hears about it, is the vow in force?

No, her vow will not remain in force. 

# If a woman in her husband's family makes a vow and her husband hears of it and says nothing to her, is the vow in force?

Yes, her vows must remain in force. 

# If a woman in her husband's family makes a vow and her husband cancels it on the day that he hears about it, is the vow in force?

No, her vow will not remain in force. 

# If a woman in her husband's family makes a vow and her husband hears of it and says nothing to her, is the vow in force?

Yes, her vows must remain in force. 

# If a woman in her husband's family makes a vow and her husband cancels it on the day that he hears about it, is the vow in force?

No, her vow will not remain in force. 

# If a woman in her husband's family makes a vow and her husband hears of it and says nothing to her, is the vow in force?

Yes, her vows must remain in force. 

# If a wife's husband tries to cancel her vow a long time after he has heard about it, is the vow in force?

Yes, it will be in force, and if he breaks it, he will be responsible for her sin and suffer the penalty for breaking it. 

# What did Yahweh tell Moses would happen after he avenged the people of Israel against the Midianites?

Yahweh told Moses that Moses would die and be gathered to his people. 

# What did Yahweh tell Moses would happen after he avenged the people of Israel against the Midianites?

Yahweh told Moses that Moses would die and be gathered to his people. 

# How many soldiers was each tribe to send to war against Midian?

Each tribe was to send a thousand soldiers. 

# How many soldiers was each tribe to send to war against Midian?

Each tribe was to send a thousand soldiers. 

# How many soldiers was each tribe to send to war against Midian?

Each tribe was to send a thousand soldiers. 

# What happened in Israel's battle against Midian?

Every Midianite was killed, including their kings and Balaam. 

# What happened in Israel's battle against Midian?

Every Midianite was killed, including their kings and Balaam. 

# What happened in Israel's battle against Midian?

Every Midianite was killed, including their kings and Balaam. 

# What did the army of Israel take as plunder from Midian?

The army of Israel took the women of Midian, their children, and all their cattle, flocks, and goods as plunder. 

# Why was Moses angry with the officers of the army of Israel?

Moses was angry with the officers because they let had all the women of Midian live. 

# Why was Moses angry with the officers of the army of Israel?

Moses was angry with the officers because they let had all the women of Midian live. 

# Why was Moses angry with the officers of the army of Israel?

Moses was angry with the officers because they let had all the women of Midian live. 

# Why was Moses angry that the officers of the army of Israel had let the women of Midian live?

Moses was angry because the women of Midian had caused the people of Israel, through Balaam's advice, to commit sin against Yahweh. 

# Who did Moses command the officers of the army of Israel to kill?

Moses told the officers to kill every male among the little ones and every woman who had slept with a man. 

# Who did Moses tell the officers of the army they could take for themselves?

Moses told the officers of the army they could take for themselves all the young girls who had never slept with a man. 

# How long did the soldiers who had killed anyone or touched a dead body have to camp outside the camp of Israel?

They were to stay outside the camp for seven days. 

# Which men in the army of Israel had to purify themselves?

All the men in the army who had killed anyone or touched a dead person had to purify themselves. 

# How long did the soldiers who had killed anyone or touched a dead body have to camp outside the camp of Israel?

They were to stay outside the camp for seven days. 

# On which days were those soldiers and their prisoners camped outside the camp of Israel supposed to purify themselves?

Those camped outside the camp of Israel had to purify themselves on the third and and seventh days. 

# Which men in the army of Israel had to purify themselves?

All the men in the army who had killed anyone or touched a dead person had to purify themselves. 

# Between what two groups did Moses ask Eleazar the priest to divide the plunder from the war?

Moses asked Eleazar to divide the plunder from the war between the soldiers who went out to battle and all the rest of the community. 

# Between what two groups did Moses ask Eleazar the priest to divide the plunder from the war?

Moses asked Eleazar to divide the plunder from the war between the soldiers who went out to battle and all the rest of the community. 

# Between what two groups did Moses ask Eleazar the priest to divide the plunder from the war?

Moses asked Eleazar to divide the plunder from the war between the soldiers who went out to battle and all the rest of the community. 

# What was the tax that the soldiers were to pay to Eleazar the priest?

The soldiers were to pay a tax of one out of every five hundred persons, cattle, donkeys, sheep, or goats. 

# What was the tax that the soldiers were to pay to Eleazar the priest?

The soldiers were to pay a tax of one out of every five hundred persons, cattle, donkeys, sheep, or goats. 

# What was the tax the people of Israel were to give to the Levites who took care of the tabernacle?

The people of Israel were to pay a tax of one out of every fifty persons,cattle, donkeys, sheep, and goats. 

# What was the tax the people of Israel were to give to the Levites who took care of the tabernacle?

The people of Israel were to pay a tax of one out of every fifty persons,cattle, donkeys, sheep, and goats. 

# Why did the officers of the army of Israel bring Yahweh offerings?

They brought the offerings to make atonement for themselves before Yahweh. 

# Why did the officers of the army of Israel bring Yahweh offerings?

They brought the offerings to make atonement for themselves before Yahweh. 

# Why was all the gold from the commanders of thousands and from the captains of hundreds given over to Yahweh?

It was placed in the tent of meeting to remind Yahweh of the people of Israel. 

# Why was all the gold from the commanders of thousands and from the captains of hundreds given over to Yahweh?

It was placed in the tent of meeting to remind Yahweh of the people of Israel. 

# Why was all the gold from the commanders of thousands and from the captains of hundreds given over to Yahweh?

It was placed in the tent of meeting to remind Yahweh of the people of Israel. 

# Why did the descendants of Reuben and Gad go and speak to Moses?

The descendants of Reuben and Gad went and spoke to Moses because they saw that the land of Jazer and Gilead was a wonderful place for livestock and the descendants of Reuben and Gad had large numbers of livestock. 

# Why did the descendants of Reuben and Gad go and speak to Moses?

The descendants of Reuben and Gad went and spoke to Moses because they saw that the land of Jazer and Gilead was a wonderful place for livestock and the descendants of Reuben and Gad had large numbers of livestock. 

# Why did the descendants of Reuben and Gad go and speak to Moses?

The descendants of Reuben and Gad went and spoke to Moses because they saw that the land of Jazer and Gilead was a wonderful place for livestock and the descendants of Reuben and Gad had large numbers of livestock. 

# Why did Moses think the descendants of Gad and Reuben wanted to stay in Jazer and Gilead?

He thought they wanted to settle there and let their brothers go to war. 

# What did Moses think would happen to the hearts of the people of Israel if the people of Gad and Reuben settled there?

He thought the hearts of the people would become discouraged. 

# What had their fathers done when Moses sent them from Kadesh Barnea to examine the land?

They had seen the land and then discouraged the hearts of the people of Israel so they refused to enter the land. 

# Why did Yahweh take an oath that none of the men of Israel from twenty years old and up except Caleb and Joshua would see the land which he had sworn to Abraham, Isaac, and Jacob?

Yahweh took this oath because he was angry that the men of Israel had not completely followed him. 

# Why did Yahweh take an oath that none of the men of Israel from twenty years old and up except Caleb and Joshua would see the land which he had sworn to Abraham, Isaac, and Jacob?

Yahweh took this oath because he was angry that the men of Israel had not completely followed him. 

# Why did Yahweh take an oath that none of the men of Israel from twenty years old and up except Caleb and Joshua would see the land which he had sworn to Abraham, Isaac, and Jacob?

Yahweh took this oath because he was angry that the men of Israel had not completely followed him. 

# What did Yahweh do because he was angry with the men of Israel?

He made them wander around in the wilderness for forty years. 

# What promise did the descendants of Reuben and Gad make to Moses if he would allow them to build fences for their cattle and cities for their families?

They promised to be armed to go with Israel's army and not return until they had led Israel into their place. 

# What promise did the descendants of Reuben and Gad make to Moses if he would allow them to build fences for their cattle and cities for their families?

They promised to be armed to go with Israel's army and not return until they had led Israel into their place. 

# What did Moses decide to do about the request the descendants of Reuben and Gad had made?

He told them that if they would go to war with the men of Israel and drive out the enemies in the land, then they could return to the land they possessed and be guiltless towards Yahweh and Israel. 

# What did Moses decide to do about the request the descendants of Reuben and Gad had made?

He told them that if they would go to war with the men of Israel and drive out the enemies in the land, then they could return to the land they possessed and be guiltless towards Yahweh and Israel. 

# What did Moses decide to do about the request the descendants of Reuben and Gad had made?

He told them that if they would go to war with the men of Israel and drive out the enemies in the land, then they could return to the land they possessed and be guiltless towards Yahweh and Israel. 

# What would happen if the descendants of Reuben and Gad did not cross over and fight with the men of Israel to take the land Yahweh had given to them?

If they did not cross over and fight with the men of Israel, then they would not receive the land in Gilead, but would acquire their possessions in the land of Canaan. 

# What would happen if the descendants of Reuben and Gad did not cross over and fight with the men of Israel to take the land Yahweh had given to them?

If they did not cross over and fight with the men of Israel, then they would not receive the land in Gilead, but would acquire their possessions in the land of Canaan. 

# What would happen if the descendants of Reuben and Gad did not cross over and fight with the men of Israel to take the land Yahweh had given to them?

If they did not cross over and fight with the men of Israel, then they would not receive the land in Gilead, but would acquire their possessions in the land of Canaan. 

# What did the descendants of Reuben and Gad and the half tribe of Manasseh promise to the leaders of the people of Israel?

They promised to cross over into the land of Canaan. 

# What did the descendants of Reuben and Gad and the half tribe of Manasseh promise to the leaders of the people of Israel?

They promised to cross over into the land of Canaan. 

# Whose land did Moses give to the descendants of Gad and Reuben, and also to the half tribe of Manasseh?

He gave them the land of Sihon, king of the Amorites, and of Og, king of Bashan. 

# Why were the people of Israel able to openly leave Rameses without opposition from the Egyptians?

They were able to leave openly because the Egyptians were busy burying all their firstborn. 

# Why were the people of Israel able to openly leave Rameses without opposition from the Egyptians?

They were able to leave openly because the Egyptians were busy burying all their firstborn. 

# Why did the people of Israel choose to camp at Elim?

They choose to camp there because twelve springs of water and seventy palm trees were there. 

# What could the people of Israel not find at Rephidim?

There was no water found at Rephidim. 

# How long after Israel had come out of Egypt did Aaron die at Mount Hor?

Aaron died forty years after the people of Israel had come out of Egypt. 

# How long after Israel had come out of Egypt did Aaron die at Mount Hor?

Aaron died forty years after the people of Israel had come out of Egypt. 

# What did Yahweh command the people through Moses to do after they crossed over the Jordan into Canaan?

Yahweh commanded them to drive out all of the land's inhabitants and destroy all their cast figures and shrines. 

# What did Yahweh command the people through Moses to do after they crossed over the Jordan into Canaan?

Yahweh commanded them to drive out all of the land's inhabitants and destroy all their cast figures and shrines. 

# What did Yahweh command the people through Moses to do after they crossed over the Jordan into Canaan?

Yahweh commanded them to drive out all of the land's inhabitants and destroy all their cast figures and shrines. 

# How did Yahweh want the people of Israel to divide up the land that they were to possess?

Yahweh wanted the people of Israel to divide up the land by lot, giving a larger share of land to the large clans and a small share of land to the small clans. 

# How did Yahweh want the people of Israel to divide up the land that they were to possess?

Yahweh wanted the people of Israel to divide up the land by lot, giving a larger share of land to the large clans and a small share of land to the small clans. 

# What would happen if the people of Israel did not drive out the land's inhabitants?

The people whom they allowed to stay would make life difficult for them. 

# What would happen if the people of Israel did not drive out the land's inhabitants?

The people whom they allowed to stay would make life difficult for them. 

# Who were the people who would receive the land of Canaan as their possession?

The nine and one half tribes of Israel would receive the land of Canaan as their possession. 

# What would the descendants of Reuben and Gad and the half tribe of Manasseh receive as their share of the land?

The descendants of Reuben and Gad and the half tribe of Manasseh would receive their share of land beyond the Jordan at Jericho eastward. 

# What would the descendants of Reuben and Gad and the half tribe of Manasseh receive as their share of the land?

The descendants of Reuben and Gad and the half tribe of Manasseh would receive their share of land beyond the Jordan at Jericho eastward. 

# Who were the men who would divide the land for their inheritance?

The men would be Eleazar the priest, Joshua son of Nun, and one leader from every tribe. 

# Who were the men who would divide the land for their inheritance?

The men would be Eleazar the priest, Joshua son of Nun, and one leader from every tribe. 

# Who were the men who would divide the land for their inheritance?

The men would be Eleazar the priest, Joshua son of Nun, and one leader from every tribe. 

# What did Yahweh command these men to do?

He commanded them to divide the land of Canaan and to give each tribe of Israel its share. 

# What did Yahweh command each one of the tribes of Israel to do for the Levites?

He commanded them to give to the Levites some of their own shares of land, cities to live in, and pastureland surrounding the cities. 

# What did Yahweh command each one of the tribes of Israel to do for the Levites?

He commanded them to give to the Levites some of their own shares of land, cities to live in, and pastureland surrounding the cities. 

# How many cities were to be given to the Levites?

Forty-eight cities were to be given to the Levites. 

# What was the purpose for six of the cities that the Levites would receive?

They were to serve as cities of refuge to which accused murderers could flee. 

# How would the cities of refuge protect an accused man from his avenger?

Anyone who killed someone unintentionally could flee to them and know they would not be killed without standing on trial before the community. 

# What would cause an accused man to certainly be put to death?

He would be put to death if he struck his victim with an instrument of iron, a stone in his hand, or a wooden weapon and then his victim died. 

# What would cause an accused man to certainly be put to death?

He would be put to death if he struck his victim with an instrument of iron, a stone in his hand, or a wooden weapon and then his victim died. 

# What would cause an accused man to certainly be put to death?

He would be put to death if he struck his victim with an instrument of iron, a stone in his hand, or a wooden weapon and then his victim died. 

# What would happen if an accused man without a weapon injured someone so that they die?

If an accused man without a weapon manhandles anyone or throws something at him while hiding, or strikes him down with his hand so that the victim dies, then the accused man must be put to death. 

# What would happen if an accused man without a weapon injured someone so that they die?

If an accused man without a weapon manhandles anyone or throws something at him while hiding, or strikes him down with his hand so that the victim dies, then the accused man must be put to death. 

# What must the community do to rescue from the blood avenger an accused man, whose victim dies through unintentional harm?

The community must rescue the accused man by returning him to the city of refuge to which he had originally fled. 

# When could a blood avenger kill the accused man and yet not be guilty of murder?

If the blood avenger would find the accused man outside the border of the city of refuge to which he fled, then he could kill him and not be found guilty of murder. 

# When could a blood avenger kill the accused man and yet not be guilty of murder?

If the blood avenger would find the accused man outside the border of the city of refuge to which he fled, then he could kill him and not be found guilty of murder. 

# When would an accused man be free to return to his own property?

He would be free to return after the death of the high priest. 

# What is needed before a murderer can be put to death?

The testimony of more than one witness is needed before a murderer can be put to death. 

# What ransom can people accept for the life of a murderer?

The people are to accept no ransom for the life of a murderer or for one who has fled to a city of refuge. 

# What ransom can people accept for the life of a murderer?

The people are to accept no ransom for the life of a murderer or for one who has fled to a city of refuge. 

# What is the only thing that can atone for land on which blood has been shed?

Only the blood of the one who has shed the blood will atone for the land. 

# What is the only thing that can atone for land on which blood has been shed?

Only the blood of the one who has shed the blood will atone for the land. 

# To whom had Yahweh commanded Moses to give the land of Zelophehad?

Yahweh had commanded Moses to give Zelophehad's land to his daughters. 

# To whom had Yahweh commanded Moses to give the land of Zelophehad?

Yahweh had commanded Moses to give Zelophehad's land to his daughters. 

# What would happen to Zelophehad's land if his daughters married men from other tribes in Israel?

If they did that, then their share of land would belong to the tribe into which they married. 

# What would happen to the land that had belonged to a daughter who had married a man from another tribe when the jubilee came?

When the jubilee came, the share that had belonged to the daughter would belong to her husband's tribe and be taken away from Zelophehad's tribe. 

# What command did Yahweh give through Moses concerning Zelophehad's daughters?

He commanded that Zelophehad's daughters could marry only within their father's tribe. 

# What command did Yahweh give through Moses concerning Zelophehad's daughters?

He commanded that Zelophehad's daughters could marry only within their father's tribe. 

# What must never happen to shares of land in Israel?

No share of land in Israel can change from one tribe to another. Each man's share must stay within his ancestor's tribe. 

# Why did Yahweh command that every woman among the people of Israel who owned a share of land in her tribe must marry someone from the clans belonging to her father's tribe?

Yahweh gave this command so that everyone among the people of Israel could own an inheritance from his ancestors. 

# Why did Yahweh command that every woman among the people of Israel who owned a share of land in her tribe must marry someone from the clans belonging to her father's tribe?

Yahweh gave this command so that everyone among the people of Israel could own an inheritance from his ancestors. 

# How did Zelophehad's daughters comply with this command from Yahweh?

They married into the clans of the descendants of Manasseh so their inheritance remained in the tribe of their father's clan. 

# How did Zelophehad's daughters comply with this command from Yahweh?

They married into the clans of the descendants of Manasseh so their inheritance remained in the tribe of their father's clan. 

# How did Zelophehad's daughters comply with this command from Yahweh?

They married into the clans of the descendants of Manasseh so their inheritance remained in the tribe of their father's clan. 

