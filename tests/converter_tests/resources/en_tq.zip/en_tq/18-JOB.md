# How is Job's character described?

He was blameless and upright, and honored God and turned from evil. 

# After Job's sons held feasts with their brothers and sisters in their houses, what would Job do?

Job would consecrate them to God, offer burnt offerings, and pray for them. 

# Why did Yahweh say Satan should consider Job?

There was no one like Job in the earth, a perfect and an upright man, one who feared God and turned away from evil. 

# How did Satan say Yahweh had protected Job?

He made a hedge around Job, around his house, and around all that he had on every side. 

# What did Satan think would cause Job to renounce God?

He said to Job would renounce God is God attacked all Job's possessions. 

# What did Yahweh give Satan permission to do?

He gave Satan permission to take everything from Job, but not to lay a hand on his person. 

# What did the messenger tell Job the Sabeans had done to him?

They killed all Job's servants in the field and took away all the oxen and donkeys. 

# What did the messenger tell Job the Sabeans had done to him?

They killed all Job's servants in the field and took away all the oxen and donkeys. 

# What did the second messenger tell Job had happened to his sheep?

The fire of God fell from then heavens and burned them up along with the servants. 

# What the third messenger tell Job had happened to his camels?

Three groups of robbers came and attacked them. They stole all the camels and killed all the men that were caring for them. 

# What news did the fourth messenger bring to Job?

Job's sons and daughters were feasting in their brother's home when a great wind came and struck the house, which collapsed on them and killed them. 

# What news did the fourth messenger bring to Job?

Job's sons and daughters were feasting in their brother's home when a great wind came and struck the house, which collapsed on them and killed them. 

# What did Job do after he got all these messages?

Job tore his robe, shaved his head, lay facedown on the ground, and worshipped God. 

# What did Job say about his condition after these events?

He said he came naked from his mother's womb, and would return naked. 

# What did Job say that Yahweh had done to him?

Yahweh gave, and Yahweh has taken away. 

# How did Job show that he was not a foolish man?

Job did not sin, nor did he foolishly accuse God. 

# Who came with the sons of God when they presented themselves before Yahweh?

Satan also came and presented himself. 

# What did Satan tell Yahweh that he had been doing?

He said he was going to and fro on the earth, and walking back and forth on it. 

# How did Yahweh say that Job continued to do after Satan's attacks?

Job held fast to his integrity. 

# What does Satan want to do to Job now so that Job will curse God?

Satan wants to touch Job's bones and his body to hurt him. 

# How did Satan afflict Job's body?

He afflicted Job with severe boils from the sole of his foot to the top of his head. 

# What did Job do to deal with the pain of his affliction?

He took a potshard and scraped himself as he sat in ashes. 

# What did Job's wife want him to do?

Job's wife wanted him to curse God and die. 

# What accusation did Job make to his wife?

He accused her of thinking they should receive good at the hand of God but not evil. 

# What did Job's three friends do when they heard what happened to Job?

They came to mourn with him and comfort him. 

# How did the three friends of Job show their grief when they saw him?

They raised their voices and wept, tore their robes, threw dust on their heads, and sat on the ground in silence for seven days and nights. 

# How did the three friends of Job show their grief when they saw him?

They raised their voices and wept, tore their robes, threw dust on their heads, and sat on the ground in silence for seven days and nights. 

# What did Job say about the day he was born?

He cursed the day he was born and asked that it would perish. 

# What did Job say about the day he was born?

He cursed the day he was born and asked that it would perish. 

# What did Job say about the day he was born?

He cursed the day he was born and asked that it would perish. 

# What does Job want to claim the day he was born?

He wants that day to be claimed by darkness and the shadow of death. 

# What does Job want to seize the night he was conceived?

Job wants that night to be seized by thick darkness. 

# What did Job with had happened when he came out of the womb?

He wishes he had died and given up his spirit. 

# What does Job say he would be doing now if he had died at birth?

He would be sleeping and at rest with kings and counselors of the earth. 

# What does Job say he would be doing now if he had died at birth?

He would be sleeping and at rest with kings and counselors of the earth. 

# From what are prisoners and servants released in death?

The prisoner is released from the voice of the slave driver, and the servant is free from his master. 

# From what are prisoners and servants released in death?

The prisoner is released from the voice of the slave driver, and the servant is free from his master. 

# To whom does Job say that death will not come?

It does not come to the one who longs for death, and who searches for it more than those who search for hidden treasure. 

# How does Job describe his groaning?

His groaning is poured out like water. 

# What is the things that Job has feared that has come upon him?

He is not at ease or quiet, and has no rest. 

# What good things does Eliphaz say Job has done for others?

Job had instructed many, and strengthened weak hands. 

# What does Eliphaz say is Job's confidence and hope in time of trouble?

Job's fear of God is his confidence, and the integrity of his ways is his hope. 

# Who has perished and are consumed by the breath of God and his anger?

Those who plow iniquity sow trouble perish and are consumed. 

# Who has perished and are consumed by the breath of God and his anger?

Those who plow iniquity sow trouble perish and are consumed. 

# How does Eliphaz says is broken?

The voice of the fierce lion and the teeth of young lions are broken. 

# How did Eliphaz secretly receive a certain message?

He heard a whisper in his ear and saw visions in the night. 

# How did Eliphaz secretly receive a certain message?

He heard a whisper in his ear and saw visions in the night. 

# What came upon Eliphaz when he received the message?

Fear and trembling came on him. 

# What did the voice ask about mortal men?

It asked if a mortal man can be more righteous than God, and more pure than his maker? 

# How does Eliphaz describe mortal men?

They live in houses of clay, whose foundation is the dust, and who are crushed sooner than a moth. 

# What does Eliphaz say will happen to a foolish and silly man?

Anger kills the foolish man, and jealousy kills the silly one. 

# What happens to he children of the foolish person in the city gate?

They are crushed in the gate. 

# From where does trouble really come?

Mankind makes his own trouble. 

# What does God give to the earth and the fields?

He gives rain on the earth and sends water on the fields. 

# What does God do the schemes of crafty people?

He frustrates their schemes so that their hands cannot carry out their plots. 

# From what does God save the needy and poor person?

He saves the poor person from the sword in their mouths, and saves the needy person from the hand of the mighty people. 

# Why is the man happy whom God corrects and chastens?

He is happy because God after he wounds, he binds up wounds, and his hands heal. 

# At what will the man whom God corrects laugh?

He will laugh at destruction and famine. 

# What will the man whom God corrects find when he visits his sheepfold?

He will find that nothing will be missing. 

# How long will the man whom God corrects live?

He will come to his grave at a full age. 

# How does Job describe his anguish and his calamity?

Ff his anguish and calamity were weighed, they would be heavier than the sand of the seas. 

# How does Job describe his anguish and his calamity?

Ff his anguish and calamity were weighed, they would be heavier than the sand of the seas. 

# What has the Almighty done to Job with his arrows?

His arrows are in Job, and Job's spirit drinks up the poison. 

# What food does Job say has no taste?

He says the white of an egg does not have any taste. 

# What one request does Job long for God to grant him?

He wants God to crush him and cut him loose from his life. 

# What one request does Job long for God to grant him?

He wants God to crush him and cut him loose from his life. 

# What is Job's consolation?

His consolation is that he has not have denied the words of the Holy One. 

# What has been driven from Job?

Wisdom has been driven out of him. 

# To whom should a friend show faithfulness?

A friend should show faithfulness to the person who is about to faint. 

# How does Job compare his brothers to a desert streambed?

They pass away to nothing, they vanish when they thaw, and they melt when it is hot. 

# How does Job compare his brothers to a desert streambed?

They pass away to nothing, they vanish when they thaw, and they melt when it is hot. 

# How does Job compare his brothers to a desert streambed?

They pass away to nothing, they vanish when they thaw, and they melt when it is hot. 

# What happened to the caravans when they looked for water in these streams?

They wandered into barren land and then perished. They were disappointed and deceived. 

# What happened to the caravans when they looked for water in these streams?

They wandered into barren land and then perished. They were disappointed and deceived. 

# What happened to the caravans when they looked for water in these streams?

They wandered into barren land and then perished. They were disappointed and deceived. 

# Why were Job's friends nothing to him?

They saw his dreadful situation and were afraid. 

# What does Job say he will do if his friends would teach him?

He will hold his peace. 

# What does Job say his friends plan to do with his words?

They plan to ignore his words, and to treat them like the wind. 

# Why does Job say his friends should relent in their attacks on him?

Job's cause is just. 

# To what does Job compare his months of misery and trouble-filled nights?

He compares them to a slave desiring the evening, or a hired man looking for his wages? 

# To what does Job compare his months of misery and trouble-filled nights?

He compares them to a slave desiring the evening, or a hired man looking for his wages? 

# What covers Job's flesh?

Worms and clods of dust cover his flesh. 

# What image does Job use to describe the speed of his days?

His days are swifter than a weaver's shuttle. 

# To what does Job compare the man who goes down to sheol?

He is like a cloud that is consumed and vanishes away. 

# In what way will Job speak and complain?

He will speak in the anguish of his spirit and complain in the bitterness of his soul. 

# What does Job God does to him when he goes to bed?

God scares him with dreams and terrifies him through visions. 

# Why did Job want God to leave him alone?

Job said his days are useless. 

# What does Job ask God to let him alone long enough to do?

He asks to be left alone long enough to swallow his own saliva. 

# What does Job think God will not do?

Job thinks God will not pardon his transgression and take away his iniquity. 

# To what did Bildad compare the words of Job's mouth?

He compared them to a mighty wind. 

# How did Bildad say he knew that Job's children sinned?

He said he knew this because God had handed Job's children over to their sin. 

# How does Bildad say that God would bless Job if he was pure and upright?

He would reward Job with a home that truly belonged to him. 

# To what does Bildad compare our days on earth?

He says they are a shadow. 

# What do papyrus and reeds require in order to grow?

Papyrus requires a marsh, and reeds need water to grow. 

# To what does Bildad compare the trust of godless men?

Their trust is as fragile as a spider's web. 

# What do the roots do that represent a person that forgets God?

His roots are wrapped around the heaps of stone and look for good places among the rocks. 

# How does God treat the innocent man and the evildoers differently?

He will not cast away an innocent man, but will not take the hand of evildoers. 

# With what will God fill the mouth and lips of the innocent man?

He will fill his mouth with laughter and his lips with shouting. 

# What would happen is a man tried to argue with God?

The man could not answer God once in a thousand times. 

# What does God do to the mountains when he is angry?

He removes the mountains without warning and overturns them. 

# What does God trample down?

He tramples down and subdues the waves of the sea. 

# Does Job see God when he passes by?

God goes by him and Job does not see or perceive him. 

# Even if Job was righteous, how would he need to address God?

Job could not answer him, but could only plead for mercy. 

# Why does Job believe God has multiple his wounds?

Job believed God multiplied his wounds without cause. 

# Is is possible for Job to be righteous and perfect?

No, even then, his mouth would condemn him and prove him guilty. 

# Does Job think God treats righteous and wicked people differently?

He says God destroys both perfect people and wicked people together. 

# To what three things does Job compare the speed of his days?

They are swifter than a running messenger, they are as fast as reed boats, and as fast as the swooping eagle. 

# Why did Job say it would be in vain to forget about his complaints?

God would not consider him innocent, but Job would be condemned. 

# Why did Job say it would be in vain to forget about his complaints?

God would not consider him innocent, but Job would be condemned. 

# Why did Job say it would be in vain to forget about his complaints?

God would not consider him innocent, but Job would be condemned. 

# What does Job say that no judge would be able to do?

No judge could lay his hand on both Job and God. 

# What does Job say no other judge could do?

There is no other judge who can take God's rod from Job, or keep God's terror from frightening Job. 

# Why does Job want God to show him, instead of merely condemning him?

He wants God to show Job why he accuses him. 

# What kind of eyes does Job ask God if he has?

Job asks him if he has eyes of flesh and sees like a man sees. 

# What does Job say that God inquires and searches after?

God inquires after Job's iniquity and searches after his sin. 

# What had God's hands done for Job?

They had framed and fashioned Job, together round about. 

# With what did God clothe Job?

He clothed him with skin and flesh. 

# What has God granted to Job?

God granted him life and covenant faithfulness. 

# What would God do if Job sinned?

God will notice his sin, and not acquit him of his iniquity. 

# What does God do to Job if Job's head lifts itself?

God would hunt him down like a lion. 

# Who does God bring against Job describe what is happening to him?

God brings new witnesses against him. 

# What does Job with had happened to him?

He wishes he had given up his spirit and that no eye had ever seen him. 

# Where is Job going, from which he will not return?

He is going to the land of darkness and to the shadow of death. 

# What did Zophar think Job had done to their teaching?

He thought Job had mocked his friends teaching. 

# What does Zophar say that God has demanded from Job?

He said God has demanded less from Job than his iniquity deserved. 

# Does Zophar think that Job could possibly understand God?

Zophar thinks that it is impossible because God is high as the heaven, deeper than sheol, longer than the earth, and wider than the sea. 

# Does Zophar think that Job could possibly understand God?

Zophar thinks that it is impossible because God is high as the heaven, deeper than sheol, longer than the earth, and wider than the sea. 

# Does Zophar think that Job could possibly understand God?

Zophar thinks that it is impossible because God is high as the heaven, deeper than sheol, longer than the earth, and wider than the sea. 

# Does Zophar think that it is possible for anyone to stop God?

It is impossible to stop God because he knows false people and notices iniquity. 

# Does Zophar think that it is possible for anyone to stop God?

It is impossible to stop God because he knows false people and notices iniquity. 

# When does Zophar say foolish people will have understanding?

They will have understanding when a wild donkey gives birth to a man. 

# What does Zophar say would happen to Job's misery if he truly put away his iniquity?

Job would forget his misery and remember it only like waters that have flowed away. 

# Why would Job be secure if he put away his iniquity?

He would be secure because there would be hope. 

# What does Zophar say is the only hope of wicked people?

Their only hope will be a last gasp of life. 

# How does Job compare himself to his friends?

He says he also has understanding and is not inferior to them. 

# What do Job's neighbors think of him now?

They laugh at him. 

# Who does Job think could teach his friends?

The beasts, the birds, the earth, and the fish of the sea could teach his friends. 

# Who does Job think could teach his friends?

The beasts, the birds, the earth, and the fish of the sea could teach his friends. 

# What do all of the animals know?

They know that the hand of Yayweh has given them life. 

# What does Job say about aged men and understanding?

Aged men have wisdom, and in length of days is understanding. 

# What does God do with the waters?

He with holds them and they dry up, and he sends them out and they overwhelm the land. 

# What does God take from kings?

He takes off the chain of authority from them. 

# What does Job say about God does to the trustworthy and the elders?

He removes the speech of the trustworthy, and takes away the understanding of elders. 

# What does Job say about God does to nations?

He makes them strong or destroys them, and enlarges them or leads them along as prisoners. 

# What happens to the leaders of the people of the earth when God takes away their understanding?

He causes them them to wander in a wilderness where there is no path. 

# How does Job say his knowledge compares to that of his friends?

Job says that he know the same as they know, and he is not inferior to them. 

# Who would Job like to talk to instead of his friends and why?

He would rather speak to the Almighty because Job wants to reason with God. 

# What does Job say his friends do with truth?

They whitewash the truth with lies. 

# What does Job want his friends to hear?

He wants them to listen to the pleading of his lips. 

# Would God approval if Job's friends showed favoritism to God?

No, he would reprove them if they showed favoritism to him. 

# What does Job think about his friends' sayings and defenses?

He says their sayings are proverbs made of ashes, and their defenses are made of clay. 

# What does Job ask his friends to do so that he may speak?

Job asks them to hold their peace and let him alone. 

# Why does Job think that he would be acquitted?

He does not come before God like a godless man. 

# What has Job set in order?

He has set his defense in order. 

# What does Job want God to withdraw from him?

Job wants God to withdraw his oppressive hand from Job. 

# Who does God treat Job like?

He treats Job like his enemy. 

# What useless things does Job say he is like?

He is like a rotten thing that wastes away, like a garment that moths have eaten. 

# How does Job say man is like a flower?

Man sprouts from the ground like a flower, and is cut down. 

# Who decides the lifespan of man?

God has determined his days and the number of his months. 

# What does Job say about a tree that has been cut down?

There can be hope for a tree that has been cut down, for it can sprout again. 

# Does Job say a man can live again?

He says that that people do not rise up again, and will not be roused out of their sleep. 

# Where does Job wish would God would hide him?

Job wants God to hide him away in sheol away from troubles. 

# How would God treat Job's transgression and iniquity if God's wrath was finished?

God would seal up Job's transgression in a bag, and cover up Job's iniquity. 

# What amazing thing can water do over time?

It can wear down the stones. 

# How does it affect a dead man if his sons are honored or brought low?

If they come to honor, he does not know it, and if they are brought low, he does not see it happen. 

# With what should a wise man not fill himself?

He should not fill himself with the east wind. 

# How does Eliphaz think that Job's statements dishonored God?

He thinks Job diminishes respect for God, and obstructs devotion to him. 

# Does Eliphaz think that Job knows something that the other friends do not know?

He does not thing that Job knows what they do not know, or that he understands what is not also in them. 

# Which people does Eliphaz say agree with Job's friends?

The gray-headed and very aged men who are older than Job's father are with Eliphaz and his friends. 

# What does Eliphaz think Job's spirit has done?

He thinks Job's has turned his spirit against God. 

# How does God view his holy ones and the heavens?

He puts no trust even in his holy ones, and the heavens are not clean in his sight. 

# From whom did Eliphaz get the things he will announce to Job?

The things he has seen are things that wise men passed down from their fathers, and things that ancestors did not hide. 

# From whom did Eliphaz get the things he will announce to Job?

The things he has seen are things that wise men passed down from their fathers, and things that ancestors did not hide. 

# When will they destroyer come upon the wicked man?

The destroyer will come upon him while he is in his prosperity. 

# What waits for the wicked man?

The sword waits for the wicked man. 

# With what does the wicked man run against God?

He runs at God with a stiff neck and a thick shield. 

# What will happen to the cities and houses of the wicked man?

They are ready to become heaps. 

# What will cause the wicked to go away?

He will go away at the breath of God's mouth. 

# What reward will the wicked man have for trusting in useless things?

Uselessness will be his reward. 

# What will happen to the company of godless people?

It will be barren, and fire will consume their tents of bribery. 

# What did Job say about the comfort of his friends?

Job said they were miserable comforters using useless words. 

# What did Job say about the comfort of his friends?

Job said they were miserable comforters using useless words. 

# How does Job's speaking affect his grief?

If he speaks, his grief is not lessened, and if he keeps from speaking, his is not helped. 

# How are other people treating Job as God attacks him?

They gape at Job with open mouth, hit him reproachfully on the cheek, and gather together against him. 

# To whom has God given Job?

God handed him over to ungodly, and threw him into the hands of wicked people. 

# How has God injured Job?

He has pierced Job's kidneys and poured out his bile on the ground. 

# What has Job done to his skin to show his grief?

He has sewn sackcloth on his skin. 

# Who is Job's witness and able to vouch for Job?

Job's witness is in heaven, and the one who is for him is on high. 

# Who does Job turn to as his friends scoff at him?

Job pours out his tears to God. 

# What must Job always see?

He must always see the provocation of the mockers who are with him. 

# What pledge does Job want God to make to Job?

He wants God to pledge to be a guarantee with himself for Job. 

# Whose evil deed will cause the eyes of his children to fail?

The one who denounces his friends for a reward will cause the eyes of his children to fail. 

# What has happened to Job's eye and his body because of sorrow?

His eye is dim and all his body parts are as thin as shadows. 

# Does Job think that he can find a wise man among his friends?

Job does knows that he will not find a wise man among them. 

# Does Job have plans for the future?

Job's plans are over, as are the wishes of his heart. 

# What has become Job's father, mother, and sister?

The pit has become his father, and the worm is his mother and sister. 

# How did Bildad think Job viewed his friends?

Bildad thought Job regarded them as beasts, and thought they were stupid. 

# What will happen to the light of the wicked person?

His light will be put out, and the spark of his fire will not shine. 

# What will throw the wicked man into a net?

He will be thrown into a net by his own feet, and he will walk into a pitfall. 

# What will catch the wicked man?

He will be caught by a trap, a snare, and a noose. 

# What will catch the wicked man?

He will be caught by a trap, a snare, and a noose. 

# What will happen to the wealth of the wicked man?

His wealth turn into hunger. 

# Where will the wicked man no longer live?

He will be torn out of his tent, his home in which he now trusts. 

# What image does Bildad use to describe what will happen to the wicked man?

He describes the wicked man as a tree whose roots will dry up beneath the ground, and whose branch will be cut off above. 

# Will the wicked man have any descendants?

He will have no son or son's son among his people, nor any remaining kinfolk where he had stayed. 

# How do the people respond to what happens to the wicked man?

The people who live in the west will be horrified and the people who live in the east will be frightened. 

# Into what does Job say his friends have broken him?

Job says they have broken him into pieces of wood. 

# How many times have Job's friends reproached him?

They have reproached him ten times. 

# Whose concern should it be if Job had erred?

Job says the error should be his own concern. 

# How does Job say God has treated him?

Job says God has dome wrong to Job and caught him in God's net. 

# What happens when Job calls out for help because he has been wronged?

He is not heard and there is no justice. 

# How has God regarded Job?

He has regarded Job as one of his adversaries. 

# What has happened to all of Job's family and friends?

God has put his brothers far from him, his acquaintances are alienated, his kinsfolk fail him, and his close friends have forgotten him. 

# What has happened to all of Job's family and friends?

God has put his brothers far from him, his acquaintances are alienated, his kinsfolk fail him, and his close friends have forgotten him. 

# How does Job's servant respond to Job when he calls him?

His servant him gives me no answer although he entreats him with his mouth. 

# What have those whom Job loves responded to him?

Those whom he loves have turned against him. 

# How does Job survive?

He survives only by the skin of his teeth. 

# What does Job want to happen to his words?

He wants them to be written down and inscribed in a book, or engraved with pen and lead in the rock forever. 

# What does Job want to happen to his words?

He wants them to be written down and inscribed in a book, or engraved with pen and lead in the rock forever. 

# What does Job say he knows?

He knows that his Redeemer lives, and that at last his Redeemer will stand on the earth. 

# What does Job say will happen when his body is destroyed?

Job in his flesh will see God. 

# What does wrath bring?

Wrath brings the punishment of the sword. 

# Why did Zophar answer Job quickly?

He answered Job quickly because of his worry and that there is a spirit beyond his understanding that answers him. He has heard Job's rebuke and says it puts him to shame. 

# Why did Zophar answer Job quickly?

He answered Job quickly because of his worry and that there is a spirit beyond his understanding that answers him. He has heard Job's rebuke and says it puts him to shame. 

# Why did Zophar answer Job quickly?

He answered Job quickly because of his worry and that there is a spirit beyond his understanding that answers him. He has heard Job's rebuke and says it puts him to shame. 

# How long does the joy of a godless man last?

The joy of the godless only lasts for a moment. 

# How will the wicked man perish?

He will perish permanently like his own feces. 

# How will the wicked man go away?

He will fly away like a dream, and be chased away like a vision of the night. 

# What will the wicked man's children do?

His children will apologize to poor people. 

# What happens to wickedness inside the wicked man?

It will cause the food in his intestines to turn bitter, and will becomes like the poison of asps inside him. 

# What will happen to the riches that the wicked man swallows down?

He will vomit them up again. 

# What will the wicked man not live to enjoy?

He will not live to enjoy looking on rivers and flowing streams of honey and butter. 

# Why will the wicked man not rejoice?

He has oppressed and neglected the poor people, and has violently taken away houses that he did not build. 

# Why will the prosperity of the wicked man not be permanent?

It will not be permanent because there is nothing left that he did not devour. 

# What will God do to the wicked man who is about to fill his belly?

God will rain down the fierceness of his wrath on him while he is eating. 

# What will happen when the wicked man flees from the iron weapon?

A bow of bronze will shoot him. 

# What will the heavens and the earth do against the wicked man?

The heavens will reveal his iniquity and the earth will be a witness against him. 

# What will happen to the wicked man on the day of God's wrath?

The wealth of his house will vanish and his goods will flow away. 

# What does Job think his friends will do after he has spoken?

He thinks they will continue to mock him. 

# How will people respond when they look at Job?

They will be astonished and lay their hands upon their mouths. 

# What happens to Job when he thinks about his sufferings?

He is troubled and horror takes hold of his flesh. 

# What does Job ask about wicked people?

Job asks why do they continue to live, become old, and grow mighty in power? 

# What happens to the bull and the cow of the wicked?

The bull doesn't fail to breed and the cow doesn't lose her calf prematurely. 

# What do the wicked say to God?

They tell God to depart from them, for they do not wish any knowledge of his ways. 

# How does Job respond to the advice of wicked people?

He has nothing to do with their advice. 

# Who does Job want to pay for the guilt of the wicked person?

Job wants the wicked person to pay for his guilt, and not his children, so that he would know his guilt. 

# Can anyone teach God knowledge?

No, for he judges even those who are high. 

# What happens to both the man who dies in full strength and the one who dies in bitterness of soul?

They both lie down alike in the dust and the worms cover them both. 

# What does Job know about his friends' thoughts and ways?

He knows their thoughts and the ways in which they wish to wrong him. 

# What have traveling people seen happen to the wicked man?

They have seen that the wicked man is kept from the day of calamity, and that he is led away from the day of wrath. 

# What will men do for the tomb of the wicked man?

Men will keep watch over his tomb. 

# With what does Job say Zophar was trying to comfort him?

Job says Zophar was comforting him with nonsense. 

# What does Eliphaz ask Job if his righteousness can do for the Almighty?

He asks if it brings any pleasure to the Almighty if Job is righteous. 

# How does Eliphaz mock Job's reverence for God?

He mockingly says that because Job was reverent to God, he rebukes Job. 

# What does Eliphaz accuse Job of doing to the naked?

He says that Job has stripped the naked of their clothing. 

# What does Eliphaz accuse Job of doing to widows?

He claims Job has sent widows away empty. 

# What does Eliphaz say the darkness has done to Job?

He says that there is darkness, so that Job cannot see. 

# What does Eliphaz claim Job says about God not seeing people?

Job says, "Thick clouds are a covering to God, so that he does not see people." 

# What happens to the foundations of wicked men?

The wicked men's foundations have washed away like a river. 

# How do the righteous act when they see the fate of the wicked?

The righteous see their fate and are glad. 

# What will happen if Job is at peace with God?

If Job is at peace with God, good will come to him. 

# What does Eliphaz say will happen if Job returns to the Almighty?

If Job returns to the Almighty, he will be built up. 

# What will happen when Job takes pleasure in the Almighty?

When Job takes pleasure in the Almighty, he will lift up his face to God. 

# What does God do to the proud?

God humbles the proud. 

# What does Job say is heaveir than his groaning?

Job said that his suffering is heavier than his groaning. 

# What would Job do before God if he could find him?

He would lay his case in order before God and fill his mouth with arguments. 

# Does Job think God would against him in the greatness of God's power if he could stand before him?

No, he thinks God would pay attention to him. 

# What does Job say God is doing in the south?

Job says in the south, God hides himself so that Job cannot see him. 

# What result does Job expect from God's testing him?

When God has tested Job, he will come out like gold. 

# What has Job done with the words of God's mouth?

Job has treasured up in his heart the words of God's mouth. 

# What does God carry out for Job?

God carries out his decrees for Job. 

# How does Job feel when he thinks about God?

When Job thinks about him, he is afraid of him. 

# What covers Job's face?

The thick darkness cover's Job's face. 

# What times does Job think are not set by the Almighty?

Job asks why times for judging the wicked are not set by the Almighty. 

# What do the wicked do to the donkey of the fatherless?

They drive away the donkey of the fatherless. 

# What do the poor hope the Arabah will provide?

They hope the Arabah will provide them food for their children. 

# What do the poor lack in the cold?

They have no covering in the cold. 

# What do the poor embrace for lack of shelter?

They embrace a rock for lack of shelter. 

# What do the poor do for others even though they go hungry?

Even though they go hungry, they carry others' sheaves of grain. 

# What do the poor do for others even though they suffer thirst?

They tread the wicked men's winepresses, but they suffer thirst. 

# What is the murderer like in the night?

In the night, the muderer is like a thief. 

# Why do the wicked shut themselves up in daytime?

The wicked do not care for the light. 

# With what terrors are the wicked comfortable?

They are comfortable with the terrors of the thick darkness. 

# Who does sheol consume?

Sheol consumes those who have sinned. 

# Who does the wicked one devour?

The wicked one devours the barren women who have not born children. 

# Who does God drag away?

God drags away the mighty by his power. 

# What will happen to the mighty in a little while?

In only a little while, the mighty will be gone. 

# Where does God make order?

God makes order in his high places of heaven. 

# Of whom does Bildad ask can they be clean and acceptable to God?

He asks if one who is born of a woman can be clean and acceptable to God. 

# To what does Bildad compare a son of man?

He says that a son of man is a worm. 

# How does Job think Bildad's spoke his own words?

No, Job wants to know who helped Bildad speak his words. 

# What has no covering before God?

Destruction itself has no covering against God. 

# Where does God bind up the waters?

He binds up the waters in his thick clouds. 

# What does God spread on the face of the moon?

He encloses the face of the moon and spreads his clouds on it. 

# What did God calm with his power?

He calmed the sea with his power. 

# By what did God clear the heavens of storms?

By his breath, he cleared the heavens of storms. 

# What measure of God's voice do we hear?

We hear but a small whisper of him. 

# What does Job say God has taken away from him?

God has taken away his justice. 

# What does Job vow his lips will not speak?

Job vows that surely his lips will not speak unrighteousness. 

# How long will Job's thoughts not reproach him?

His thoughts will not reproach him so long as he lives. 

# What does Job say God does when he cuts off a godless man's life?

When God cuts off his life, God takes away his soul. 

# What does Job say he will not conceal of the Almighty?

Job said that he would not conceal the thoughts of the Almighty. 

# Of what will the wicked man's offspring not have enough?

His offspring will never have enough food. 

# What will the wicked man's widow not do for him?

His widow will make no lament for him. 

# What will happen to the silver of the wicked man?

The innocent will divide up his silver among themselves. 

# What does the wicked man see when he opens his eyes after he lies down rich?

He opens his eyes, and everything is gone. 

# What does the east wind do as it carries the wicked man away?

The east wind carries him away, and it sweeps him out of his place. 

# What does the wicked man try to do when the east wind does not stop?

He tries to flee out of its hand. 

# From where is copper smelted?

Copper is smelted out of the stone. 

# What does man search out to the farthest limit?

Man searches out, to the farthest limit, the stones in obscurity and thick darkness. 

# Where does man break open a shaft?

He breaks open a shaft away from where people live. 

# What is contained in the dust of the earth?

The earth's dust contains gold. 

# What has not walked through the path of man's shaft?

The proud animals have not walked such a path, nor has the fierce lion passed there. 

# What does man see in the channels he cuts among the rocks?

His eye sees every valuable thing there. 

# Where are wisdom and understanding not found?

Both of these are not found in the land of the living. 

# What cannot equal the worth of wisdom and understanding?

Gold and crystal cannot equal both of these in worth. 

# The price of wisdom is more than what jewel?

The price of wisdom is more than rubies. 

# From whose eyes is wisdom hidden?

Wisdom is hidden from the eyes of all living things. 

# Who knows wisdom's place?

God understands the way to wisdom and he knows its place. 

# What did God parcel out by measure?

He parceled out the waters by measure. 

# For what did God make a decree?

He made a decree for the rain. 

# What did God tell people is wisdom?

To people God said, "See, the fear of the Lord—that is wisdom." 

# Does Job recall a time when God cared for him?

Job remembers that in the past months God had cared for him. 

# What was on Job's tent in the ripeness of his days?

Job remembers the ripeness of his days, when the friendship of God was on his tent. 

# What had the rock poured out for Job in the past?

When the almighty was with Job, the rock poured out for him streams of oil. 

# How did the young men show respect for Job in the city square?

They saw Job and kept their distance from him in respect. 

# What did the princes do in the past when Job came?

They used to refrain from talking when he came. 

# What happened to the tongue of the noblemen when Job came?

Their tongue clung to the roof of their mouths. 

# What would the noblemen do after their eyes saw Job?

They would then give witness to Job and approve of him. 

# What did Job cause the widow's heart to do?

He caused her heart to sing for joy. 

# What had Job done even for the person he did not know?

He would examine the case even of one whom he did not know. 

# Who would Job pluck from the teeth of the unrighteous?

He plucked the victim out from between the teeth of the unrighteous. 

# What does Job say is always new in his hand?

The bow of his strength is always new in his hand. 

# What did men wait to drink in like rain from Job?

They opened their mouth wide to drink in his words as they would for the latter rain. 

# To what does Job compare himself at a funeral?

He say that he is like one who comforts mourners at a funeral. 

# Who has nothing but mockery for Job?

Those who are younger than Job have nothing but mockery for him. 

# What made the young men's fathers thin?

They were thin from poverty and hunger. 

# From where were the young men's fathers driven out?

Their fathers were driven out from among people. 

# Of whom does Job say the young men's fathers are descendants.

Job says that they were descendants of fools, indeed, of worthless men. 

# What had Job become for the sons of the worthless men?

Job had become their subject for a song of mockery. 

# What do the people now lose in front of Job?

These people lose all self-control in front of him. 

# Why are the men able to push forward disaster for Job?

They push forward disaster for him, for they have no one to hold them back. 

# What does Job say is driven away by the wind?

His honor is driven away as if by the wind. 

# What has laid hold of Job as his life is pouring out within him?

Many days of suffering have laid hold on him. 

# What does Job say has seized his clothing?

God's great force has seized my clothing. 

# How does Job say God persecutes him as he has changed and become cruel?

God has changed and become cruel to him; with the power of his hand God persecutes him. 

# What does Job know is destined for all living things?

He knows that God will bring him to death, to the house destined for all living things. 

# What came when Job waited for light?

When he waited for light, darkness came instead. 

# Where did Job stand to call for help?

He stood up in the assembly and cried for help. 

# For what kind of music does Job say his harp is tuned?

Job says that his harp is tuned for songs of mourning. 

# What desire does Job say is subdued by a covenant with his eyes?

Job has made a covenant with his eyes to not look with desire on a virgin. 

# For whom did Job use to think calamity was reserved?

Job used to think that calamity was for the unrighteous. 

# What does Job ask to be done so that God would know his integrity?

He asks to be weighed in an even balance, so that God would know his integrity. 

# What does Job ask to happen to the harvest, if he has turned out of the right way?

He says to let the harvest be uprooted out of his field. 

# What does Job say should be the judgement if he was attracted to another woman?

Job says to let his wife grind grain for another man. 

# What kind of fire does Job say this crime is like?

Job says that it is a fire that consumes everything for sheol. 

# What did God do for both the servants and for Job?

God made and molded them all in the womb. 

# How does Job say he has treated the orphan from his youth?

He says the orphan grew up with him as with a father. 

# What should be offered to warm the needy with no clothing?

They should have been warmed with the wool of his sheep. 

# What part of his body does Job say should come off if he has failed to have compassion?

Job says to let his shoulder fall from the shoulder blade. 

# What could people say to fine gold?

They could say to fine gold, "You are my confidence." 

# Who would Job be denying if he worshipped the sun or moon?

If he worshiped them he would have denied the God who is above. 

# How has Job not suffered his mouth to sin?

Job has not suffered his mouth to sin by asking for the life of those who hate him with a curse. 

# What had Job always done for the traveler?

He had always opened his doors to the traveler. 

# How does Job say mankind has hidden his sins?

He has hidden his sins by hiding his guilt inside his tunic. 

# What does Job want to have that his opponent has written?

Job desired the indictment that his opponent had written. 

# How would Job go up to his opponent if he had their indictment?

He would go up to him as a confident prince. 

# If Job has caused landowners to lose their lives, what does he call to grow instead of crops?

Job said to let thorns grow instead of wheat and weeds instead of barley. 

# What did Job's three friends do when they could not convince Job that he had done anything wrong?

They stopped answering Job. 

# What emotion was kindled in Elihu when Job continued to justify himself rather than God?

Elihu's anger was kindled against Job. 

# Why was Elihu's anger kindled against Job's three friends?

He was angry with Job's friends because they had found no answer to Job and yet they had condemned Job. 

# Why was Elihu's anger kindled against Job's three friends?

He was angry with Job's friends because they had found no answer to Job and yet they had condemned Job. 

# Why was Elihu's anger kindled against Job's three friends?

He was angry with Job's friends because they had found no answer to Job and yet they had condemned Job. 

# Why was Elihu timid and afraid to tell Job and his friends what he was thinking?

Elihu was young and the others were all very old and should be able to teach wisdom. 

# Why was Elihu timid and afraid to tell Job and his friends what he was thinking?

Elihu was young and the others were all very old and should be able to teach wisdom. 

# Who does Elihu say gives understanding to man?

The breath of the Almighty gives man understanding. 

# Why does Elihu say the others should listen to him and allow him to declare what he knows?

It is not only the great who are wise, and it not the aged alone who understand justice. 

# Why does Elihu say the others should listen to him and allow him to declare what he knows?

It is not only the great who are wise, and it not the aged alone who understand justice. 

# What were Job's friends not able to do even though Elihu waited for them to speak, and paid attention carefully?

Job's friends were not able to convince Job or respond to his words. 

# What were Job's friends not able to do even though Elihu waited for them to speak, and paid attention carefully?

Job's friends were not able to convince Job or respond to his words. 

# Who does Elihu say must refute Job when the three friends, who thought they were wise, were not able to do that?

It is God who must refute Job. 

# What does Elihu decide to do because the three friends were dumbfounded and could not answer Job?

Elihu decided that because the friends had not a word more to say, he will not wait any longer. 

# What does Elihu decide to do because the three friends were dumbfounded and could not answer Job?

Elihu decided that because the friends had not a word more to say, he will not wait any longer. 

# What is it that compels Elihu to share his knowledge with Job?

The spirit compels Elihu to share his knowledge. 

# What does Elihu say he is feeling like within his breast?

He says his breast feels like wine in new wineskins that are ready to burst. 

# What does Elihu say his Maker would do to him if he were to speak and give honorific titles to any man?

Elihu says that his Maker would soon take him away. 

# What does Elihu say his Maker would do to him if he were to speak and give honorific titles to any man?

Elihu says that his Maker would soon take him away. 

# Why does Elihu beg Job to listen to the words he will speak?

Elihu begs Job to listen because he will speak the uprightness of his heart. 

# Why does Elihu beg Job to listen to the words he will speak?

Elihu begs Job to listen because he will speak the uprightness of his heart. 

# Why does Elihu beg Job to listen to the words he will speak?

Elihu begs Job to listen because he will speak the uprightness of his heart. 

# Who has made Elihu and what has given him life?

The Spirit of God made Elihu and the Almighty gave him life. 

# What does Elihu ask Job to do if Job could answer Elihu?

He asks Job to set his words in order and stand up before Elihu. 

# What reason does Elihu give that Job should not be afraid of him or feel pressure from Elihu?

Elihu tells Job that they are the same in God's sight and were both formed out of the clay. 

# What reason does Elihu give that Job should not be afraid of him or feel pressure from Elihu?

Elihu tells Job that they are the same in God's sight and were both formed out of the clay. 

# What had Elihu heard Job saying?

Elihu heard Job saying that he was clean, without transgression, innocent and there was no sin in him. 

# What had Elihu heard Job saying?

Elihu heard Job saying that he was clean, without transgression, innocent and there was no sin in him. 

# Who does Job blame for finding opportunities to attack him, and for regarding him as an enemy?

Job blames God for doing these things. 

# How does Elihu say God compares to man?

Elihu says God is greater than man. 

# Why does Elihu say it is useless to struggle against God?

God does not have to account for any of his doings. 

# How does Elihu say that God speaks to man?

God speaks in a dream and in a vision during the night while men are sleeping. 

# How does Elihu say that God speaks to man?

God speaks in a dream and in a vision during the night while men are sleeping. 

# Why does God open the ears of men and frighten them with threats?

God does this in order to pull man back from sinful purposes and keep pride from him. 

# Why does God open the ears of men and frighten them with threats?

God does this in order to pull man back from sinful purposes and keep pride from him. 

# What does Elihu say is the reason that man has pain on his bed, agony in his bones, and no desire for food or delicacies?

Elihu says that this is because man is being punished. 

# What does Elihu say is the reason that man has pain on his bed, agony in his bones, and no desire for food or delicacies?

Elihu says that this is because man is being punished. 

# What does Elihu say happens to a man who is being punished by God?

A man's flesh is consumed, his bones stick out and his soul draws close to the pit. 

# What does Elihu say happens to a man who is being punished by God?

A man's flesh is consumed, his bones stick out and his soul draws close to the pit. 

# What could an angel mediator say to God to save a person from going down to the pit?

The angel could ay to God, "I have found a ransom for him." 

# What will happen to the flesh of the person who is saved from going down to the pit?

His flesh will become fresher than a child's. 

# What will happen to the life of a person who admits his sin and is rescued from the pit by God?

That person's life will continue to see light. 

# Why does Elihu say that God rescues a person from the pit?

God does this so that a person may be enlightened with the light of life. 

# Why does Elihu say that God rescues a person from the pit?

God does this so that a person may be enlightened with the light of life. 

# What does Elihu want to teach Job if Job will pay attention and listen to him and remain silent?

Elihu wants to teach Job wisdom. 

# Who does Elihu want to listen to his words and hear him?

Elhu wants the wise men and those who have knowledge to listen to him. 

# Who does Elihu want to listen to his words and hear him?

Elhu wants the wise men and those who have knowledge to listen to him. 

# Who does Elihu want to listen to his words and hear him?

Elhu wants the wise men and those who have knowledge to listen to him. 

# What does Elihu want others to choose and discover for themselves?

Elihu wants them to choose what is just and discover what is good. 

# What does Job say that God has taken away from him even though he is without sin and what is incurable?

Job says that God has taken away his rights. 

# In whose company does Elihu say Job goes around?

He says Job goes around in the company of those who do evil. 

# What does Elihu tell the men of understanding that God does not do?

God does not do wickedness, commit sin, or pervert justice. 

# What does Elihu tell the men of understanding that God does not do?

God does not do wickedness, commit sin, or pervert justice. 

# What does Elihu tell the men of understanding that God does not do?

God does not do wickedness, commit sin, or pervert justice. 

# What does Elihu say would happen if God ever gathered back to himself his spirit and his breath?

All flesh would perish and mankind would return to dust again. 

# What does Elihu say would happen if God ever gathered back to himself his spirit and his breath?

All flesh would perish and mankind would return to dust again. 

# What does Elihu say would happen if God ever gathered back to himself his spirit and his breath?

All flesh would perish and mankind would return to dust again. 

# Who does Elihu's question imply that Job is condemning?

He implies Job is condemning God who is righteous and mighty. 

# Who does Elihu say are the works of God's hands?

Leaders, rich and poor, are all the work of God's hands. 

# What does Elihu say that God sees.

Elihu says that God sees a person's ways and all his steps. 

# What does God do in the night to mighty men whose ways and deeds he knows?

God overthrows them in the night and they are destroyed. 

# What will God do to those who do wicked deeds like criminals and make the cry of the poor come to him?

God will kill them in the open sight of others. 

# Over whom does God rule?

God rules over the nation and the individual alike. 

# What is Elihu suggesting that Job should admit to God?

Elihu suggests that Job should admit that he is guilty and has committed sin, but will do it no longer. 

# What is Elihu suggesting that Job should admit to God?

Elihu suggests that Job should admit that he is guilty and has committed sin, but will do it no longer. 

# What will men of understanding say about Job?

They will say that Job speaks without knowledge and wisdom. 

# What will men of understanding say about Job?

They will say that Job speaks without knowledge and wisdom. 

# What does Elihu say Job is adding to his sin because of his talking like wicked men?

He says that Job is adding rebellion to his sin. 

# How does Elihu imply Job compares himself to God?

Elihu implies that Job thinks he is innocent, and that he is more righteous than God. 

# How does Elihu imply Job compares himself to God?

Elihu implies that Job thinks he is innocent, and that he is more righteous than God. 

# What does Elihu tell Job and his friends to look up and see?

Elihu tells them to look up and see the sky. 

# What effect could Job's wickedness or his rightousness have on another man?

Job's wickedness could hurt a man and his righteousness could benefit another son of man. 

# Why do people cry out for help from the arms of mighty men?

They cry out for help because of the many acts of oppression. 

# What things does Elihu say that God can do for people even though no one acknowledges it?

God gives songs in the night, teaches us, and makes us wise. 

# What things does Elihu say that God can do for people even though no one acknowledges it?

God gives songs in the night, teaches us, and makes us wise. 

# Why does Elihu say that God does not give an answer when people cry out to him?

Elihu says that God does not give an answer when people cry out because of the pride of evil men. 

# What will God certainly not hear?

He will certainly not hear a foolish cry. 

# What does Elihu accuse Job of doing when Job opens his mouth?

He says Job opens his mouth to speak foolishness and to pile up words without knowledge. 

# To whom does Elihu acknowledge that righteousness belongs?

Elihu acknowledges that righteousness belongs to his Maker. 

# What does God do for those who those who suffer?

He does what is right for those who suffer. 

# What does God do for the righteous?

He sets them on thrones like kings forever, and they are lifted up. 

# What does God reveal to those who are bound in chains and trapped in cords of suffering?

He reveals to them what they have done, their transgressions, and how they behaved arrogantly. 

# What will happen to listen to God and worship him?

They will spend their days in prosperity and their years in contentment. 

# What will happen to the people who do not listen to God?

They will perish by the sword and die because they have no knowledge. 

# What does the godless person who stores up anger and does not cry out to God for help?

They will die in their youth and their lives will end in disgrace. 

# How does Elihu say God uses affliction and oppression?

God uses affliction to rescue the afflicted and oppression to open their ears. 

# How does Elihu say God uses affliction and oppression?

God uses affliction to rescue the afflicted and oppression to open their ears. 

# What does Elihu say that God would like to do for Job?

God would like to draw Job out of his distress into a broad place where there is no hardship. 

# What has filled Job?

He is full of the judgment on the wicked. 

# What things could lead Job to deception and turn him aside from justice?

Wealth could lead Job to deception and a bribe could turn him aside from justice. 

# What things will not be able to help Job out of his distress?

Job's wealth and the force of his strength will not help him out of his distress. 

# Why does Elihu say that Job is being tested by suffering?

Job is being tested by suffering so that he will stay away from sinning. 

# What can no one say about God?

No one can say that God has committed unrighteousness. 

# What is it about God that we cannot calculate?

We cannot calculate the number of his years. 

# How does God cause rain to fall?

He draws up the drops of water that distill as rain from his vapor, which the clouds pour down and drop in abundance on mankind. 

# How does God cause rain to fall?

He draws up the drops of water that distill as rain from his vapor, which the clouds pour down and drop in abundance on mankind. 

# Why does Elihu say that God spreads lightning and covers the sea with darkness?

He spreads lightning around himself and covers the sea with darkness in order to feed people and give food in abundance. 

# Why does Elihu say that God spreads lightning and covers the sea with darkness?

He spreads lightning around himself and covers the sea with darkness in order to feed people and give food in abundance. 

# What tells people and cattle of the coming storm?

The noise of the lightning bolts hitting their targets tells people and cattle of the coming storm. 

# What tells people and cattle of the coming storm?

The noise of the lightning bolts hitting their targets tells people and cattle of the coming storm. 

# What makes Elihu's heart tremble?

The noise of God's voice and the sound from his mouth causes Elihu's heart to tremble. 

# What makes Elihu's heart tremble?

The noise of God's voice and the sound from his mouth causes Elihu's heart to tremble. 

# What does God tell the snow and the rain to do?

HE tells the snow to fall to the earth, and the rain to become a great shower of rain. 

# Why does God stop the hand of every man from working?

God stops them so that all people may see his deeds. 

# For what reason do the beasts go into hiding and stay in their dens?

They hide and stay in their dens because of the storms that come. 

# For what reason do the beasts go into hiding and stay in their dens?

They hide and stay in their dens because of the storms that come. 

# What is given by the breath of God?

By the breath of God ice is given. 

# For what reasons does God give guidance to the clouds and cause them to do whatever he commands?

He makes this happen sometimes for correction, sometimes for his land, and sometimes as acts of covenant faithfulness. 

# About what does Elihu want Job to stop and think?

He wants Job to stop and think about God's marvelous deeds. 

# What happens when God forces his will on the clouds?

God makes lightning bolts flash in the clouds. 

# What image does Elihu use to describe the sky?

He says the sky is as strong as a mirror of cast metal. 

# Why does Elihu say that he and others cannot lay out their arguments before God?

They cannot lay out their arguments before God because of the darkness of their minds. 

# What is it that people cannot look at when the sky is clear?

People cannot look at the sun when it is bright in the sky. 

# What does Elihu say that the Almighty does not do to his people?

The Almighty does not oppress people. 

# To whom does Elihu say that the Almighty does not pay attention?

The Almighty does not pay attention to those who are wise in their own minds. 

# Out of what did Yahweh speak to Job?

Yahweh spoke to Job out of a fierce storm. 

# By what means did someone bring darkness to Yahweh's plans?

Job brought darkness to Yahweh's plans by means of words without knowledge. 

# What does Yahweh tell Job he must do when Yahweh questions him?

Job must gird up his loins like a man and answer Yahweh's questions. 

# What sang together and who shouted for joy when Yahweh laid the cornerstone of the earth?

The morning stars sang together and all the sons of God shouted for joy when the cornerstone was laid. 

# What sang together and who shouted for joy when Yahweh laid the cornerstone of the earth?

The morning stars sang together and all the sons of God shouted for joy when the cornerstone was laid. 

# To what does Yahweh compare the sea bursting out after it was shut up with doors?

God compares the sea bursting out of doors to coming out of the womb. 

# What did Yahweh put in place to mark out the boundary of the sea so that it could come only so far and no farther?

Yahweh put in place bars and doors to mark a boundary for the sea. 

# What did Yahweh put in place to mark out the boundary of the sea so that it could come only so far and no farther?

Yahweh put in place bars and doors to mark a boundary for the sea. 

# How is the earth is changed in appearance like clay changes under a seal?

The light of dawn changes the earth so that all things on it stand out clearly like the folds of a piece of clothing. 

# What does Yahweh say to mock Job about his lack of knowledge about the way to the resting place of light and darkness?

Yahweh mocks Job by saying that undoubtedly Job should know about this because the number of Job's days is so large. 

# What does Yahweh say to mock Job about his lack of knowledge about the way to the resting place of light and darkness?

Yahweh mocks Job by saying that undoubtedly Job should know about this because the number of Job's days is so large. 

# What does Yahweh say to mock Job about his lack of knowledge about the way to the resting place of light and darkness?

Yahweh mocks Job by saying that undoubtedly Job should know about this because the number of Job's days is so large. 

# For what reason does Yahweh say he has kept storehouses for the snow and the hail?

Yahweh has kept these storehouses for times of trouble and for days of battle and war. 

# For what reason does Yahweh say he has kept storehouses for the snow and the hail?

Yahweh has kept these storehouses for times of trouble and for days of battle and war. 

# Why does Yahweh cause it to rain on the wilderness in which there is no person?

He causes it to rain in order to meet the needs of the barren and lonely regions and to make the tender grass sprout up. 

# Why does Yahweh cause it to rain on the wilderness in which there is no person?

He causes it to rain in order to meet the needs of the barren and lonely regions and to make the tender grass sprout up. 

# Why does Yahweh cause it to rain on the wilderness in which there is no person?

He causes it to rain in order to meet the needs of the barren and lonely regions and to make the tender grass sprout up. 

# What does Yahweh asks Job if he can do to Pleiades and Orion?

He asks Job if he can fasten chains on Pleiades or undo the cords of Orion. 

# What happens to the dust and clods of earth when Yahweh pours out water on them?

The dust runs into a hard mass and the clods of earth clump tightly together. 

# What happens to the dust and clods of earth when Yahweh pours out water on them?

The dust runs into a hard mass and the clods of earth clump tightly together. 

# Where do the young lion cubs wait for their food?

They are crouch in their dens and shelter in hiding to lie in wait. 

# Why do the young ones of the ravens stagger about?

They stagger about for lack of food. 

# What happens to the young deer after they grow up in the open fields?

They go out and do not come back again. 

# Where has Yahweh made the home of the donkey?

He has made his home in the Arabah, and his house in the salt land. 

# Where does the wild donkey find food?

He roams over the mountains where he looks for every green plant to eat. 

# What does Yahweh ask Job to make the wild ox do with a rope?

He asks Job if with a rope, he can make the wild ox to plow the furrows or harrow the valleys for him. 

# What does the ostrich wave proudly?

The wings of the ostrich wave proudly. 

# What does the ostrich do with her eggs?

She leaves her eggs on the earth, and lets them keep warm in the dust. 

# Why does the ostrich not fear that her labor might have been in vain?

Yahweh has deprived her of wisdom and not given her any understanding. 

# What does Yahweh say the ostrich does when she runs?

She laughs in scorn at the horse and its rider. 

# What clothes the neck of the horse?

A flowing mane clothes his neck. 

# How does the horse react to the sword?

He does not turn back from the sword. 

# What can the horse not do at the sound of the trumpet?

He cannot stand in one place. 

# Where does the eagle make his nest and his home?

He makes his nest in high places, and his home on the peaks of the cliffs. 

# Where does the eagle make his nest and his home?

He makes his nest in high places, and his home on the peaks of the cliffs. 

# How did Job do to show that he was too insignificant to answer Yahweh?

Job put his hand over his mouth. 

# From what did Yahweh answer Job?

Yahweh answered Job from out of a fierce storm. 

# What did Yahweh tell Job to do to prepare to answer Yahweh?

He told Job to gird up his loins like a man. 

# Why did Yahweh say that Job was condemning Yahweh?

He said Job condemned Yahweh so that Job could claim he was right. 

# With what does Yahweh challenge Job to clothe himself?

He challenges Job to cloth himself with glory, dignity, honor and majesty. 

# What does Yahweh tell Job to do to the wicked people?

Yahweh tells Job to trample them down where they stand. 

# What does the behemoth eat?

He eats grass like an ox. 

# What is the tail of the behemoth like?

His tail is like a cedar. 

# Who can defeat the behemoth?

Only God can defeat the behemoth. 

# Where does the behemoth lie?

He lies under the lotus plants in the shelter of the reeds. 

# What does the behemoth think when the river floods and the Jordan surges?

He does not tremble and he is confident. 

# With what does Yahweh ask Job if he can draw out leviathan?

Yahweh asks Job if he can draw out the leviathan with a fishhook. 

# What does Yahweh ask Job if the fishermen would do with leviathan?

He asks Job if the fishermen would bargain for leviathan or divide him up to trade among the merchants. 

# What will happens if a person puts his hand on leviathan?

It someone puts his hand on the leviathan just once, he will remember the battle and do it no more. 

# Since no one is fierce enough to dare stir leviathan up, can anyone stand before Yahweh?

No one dares to stir leviathan up, so there is no one who can stand before Yahweh. 

# How more does Yahweh describe leviathan's mouth?

He says it is the doors of his face that are ringed with his teeth, which are a terror. 

# How close are the scales on the back of leviathan?

One is so near to another that no air can come between them. 

# How does Yahweh say leviathan's eyes are like?

His eyes are like eyelids of the morning. 

# What comes out of leviathan's mouth?

Out of leviathan's mouth go burning torches, and sparks of fire leap out. 

# How is the smoke from leviathan's nostrils like?

It is like a boiling pot on a fire that has been fanned to be very hot. 

# What is leviathan's heart like?

His heart is as hard as a lower millstone. 

# What do the gods do when leviathan raises himself up?

They become afraid and draw back. 

# What happens when a sword, spear, arrow or any pointed weapon strikes leviathan?

They do nothing to him. 

# What does leviathan think of iron and bronze?

He thinks of iron as if it were straw and bronze as if it were rotten. 

# What kind of trail does leviathan leave?

He leaves a spreading trail in the mud as if he were a threshing sledge. 

# What does he make the deep to do?

He makes the deep to foam up like a boiling pot of water. 

# Why does leviathan have no equal on earth?

He s has been made to live without fear. 

# What did Job acknowledge that he had spoken?

He had spoken things that he did not understand, things too difficult for him to understand, which he did not know about. 

# How did Job respond to Yahweh after seeing him with his eye?

Job despised himself and repented in dust and ashes. 

# What did Yahweh say that Eliphaz and his two friends had done wrong?

They had not said right things about Yahweh, as Job had done. 

# What did Yahweh tell Eliphaz to give as an offering?

He told Eliphaz to take seven bulls and seven rams to offer for themselves as a burnt offering. 

# Whose prayer did Yahweh say he would accept?

Yahweh said he would accept Job's prayer. 

# What happened after Job prayed for his friends?

Yahweh restored his fortunes, and gave him twice of what he had possessed before. 

# What did every person give to Job when they came to comfort him?

They each gave him a piece of silver and a ring of gold. 

# How did Yahweh bless Job at the end of his life?

Yahweh blessed Job more than the first part of Job's life. 

# How many more sons and daughters did Yahweh give to Job?

He had seven sons and three daughters. 

# What was unique about Job's daughters?

There were no woman in the land as beautiful as Job's daughters, and he gave them an inheritance with their brothers. 

