# Where does the blessed man not walk?

He does not walk in the advice of the wicked. 

# Where does the blessed man not stand?

He does not stand in the pathway with sinners. 

# Where does the blessed man not sit?

He does not sit in the assembly of mockers. 

# In what does the blessed man delight?

He delights in the law of Yahweh. 

# When does the blessed man meditate on the law?

He meditates on it day and night. 

# What is the blessed man like?

He is like a tree planted by the streams of water. 

# What will happen to everything the blessed man does?

Whatever he does will prosper. 

# What are wicked people like?

They are like the chaff that the wind drives away. 

# What will happen to wicked people in the judgment?

They will not stand in the judgment. 

# Who approves of the way of the righteous?

Yahweh approves of the way of the righteous. 

# What will happen to the way of the wicked?

The way of the wicked will perish. 

# Who are the rulers conspiring against?

They are conspiring against Yahweh and against his Messiah. 

# What do the rulers want to tear off and throw off?

They want to tear off the shackles Yahweh and his Messiah put on them and throw off their chains. 

# Who sits in the heavens and mocks the nations who rebel?

The Lord mocks them. 

# Who has the Lord anointed?

The Lord has anointed his king on Zion, his holy mountain. 

# What decree does Yahweh give to the writer?

Yahweh says, "You are my son! This day I have become your father." 

# What will Yahweh do with the nations and farthermost regions of the earth?

Yahweh will give them as an inheritance and possession. 

# What will happen to the nations?

They will be broken and smashed. 

# How should the kings and rulers respond to Yahweh's decree?

They should worship Yahweh in fear and rejoice with trembling. 

# Why should the kings give allegiance to Yahweh's son?

They should give him allegiance so that he will not be angry and they will not die. 

# What happens to all those who take shelter in the son?

They are blessed. 

# What have David's enemies done to him?

They have turned away and attacked him. 

# To what does David compare Yahweh?

Yahweh is a shield around him, his glory, and the one who lifts his head. 

# What does Yahweh do when David lifts his voice to him?

He answers from his holy hill. 

# Who will David not fear because of Yahweh's protection?

David will not be afraid of people who have set themselves against him. 

# What will Yahweh do to David's enemies?

He will hit all his enemies on the jaw; he will break the teeth of the wicked. 

# From whom does salvation come?

Salvation comes from Yahweh. 

# Who does David ask to answer when he calls?

David prays for the God of his righteousness to answer when he calls. 

# What are the people doing to David's honor?

They are turning his honor into shame. 

# Who does Yahweh set apart?

He sets apart the godly for himself. 

# How does David say to meditate?

He says, "Meditate in your heart on your bed and be silent." 

# What kind of sacrifices does David say to offer?

He says to offer the sacrifices of righteousness. 

# In whom does David say to trust?

He says to trust in Yahweh. 

# What will many say?

Many will say, "Who will show us anything good?" 

# What does David ask Yahweh to lift up?

He asks Yahweh to lift up the light of his face on them. 

# What has Yahweh given David's heart?

Yahweh has given his heart more gladness than others have when their grain and new wine abound. 

# Who makes David safe and secure when he lies down in peacful sleep?

Yahweh alone makes David safe and secure. 

# Who is David asking to listen to his call and think about his groanings?

David is asking Yahweh to listen to his call and think about his groanings. 

# What names does David use for the one who listens to the sound of his call?

David calls him, "my King and my God." 

# What will David do in the morning?

He will bring his petition to Yahweh and wait expectantly. 

# What does God certainly not do?

He certainly does not approve of evil, and evil people will not be his guests. 

# Who will not stand in God's presence?

The arrogant will not stand in God's presence. 

# Who does God hate?

God hates all who behave wickedly. 

# What will God do to liars?

God will destroy liars. 

# Who does Yahweh despise?

Yahweh despises violent and deceitful men. 

# Why will David come into Yahweh's house?

David will come into Yahweh's house because of Yahweh's great covenant faithfulness. 

# How will David bow down toward Yahweh's holy temple?

David will bow down in reverence. 

# Why does David ask the Lord to lead him in righteousness?

David asks the Lord to lead him in the Lord's righteousness because of David's enemies. 

# How does David describe his enemies?

David describes his enemies as having no truth in their mouth, their inward being is wicked, their throat is an open sepulchre and they flatter with their tongue. 

# What is David asking God to do to David's enemies because of their many transgressions and rebellion against God?

David is asking God to declare that his enemies are guilty. 

# Why should those who take refuge in God shout for joy?

They should shout for joy because God defends them. 

# What will Yahweh do for the righteous?

Yahweh will bless the righteous and surround them with his favor as with a shield. 

# What is David asking Yahweh not to do?

He asks Yahweh not to rebuke him in his anger or discipline him in his wrath. 

# What is David asking Yahweh to do because David is frail?

David asks Yahweh to have mercy on him and to heal him. 

# Why should Yahweh rescue and save David?

Because of Yahweh's covenant faithfulness. 

# What will not be remembered in death?

In death there is no remembrance of Yahweh. 

# What does David do to his bed because he is weary and groaning?

All night he drenches it with his tears. 

# What happens to David's eyes because of his grief and because of all his adversaries?

His eyes grow dim and weak. 

# Why should those who practice iniquity get away from David?

Because Yahweh has heard the sound of his weeping and his appeal for mercy and has accepted his prayer. 

# Why should those who practice iniquity get away from David?

Because Yahweh has heard the sound of his weeping and his appeal for mercy and has accepted his prayer. 

# What will happen to David's enemies?

All his enemies will be ashamed and greatly troubled and they will turn back and be suddenly humiliated. 

# In whom does David take refuge?

David takes refuge in Yahweh his God. 

# What is David asking Yahweh to do?

David is asking Yahweh to save him from those who chase him, and to rescue him. 

# What is only Yahweh able to do for David?

No one but Yahweh is able to bring David to safety. 

# What did David say that he did not do?

David tells Yahweh that he never did what his enemies said he did and there is no injustice on his hands. 

# What does David say he has not done to anyone at peace with him or who is against him?

David says he has never done wrong to anyone at peace with him or senselessly harmed any who are against him. 

# What does David say Yahweh should do to him if David is not telling the truth?

David says Yahweh should let David's enemy pursue David's life and overtake it, trample his living body, and leave him dishonored in the dust. 

# What is David asking Yahweh to do in Yahweh's anger?

David is asking Yahweh to arise and stand up against David's enemies. 

# What does David ask Yahweh to do for David's sake?

David asks Yahweh to wake up and carry out the righteous decrees that Yahweh commanded. 

# What does David want Yahweh to do about the countries?

David wants Yahweh to take his rightful place over the countries. 

# Who does David want Yahweh to judge?

David wants Yahweh to judge the nations. 

# What does David say the righteous God does?

David says God examines hearts and minds. 

# Where does David's shield come from?

David's shield comes from God. 

# Who does God save?

God saves the upright in heart. 

# How does David describe God?

David describes God as a righteous judge who is indignant each day. 

# What will God do if a person does not repent?

God will sharpen his sword and will prepare his bow for battle. 

# How does David describe wickedness in the one who does not repent?

David describes him as pregnant with wickedness, one who conceives destructive plans and gives birth to harmful lies. 

# What happens to the wicked man who digs a pit?

He falls into the hole he has made. 

# What happens to the destructive plans of the wicked man?

His plans return to his own head and his violence comes down on his own head. 

# For what will David give thanks to Yahweh?

He will give thanks to Yahweh for his justice. 

# To whom will David sing praise?

David will sing praise to Yahweh Most High. 

# Whose name is magnificent in all the earth?

The name of Yahweh our Lord is magnificant. 

# What did Yahweh create out of the mouth of babies and infants?

Yahweh created praise. 

# Why did Yahweh create praise?

He created praise in order to silence both the enemy and the avenger. 

# What did David look up at that caused him to think the human race was not important?

He looked up at the heavens, the moon, and the stars. 

# How does the human race compare to the heavenly beings?

Yahweh made humans only a little lower than the heavenly beings. 

# WIth what did Yahweh crown humans?

He crowned them with glory and honor. 

# What did Yahweh make mankind to do?

Yahweh made mankind to rule over the works of Yahweh's hands. 

# What are some things that Yahweh put under mankind's feet?

He put all sheep and oxen, and even the animals of the field, the birds of the heavens, and the fish of the sea, and everything that passes through the currents of the seas under mankind's feet. 

# What are some things that Yahweh put under mankind's feet?

He put all sheep and oxen, and even the animals of the field, the birds of the heavens, and the fish of the sea, and everything that passes through the currents of the seas under mankind's feet. 

# Whose name is magnificent in all the earth?

The name of Yahweh our Lord is magnificent. 

# How will David give thanks to Yahweh and of what will he tell?

He will give thanks to Yahweh with his whole heart and tell about all his marvelous deeds. 

# When David's enemies turn back, what happens to them?

The enemies stumble and perish before Yahweh. 

# What has the rightous judge done for David?

The rightous judge sits on his throne and has defended David's just cause. 

# What did the rightous judge do to the nations and the wicked?

He terrified the nations with his battle cry, destroyed the wicked, and blotted out their memory forever. 

# What happened to the enemy when the righteous judge overthrew their cities?

The enemy crumbled like ruins and all remembrance of them perished. 

# Who remains forever and establishes his throne for justice?

Yahweh remains forever and establishes his throne for justice. 

# How does Yahweh judge the world and what does he do for the nations?

Yahweh judges the world fairly and makes just decisions for the nations. 

# What will Yahweh be for the oppressed?

Yahweh will be a stronghold for the oppressed in times of trouble. 

# What does David ask Yahweh do for those who seek him?

David asks Yahweh not to abandon those who seek him. 

# What does David say the people are to do to Yahweh, who rules in Zion?

They are to sing praises to Yahweh and tell the nations what Yahweh has done. 

# What does the God not forget?

He does not forget the cry of the oppressed. 

# What is David asking Yahweh to do for him?

He is asking Yahweh to have mercy on him. 

# By whom is David oppressed?

David is oppressed by those who hate him. 

# Where will David rejoice in salvation?

David will rejoice in salvation in the gates of the daughter of Zion. 

# What has happened to the nations?

The nations have sunk down into the pit that they made and their feet are caught in the net that they hid. 

# Who has made himself known and executed judgment?

Yahweh has made himself known and executed judgment. 

# Where are the wicked sent?

They are sent to sheol, which is the destiny of all the nations that forget God. 

# What will not happen to the needy and the oppressed?

The needy will not always be forgotten nor will the hopes of the oppressed be forever dashed. 

# What does David want Yahweh to prevent man from doing?

David wants Yahwah to arise and not let man conquer them. 

# What is David asking Yahweh to do to the nations?

He is asking Yahweh to terrify them and make them know that they are mere men. 

# How does the writer feel that Yahweh is treating him?

The writer feels that Yahweh is standing far off and hiding himself. 

# What does the writer ask Yahweh to do to the wicked people?

The writer asks Yahweh to let the wicked be trapped by their own schemes. 

# Why does the wicked man not seek God?

The wicked man does not seek God because he is so proud. 

# What does the wicked man say in his heart?

The wicked man says, "I will never fail; throughout all generations I will not meet adversity." 

# What fills the mouth of the wicked man?

His mouth is full of curing and deceptive, harmful words. 

# What animal if the wicked man like?

He is like a lion that lurks in secret in the thicket and lies in wait to catch the oppressed. 

# What does the wicked man say in his heart about God?

The wicked man says, "God has forgotten; he covers his face; he will not bother to look." 

# How does the writer want Yahweh to respond to the wicked man?

He wants Yahweh to lift up his hand in judgment and to not forget the oppressed. 

# What does the wicked man say in his heart to God?

He says, "You will not hold me accountable." 

# What did the wicked and evil man think about his evil deeds?

He thought God would not discover them. 

# How does Yahweh respond to the needs of the oppressed?

He strengthen's their heart, listens to their prayer, and defends them. 

# In whom does David take refuge?

David takes refuge in Yahweh. 

# What will the people say to David about his soul?

They will tell him to flee like a bird to the mountain. 

# How do the wicked prepare to attack the upright in heart?

They prepare their bows and make ready their arrows. 

# What is Yahweh doing in his holy temple?

His eyes are watching and examining the children of men. 

# Who does Yahweh examine?

He examines the righteous and the wicked 

# Who does Yahweh hate?

He hates those who love to do violence. 

# What does Yahweh do to the wicked?

He rains burning coals and brimstone upon them and pours out a scorching wind from his cup. 

# What does Yahweh think of righteousness?

He loves righteousness. 

# What will happen to the upright?

The upright will see Yahweh's face. 

# Why is David asking for Yahweh's help?

David is asking for Yahweh's help because the godly have disappeared and the faithful have vanished. 

# How does everyone speak to his neighbor?

Everyone says empty words to his neighbor, and speaks with flattering lips and a double heart. 

# What does David want Yahweh to do to the flattering lips?

David wants Yahweh to cut off all flatterings lips and every tongue declaring great things. 

# What flattering thing have some said?

Some have said, " With our tongues will we prevail. When our lips speak, who can be lord over us?" 

# What will Yahweh do for the poor and the needy?

Yahweh will arise and provide safety for which they long. 

# What are the words of Yahweh like?

Yahweh's words are pure words like silver purified in a furnace and refined seven times. 

# What does David ask Yahweh to do for godly people?

He asks Yahweh to forever keep and preserve them from this wicked generation. 

# What causes the wicked to walk on every side?

The wicked walk on every side when evil is exalted among the sons of men. 

# How does David ask Yahweh to respond to his prayer?

He asks Yahweh to look at him, answer him, and enlighten his eyes. 

# What does David fear will happen if Yahweh does not answer?

David fears he will sleep in death. 

# What does David not want his enemies to say about him?

He does not want them to say they have defeated him and prevailed over their adversary. 

# What will happen if David is defeated?

His enemies will rejoice when he is brought down. 

# In what has David trusted?

David has trusted in Yahweh's covenant faithfulness. 

# In what does David's heart rejoice?

His heart rejoices in Yahweh's salvation. 

# Why will David sing to Yahweh?

David will sing because Yahweh has treated him very generously. 

# What does a fool say in his heart?

A fool says, "There is no God." 

# Why does Yahweh looks down on the sons of mankind?

He looks down to see if there are any who understand, who seek after him. 

# Who has turned aside and become filthy?

Everyone has turned aside and all have become filthy. 

# Who does not call on Yahweh?

Those who commit iniquity and who eat up David's people as they eat bread, and do not call on Yahweh. 

# Why do those who do not call on Yahweh tremble with dread?

They tremble with dread because God is with the righteous assembly. 

# Who is the refuge of the poor person?

Yahweh is his refuge. 

# What does David want to come from Zion?

David wants the salvation of Israel to come from Zion. 

# When will Jacob rejoice and Israel be glad?

When Yahweh brings back his people from the captivity. 

# What kind of person may stay in Yahweh's tabernacle and live on his holy hill?

The person who walks blamelessly, does what is right, and speaks truth from his heart may stay in Yahweh's tabernacle and live on his holy hill. 

# What kind of person may stay in Yahweh's tabernacle and live on his holy hill?

The person who walks blamelessly, does what is right, and speaks truth from his heart may stay in Yahweh's tabernacle and live on his holy hill. 

# What does this blameless person not do with his tongue?

He does not slander with his tongue. 

# Who does this blameless person despise?

He despises the worthless person. 

# Who does this blameless person honor?

He honors those who fear Yahweh. 

# When this person swears to his own disadvantage, what does he not do?

He does not take back his promises. 

# When this blameless person lends money, what does he not do?

He does not charge interest. 

# What does this blameless person not take bribes to do?

He does not take bribes to testify against the innocent. 

# What will never happen to the blameless person who does these things?

He will never be shaken. 

# What does David ask God to do for him?

David wants God to protect him because he takes refuge in God. 

# What does David recognize about his relationship to Yahweh?

David recognizes that Yahweh is his Lord, and that David's goodness is nothing apart from Yahweh. 

# Who are the saints on the earth?

They are the noble people in whom David delights. 

# What will happen to those who seek out other gods?

Trouble will be increased to those who seek out other gods. 

# In what ways will David not worship other gods?

He will not pour out drink offerings of blood to their gods, or lift up their names with his lips. 

# What does David recognize that Yahweh does for him?

Yahweh holds David's destiny, gives him pleasant places, and a pleasing inheritance. 

# Why does David bless Yahweh?

David blesses Yahweh because Yahweh counsels him. 

# Why does David bless Yahweh?

David blesses Yahweh because Yahweh counsels him. 

# How does David's heart respond to Yahweh?

David's heart is glad, and will exalt in Yahweh. 

# What will Yahweh not allow to happen to the one who has covenant faithfulness?

Yahweh will not let him see the pit. 

# What benefits does David get from Yahweh?

Yahweh teaches David the path of life, gives him joy, and delights that comes from abiding in Yahweh's right hand forever. 

# What does David ask God to do for him?

David asks Yahweh to listen to his plea for justice, pay attention to his call for help, and give ear to his prayer. 

# What does David pray will come from Yahweh's presence?

David prays that his vindication will come from Yahweh's presence. 

# What will happen to David if Yahweh comes to him in the night?

Yahweh will purify him and not find any evil plans or transgressions in his mouth. 

# How has David kept himself from the ways of the lawless?

It is at the word of Yahweh's lips that David has kept himself from lawless ways. 

# Why does David call on God?

David calls on God because God answers him. 

# What does David ask God to show him?

He asks God to show his covenant faithfulness to him in a wonderful way. 

# Who does God save by his right hand?

He saves those who take refuge in him from their enemies. 

# How does David describe the way God protects him from the wicked enemies who assault him?

God will protect David like the apple of God's eye by hiding David under the shadow of God's wings. 

# How does David describe the way God protects him from the wicked enemies who assault him?

God will protect David like the apple of God's eye by hiding David under the shadow of God's wings. 

# How does David describe his enemies?

He says his enemies have no mercy on anyone, and their mouths speak with pride. 

# What have David's enemies done to him?

They have surrounded his steps and set their eyes to strike him to the ground. 

# What does David ask Yahweh to do to his enemies?

He asks Yahweh to arise, attack his enemies, and throw them down on their faces. 

# From whom is David asking Yahweh to rescue his him by his hand?

He is asking Yahweh to rescue him from men of this world whose prosperity is in this life alone. 

# How will Yahweh provide for his treasured ones?

Yahweh will fill their bellies with riches so that they will have many children to whom they will leave their wealth. 

# What does David expect to happen when he sees Yahweh's face in righteousness ?

He will be satisfied with a sight of Yahweh. 

# What emotion does David express toward Yahweh?

He says, "I love you." 

# What will happen when David calls on Yahweh?

David will be saved from his enemies. 

# Where was Yahweh when he heard David's voice?

Yahweh heard David's voice from his temple. 

# Why were the foundations of the mountains shaken? 

They were shaken because God was angry. 

# How did Yahweh come down from the heavens? 

He rode on a cherub and flew; he glided on the wings of the wind. 

# How did Yahweh scatter his enemies?

He shot his arrows and scattered them. 

# What exposed the foundations of the world?

Yahweh's battle cry and the blast of the breath of his nostrils. 

# Out of what did Yahweh pull David?

He pulled David out of the surging water. 

# Why did Yahweh save David?

Yahweh saved David because Yahweh was pleased with him. 

# What does Yahweh do to afflicted people?

He saves afflicted people. 

# What does Yahweh do to those with proud, uplifted eyes?

He brings down those with proud, uplifted eyes. 

# How does David describe Yahweh's way?

He says Yahweh's way is perfect. 

# What did David do to his enemies?

David pursued his enemies and caught them. 

# What happened when David's enemies called to Yahweh?

Yahweh did not answer them. 

# Over what has Yahweh made David the head?

Yahweh made David the head over nations. 

# From whom is David set free?

He is set free from his enemies. 

# To whom does Yahweh show his covenant loyalty?

He shows his covenant loyalty to his anointed one, to David and to his descendants forever. 

# What do the heavens declare and the skies make known?

The heavens declare God's glory and the skies make his handiwork known. 

# What does the speech that pours out reveal?

The speech that pours out reveals knowledge. 

# Where do the words and speech of the heavens and the skies go?

Their words go out over all the earth, to the end of the world. 

# What is the sun like?

The sun is like a bridegroom, and like a strong man. 

# What does the law of Yahweh do?

The law of Yahweh restores the soul. 

# What do the decrees of Yahweh do?

The decrees of Yahweh give wisdom to the inexperienced. 

# What do the instructions of Yahweh do?

They make the heart joyful. 

# What do the commands of Yahweh do?

They give insight to the eyes. 

# How do the righteous decrees of Yahweh compare to gold?

They are of greater value than gold, even much more than much find gold. 

# What do the righteous decrees of Yahweh do for Yahweh's servant?

By them his servant is warned, they cause him to obey and receive great reward. 

# From what does David ask to be cleansed?

He asks to be cleansed from hidden faults. 

# What happens when the servant does not let his arrogant sins rule over him?

He will be perfect and innocent from many transgressions. 

# What does David want to be acceptable in Yahweh's sight.

David wants the words of his mouth and the thoughts of his heart to be acceptable in Yahweh's sight. 

# From where does David want God to send help and support?

He asks that Yahweh send help from the sanctuary and support from Zion. 

# What does David want Yahweh to call to mind and to accept?

David asks that Yahweh call to mind all of the offerings and accept their burnt sacrifices. 

# In what does David say they will rejoice?

David says they will rejoice in Yahweh's salvation. 

# Who does David say that Yahweh will rescue?

David knows that Yahweh will rescue his anointed. 

# In what do other people trust?

Some trust in chariots and others in horses. 

# What does David and his people do in order to gain victory?

They call on Yahweh their God. 

# In what does the king rejoice?

He rejoices in Yahweh's strength and in the salvation Yahweh provides. 

# What has Yahweh done for the king?

Yahweh has given the king his heart's desire and has not held back the request of his lips. 

# What has Yahweh brought to the king and placed on his head?

He has brought the king rich blessings and placed a crown of purest gold on his head. 

# What did Yahweh give the king after the king asked for it? 

Yahweh gave the king life and long days forever and ever. 

# Why is the king's glory great?

His glory is great because of Yahweh's victory. 

# What has Yahweh bestowed upon the king?

Yahweh has bestowed splendor and majesty. 

# Why will the king not be moved?

He will not be moved because he trusts in Yahweh through the Most High's covenant faithfulness. 

# Who will the hand of Yahweh seize?

His hand will seize all the enemies who hate Yahweh. 

# What will Yahweh do to his enemies?

He will burn them up, and they will be consumed in his wrath. 

# What will Yahweh do to the offspring of his enemies?

He will destroy their offspring and their descendants. 

# Why will Yahweh destroy his enemies?

He will destroy them because they intended evil against him. 

# Why will the plot of Yahweh's enemies not succeed?

It will not succeed because Yahweh will turn them back and draw his bow against them. 

# Why will the plot of Yahweh's enemies not succeed?

It will not succeed because Yahweh will turn them back and draw his bow against them. 

# How will the people exalt Yahweh?

They will sing and praise his power. 

# What is David asking God?

David is asking why God has abandoned him, why he is so far from David. 

# What does David do in the daytime and at night?

David cries out in the daytime and at night David is not silent. 

# How does David refer to God?

David refers to God as Holy, sitting as king with the praises of Isreal. 

# What did David's ancestors do and how did God respond?

They trusted in God, he rescued them, and they were not disappointed. 

# What did David's ancestors do and how did God respond?

They trusted in God, he rescued them, and they were not disappointed. 

# How does David describe himself?

David says he is a worm and not a man, a disgrace to humanity and despised by the people. 

# What do the people that taunt and mock David say to him?

They say, "He trusts in Yahweh; let Yahweh rescue him." 

# How long has David trusted God?

David trusted Yahweh when he was on his mother's breasts and since he was in his mother's womb. 

# How long has David trusted God?

David trusted Yahweh when he was on his mother's breasts and since he was in his mother's womb. 

# What is David asking God to do for him?

He is asking God to not be far away from him because trouble is near and there is no one to help. 

# What is surrounding David like a roaring lion?

Many strong bulls of Bashan surround him with mouths wide open against him. 

# What is surrounding David like a roaring lion?

Many strong bulls of Bashan surround him with mouths wide open against him. 

# How does David describe himself?

He says he is being poured out like water, all his bones are dislocated, his heart is like wax, his strength has dried up, his tongue sticks to the roof of his mouth. 

# How does David describe himself?

He says he is being poured out like water, all his bones are dislocated, his heart is like wax, his strength has dried up, his tongue sticks to the roof of his mouth. 

# What has surrounded David and encircled him?

Dogs have surrounded him and a company of evildoers encircled him, having pierced his hands and feet. 

# What was done to the garments and the clothes?

The garments were divided and lots were cast for the clothes. 

# What does David request of Yahweh?

He requests Yahweh to not be far away. 

# From what does David want to be rescued and saved?

He wants his soul rescued from the sword, his precious life from the paws of the dogs, the horns of the wild oxen, and be saved from the lion's mouth. 

# From what does David want to be rescued and saved?

He wants his soul rescued from the sword, his precious life from the paws of the dogs, the horns of the wild oxen, and be saved from the lion's mouth. 

# What will David declare to his brothers and where will he praise Yahweh?

He will declare Yahweh's name to his brothers and praise him in the midst of the assembly. 

# Who should praise, honor, and stand in awe of Yahweh?

All who fear Yahweh, all descendants of Jacob, and all descendants of Israel should praise, honor, and stand in awe of him. 

# When did Yahweh hear the afflicted one?

He heard the afflicted one when he cried to him. 

# Where will David praise and fulfill his vows?

He will praise Yahweh in the great assembly and fulfill his vows before those who fear Yahweh. 

# Who will eat, be satisfied, and praise Yahweh?

The oppressed will eat, be satisifed and those who seek Yahweh will praise him. 

# What will all the peoples of the earth and what will the famiies of the nations do?

The peoples of the earth will remember and turn to Yahweh and all the families of the nations will bow down before him. 

# Over what does Yahweh rule?

Yahweh rules over the nations. 

# Who will bow before Yahweh?

All those who are descending into the dust, who cannot preserve their own souls, will bow before him. 

# What will future generations do?

They will come and tell to a people not yet born what he has done. 

# What will future generations do?

They will come and tell to a people not yet born what he has done. 

# Who is David's shepherd?

David's shepherd is Yahweh. 

# Where does Yahweh make David lie down?

Yahweh makes David lie down in green pastures. 

# Where does Yahweh lead David?

Yahweh leads David beside tranquil water. 

# What does Yahweh restore?

Yahweh restores David's soul. 

# Where does Yahweh guide David?

Yahweh guides David along right paths. 

# When David walks through a valley of darkest shadow, who is with him?

Yahweh is with David. 

# What does Yahweh prepare before David?

Yahweh prepares a table in the presence of David's enemies. 

# What does Yahweh annoint?

Yahweh annoints David's head with oil. 

# What will pursue David all the days of his life?

Goodness and covenant faithfulness will pursue David. 

# Where will David live all the days of his life?

David will live in the house of Yahweh for a very long time. 

# Who founded the earth?

Yahweh founded it upon the seas and established it on the rivers. 

# Who will ascend the mountain of Yahweh and stand in Yahweh's holy place?

Those who have clean hands and a pure heart; who have not lifted up their soul to what is false, and who have not sworn deceitfully will ascend Yahweh's mountain and stand in his holy place. 

# Who will ascend the mountain of Yahweh and stand in Yahweh's holy place?

Those who have clean hands and a pure heart; who have not lifted up their soul to what is false, and who have not sworn deceitfully will ascend Yahweh's mountain and stand in his holy place. 

# Who will receive a blessing from Yahweh?

The generation of those who seek him, those who seek the face of the God of Jacob, will receive a blessing. 

# Who will receive a blessing from Yahweh?

The generation of those who seek him, those who seek the face of the God of Jacob, will receive a blessing. 

# Why are the gates to be lifted up?

So that the King of glory may come in. 

# For what does David ask God?

David asks God to not let him be humiliated, and to not let his enemies rejoice over him. 

# What does David ask Yahweh to make known to him?

David requests Yahweh to make known to him Yahweh's ways. 

# What does David ask Yahweh to make known to him?

David requests Yahweh to make known to him Yahweh's ways. 

# What does David ask Yahweh to call to mind?

David asks Yahweh to call to mind his acts of compassion and of covenant faithfulness, but not to think about the sins of David's youth or his rebelliousness. 

# What does David ask Yahweh to call to mind?

David asks Yahweh to call to mind his acts of compassion and of covenant faithfulness, but not to think about the sins of David's youth or his rebelliousness. 

# What does Yahweh do because he is good and upright?

He teaches sinners the way, guides the humble with justice, and teaches the humble his way. 

# What does Yahweh do because he is good and upright?

He teaches sinners the way, guides the humble with justice, and teaches the humble his way. 

# From what are the paths of Yahweh made?

They are made from covenant faithfulness and trustworthiness. 

# Why should Yahweh pardon David's sin?

He should pardon David for the sake of Yahweh's name. 

# What will Yahweh do for the man who fears Yahweh?

The Lord will instruct him in the way he should choose. 

# What will Yahweh do for the man who fears Yahweh?

The Lord will instruct him in the way he should choose. 

# What does Yahweh do for those who honor him?

He gives them his friendship and makes his covenant known to them. 

# Why does David always keep his eyes on Yahweh?

Because Yahweh will free David's feet from the net. 

# When David is alone and afflicted, what does he request of Yahweh?

David asks Yahweh to turn toward him and have mercy on him. 

# When David's heart is troubled what does he ask of Yahweh?

David asks Yahweh to see his affliction and his toils, to forgive his sins, and to see his enemies who hate him and are cruel to him. 

# When David's heart is troubled what does he ask of Yahweh?

David asks Yahweh to see his affliction and his toils, to forgive his sins, and to see his enemies who hate him and are cruel to him. 

# When David's heart is troubled what does he ask of Yahweh?

David asks Yahweh to see his affliction and his toils, to forgive his sins, and to see his enemies who hate him and are cruel to him. 

# Why will David not be humiliated?

Because he takes refuge in Yahweh. 

# From what does David ask God to rescue Israel?

He asks God to rescue Israel from all of its troubles. 

# How does David say that he has walked?

David says he has walked with integrity and has trusted in Yahweh without wavering. 

# What does David ask Yahweh to examine and test?

He asks Yahweh to test the purity of his inner parts and heart. 

# What is before David's eyes?

Yahweh's covenant faithfulness is before David's eyes. 

# With whom does David not associate or mingle?

Davied does not associate with deceitful people or mingle with dishonest people. 

# What does David hate?

David hates the assembly of evildoers. 

# With whom does David not live?

He does not live with the wicked. 

# What does David do as he goes around Yahweh's altar?

He sings a loud song of praise and reports all of Yahweh's wonderful deeds. 

# What does David do as he goes around Yahweh's altar?

He sings a loud song of praise and reports all of Yahweh's wonderful deeds. 

# How does David feel about the house where Yahweh lives?

He loves the house where Yahweh lives. 

# What does David asking Yahweh not to do?

David asks Yahweh not to sweep his soul away with the sinners, or his life with bloodthirsty men. 

# How does David say that he will walk?

David says that he will walk in integrity. 

# Where does David's foot stand and where will he bless Yahweh?

His foot stands on level ground and he will bless Yahweh in the assemblies. 

# Why should David not fear anyone?

David should not fear anyone since Yahweh is his light, his salvation, and his life's refuge. 

# What happened when evildoers drew near to David?

His adversaries and enemies stumbled and fell. 

# In what situations will David not fear but rather remain confident?

His heart will not fear even though an army encamps against him and war rises up against him. 

# What has David asked of Yahweh?

David has asked that he may live in the house of Yahweh all the days of his life, to see the beauty of Yahweh, and to meditate in his temple. 

# What will Yahweh do for David in the day of trouble?

Yahweh will shelter him in his booth, hide him in the cover of his tent, and lift him high on a rock. 

# How will David offer worship to Yahweh?

David will offer sacrifices of joy, sing, and make songs to Yahweh. 

# What does David ask Yahweh to do?

David asks Yahweh to hear his voice, to have mercy on him, and to answer him. 

# What does David's heart say about Yahweh?

David's heart says, "Seek his face!" 

# What does David ask Yahweh not to do?

David asks Yahweh not to hide his face from him, not to strike his servant in anger, nor to forsake or abandon him. 

# In what situation will Yahweh take David in?

Yahweh will take David in even if his father and mother forsake him. 

# How does David ask Yahweh to do because of David's enemies?

David asks Yahweh to teach him Yahweh's ways and to lead him on a level path because of his enemies. 

# Why does David ask that Yahweh not give his soul to his enemies?

David asks that Yahweh not give his soul to his enemies because false witnesses have risen up against him, and they breathe out violence. 

# What did David believe that helped him?

He believed that he would see the goodness of Yahweh in the land of the living. 

# What does David encourage the people to do?

David encourages the people to wait for Yahweh, to be strong, and to let their heart be courageous. 

# To whom does David cry out?

David cries out to Yahweh, his rock. 

# What will happen to David if Yahweh does not respond to him?

David will join those who go down to the grave. 

# Who does David want to hear the sound of his pleading?

David wants Yahweh to hear the sound of his pleading. 

# What does David ask Yahweh not to do?

David asks Yahweh not to drag him away with the wicked. 

# What does David ask Yahweh to give the wicked?

David asks Yahweh to give them what their deeds deserve and to repay them for what their wickedness demands. 

# What does the wicked not understand?

The wicked does not understand the ways of Yahweh or the work of his hands. 

# What has Yahweh heard?

Yahweh has heard the sound of David's pleading. 

# Who is David's strength and shield?

Yahweh is David's strength and shield. 

# In whom does David's heart trust?

David's heart trusts in Yahweh and greatly rejoices. 

# Who is the strength of his people?

Yahweh is the strength of his people. 

# Who is the saving refuge of his annointed one?

Yahweh is the saving refuge of his annointed one. 

# Who does David want Yahweh to save and bless?

David wants Yahweh to save his people and bless his inheritance, 

# Who does David say should acknowledge Yahweh has glory and power?

David says the sons of the mighty should acknowledge Yahweh's glory and power. 

# What does the name of Yahweh deserve?

Yahweh's name deserves honor. 

# To what does David compares the voice of Yahweh?

He compares the voice of Yahweh to thunder. 

# What does Yahweh break in pieces?

Yahweh breaks in pieces the cedars of Lebanon. 

# What does Yahweh shake?

Yahweh shakes the wilderness of Kadesh. 

# What does everyone in Yahweh's temple say?

Everyone in his temple says, "Glory!" 

# How long will Yahweh sit as king?

Yahweh sits as king forever. 

# What two things does Yahweh give his people?

Yahweh gives strength to his people and blesses his people with peace. 

# Why does David exalt Yahweh?

He exalts Yahweh because Yahweh has raised David up and not allowed David's enemies to rejoice over him. 

# What did Yahweh do when David cried for help?

Yahweh healed David. 

# From where did Yahweh bring up David's soul?

Yahweh brought up David's soul from sheol. 

# What are the faithful told to do in remembrance of Yahweh's holiness?

The faithful are told to sing praise to Yahweh and to give him thanks. 

# How long does Yahweh's anger and favor last?

Yahweh's anger is only for a moment, but his favor is for a lifetime. 

# What happens after weeping comes for a night?

Joy comes in the morning. 

# What did David say in confidence?

David said, "I will never be shaken." 

# What happened to David when Yahweh hid his face?

When Yahweh hid his face, David was troubled. 

# What did David seek from the Lord?

David sought favor from the Lord. 

# What things is David asking Yahweh to do for him?

David is asking Yahweh to hear him, to have mercy on him, and be his helper. 

# What has Yahweh done for David?

Yahweh has turned David's mourning into dancing, removed his sackcloth and clothed him with gladness. 

# What will David's honored heart do?

David's heart will sing praise to Yahweh and not be silent. He will give thanks to Yahweh his God forever. 

# In whom does David take refuge?

David takes refuge in Yahweh. 

# What does David ask Yahweh to become for David?

He asks Yahweh to become his rock of refuge and a stronghold to save him. 

# What does David ask Yahweh to become for David?

He asks Yahweh to become his rock of refuge and a stronghold to save him. 

# Why does David ask God to lead and guide him?

David asks God to lead and guide him for Yahweh's name sake. 

# Why does David believe that Yahweh will pluck him out of the net his enemies have hidden for him?

Yahweh will pluck him out of the net because Yahweh is his refuge. 

# Into what does David entrust his spirit?

David entrusts his spirit into the hands of Yahweh. 

# Who does David hate?

He hates those who serve worthless idols. 

# Why will David be glad and rejoice in Yahweh's covenant faithfulness?

David will be glad and rejoice because Yahweh has seen his affliction and known the distress of his soul. 

# Where has Yahweh set David's feet?

Yahweh has set David's feet in a wide open place. 

# Why does David want Yahweh to have mercy upon him?

He wants Yahweh to have mercy upon him because he is in distress and his eyes grow weary with grief. 

# Why does David's strength fail and his bones waste away?

His strength fails and his bones waste away because of his sin. 

# How did people respond to David's situation?

People disdain him, his neighbors are appalled and horrified at his situation, and those who see him in the street run from him. 

# To what does David compare himself?

David says he is as forgotten as a dead man whom no thinks about, and that he is like a broken pot. 

# Why is David so troubled?

He has heard the whispering of many, terrifying news from every side as they plot together to take away his life. 

# From whom does David ask God to rescue him?

He asks God to rescue him from his enemies and from those who pursue him. 

# What does David ask God to do for his servant?

David asks God to make his face shine upon David, and to save him in Yahweh's covenant faithfulness. 

# What does David ask God to not let happen to David?

David asks Yahweh to not to let him be humiliated. 

# Why should lying lips be silenced?

They speak against the righteous defiantly with arrogance and contempt. 

# For whom is God's goodness stored up?

Yahweh's goodness is stored up for those who revere him. 

# From what does Yahweh hide those who revere him?

He hides them from the plots of men and from the violence of tongues. 

# Why is Yahweh to be blessed?

Yahweh showed David his marvelous covenant faithfulness when David was in a beseiged city. 

# What did Yahweh do for David even though David said that he was cut off from God's eyes?

Yahweh heard his plea for help when David cried to him. 

# What does Yahweh do for his faithful followers?

Yahweh protects the faithful but pays back the arrogant in full. 

# How advice does David give to those who trust in Yahweh?

He tells them to be strong and confident. 

# How does Yahweh bless people?

Yahweh blesses people by forgiving their transgression and covering their sin. 

# What happened to David when he remained silent?

His bones wasted away and he groaned all day long. God's hand was heavy on David and his strenghth withered. 

# What happened to David when he remained silent?

His bones wasted away and he groaned all day long. God's hand was heavy on David and his strenghth withered. 

# What did God do when David acknowledged his sin and no longer hid his iniquity?

God forgave the guilt of David's sin. 

# What should godly people do?

They should pray to Yahweh at a time of great distress. 

# What will happen to the godly who pray to Yahweh at a time of great distress?

When the surging waters overflow, they will not reach those people. 

# With what does God surround David?

God surrounds him with the songs of victory. 

# What will happen to the one who trusts in Yahweh?

Yahweh's covenant faithfulness will surrounding him. 

# What should the righteous and the upright in heart do for Yahweh?

The upright in heart should rejoice and shout for joy. 

# In whom does the writer say the righteous should rejoice?

The righteous should rejoice in Yahweh. 

# With what instrument does the writer say to give thanks to Yahweh?

The writer says to give thanks to Yahweh with the harp. 

# How does the writer describe Yahweh's word and actions?

Yahweh's word is upright and everything he does is fair. 

# What does Yahweh love?

Yahweh loves righteousness and justice. 

# What was made by the word of Yahweh?

The heavens were made by the word of Yahweh. 

# What was made by the breath of Yahweh's mouth?

All the stars were made by the breath of Yahweh's mouth. 

# What does the writer say Yahweh does to the waters of the sea?

He gathers the waters of the sea together like a heap. 

# What does the writer say all the inhabitants of the world should do?

All the inhabitants of the world should stand in awe of Yahweh. 

# How long will Yahweh's plans stand?

The plans of Yahweh stand forever, the plans of his heart for all generations. 

# On whom does Yahweh look down from where he lives?

Yahweh looks down on all the people, on all who live on the earth. 

# On whom is Yahweh's eye?

Yahweh's eye is on those who fear him. 

# Why should our hearts rejoice in Yahweh?

Our hearts should rejoice in him, for we trust in his holy name. 

# How often will David praise Yahweh?

David will praise Yahweh at all times. 

# Who does David want to hear when he praises Yahweh?

David wants the oppressed to hear it and rejoice. 

# What is David asking people to do with him?

David is asking them to praise Yahweh and lift up his name together. 

# What happened when David sought Yahweh?

Yahweh answered David and gave him victory over all his fears. 

# What happens to those who look to Yahweh?

They are radiant and their faces are not ashamed. 

# What did Yahweh do when he heard this oppressed man cry?

Yahweh saved him from all his troubles. 

# What does the angel of Yahweh do when he camps around those who fear him?

The angel of Yahweh rescues them. 

# Who is the man who is blessed?

The man is blessed who takes refuge in Yahweh. 

# What to Yahweh's chosen people who fear him?

There is no lack for those who fear Yahweh. 

# What does David say about those who seek Yahweh?

Those who seek Yahweh will not lack anything good. 

# What does David say to the children?

David says, "Come, listen and I will teach you the fear of Yahweh." 

# What does David say a man who desire life should do?

David says he should keep from speaking evil, keep from speaking lies, turn from evil, do good and seek peace and promote it. 

# What does David say a man who desire life should do?

David says he should keep from speaking evil, keep from speaking lies, turn from evil, do good and seek peace and promote it. 

# How does Yahweh respond to the cry of the righteous?

His eyes are on the righteous and his ears are directed toward their cry. 

# What will Yahweh do to the evildoers, whom his is against?

He will wipe out their memory from the earth. 

# What does Yahweh do when the righteous cry out?

He hears and rescues them from all their troubles. 

# To Whom is Yahweh near?

He is near the brokenhearted. 

# Who does Yahweh save?

Yahweh saves those with a crushed spirit. 

# What happens to the righteous who have many troubles?

Yahweh gives him victory over them all and protects all his bones. 

# What happens to the righteous who have many troubles?

Yahweh gives him victory over them all and protects all his bones. 

# What will happen to the wicked?

Evil will kill the wicked. 

# What will happen to those who hate the righteous?

They will be condemned. 

# What does Yahweh do for his servants who take refuge in him?

He redeems their souls and they will not be condemned. 

# What does David ask Yahweh to do for him?

David asks Yahweh to work against those who work against him, and fight against those who fight against him. 

# What weapons does David ask Yahweh to use to help him?

He asks Yahweh to use his small and large shield, his spear, and his battle axe. 

# What weapons does David ask Yahweh to use to help him?

He asks Yahweh to use his small and large shield, his spear, and his battle axe. 

# What does David want to happen to those who plan to harm him?

David wants them to be turned back and confounded. 

# Who does David want to drive away his enemies?

He wants the angel of Yahweh to drive them away. 

# What did David's enemies do without cause?

They set their net and dug a pit for David. 

# What does David want to happen to his enemies?

David wants destruction to overtake them by surprise, for them to be caught in their own nets, and for them to fall to their destruction. 

# In what will David rejoice?

He will rejoice in Yahweh's salvation. 

# Why is David sorrowful?

He is sorrowful because unrighteous witnesses rise up to accuse him falsely, and repay him evil for good. 

# Why is David sorrowful?

He is sorrowful because unrighteous witnesses rise up to accuse him falsely, and repay him evil for good. 

# How did David respond to his enemies' troubles?

David wore sackcloth, fasted for them, went about in grief and bent down in mourning for them. 

# How did David respond to his enemies' troubles?

David wore sackcloth, fasted for them, went about in grief and bent down in mourning for them. 

# How did the enemies respond to David's troubles?

They rejoiced, gathered against him, tore at him, taunted him, and gnashed at him with their teeth. 

# How did the enemies respond to David's troubles?

They rejoiced, gathered against him, tore at him, taunted him, and gnashed at him with their teeth. 

# When will David thank Yahweh in the assembly?

He will thank Yahweh when his soul is rescued from their destructive attacks. 

# When will David thank Yahweh in the assembly?

He will thank Yahweh when his soul is rescued from their destructive attacks. 

# What do David's enemies do instead of speaking peace?

They devise deceitful words against those who live in peace. 

# What does David want Yahweh to do since he has seen David's troubles?

He wants Yahweh to not be silent, to not be far away, and to arouse and awake to his defense. 

# What does David want Yahweh to do since he has seen David's troubles?

He wants Yahweh to not be silent, to not be far away, and to arouse and awake to his defense. 

# Why does David say Yahweh should defend him?

He says Yahweh should defend him because of Yahweh's righteousness. 

# How does sin speak in the heart of the wicked man?

Sin speaks like an oracle in the heart of the wicked man. 

# How does the wicked man comfort himself?

He thinks that his sin will not be discovered and be hated. 

# What are the wicked man's words like?

His words are sinful and deceitful. 

# What does the wicked man not want to be?

He does not want to be wise and to do good. 

# What does the wicked man do while he lies in bed?

He plans ways to sin while he lies in bed. 

# What reaches to the heavens and to the clouds?

Yahweh's covenant faithfulness reached to the heavens, and his loyalty reaches to the clouds. 

# What is Yahweh's justice like?

His justice is like the highest mountains and the deepest sea. 

# What does Yahweh preserve?

Yahweh preserves both mankind and the animals. 

# Who takes refuge under the shadow of God's wings?

Humanity takes refuge under the shadow of God's wings. 

# What will abundantly satisfy humanity?

The richness of the food of God's house will satisfy humanity. 

# To whom does David ask God to extend his covenant faithfulness?

David asks God to extend God's covenant faithfulness fully to those who know God. 

# What does David ask God not to let happen?

David asks God not to let the foot of the arrogant man come near him, and the hand of the wicked to drive him away. 

# What will happen to the evildoers who have fallen?

They are knocked down and not able to get up. 

# Why does David say to not be irritated because of evildoers?

He says to not be irritated because of evildoers because they will soon dry up as the grass and wither as the green plants. 

# Why does David say to not be irritated because of evildoers?

He says to not be irritated because of evildoers because they will soon dry up as the grass and wither as the green plants. 

# Why does David say to delight in Yahweh?

He says to delight in Yahweh so he will give you the desires of your heart. 

# Why does David say to trust in Yahweh?

He says to trust in Yahweh so that he will act on your behalf, display your justice like the daylight, and your innocence like the day at noon. 

# Why does David say to trust in Yahweh?

He says to trust in Yahweh so that he will act on your behalf, display your justice like the daylight, and your innocence like the day at noon. 

# What does David say we should do before Yahweh?

He says to be still before him and wait patiently for him, and to not worry if someone tries to make his evil ways succeed. 

# Why does David say to not be angry and frustrated or to worry about evildoers?

They will be cut off and disappear, but those who wait for Yahweh will inherit the land. 

# Why does David say to not be angry and frustrated or to worry about evildoers?

They will be cut off and disappear, but those who wait for Yahweh will inherit the land. 

# Why does David say to not be angry and frustrated or to worry about evildoers?

They will be cut off and disappear, but those who wait for Yahweh will inherit the land. 

# What will happen to the meek?

They will inherit the land and delight in great prosperity. 

# What will happen to the wicked who have tried to kill those who are upright?

The swords of the wicked will pierce their own hearts and their bows will be broken. 

# What will happen to the wicked who have tried to kill those who are upright?

The swords of the wicked will pierce their own hearts and their bows will be broken. 

# Why is the little that the righteous have better than the abundance of many wicked people?

The little that the righteous have is better because the arms of the wicked people will be broken, but Yahweh will support the righteous people. 

# Why is the little that the righteous have better than the abundance of many wicked people?

The little that the righteous have is better because the arms of the wicked people will be broken, but Yahweh will support the righteous people. 

# How will Yahweh provide for the blameless?

The blameless will not be ashamed when times are bad, they will have enough to eat, and their heritage will be forever. 

# How will Yahweh provide for the blameless?

The blameless will not be ashamed when times are bad, they will have enough to eat, and their heritage will be forever. 

# What will happen to Yahweh's enemies?

His enemies will be like the glory of the pastures which will be consumed and disappear in the smoke. 

# What is the benefit of having Yahweh establish a man's steps?

Even though he stumbles, he will not fall down for Yahweh is holding him with his hand. 

# What is the benefit of having Yahweh establish a man's steps?

Even though he stumbles, he will not fall down for Yahweh is holding him with his hand. 

# What has David not seen happen to the righteous person?

He has not seen that the righteous person abandoned or his children begging for bread. 

# How does the righteous person act?

He is gracious all the day long and lends. 

# What should people do to be safe forever?

They should turn away from evil and do what is right. 

# What will the righteous inherit?

They will inherit the land and live there forever. 

# What does the mouth of the righteous person speak?

The mouth of the righteous person speaks wisdom and increases justice. 

# What will happen to the righteous person whom the wicked person seeks to kill?

Yahweh will not abandon him into the wicked person's hand nor condemn him when he is judged. 

# What will happen to the righteous person whom the wicked person seeks to kill?

Yahweh will not abandon him into the wicked person's hand nor condemn him when he is judged. 

# What will happen to those who wait for Yahweh?

Yahweh will raise them up to possess the land. 

# What will happen to the wicked and terrifying person?

He will spread out like a green tree in its native soil, but later he will not be found. 

# What will happen to the wicked and terrifying person?

He will spread out like a green tree in its native soil, but later he will not be found. 

# What does Yahweh do for the righteous?

Yahweh protects them in time of trouble, and helps and rescues them. 

# What does Yahweh do for the righteous?

Yahweh protects them in time of trouble, and helps and rescues them. 

# What does David ask Yahweh not to do in his anger?

He asks Yahweh not to rebuke him in his anger, or punish him in his wrath. 

# Why does David say, "There is no health in my bones?"

He says there is no health in his bones because of his sin. 

# What has overwhelmed David?

His iniquities have overwhelmed him. 

# What does David do all day long?

He goes about mourning all day long. 

# With what is David overcome?

He is overcome with shame. 

# What does David say the Lord understands?

He says the Lord understands his heart's deepest yearnings. 

# Why do David's friends and companions shun him?

David's friends and companions shun him because of his condition. 

# What does David fear his enemies will do if his foot slips?

If David's foot slips, his enemies will do terrible things to him. 

# How do his enemies repay the good he has done?

They repay David evil for good and they hurl accusations at him. 

# What names does David use when he asks Yahweh for help?

He calls him, "Yahweh", "God", "Lord", and "my salvation." 

# What names does David use when he asks Yahweh for help?

He calls him, "Yahweh", "God", "Lord", and "my salvation." 

# What did David decide he will do?

David decided to watch what he says and he to muzzle his mouth while in the presence of an evil man. 

# What happened when David kept silent and kept back his words from saying anything good?

David's pain grew worse and his heart became hot like a fire. 

# What happened when David kept silent and kept back his words from saying anything good?

David's pain grew worse and his heart became hot like a fire. 

# What does David want to know about his life?

David wants to know when will his life end, the extent of his days, and how transient he is. 

# What does David say his life is like before Yahweh?

David's lifetime is like nothing before Yahweh. 

# What does everyone hurry about to do?

Everyone who hurries about to accumulate riches. 

# What is David's only hope?

The Lord is David's only hope. 

# What victory does David ask Yahweh to give him?

David ask Yahweh to give him victory over all his sins. 

# Of what does David not want to be the object?

David does not want to be the object of insults of fools. 

# How does David respond to what the Lord did?

David is silent and does not open his mouth. 

# By what is David overwhelmed?

David is overwhelmed by the blow of the Lord's hand. 

# What happens when the Lord disciplines people for sin?

The Lord consumes their strength like a moth and they are nothing but vapor. 

# Why does David ask Yahweh to listen to his weeping and to not be deaf to him?

He asks Yahweh to listen because David is like a foreigner with him and a refugee like all his ancestors were. 

# What does David ask Yahweh to do before David dies?

He asks Yahweh to turn his gaze from David so that David may smile again. 

# What did Yahweh do after David waited patiently for him?

Yahweh listened to David and heard his cry. 

# What else did Yahweh do for David?

Yahweh brought David out of a horrible pit, out of the miry clay, and set his feet on a rock. 

# What will many do because God has put a new song of praise in David's mouth?

Many will see it and honor Yahweh and trust in Yahweh. 

# Who is blessed?

The man who makes Yahweh his trust and does not honor the proud or those who turn away from God is blessed. 

# How does David describe God's deeds and thoughts?

God's wonderful deeds are many and his thoughts about us cannot be numbered. 

# What is written about David in the scroll of the document?

It is written that he delights to do God's will and that God's laws are in his heart. 

# What is written about David in the scroll of the document?

It is written that he delights to do God's will and that God's laws are in his heart. 

# What has David proclaimed in the great assembly?

He has proclaimed good news of God's righteousness in the great assembly. 

# What has David not concealed?

He has not concealed God's righteousness in his heart nor God's covenent faithfulness nor trustworthiness from the great assembly. 

# What does David pray that Yahweh will do for him?

David prays that Yahweh not keep back his acts of mercy from David but rather let Yahweh's covenent faithfulness and his trustworthiness always preserve David. 

# Why is David afraid?

He is afraid because troubles that cannot be numbered surround him and his iniquities have overtaken him. His heart has failed him. 

# What does he pray that Yahweh will be pleased to do?

He prays that Yahweh will be pleased to rescue him. 

# What does David pray will happen to those who pursue his life?

He prays that they be put to shame and confused, turned back and brought to dishonor. 

# What does David pray for those who seek God and love his salvation?

He prays that they rejoice and be glad in God, and that they say continually, "May Yahweh be praised." 

# How does David describe the Lord?

The Lord thinks about him, is his help, and comes to David's rescue. 

# Who does David say is the one who is blessed?

The one who is concerned for the weak is blessed. 

# What will Yahweh do for the blessed person?

Yahweh will rescue him, preserve him and keep him alive, and he will be blessed on the earth. 

# What will Yahweh do for the blessed person?

Yahweh will rescue him, preserve him and keep him alive, and he will be blessed on the earth. 

# What will Yahweh not do to the blessed person?

Yahweh will not turn him over to the will of his enemies. 

# What will Yahweh do for the blessed person on the bed of suffering?

Yahweh will support him on the bed of suffering and make his bed of sickness into a bed of healing. 

# Why did David ask Yahweh to have mercy on him?

He asked Yahweh to have mercy on him because he had sinned against Yahweh. 

# What evil do his enemies speak against David?

They ask when he will die and and his name perish. 

# What does David's enemy say to him?

His enemy says worthless things. 

# What do those who hate David whisper and hope for?

Those who hate David whisper together against him and hope for his hurt. 

# What has David's own close friend in whom he trusted done?

His own close friend has lifted his heel against him. 

# What has Yahweh done for David?

Yahweh had mercy on him and raised him up so that he may pay back the ones who hate him. 

# How does David know that Yahweh delights in him?

David knows this because his enemy does not triumph over him. 

# How does Yahweh support David?

Yahweh supports him in his integrity and will keep him before Yahweh's face forever. 

# When may Yahweh be praised?

Yahweh may be praised from everlasting to everlasting. 

# How does the writer's soul pant after God?

His soul pants after God as the deer pants after streams of water. 

# What does the writer's say about his soul?

His soul thirsts for God, for the living God. 

# What have the writer's tears become for him?

His tears have been his food day and night. 

# What things does the writer call to mind?

He calls to mind how he went with the throng and led them to the house of God with the voice of joy and praise. 

# What does the writer tell his soul to do?

He tells his soul to hope in God, for he will yet praise God for the help of God's presence. 

# What has gone over the writer?

All God's waves and billows have gone over the writer. 

# What will Yahweh command in the daytime?

Yahweh will command his covenant faithfulness in the daytime. 

# What will happen in the night?

In the night God's song will be with the writer, a prayer to the God of his life. 

# What will the writer ask God, his rock?

He will ask why God has forgotten him, and why he must mourn because of the oppression of the enemy. 

# To what does the writer compare the rebukes of his adversaries?

He says they are like wounds that shatter his bones. 

# What will the writer expect God to do?

He will confidently expect God to bless him. 

# What does the writer ask God to do for him?

He asks God to judge him and to plead his cause against an ungodly nation. 

# Why should God judge him and plead his cause?

God should judge him because God is the God of his strength. 

# What does the writer ask God to let his light and truth do?

He asks God to let his light and truth lead him and bring him to God's holy hill and tabernacles. 

# Where will the writer go when God bring him to the tabernacle?

He will go to the altar of God. 

# What will the writer do on his harp?

He will praise God on his harp. 

# Why should the writer's soul not be discouraged nor disquieted within himself?

His soul should hope in God for he will yet praise God, who is his help and his God. 

# What have the writers heard with their ears?

They have heard what work God did in their days, in the days of old. 

# What did God do with his hand?

God drove out the nations with his hand and planted the people of Israel. 

# How did the Israelites obtain the land and save themselves?

They did not obtain the land for their possession by their own sword or by their own arm, but by God's right arm because he was favorable to them. 

# What will the Israelites do through God?

They will push down their adversaries and through God's name tread them under. 

# In what will the writer not trust?

He will not trust in his bow, neither will his sword save him. 

# From what has God saved them?

God has saved them from their adversaries and put to shame those who hate them. 

# What has God now done?

God has now thrown them off and brought them dishonor, and does not go out with their armies. 

# What does God make the Israelites do?

God makes them turn back from the adversary. 

# What do those who hate the Israelites do?

Those who hate them take spoil for themselves. 

# What has God made the Israelites like?

God has made them like sheep destined for food and has scattered them among the nations. 

# What does God make the Israelites to their neighbors?

God makes them a rebuke to their neighbors, a scoffing and a derision to those who are around them. 

# Why is the writer's dishonor before him all the day long?

His dishonor is before him, and the shame of his face has covered him because of the voice of him who rebukes and insults, because of the enemy and the avenger. 

# What have the Israelites not done?

They have not forgotten God nor dealt falsely with God's covenant. 

# What have the Israelites' heart and steps not done?

Their heart has not turned back nor have their steps gone from God's way. 

# What has God done anyway?

God has severely broken them in the place of jackals and covered them with the shadow of death. 

# What would God surely search out?

God would search out whether they have forgotten the name of their God or spread out their hands to a strange god. 

# What would God surely search out?

God would search out whether they have forgotten the name of their God or spread out their hands to a strange god. 

# What are the Israelites considered to be for God's sake?

They are consiered to be sheep for the slaughter. 

# What have the Israelites' souls done?

Their souls have melted away into the dust and their bodies cling to the earth. 

# What does the writer pray that God would do?

He prays that God might rise up for their help and redeem them for the sake of God's covenant faithfulness. 

# What will the writer read aloud?

He will read aloud the words he has composed about the king. 

# How does the writer describe the king?

The king is fairer than the children of men, grace is poured onto his lips, and God has blessed him forever. 

# Why should the king ride on triumphantly?

The king should ride on triumphantly because of trustworthiness, meekness, and righteousness. 

# How are the king's arrows described?

His arrows are sharp and in the hearts of the king's enemies. 

# How is God's throne and a scepter of justice described?

His throne is forever and ever, and a scepter of justice is the scepter of God's kingdom. 

# What has the king loved and hated?

He has loved righteousness and hated wickedness. 

# Of what do all of the king's garments smell?

All of his garments smell of myrhh, aloes, and cassia. 

# Where are kings' daughters and the queen?

Kings' daughters are among God's honorable women and at God's right hand stands the queen clothed in gold of Ophir. 

# What will the rich do?

The rich among the people will beg for a favor. 

# Where will the royal daughter be led?

She will be led to the king in embroidered dress. 

# How and where will the virgins be led?

They will be led by gladness and rejoicing; they will enter into the king's palace. 

# Who will be in the place of the king's fathers?

In the place of your fathers will be your children, whom you will make princes in all the earth. 

# What will be made of the king's name?

It will be a name to be remembered in all generations. 

# How does the writer describe God?

God is our refuge and strength, a very present help in trouble. 

# What will the Israelites not do, even though the earth should change and the mountains should be shaken into the heart of the seas?

Therefore, they will not fear. 

# What makes the city of God happy?

There is a river, the streams of which make the city happy. 

# What will the city of God not do?

The city will not be moved. 

# What happened to the earth when God lifted up his voice after the nations raged and the kingdoms were shaken?

The earth melted. 

# Where and what is Yahweh of hosts, the God of Jacob?

Yahweh of hosts is with Israel, and the God of Jacob is their refuge. 

# What does Yahweh do to wars?

He makes wars cease to the ends of the earth, and he breaks the bow, cuts the spear into pieces, and burns up the shields. 

# What does God tell the people to do?

Be quiet and know that he is God. 

# What will happen to God among the nations?

He will be exalted among the nations and on the earth. 

# What is the God of Jacob for Israel?

He is their refuge. 

# Why should everyone clap their hands and shout to God with the sound of triumph?

They should clap and shout because Yahweh Most High is terrifying and a great King over all the earth. 

# Why should everyone clap their hands and shout to God with the sound of triumph?

They should clap and shout because Yahweh Most High is terrifying and a great King over all the earth. 

# What does Yahweh do to peoples and nations?

He subdues peoples under the Israelites and the nations under their feet. 

# How has God gone up?

God has gone up with a shout and the sound of a trumpet. 

# Why should everyone sing praises to God?

They should sing praises because God is the King over all the earth. 

# Why should everyone sing praises to God?

They should sing praises because God is the King over all the earth. 

# Where does God reign?

God reigns over the nations. 

# Where does God sit?

God sits on his holy throne. 

# Where have the princes of the peoples gathered together?

They have gathered together to the people of the God of Abraham. 

# Why have the princes gathered to the people of Abraham?

They have gathered to the people of Abraham because he is greatly exalted. 

# How does the writer describe Yahweh?

Great is Yahweh and greatly to be praised. 

# How is Mount Zion described?

Mount Zion is beautiful in elevation, the joy of the whole earth. 

# How has God made himself known?

God has made himself known as a refuge. 

# What happened when the kings assembled themselves together and saw Mount Zion?

They were amazed, dismayed, and hurried away; trembling took hold of them there. 

# What happened when the kings assembled themselves together and saw Mount Zion?

They were amazed, dismayed, and hurried away; trembling took hold of them there. 

# What happened when the kings assembled themselves together and saw Mount Zion?

They were amazed, dismayed, and hurried away; trembling took hold of them there. 

# What will God do for the city of Yahweh of hosts?

God will establish it forever. 

# What have the Israelites thought about in the middle of God's temple?

They have thought about God's covenent faithfulness. 

# How does the writer describe God's right hand?

His right hand is full of righteousness. 

# Why should Mount Zion be glad and the daughters of Judah rejoice?

It should be glad and they should rejoice because of God's righteous decrees. 

# Why should the Israelites walk around Mount Zion, count her towers, and look at her palaces?

They should do these things so that they may tell it to the next generation. 

# What will God be for the Israelites?

He will be their guide until death. 

# Who does the writer tell to hear and to give ear?

He tells to all the peoples to give hear, and all the inhabitants of the world, both low and high, rich and poor together, to give ear. 

# Who does the writer tell to hear and to give ear?

He tells to all the peoples to give hear, and all the inhabitants of the world, both low and high, rich and poor together, to give ear. 

# What will the writer's mouth speak?

His mouth will speak wisdom. 

# What will be the meditation of the writer's heart?

The meditation of his heart will be of understanding. 

# To what will the writer incline his ear and how will he begin it?

He will incline his ear to a parable which he will begin with the harp. 

# What can those who trust in their wealth not do?

None of them can by any means redeem his brother nor give God a ransom for him. 

# What can those who trust in their wealth not do?

None of them can by any means redeem his brother nor give God a ransom for him. 

# How does the writer describe the redemption of one's life?

The redemption of one's life is costly and always costs too much. 

# Who can live forever?

No one can live forever so that his body should not decay. 

# What happens to wise men, the fool, and the brute alike?

Wise men die; the fool and the brute alike perish and leave their wealth to others. 

# What happens to mankind?

Man, having wealth, does not remain alive. 

# Who will be mankind's shepherd?

Death will be their shepherd. 

# What will happen to mankind in the morning?

The upright will have power over them in the morning. 

# What will God do for the writer?

God will redeem his soul from the power of sheol; he will receive him. 

# When does the writer say not to be afraid?

People should not be afraid when one becomes rich, when the power of his house increases. 

# Why does the writer say not to be afraid?

He says not to be afraid because when the rich one dies, he will take nothing away, and his power will not descend with him. 

# Why does the writer say not to be afraid?

He says not to be afraid because when the rich one dies, he will take nothing away, and his power will not descend with him. 

# When do men praise other people?

Men praise other people who live for themselves. 

# To whom will the rich go?

He will go to the generation of his fathers. 

# What will the rich and his fathers not see?

They will never see the light again. 

# What is a person who has wealth but no understanding like?

He is like the beasts, which perish. 

# What three names of God does Asaph use to refer to God?

He uses the names "Mighty One", "God", and "Yahweh". 

# Why does God call to the heavens above and to the earth?

He calls to the heavens above and to the earth so that he may judge his people. 

# What does God tell his people that he will not reprove?

God tells them that he will not reprove them for their sacrifices. 

# Why does God say that he will take no bull or goat from his people?

God says that every beast of the forest is his, and the cattle on a thousand hills. 

# What does Asaph say everyone should offer and to pay to God?

Everyone should offer to God the sacrifice of thanksgiving and pay their vows to the Most High. 

# What does God say the wicked hate and throw away?

God says that the wicked hate instruction and throw away his words. 

# What does God say that the wicked think about him when God keeps silent?

They thought that he was someone just like them. 

# Who will help the wicked when God tears them in pieces?

There will be no one to come to help them. 

# To whom will God show his salvation?

God will show his salvation to whoever offers a sacrifice of thanksgiving and plans his path in the right way. 

# Why does David say that God should have mercy on him?

He says God should have mercy because of his covenant faithfulness. 

# Against whom does David say he has sinned?

He says he has sinned against God, and only against God. 

# When does David say that his sin began?

He says he was born in iniquity, and as soon as his mother conceived him, he was in sin. 

# What does David ask God to do so that he may be purified?

He asks God to purify him with hyssop so he will be clean, and to wash him so he will be whiter than snow. 

# What does David ask God to create and renew in him?

He asks God to create in him a clean heart, and to renew a right spirit within him. 

# What does David ask God to not do to him?

He asks God not to drive him away from his presence, and to not take his holy Spirit from him. 

# What sin does David ask God to forgive?

He asks God to forgive him for shedding blood. 

# What are the sacrifices of God?

The sacrifices of God are a broken spirit. He will not despise a broken and a contrite heart." 

# What comes from God every day?

The covenant faithfulness of God comes every day. 

# What does the mighty man love more than good?

He loves evil more than good. 

# What kind of words does the mighty man love?

He loves all words that devour others. 

# What will God do to the mighty man?

God will destroy him forever. 

# In what did the man trust?

He trusted in the abundance of his riches. 

# In what will David place his own trust?

He will trust in the covenant faithfulness of God forever and ever. 

# What does the fool say in his heart?

He says, "There is no God." 

# When God looks down on the sons of mankind, does he find anyone who understands and seeks after him?

No, they have all become filthy, and there is no one who does good. 

# Why will people who do not call on God will be put to shame?

They will be put to shame because God has rejected them. 

# From where did David hope that salvation for Israel would come?

He hoped that the salvation of Israel would come from Zion! 

# By what did David ask God to save him?

He asked God to save him by God's name. 

# Who has risen up and sought David's soul?

Strangers have risen up against him, and pitiless men have sought after his soul. 

# Who sustains David's soul?

The Lord is the one who sustains his soul. 

# What will God repay David's enemies?

He will repay the evil to them. 

# Why will David give thanks to the name of Yahweh?

He will give thanks to his name for it is good. 

# How has David looked on his enemies?

His eye has looked in triumph on his enemies. 

# Why does David have no rest in his troubles?

He has no rest because of the voice of his enemies, and because of the oppression of the wicked. 

# What kind of terrors have fallen on David?

The terrors of death have fallen on him. 

# Why does David with that he had wings like a dove?

If he had wings like a dove, he could fly away and be at rest. 

# What does David ask the Lord to do to David's enemies?

He asks the Lord to destroy them, and to confuse their languages. 

# What is found in the middle of the city?

Iniquity, mischief and wickedness are in the middle of the city. 

# What is found in the middle of the city?

Iniquity, mischief and wickedness are in the middle of the city. 

# Who rebuked David and raised himself up against David?

David's companion and close friend rebuked David and raised himself up against him. 

# Who rebuked David and raised himself up against David?

David's companion and close friend rebuked David and raised himself up against him. 

# What does David want to come suddenly upon his enemies?

He want death to come suddenly on them, and for them to go down alive to sheol. 

# What does David do at evening, morning and noonday?

He complains and moans to God. 

# Why will God hear and respond to David's enemies?

He will hear and respond because they do not change, and they do not fear God. 

# What did David's friend to do the covenant that he made?

He has not respected the covenant that he made. 

# To where will God bring the wicked down?

He will bring the wicked down into the pit of destruction. 

# Why does David ask God to be merciful to him?

He asks God to be merciful because someone wishes to swallow him up. 

# When do David's enemies wish to swallow him up?

David's enemies wish to swallow him up all the day long. 

# David vows to do what when he is afraid?

When David is afraid, he will put his trust in God. 

# What is the result of David's trust in God?

David put his trust in God so he will not be afraid. 

# What do David's enemies do with David's words?

They twist David's words. 

# What are David's enemies thoughts toward David?

All their thoughts are against David for evil. 

# How does David ask God to bring down David's enemies?

David asks God to bring them down in God's anger. 

# What does David ask God to do what with his tears?

David asks God to put David's tears in God's bottle. 

# When will David's enemies turn back?

David's enemies will turn back on the day that he calls to God. 

# What does David vow to give to God?

David vows that he will give thank offerings to God. 

# Where does David walk before God?

David walks before God in the light of the living. 

# Why does David ask God to be merciful to him?

He asks God to be merciful to him, for his soul takes refuge in God. 

# For how long does David take refuge in God?

David takes refuge in God until these troubles are over. 

# What does David say God does for him?

David says God does all things for him. 

# What does David say God will send out to him?

David says that God will send out to him God's covenant faithfulness and his trustworthiness. 

# Among whom does David lie?

He lies among those who are set on fire. 

# Where does David ask God to let his glory be?

David asked God to let God's glory be above all the earth. 

# What happened to those who dug a pit in front of David?

They themselves have fallen into the middle of it. 

# What musical instruments does David call to wake up?

David calls to the lute and harp to wake up. 

# Where will David give thanks to the Lord?

David will give thanks to the Lord among the peoples. 

# Where will David sing praise to the Lord?

David will sing praises to the Lord among the nations. 

# Where does David asks for God's glory to be exalted?

David asks for God's glory to be exalted over all the earth. 

# What does David say the sons of men distribute through the lands?

They distribute violence through the land with their hands. 

# When does David say the wicked go astray?

They go astray as soon as they are born. 

# What does David ask God to do when the wicked shoot their arrows?

David asks God to let the arrows be as though they had no points. 

# When will the righteous rejoice?

The righteous will rejoice when he sees God's vengeance. 

# How does David ask God to rescue him from his enemies?

He asks God to set him on high away from those who rise up against him. 

# Who gather themsleves together against David?

The mighty evildoers gather themselves together against David. 

# Who does David ask Yahweh to not be merciful to?

He asks Yahweh to not be merciful to any wicked transgressors. 

# How does David expect his God to meet him?

God will meet him with his covenant faithfulness. 

# How does David ask God to consume his enemies?

He asks God to consume them in wrath, and to consume them so that they will be no more. 

# How does David sing about God's strength?

He says God has been his high tower and a refuge in the day of his distress. 

# What has God done to the Israelies?

He has cast them off, broken them down, and has been angry with them. 

# What has God done to the land?

He has made the land tremble and torn it apart. 

# What has God shown to his people and made them drink?

He has shown them severe things and made them drink the wine of staggering. 

# To whom has God given a banner?

He gave a banner to those that honor him. 

# What will God do to Shechem and the valley of Succoth?

He will divide Shechem and apportion out the valley of Succoth. 

# What will God do to Edom?

He will throw his shoe over Edom. 

# What did God not do for the army?

He did not go into battle with them. 

# How will the Israelites be able to triumph?

They will triumph with God's help, for he will trample down the enemy. 

# How will the Israelites be able to triumph?

They will triumph with God's help, for he will trample down the enemy. 

# What does David ask God to do for him?

David asks God to hear his cry, and to attend to his prayer. 

# What has God been like for David?

God has been a refuge and a strong tower from the enemy for David. 

# Where will David live and take refuge?

David will live in God's tabernacle forever and take refuge in the hiding place under God's wings. 

# What did God do for David when he heard his vows?

God gave him the inheritance of those who honor God's name. 

# What will God do for the king's life?

God will prolong the king's life so that his years will be like many generations. 

# Why will David sing praise to God's name forever?

David will sing praise to God's name forever so that he may perform his vows every day. 

# Why does David wait in silence for God alone?

David waits in silence for God because his salvation comes from God. 

# What does David say God is to him?

David says God alone is his rock and salvation, and his high tower. 

# How do they treat a man in his honorable position?

They consult with him only to bring him down, they love to tell lies, and they bless him with their mouths, but in their hearts they curse him. 

# What does David tell the people to do?

He tells the people to trust in God at all times and to pour out their heart before God. 

# How does David describe men of low and high standing?

Men of low standing are vanity, and men of high standing are a lie, weighed together they are lighter than nothing. 

# On what does David say people should not fix their hearts?

He says they should not trust in oppression or robbery and not hope uselessly in riches, because they will bear no fruit. 

# What has David heard when God has spoken?

David has heard that power belongs to God. 

# To whom does covenant faithfulness belong?

Covenant faithfulness belongs to the Lord because the Lord pays back every person for what he has done. 

# How does David seek God?

He seeks God earnestly, his soul thirsts for him, and his flesh longs for God. 

# When David looks for God in the sanctuary, what does he see?

He sees God's power and glory. 

# What will David do because of God's covenant faithfulness?

David's lips will praise God, he will bless God while he lives, and he will lift up his hands in God's name. 

# What will David do because of God's covenant faithfulness?

David's lips will praise God, he will bless God while he lives, and he will lift up his hands in God's name. 

# What satisfies David's soul and causes him to praise God?

He is satisfied and praises when he thinks about God on his bed and mediates on him in the night. 

# What satisfies David's soul and causes him to praise God?

He is satisfied and praises when he thinks about God on his bed and mediates on him in the night. 

# Where does David rejoice?

He rejoices in the shadow of God's wings. 

# What supports David?

God's right hand supports David. 

# What will happen to those who seek to destroy David's soul?

They will go into the lower parts of the earth, they will be given over to the power of the sword, and given to jackals. 

# What will happen to those who seek to destroy David's soul?

They will go into the lower parts of the earth, they will be given over to the power of the sword, and given to jackals. 

# What will happen to those who swear by God?

Those that swear by him will be proud of him. 

# What will happen to those who speak lies?

Those who speak lies will have their mouths stopped up. 

# What is David asking of God to hear?

He wants God to hear his voice and to listen to his complaint. 

# From what does David ask God to hide him?

He asks God to hide him from the secret plotting of evildoers and from the commotion of the doers of iniquity. 

# What have David's enemies done to their tongues?

They have sharpened their tongues as swords. 

# At whom do David's enemies shoot?

They shoot at someone who is innocent. 

# What do David's enemies say when they consult privately together to plan evil and set traps?

They say, "Who will see us?" 

# How will God respond to David's enemies?

God will shoot them and suddenly and they will be wounded with his arrows. 

# Because of God's actions, what will happen to the enemy?

The enemy will be made to stumble and all who see them will wag their heads. 

# How will all people respond when God judges David's enemies?

All people will fear, declare God's deeds, and think wisely about what God has done. 

# What will the righteous and all the upright in heart do?

The righteous will be glad about Yahweh and will take refuge in him; all the upright in heart will take pride in him. 

# To whom does David say their vows will be carried?

Their vows will be carried to God in Zion. 

# What does David say God will do about their transgressions?

He says God will forgive their transgressions. 

# Who does David say is the blessed man?

Blessed is the man whom God chooses to bring near and live in his courts; he will be satisfied with the goodness of God's house. 

# How will God of their salvation answer their prayer?

God will answer in righteousness by doing amazing things. 

# What does God quiet?

He quiets the roaring seas, the roaring waves, and the commotion of the peoples. 

# Who is afraid of the evidence of God's deeds?

Those who live in the uppermost parts of the earth are afraid of the evidence of God's deeds. 

# How does David say God helps the earth?

God waters it, enriches it, and prepares the earth to provide mankind with grain. 

# What happens to the earth behind God's chariot?

The tracks behind his chariot drop fatness down to the earth. 

# With what are the pastures clothed, and the valleys covered?

The pastures are clothed with flocks, and the valleys are covered over with grain. 

# What does the writer tell all the earth to do?

He tells everyone to make a joyful noise to God, sing out the glory of his name, and make his praise glorious. 

# What will cause God's enemies to submit to him?

The greatness of God's power will cause his enemies to submit to him. 

# What miraculous deed did God do for the children of men?

He turned the sea into dry land so that the people went through the river on foot. 

# What does God do for his people in life?

He keeps their souls in life and does not allow their feet to be moved. 

# How has God tested his people and where has he brought them?

God has tested them as silver is tested. 

# Where did God bring his people out?

He brought them out into a spacious place. 

# With what will the writer come into God' house?

He will come into God's house with burnt offerings. 

# What will the writer offer to God?

He will offer burnt offerings of fat animals, the sweet aroma of rams, and bulls and goats. 

# What will the writer declare to all who fear God?

He will declare what God has done for his soul. 

# What will the Lord do if the writer looks at iniquity in his heart?

The Lord will not hear him if the writer looks at iniquity in his heart. 

# From what has God not turned away?

He has not turned away from the writer's prayer and from his covenant faithfulness. 

# Why should God be merciful to his people and bless them?

He should bless them so that his ways may be known on the earth, and his salvation among all nations. 

# Why should God be merciful to his people and bless them?

He should bless them so that his ways may be known on the earth, and his salvation among all nations. 

# Who should praise God?

All the peoples should praise God. 

# Why should the nations be glad and sing?

The nations should be glad and sing because God will judge the peoples with justice and govern the nations on earth. 

# Why has the earth yielded its harvest?

The earth yielded its harvest because God has blessed the peoples. 

# What should happen because God has blessed the peoples?

All the ends of the earth should honor him. 

# What does David want to happen to God's enemies and to those who hate God?

He wants God's enemies to be scattered, and those who hate God to flee before him. 

# What should the righteous do?

The righteous should be glad, rejoice, sing and be happy before Yahweh. 

# What does God do for the lonely and the prisoners?

He puts the lonely into familes, and brings out the prisoners with singing. 

# What did the earth and heavens do when God went out before his people?

The earth trembled and the heavens dropped rain in God's presence. 

# What did the earth and heavens do when God went out before his people?

The earth trembled and the heavens dropped rain in God's presence. 

# What did God send for his people?

God sent a plentiful rain to strengthen his inheritance when it was weary. 

# What did God send for his people?

God sent a plentiful rain to strengthen his inheritance when it was weary. 

# What did the great army announce?

The army announced the Lord's orders. 

# What do the women waiting at home do after the kings of armies flee?

They divide the plunder of silver and gold doves. 

# What do the women waiting at home do after the kings of armies flee?

They divide the plunder of silver and gold doves. 

# At what is the hill country looking in envy?

The hill country is looking in envy at the mountain which God desires for the place where he will live forever. 

# How many chariots of God are there?

The chariots of God are twenty thousand, thousands upon thousands. 

# What does the Lord do for his people daily?

The Lord daily bears their burdens. 

# From where will the Lord bring back his people?

The Lord will bring his people from Bashan and from the depths of the sea. 

# What order did the procession of God take place into the sanctuary?

The singers went first, the minstrels followed after, and in the middle were the unmarried girls playing small drums. 

# What order did the procession of God take place into the sanctuary?

The singers went first, the minstrels followed after, and in the middle were the unmarried girls playing small drums. 

# Who should bless and praise God in the assembly?

The true descendants of Israel should bless and praise God. 

# Who is the smallest tribe?

Benjamin is the smallest tribe. 

# What does David ask God to reveal to his people?

He asks God to reveal to them God's power as in times past. 

# What does David say to rebuke?

David says to rebuke the wild beast of the reeds and the bulls and calves of the peoples. 

# Who will come out of Egypt?

Princes will come out of Egypt. 

# Who should sing to God?

The kingdoms of the earth should sing praises to Yahweh. 

# To whom does David say strength should be ascribed?

David says ascribe strength to God. 

# What does God give to his people?

He gives strength and power to his people. 

# From what does David ask God to save him?

He asks God to save him from the deep waters that have come in to his soul. 

# What is happening to David as he waits for his God?

He is weary from crying, his throat is dry, and his eyes fail. 

# How many are David's enemies who hate him?

His enemies are more than the hairs on his head. 

# What does God know about David?

God knows about David's foolishness and his sins are not hidden from God. 

# What does David not want to happen to those who wait for and seek God?

David asks that they not be put to shame or brought to dishonor because of David. 

# What has eaten up David?

Zeal for God's house has eaten him up. 

# What did David do as a rebuke to himself?

He wept and punished his soul with fasting. 

# When did David become the object of a proverb?

He made sackcloth of his clothing. 

# When did David become the object of a proverb?

He made sackcloth of his clothing. 

# How does David want Yahweh to answer his prayer?

He asks Yahweh to answer him in the trustworthiness of Yahweh's salvation. 

# Why should Yahweh turn to David?

He should turn to David because Yahweh's mercies for David are many. 

# What does David want Yahweh to do because of David's enemies?

He wants Yahweh to draw near his soul and to redeem it. 

# What did David's enemies give him to eat and drink?

They gave him poison for food and vinegar to drink. 

# What does David want the table of his enemies to become?

He wants his enemies' table to become a snare and a trap for them. 

# What does David want to happen to his enemies' place?

He wants their placer to be a desolation, and no one to live in their tents. 

# Of what does David want Yahweh to accuse his enemies?

He wants Yahweh to accuse them of having committed iniquity after iniquity. 

# What will please God more than an ox or a bull?

David's praise to his name with a song and his thanksgiving will please Yahweh. 

# What will please God more than an ox or a bull?

David's praise to his name with a song and his thanksgiving will please Yahweh. 

# How does Yahweh respond to the needy and his prisoners?

Yahweh hears the needy and does not despise his prisoners. 

# What does David say should praise God?

Heaven, earth, the seas, and everything that moves should praise God. 

# What will God do to Zion and the cities of Judah?

God will save Zion and will rebuild the cities of Judah, and the people will live there and have it as a possession. 

# What will God do to Zion and the cities of Judah?

God will save Zion and will rebuild the cities of Judah, and the people will live there and have it as a possession. 

# What is David asking God to do?

David is asking God to save him and to come quickly and help him. 

# What does David want God to do to those who seek after his soul?

David wants God to put them to shame and confound them, to turn them backward and bring them to dishonor. 

# What does David want God to do to those who seek after his soul?

David wants God to put them to shame and confound them, to turn them backward and bring them to dishonor. 

# What does David want all those who seek Yahweh to do?

He want them to rejoice and be glad and say, "May God be praised." 

# What does David need from God because he is poor and needy?

David needs God to hurry to help and rescue him. 

# What does the writer tell Yahweh he wants him to do?

The writer wants him to rescue him, make him safe, turn his ear to him and save him. 

# What does the writer want Yahweh to be to him?

The writer wants Yahweh to be his rock and his fortress. 

# From whose hand does the writer want to be rescued?

He wants to be rescued from the hand of the wicked, and from the unrighteous and cruel man. 

# How long has the writer trusted in Yahweh?

He has trusted in Yahweh since he was a child. 

# What has the writer become for many people?

He has become an example for many people. 

# What does the writer do with his mouth all day?

He fills his mouth with praise and honor all the day. 

# What does the writer ask God not to do when the writer is old and his strength fails?

He asks Yahweh to not throw him away or abandon him. 

# What do the enemies of the writer say as they are plotting together against him?

They say, "God has forsaken him; pursue and take him, for these is no one to save him." 

# What do the enemies of the writer say as they are plotting together against him?

They say, "God has forsaken him; pursue and take him, for these is no one to save him." 

# What does the writer want to happen to those who are hostile to his life.

He wants them to be put to shame and consumed, and covered with rebuke and dishonor. 

# . What will the writer proclaim with his mouth about Yahweh?

His mouth will tell of Yahweh's righteousness and salvation. 

# Why should Yahweh not forsake the writer?

Yahweh should not forsake him because the writer is declaring Yahweh's strength to the next generation, and his power to everyone who is to come. 

# Why should Yahweh not forsake the writer?

Yahweh should not forsake him because the writer is declaring Yahweh's strength to the next generation, and his power to everyone who is to come. 

# What does the writer say is very high?

God's righteousness is very high. 

# For what does the writer give thanks with his harp?

He gives thanks to God for God's trustworthiness. 

# For what does the writer give thanks with his harp?

He gives thanks to God for God's trustworthiness. 

# What does the writer's tongue do all day long?

It will talk about God's righteousness all day long. 

# What does the writer's tongue do all day long?

It will talk about God's righteousness all day long. 

# What does Solomon ask God to give to the king and his son?

Solomon asks God to give the king his righteous decrees, and to give his son God's righteousness. 

# How long does Solomon want the people to honor God?

He wants them to honor God while the sun endures and as long as the moon lasts throughout all generations. 

# What does Solomon want the king days to be like?

He wants them to be like rain on the mown grass, and showers that water the earth. 

# How far will the king's dominion reach?

His dominion will reach from sea to sea, from the River to the ends of the earth. 

# What will all kings and nations do before the king?

All the kings will fall down before him and serve him. 

# How does the king treat the poor and the needy?

He has pity on the poor and needy, and the souls of the needy he saves. 

# What are the signs of God's blessing on the king?

The signs of blessing are an abundance of grain, and the people in the cities will flourish. 

# How long does Solomon ask that the king's name endure?

He asks that the king's name endure forever, and continue as long as the sun. 

# What does Yahweh alone do?

He alone does wonderful things. 

# To whom is God good?

God is good to Israel, to those with a pure heart. 

# Why did Asaph's feet nearly slip?

He nearly slipped because he was envious of the arrogant when he saw the prosperity of the wicked. 

# Why did Asaph's feet nearly slip?

He nearly slipped because he was envious of the arrogant when he saw the prosperity of the wicked. 

# How did Asaph describe the arrogant and wicked?

He said they had no pain, they are strong and well fed, they are free from burdens, and are not afflicted like other men. 

# How did Asaph describe the arrogant and wicked?

He said they had no pain, they are strong and well fed, they are free from burdens, and are not afflicted like other men. 

# What is pride and violence like to the wicked?

Pride is like a necklace around their neck, and violence clothes them like a robe. 

# What is the result of the blindness of the wicked?

Out of this blindness comes sin and evil thoughts. 

# What things do the wicked say?

They mock, say evil things, threaten violence, and speak against heaven. 

# What things do the wicked say?

They mock, say evil things, threaten violence, and speak against heaven. 

# What do the wicked say about God?

They say, "How does God know? Does God know what goes on?." 

# Why does Asaph feel he guarded his heart in vain?

Asaph has been afflicted all day long and disciplined every morning. 

# Why does Asaph feel he guarded his heart in vain?

Asaph has been afflicted all day long and disciplined every morning. 

# What will happen if Asaph says these things?

He will betray this generation of God's children. 

# Where did Asaph go to gain understanding of these things?

Aspha went to God's sanctuary. 

# Where did Asaph go to gain understanding of these things?

Aspha went to God's sanctuary. 

# What will the wicked become in a moment?

They will become a wilderness in a moment. 

# What did Asaph say he was like before God?

He was like a senseless animal before God. 

# What will God do for Asaph after he guides him with his advice?

Afterward, God will receive Asaph into glory. 

# What is Asaph's only desire on earth?

The God of heaven is all he desires. 

# Who will perish?

Those who are far from God will perish, and he will destroy all those who are unfaithful to him. 

# What is the one thing that Asaph needs to do?

He needs to draw near to God. 

# What does Asaph ask God to remember that he did for his people in ancient times?

God redeemed them in ancient times, and purchased them to be his own heritage. 

# What damage did the enemy do in the sanctuary?

They set up their battle flags, hacked with axes, smashed and broke the engravings. 

# What damage did the enemy do in the sanctuary?

They set up their battle flags, hacked with axes, smashed and broke the engravings. 

# What damage did the enemy do in the sanctuary?

They set up their battle flags, hacked with axes, smashed and broke the engravings. 

# What else did they do to the sanctuary?

They set it on fire, and desecrated it by knocking it to the ground, 

# What did the enemy do to the meeting places?

They burned them all of the meeting places in the land. 

# What did God's people not see anymore?

They did not see any more miraculous signs, there is no prophet any more. 

# What are signs that God has been Asaph's king since ancient times?

God divided the sea and smashed the heads of sea monsters. 

# What are signs that God has been Asaph's king since ancient times?

God divided the sea and smashed the heads of sea monsters. 

# What did God to to the leviathan?

He crushed the heads of leviathan, and fed him to those living in the wilderness. 

# What did God set in place?

He set the sun and moon in place, and set all the borders of the earth. 

# What did God set in place?

He set the sun and moon in place, and set all the borders of the earth. 

# What does the enemy do that Asaph wants Yahweh to remember?

The enemy hurled insults at Yahweh and blasphemed his name. 

# Why does Asaph ask God to remember his covenant?

He wants Yahweh to remember his covenant because the earth is full of violence. 

# What does Asaph want God to defend?

Asaph wants God to arise and defend his own honor. 

# For what do the people give thanks?

They give thanks because God reveals his presence. 

# What will God do at the appointed time?

He will judge fairly, and make steady the earth's pillars. 

# What will God do at the appointed time?

He will judge fairly, and make steady the earth's pillars. 

# What does Asaph tell the arrogant and wicked not to do?

He tells them not to be arrogant or confident of victory, and not to speak with their head held high. 

# What does Asaph tell the arrogant and wicked not to do?

He tells them not to be arrogant or confident of victory, and not to speak with their head held high. 

# What does Asaph say about God?

God is judge and brings one down and raises up another. 

# What will the wicked do with the cup of foaming wine in Yahweh's hand?

They will drink it to the last drop. 

# How will Asaph praise the God of Jacob?

He will continually tell what God has done and sing praises to him. 

# What does God say he will do to the horns of the wicked and the righteous?

He will cut off the horns of the wicked and raise up the horns of the righteous. 

# Where is the dwelling place of the God of Judah?

His dwelling place is in Zion. 

# As he descends from the mountains, what does God look like?

God shines brightly and reveals his glory. 

# What happened when the God of Jacob rebuked his enemies?

At his rebuke, both horse and rider died. 

# What happened when God's judgment came from heaven?

When his judgment came, the earth was afraid and silent. 

# What will God's angry judgment of his enemies bring him?

His angry judgment of his enemies will bring him praise. 

# What should people about the vows they make to Yahweh their God?

They should keep their vows. 

# How do the princes and kings respond to Yahweh?

He humbles the spirit of the princes, and he is feared by the kings. 

# What did Asaph do in the day of his trouble?

He sought the Lord, prayed all night, and reached out his hands. 

# What did Asaph do in the day of his trouble?

He sought the Lord, prayed all night, and reached out his hands. 

# What did Asaph think about when he could not sleep at night?

He thought about the days of old, about times long past. 

# What did Asaph recall to mind during the night?

He called to mind the song he once sang. 

# What is Asaph's sorrow?

His sorrow is the changing of the Almighty's right hand toward him and his people. 

# Which deeds of Yahweh does Asaph think about?

He thinks about Yahweh's wonderful deeds of old. 

# How is God different from all other gods?

God is extraordinary, he does wonders, he reveals his strength, and he gives his people victory. 

# How is God different from all other gods?

God is extraordinary, he does wonders, he reveals his strength, and he gives his people victory. 

# How is God different from all other gods?

God is extraordinary, he does wonders, he reveals his strength, and he gives his people victory. 

# How did nature react to God.

The waters were afraid and trembled. The clouds poured water and the skies thundered. 

# How did nature react to God.

The waters were afraid and trembled. The clouds poured water and the skies thundered. 

# Where did God's path go?

His path went through the sea, and his way through the surging waters, but his footprints were not seen. 

# Where did God's path go?

His path went through the sea, and his way through the surging waters, but his footprints were not seen. 

# Where did God's path go?

His path went through the sea, and his way through the surging waters, but his footprints were not seen. 

# How will Asaph teach his people?

Asaph will open his mouth in parables and sing about hidden things about the past. 

# What will Asaph pass on to the next generation?

Asaph will tell the next generation about the praise worthy deeds of Yahweh, his strength, and the wonders that he has done. 

# Why did Yahweh command Asaph's ancestors to teach Yahweh's decrees to their children?

Yahweh commanded this so that the generation to come might know his decrees so that the children not yet born should tell them in turn to their own children. 

# Why was it important for Asaph's ancestors to teach Yahweh's decrees to their children?

It was important for them to teach Yahweh's decrees to their children so the children would not be like their ancestors who were a stubborn and rebellious generation. 

# Why was it important for Asaph's ancestors to teach Yahweh's decrees to their children?

It was important for them to teach Yahweh's decrees to their children so the children would not be like their ancestors who were a stubborn and rebellious generation. 

# How did Israel do that was wrong in God's sight?

They did not keep the covenant with God, and refused to obey his law. 

# How did God lead Israel?

He led them in the daytime with a cloud and at night with the light of fire. 

# How did Israel challenge God?

They challenged God in their hearts by asking for food to satisfy their appetites. 

# What did Israel speak against God?

They spoke against God saying, "Can God really lay out a table for us in the wilderness?" 

# Why did Yahweh become angry and attack Israel in his anger?

Yahweh became angry with Israel because they did not believe in him and trust in his salvation. 

# How did God provide for Israel even though they did not believe in him?

God provide for them by raining down manna and meat in abundance for them to eat so they were full. 

# How did God provide for Israel even though they did not believe in him?

God provide for them by raining down manna and meat in abundance for them to eat so they were full. 

# What did God do to Israel in his anger?

He attacked and killed the strongest of them, and brought down the young men. 

# How did the people of Israel respond whenever God afflicted them?

They would start to seek him, and would return and look earnestly for him. 

# What was the condition of Israel's hearts before God?

Their hearts were not firmly fixed on God, and they were not faithful to his covenant. 

# How did God show mercy to the people of Israel?

He forgave their iniquity and did not destroy them because he remembered they were made of flesh. 

# What did God do to the Egyptians' rivers?

He turned the Egyptians' rivers to blood, so they could not drink from their streams. 

# What did God do to the firstborn of the Egyptians?

He killed all the firstborn in Egypt, the firstborn of their strength. 

# How did God lead his own people?

He led them out like sheep, and guided them through the wilderness like a flock. 

# What did God do to the nations?

He drove out the nations before the Israelites and assigned their inheritance to Israel. 

# How did the people of Israel act like their fathers?

They were unfaithful and acted treacherously like their fathers. 

# With what did Israel make God angry?

They made him angry with their pagan shrines and provoked him to jealous anger with their idols. 

# To what did God hand over his people?

He handed them over to the sword, and fire devoured their young men. 

# To what did God hand over his people?

He handed them over to the sword, and fire devoured their young men. 

# Which tribe did God chose from Israel?

God chose the tribe of Judah and Mount Zion that he loved. 

# Who did God choose to be the shepherd of Israel?

He chose David, his servant, and took him form the sheepfolds. 

# What happened when the foreign nations came into Israel?

They defiled the temple, they turned Jerusalem into a heap of ruins. 

# What has Israel become to their neighbors?

They have become a reproach for their neighbors to make, and a mocking and derision to those around them. 

# On whom does Asaph ask God to pour out his wrath?

He asks God to pour out his wrath on the nations that do not know God and on the kingdoms that do not call upon God's name. 

# What does Asaph not want God to hold against Israel?

He wants God to not hold the sins of their forefathers agains them. 

# What does Asaph not want the nations to say?

He does not want the nations to say, "Where is their God?" 

# What does Asaph say that Israel is to God?

He says they are God's people and the sheep of God's pasture. 

# What is the writer asking the Shepherd of Israel to do?

The writer is asking him to pay attention and to shine on them. 

# What is the writer asking the Shepherd of Israel to do in the sight of Ephraim and Benjamin and Manasseh?

He is asking the Spherd of Israel to stir up his power and come and save them. 

# What is the writer asking God to do?

He is asking God to restore them, shine his face on them and they will be saved 

# What was Yahweh's response when his people prayed?

He was angry at his people when they prayed. 

# What has Yahweh given them eat and to drink?

He has fed them with tears and given them tears to drink. 

# What are Israel's neighbors and enemies doing to them?

Their neighbors are arguing over them and their enemies are laughing about them. 

# What will happen when the God of hosts restores them and shines his face on them?

They will be saved. 

# What did the God of hosts do with the vine that he brought out of Egypt?

He drove out nations and transplanted it. 

# What did God do to prepare for planting the vine?

God cleared the land for it. 

# What did the vine's branches cover?

The vine covered the mountains and the highest cedars. 

# How far did the vine send out its branches and shoots?

The vine sent its branches as far as the sea and sent its shoots to the Euphrates River. 

# What will happen since the walls of the vine are broken down?

All who pass by will pluck its fruit. 

# What will the boars and beasts do to the vine?

The boars ruin it and the beasts feed on it. 

# What does the writer ask the God of hosts to do for the vine?

He asks the God of hosts to turn back, look down from heaven, take notice and take care of this vine. 

# Who planted the root of the vine and made the shoot grow?

The right hand of the God of hosts planted the root and made the shoot grow. 

# What is happening to the vine?

The vine is burned and cut down. 

# What does the writer want to happen to the enemies of the God of hosts?

The writer want the enemies of the God of hosts to perish because of his rebuke. 

# What does the writer want God to do to the man of God's right hand?

The writer wants God's hand to be on that man. 

# What did God do for the son of man?

God made him strong for himself. 

# What will the people do if God revives them?

They will call on God's name. 

# What will happen if Yahweh, the God of hosts shines on the people?

If Yahweh shines on them, they will be saved. 

# What does the writer tell everyone to do to God?

He tells them to sing aloud and to shout out for joy. 

# What instruments does the writer tell the people to play as they sing a song?

The people should play the tambourine and the pleasant lyre with the harp. 

# When should the people blow the ram's horn?

They should blow it on the day of the new moon, the day of the full moon, when their feast day begins. 

# Who gave the statute and decree for Israel?

The God of Jacob gave them for Israel. 

# Why did the God of Jacob issue a statute and decree for Israel?

He issued it as a regulation in Joseph. 

# What did God remove from the shoulder of the people?

God removed the burden. 

# What happened when the people called out in their distress?

God helped them, and answered them and tested them. 

# What did God say about foreign gods?

God said there must be no foreign god among Israel and they must not worship any foreign god. 

# What does Yahweh say he did for Israel?

He brought them out of Egypt. 

# Why did God tell the Israelites to open their mouth wide?

He told them to open it so he would fill it. 

# What did Yahweh's people, Israel, not do?

They did not listen to Yahweh's words or obey him. 

# Why did Yahweh give his people over to their own stubborn way?

He gave them over so that they might do what seemed right to them. 

# What does Yahweh long for his people to do?

Yahweh wants his people to listen to him and walk in his paths. 

# What would Yahweh do if his people would listen to him and walk in his paths?

He would quickly subdue their enemies and turn his hand against their oppressors. 

# What does the writer want to happen to those who hate Yahweh?

He wants them to cringe in fear and be humiliated forever. 

# What does Yahweh say he would do for Israel?

Yahweh would feed them with the finest wheat and satisfy them with the honey out of the rock. 

# Where does God stand to render judgment?

He stands in the divine assembly and in the midst of the gods. 

# What does Asaph ask God?

He asks God how long God will you judge unjustly and show favoritism to the wicked? 

# What does Asaph ask God to do for the poor and fatherless and the afflicted and destitute?

He asks God to defend them and maintain their rights. 

# What does Asaph ask God to do for the poor and needy?

He asks God to rescue them and take them out of the hand of the wicked. 

# Where do those who neither know nor understand and wander?

They wander around in darkness. 

# How does Asaph say the sons of the Most High will die?

They will die like men and fall like one of the princes. 

# How does Asaph say the sons of the Most High will die?

They will die like men and fall like one of the princes. 

# Why is Asaph asking God to arise and judge the earth?

He asks God to judge because he will inherit all the nations. 

# What are God's enemies doing?

They are making a commotion, and have raised their heads. 

# Who do the enemies of God conspire against and plan against?

They conspire against God's people and plan against God's protected ones. 

# What do God's enemies say they will do to Israel?

They said, "Let us destroy them as a nation." 

# What would happen to the name of Israel if God's enemies destroyed them?

Israel would no longer be remembered. 

# Against whom have God's enemies schemed?

They schemed against God and made an alliance. 

# What does Asaph ask God to do to his enemies, as he did to Midian, Sisera and Jabin?

He asks that they perish at Endor and become like manure for the earth. 

# What does Asaph ask God to do to his enemies, as he did to Midian, Sisera and Jabin?

He asks that they perish at Endor and become like manure for the earth. 

# What did the nobles and the princes of the enemies say about Israel?

They said, "Let us take for ourselves the pastures of God." 

# What did the nobles and the princes of the enemies say about Israel?

They said, "Let us take for ourselves the pastures of God." 

# What things does Asaph want God to make his enemies like?

He wants God to make them like whirling dust, chaff before the wind, fire that burns the forest, and the flame that sets the mountains on fire. 

# What things does Asaph want God to make his enemies like?

He wants God to make them like whirling dust, chaff before the wind, fire that burns the forest, and the flame that sets the mountains on fire. 

# How does Asaph want God to chase and terrify his enemies?

He wants God to chase them with God's strong wind and terrify them with God's windstorm. 

# Why does Asaph ask Yahweh to fill the enemies faces with shame?

He asks God to fill the enemies with shame so they might seek Yahweh's name. 

# What does Asaph desire to happen to God's enemies?

He desires that they be put to shame, be terrified forever and perish in disgrace. 

# What will God's enemies know about Yahweh?

They will know that Yahweh alone is the Most High over all the earth. 

# What does the writer say about the place where Yahweh of hosts lives?

He says the place where Yahweh of hosts lives is lovely. 

# For what does the writer long?

He longs for the courts of Yahweh. 

# To whom does the writers heart and whole being call out?

His heart and whole being calls out to the living God. 

# Where has the sparrow found her house and the swallow a nest where she may lay her young?

They have found their house and nest near the altars of Yahweh of hosts. 

# What other names does the writer use for Yahweh of hosts?

He uses the names of my King and my God. 

# What happens to those who live in Yahweh's house?

They are blessed and they praise Yahweh continually. 

# What happens to the man whose strength is in Yahweh?

The man whose strength is in Yahweh is blessed. 

# Where do the blessed find springs of water to drink?

They find springs of water to drink as they pass through the Valley of Weeping. 

# Where does the blessed people appear?

They appear before God in Zion. 

# Who does the writer want to hear his prayer?

He wants Yahweh God of hosts to hear his prayer. 

# Who does the writer want to listen to what he is saying?

He wants the God of Jacob to listen to what he is saying. 

# What does the writer want God to watch over and for whom does he want God to show concern?

He wants God to watch over their shield and show concern for God's anointed. 

# A day in Yahweh's courts is better than what?

A day in Yahweh's courts is better that a thousand years elsewhere. 

# What would the writer rather be in the house of his God than to live within the tents of the wicked?

He would rather be a doorkeeper in the house of his God. 

# What is Yahweh God to the writer?

Yahweh God is our sun and shield. 

# What will Yahweh give?

Yahweh will give grace and glory. 

# What does Yahweh not withhold from those who walk in integrity.

Yahweh does not withhold any good thing from those who walk in integrity. 

# What happens to the man who trusts in Yahweh of hosts?

The man who trusts in Yahweh is blessed. 

# What has Yahweh done for the well-being of Jacob?

Yahweh has shown favor to their land and restored the well-being of Jacob. 

# What has Yahweh done about the sins of his people?

He has forgiven his people and covered all their sins. 

# What has Yahweh done with his wrath and hot anger?

He has withdrawn all his wrath and turned back from his hot anger. 

# Of what does the writer ask God to let go?

He ask God to let go of his displeasure with his people. 

# What will God's people do if God revives them again?

God's people will rejoice in God. 

# What is the writer asking God to show and grant his people?

He is asking Yahweh to show his covenant faithfulness and grant his salvation. 

# What does the writer say will happen when he listens to what Yahweh God says?

God will make peace with his people, his faithful followers. 

# What must the people do to make peace with God?

God's people must not turn again to foolish ways. 

# What will remain in the land when God's salvation is near to those who fear him?

Glory will remain in the land. 

# What have met together and what have kissed each other?

Covenant faithfulness and trustworthiness have met together and righteousness and peace have kissed each other. 

# What will sprout up from the ground and what will look down from the sky?

Trustworthiness will sprout up and victory will look down. 

# What will happen when Yahweh gives his good blessings?

Their land will yield its crops. 

# What will go before Yahweh and make a way for his footsteps?

Righteousness will go before Yahweh. 

# Why does David ask Yahweh to listen to and answer him?

He asks Yahweh to answer him because David is poor and oppressed. 

# What does David ask God to do for him when he is loyal and trusts in God?

David asks God to protect him and save him. 

# What does David asks when he cries out to the Lord?

David asks the Lord to be merciful to him. 

# When David lifts up his soul to the Lord, what is he asking from the Lord?

David asks the Lord to make his servant glad. 

# What happens to all those who cry out to the Lord who is good?

The Lord is ready to forgive and show them great mercy. 

# Who does David ask to listen to his prayer and hear the sound of his pleas?

David asks Yahweh to listen and hear. 

# What will Yahweh do when David calls on him in his day of trouble?

Yahweh will answer David. 

# Who compares to the Lord among the gods?

There is no one who compares to the Lord. 

# What will all the nations do before the Lord?

All the nations will come and bow before the Lord and honor the Lord's name. 

# Who only does great and wonderful things?

Only God does great and wonderful things. 

# What does David ask Yahweh to teach him?

David asks Yahweh to teach him Yahweh's ways. 

# What will happen when Yahweh teaches David?

David will walk in Yahweh's truth. 

# What does David tell God he will do?

David will praise God and glorify God's name forever. 

# What does David say God's covenant faithfulness toward him has done?

God has rescued David's soul from the depths of sheol. 

# What does David say the arrogant and violent men have done?

They have risen up against David, seek his life and have no regard for God. 

# How does David describe the Lord?

David describes the Lord as a merciful and gracious God, slow to anger, and abundant in covenant faithfulness and trustworthiness. 

# What does David ask the Lord to do for him?

David asks the Lord to turn toward him, have mercy on him, give his strength and save him. 

# What will happen when Yahweh shows David a sign of his favor?

Those who hate David will see God's favor and be put to shame. 

# What does David say Yahweh as done for him?

Yahweh has helped David and comforted him. 

# Where is the Lord's city established?

It is established on the holy mountains. 

# How much does Yahweh love the gates of Zion?

He loves them more than all the tents of Jacob. 

# What things are said of the city of God?

Glorious things are said of the city of God. 

# To whom did the writer mention Rahab and Babylon?

He mentioned them to his followers. 

# What will the Most High do for Zion?

The Most High himself will establish her. 

# What does Yahweh note as he registers the peoples?

He notes, "This one was born there." 

# What do the singers and dancers say?

They say, "All my springs of water are in you." 

# When does the writer cry out to Yahweh, the God of his salvation?

The writer cries out day and night before Yahweh. 

# What does the writer ask Yahweh to do for him?

He asks Yahweh to listen to his prayer and pay attention to his cry. 

# What is the problem with the writer's soul and life?

His soul is full of troubles and his life is nearing sheol. 

# How does the writer describe himself when people treat him like those who go down to the pit?

He describes himself as a man with no strength. 

# What does the writer say happens to him when he is like the dead who lie in the grave?

He says that Yahweh cares for the dead no more because they are cut off from Yahweh's power. 

# Where does the writer say that Yahweh has placed him?

He says Yahweh has placed him in the lowest part of the pit. 

# What lies heavy on the writer?

Yahweh's wrath lies heavy on the writer. 

# What has Yahweh done to make the writer's acquaintenances avoid him?

Yahweh has made the writer a shocking sight to his acquaintances. 

# From what do the writer's eyes to grow weary?

His eyes grow weary from trouble. 

# What questions does the writer ask Yahweh about the dead and those who have died?

He asks Yahweh if he will do wonders for the dead, and if they will rise up and praise Yahweh. 

# What does the writer asks Yahweh about his covenant faithfulness, loyalty, wonderful deeds and righteousness?

The writer asks Yahweh if they will be proclaimed in the grave, in the place of the dead, in the darkness and in the place of forgetfulness. 

# What does the writer asks Yahweh about his covenant faithfulness, loyalty, wonderful deeds and righteousness?

The writer asks Yahweh if they will be proclaimed in the grave, in the place of the dead, in the darkness and in the place of forgetfulness. 

# When does the writer's prayer come before Yahweh?

His prayer comes before Yahweh in the morning. 

# What has Yahweh done to the writer?

Yahweh has rejected the writer and hidden his face from him. 

# How long has the writer been afflicted and on the verge of death.

The writer has been afflictd and on the verge of death since his youth. 

# What does the writer say Yahweh's angry actions and terrifying deeds have done?

Yahweh's actions have passed over and his deeds have annihilated the writer. 

# What have Yahweh's actions and deeds done to the writer all day long?

They surrounded the writed like water and encircled him. 

# What does the writer say is his only acquaintance?

He says his only acquaintance is the darkness. 

# Of what will the writer sing forever?

He will sing of Yahweh"s acts of covenant faithfulness. 

# What will the writer proclaim to future generations?

He will proclaim Yahweh's truthfulness. 

# Where has Yahweh's truthfulness been established?

It has been established in the heavens. 

# With whom has a covenant and an oath been made?

The covenant has been made with the chosen one and an oath has been made to David. 

# How long will the descendants and the throne be established?

The descendants will be established forever and the throne through all generations. 

# For what will the heavens praise Yahweh?

The heavens will praise Yahweh for his wonders. 

# For what will the assembly of the holy ones praise Yahweh?

They will praise Yahweh for his truthfulness. 

# How does God compare to those who surround him?

He is more awesome than all who surround him. 

# What does the writer say about Yahweh's truthfulness?

It surrounds Yahweh. 

# What does the writer say about Yahweh's rule of the raging sea?

He says that when the waves surge, Yahweh calms them. 

# What did Yahweh do to Rahab?

He crushed her as one who is killed. 

# What did Yahweh use to scatter his enemies?

He used his strong arm. 

# What belongs to Yahweh who made the world and all it contains?

The heavens and the earth belong to Yahweh. 

# What did Yahweh create?

Yahweh created the north and the south. 

# What does the writer say about Yahweh's arm and hand?

Yahweh has a mighty arm and a strong hand, and his right hand is high. 

# What is the foundation of Yahweh's throne?

Righteousness and justice are the foundation of Yahweh's throne. 

# What comes before Yahweh?

Covenant faitfhulness and trustworthiness come before Yahweh. 

# What happens to the people who worship Yahweh?

They are blessed and walk in the light of Yahweh's face, they rejoice in Yahweh's name, and in Yahweh's righteousness they exalt. 

# What happens to the people who worship Yahweh?

They are blessed and walk in the light of Yahweh's face, they rejoice in Yahweh's name, and in Yahweh's righteousness they exalt. 

# How does Yahweh's majestic strength and favor benefit the people?

The people are victorious 

# What belongs to Yahweh and what is he called?

The people's shield belongs to Yahweh and is called the Holy One of Israel. 

# What did Yahweh say in a vision to his faithful ones?

He said that he set a crown on a mighty one and raised up one chosen from among the people. 

# What did Yahweh say he will do for his chosen servant David?

He said he had anointed him, will support him, and will strengthen him. 

# What did Yahweh say he will do for his chosen servant David?

He said he had anointed him, will support him, and will strengthen him. 

# What did Yahweh say he will do for his chosen servant David?

He said he had anointed him, will support him, and will strengthen him. 

# What did Yahweh say he will do for his chosen servant David?

He said he had anointed him, will support him, and will strengthen him. 

# What will be with David and how will he be victorious?

Yahweh's truth and covenant faithfulness will be with David and by Yahweh's name David will be victorious. 

# What will David call out to Yahweh?

He will call Yahweh his Father, his God, and the rock of his salvation. 

# What will Yahweh do for David who he places as his firstborn son and most exalted of the kings of the earth?

Yahweh will extend and secure his covenant faithfulness to David forever. 

# What will Yahweh do for David who he places as his firstborn son and most exalted of the kings of the earth?

Yahweh will extend and secure his covenant faithfulness to David forever. 

# How long will David's descendants and throne endure?

His descendants will endure forever and his throne will endure as the skies above. 

# What will Yahweh do to David's children if they forsake Yahweh's law, disobey his decrees, break his rules and do not keep his commands?

Yahweh will punish their rebellion with a rod and their iniquity with blows. 

# What will Yahweh do to David's children if they forsake Yahweh's law, disobey his decrees, break his rules and do not keep his commands?

Yahweh will punish their rebellion with a rod and their iniquity with blows. 

# What will Yahweh do to David's children if they forsake Yahweh's law, disobey his decrees, break his rules and do not keep his commands?

Yahweh will punish their rebellion with a rod and their iniquity with blows. 

# What promises does Yahweh make to David?

Yahweh promises not to remove his covenant faithfulness or be unfaithful to his promise. He will not break his covenant or change the words of his lips. 

# What promises does Yahweh make to David?

Yahweh promises not to remove his covenant faithfulness or be unfaithful to his promise. He will not break his covenant or change the words of his lips. 

# By what does Yahweh swear once and for all.

Yahweh swears by his holiness. 

# What does the writer now say about how David is being treated by Yahweh?

The writer says that Yahweh has refused and rejected and is angry with the anointed king. 

# What does the writer say is happening to the anointed king?

He is being robbed and has become an object of disgust to his neighbors. 

# What have the anointed king's enemies done?

They have raised their right hand and have been made to rejoice. 

# What happened when the anointed king went into battle?

The edge of the king's sword was turned back and he was made unable to stand in battle. 

# What has happened to the king's spendor and throne?

His splendor has been brought to an end and his throne has been brought down to the ground. 

# What has happened to the days of the anointed king?

His days have been shortened and he has been covered with shame. 

# What does the writer ask Yahweh about his anger?

He asks how long will Yahweh will hide himself and his anger will burn like fire. 

# What does the writer ask Yahweh to think about?

He asks Yahwe to think about how short his time is and for what uselessness Yahweh has created all the sons of men. 

# What does the writer ask the Lord about his former acts of covenant faithfulness?

The writer asks the Lord, "Where are your former acts of covenant faithfulness?" 

# What does the writer tell the Lord to call to mind?

His tells the Lord that Yahweh's enemies hurl insults and mock the footsteps of Yahweh's anointed one. 

# What does the writer tell the Lord to call to mind?

His tells the Lord that Yahweh's enemies hurl insults and mock the footsteps of Yahweh's anointed one. 

# How long does the writer say Yahweh will be blessed?

Yahweh will be blessed forever. 

# How long has the Lord been a refuge for Moses and the people?

The Lord has been a refuge throughout all generations. 

# To what does the Lord return man?

He returns man to the dust. 

# What are a thousand years like in the sight of the Lord?

They are as yesterday when it is past, and as a watch in the night. 

# To what are the descendants of mankind like?

They are like the grass that sprouts up, blooms and grows up, and then withers and dries up. 

# To what are the descendants of mankind like?

They are like the grass that sprouts up, blooms and grows up, and then withers and dries up. 

# Why is mankind consumed in the Lord's anger and terrified in his wrath?

They are consumed and terrified because the Lord has set their iniquities before himself, and their hidden sins in the light of his presence. 

# Why is mankind consumed in the Lord's anger and terrified in his wrath?

They are consumed and terrified because the Lord has set their iniquities before himself, and their hidden sins in the light of his presence. 

# How many are the years of mankind if they are healthy?

Their years are eighty if healthy. 

# What does Moses ask the Lord to teach mankind?

He asks the Lord to teach mankind to consider their lives, so that they may live wisely. 

# With what does Moses want the Lord to satisfy mankind in the morning?

He wants the Lord to satisfy mankind with the Lord's covenant faithfulness, so that they may rejoice and be glad all their days. 

# What does Moses want the Lord to let his servants see?

He wants the Lord to let his servants see his work and their children see his majesty. 

# How does the Lord show his favor to mankind?

He prospers the work of their hands. 

# What does the writer say of Yahweh?

The writer says, "He is my shelter and my fortress, my God, in whom I trust." 

# What will Yahweh do for the one who trusts in him?

Yahweh will rescue him from the snare of the hunter and from the deadly plague and cover him with his wings. 

# What will Yahweh do for the one who trusts in him?

Yahweh will rescue him from the snare of the hunter and from the deadly plague and cover him with his wings. 

# What does the one who trusts in Yahweh need not be afraid of?

The one who trusts in Yahweh need not be afraid of terror in the night, or the the arrow that flies by day, the plagues that roam around in the darkness, and the disease that comes at noontime. 

# What does the one who trusts in Yahweh need not be afraid of?

The one who trusts in Yahweh need not be afraid of terror in the night, or the the arrow that flies by day, the plagues that roam around in the darkness, and the disease that comes at noontime. 

# What is Yahweh for the writer?

Yahweh is the refuge for the writer. 

# Why will no evil overtake nor affliction come near the home of the one who trusts in Yahweh?

No evil will overtake nor affliction come near the one who trusts in Yahweh because Yahweh will direct his angels to protect and guard him in all his ways. 

# Why will no evil overtake nor affliction come near the home of the one who trusts in Yahweh?

No evil will overtake nor affliction come near the one who trusts in Yahweh because Yahweh will direct his angels to protect and guard him in all his ways. 

# How will the angels protect and guard the one who trusts in Yahweh?

The angels will lift him up with their hand so he will not slip and fall on a stone. 

# How will the angels protect and guard the one who trusts in Yahweh?

The angels will lift him up with their hand so he will not slip and fall on a stone. 

# What does Yahweh do for the one who is devoted to him?

Yahweh will rescue him, protect him, answer him when he calls, give him victory and honor when he is in trouble, satisfy him with long life, and show him Yahweh's salvation. 

# What does Yahweh do for the one who is devoted to him?

Yahweh will rescue him, protect him, answer him when he calls, give him victory and honor when he is in trouble, satisfy him with long life, and show him Yahweh's salvation. 

# What does Yahweh do for the one who is devoted to him?

Yahweh will rescue him, protect him, answer him when he calls, give him victory and honor when he is in trouble, satisfy him with long life, and show him Yahweh's salvation. 

# What does the writer consider to be a good thing?

It is a good thing to give thanks and sing praises to the name of Yahweh. 

# When does there writer say to proclaim Yahweh's covenant faithfulness and truthfulness?

He says to proclaim Yahweh's covenant faithfulness in the morning and his truthfulness every night. 

# How has the writer responded to the great deeds of Yahweh?

Yahweh's great deeds have made him glad so that he will sing for joy. 

# How has the writer responded to the great deeds of Yahweh?

Yahweh's great deeds have made him glad so that he will sing for joy. 

# What kind of person does not know and understand such joy?

Such joy is not known by a brutish person nor a fool. 

# What is the destiny of the wicked who sprout like the grass and all the evildoers who thrive?

The wicked who sprout like the grass and all the evildoers who thrive are still doomed to eternal destruction. 

# Why do all the evildoers, who are Yahweh's enemies, scatter?

All the evildoers are scattered because Yahweh will reign forever. 

# Why do all the evildoers, who are Yahweh's enemies, scatter?

All the evildoers are scattered because Yahweh will reign forever. 

# How has Yahweh exalted the writer's horn and anointed him with fresh oil?

Yahweh has exalted and anointed the writer by allowing him to see the downfall of his enemies and hear the doom of his evil foes. 

# How has Yahweh exalted the writer's horn and anointed him with fresh oil?

Yahweh has exalted and anointed the writer by allowing him to see the downfall of his enemies and hear the doom of his evil foes. 

# Where are the righteous planted?

They are planted in the house of Yahweh. 

# What do the righteous do to proclaim that Yahweh is just?

The righteous bear fruit when they are old and stay fresh and green. 

# What do the righteous do to proclaim that Yahweh is just?

The righteous bear fruit when they are old and stay fresh and green. 

# Why is Yahweh the rock of the writer?

Yahaweh is his rock because there is no unrighteousness in Yahweh. 

# In what is Yahweh robed and clothed?

Yahweh is robed in majesty and clothed with strength which he wears like a belt. 

# How have the oceans lifted up their voice?

The oceans rise and their waves crash and roar. 

# Who is above the crashing of many waves and the mighty breakers of the sea?

Yahweh on high is mighty and above the many crashing waves and mighty breakers of the sea. 

# How does the writer describe Yahweh's commands and holiness?

The writer says that Yahweh's commands are very trustworthy and holiness adorns Yahweh's house forever. 

# What does the writer ask Yahweh God to do?

The writer asks Yahweh God to shine over his people and give to the proud what they deserve. 

# What does the writer ask Yahweh God to do?

The writer asks Yahweh God to shine over his people and give to the proud what they deserve. 

# How do the wicked rejoice in what they say?

The wicked rejoice by pouring out arrogant, defiant and boastful speeches. 

# How do the wicked rejoice in what they say?

The wicked rejoice by pouring out arrogant, defiant and boastful speeches. 

# What is the behavior of the wicked?

The wicked crush Yahweh's people and they kill the widow, the alien and the fatherless. 

# What is the behavior of the wicked?

The wicked crush Yahweh's people and they kill the widow, the alien and the fatherless. 

# What does the wicked say?

The wicked says that Yahweh will not see nor take notice of what we do. 

# What is the question the writer asks of the fools?

He asks them, "When will you ever learn?" 

# What does Yahweh know about the thoughts of men?

Yahweh knows that the thoughts of men are corrupt. 

# What does Yahweh do for the one who is blessed?

Yahweh teaches his law and gives rest in times of trouble to the one who is blessed. 

# What does Yahweh do for the one who is blessed?

Yahweh teaches his law and gives rest in times of trouble to the one who is blessed. 

# What promise does the writer give to Yahweh's people?

The writer says that Yahweh will not forsake his people nor abandon his inheritance. 

# What is the result of Yahweh's promise?

The result of Yahweh's promise is that justice will prevail and all the upright will follow it. 

# What provision from Yahweh was a help to the writer?

The provision was Yahweh's covenant faithfulness which held the writer up when he said, "my foot is slipping." 

# What provision from Yahweh was a help to the writer?

The provision was Yahweh's covenant faithfulness which held the writer up when he said, "my foot is slipping." 

# How do the wicked rulers create injustice by statute?

The wicked rulers create injustice by conspiring against the righteous and condemning the innocent to death. 

# How do the wicked rulers create injustice by statute?

The wicked rulers create injustice by conspiring against the righteous and condemning the innocent to death. 

# How has Yahweh encouraged the writer?

Yahweh has encouraged the writer by being his high tower and the rock of his refuge. 

# What will Yahweh do to the wicked rulers?

Yahweh will bring on them their own iniquity and cut them off in their own wickedness. 

# How does the writer encourage everyone to enter?

The writer encourages everyone to enter Yahweh's presence with thanksgiving. 

# How does Yahweh compare to other gods?

Yahweh is a great God and a great King who is superior to all gods. 

# How is Yahweh superior to all gods?

Yahweh is superior to all gods in that the heights of the mountains and the seas which he made are his and his hands formed the dry land. 

# How is Yahweh superior to all gods?

Yahweh is superior to all gods in that the heights of the mountains and the seas which he made are his and his hands formed the dry land. 

# Why should everyone worship by bowing down and kneeling before Yahweh?

Everyone should worship Yahweh because he is their God and they are the people of his pasture and the sheep of his hand. 

# Why should everyone worship by bowing down and kneeling before Yahweh?

Everyone should worship Yahweh because he is their God and they are the people of his pasture and the sheep of his hand. 

# How did the forefathers of Israel respond to Yahweh?

They challenged his authority and tried his patience, though they had seen his deeds. 

# How did Yahweh describe the people who challenged his authority?

Yahweh said, "This is a people whose hearts wander astray; they have not known my ways." 

# What did Yahweh vow in his anger?

Yahweh vowed in his anger that the people who challenged his authority would never enter into Yahweh's resting place. 

# What does the writer encourage everyone to announce?

The writer encourages everyone to announce Yahweh's salvation day after day. 

# Why should everyone declare Yahweh's glory and his marvelous deeds among the nations?

Everyone should declare Yahweh's glory and his marvelous deeds because Yahweh is great, and greatly to be praised, and to be feared above all other gods. 

# Why should everyone declare Yahweh's glory and his marvelous deeds among the nations?

Everyone should declare Yahweh's glory and his marvelous deeds because Yahweh is great, and greatly to be praised, and to be feared above all other gods. 

# What attributes are in Yahweh's presence?

The attributes in Yahweh's presence are splendor, majesty, strength and beauty. 

# What should everyone do to ascribe to Yahweh the glory due to his name?

Everyone should bring an offering and come into his courts. 

# What did the writer encourage everyone to say among the nations?

The writer encouraged everyone to say, "Yahweh reigns." 

# How does Yahweh judge the peoples?

Yahweh judges the peoples fairly. 

# Why should the heavens be glad and the earth rejoice?

The heavens should be glad and the earth rejoice because Yahweh is coming. 

# Why should the heavens be glad and the earth rejoice?

The heavens should be glad and the earth rejoice because Yahweh is coming. 

# Why should the heavens be glad and the earth rejoice?

The heavens should be glad and the earth rejoice because Yahweh is coming. 

# What will Yahweh do when he comes?

When Yahweh comes he will judge the earth, the world with righteousness, and the people with his faithfulness. 

# What is the foundation of Yahweh's throne?

The foundation of Yahweh's throne is righteousness and justice. 

# What is the result of the fire that goes before Yahweh?

The fire that goes before Yahweh consumes his adversaries on every side. 

# What happens in Yahweh's presence?

Yahweh's lightning lights up the world, the earth sees and trembles, and the mountains melt like wax in Yahweh's presence. 

# What happens in Yahweh's presence?

Yahweh's lightning lights up the world, the earth sees and trembles, and the mountains melt like wax in Yahweh's presence. 

# What declares Yahweh's justice and glory?

The skies declare Yahweh's justice and all the nations see his glory. 

# Who will be shamed by Yahweh?

All those who worship carved figures and boast in worthless idols will be shamed by Yahweh. 

# Why did Zion hear and the towns of Judah rejoice?

Zion heard and the towns of Judah rejoiced because of Yahweh's righteous decrees. 

# What does the writer say about Yahweh?

The writer says that Yahweh is most high above all the earth and exalted far above all gods. 

# What does Yahweh do for his saints?

Yahweh protects the lives of his saints and takes them out of the hand of the wicked. 

# What does the writer encourage the righteous to do?

The writer encourages the righteous to be glad in Yahweh and give thanks to his holy name. 

# What has given victory to Yahweh's people?

Yahweh's right hand and holy arm have given his people victory. 

# What has Yahweh openly showed to all the nations?

He has openly showed his justice to all the nations. 

# What does Yahweh call to mind?

Yahweh calls to mind his covenant loyalty and faithfulness for the house of Israel. 

# Who will see the victory of Israel's God?

All the ends of the earth will see the victory of Israel's God. 

# What should be the response of everyone to Yahweh's provision?

Everyone should shout for joy and burst into song, singing Yahweh's praises. 

# What instruments should the house of Israel use to sing praises and make a joyful noise before Yahweh?

The house of Israel should use the harp, trumpets, and the sound of the horn. 

# What instruments should the house of Israel use to sing praises and make a joyful noise before Yahweh?

The house of Israel should use the harp, trumpets, and the sound of the horn. 

# How does the writer encourage Yahweh's creation to respond to his coming?

The writer says the sea and everything in it and the world and those who live in it should shout, and the rivers should clap their hands and the mountains should shout for joy. 

# How does the writer encourage Yahweh's creation to respond to his coming?

The writer says the sea and everything in it and the world and those who live in it should shout, and the rivers should clap their hands and the mountains should shout for joy. 

# How will Yahweh judge the world?

Yahweh will judge the world with righteousness and the nations with fairness. 

# How should the nations respond to Yahweh's reign?

The nations should tremble in response to Yahweh's reign. 

# Why does the earth quake?

The earth quakes because Yahweh sits enthroned above the cherubim. 

# Why is Yahweh exhalted above all the nations?

Yahweh is exalted because he is great in Zion. 

# Why should the nations praise Yahweh's great and awesome name?

The nations should praise Yahweh's name because he is holy. 

# How does the writer describe the king?

The writer says the king is strong and he loves justice. 

# How does the writer say that the nations should respond to Yahweh?

The writer says that the nations should praise Yahweh and worship at his footstool because he is holy. 

# Who were some of those men who prayed to Yahweh and he answered them?

Some of those men who prayed to Yahweh and he answered them were Moses, Aaron, and Samuel. 

# How did the men who prayed to Yahweh respond to what he said?

The men who prayed kept Yahweh's solemn commands and the statutes that he gave them. 

# What did Yahweh do for the men who prayed to him?

Yahweh forgave them though he punished their sinful deeds. 

# What does the writer encourage everyone to do?

The writer says to praise Yahweh and worship at his holy hill because he is holy. 

# Who does the writer invite to shout joyfully to Yahweh?

He invites all the earth to shout joyfully to Yahweh. 

# How should people come into Yahweh's presence?

They should come before his presence with joyful singing. 

# Why does image does the writer use to show how people belong to Yahweh?

He says they are Yahweh's people and the sheep of his pasture. 

# How should people enter into Yahweh's gates and courts?

They should enter into his gates with thanksgiving and into his courts with praise. 

# What does the writer says endures forever?

He says that Yahweh's covenant faithfulness endures forever. 

# Of what two qualities will David sing?

He will sing of covenant faithfulness and justice. 

# What has David not put before his eyes?

He has not put wrong doing before his eyes. 

# Who will David destroy?

He will destroy whoever secretly slanders his neighbor. 

# What kind of people does David want to sit at his side and serve him?

David wants the faithful of the land to sit at his side, and those who walk in integrity to serve him. 

# Who will David not allow to remain within his house?

He will not allow deceitful people to remain within his house. 

# How often does David say that he will destroy all the wicked from the land?

Morning by morning, he will destroy all the wicked. 

# What does the afflicted pray for Yahweh not to do in his time of trouble?

The afflicted prays for Yahweh not to hide his face from him in his time of trouble. 

# To what does the afflicted compare his crushed heart?

The afflicted says that he is like grass that has withered. 

# What has happened due to the afflicted's continual groaning?

With the afflicted's continual groaning, he has become very thin. 

# How do those who mock the afflicted use his name?

Those who mock the afflicted use his name in curses. 

# How does the afflicted say he has been treated by Yahweh's anger?

The afflicted says that God has lifted him up to throw him down. 

# How long will the fame of Yahweh endure?

The writer says that Yahweh's fame is for all generations. 

# For what do the servants of Yahweh feel compassion?

Yahweh's servants feel compassion for the dust of Zion's ruins. 

# How will the kings of the earth show respect for Yahweh?

All the kings of the earth will honor Yahweh's glory. 

# To what action of the destitute will Yahweh respond?

Yahweh will respond to the prayer of the destitute. 

# How does the writer show how far into the future Yahweh's praise will continue?

He writes that a people not yet born will praise Yahweh. 

# What does Yahweh view from heaven?

From heaven Yahweh has viewed the earth. 

# For what action are the peoples and kingdoms gathered together?

The peoples and kingdoms gather together to serve Yahweh. 

# For what does the afflicted writer plead for God not to do?

The writer said, "My God, do not take me away in the middle of life." 

# What does the writer say Yahweh did in ancient times.

The writer says that in ancient times Yahweh set the earth in place. 

# How long will the years of Yahweh endure?

Yahweh's years will have no end. 

# Where does the writer say the descendants of Yahweh's servants will live?

The descendants of Yahweh's servants will live in his presence. 

# What does David not want to forget?

He does not want to forget all of Yahweh's good deeds. 

# With what does David say Yahweh crowns his soul?

He crowns his soul with covenant faithfulness and acts of tender mercy. 

# What does Yahweh do for all who are oppressed?

Yahweh does acts of justice for all who are oppressed. 

# What did Yahweh make known to the descendants of Israel?

He made known his deeds to the descendants of Israel. 

# What does David say that Yahweh will not always do?

He says Yahweh will not always discipline, and is not always angry. 

# David says that Yahweh does not deal with us in what way?

Yahweh does not deal with us as our sins deserve. 

# In what special way does Yahweh have compassion on those who honor him?

Yahweh has compassion on those who honor him in the same way as a father has compassion on his children. 

# How long does the covenant faithfulness of Yahweh last?

The covenant faithfulness of Yahweh is from everlasting to everlasting on those who honor him. 

# Where has Yahweh established his throne?

Yahweh has established his throne in the heavens. 

# Who are the ones with great strength who are called to bless Yahweh and obey his word?

His angels are called to obey his word. 

# Who are the servants that David says carry out Yahweh's will?

All of Yahweh's angel armies carry out his will. 

# How does the writer say that Yahweh is clothed?

He says that Yahweh is clothed with splendor and majesty. 

# In what way does Yahweh spread out the heavens?

He spreads out the heavens like a tent curtain. 

# What does the writer say will never happen to the foundations of the earth that Yahweh laid?

The foundations of the earth will never be moved. 

# What does the writer say made the waters to recede?

Yahweh's rebuke made the waters recede. 

# Why will the waters not cover the earth again?

Yahweh set a boundary for them that they will not cross. 

# What three things does the writer say Yahweh provides for man?

Yahweh provides wine to make man happy, oil to make his face shine, and food to sustain his life 

# What did Yahweh appoint the moon and the sun to mark?

He appointed the moon to mark the seasons and the sun to know its time for setting. 

# What happens to the young lions when the sun rises?

When the sun rises, they retreat and sleep in their dens. 

# With what does the deep and wide sea teem? 

The sea teems with many creatures both great and small. 

# To whom do all the sea creatures look to give them their food?

They all look to Yahweh to give them their food on time. 

# What happens to the creatures if Yahweh hides his face or takes away their breath? 

When he hide his face, they are troubled; if he take away their breath, they die and return to dust. 

# What does the writer want Yahweh to do with his creation?

The writer wants Yahweh to enjoy his creation. 

# What does the writer promise to sing for the rest of his life?

He promises to sing praise to his God as long as he lives. 

# What does the writer hope will happen to sinners and the wicked on the earth? 

He wants sinners to vanish from the earth and the wicked to be no more. 

# Where does the writer say to make known Yahweh's deeds?

The writer calls people to make known Yahweh's deeds among the nations. 

# Whose heart does the writer exhort to rejoice?

The writer calls the heart of those who seek Yahweh to rejoice. 

# How often should people seek the presence of Yahweh?

The writer calls people to seek his presence continually. 

# For how long does the writer say God keeps the word that he commanded?

The writer says that God keeps the word that he commanded for a thousand generations. 

# What covenant does the writer say God calls to mind?

God calls to mind the covenant that he made with Abraham and his oath to Isaac. 

# What everlasting covenant has Yahweh made with Israel?

Yahweh made an everlasting covenant with Israel to give them the land of Canaan as your share of their inheritance. 

# When does the writer say Yahweh made the covenant with Israel?

The writer says that Yahweh said this covenant when Israel was only few in number. 

# Whom did Yahweh tell kings not to touch?

Yahweh told them not to touch his anointed ones. 

# How did Yahweh send Joseph ahead of Israel?

He sent Joseph ahead of them to be sold as a servant. 

# How long was Joseph kept in iron chains?

Joseph was put in iron chains until the time that his prediction came true. 

# What term is used to describe the king putting Joseph in charge of his house?

Joseph was put in charge of the king's house as ruler of all the king's possessions. 

# Where did Jacob live when he came to Egypt?

Jacob lived for a time in the land of Ham. 

# Whom did God cause to hate his people Israel?

God caused Israel's enemies to hate God's people. 

# Where did Moses and Aaron perform God's signs?

Moses and Aaron performed God's signs among the Egyptians. 

# What did God do to the Egyptians' water and fish?

God turned the Egyptians' water into blood and killed their fish. 

# What did God send with the hail and rain in Egypt?

God sent hail and rain, with lightning and thunder, to their land. 

# What group of people did God kill in Egypt?

God killed every firstborn in their land, the first fruits of all their strength. 

# Why was Egypt glad when the Israelites went away?

Egypt was glad when the Israelites went away, for the Egyptians were afraid of them. 

# With what kind of food did God satisfy the Israelites?

God satisfied them with bread from heaven. 

# Which holy promise did God call to mind regarding the Israelites?

God called to mind his holy promise that he made to Abraham his servant. 

# Of what did God allow his people to take possession?

His people took possession of the wealth of the peoples. 

# What does the writer say endures forever? 

Yahweh's covenant faithfulness endures forever. 

# When does the writer ask Yahweh call him to mind? 

He asks Yahweh to call him to mind when Yahweh shows favor to his people. 

# What will cause the writer to rejoice? 

He will rejoice when he sees the prosperity of Yahweh's chosen. 

# How did the fathers of the writer respond to Yahweh's marvelous deeds? 

The fathers did not appreciate Yahweh's marvelous deeds in Egypt. 

# Why did Yahweh save the writer's ancestors? 

He saved them for his name's sake so that he might reveal his power. 

# What happened to the adversaries of Israel? 

The waters covered their adversaries; not one of them survived. 

# What did the people do when they had insatiable cravings in the wilderness. 

They challenged God in the desert. 

# What did the earth do to Dathan and the followers of Abiram? 

The earth opened and swallowed up Dathan and covered the followers of Abiram. 

# What did the people worship at Horeb? 

They made a calf at Horeb and worshipped a cast metal figure. 

# Why did God not decree the destruction of the Israelites? 

Moses, his chosen one, intervened with him in the breach to turn Yahweh's anger away from destroying them. 

# What did God swear he would do when he raised his hand? 

God swore to them that he would let them die in the desert, and scatter their descendants among the nations. 

# What happened to Israel when they provoked Yahweh to anger?

A plague broke out among them. 

# What happened when Phinehas rose to intervene for the people?

When Phinehas intervened, the plague subsided. 

# Why did Moses sin at the waters of Meribah?

The people made Moses bitter, and he spoke rashly. 

# What happened to the people when they mingled with the nations and worshipped their idols? 

Their idols became a snare for them. 

# What happened to Israel when Yahweh was angry with them and handed them over to the nations?

When Yahweh handed them over, those who hated them and ruled over them. 

# Why did Yahweh relent and pay attention to Israel in their distress? 

He called to mind his covenant with them and relented because of his covenant faithfulness. 

# For what reason should Yahweh gather Israel from among the nations? 

He should gather them so that they may give thanks to his holy name and glory in his praises. 

# How long does Yahweh's covenant faithfulness last?

His covenant faithfulness endures forever. 

# From where has Yahweh gathered his redeemed?

He has gathered them out of foreign lands, from the east and from the west, from the north and from the south. 

# What did Yahweh do for his redeemed when they called out to him in their trouble?

He rescued them out of all their distress. 

# For what should people praise Yahweh? 

They should praise him for his covenant faithfulness and for the amazing things he has done for humanity. 

# How did Yahweh humble the hearts of the people?

He humbled their hearts through hardship. 

# What kind of gates and bars has Yahweh broken for his people?

He has broken the gates of bronze and cut through the bars of iron. 

# Why were the people afflicted?

They were afflicted because for their sins. 

# What kind of sacrifices should people offer to Yahweh?

"They should offer the sacrifices of thanksgiving. 

# What did the people who travel on the sea in ships and do business overseas see of Yahweh?

They saw the deeds of Yahweh and his wonders on the seas. 

# Why happened to men when the waves reached up to the heavens and then they dropped down to the depths? 

The men's courage melted away because of the danger. 

# What happened to the men when they called out to Yahweh in their trouble? 

He brought them out of their distress and calmed the storm. 

# What happened to the men when they called out to Yahweh in their trouble? 

He brought them out of their distress and calmed the storm. 

# Where should people exalt and praise Yahweh?

They should exalt him in the assembly of the people and praise him in the council of the elders. 

# What did Yahweh do to a fruitful land because of the wickedness of the people? 

He turned a fruitful land into a barren place because of the wickedness of its people. 

# What did the people plant in their city? 

They planted fields and vineyards. 

# What happened to the leaders when Yahweh poured contempt on them?

He caused them to wander in the wilderness, where there are no roads. 

# What will all wickedness do when the upright see Yahweh's protection and rejoice?

All wickedness will shut its mouth. 

# Who does the writer call upon to take note of these things? 

The writer calls upon whoever is wise to take note of these things and meditate on Yahweh's acts of covenant faithfulness. 

# With what does David say he will sing praises?

David says that he will sing praises also with his honored heart. 

# How great does David say is Yahweh's covenant faithfulness?

David says that Yahweh's covenant faithfulness is great above the heavens. 

# Where does David ask for God's glory to be exalted?

David asks that God's glory be exalted over all the earth. 

# What has God spoken about Ephraim and Judah?

God said that Ephraim also is his helmet and Judah is his scepter. 

# How will God shout because of Philistia?

God will shout in triumph because of Philistia. 

# Whose help does David say is futile?

David asks for God's help because man's help is futile. 

# How does David describe his triumph with God's help?

David says that his army will triumph with God's help, because God will trample down David's enemies. 

# Who does David say attacks him?

David says the wicked and deceitful attack him. 

# What do the wicked give in return for David's love?

David says that in return for his love they slander him. 

# What does David ask to happen when his enemy is judged?

David asks that when his enemy is judged, he may be found guilty. 

# What is David's request for the children of his enemies?

David asks for his enemy's children to wander about and beg, asking for handouts. 

# What does David ask to happen to his enemy's earnings?

David asks for strangers to plunder what his enemy earns. 

# Why does David ask Yahweh to deal kindly with him?

David asks Yahweh his Lord to deal kindly with him for Yahweh's name's sake. 

# What is David's request from Yahweh for the memory of his enemy?

David asks that Yahweh cut off his enemy's memory from the earth. 

# Why does David ask Yahweh to cut off their memory?

David prays that Yahweh would do this because this man never bothered to show any covenant faithfulness. 

# What does David ask for since his enemy hated blessing?

David says that since his enemy hated blessing, that no blessing may come to him. 

# From whom does David request the reward for his accusers?

David asks for this to be the reward of his accusers from Yahweh. 

# To what does David compare his fading away?

David says that he is fading away like the shadow of the evening. 

# What do David's accusers do when they see him?

David says that when they see him, his accusers shake their heads. 

# By what does David ask Yahweh to save him?

David ask Yahweh to save him by Yahweh's covenant faithfulness. 

# What does David ask to happen when his accusers attack him?

David asks that when his accusers attack, they would be put to shame. 

# What does David say will happen when Yahweh stands at right hand of the needy person?

Yahweh will save the needy person from those who condemn him. 

# Where does Yahweh ask David's master to sit, and for how long?

Yahweh asks him to sit at his right hand until he makes his enemies his footstool. 

# What will the people wear as they follow David's master? 

They will follow him in sacred garments. 

# What has Yahweh sworn and will not change?

He has sworn to David's master that, "You are a priest forever." 

# What will David's master do to kings on the day of his anger?

He will kill kings on the day of his anger. 

# What will David's master do after he drinks of the brook along the road? 

He will lift his head up high after victory. 

# Where will the writer says he will give thanks to Yahweh with his whole heart?

He will give thanks to Yahweh in the assembly of the upright, in their gathering. 

# How long will Yahweh's righteousness endure?

His righteousness endures forever. 

# What will Yahweh always call to mind?

He will always call to mind his covenant. 

# How did Yahweh show his powerful works to his people?

He showed his powerful works to the people in giving them the inheritance of the nations. 

# How are Yahweh's instructions to be observed? 

All his instructions are to be observed faithfully and properly. 

# How does the writer describe Yahweh's name?

The writer says, "Holy and awesome is his name." 

# What is the beginning of wisdom?

To honor Yahweh is the beginning of wisdom. 

# What do those who carry out Yahweh's instructions have?

Those who carry out his instructions have good understanding. 

# What happens to the descendants of the man who obeys Yahweh and who greatly delights in his commandments?

His descendants will be powerful on earth and will be blessed. 

# What is in the house of the man who obeys Yahweh?

Wealth and riches are in his house. 

# For whom does the writer says things will go well?

It will go well for the man who deals graciously and lends money, and who conducts his affairs with honesty. 

# What does the righteous man do rather than fear bad news?

He does not fear, but he is confident, trusting in Yahweh. 

# What happens to the godly person who generously gives to the poor? 

He will be exalted with honor. 

# What happens to the wicked person who sees the blessing of the righteous person and is angry?

The wicked person will gnash with his teeth and melt away. 

# When will the name of Yahweh be blessed?

His name will be blessed both now and forevermore. 

# Where does the glory of Yahweh reach?

His glory reaches above the skies. 

# Where is the seat of Yahweh?

His seat is on high, from where he looks down at the sky and earth. 

# Where is the seat of Yahweh?

His seat is on high, from where he looks down at the sky and earth. 

# Where does Yahweh seat the poor and the needy person when he raises him up? 

Yahweh seats him with princes, with the princes of his people. 

# What does Yahweh give the barren woman?

He gives the barren woman in the house a seat like a joyful mother of the children. 

# When Israel left Egypt, what did Judah and Israel become?

Judah became his sanctuary, and Israel became his kingdom. 

# What did the mountains and the hills do when the Israelites came to the land?

The mountains skipped like rams, and the hills skipped like lambs. 

# Why does the writer say the earth should tremble? 

The earth should tremble before the Lord, at the presence of the God of Jacob. 

# Into what does the writer say Yahweh turned the rock and the hard rock? 

He turned the rock into a pool of water, and the hard rock into a spring of water. 

# For what reason does David pray that Yahweh would bring honor to Yahweh's name?

He asks Yahweh to bring honor to his hame for his covenant faithfulness and for his trustworthiness. 

# What does David says the nations' idols are?

He says their idols are silver and gold, the work of men's hands. 

# What are the idols not able to do?

They are not able to speak, or see, or hear, or smell. 

# What are the idols not able to do?

They are not able to speak, or see, or hear, or smell. 

# Why should everyone trust in Yahweh? 

They should trust in Yahweh because his is their help and shield. 

# Why should everyone trust in Yahweh? 

They should trust in Yahweh because his is their help and shield. 

# Why should everyone trust in Yahweh? 

They should trust in Yahweh because his is their help and shield. 

# How old must a person be for Yahweh to bless him?

Yahweh will bless those who honor him, both young and old. 

# To whom do the heavens and earth belong? 

The heavens belong to Yahweh; but the earth he has given to mankind. 

# How long does David say people will bless Yahweh?

He says they will bless Yahweh now and forevermore. 

# For what reason does the writer say he loves Yahweh?

He loves Yahweh because Yahweh hears his voice and his pleas for mercy. 

# What did the writer feel when he was surrounded by the cords of death and confronted by the snares of sheol? 

He felt anguish and sorrow. 

# Who does Yahweh protect?

Yahweh protects the naive. 

# From what was the writer's soul freed?

Yahweh freed his soul from death. 

# Where does the writer say he will serve Yahweh?

He will serve Yahweh in the land of the living. 

# Where does the writer say he will fulfill his vows to Yahweh?

He will fulfill his vows in the presence of all his people. 

# What is precious in the sight of Yahweh?

Precious in the sight of Yahweh is the death of his saints. 

# What does the writer say he will offer to Yahweh for taking away his bonds? 

He says he will offer to him the sacrifice of thanksgiving. 

# In whose presence will the writer fulfill his vows to Yahweh? 

He will fulfill his vows in the presence of all Yahweh's people. 

# Who does this writer call upon to praise Yahweh?

He calls upon all the nations and all the peoples to praise Yahweh. 

# What is great toward his people?

Yahweh's covenant faithfulness is great toward his people. 

# How long does the trustworthiness of Yahweh endure?

The trustworthiness of Yahweh endures forever. 

# What are the two reasons the writer says people should give thanks to Yahweh? 

They should give thanks to Yahweh because he is good and because his covenant faithfulness endures forever. 

# How did the Yahweh respond when the writer called out to him? 

Yahweh answered him and set him free. 

# The writer says it is better to take shelter in Yahweh than do what?

It is better to take shelter in Yahweh than to put confidence in man. 

# What does the writer say all the nations were like when they surrounded him?

He said all the nations surrounded him like bees. 

# What kind of shout is heard in the tents of the righteous?

The joyful shout of victory is heard in the tents of the righteous. 

# What has Yahweh not done when he punished the writer harshly?

Yahweh did not hand him over to death. 

# What will the writer do when Yahweh opens the gates of righteousness to him? 

The writer will enter the gates of righteousness and give thanks to Yahweh. 

# What has happened to the stone that the builders rejected? 

The stone that the builders rejected has become the cornerstone. 

# What will the people do on the day on which Yahweh has acted?

They will rejoice and be glad in it. 

# What does the writer say the people should do with the sacrifice?

They should bind the sacrifice with cords to the horns of the altar. 

# What does the writer say he will do because Yahweh is his God?

He will give thanks to Yahweh, and will exalt him. 

# How does the writer say people should seek Yahweh?

They should seek him with all their heart. 

# What does the writer say would happen if he would be firmly established in the observance of Yahweh's statutes? 

He says he would not be put to shame when he thinks of all Yahweh's commandments. 

# With what does the writer give thanks to Yahweh?

He gives thanks with a sincere heart. 

# How does the writer say a young person can keep his path pure? 

A young person can keep his path pure by obeying Yahweh's word. 

# The writer says Yahweh's words are sweeter than what?

Yahweh's words are sweeter than honey to the writer's mouth! 

# What one thing has the writer sworn and confirmed?

He has sworn and has confirmed that he will observe Yahweh's decrees. 

# Why has the writer stored up Yahweh's word in his heart?

He has stored up Yahweh's word in his heart so that he might not sin against Yahweh. 

# What does the writer claim as his heritage forever and the joy of his heart? 

He claims Yahweh's covenant decrees as his heritage forever, for they are the joy of his heart. 

# Since Yahweh is his hiding place and his shield, what is the writer waiting for?

The writer is waiting for Yahweh's word. 

# Why does Yahweh rejects all those who stray from his statutes?

He rejects all those who stray from his statutes, for those people are deceptive and unreliable. 

# In fear of what does the writer's body tremble?

His body trembles in fear of Yahweh. 

# For what does the writer wait as his eyes grow tired?

He waits for Yahweh's salvation and for his righteous word. 

# Why does the writer ask Yahweh for understanding? 

He asks for understanding so that he might know Yahweh's covenant decrees. 

# What does the writer hate? 

He hates every path of falsehood. 

# What does the unfolding of Yahweh's words give?

The unfolding of Yahweh's words gives light, and understanding to the untrained. 

# What does Yahweh always do for those who love his name?

Yahweh always turns to them and has mercy on them. 

# Why does the writer ask Yahweh redeem him from human oppression?

He asks Yahweh to redeem him so that he might observe Yahweh's instructions. 

# Why do streams of tears run down from the writer's eyes?

Streams of tears run down from his eyes because people do not observe Yahweh's law. 

# In what way has Yahweh given his covenant decrees? 

Yahweh has given his covenant decrees righteously and faithfully. 

# In what does the writer rejoice more than in all riches?

He rejoices in the way of Yahweh's covenant decrees more than in all riches. 

# What does the writer not do despite the fact that he is insignificant and despised?

He does not forget Yahweh's instructions. 

# What are Yahweh's commandments to the writer, even though distress and anguish have found him?

Though distress and anguish have found him, Yahweh's commandments are still his delight. 

# What will the writer do if Yahweh saves him?

He will observe Yahweh's covenant decrees. 

# What will the writer do with Yahweh's instructions?

He will meditate on Yahweh's instructions. 

# What did the writer learn long ago from Yahweh's covenant decrees?

He learned that Yahweh had set his covenant decrees in place forever. 

# Why does writer say that Yahweh should look on his affliction and help him? 

Yahweh should help him because the writer does not forget Yahweh's law. 

# Why is salvation far from the wicked?

Salvation is far from the wicked, for they do not love Yahweh's statutes. 

# Why does the writer view the treacherous with disgust?

He views the treacherous with disgust because they do not observe Yahweh's word. 

# How long does every one of Yahweh's decrees last?

Every one of Yahweh's decrees lasts forever. 

# Of what is the writer afraid when the princes persecute him without cause?

He is afraid of disobeying Yahweh's word. 

# How often does the writer praise Yahweh because of his righteous decrees?

He praises Yahweh seven times a day. 

# Why does the writer keep Yahweh's instructions and solemn commands?

He keeps Yahweh's instructions and solemn commands because Yahweh is aware of everything the writer does. 

# What did Yahweh promise in his word to do?

Yahweh promised in his word to help the writer as his plea comes before Yahweh. 

# Why does the writer ask Yahweh to let his tongue sing about Yahweh's word?

He wants his tongue to sing about Yahweh's word because all Yahweh's commandments are right. 

# What does the writer ask Yahweh to do when the writer has wandered off like a lost sheep?

He asks Yahweh to seek his servant, for he has not forgotten Yahweh's commandments. 

# How will the writer see marvelous things in Yahweh's law? 

He will see marvelous things in Yahweh's law when Yahweh opens his eyes. 

# What happens to the writer's soul as he longs to know Yahweh's righteous decrees?

His soul is crushed by longing to know Yahweh's righteous decrees. 

# Who does the writer say is cursed and wanders from Yahweh's commandments?

The proud are cursed and wander from Yahweh's commandments. 

# What does the writer do even though rulers plot and slander him?

He meditates on Yahweh's statutes. 

# By what means does the writer ask Yahweh to give him life?

He asks Yahweh to give him life by Yahweh's word. 

# Why does the writer want to understand the ways of Yahweh's instructions?

He wants to understand the ways of Yahweh's instructions so he can meditate on Yahweh's wondrous teachings. 

# From what path does the writer ask Yahweh to turn the writer? 

He asks Yahweh to turn him from the path of deceit. 

# Where does the writer asks Yahweh to direct the writer's heart?

He asks Yahweh to direct his heart toward Yahweh's covenant decrees and away from unrighteous gain. 

# From what does the writer ask Yahweh to turn the writer's eyes? 

He asks Yahweh to turn the writer's eyes from looking at worthless things. 

# What does the writer ask Yahweh to not take from his mouth?

He asks Yahweh to not take the word of truth from his mouth. 

# Why does the writer say that he will walk securely?

He will walk securely because he seeks Yahweh's instructions. 

# What does the writer says he dearly loves?

He dearly loves Yahweh's commandments. 

# What does the writer ask Yahweh to call to mind?

He asks Yahweh to call to mind his promise to his servant. 

# Even though the proud have scoffed at him, what has the writer not done?

The writer has not turned away from Yahweh's law. 

# The writer says Yahweh's statutes have been his songs in what kind of house?

Yahweh's statutes have been the writer's songs in the house where he temporarily lives. 

# With what did the writer request Yahweh's favor?

He earnestly requested Yahweh's favor with his whole heart. 

# What has the writer not forgotten when the cords of the wicked ensnared him?

He has not forgotten Yahweh's law. 

# The writer is a companion of what kind of people?

He is a companion of all who honor Yahweh, to all who observe his instructions. 

# Why does the writer ask Yahweh to teach him proper discernment and understanding?

He asks Yahweh to teach him proper discernment and understanding because he has believed in Yahweh's commandments. 

# What did the writer do when the arrogant smeared him with lies?

He kept Yahweh's instructions with his whole heart. 

# Why does the writer say that it is good that he has suffered?

It was good for him to suffer so that he would learn Yahweh's statutes. 

# The writer says that instruction from Yahweh's mouth is more precious to him than what?

Instruction from Yahweh's mouth is more precious to him than thousands of pieces of gold and silver. 

# Why does the writer say that those who honor Yahweh will be glad when they see the writer?

They will be glad when they see the writer because he found hope in Yahweh's word. 

# How does the writer say that Yahweh afflicted him?

In faithfulness Yahweh afflicted him. 

# The writer asks that his heart may be blameless with respect to Yahweh's statutes so that what might not happen?

He wants his heart be blameless with respect to Yahweh's statutes so that the writer may not be put to shame. 

# What do the writers' eyes long to see?

His eyes long to see Yahweh's promise. 

# How have the proud defied Yahweh's law? 

The proud have dug pits for the writer, defying Yahweh's law. 

# The writer prays that Yahweh would keep him alive so that the writer may do what?

He asks Yahweh to keep him alive so that he may keep the covenant decrees that Yahweh's has spoken. 

# How long does Yahweh's faithfulness last?

Yahweh's faithfulness lasts for all generations. 

# Why will the writer never forget Yahweh's instructions?

He will never forget Yahweh's instructions, for through them Yahweh has kept him alive. 

# What is the only thing that does not have limits?

Yahweh's commandments are broad, beyond limits. 

# Why does the writer say he has more understanding than all his teachers?

He has more understanding than all his teachers, for he meditates on Yahweh's covenant decrees. 

# What did Yahweh do when the writer called out in distress?

The writer says that Yahweh answered him. 

# What is the writer asking Yahweh to do for his soul?

The writer is asking Yahweh to rescue his soul from those who lie with and deceive with their tongues. 

# What is the writer telling the people that Yahweh will do to those with a deceitful tongue?

Yahweh will shoot them with sharp arrows and with arrowheads heated over the hot coals from wood of the broom tree. 

# Where does the writer say that he has temporarily lived and previously lived?

The writer says that he temporarily lived in Meshech and previously lived among the tents of Kedar. 

# What does the writer say about peace?

The writer says that he has lived for too long with those who hate peace and he is for peace. 

# What does the writer say about peace?

The writer says that he has lived for too long with those who hate peace and he is for peace. 

# What will the writer lift his eyes up to?

The writer says he will lift up his eyes to the mountains. 

# From whom does the writer say his help comes?

The writer says his help comes from Yahweh. 

# How will Yahweh help the writer?

Yahweh will not allow the writer's foot to slip and will protect him. 

# What does the writer say the guardian of Israel never does?

The guardian of Israel never slumbers or sleeps. 

# Who is Israel's guardian and shade?

Yahweh is Israel's guardian and the shade at their right hand. 

# What will not harm Israel?

The sun will not harm them by day nor the moon by night. 

# Who will protect Israel from all evil, keep their soul, and protect them in all they do?

Yahweh will protect them from all evil, keep their soul and protect them in all they do. 

# Who will protect Israel from all evil, keep their soul, and protect them in all they do?

Yahweh will protect them from all evil, keep their soul and protect them in all they do. 

# What was said to David to make him glad?

"Let us go to the house of Yahweh" was said to David. 

# Where are the people's feet standing?

Their feet are standing inside the gates of Jerusalem. 

# How was Jerusalem built?

Jerusalem was built like a city that is compact together. 

# Why did the tribes go up to Jerusalem?

The tribes go up to Jerusalem to give thanks to the name of Yahweh. 

# Why do the leaders sit on thrones in Jerusalem?

The leaders sit on thrones for judgement for the house of David. 

# What will happen to those who love Jerusalem?

Those who love Jerusalem will prosper. 

# What does David want to be within the walls and towers of Jerusalem?

He wants there to be peace within the walls and prosperity within the towers. 

# For whose sake will David say, "May there be peace in you."?

David says this for the sake of his brothers and companions. 

# Why does David say he will pray for Jerusalem's good?

He will pray for Jerusalem's good for he sake of the house of Yahweh. 

# To whom does the writer lift up his eyes?

The writer lifts up his eye to the one who is enthroned in the heavens. 

# How long do the eyes of the people look to Yahweh their God?

They look to Yahweh until he has mercy on them. 

# Why do the people ask Yahweh to have mercy on them?

The people are filled with humiliation, they are more than full of the scoffing of the insolent and with the contempt of the proud. 

# Why do the people ask Yahweh to have mercy on them?

The people are filled with humiliation, they are more than full of the scoffing of the insolent and with the contempt of the proud. 

# What would have happened if Yahweh had not been on the side of Israel when men rose up against them?

If Yahweh had not been on the side of Israel, the men who rose up against them would have swallowed them up alive. 

# What would have happened if Yahweh had not been on the side of Israel when men rose up against them?

If Yahweh had not been on the side of Israel, the men who rose up against them would have swallowed them up alive. 

# What would have happened if Yahweh had not been on the side of Israel when men rose up against them?

If Yahweh had not been on the side of Israel, the men who rose up against them would have swallowed them up alive. 

# What would the water, torrent and raging waters have done to Israel?

The water would have swept them away, the torrent would have overwhelmed them, and the raging waters would have drowned them. 

# What would the water, torrent and raging waters have done to Israel?

The water would have swept them away, the torrent would have overwhelmed them, and the raging waters would have drowned them. 

# What did the people do after Yahweh did not allow them to be torn by their enemy's teeth?

The people blessed Yahweh. 

# What is the escape of the Israelites like?

Their escape is like a bird out of the snare of the fowlers. 

# From where does David say the Israelite's help comes?

Their help comes from Yahweh who made heaven and earth. 

# What are those who trust in Yahweh like?

They are like Mount Zion, unshakable and forever enduring. 

# To what does the writer compare the way that Yahweh surrounds his people?

The writer compares the way Yahweh surrounds his people to the mountains that surround Jerusalem, now and forever. 

# What must not rule in the land of the righteous?

The scepter of wickedness must not rule in the land of the righteous. 

# To whom does the writer request that Yahweh do good?

He requests that Yahweh do good to those who are upright in their hearts. 

# What will happen to those who turn aside to their crooked ways?

Yahweh will lead them away with the evildoers. 

# What does the writer want to be on Israel?

The writer wants there to be peace on Israel. 

# What did it seem like when Yahweh restored well being to Zion?

It seemed like they were those who dream. 

# What filled the mouth of the people when Yahweh restored well being to Zion?

Their mouths were filled with laughter and our tongues with singing. 

# What filled the mouth of the people when Yahweh restored well being to Zion?

Their mouths were filled with laughter and our tongues with singing. 

# What does the writer request of Yahweh?

The writer requests that Yahweh restore their fortunes. 

# What will happen to those who sow in tears?

They will reap with shouts of joy. 

# What will happen to the person who goes out weeping and carrying seed for sowing?

He will return with shouts of joy, bringing his sheaves with him. 

# What happens if Yahweh does not build the house and does not guard the city?

When Yahweh does not build the house those who build it work uselessly and if Yahweh does not guard the city the watchman stands guard uselessly. 

# What does Yahweh give to his beloved?

Yahweh gives his beloved sleep. 

# What are a heritage and a reward from Yahweh?

Children are a heritage and the fruit of the womb is a reward from Yahweh. 

# What are the children of one's youth like?

Children are like arrows in the hand of the warrior. 

# When will the blessed man, who has his quiver full of children, not be put to shame?

He will not be put to shame when he confronts his enemies in the gate. 

# What happens to those who honor Yahweh and walk in his ways?

Everyone who honors Yahweh and walks in his ways is blessed. 

# What does the writer say will happen to the person who enjoys what his hands have provided?

That person will be blessed and prosper. 

# What does the writer say the wife of the blessed man is like?

She is like a fruitful vine. 

# What does the writer say the children of the blessed man will be like?

His children will be like olive plants. 

# What will happen to the man who honors Yahweh?

The man who honors Yahweh will be blessed. 

# What does the writer ask Yahweh to do for the man who is blessed from Zion?

The writer asks that the man from Zion may see the prosperity of Jerusalem all the days of his life and that he may live to see his children's children. 

# What does the writer ask Yahweh to do for the man who is blessed from Zion?

The writer asks that the man from Zion may see the prosperity of Jerusalem all the days of his life and that he may live to see his children's children. 

# How long has Israel been under attack and not defeated?

Israel has been under attack and not defeated since it's youth. 

# How long has Israel been under attack and not defeated?

Israel has been under attack and not defeated since it's youth. 

# What did the plowers do on Israel's back?

The plowers plowed on Israel's back and made their furrows long. 

# What has righteous Yahweh done for Israel?

Yahweh has cut the ropes of the wicked. 

# What does the writer want to happen to those who hate Zion?

He wants for them to all be put to shame and turned back. 

# What does the writer not want those who pass by to say?

He does not want them to say, "May the blessing of Yahweh be on you; we bless you in the name of Yahweh." 

# What does the writer cry out to Yahweh?

The writer the Lord to hear his voice and to be attentive to his pleas. 

# What does the writer cry out to Yahweh?

The writer the Lord to hear his voice and to be attentive to his pleas. 

# Why does the writer say Yahweh should be revered?

Yahweh should be revered because there is forgiveness with him. 

# Why does the writer say Yahweh should be revered?

Yahweh should be revered because there is forgiveness with him. 

# For whom does the writer's soul wait and hope?

His soul waits for Yahweh and in his word does he hope. 

# For whom does the writer's soul wait and hope?

His soul waits for Yahweh and in his word does he hope. 

# Why does the writer tell Israel to hope in Yahweh?

Yahweh is merciful, willing to forgive, and he will redeem Israel from all sins. 

# Why does the writer tell Israel to hope in Yahweh?

Yahweh is merciful, willing to forgive, and he will redeem Israel from all sins. 

# How does David describe his heart and eyes?

His heart is not proud and his eyes are not haughty. 

# What David's soul like?

His soul is stilled and quieted like a weaned child. 

# When does David tell Israel to hope in Yahweh?

He tells them to hope in Yahweh now and forever. 

# What did the writer ask Yahweh to remember?

He asked Yahweh to call to mind David's afflictions, how he swore to Yahweh, and how he vowed to the mighty one of Jacob. 

# What did the writer ask Yahweh to remember?

He asked Yahweh to call to mind David's afflictions, how he swore to Yahweh, and how he vowed to the mighty one of Jacob. 

# David vowed that he would not enter his house or sleep until he did what?

He said he would not sleep until he found a place for Yahweh, a tabernacle for the Mighty One of Jacob. 

# Where will the people go and what will they do when they get there?

They will go into God's tabernacle and will worship at his footstool. 

# How may the priests be clothed and who may shout for joy?

The priests may be clothed with integrity and God's faithful ones may shout for joy. 

# From whom should the faithful ones not turn?

They should not turn away from their anointed king. 

# What is the oath Yahweh swore to David?

Yahweh swore to be trustworthy to David. 

# Where does the writer desire to rest and live forever?

He desires to rest and live in Yahweh's chosen Zion. 

# Where does the writer desire to rest and live forever?

He desires to rest and live in Yahweh's chosen Zion. 

# What will Yahweh do for Zion?

He will abundantly bless her, satisfy her poor with bread, and clothe her priests with salvation. 

# What will Yahweh do for Zion?

He will abundantly bless her, satisfy her poor with bread, and clothe her priests with salvation. 

# Who will Yahweh clothe with shame?

He will clothe his enemies with shame. 

# What does David say about brothers?

He says it is good and pleasant for them to remain together in unity. 

# What does David say the unity of brothers is like?

It is like the precious oil that flowed down the head, beard, and garments of Aaron. It is also like the dew of Hermon, which comes down upon the mountains of Zion. 

# What does David say the unity of brothers is like?

It is like the precious oil that flowed down the head, beard, and garments of Aaron. It is also like the dew of Hermon, which comes down upon the mountains of Zion. 

# Where did Yahweh decree the blessing of life forevermore?

He decreed life forevermore upon the mountains of Zion. 

# What should all the servants of Yahweh do?

They should come, bless Yahweh, and lift up their hands to the holy place. 

# What should all the servants of Yahweh do?

They should come, bless Yahweh, and lift up their hands to the holy place. 

# Where will Yahweh, who made heaven and earth, bless his servents?

He will bless them from Zion. 

# Who should praise Yahweh?

The servants of Yahweh, those who stand in Yahweh's house, and those in the courtyards should praise Yahweh. 

# Who should praise Yahweh?

The servants of Yahweh, those who stand in Yahweh's house, and those in the courtyards should praise Yahweh. 

# Why should the servants of Yahweh praise and sing to him?

They should praise Yahweh for he is good, and they should sing for it is pleasant to do. 

# What does the writer know about Yahweh?

He knows that Yahweh is great, he is above all gods, and whatever Yahweh desires he does in heaven, earth and in the seas. 

# What does the writer know about Yahweh?

He knows that Yahweh is great, he is above all gods, and whatever Yahweh desires he does in heaven, earth and in the seas. 

# What acts does Yahweh do that show his greatness?

Yahweh brings the clouds, makes lightening bolts accompany the rain, and brings the wind out of his storehouse. 

# What did Yahweh do to the Egyptians?

He killed the firstborn man and animals of Egypt and he sent signs and wonders against Pharaoh and all his servants. 

# What did Yahweh do to the Egyptians?

He killed the firstborn man and animals of Egypt and he sent signs and wonders against Pharaoh and all his servants. 

# What did Yahweh do with the land of the nations the Israelites attacked?

He gave their land as a heritage to Israel his people. 

# What do the nations' idols look like?

They are made of silver and gold, have mouths, eyes, and ears but they do not speak, see, hear, nor breathe. 

# What do the nations' idols look like?

They are made of silver and gold, have mouths, eyes, and ears but they do not speak, see, hear, nor breathe. 

# What do the nations' idols look like?

They are made of silver and gold, have mouths, eyes, and ears but they do not speak, see, hear, nor breathe. 

# Who made the nations' idols?

The men who are like them and trust in them made them. 

# Who should bless Yahweh?

The descendants of Israel, Aaron, Levi, and those that honor Yahweh should bless him. 

# Who should bless Yahweh?

The descendants of Israel, Aaron, Levi, and those that honor Yahweh should bless him. 

# Why should the people give thanks to Yahweh?

They should give thanks to him for he is good, and his covenant faithfulness endures forever. 

# What does Yahweh do that no one else does?

Yahweh alone does great wonders. 

# Why did Yahweh do to the firstborn of Egypt?

He killed the firstborn of Egypt. 

# What did Yahweh do for Israel when he divided the Red Sea?

He made the Isrealites to pass through the middle the Red Sea. 

# How was Yahweh faithful to his people?

He led his people through the wilderness. 

# What did Yahweh do with the land of the great kings?

He gave their land as an inheritance to Israel his servant. 

# What did Yahweh do with the land of the great kings?

He gave their land as an inheritance to Israel his servant. 

# Why does the writer say to give thanks to the God of heaven?

People should give thanks to him because of his faithfulness. 

# Where were the captives when they sat down and wept?

They were by the rivers of Babylon. 

# What did the captors require the captives to sing?

Their captors required them to be happy and sing songs of Zion. 

# What does the writer want happen if he forgets Jerusalem and thinks about Yahweh no more?

He wants his right hand to forget his skill and his tongue to cling to the roof of his mouth. 

# What does the writer want happen if he forgets Jerusalem and thinks about Yahweh no more?

He wants his right hand to forget his skill and his tongue to cling to the roof of his mouth. 

# What did the writer want Yahweh to remember about the Edomites?

He wanted Yahweh to remember that on the day Jerusalem fell the Edomites said, "Tear it down, tear it down to its foundations". 

# Who does the writer want be blessed?

He wants the person who destroys Babylon to be blessed. 

# Who does the writer want be blessed?

He wants the person who destroys Babylon to be blessed. 

# What has Yahweh magnified above all?

He has magnified his word and his name above all. 

# What did Yahweh do for David when he called to him?

Yahweh answered him, and encouraged and strengthened his soul. 

# What will the kings of the earth do?

They will give thanks for Yahweh's words. 

# For whom does Yahweh care?

He cares for the lowly. 

# Who does David ask that Yahweh not forsake?

He asks that Yahweh not forsake the ones his hands made. 

# What does Yahweh understand from afar?

Yahweh understands David's thoughts from afar. 

# How does David respond to the knowledge that Yahweh completely surrounds David?

That knowledge is too much for David, it is too high, and he cannot understand it. 

# Where can David not go to escape from Yahweh's presence, because Yahweh is there?

He cannot go up to the heavens or make his bed in sheol, for Yahweh is there. 

# How are the darkness and the light different to Yahweh?

The darkness and the light are both alike to Yahweh? 

# Where did Yahweh form David?

Yahweh formed him in his mother's womb. 

# When did Yahweh record the days of David's life?

Yahweh recorded all the days of David's life in Yahweh's book even before the first one happened. 

# How does David describe God's thoughts?

They are precious and too vast to count. 

# What does David want God to do to the wicked and violent men?

David wants God to kill the wicked and get the violent men away from him. 

# What way does David want God to lead him?

David asks God to lead him in the way everlasting. 

# From whom does David need Yahweh to rescue him?

David need Yahweh to rescue him from the wicked to preserve him from violent men. 

# What does David say the wicked are like?

He says their tongues wound like serpents and they have vipers' poison on their lips. 

# What does David say the wicked are like?

He says their tongues wound like serpents and they have vipers' poison on their lips. 

# What do the violent men plan to do to David?

They plan to knock him over. 

# What have the proud set for David?

They have set a trap for him, spread a net, and set a snare. 

# To what does David ask Yahweh to listen?

David asks Yahweh to listen to his cries for mercy. 

# What does Yahweh do for David in the day of battle?

Yahweh shields David's head in the day of battle. 

# What does Yahweh do for David in the day of battle?

Yahweh shields David's head in the day of battle. 

# What does David want to overwhelm those who surround him?

David wants the mischief of their own lips to overwhelm them. 

# What does David want to happen to those who say evil things about others?

David wants anyone who says evil things about others to not be secure on the earth. 

# What will Yahweh do for the afflicted and the needy?

Yahweh will maintain the cause of the afflicted and will exercise justice for the needy. 

# What will the righteous people surely do?

The righteous people will surely give thanks to Yahweh's name. 

# What will happen the upright people?

They will live in Yahweh's presence. 

# What is David crying out to Yahweh?

He is crying out for Yahweh to come quickly and to listen to him when he calls. 

# What does David want his prayer and lifted hands to be like for Yahweh?

David wants his prayer to be like incense before Yahweh and his lifted hands to be like the evening sacrifice. 

# What does David not want his heart to do?

He wants his heart to not desire any evil thing, or participate in sinful activities with wicked men, and to not eat any of the evil men's delicacies. 

# What does David say it will be like if a righteous man hits him?

He says if a righteous man hits him, it will be kindness to him. 

# What does David say it will be like if a righteous man corrects him?

He says it will be like oil on his head. 

# Against what does David always pray?

He always prays against the deeds of the wicked people. 

# What will happen to the wicked peoples' leaders?

Their leaders will be thrown down from the top of cliffs and hear that David's own words are pleasant. 

# Who will have to say "As when one plows and breaks up the ground, so our bones have been scattered at the mouth of sheol."

The wicked people will have to say, "As when one plows and breaks up the ground, so our bones have been scattered at the mouth of sheol." 

# On whom are David's eyes?

David's eyes are on Yahweh, the Lord. 

# From what does David want Yahweh to protect him?

David wants Yahweh to protect him from the snares that have been laid for him, and from the traps of evildoers. 

# From what does David want Yahweh to protect him?

David wants Yahweh to protect him from the snares that have been laid for him, and from the traps of evildoers. 

# What does David want to happen to the wicked?

David wants the wicked to fall into their own nets while he escapes. 

# What does David pour out to Yahweh?

David pours out a lament to tell Yahweh his troubles. 

# What does Yahweh know when David's spirit is weak?

Yahweh knows David's path when his spirit is weak. 

# What does David see when he looks to the right?

David sees that there is no one who cares about him, and there is no escape for him. 

# Who does David say Yahweh was to him?

Yahweh was David's refuge and his portion in the land of the living. 

# Why does David need Yahweh to reduce him from his persecutors?

David asks Yahweh to rescue him from his persecutors because their are stronger than David. 

# Why will the righteous gather around David?

The righteous will gather around David because Yahweh has been good to him. 

# Why does David not want Yahweh to enter judgement against him?

David does not want Yahweh to enter judgement against him because in Yahweh's sight no one is righteous. 

# What has the enemy done to David?

The enemy has pursued his soul, pushed him down to the ground, and made him live in darkness. 

# What does the enemy cause to happen to David's spirit and his heart?

The enemy causes David's spirit to overwhelm him and his heart to despair. 

# How does David describe the desire of his soul for Yahweh?

David's soul thirsts for Yahweh in a parched land. 

# What would cause David to become like those who go down into the pit?

David would become like those who go down to the pit if Yahweh does not answer quickly or if he hides his face from David. 

# What does David want to hear in the morning because he trusts Yahweh?

David wants to hear Yahweh's covenant faithfulness. 

# What does David want Yahweh to do because he lifts up his soul to Yahweh?

David wants Yahweh to show him the way where he should walk. 

# What does David wants to lead him in the land of uprightness?

David wants Yahweh's good spirit to lead him in the land of uprightness. 

# What does David want Yahweh to do to David's enemies?

David asks Yahweh to cut off David's enemies and destroy all the enemies of David's life. 

# For what does Yahweh train David's hands for war and his fingers?

Yahweh trains David's hands for war and his fingers for battle. 

# Who does Yahweh notice and thinks about that surprises David?

David is surprised that Yahweh notices man and the son of man. 

# What would the mountains do if Yahweh touched them?

Yahweh would cause the mountains to smoke if he touched them. 

# How does Yahweh rescue David from the hand of foreigners?

Yahweh reaches out his hand from above and rescues David out of the waters and from the hands of foreigners. 

# On what instrument will David sing a new song to God?

David will sing a new song to God on the lute of ten strings. 

# What do the mouths of the foreigners speak?

Their mouths speak lies and their right hand is falsehood. 

# What does David want Israel's sons to be like?

He wants them to be like plants who grow to full size in their youth. 

# What does David want Israel's daughters to be like?

He wants them to be like carved corner pillars, shapely like those of a palace. 

# Who does David say are the people who are happy?

He says the people who are happy are those whose God is Yahweh. 

# Who will David extol and bless?

David will extol his God and King, blessing his name forever and ever. 

# How often does David bless God?

Every day David will bless God. 

# What will one generation praise and proclaim to the next?

One generation will praise God's deeds to the next and proclaim his mighty actions. 

# On what will David meditate?

He will meditate on the majesty of Yahweh's glory and on his marvelous deeds. 

# What will one generation declare and sing about to the next?

They will declare Yahweh's abounding goodness and sing about his righteousness. 

# What will thank and bless Yahweh?

All that Yahweh has made will give thanks to him and his faithful ones will bless him. 

# Who will speak of the glory of Yahweh's kingdom and tell of Yahweh's power?

Yahweh's faithful ones will speak of the glory of his kingdom and tell of his power. 

# How long will Yahweh's kingdom last?

Yahweh's kingdom is an everlasting kingdom and his dominion endures throughout all generations. 

# Who does Yahweh support and raise up?

Yahweh supports all who are falling and raises up all those who are bent over. 

# Whose eyes wait for Yahweh and is given food at the right time?

Everyone's eyes wait for Yahweh and are given food at the right time. 

# How does Yahweh satisfy the desires of every living thing?

Yahweh opens his hand and satisfies the desire of every living thing. 

# To whom is Yahweh near?

Yahweh is near to all those who call to him and to all who call to him in trustworthiness. 

# What does Yahweh do for those who love him?

Yahweh watches over all those who love him. 

# What will Yahweh do to all the wicked?

He will destroy all the wicked. 

# How long will the writer praise Yahweh?

He will praise Yahweh as long as he lives. 

# What should one not put their trust in?

People should not put their trust in princes or in mankind, in whom there is no salvation. 

# What happens when a person's life's breath stops?

When a person's life's breath stops, he returns to the ground; on that day his plans end. 

# Who is the one who is blessed?

The one who is blessed is the one who has the God of Jacob for his help, whose hope is in Yahweh his God. 

# What has Yahweh made?

Yahweh made heaven and earth, the sea, and all that is in them. 

# What does God do for the oppressed and the hungry?

Yahweh executes justice for the oppressed and gives food to the hungry. 

# What does Yahweh do for the blind and those who are bowed down?

Yahweh opens the eyes of the blind, and raises up those who are bowed down. 

# Who does Yahweh protect?

Yahweh protects the foreigners in the land. 

# How long will Yahweh reign?

Yahweh will reign forever, for all generations. 

# Why should Yahweh be praised?

Yahweh should be praised because it is good, pleasant and suitable. 

# How does Yahweh help his followers?

Yahweh helps rebuild Jerusalem, gathers the scattered people of Israel. 

# What does Yahweh do to the stars after he counts them?

Yahweh counts the stars and gives names all of them. 

# How great is Lord's understanding?

His understanding cannot be measured. 

# What does Yahweh do to the wicked?

Yahweh brings the wicked down to the ground. 

# How does Yahweh care for the animals and ravens?

Yahweh gives food to the animals and the young ravens when they cry. 

# In what does Yahweh find no delight and take no pleasure?

Yahweh finds no delight in the strength of horse and takes no pleasure in the strong legs of man. 

# In what does Yahweh take pleasure?

Yahweh takes pleasure in those who honor him, who hope in his covenant faithfulness. 

# With what does Yahweh satisfy the people of Jerusalem?

Yahweh satisfies them with the finest of wheat. 

# With what does Yahweh satisfy the people of Jerusalem?

Yahweh satisfies them with the finest of wheat. 

# With what does Yahweh satisfy the people of Jerusalem?

Yahweh satisfies them with the finest of wheat. 

# How do Yahweh's commandment of out to the earth?

Yahweh sends his commandment to earth and his command runs very swiftly. 

# How does Yahweh dispense the hail?

Yahweh dispenses the hail like crumbs. 

# To whom did Yahweh proclaim his word and his statutes and righteous decrees?

Yahweh proclaimed his word to Jacob, and his statutes and righteous decrees to Israel. 

# To which other nation has Yahweh proclaimed his word, statutes and decrees?

Yahweh has not proclaimed his word, statutes and decrees to any other nation. 

# Who is to praise Yahweh?

Everyone in the heavens, those in the heights, all his angels and all his angel armies are to praise Yahweh. 

# Who is to praise Yahweh?

Everyone in the heavens, those in the heights, all his angels and all his angel armies are to praise Yahweh. 

# Who is to praise Yahweh?

The sun, moon, shining stars, highest heaven and the waters above the sky are to praise Yahweh. 

# Who is to praise Yahweh?

The sun, moon, shining stars, highest heaven and the waters above the sky are to praise Yahweh. 

# Why should Yahweh be praised?

Yahweh should be praised because he gave the command and everything was created. 

# What decree will never change?

The decree of Yahweh will never change. 

# Who should praise God from the earth?

The sea creatures, all in the ocean, fire, hail, snow , clouds and wind which fulfills his word should praise Yahweh. 

# Who should praise God from the earth?

The sea creatures, all in the ocean, fire, hail, snow , clouds and wind which fulfills his word should praise Yahweh. 

# Who also should praise Yahweh?

The mountains, hills, fruit trees, cedars, wild and tame animals, creatures that crawl and birds need to praise Yahweh. 

# Who also should praise Yahweh?

The mountains, hills, fruit trees, cedars, wild and tame animals, creatures that crawl and birds need to praise Yahweh. 

# Who else should praise Yahweh?

Kings, princes young men and women, the elderly and the children need to praise Yahweh. 

# Who else should praise Yahweh?

Kings, princes young men and women, the elderly and the children need to praise Yahweh. 

# Why should Yahweh be praised?

Yahweh should be praised because his name alone is exalted and his glory extends over the earth and heavens. 

# Who are Yahweh's faithful ones?

The Israelites and the people near to him are Yahweh's faithful ones. 

# How should everyone praise Yahweh?

Everyone should sing a new song to Yahweh and sing his praise in the assembly. 

# In whom should Israel rejoice?

Israel should rejoice in the one who made them a nation, and in their king. 

# How should everyone praise Yahweh?

Everyone should praise Yahweh's name with dancing and sing praises to him with tambourine and harp. 

# In whom does Yahweh take pleasure?

Yahweh takes pleasure in his people. 

# Who does Yahweh glorify?

He glorifies the humble with salvation. 

# How should godly people rejoice?

Godly people should rejoice in victory and sing for joy. 

# What should be in the mouths of the godly?

The praises of God should be in their mouths. 

# What is the purpose of the two-edged sword in the hands of the godly?

The sword in their hand is to execute vengeance on the nations and acts of punishment on the peoples. 

# What is the purpose of the two-edged sword in the hands of the godly?

The sword in their hand is to execute vengeance on the nations and acts of punishment on the peoples. 

# What will the godly do to the kings and nobles of the other nations?

They will bind the kings with chains and the nobles with iron shackles. 

# Who will be honored when the judgement is executed?

This will be an honor for all his faithful ones. 

# Where should everyone praise God?

Everyone should praise God in his sanctuary and the mighty heavens. 

# For what should everyone praise God?

Everyone should praise God for his mighty acts and for his surpassing greatness. 

# With what instruments should everyone praise God?

Everyone should praise God with the horn, lute, harp, tambourines, dancing, stringed and wind instruments, and with cymbals. 

# With what instruments should everyone praise God?

Everyone should praise God with the horn, lute, harp, tambourines, dancing, stringed and wind instruments, and with cymbals. 

# With what instruments should everyone praise God?

Everyone should praise God with the horn, lute, harp, tambourines, dancing, stringed and wind instruments, and with cymbals. 

# Who should praise Yahweh?

Everything that has breath should praise Yahweh. 

