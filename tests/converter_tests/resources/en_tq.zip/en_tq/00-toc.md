# translationQuestions

## Table of Contents:

* [Genesis](#01-GEN.html)

* [Exodus](#02-EXO.html)

* [Leviticus](#03-LEV.html)

* [Numbers](#04-NUM.html)

* [Deuteronomy](#05-DEU.html)

* [Joshua](#06-JOS.html)

* [Judges](#07-JDG.html)

* [Ruth](#08-RUT.html)

* [1 Samuel](#09-1SA.html)

* [2 Samuel](#10-2SA.html)

* [1 Kings](#11-1KI.html)

* [2 Kings](#12-2KI.html)

* [1 Chronicles](#13-1CH.html)

* [2 Chronicles](#14-2CH.html)

* [Ezra](#15-EZR.html)

* [Nehemiah](#16-NEH.html)

* [Esther](#17-EST.html)

* [Job](#18-JOB.html)

* [Psalms](#19-PSA.html)

* [Proverbs](#20-PRO.html)

* [Ecclesiastes](#21-ECC.html)

* [Song of Solomon](#22-SNG.html)

* [Isaiah](#23-ISA.html)

* [Jeremiah](#24-JER.html)

* [Lamentations](#25-LAM.html)

* [Ezekiel](#26-EZK.html)

* [Daniel](#27-DAN.html)

* [Hosea](#28-HOS.html)

* [Joel](#29-JOL.html)

* [Amos](#30-AMO.html)

* [Obadiah](#31-OBA.html)

* [Jonah](#32-JON.html)

* [Micah](#33-MIC.html)

* [Nahum](#34-NAM.html)

* [Habakkuk](#35-HAB.html)

* [Zephaniah](#36-ZEP.html)

* [Haggai](#37-HAG.html)

* [Zechariah](#38-ZEC.html)

* [Malachi](#39-MAL.html)

* [Matthew](#41-MAT.html)

* [Mark](#42-MRK.html)

* [Luke](#43-LUK.html)

* [John](#44-JHN.html)

* [Acts](#45-ACT.html)

* [Romans](#46-ROM.html)

* [1 Corinthians](#47-1CO.html)

* [2 Corinthians](#48-2CO.html)

* [Galatians](#49-GAL.html)

* [Ephesians](#50-EPH.html)

* [Philippians](#51-PHP.html)

* [Colossians](#52-COL.html)

* [1 Thessalonians](#53-1TH.html)

* [2 Thessalonians](#54-2TH.html)

* [1 Timothy](#55-1TI.html)

* [2 Timothy](#56-2TI.html)

* [Titus](#57-TIT.html)

* [Philemon](#58-PHM.html)

* [Hebrews](#59-HEB.html)

* [James](#60-JAS.html)

* [1 Peter](#61-1PE.html)

* [2 Peter](#62-2PE.html)

* [1 John](#63-1JN.html)

* [2 John](#64-2JN.html)

* [3 John](#65-3JN.html)

* [Jude](#66-JUD.html)

* [Revelation](#67-REV.html)

