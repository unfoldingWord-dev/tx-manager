# Who was the author of these proverbs?

Solomon, king of Israel, was the author of these proverbs. 

# How do these proverbs teach people to live?

These proverbs teaches people to live by doing what is right, just, and fair. 

# What can the wise receive by listening to these proverbs?

The wise can increase their learning by listening to these proverbs. 

# What is the beginning of knowledge?

The fear of Yahweh is the beginning of knowledge. 

# To whose instruction should a son listen?

A son should listen to instruction from his father and mother. 

# What should a son do if sinners try to entice him with sin?

A son should refuse to follow those who try to entice him with sin. 

# With what do those who are sinning plan to fill their houses?

Those who are sinning plan to fill their houses with what they steal from others. 

# What do those who are sinning hurry to do?

Those who are sinning hurry to shed blood. 

# What does unjust gain do to those who hold on to it?

Unjust gain takes away the lives of those who hold on to it. 

# Who cries aloud in the streets, open places, and city gates?

Wisdom cries aloud in the streets, open places, and city gates. 

# Who cries aloud in the streets, open places, and city gates?

Wisdom cries aloud in the streets, open places, and city gates. 

# What did those who lacked wisdom do when Wisdom called out to them?

Those who lacked wisdom refused to listen and did not pay attention when Wisdom called out to them. 

# What did those who lacked wisdom do when Wisdom called out to them?

Those who lacked wisdom refused to listen and did not pay attention when Wisdom called out to them. 

# What will Wisdom do when calamity comes on those who lacked wisdom?

Wisdom will laugh when calamity comes on those who lacked wisdom. 

# What will Wisdom do when those who lacked wisdom call upon her?

Wisdom will not answer when those who lacked wisdom call upon her. 

# With what will those who lacked wisdom be filled?

Those who lacked wisdom will be filled with the fruit of their schemes. 

# How will those live who listen to Wisdom?

Those who listen to wisdom will live in safety. 

# What does Wisdom want her son to treasure?

Wisdom wants her son to treasure her commandments. 

# How should the son seek and search for understanding?

The son should seek understanding as silver, and search for it as a hidden treasure. 

# How should the son seek and search for understanding?

The son should seek understanding as silver, and search for it as a hidden treasure. 

# If the son seeks and searches for understanding, what will he find?

The son will find the knowledge of God. 

# What is Yahweh for those who walk in integrity?

Yahweh is a shield for those who walk in integrity. 

# When wisdom comes into the son's heart, what will he understand?

The son will understand righteousness, justice, equity, and every good path. 

# From what will discretion and understanding rescue the son?

Discretion and understanding will rescue the son from the way of evil and from those who walk in the ways of darkness. 

# From what will discretion and understanding rescue the son?

Discretion and understanding will rescue the son from the way of evil and from those who walk in the ways of darkness. 

# From what will discretion and understanding rescue the son?

Discretion and understanding will rescue the son from the way of evil and from those who walk in the ways of darkness. 

# How do those who walk in the ways of darkness hide their tracks?

Those who walk in the ways of darkness hide their tracks using deception. 

# What does the immoral woman forsake and forget?

The immoral woman forsakes the companion of her youth, and forgets the covenant of her God. 

# To where do the immoral woman's tracks lead?

The immoral woman's tracks lead to those in the grave. 

# In whose ways should the son walk?

The son should walk in the way of good people and those who do right. 

# What will happen to those who do right?

Those who do right will make a home in the land. 

# What will happen to those who are wicked?

Those who are wicked will be cut off from the land. 

# What will Wisdom's commands and teachings add to her son?

Wisdom's commands and teachings will add years of life and peace to her son. 

# What will Wisdom's commands and teachings add to her son?

Wisdom's commands and teachings will add years of life and peace to her son. 

# Where must covenant faithfulness and trustworthiness be written?

Covenant faithfulness and trustworthiness must be written on the tablet of the heart. 

# On what must the son not lean?

The son must not lean on (relay on) his own understanding. 

# How must the son not see himself?

The son must not see himself as wise. 

# What must the son do with his wealth?

The son must honor Yahweh with his wealth. 

# Who does Yahweh discipline?

Yahweh disciplines those he loves. 

# Wisdom is better than what?

Wisdom is better than silver and gold. 

# What are all the paths of wisdom?

All the paths of wisdom are peace. 

# What did Yahweh do by wisdom?

By wisdom, Yahweh founded the earth. 

# What will be life to the son's soul?

Sound judgment and discernment will be life to the son's soul. 

# What will be life to the son's soul?

Sound judgment and discernment will be life to the son's soul. 

# If the son walks in wisdom, what will happen when he lies down?

When he lies down, he will not be afraid and his sleep will be sweet. 

# Of what should the son not be afraid?

The son should not be afraid of sudden terror or devastation. 

# What should the son do for those who deserve it?

The son should not withhold good from those who deserve it. 

# What should the son not do to his neighbor?

The son should not make a plan to harm his neighbor. 

# Who is wicked to Yahweh?

The lying person is wicked to Yahweh. 

# What does Yahweh do to the mockers?

Yahweh mocks the mockers. 

# What do the wise inherit?

The wise inherit honor. 

# What should the sons not forget?

The sons should not forget their father's instruction. 

# What should the sons not forget?

The sons should not forget their father's instruction. 

# How did the father tell the son he would live?

The father told the son he would live by keeping the father's commands. 

# What will wisdom do for the son if the son does not abandon her, but loves her?

Wisdom will watch over him and keep him safe. 

# What will wisdom do for the son if the son cherishes and embraces her?

Wisdom will exalt him, honor him, put a wreath on his head, and give him a beautiful crown. 

# What will wisdom do for the son if the son cherishes and embraces her?

Wisdom will exalt him, honor him, put a wreath on his head, and give him a beautiful crown. 

# Down what kind of path does the father lead the son?

The father leads the son down the straight path. 

# On to what must the son hold, for it is his life?

The son must hold on to discipline, for it is his life. 

# What path must the son avoid?

The son must avoid the path of the wicked. 

# What path must the son avoid?

The son must avoid the path of the wicked. 

# What must the wicked do before they can sleep?

The wicked must do evil before they can sleep. 

# What is the path of the righteous like?

The path of the righteous is like a first light that grows brighter. 

# What is the path of the wicked like?

The path of the wicked is like darkness. 

# Why must the son guard his heart with all diligence?

The son must guard his heart with all diligence for from it flow the springs of life. 

# What kind of speech and talk must the son put away?

The son must put away crooked speech and corrupt talk. 

# Where must the son fix his gaze?

The son must fix his gaze straight before him. 

# What will the son learn if he listens carefully to understanding?

The son will learn about discretion if he listens carefully to understanding. 

# In the end, what is an adulteress like?

In the end, an adulteress is bitter as wormwood. 

# To where do an adulteress' feet go?

An adulteress' feet go down to death, all the way to Sheol. 

# What path should wise sons take regarding an adulteress and her house?

Wise sons should take a path far from an adulteress and not near her house. 

# What will the sons give away if they become involved with an adulteress?

If they become involved with an adulteress, the sons will give away their honor and years of their lives. 

# What will happen at the end of their lives if the sons become involved with an adulteress?

If they become involved with an adulteress, their flesh and body will waste away. 

# What regret will the sons speak at the end of their lives if they become involved with an adulteress?

If they become involved with an adulteress, they will say at the end of their lives that they regret having hated discipline and having rejected correction. 

# From where should the sons drink?

The sons should drink water from their own cistern and from their own well. 

# With whom should the sons rejoice?

The sons should rejoice with the wife of their youth. 

# With what should the sons be captivated?

The sons should be captivated by the love of the wife of their youth. 

# What does Yahweh see?

Yahweh sees everything a person does. 

# What will seize and hold tight the wicked person?

His sin will seize and hold the wicked person. 

# How could the son lay a trap for himself?

The son could lay a trap for himself by giving his promise for a loan of someone he does not know. 

# How could the son lay a trap for himself?

The son could lay a trap for himself by giving his promise for a loan of someone he does not know. 

# What must the son do to save himself?

To save himself the son must go to his neighbor and beg to be released from his promise. 

# What should a lazy person study?

A lazy person should study the ant. 

# What does the ant do in the summer?

In the summer, the ant prepares and stores its food. 

# What will happen to the lazy person who does not rise from his slumber?

Poverty will come on the lazy person who does not rise from his slumber. 

# By what does a wicked man live?

A wicked man lives by the crookedness of his speech. 

# What will happen to the wicked man because of his evil plots?

Disaster will overtake the wicked man in an instant. 

# How many things does Yahweh hate and how many things are disgusting to him?

There are six things that Yahweh hates, seven that are disgusting to him. 

# What kind of feet does Yahweh hate?

Yahweh hates the feet that quickly run to do evil. 

# What kind of witness does Yahweh hate?

Yahweh hates the witness who speaks out lies. 

# What are "the commands" and "the teaching" likened to?

The commands are likened to a lamp and the teachings are likened to a light. 

# What can sleeping with the wife of another cost the son?

Sleeping with the wife of another can cost the son his very life. 

# Why might people not despise a thief if he steals?

People might not despise a thief if he steals in order to satisfy his need when he is hungry. 

# Who does one who commits adultery destroy?

One who commits adultery destroys himself. 

# What will the one who takes revenge against adultery not accept?

The one who takes revenge against adultery will not accept compensation. 

# What must the son keep and store up in order to live?

The son must keep and store up his father's commands and instruction. 

# What must the son keep and store up in order to live?

The son must keep and store up his father's commands and instruction. 

# From who does wisdom and understanding keep the son?

Wisdom and understanding keep the son from the seductive woman. 

# From who does wisdom and understanding keep the son?

Wisdom and understanding keep the son from the seductive woman. 

# What did Solomon see as he looked out through the lattice?

Solomon saw many untaught young men and among them a young man who had no sense. 

# What did Solomon see as he looked out through the lattice?

Solomon saw many untaught young men and among them a young man who had no sense. 

# How was the woman that the young man met dressed?

The woman was dressed like a prostitute. 

# What does the woman do at every corner?

The woman lies in wait at every corner. 

# What had the woman made earlier in the day?

Earlier in the day, the woman had made her peace offering. 

# What had the woman been eagerly seeking?

The woman had been eagerly seeking the face of the young man. 

# What does the woman invite the young man to do?

The woman invites the young man to go with her to her bed until morning. 

# What does the woman invite the young man to do?

The woman invites the young man to go with her to her bed until morning. 

# What does the woman invite the young man to do?

The woman invites the young man to go with her to her bed until morning. 

# Where is the woman's husband?

The woman's husband is away on a long journey. 

# In what way does the young man walk after the woman?

The young man walks after the woman like an ox to the slaughter or like a deer caught in a trap. 

# What will the young man's actions cost him?

The young man's actions will cost him his life. 

# What wise instruction is the young man given about the woman?

The young man is wisely instructed to not go astray into her path. 

# On what road is the woman's house?

The woman's house is on the road to Sheol. 

# Who calls out beside the entrance to the city?

Wisdom calls out beside the entrance to the city. 

# Who calls out beside the entrance to the city?

Wisdom calls out beside the entrance to the city. 

# Who calls out beside the entrance to the city?

Wisdom calls out beside the entrance to the city. 

# To whom does Wisdom call?

Wisdom calls to the children of mankind. 

# What kinds of things does Wisdom speak?

Wisdom speaks of noble things and of what is trustworthy. 

# What kinds of things does Wisdom speak?

Wisdom speaks of noble things and of what is trustworthy. 

# What is Wisdom more valuable than?

Wisdom is more valuable than jewels. 

# What do those who fear Yahweh hate?

Those who fear Yahweh hate evil, pride, arrogance, and perverted speech. 

# How do kings and princes who have Wisdom govern?

Kings and princes who have Wisdom govern justly. 

# How do kings and princes who have Wisdom govern?

Kings and princes who have Wisdom govern justly. 

# What is the fruit of Wisdom better than?

The fruit of Wisdom is better than gold and silver. 

# What will Wisdom give to those who love her?

Wisdom will give an inheritance to those who love her. 

# When was Wisdom set up?

Wisdom was set up from ages long ago, from the first. 

# Where was Wisdom when Yahweh made the earth and heavens?

Wisdom was there when Yahweh made the earth and heavens. 

# Where was Wisdom when Yahweh made the earth and heavens?

Wisdom was there when Yahweh made the earth and heavens. 

# What was Wisdom doing beside Yahweh when Yahweh made everything?

Wisdom was beside Yahweh as a master craftsman when Yahweh made everything. 

# What was Wisdom's delight?

Wisdom's delight was mankind. 

# What does one who finds Wisdom also find?

One who finds Wisdom also finds life and the favor of Yahweh. 

# What does one who fails to find Wisdom also find?

One who fails to find Wisdom also finds death. 

# What has Wisdom built?

Wisdom has built her own house. 

# Who are the invitations that Wisdom sends out directed to?

The invitations Wisdom sends out are directed to the untaught, to those who have no sense. 

# Who are the invitations that Wisdom sends out directed to?

The invitations Wisdom sends out are directed to the untaught, to those who have no sense. 

# What does Wisdom say the untaught should leave behind?

Wisdom says the untaught should leave behind their untaught ways. 

# What happens to one who reproves a mocker?

One who reproves a mocker invites abuse and will be hurt and hated. 

# What happens to one who reproves a mocker?

One who reproves a mocker invites abuse and will be hurt and hated. 

# What happens to one who instructs a wise man?

One who instructs a wise man is loved. 

# What is the beginning of wisdom?

The fear of Yahweh is the beginning of wisdom. 

# What is understanding?

The knowledge of the Holy One is understanding. 

# What are the characteristics of a foolish woman?

A foolish woman is noisy, untaught, and knows nothing. 

# How can stolen and secret things initially be to the one who gets them?

Stolen and secret things can initially be sweet and pleasant to the one who gets them. 

# Who are in the foolish woman's house?

The dead in the depths of Sheol are in the woman's house. 

# How does a father react to a wise child?

A wise child makes his father rejoice. 

# What does Yahweh do to the cravings of the wicked?

Yahweh frustrates the cravings of the wicked. 

# What is the result of a lazy hand?

A lazy hand causes a person to be poor. 

# What do those who do what is right receive from God?

Those who do what is right receive gifts from God. 

# What will happen to a talkative fool?

A talkative fool will come to ruin. 

# What does love cover?

Love covers over all offenses. 

# What is found on the lips of a discerning person?

Wisdom is found on the lips of a discerning person. 

# What happens to the one who rejects reproof?

The one who rejects reproof is led astray. 

# What is not lacking when there are many words?

Transgression (sin) is not lacking when there are many words. 

# What do the good gifts of Yahweh bring?

The good gifts of Yahweh bring wealth. 

# What are the wicked like?

The wicked are like a storm that passes by and is no more. 

# What is like smoke in the eyes?

The sluggard is like smoke in the eyes to those who send him. 

# What will the years of the wicked be?

The years of the wicked will be short. 

# Who does the way of Yahweh protect?

The way of Yahweh protects those who have integrity. 

# What comes out of the mouth of those doing right?

Out of the mouth of those doing right comes the fruit of wisdom. 

# What comes before disgrace?

Pride comes before disgrace. 

# What is valuable on the day of wrath?

Having done right is valuable on the day of wrath. 

# What traps the treacherous (wicked)?

The treacherous are trapped by their cravings. 

# What keeps a person away from trouble?

Doing what is right keeps a person away from trouble. 

# How does the godless person destroy his neighbor?

The godless person destroys his neighbor with his mouth. 

# What does a faithful person do instead of slandering?

A faithful person keeps a matter covered instead of slandering. 

# What should a person not do for a stranger because it will bring harm to himself?

A person should not guarantee a loan for a stranger. 

# How does a wicked person get his wages?

A wicked person lies to get his wages. 

# In whom does Yahweh delight?

Yahweh delights in those whose ways are blameless. 

# Of what can everyone be sure?

Everyone can be sure that the wicked will not go unpunished. 

# What happens to the one who sows seed?

The one who sows seeds will accumulate even more. 

# What does the one who gives water to others receive?

The one who gives water to others receives water for himself. 

# What happens to the one who trusts in his riches?

The one who trusts in his riches will fall. 

# Who are like a tree of life?

Those who do right are like a tree of life. 

# Who will receive what they deserve?

Those who do right, and much more the wicked and the sinner will receive what they deserve. 

# What does a stupid person hate?

A stupid person hates correction. 

# Who does Yahweh condemn?

Yahweh condemns a man who makes evil plans. 

# What is a husband's crown?

A worthy wife is a husband's crown. 

# What kind of advice do the wicked give?

The wicked give deceitful advice. 

# What happens to the house of those who do right?

The house of those who do right will stand. 

# Who cares about the needs of his animal?

The one who does right cares about the needs of his animal. 

# What traps an evil person?

An evil person is trapped by his wicked talk. 

# How does the way of a fool look in his own eyes?

The way of a fool is right in his own eyes. 

# What are words spoken rashly like?

Words spoken rashly are like the thrusts of a sword. 

# What is in the heart of those who plan to do evil?

Deceit is in the heart of those who plan to do evil. 

# What does Yahweh hate?

Yahweh hates lying lips. 

# To what will the lazy be subject?

The lazy will be subject to forced labor. 

# Where does the way of the wicked lead them?

The way of the wicked leads them astray. 

# What do those who walk in the right way find?

Those who walk in the right way find life. 

# What does a wise son hear?

A wise son hears his father's instruction. 

# How does a person protect his life?

A person protects his life by guarding his mouth. 

# Who craves, but gets nothing?

The lazy craves, but gets nothing. 

# How are some truly wealthy?

Some are truly wealthy by giving everything away. 

# What kind of threat will a poor person never receive?

A poor person will never receive a ransom threat. 

# What does pride breed?

Pride breeds only conflict. 

# How does wealth dwindle away?

Wealth dwindles away when there is too much vanity. 

# What is a fountain of life?

The teaching of the wise is a fountain of life. 

# Out of what do the wise act in every decision?

The wise act out of knowledge in every decision. 

# What will come to him who learns from correction?

Honor will come to him who learns from correction. 

# With whom should a person walk in order to be wise?

In order to be wise, a person should walk with wise people. 

# For whom is a sinner's wealth stored up?

A sinner's wealth is stored up for the one who does right. 

# How does a parent show love for his child?

A parent shows love for his child by being careful to discipline him. 

# In what condition is the stomach of the wicked?

The stomach of the wicked is always hungry. 

# What does a wise woman do?

A wise woman builds her house. 

# Who despises Yahweh?

The one who is dishonest in his ways despises Yahweh. 

# What does a faithful witness not do?

A faithful witness does not lie. 

# What will not be found on the lips of a foolish person?

Knowledge will not be found on the lips of a foolish person. 

# What will happen to the house of the wicked?

The house of the wicked will be destroyed. 

# What will happen to the tent of the upright?

The tent of the upright will flourish. 

# What will someone who is not faithful get?

Someone who is not faithful will get what his ways deserve. 

# What does a fool do when he is warned?

A fool confidently dismisses a warning. 

# What does someone who is quick to become angry do?

Someone who is quick to become angry does foolish things. 

# To whom will the evil bow down?

The evil will bow down before those who are good. 

# What do those receive who plan to do good?

Those who plan to do good receive covenant faithfulness and trustworthiness. 

# What comes with all hard work?

With all hard work comes a profit. 

# What is a fountain of life?

The fear of Yahweh is a fountain of life. 

# Who exalts folly?

The quick to get angry exalts folly. 

# Who curses his Maker by his actions?

The one who oppresses the poor curses his Maker. 

# What exalts a nation?

Doing what is right exalts a nation. 

# What turns away wrath?

A gentle answer turns away wrath. 

# Over whom does Yahweh watch?

Yahweh watches over the evil and the good. 

# What is a fool's attitude toward his father's discipline?

A fool has contempt for his father's discipline. 

# What kind of sacrifice does Yahweh hate?

Yahweh hates the sacrifice of the wicked. 

# What awaits anyone who forsakes the way?

Harsh discipline awaits anyone who forsakes the way. 

# What makes the face cheerful?

A joyful heart makes the face cheerful. 

# What is better than great treasure with confusion?

A little with the fear of Yahweh is better than great treasure with confusion. 

# What kind of person quiets a quarrel?

A person who is slow to anger quiets a quarrel. 

# What does a wise son bring to his father?

A wise son brings joy to his father. 

# What causes plans to succeed?

Numerous advisers cause plans to succeed. 

# What does Yahweh tear down?

Yahweh tears down the legacy of the proud. 

# What does the one who does right do before answering?

The one who does right ponders before answering. 

# What does the wise person do when someone corrects him?

The wise person pays attention when someone corrects him. 

# What comes before honor?

Humility comes before honor. 

# How do all of a person's ways appear to himself?

All of a person's ways are pure in his own eyes. 

# For what has Yahweh made everything?

Yahweh has made everything for its purpose. 

# By what is iniquity (sin) forgiven?

By covenant faithfulness and trustworthiness iniquity (sin) forgiven. 

# Once a person plans out his way, what does Yahweh do?

Once a person plans out his way, Yahweh directs his steps. 

# How is a throne established?

A throne is established by doing what is right. 

# What is a messenger of death?

A king's wrath is a messenger of death. 

# What should be chosen more than gold and silver?

Wisdom and understanding should be chosen more than gold and silver. 

# What comes before a downfall?

A haughty spirit comes before a downfall. 

# How does a person find what is good in what they are taught?

A person who contemplates what he is taught finds what is good. 

# What does the heart of the wise do for his mouth?

The heart of the wise gives insight to his mouth. 

# Even though a way may seem right to a man, where can it lead?

Even though a way may seem right to a man, it may lead to death. 

# What separates close friends?

Gossip separates close friends. 

# What is the one who winks the eye doing?

The one who winks the eye is plotting evil things. 

# What is a crown of glory?

Gray hair is a crown of glory. 

# Who is stronger than one who conquers a city?

One who rules his spirit is stronger than one who conquers a city. 

# How is the decision of the lots made?

The decision of the lots is made by Yahweh. 

# What does a wise servant do with a shameful son?

A wise servant rules over a shameful son. 

# To whom does a liar pay attention?

A liar pays attention to those who say evil things. 

# What happens to those who rejoice at misfortune?

Those who rejoice at misfortune will not go unpunished. 

# How is a bribe like a magic stone?

A bribe is like a magic stone because the one who gives it succeeds wherever he turns. 

# Even what fails to deeply affect a fool?

Even a hundred blows fail to deeply affect a fool. 

# What is worse than meeting a bear robbed of her cubs?

Meeting a fool in his foolishness is worse than meeting a bear robbed of her cubs. 

# What should a person do before a dispute breaks out?

A person should walk away before a dispute breaks out. 

# What kind of people are an wicked to Yahweh?

A person who acquits the wicked or condemns those who do right is wicked to Yahweh. 

# What does a man having no sense do?

A man having no sense makes binding promises for his neighbor's debts. 

# What causes a person to fall into calamity?

An evil tongue causes a person to fall into calamity. 

# What is good medicine?

A cheerful heart is good medicine. 

# What is a foolish son to his father and mother?

A foolish son is a grief to his father and bitterness to his mother. 

# How can a fool be considered wise?

A fool can be considered wise if he keeps silent. 

# In what does a fool not find pleasure?

A fool finds no pleasure in understanding. 

# What comes with a wicked person?

Contempt, shame, and reproach come with a wicked person. 

# What do a fool's lips bring him?

A fool's lips bring him conflict. 

# What are like delicious morsels?

The words of a gossip are like delicious morsels. 

# What is a strong tower?

The name of Yahweh is a strong tower. 

# What is the attitude of a person before his downfall?

Before his downfall, a person's heart is proud. 

# What is something very difficult to bear?

A broken spirit is something very difficult to bear. 

# Who seems right at first?

The first to plead his case seems right. 

# What is harder to win than a strong city?

An offended brother is harder to win than a strong city. 

# What are in the power of the tongue?

Death and life are in the power of the tongue. 

# How does a rich person answer others?

A rich person answers others harshly. 

# What must a person have in addition to desire?

A person must have knowledge in addition to desire. 

# What will happen to a person who is a false witness?

A false witness will not go unpunished. 

# What happens when a poor man calls out to his friends?

When a poor man calls out to his friends, they are gone. 

# What does a person do who loves his own soul?

A person who loves his own soul gets wisdom. 

# What does a person with discretion do when offended?

A person with discretion overlooks an offense. 

# What is like a constant dripping of water?

A quarreling wife is like a constant dripping of water. 

# From where does a prudent wife come?

A prudent (wise) wife is from Yahweh. 

# How does a person lend to Yahweh?

One who is kind to the poor lends to Yahweh. 

# Who will have to be rescued a second time?

A hot-tempered (angry) person will have to be rescued a second time. 

# How can a person become wise by the end of his life?

A person can become wise by the end of his life by listening to advice and accepting instruction. 

# What leads people to life?

Honor for Yahweh leads people to life. 

# What is a sluggard unable to do?

A sluggard is unable to even bring his hand up from the dish to his mouth. 

# What does a child bring who robs his father and chases his mother away?

A child who robs his father and chases his mother away brings shame and reproach. 

# What makes justice a mockery?

A corrupt witness makes justice a mockery. 

# What happens to someone who angers the king?

Someone who angers the king forfeits his life. 

# Into what does every fool jump?

Every fool jumps into an argument. 

# What kind of person is difficult to find?

A faithful person is difficult to find. 

# What is something that no one can say about himself?

No one can say about himself, "I have kept my heart clean; I am free from sin." 

# By what is even a youth known?

Even a youth is known by his actions. 

# Loving what brings a person to poverty?

Loving sleep brings a person to poverty. 

# What are like a precious jewel?

Lips of knowledge are like a precious jewel. 

# What does bread gained by deceit taste like afterward?

Bread gained by deceit tastes like gravel afterward. 

# What happens to a person who curses his father or mother?

A person who curses his father or mother will have his lamp snuffed out. 

# Instead of trying to pay someone back for a wrong, what should a person do?

Instead of trying to pay someone back, a person should wait for Yahweh to rescue him. 

# What is it a snare to do rashly?

It is a snare to make a vow rashly. 

# What preserves the king?

Covenant faithfulness and trustworthiness preserve the king. 

# What is the glory of young men?

The glory of young men is their strength. 

# What does Yahweh direct wherever he pleases?

Yahweh directs a king's heart wherever he pleases. 

# What is more acceptable to Yahweh than sacrifice?

To do what is right and just is more acceptable to Yahweh than sacrifice. 

# What happens to someone who acquires riches by a lying tongue?

Someone who acquires riches by a lying tongue is killed by that snare. 

# Why are the wicked swept away?

The wicked are swept away because they refuse to do what is just. 

# What is not seen in the eyes of the wicked?

Kindness is not seen in the eyes of the wicked. 

# Who learns wisdom when a mocker is punished?

The untaught learn wisdom when a mocker is punished. 

# What does a secret gift accomplish?

A secret gift appeases anger. 

# Where does one who wanders from understanding rest?

One who wanders from understanding rests in the assembly of the dead. 

# Where is it better to live than with a complaining wife?

It is better to live in the desert than with a complaining wife. 

# What is a wise man able to bring down?

A wise man is able to bring down the stronghold of the city of the mighty. 

# What is the name for a proud and haughty person?

A proud and haughty person is called a "mocker." 

# What kind of sacrifice is detestable?

The sacrifice of the wicked is detestable. 

# What cannot stand against Yahweh?

No wisdom, understanding, or advice can stand against Yahweh. 

# Who gives the victory in the day of battle?

Yahweh gives the victory in the day of battle. 

# What do the rich and poor have in common?

Yahweh is the maker of both the rich and poor. 

# For what is the reward riches, honor, and life?

For humility and fear of Yahweh the reward is riches, honor, and life. 

# If a child is taught the way he should go, what will he not do when he grows old?

If a child is taught the way he should go, he will not turn away from that instruction when he grows old. 

# What is the relationship between the one who borrows and the one who lends?

The one who borrows is a slave to the one who lends. 

# What will cease if the mocker is driven away?

Strife, disputes, and insults will cease if the mocker is driven away. 

# What excuse does a lazy person use?

A lazy person says there is a lion in the streets as an excuse. 

# What do those who fall for an adulteress stir up?

Those who fall for an adulteress stir up Yahweh's anger against them. 

# What drives foolishness from a child?

The rod of discipline drives foolishness from a child. 

# In whom should a person trust?

A person should trust in Yahweh. 

# What must not be done to the poor and needy?

The poor and needy must not be robbed or crushed. 

# What will Yahweh do to those who rob the poor?

Yahweh will rob the life of those who rob the poor. 

# Why must a person not make a friend of someone ruled by anger?

A person must not make a friend of someone ruled by anger because the person will learn his ways and be entangled in a snare. 

# What could a person lose if they cannot pay their debts?

A person could lose their bed if they cannot pay their debts. 

# What must not be removed?

The ancient boundary stone set by the fathers must not be removed. 

# When should a person observe carefully what is before him?

When a person sits to eat with a ruler, he should carefully observe what is before him. 

# A wise person knows when to stop doing what?

A wise person knows when to stop working too hard to try to become rich. 

# What happens when a person lights his eyes upon money?

When a person lights his eyes upon money, it is gone. 

# Why is the heart of an evil man not with you when he invites you to eat and drink?

The heart of an evil man is not with you because he counts the price of the food. 

# How does a fool react to wise words?

A fool despises wise words. 

# Who will plead the cause of orphans?

Their strong Redeemer will plead the cause of orphans. 

# What should not be withheld from a child?

Discipline should not be withheld from a child. 

# What makes the inmost being of a father rejoice?

When his son speaks what is right, the inmost being of a father rejoices. 

# With whom should a person not associate?

A person should not associate with drunkards or gluttonous eaters. 

# What should a person buy?

A person should buy truth, wisdom, discipline, and understanding. 

# What should a son give to his father?

A son should give his father his heart. 

# What does another's man's wife increase among humanity?

Another man's wife increases the number of traitors among humanity. 

# Who has woe and fights?

The one who lingers over wine has woe and fights. 

# Who has woe and fights?

The one who lingers over wine has woe and fights. 

# What do the eyes of one who looks at the wine when it is red see?

One who looks at the wine when it is red sees strange things. 

# What does the drunkard say he will do when he wakes up?

The drunkard says he will seek another drink when he wakes up. 

# Of whom should a person not be envious?

A person should not be envious of those who are evil. 

# By what is a house established?

By understanding a house is established. 

# What is better than a person who is strong?

A person who has knowledge is better than a person who is strong. 

# What do people call a person who plans to do evil?

People call a person who plans to do evil a master of schemes. 

# How is a person's strength shown to be small?

When a person shows his cowardice in the day of trouble, he shows his strength to be small. 

# What does God give each person?

God gives each person what he deserves. 

# What do the wicked lie in wait to do?

The wicked lie in wait to attack the house of those who do right. 

# What will Yahweh do if a person celebrates when his enemy falls?

Yahweh will see and disapprove, and turn away his wrath from the enemy. 

# What will Yahweh do if a person celebrates when his enemy falls?

Yahweh will see and disapprove, and turn away his wrath from the enemy. 

# What happens to the lamp of the wicked?

The lamp of the wicked goes out. 

# With whom should a person not associate?

A person should not associate with those who rebel against the king. 

# What will happen to the one who says to the guilty, "You are in the right."?

That person will be cursed by peoples and hated by nations. 

# What is like a kiss on the lips?

An honest answer is like a kiss on the lips. 

# What should a person not say about his neighbor?

A person should not say that he will pay back his neighbor for what he has done. 

# What did the field of the lazy man look like?

In the lazy man's field, the thorns grew up, the ground had nettles, and the wall was broken down. 

# What did the field of the lazy man look like?

In the lazy man's field, the thorns grew up, the ground had nettles, and the wall was broken down. 

# What comes upon the lazy man like a robber?

Poverty comes upon the lazy man like a robber. 

# Who was the author of this proverb?

King Solomon was the author of this proverb. 

# What is it the glory of God to do?

It is the glory of God to conceal a matter. 

# How is the throne of the king established?

By removing the wicked from the presence of the king, the throne of the king is established. 

# What is better than standing in the place designated for the great?

Waiting for the king to say to you, "Come up here," is better than standing in the place designated for the great. 

# If you have witnessed something concerning your neighbor, why should you not be quick to bring it to trial?

You should not be quick to bring it to trial because your neighbor may put you to shame. 

# If you have witnessed something concerning your neighbor, why should you not be quick to bring it to trial?

You should not be quick to bring it to trial because your neighbor may put you to shame. 

# What does a faithful messenger do for his masters?

A faithful messenger refreshes the soul of his masters. 

# With what can a ruler be persuaded?

With patience a ruler can be persuaded. 

# How could your neighbor become tired of you?

Your neighbor could become tired of you if you set your foot in his house too often. 

# What is like a foot that slips?

An unfaithful man in whom you trust is like a foot that slips. 

# What should you do for your enemy?

You should give your enemy food to eat and water to drink. 

# What will Yahweh do for the one who gives his enemy food and drink?

Yahweh will reward the one who gives his enemy food and drink. 

# What does not alight on a person?

An undeserved curse does not alight on a person. 

# What will a person become if he joins in the folly of a fool?

A person who joins in the folly of a fool will become a fool. 

# What is like cutting off one's own feet?

Sending a message by the hand of a fool is like cutting off one's own feet. 

# One who hires a fool is like what?

One who hires a fool is like an archer who wounds everybody. 

# Why is a fool like a dog who returns to his vomit?

A fool is like a dog who returns to his vomit because a fool repeats his folly. 

# What is a door turning on its hinges like?

A door turning on its hinges is like a lazy person upon his bed. 

# How does a lazy person appear in his own eyes?

A lazy person appears wiser than seven men with discernment in his own eyes. 

# What does a person say after deceiving his neighbor?

A person says, "Was I not telling a joke?" after deceiving his neighbor. 

# What does a quarrelsome person kindle?

A quarrelsome person kindles strife. 

# How does a person disguise the fact that he hates others?

A person who hates others disguises it with his lips. 

# What happens to the person who digs a pit?

The person who digs a pit will fall into it. 

# What does a flattering mouth bring about?

A flattering mouth brings about ruin. 

# Why should a person not boast about tomorrow?

A person should not boast about tomorrow because he does not know what a day may bring. 

# What is heavier than the weight of sand?

The provocation of a fool is heavier than the weight of sand. 

# What may an enemy do to deceive you?

An enemy may kiss you profusely to deceive you. 

# To whom is every bitter thing sweet?

To the hungry person, every bitter thing is sweet. 

# What is better than a brother who is far away?

A neighbor is better than a brother who is far away. 

# What does a prudent man do when he sees trouble?

A prudent man hides himself when he sees trouble. 

# When is a blessing given with a loud voice considered to be a curse?

Early in the morning, a blessing given with a loud voice is considered to be a curse. 

# What is like restraining the wind?

Restraining a quarreling wife is like restraining the wind. 

# What is like restraining the wind?

Restraining a quarreling wife is like restraining the wind. 

# What is like iron which sharpens iron?

A man who sharpens his friend is like iron which sharpens iron. 

# What are never satisfied, just like Abaddon?

A man's eyes are never satisfied, just like Abaddon. 

# Even what will not remove foolishness from a fool?

Even crushing a fool will not remove foolishness from a fool. 

# How long does wealth last?

Wealth does not last forever. 

# What do lambs provide for a household?

Lambs provide clothing for a household. 

# Who runs away even when no one is chasing them?

The wicked run away even when no one is chasing them. 

# Who are praised by those who forsake the law?

The wicked are praised by those who forsake the law. 

# Which is more important, money or integrity?

Integrity is more important than money. 

# What happens to the wealth of someone who becomes rich by charging too much interest?

His wealth is given to another who will have pity on the poor. 

# Who will fall into his own pit?

A person who misleads the upright into an evil way will fall into his own pit. 

# How do the people react when the wicked arise?

The people hide themselves when the wicked arise. 

# How can a sinner receive mercy?

A sinner who confesses and forsakes his sin will receive mercy. 

# How can a ruler's days be prolonged?

A ruler can prolong his days if he hates dishonesty. 

# What can make a person a fugitive until death?

Shedding someone's blood can make a person a fugitive until death. 

# How can a person have plenty of poverty?

If a person follows worthless pursuits, he will have plenty of poverty. 

# How does a stingy man pursue riches?

A stingy man hurries after riches. 

# What is the result of trusting in Yahweh?

The one who trusts in Yahweh will prosper. 

# What will a person who closes his eyes to the poor receive?

A person who closes his eyes to the poor will receive many curses. 

# What happens to a person who stiffens his neck after many rebukes?

A person who stiffens his neck after many rebukes will be broken beyond healing. 

# What destroys a person's wealth?

Keeping company with prostitutes destroys a person's wealth. 

# What causes an evil person to be caught in a trap?

His own sin causes an evil person to be caught in a trap. 

# What kind of person turns away wrath?

A wise person turns away wrath. 

# Who do the bloodthirsty seek to kill?

The bloodthirsty seek to kill the upright. 

# What does a wise man do with his anger?

A wise man holds back his anger and calms himself down. 

# How can a king establish his throne forever?

A king can establish his throne forever by judging the poor by the truth. 

# What is the result of disciplining a child?

A disciplined child will give the parents rest. 

# If the people do not keep the law, what do they do?

If the people do not keep the law, they run wild. 

# What is worse than being a fool?

Being a man who is hasty in his words is worse than being a fool. 

# What kind of person is given honor?

A person with a humble spirit is given honor. 

# What does Yahweh do for the one who trusts in him?

Yahweh protects the one who trusts in him. 

# Who is an abomination to those who do right?

An unjust man is an abomination to those who do right. 

# Whose sayings are written in this proverb?

The sayings of Agur the son of Jakeh are written in this proverb. 

# What has the author not learned?

The author has not learned wisdom. 

# What will happen to someone who adds to God's words?

God will rebuke someone who adds to God's words. 

# How wealthy does the author wish to be?

The author wishes to have neither poverty nor riches. 

# What is the author afraid he would do if he were rich?

The author is afraid he would deny Yahweh if he were rich. 

# Who is not washed of their filth?

A generation that curses their father and does not bless their mother is not washed of their filth. 

# Who is not washed of their filth?

A generation that curses their father and does not bless their mother is not washed of their filth. 

# What does the haughty generation do to the poor?

The haughty generation devours the poor. 

# What are four things that never say "enough"?

Four things that never say "enough" are sheol, the barren womb, land thirsty for water, and fire. 

# What are four things that never say "enough"?

Four things that never say "enough" are sheol, the barren womb, land thirsty for water, and fire. 

# What is the second thing that the author does not understand because it is too wonderful?

The author does not understand the way of a snake on a rock. 

# What is the first thing that the author says causes the earth to tremble?

The first thing that causes the earth to tremble is a slave when he becomes king. 

# What does the author find amazing about locusts?

The author finds locusts amazing because they have no king, but all of them march in rank. 

# What does not turn away from anything?

The lion does not turn away from anything. 

# What should a person do who has been devising evil?

A person who has been devising evil should put his hand over his mouth. 

# What does anger produce?

Anger produces conflict. 

# Who wrote this proverb?

King Lemuel wrote this proverb. 

# To whom should the king not give his ways?

He should not give his ways to those who destroy kings. 

# What do rulers forget when they have strong drink?

Rulers forget what has been decreed when they have strong drink. 

# What do those in bitter distress forget when they have strong drink?

Those in bitter distress forget their trouble when they have strong drink. 

# Whose cause should the king plead?

The king should please the cause of the poor and needy. 

# What is more valuable than jewels?

A capable wife is more valuable than jewels. 

# What does the capable wife do all the days of her life?

She does good for her husband and not evil all the days of her life. 

# When does the capable wife arise?

She arises while it is night. 

# With what does the capable wife dress herself?

She dresses herself with strength. 

# To whom does the capable wife reach out?

She reaches out to the poor and needy. 

# Where does the capable wife's husband sit?

Her husband sits with the elders at the gates. 

# What is on the capable wife's tongue?

The law of kindness is on the capable wife's tongue. 

# What do the children of the capable wife call her?

Her children call her blessed. 

# What kind of woman will be praised?

A woman who fears Yahweh will be praised. 

