# What kind of wife did Yahweh tell Hosea to take for himself?

Yahweh told him to take for himself a wife who was a prostitute. 

# Why should Hosea call the name of his first son Jezreel?

Hosea should call his name Jezreel. For in a little while Yahweh will punish the house of Jehu for the bloodshed at Jezreel. 

# On whom will Yahweh have mercy?

Yahweh will have mercy on the house of Judah. 

# Why should Hosea call the name of his second son Lo Ammi?

Hosea should call his name Lo Ammi, for the Israelites were no longer his people. 

# What will be said to those who formerly were not Yahweh's people?

It will be said to them that they were people of the living God. 

# What will Yahweh do if Israel does not put away her prostitution?

If Israel does not put away her prostitution, Yahweh will strip her naked and show her nakedness as on the day that she was born. 

# What will Yahweh do if Israel does not put away her prostitution?

If Israel does not put away her prostitution, Yahweh will strip her naked and show her nakedness as on the day that she was born. 

# Why will Yahweh not have any mercy on Israel's children?

Yahweh will not have any mercy on her children, for they were children of prostitution. 

# Why will Israel return to her first husband?

Israel will return to her first husband, for was it better for her then than it now. 

# Who lavished on Israel silver and gold?

Yahweh lavished on her silver and gold. 

# What will Yahweh do to Israel in the sight of her lovers?

Yahweh will strip her naked in the sight of her lovers. 

# What wages did Israel's lovers give her?

Israel's lovers gave her vines and fig trees. 

# How will the prostitute answer Yahweh after he goes to win her back?

She will answer him as she did in the days of her youth, as in the days that she came out of the land of Egypt. 

# In that day, what will Israel call Yahweh?

She will call him 'My husband,' and no longer, 'My Baal.' 

# What will Yahweh make his people do?

He will make them lie down in safety. 

# For how long will Yahweh promise to be his people's husband?

Yahweh will promise to be their husband forever. 

# What will the new wine and the oil answer?

The new wine and the oil will answer Jezreel. 

# What will Yahweh say to those who were not his people?

Yahweh will say to those who were not his people, 'You are my people.' 

# In what way must Hosea love his wife?

Hosea must love her just as Yahweh loves the people of Israel. 

# For how much did Yahweh buy Israel?

He bought her for fifteen pieces of silver and a homer and a lethek of barley. 

# After the people of Israel live for many days without a king, who will they seek?

After the people of Israel live for many days without a king, they will seek Yahweh their God and David their king. 

# After the people of Israel live for many days without a king, who will they seek?

After the people of Israel live for many days without a king, they will seek Yahweh their God and David their king. 

# Against whom did Yahweh have a lawsuit?

Yahweh had a lawsuit against the inhabitants of the land. 

# What was happening to every one who was living in the land?

Every one who was living in it was wasting away. 

# Who will stumble by night?

The prophets will stumble by night. 

# Why will Yahweh forget the children of the people of Israel?

Yahweh will forget the children of the people of Israel because they forgot the Law of God. 

# How will the people act?

They will act like the priests. 

# What things took away the understanding of the people?

Sexual promiscuity, wine, and new wine took away their understanding. 

# Why will Yahweh not punish the people's daughters when they choose to commit sexual immorality?

Yahweh will not punish the people's daughters when they choose to commit sexual immorality, for the men also give themselves to the prostitutes. 

# Where should the people not go?

They should not go to Gilgal or Beth Aven. 

# What did Ephraim do even when their strong drink was gone?

Ephraim continued to commit adultery even when their strong drink was gone. 

# Where did the rebels stand?

The rebels stood deep in slaughter. 

# What will not allow Ephraim to turn to their God?

Ephraim's deeds will not allow them to turn to their God. 

# Why will Israel, Ephraim, and Judah not find Yahweh?

Israel, Ephraim, and Judah will not find Yahweh, for he has withdrawn himself from them. 

# Who declared that Ephraim will become a desolation?

Yahweh declared that Ephraim will become a desolation. 

# On whom will Yahweh pour his wrath?

Yahweh will pour his wrath on the leaders of Judah. 

# When did Ephraim go to Assyria?

When Ephraim saw his sickness, then he went to Assyria. 

# For how long will Yahweh go and return to his place?

Yahweh will go and return to his place until Ephraim and Judah acknowledge their guilt and seek his face; until they earnestly seek him in their distress. 

# Although Yahweh tore his people to pieces, what will he then do?

Although he tore them to pieces, he will heal them. 

# When will Yahweh raise up his people?

He will raise them up on the third day. 

# What was the faithfulness of Ephraim and Judah like?

Their faithfulness was like a morning cloud, like the dew that goes away early. 

# What did God desire?

God desired faithfulness and not sacrifice, and the knowledge of him more than burnt offerings. 

# In what way did the priests band together to commit murder on the way to Shechem?

As gangs of robbers wait for someone, so the priests banded together to commit murder on the way to Shechem. 

# What was appointed to Judah when Yahweh will restore the fortunes of his people?

A harvest was appointed, when Yahweh will restore the fortunes of his people. 

# What did Yahweh remember?

Yahweh remembered all their evil deeds. 

# How did the people make the officials glad?

By their lies they made the officials glad. 

# What were the people's hearts like?

Their hearts were like an oven. 

# What did Ephraim not know?

Ephraim did not know that foreigners devoured his strength or that gray hairs were sprinkled on him. 

# How was Ephraim like a dove?

Ephraim was like a dove, gullible and without sense. 

# Why did Yahweh not rescue the people?

Yahweh did not rescue the people because they spoke lies against him. 

# What did the people do to obtain grain and new wine?

They cut themselves to obtain grain and new wine. 

# Why will the officials fall?

The officials will fall because of the wickedness of their tongues. 

# Why was an eagle coming over the house of Yahweh?

An eagle was coming over the house of Yahweh because the people broke his covenant and rebelled against his Law. 

# With what did the people make idols for themselves?

With their silver and gold they made idols for themselves. 

# What happened when people sowed the wind?

People sowed the wind and reaped the whirlwind. 

# What will Yahweh do even though the people hired lovers among the nations?

Even though they hired lovers among the nations, Yahweh will gather them together. 

# If Yahweh wrote down his Law for them ten thousand times, how would they view it?

If Yahweh wrote down his Law for them ten thousand times, they would view it as something strange to them. 

# How will Yahweh punish the people's sins?

He will punish their sins by returning them to Egypt. 

# What did Israel love to pay?

Israel loved to pay the wages a prostitute required on all the threshing floors. 

# What will Ephraim's sacrifices be to them like?

Their sacrifices will be to them like mourners' food: all who eat it will be defiled. 

# If the people escaped from destruction, what will happen?

If the people escaped from destruction, Egypt will gather them, and Memphis will bury them. 

# What days were coming?

The days for punishment were coming. The days for retribution were coming. 

# What was on the prophet's paths?

A bird's snare was on his paths. 

# After the fathers went to Baal Peor, what did they become like?

After the fathers went to Baal Peor, they became as detestable as the idol they loved. 

# What will happen to Ephraim's glory?

Ephraim's glory will fly away like a bird. 

# What will Yahweh give Ephraim?

Yahweh will give them a miscarrying womb and breasts that give no milk. 

# Why will Yahweh drive Ephraim out of his house?

Because of their sinful deeds, Yahweh will drive them out of his house. 

# What would happen even if Ephraim had children?

Even if they had children, Yahweh would put their beloved children to death. 

# What happened as Israel's fruit increased?

As his fruit increased, the more altars he built. 

# How did Israel make covenants?

Israel made covenants by swearing falsely. 

# Why will the inhabitants of Samaria be carried to Assyria?

They will be carried to Assyria for a present for the great king. 

# What will grow over the altar?

Thorns and thistles will grow over the altar. 

# Why will Yahweh put a yoke on Ephraim's fair neck?

Because Ephraim was a trained heifer that loves to thresh the grain, Yahweh will put a yoke on her fair neck. 

# For how long should the people seek Yahweh?

They should seek Yahweh until he comes and rains righteousness on them. 

# What happened to mothers with their children when Shalman destroyed Beth Arbel?

When Shalman destroyed Beth Arbel, mothers were dashed to pieces with their children. 

# From where did Yahweh call Israel when Israel was a young man?

When Israel was a young man, Yahweh called him out of Egypt. 

# Who lifted Ephraim up by their arms?

Yahweh lifted them up by their arms. 

# What were Yahweh's people determined to do?

Yahweh's people were determined to turn away from him. 

# Why will Yahweh not again destroy Ephraim?

Yahweh will not again destroy Ephraim, for he is God and not a man. 

# How will the people come?

The people will come trembling from the west like a bird from Egypt, like a dove from the land of Assyria. 

# How will the people come?

The people will come trembling from the west like a bird from Egypt, like a dove from the land of Assyria. 

# Who was still faithful to God?

Judah was still faithful to God. 

# What did Yahweh have against Judah?

Yahweh had a lawsuit against Judah. 

# What did Jacob do in the womb?

In the womb, Jacob grasped his brother by the heel. 

# For what should the people wait?

They should wait continually for their God. 

# What will no one find in Ephraim's work?

In all Ephraim's work no one will find any sin in him, anything that would be sin. 

# How long had Yahweh been with the people?

Yahweh had been with them from the land of Egypt. 

# What will Gilgal's altars be like?

Gilgal's altars will be like heaps of stone in the furrows of the fields. 

# What did Yahweh do by a prophet?

Yahweh brought Israel out of Egypt by a prophet, and by a prophet he took care of them. 

# Why did Ephraim become guilty?

He became guilty because of Baal worship. 

# What happens to chaff?

Chaff is driven by the wind away from a threshing floor. 

# What happened when Yahweh's people were filled?

When Yahweh's people were filled, their heart became lifted up and they forgot him. 

# Like what will Yahweh attack his people?

He will attack them like a bear that is robbed of her cubs. 

# Why was Israel's destruction coming?

Israel's destruction was coming because they were against Yahweh, their helper. 

# When it was time for Ephraim to be born, what happened?

When it was time for Ephraim to be born, he did not come out of the womb. 

# What did Yahweh want brought to him?

Yahweh wanted death's plagues and Sheol's destruction brought to him. 

# What will Ephraim's enemy plunder?

His enemy will plunder the storehouse of every precious object. 

# What will happen to Samaria's young children?

Their young children will be dashed to pieces. 

# Why did Israel fall?

Israel fell because of their sin. 

# Why will Israel not say to the work of their hands, "You are our gods"?

Israel will not say to the work of their hands, "You are our gods," for in Yahweh the fatherless person finds compassion. 

# When will Yahweh heal Israel?

Yahweh will heal them when they turn back to him. 

# What will the people's fame be like?

Their fame will be like the wine of Lebanon. 

# Who will stumble in the ways of Yahweh?

The rebellious will stumble in them. 

