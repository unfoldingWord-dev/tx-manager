# How far did Ahasuerus reign?

Ahasuerus reigned from India as far as Ethiopia, over 127 provinces. 

# Who was in the king's presence?

The army of Persia and Media, the noblemen, and governors of the provinces were in his presence. 

# Who was the feast that lasted seven days for?

The seven day feast was for all the people in the palace of Susa, from the greatest to the least significant. 

# For whom did the king give the feast?

The feast was for all the people in the palace of Susa, from the greatest to the least significant. 

# Why was there much royal wine?

There was much royal wine because of the king's generosity. 

# What were the king's orders to all the staff of his palace?

The king gave orders to all the staff of his palace to do for them whatever each guest desired. 

# What did the king tell the seven officials who served before him?

The king told the seven officials who served before him to bring Queen Vashti before him with her royal crown. 

# What did the king tell the seven officials who served before him?

The king told the seven officials who served before him to bring Queen Vashti before him with her royal crown. 

# Why did the king become very angry?

The king became very angry because Queen Vashti refused to come at the word of the king. 

# With whom did the king confer?

The king conferred with the men who were known to be wise, who understood the times. 

# According to Memucan, against whom did Vashti do wrong?

Memucan said that not only against the king did Vashti the queen do wrong, but also against all the officials and all the people who are in all the provinces of King Ahasuerus. 

# What did Memucan say the noble women of Persia and Media would do before the end of that very day?

He said that before the end of that very day, the noble women would refuse the king's officials. 

# What did Memucan say the noble women of Persia and Media would do before the end of that very day?

He said that before the end of that very day, the noble women would refuse the king's officials. 

# To whom would the king give Vashti's position as queen?

The king would give Vashti's position as queen to another who was better than she was. 

# What did the king order?

The king ordered that every man should be master of his own household. 

# What did the king's young men recommend?

Then the king's young men recommended a search be made on the king's behalf for beautiful young virgins. 

# Under whose care would the virgins be put?

The virgins would be put under the care of Hegai, the king's official, who was in charge of the women. 

# Who had taken Mordecai from Jerusalem?

Nebuchadnezzar king of Babylonia had taken Mordecai away from Jerusalem. 

# What was Esther's other name?

Esther's other name was Hadassah. 

# How was Esther related to Mordecai?

Esther was his uncle's daughter. 

# With what did Hegai provide Esther?

Hegai provided her with cosmetics and her portion of food, and he assigned to her seven servant girls from the king's palace. 

# Why had Esther not told anyone who her people or relatives were?

Esther had not told anyone who her people or relatives were, for Mordecai had instructed her not to tell them. 

# When a young woman went to the king, what was given to her?

When a young woman went to the king, whatever she desired was given to her. 

# When would a girl return to the king?

A girl would not return to the king again unless he had taken great pleasure in her and called for her again. 

# For what did Esther ask?

She did not ask for anything but what Hegai the king's official, who was in charge of the women, suggested to her. 

# When was Esther taken to King Ahasuerus?

Esther was taken to King Ahasuerus on the tenth month, which is the month Tebeth, in the seventh year of his reign. 

# Why did the king set the royal crown on Esther's head and make her queen?

The king loved Esther more than all the other women, and she won favor and kindness before him, more than all the other virgins, so that he set the royal crown on her head and made her queen. 

# What did Bigthan and Teresh seek to do to King Ahasuerus?

Bigthan and Teresh sought to do harm to King Ahasuerus. 

# What happened to Bigthan and Teresh?

Both the men were hanged from a gallows. 

# Who knelt and prostrated themselves to Haman?

All the king's servants who were at the king's gate always knelt and prostrated themselves to Haman. 

# What did Mordecai refuse to do?

Mordecai refused to comply with demands of the king's servants. 

# Who did Haman want to kill?

Haman wanted to kill Mordecai as well as all the Jews. 

# When they threw lots, what month did they chose?

When they threw lots, they chose the twelfth month (the month of Adar). 

# How much money was Haman willing to put into the king's treasury if the king would give a command to kill the Jews?

Haman was willing to put ten thousand talents of silver into the king's treasury if the king would give a command to kill the Jews. 

# How were documents delivered to all the king's provinces?

Documents were hand-delivered by couriers to all the king's provinces. 

# How did Susa respond to the decree?

The city of Susa was in turmoil. 

# How far did Mordecai go? Why?

He went up only as far as the king's gate, because no one was allowed to go through it clothed in sackcloth. 

# When Esther sent garments to clothe Mordecai, how did he respond?

When she sent garments to clothe Mordecai, he would not accept them. 

# What did Mordecai report to Hathach?

Mordecai reported to him all that had happened to him, and the total amount of the silver that Haman had promised to weigh out and put into the king's treasuries in order to put the Jews to death. 

# Why did Mordecai give Hathach a copy of the decree that was issued in Susa for the Jews' destruction?

Mordecai did this so that Hathach could show it to Esther, and that Hathach should give her the responsibility of going to the king to beg for his favor, and to plead with him on behalf of her people. 

# What happened if any man or woman went to the king inside the inner courtyard without being summoned?

If any man or woman went to the king inside the inner courtyard without being summoned, there was only one law: that he must be put to death—except for anyone to whom the king holds out the golden scepter so that he may live. 

# What did Mordecai say would happen if Esther remained silent at that time?

If Esther remained silent at that time, relief and rescue would rise up for the Jews from another place, but she and her father's house would perish. 

# What did Esther tell Mordecai to do?

Esther told Mordecai to gather together all the Jews who live in Susa, and to fast for her for three days. 

# Where was the inner courtyard of the king's palace?

The inner courtyard of the king's palace was in front of the king's house. 

# When the king saw Esther the queen standing in the court, why did he hold out to her the golden scepter?

Esther won favor in his sight, so he held out to her the golden scepter in his hand. 

# What did Esther request from the king?

She requested that the king and Haman come to a feast that she had prepared for him. 

# What did Esther request from the king the second time?

She requested that the king and Haman come to a feast that she had prepared for them. 

# What did Haman recount to his family?

Haman recounted to them the splendor of his riches and the number of his many sons, how he had advanced above all the officials and the servants of the king. 

# Why did Haman feel that being invited to the banquets was worth nothing to him?

Being invited to the banquets was worth nothing to him as long as he saw Mordecai the Jew sitting at the king's gate. 

# What did Zeresh tell Haman to make? Why?

Zereah told him to make a gallows fifty cubits high so that he could hang Mordecai on it. 

# Why did the king command servants to bring the records of the events of his reign?

That night the king could not sleep, so he commanded servants to bring the records of the events of his reign. 

# What had been done to give honor or recognition to Mordecai for telling the king about Bigthana and Teresh?

Nothing had been done to give honor or recognition to Mordecai for telling the king about Bigthana and Teresh. 

# What had been done to give honor or recognition to Mordecai for telling the king about Bigthana and Teresh?

Nothing had been done to give honor or recognition to Mordecai for telling the king about Bigthana and Teresh. 

# When the king asked Haman what should be done for the man whom the king takes pleasure in honoring, about whom did Haman think the king was talking?

When the king asked Haman what should be done for the man whom the king takes pleasure in honoring, Haman though the king was talking about Haman. 

# Who would dress the man whom the king takes pleasure in honoring, and lead him on the horse through the city streets?

One of the king's most noble officials would dress the man whom the king takes pleasure in honoring, and lead him on the horse through the city streets. 

# Who dressed Mordecai and led him on the horse through the city streets?

Haman dressed Mordecai and led him on the horse through the city streets. 

# About what did Haman's wise men and his wife warn him?

His wise men and his wife said to him that if Mordecai was Jewish, Haman would not overcome him, but would certainly fall before him. 

# What was Esther's request?

She wanted her life and also at the lives of her people to be given to her 

# What did Esther say she would have done if her people had only been sold into slavery?

If her people had only been sold into slavery, she said she would have kept quiet. 

# Who did Esther describe as, "The hostile man, that enemy..."

This was Esther's description of Haman. 

# What did Haman do when the king got up in a rage from the wine-drinking?

When the king got up in a rage from the wine-drinking, Haman stayed to beg for his life from Queen Esther. 

# After Haman fell on the couch where Esther was, what did the king think Haman was doing?

After Haman fell on the couch where Esther was, the king thought he was assaulting the queen in the king's presence. 

# Where did the king say to hang Haman?

The king said to hang Haman and his family on the gallows Haman set up for Mordecai. 

# Why did Mordecai begin to serve before the king?

Mordecai began to serve before the king, for Esther told the king how Mordecai was related to her. 

# Why was Mordecai in charge of Haman's estate?

Esther designated Mordecai to be in charge of Haman's estate. 

# What did the king do so that Esther could arise and stand before him?

The king held out the golden scepter to Esther; so she arose and stood before the king. 

# What letters did Haman write?

Haman wrote the letters about destroying the Jews who were in all the king's provinces. 

# Why did Esther need to write another decree for the Jews in the name of the king?

Esther needed to write another decree for the Jews in the name of the king, for the first decree that had already been written in the king's name and sealed with the king's ring could not be revoked. 

# When were the king's scribes called?

The king's scribes were called in the third month, which is the month Sivan, on the twenty-third day of the month. 

# What did the king give the Jews permission to do?

The king gave the Jews permission to gather together and to make a stand to protect their lives; to kill, and to destroy any armed force from any people or province that might attack them, children and women included, or to plunder their possessions. 

# Why did many from among the variety of peoples of the land become Jews?

Many from among the variety of peoples of the land became Jews, because the fear of the Jews had fallen on them. 

# Why could no one stand against the Jews?

No one could stand against the Jews, for the fear of them had fallen on all the peoples. 

# What did the Jews do to their enemies?

The Jews attacked their enemies with the sword, killing and destroying them, and did as they pleased to those who hated them. 

# Who did the Jews kill?

The Jews killed five hundred men in the city of Susa, including the ten sons of Haman. 

# What happened to the bodies of Haman's ten sons?

The bodies of Haman's ten sons were hanged on gallows. 

# How many men did the Jews kill on the fourteenth day of the month Adar?

On the fourteenth day of the month Adar, the Jews killed three hundred more men in Susa. 

# Why do the Jews of the villages observe the fourteenth day of the month Adar as a day of gladness and feasting?

The Jews of the villages observe the fourteenth day of the month Adar as a day of gladness and feasting because stopped killing, and they rested and made that a day of feasting and gladness. 

# Why do the Jews of the villages observe the fourteenth day of the month Adar as a day of gladness and feasting?

The Jews of the villages observe the fourteenth day of the month Adar as a day of gladness and feasting because stopped killing, and they rested and made that a day of feasting and gladness. 

# Why do the Jews of the villages observe the fourteenth day of the month Adar as a day of gladness and feasting?

The Jews of the villages observe the fourteenth day of the month Adar as a day of gladness and feasting because stopped killing, and they rested and made that a day of feasting and gladness. 

# How often did Mordecai obligate the Jews to keep the fourteenth and the fifteenth day of Adar?

Mordecai obligated them to keep the fourteenth and the fifteenth day of Adar every year. 

# How often did Mordecai obligate the Jews to keep the fourteenth and the fifteenth day of Adar?

Mordecai obligated them to keep the fourteenth and the fifteenth day of Adar every year. 

# What does Pur mean?

Pur means 'lots'. 

# Why would the Jews and their descendants never cease to faithfully observe these days of Purim?

The Jews and their descendants would never cease to faithfully observe these days of Purim, so that they would never forget them. 

# Where did King Ahasuerus impose a tax?

King Ahasuerus imposed a tax on the land and on the coast lands along the sea. 

# Where were all the achievements of King Ahasuerus' power and might written?

All the achievements of his power and might were written in The Book of the Chronicles of the Kings of Media and Persia. 

# What was the rank of Mordecai the Jew?

Mordecai the Jew was second in rank to King Ahasuerus. 

# Why was Mordecai great among the Jews and popular with his many Jewish brothers?

He was great among the Jews and popular with his many Jewish brothers, for he sought the welfare of his people, and he spoke for the peace of all his people. 

