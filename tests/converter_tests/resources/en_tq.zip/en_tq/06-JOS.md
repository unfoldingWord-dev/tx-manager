# What did Yahweh tell Joshua to do after the death of Moses?

Yahweh told Joshua to cross the Jordan and lead the people of Israel into the land that Yahweh would give them. 

# What did Yahweh tell Joshua to do after the death of Moses?

Yahweh told Joshua to cross the Jordan and lead the people of Israel into the land that Yahweh would give them. 

# What did Yahweh tell Joshua to do after the death of Moses?

Yahweh told Joshua to cross the Jordan and lead the people of Israel into the land that Yahweh would give them. 

# Why did Yahweh say that no one would be able to stand against Joshua?

Yahweh said that no one would be able to stand against Joshua because he would be with Joshua just as he had been with Moses. 

# What three things did Yahweh ask of Joshua?

Yahweh ask Joshua to be strong, courageous and to obey the law. 

# What did Yahweh ask Joshua to meditate upon day and night?

Yahweh ask Joshua to meditate day and night upon the book of the Law. 

# What did Joshua command the leaders of the people to do?

Joshua commanded the leaders of the people to command the people to prepare provisions for themselves to cross over the Jordan in three days. 

# What two things did Joshua say Moses had said Yahweh had commanded the Reubenites, the Gadites and half the tribe of Manasseh to call to mind?

The two things that Joshua said Moses had said Yahweh had commanded the Reubenites, the Gadites and half the tribe of Manasseh to call to mind are "Yahweh your God is giving you rest, and he is giving you this land." 

# What did Joshua tell the Reubenites, the Gadites and half the tribe of Manasseh to do?

Joshua told the Reubenites, the Gadites and half the tribe of Manasseh to leave wives, children and livestock in the land Moses had given them beyond the Jordan, but the fighting men should cross the Jordan and help their brothers. 

# How did the people answer Joshua commands?

The people answered Joshua commands saying they would do what he said to do and go where he said to go. 

# Where did the two spies from Shittim find lodging when Joshua sent them to spy on the land?

The two spies found lodging at the house of a prostitute named Rahab. 

# What did Rahab do with the spies when the king's men came looking for them?

When the king's men came to Rahab looking for the spies, she had hid them. 

# What did Rahab say to the king's men?

Rahab said to the king's men that the spies had been there, but had already left. 

# Why did Rahab tell the spies was the reason that she had hidden them.

Rahab told the spies that she had hidden them because she believed that Yahweh had given them the land. 

# What did Rahab say were the reasons she believed that Yahweh would give the Israelites the land?

Rahab said she believed Yahweh had given the Israelites the land because the waters of the Dead Sea had dried up allowing their escape from Egypt, and they had destroyed the Amorite kings. 

# What did Rahab ask the spies to do?

Rahab ask the spies to show mercy and to spare her and her family when they came to take the land. 

# What did Rahab ask the spies to do?

Rahab ask the spies to show mercy and to spare her and her family when they came to take the land. 

# What did the spies promise Rahab?

The spies promised Rahab that they would be merciful and faithful to her if she did not tell of their business. 

# What did the spies ask Rahab to do to be safe?

The spies ask Rahab to put a scarlet rope in her window and gather her entire family into her house. 

# What did the spies report to Joshua when they returned from Rahab's city?

The spies told Joshua everything that had happened, and that Yahweh was giving them the land. 

# What did the spies report to Joshua when they returned from Rahab's city?

The spies told Joshua everything that had happened, and that Yahweh was giving them the land. 

# What did the officers tell the people to follow when the Levite priests carried it?

The officers told the people to follow the ark of the covenant when the Levite priests carried it. 

# Why did the priests tell the people to stay about 2000 cubits behind the ark of the covenant?

The priest told the people to stay behind the ark so they could see which way to go since they had never gone that way before. 

# What did Joshua say that Yahweh was going to do among the people on that day?

Joshua said that Yahweh was going to do "wonders" among the people that day. 

# What did Yahweh tell Joshua to say to the priests when they got to the Jordan River?

Yahweh told Joshua to tell the priests to stand still in the Jordan River. 

# What did Joshua tell the people would happen when the soles of the feet of the priests carrying the ark touched the Jordan River?

Joshua told the people the waters would be cut off when the soles of the feet of the priests carrying the ark touched the river. 

# Where did the people cross the Jordan River?

The people crossed the Jordan near Jericho. 

# What did the priests who carried the ark of the covenant do while the people crossed over?

The priests who carried the ark of the covenant remained in the middle of the Jordan River on dry ground while the people crossed over. 

# What did Yahweh tell Joshua to command twelve men to take from the Jordan?

Yahweh told Joshua to command twelve men to take twelve stones from the dry ground in the middle of the Jordan where the priests were standing, and to bring them to the place where they were to spend the night. 

# What did Joshua say was the purpose of taking the stones to the place where they were to spend the night?

The stones would become a memorial to remind the people of Israel forever of what Yahweh had done. 

# Where did Joshua set up a monument of twelve stones?

Joshua set up a monument of twelve stones were the priests had stood on dry ground in the Jordan River. 

# About how many men equipped for war passed by Yahweh for battle on the plains of Jericho?

About 40,000 men equipped for war passed by Yahweh for battle on the plains of Jericho. 

# What happened when the priests who carried the ark of the covenant came up out of the Jordan River?

When the priests came up out of the Jordan, the waters of the Jordan returned to their place. 

# Where did Joshua set up the stones that came out of the Jordan?

Joshua set up the stones that came out of the Jordan at Gilgal. 

# Why did Joshua tell the people to tell their children what Yahweh had done for them at the Jordan?

Joshua told the people to tell their children what Yahweh had done for them at the Jordan in order to for all the peoples of the world to know that the hand of Yahweh is mighty. 

# What happened to the hearts of the kings of the Amorites and the Canaanites when they heard how Yahweh had dried up the waters of the Jordan until the people of Israel had crossed over?

When the kings of the Amorites and the Canaanites heard how Yahweh had dried up the waters of the Jordan, their hearts melted and there was no longer any spirit in them. 

# What did Yahweh command Joshua to do with flint knives?

Yahweh commanded Joshua to circumcise all the males of Israel. 

# Why was Joshua commanded to circumcise all the males of Israel?

Joshua was commanded to circumcise all the males of Israel because the boys who had been born during the wanderings in the wilderness had not been circumcised. 

# Why was Joshua commanded to circumcise all the males of Israel?

Joshua was commanded to circumcise all the males of Israel because the boys who had been born during the wanderings in the wilderness had not been circumcised. 

# What did the people of Israel keep on the fourteenth day of the month, in the evening, on the plains of Jericho?

The Israelites kept Passover on the fourteenth day of the month, in the evening, on the plains of Jericho. 

# What stopped coming on the day after the people of Israel ate from the produce of the land?

Manna stopped coming on the day after the people of Israel ate produce from the land. 

# Who did Joshua meet standing in front of him near Jericho?

Joshua met a man with a drawn sword in his hand. 

# What did Joshua say to the man with the drawn sword?

Joshua said to the man with the drawn sword, "Are you for us or for our enemies?" 

# Who did the man with the drawn sword say that he was?

The man with the drawn sword told Joshua that he was the commander of the army of Yahweh. 

# What did the commander of the army of Yahweh tell Joshua to do?

The commander of the army of Yahweh told Joshua to remove his sandals, because he was on holy ground. 

# What did Yahweh promise to Joshua about Jericho?

Yahweh promised Joshua that he was giving Jericho into his hand. 

# How many times were the men of Israel to walk around the walls of Jericho for the first six days?

The men of Israel were to walk around the wall of Jericho one time each day for six days. 

# What did Yahweh tell the men to do on the seventh day?

Yahweh told the men to walk around Jericho seven times on the seventh day, and for the priests give blasts on their trumpets. 

# What did Yahweh say would happen if the men of Israel and the priests did this?

Yahweh said the the walls around Jericho would fall down if the men and the priests did this. 

# What did Joshua command the people not to do until the seventh day?

Joshua commanded the people not to shout until the seventh day. 

# Who did Joshua tell the people to let live when Yahweh gave them the city?

Joshua told the people to let Rahab and all in her house live because she had hidden the spies. 

# What things did Joshua tell the people were holy to Yahweh and must be brought to the treasury?

Joshua told the people that things made of silver, gold, iron and bronze were holy to Yahweh and must be brought to the treasury. 

# What did the people of Israel do when the walls of Jericho fell?

The people of Israel captured the city and destroyed all that were in the city by the edge of the sword. 

# What did Joshua command the two young men who had spied out the land to do?

Joshua commanded the two spies to go into the prostitute's house and bring her and all who were with her out, as they swore to her. 

# What did Joshua say will happen to the man who tries to rebuild Jericho?

Joshua said that the man who tries to rebuild Jericho will be cursed. 

# Why did Yahweh's anger burn against the people of Israel?

Yahweh's anger burned against the people of Israel because Achan took some things for himself that were dedicated to destruction. 

# What did the spies that were sent by Joshua to Ai report back to Joshua?

The spies that were sent to Ai reported to Joshua that only a small army could take Ai because there were few people there. 

# What happened to the smaller army of three thousand men who attacked Ai?

The smaller army which attacked Ai was driven away by the men of Ai and thirty-six were killed. 

# What did Joshua do when he learned of the defeat of his army at Ai?

When Joshua learned of the defeat of his army at Ai, he tore his garments, put dust on his head, and lay before the ark. 

# What did Yahweh tell Joshua was the reason his army was defeated at Ai?

Yahweh told Joshua that his army was defeated because Israel had sinned by stealing some of the things dedicated for destruction. 

# What did Yahweh tell Joshua to do?

Yahweh told Joshua to get up and consecrate the people to give over the things dedicated for destruction. 

# What did Yahweh say would happen to the one who had stolen the things dedicated to destruction?

Yahweh said that the one who had stolen the things dedicated to destruction would be burned as well as all he had. 

# What did Achan tell Joshua that he had taken?

Achan told Joshua that he had taken a beautiful coat, two hundred shekels of silver, and a bar of gold. 

# Where did Achan tell Joshua that he had hidden the things he had taken?

Achan told Joshua that he had hidden the things he had taken in the ground in the middle of his tent. 

# Where did Joshua and all Israel take Achan and all that he had?

Joshua and all Israel took Achan and all that he had to the valley of Achor. 

# What happened to Yahweh's burning anger?

Yahweh's burning anger was turned away. 

# What did Yahweh tell Joshua to do in order to take the city of Ai?

Yahweh told Joshua to take all the people of war to Ai and set an ambush behind the city. 

# What did Yahweh tell Joshua to do in order to take the city of Ai?

Yahweh told Joshua to take all the people of war to Ai and set an ambush behind the city. 

# What were the people to do with the plunder from Ai?

Yahweh told the people they could take the plunder and cattle for themselves. 

# When did Joshua send the thirty thousand strong and courageous men to Ai?

Joshua sent the thirty thousand strong and courageous men to Ai at night. 

# What did Joshua plan to do with his men when they approached the city?

When Joshua approached the city with his men and the people of the city came out to attack, Joshua's men would run away like before. 

# What were Joshua's men to do with the city when they captured it?

When the men captured the city, they were to set it on fire. 

# What did the men of Ai do when the army of Joshua fled toward the wilderness?

The men of Ai pursued Joshua's army as they fled toward the wilderness, until not one man was left in the city. 

# What did the men of Ai do when the army of Joshua fled toward the wilderness?

The men of Ai pursued Joshua's army as they fled toward the wilderness, until not one man was left in the city. 

# What did the men of Ai do when the army of Joshua fled toward the wilderness?

The men of Ai pursued Joshua's army as they fled toward the wilderness, until not one man was left in the city. 

# What signal did Yahweh tell Joshua to give when he was ready for his army to take the city?

Yahweh told Joshua to point the spear he held in his hand toward Ai. 

# Who did the men of Israel capture alive and bring to Joshua?

The men of Israel captured alive the King of Ai and brought him to Joshua. 

# Who did Joshua destroy in the city of Ai?

Joshua destroyed all of the people of Ai. 

# What did Israel take from the city of Ai before they burned it?

Israel took the livestock and plunder, just as Yahweh had commanded Joshua. 

# What did Joshua do with the king of Ai?

Joshua hanged the king of Ai on a tree and then threw his body in front of the city gates. 

# What did the kings who lived beyond the Jordan in the hill country do to wage war against Joshua and Israel?

The kings who lived beyond the Jordan in the hill country joined together under one command to defeat Joshua and Israel. 

# What did the kings who lived beyond the Jordan in the hill country do to wage war against Joshua and Israel?

The kings who lived beyond the Jordan in the hill country joined together under one command to defeat Joshua and Israel. 

# Who acted with a cunning plan?

The inhabitants of Gibeon acted with a cunning plan. 

# Who acted with a cunning plan?

The inhabitants of Gibeon acted with a cunning plan. 

# How did the Gibeonite "messengers" prepare themselves?

The people of Gibeon took worn out sacks and put them on their donkeys. They took old wine skins, and put on patched sandals and dressed in worn out clothing. They also took dry and moldy bread. 

# How did the Gibeonite "messengers" prepare themselves?

The people of Gibeon took worn out sacks and put them on their donkeys. They took old wine skins, and put on patched sandals and dressed in worn out clothing. They also took dry and moldy bread. 

# When the Gibeonites came to Joshua at Gilgal where did they say they were from?

The Gibeonites said they were from a very far country. 

# What did the Gibeonites want the men of Israel to do?

The Gibeonites wanted the men of Israel to make a treaty with them. 

# What did the Israelites fail to do?

The Israelites did not consult with Yahweh for guidance. 

# What did Joshua promise the people of Gibeon?

Joshua made peace with them and made a vow to let them live. 

# What did the Israelites learn about the people from Gibeon just a few days later?

The Israelites learned that the people from Gibeon were their neighbors and lived nearby. 

# Why did the Israelites not attack the people of Gibeon?

The Israelites did not attack the people of Gibeon because they had taken an oath about them before Yahweh. 

# Why did the Israelites not attack the people of Gibeon?

The Israelites did not attack the people of Gibeon because they had taken an oath about them before Yahweh. 

# What did the Gibeonites do for the Israelites?

The Gibeonites became cutters of wood and drawers of water for all the Israelites. 

# What was the reason the Gibeonites gave to Joshua for why they had deceived him?

The Gibeonites told Joshua that they were very afraid for their lives. 

# What would happen to Gibeonites?

Joshua removed them from the power of the Israelites and made them cutters of wood and drawers of water for the community and the altar of Yahweh. 

# What would happen to Gibeonites?

Joshua removed them from the power of the Israelites and made them cutters of wood and drawers of water for the community and the altar of Yahweh. 

# Why were the people of Jerusalem afraid that the people of Gibeon had made peace with Israel?

The people of Jerusalem were afraid because Gibeon was a large city, larger than Ai, and all its men were mighty warriors. 

# What did the king of Jerusalem ask the other kings to do?

The king of Jerusalem ask other kings to come up to him and help him attack Gibeon. 

# What did the king of Jerusalem ask the other kings to do?

The king of Jerusalem ask other kings to come up to him and help him attack Gibeon. 

# What did the kings do?

They came up and with all their armies and attacked Gibeon. 

# What did the people of Gibeon do when the saw all the kings and their armies?

The people of Gibeon sent a message to Joshua to come and save them. 

# What did Yahweh say to Joshua?

Yahweh said to Joshua that the kings had been given into his hand. 

# How did Yahweh kill most of the enemy?

Yahweh threw large stones from heaven which killed more than were killed with the sword by the men of Israel. 

# What did Joshua say to Yahweh on the day Yahweh gave the men of Israel victory?

Joshua said to Yahweh, "Sun, be still at Gibeon, and moon, in the valley of Aijalon." 

# What happened to the five kings?

The five kings hid in the cave of Makkedah. 

# What happened to the armies of the kings?

The Israelites slaughtered most them. Only a few survivors escaped. 

# What happened to the five kings who had hidden in the cave of Makkedah?

The five kings who had hidden in the cave were brought to Joshua, attacked and killed, hung on five trees until sunset, and then thrown into the cave. 

# What happened to the five kings who had hidden in the cave of Makkedah?

The five kings who had hidden in the cave were brought to Joshua, attacked and killed, hung on five trees until sunset, and then thrown into the cave. 

# What did Joshua and the army of Israel do throughout the land of the hill country, the Negev, the lowlands and the foothills.

Joshua and the army of Israel conquered all the kings leaving not one survivor. 

# Why was Joshua so successful in capturing all these kings and their land?

Joshua was successful in capturing these kings and their land because Yahweh, God of Israel, fought for Israel. 

# What did Jabin, king of Hazor, do when he heard about the victory of the Israelites at Gibeon?

He sent a message to many kings from the region. 

# What did Jabin, king of Hazor, do when he heard about the victory of the Israelites at Gibeon?

He sent a message to many kings from the region. 

# What did Jabin, king of Hazor, do when he heard about the victory of the Israelites at Gibeon?

He sent a message to many kings from the region. 

# What was the response of the kings to Jabin's message?

In response to Jabin's message all their armies came out with them and met at the appointed time and they camped at the waters of Merom to wage war with Israel. 

# What did their number seem like?

Their number seemed like the sand of the seashore. 

# What was the response of the kings to Jabin's message?

In response to Jabin's message all their armies came out with them and met at the appointed time and they camped at the waters of Merom to wage war with Israel. 

# Where did the battle take place?

The battle took place at the waters of Merom. 

# What did Yahweh tell Joshua he would do after the battle?

Yahweh told Joshua he would hamstring their horses and burn their chariots. 

# What did Joshua do to Hazor and its king?

Joshua burned the city and struck the king with his sword. 

# What did Joshua do to Hazor and its king?

Joshua burned the city and struck the king with his sword. 

# What did Joshua do with the rest of the kings and cities that had waged war with Israel?

Joshua captured the kings and destroyed them, but he did not burn their cities. 

# What did Joshua do with the rest of the kings and cities that had waged war with Israel?

Joshua captured the kings and destroyed them, but he did not burn their cities. 

# What had Moses commanded Joshua to do?

Moses had commanded Joshua to kill every human being. 

# Did Joshua do all that Moses had commanded him to do?

Yes. Joshua did all that Moses had commanded him to do. 

# What was the only city that made peace with Israel?

Gibeon was the only city to make peace with Israel. 

# What did the Israelites do to the land on the east side of the Jordan?

They took possession of the land of the east side of the Jordan where the sun rises. 

# Who led the people of Israel as they defeated the people on the east side of the Jordan?

Moses, the servant of Yahweh led them as they defeated the people on the east side of the Jordan. 

# Who led the people of Israel as they defeated the people on the west side of the Jordan?

Joshua led them as they defeated the people on the west side of the Jordan. 

# How many kings did Joshua and the Israelites conquer in the land which Yahweh had given them?

Joshua and the Israelites conquered thirty-one kings in all the land which Yahweh had given them. 

# Why did Yahweh say to Joshua that there was still very much land to capture?

Yahweh said to Joshua that there was still very much land to capture because Joshua was old and well along in years. 

# What did Yahweh tell Joshua to do after he drove the inhabitants out before the army of Israel?

Yahweh told Joshua to assign the land to Israel as an inheritance as Yahweh had commanded. 

# To whom should the land be divided?

The land should be divided as an inheritance to the nine tribes and the half tribe of Manasseh. 

# Where had the other two and one half tribes already received their inheritance?

The half tribe of Manasseh, the Reubenites and the Gadites had received their inheritance on the east side of the Jordan. 

# To what one tribe did Moses not give an inheritance?

Moses did not give an inheritance to the tribe of Levi. 

# What inheritance did Moses give to the tribe of Levi?

Moses gave to the tribe of Levi "The offerings of Yahweh, the God of Israel, made by fire" as an inheritance. 

# What was the border of the tribe of Reuben?

The border of the tribe of Reuben was the Jordan River. 

# What were the two tribes that made up the tribe of Joseph?

The tribes of Manasseh and Ephraim made up the tribe of Joseph. 

# How old was Caleb when Moses the servant of Yahweh sent him to spy on the land?

He was forty years old when Moses the servant of Yahweh sent him from Kadesh Barnea to spy on the land. 

# What did Moses swear to give to Caleb?

Moses swore to give to Caleb the land on which his foot has walked as an inheritance for him and for his children forever. 

# How old was Caleb when he came to Joshua?

Caleb was eighty-five years old when he came to Joshua. 

# What did Caleb ask Joshua to give him?

Caleb asked Joshua to give him the hill country as an inheritance. 

# What was the farthest point south to which the land of Judah extended?

The farthest point south was the wilderness of Sin. 

# What was the eastern boundary of the land of Judah?

The eastern boundary was the Salt Sea. 

# What was the name of the Jebusites' city?

The Jebusites' city was Jerusalem. 

# What was the western border of the clan of Judah?

The western border of the clan of Judah was the Great Sea and its coastline. 

# What did Caleb give his daughter, Achsah, when she asked for it?

Caleb gave Achsah the upper and lower springs when she asked. 

# What people could not be driven out of Jerusalem by the tribe of Judah?

The Jebusites could not be driven out of Jerusalem by the tribe of Judah. 

# What were the two tribes of Joseph that received their inheritance together?

The tribes of Joseph and Ephraim the descendants of Joseph. 

# What people did the tribe of Ephraim not drive out of Gezer?

The tribe of Ephraim was unable to drive out of Gezer the Canaanites. 

# Who was the firstborn of Joseph?

Manasseh was the firstborn of Joseph. 

# Who was Makir?

Makir was the firstborn of Manasseh and the father of Gilead. 

# Why did the daughters of Zelophehad approach Eleazer, Joshua, and the leaders?

The daughters of Zelophedad approached Eleazer, Joshua, and the leaders because they had no brothers to receive an inheritance. 

# What did Joshua do for the daughters of Zelophedad?

Joshua gave the daughters of Zelophedad an inheritance among the brothers of their father. 

# What did the people of Israel do to the Canaanites when the Israelites grew strong?

When the people of Israel grew strong, they put the Canaanites to forced labor. 

# What did the descendants of Joseph say to Joshua?

The descendants of Joseph said to Joshua that the hill country was not enough for their number. 

# What did Joshua say to the descendants of Joseph?

Joshua told the descendants of Joseph to go up by themselves to the forest and clear the land in the land of the Perizzites and of the Rephaim. 

# When the assembly of the people met at Shiloh, how many tribes of the people of Israel had not been assigned an inheritance?

When the assembly of the people met at Shiloh, seven tribes of the people of Israel had not been assigned an inheritance. 

# Who did Joshua send out to survey the land up and down?

Joshua sent out three men from each of the seven tribes to survey the land up and down. 

# What were the three men from each tribe to report to Joshua?

The three men from each tribe were to write out a description of the land, with a view to their inheritances, and then they were to come back to Joshua. 

# What did Joshua do after the men returned to him after making the survey?

Joshua cast lots for them at Shiloh before Yahweh when the men returned from surveying the land. 

# Between what two tribes was the tribe of Benjamin assigned as an inheritance?

The tribe of Benjamin was assigned as an inheritance the land between the descendants of Judah and the descendants of Joseph. 

# The second casting of lots fell to which tribe?

The second casting of lots fell to Simeon. 

# The inheritance to Simeon came out of the territory of what tribe?

The inheritance to Simeon came out of the territory of the tribe of Judah. 

# Why did the inheritance of Simeon come out of the territory of Judah?

The inheritance of Simeon came out of the territory of Judah because that territory was too large for Judah. 

# The third casting of lots fell to what tribe?

The third casting of lots fell to the tribe of Zebulun. 

# The fourth casting of lots fell to what tribe?

The fourth casting of lots fell to the tribe of Issachar. 

# The fifth casting of lots fell to what tribe?

The fifth casting of lots fell to the tribe of Asher. 

# The sixth casting of lots fell to what tribe?

The sixth casting of lots fell to the tribe of Naphtali. 

# How many cities were included in the inheritance of the tribe of Naphtali?

The inheritance of the tribe of Naphtali included nineteen cities. 

# The seventh casting of lots fell to which tribe?

The seventh casting of lots fell to the tribe of Dan. 

# What inheritance did the people of Israel give to Joshua when they had finished the allocation of the land?

The people of Israel gave to Joshua by command of Yahweh the city for which he asked, Timnath Serah. 

# What did Yahweh tell Joshua to say to the people?

Yahweh told Joshua to say to the people that they should appoint the cities of refuge. 

# What is a city of refuge?

A city of refuge is a city where someone who has unintentionally killed a person can go to escape anyone who seeks to avenge the blood of a person who was killed. 

# To whom and where would the person who killed another explain his case?

The person who had killed another would stand at the city gate and explain his case to the elders of that city. 

# After a person fled to the city of refuge and stood before the assembly for judgment, what else had to happen before he was allowed to return to his home?

He could not leave the city of refuge and return home until the death of the high priest. 

# What would the accused person do in the city of refuge to avoid being killed by the one who wanted to avenge the shed blood?

The accused person would first stand before the assembly. 

# Who asked the people of Israel to give them cities to live in and pasture lands for their livestock?

The clans of the Levites asked the people of Israel to give them cities to live in and pasture lands for their livestock. 

# Who asked the people of Israel to give them cities to live in and pasture lands for their livestock?

The clans of the Levites asked the people of Israel to give them cities to live in and pasture lands for their livestock. 

# How did the people of Israel determine the cities and pasture lands to be given to the Levites?

The people of Israel determined the cities and pasture lands to be given to the Levites by casting lots, just as Yahweh had commanded. 

# How many cities were given to the descendants of Aaron?

The descendants of Aaron received clans of Merari cities in all. 

# How many cities were given to the family of Kohath?

The family of Kohath received ten cities in all. 

# How many cities were given to the clans of Gershon?

The clans of Gershon received clans of Merari cities in all. 

# How many cities were given to the clans of Merari?

The clans of Merari received twelve cities in all. 

# How many cities were given to all the Levites from the middle of the land possessed by the people of Israel?

Forty-eight cities, including their pasture lands, were given to the Levites from the middle of the land. 

# What had Yahweh sworn to the ancestors of the Israelites?

Yahweh had sworn to give them the land they possessed, and rest on every side. 

# What commendation did Joshua give to the Reubenites, the Gadites, and the half tribe of Manasseh?

Joshua commended them by saying the had done everything that Moses and Joshua had commanded them and that they had not deserted their brothers but had been careful to obey Yahweh their God. 

# What commendation did Joshua give to the Reubenites, the Gadites, and the half tribe of Manasseh?

Joshua commended them by saying the had done everything that Moses and Joshua had commanded them and that they had not deserted their brothers but had been careful to obey Yahweh their God. 

# What commendation did Joshua give to the Reubenites, the Gadites, and the half tribe of Manasseh?

Joshua commended them by saying the had done everything that Moses and Joshua had commanded them and that they had not deserted their brothers but had been careful to obey Yahweh their God. 

# What did Joshua tell these tribes to be very careful about when they returned to their tents?

Joshua told these tribes to be very careful to observe the commandments and the law that Moses commanded them. 

# What did Joshua tell one half of the tribe of Manasseh to divide among their brothers?

Joshua told one half of the tribe of Manasseh to divide among their brothers the plunder. 

# What did the Reubenites, the Gadites, and the half tribe of Manasseh do beside the Jordon that angered the people of Israel in the land of Canaan?

The Reubenites, Gadites, and the half tribe of Manasseh built a large altar on the side of the Jordon that belonged to the people of Israel. 

# What did the Reubenites, the Gadites, and the half tribe of Manasseh do beside the Jordon that angered the people of Israel in the land of Canaan?

The Reubenites, Gadites, and the half tribe of Manasseh built a large altar on the side of the Jordon that belonged to the people of Israel. 

# What did the people of Israel do when they heard about the altar?

The people of Israel gathered together at Shiloh to go up and make war against those tribes when they heard about the altar. 

# What messengers did the people of Israel send to the people of Reuben, Gad, and the half tribe of Manasseh?

The people of Israel sent Phinehas, the son of Eleazor the priest, and ten leaders as messengers to Reuben, Gad, and the half tribe of Manasseh. 

# What messengers did the people of Israel send to the people of Reuben, Gad, and the half tribe of Manasseh?

The people of Israel sent Phinehas, the son of Eleazor the priest, and ten leaders as messengers to Reuben, Gad, and the half tribe of Manasseh. 

# What did the messengers of the people of Israel say to the people of Reuben, Gad, and the half tribe of Manasseh?

The messengers of the people of Israel said to the people of Reuben, Gad, and the half tribe of Manasseh, "What is this unfaithfulness you have committed against the God of Israel by building yourself an altar...?" 

# What were the people of Israel worried about if the people of Reuben, Gad, and the half tribe of Manasseh rebelled against Yahweh?

The people of Israel were worried that is the people of Reuben, Gad, and the half tribe of Manasseh rebelled against Yahweh, then Yahweh would be angry with the whole assembly of Israel. 

# What did the tribes of Reuben, Gad, and the half tribe of Manasseh say to the messengers of the people of Israel?

The tribes of Reuben, Gad, and the half tribe of Manasseh said to the messengers of Israel that they had built the altar, not for burnt offerings or sacrifices, but as a witness between them and the people of Israel that they will perform the service of Yahweh for future generations to see. 

# What did the tribes of Reuben, Gad, and the half tribe of Manasseh say to the messengers of the people of Israel?

The tribes of Reuben, Gad, and the half tribe of Manasseh said to the messengers of Israel that they had built the altar, not for burnt offerings or sacrifices, but as a witness between them and the people of Israel that they will perform the service of Yahweh for future generations to see. 

# What did Phinehas the priest and the other messengers say about the words they had heard from the Reubenites, the Gadites, and Manasseh?

Phinehas and the other messengers said that the words spoken by the Reubenites, Gadites, and Manasseh were good in their eyes. 

# What did the people of Israel do when Phinehas and the messengers reported back to them?

The people of Israel blessed God and spoke no more about making war. 

# What did the Reubenites and the Gadites name the altar?

The Reubenites and Gadites named the altar "Witness." 

# What did Joshua do after Yahweh had given rest to Israel from all their enemies?

After Yahweh had given rest to Israel from all their enemies, Joshua called for all Israel. 

# What did Joshua do after Yahweh had given rest to Israel from all their enemies?

After Yahweh had given rest to Israel from all their enemies, Joshua called for all Israel. 

# Who did Joshua say had fought for them?

Joshua said that Yahweh had fought for them. 

# What did Joshua tell the people not to mention?

Joshua told the people they should not mention the name of the gods of the nations that remained among them. 

# What did Joshua say Yahweh would do if they intermarried with the survivors of the nations who remained among them?

Joshua said to the people that Yahweh would cause them to perish from the good land they had been given if they intermarried with the survivors of the nations who remained among them. 

# What did Joshua say was going to happen to him?

Joshua said that he was going the way of all the earth. 

# What did Joshua say would make Yahweh bring on the people of Israel all the evil things?

Joshua said Yahweh would bring all the evil things on the people of Israel if they broke the covenant of Yahweh. 

# Who did Joshua speak to and where did he speak to them?

Joshua gathered all the tribes of Israel at Shechem and spoke to the elders of Israel, their leaders, their judges, and their officers. 

# What did Yahweh say he had given the people of Israel?

Yahweh said he had given the people of Israel land which they had not worked, cities which they had not built, and vineyards and olive groves which they did not plant. 

# What did Joshua say about himself and his house?

Joshua said he and his house would worship Yahweh. 

# How did the people of Israel answer Joshua?

The people of Israel answered Joshua by saying they would also worship Yahweh. 

# How did Joshua answer the people of Israel?

Joshua told the people of Israel they could not serve Yahweh because of their transgressions and sins. 

# What did the people of Israel finally say to Joshua?

The people of Israel finally said to Joshua, "No, we will worship Yahweh." 

# What did Joshua do to mark the covenant with the people made that day?

Joshua wrote these words in the book of the Law of God and set a large stone beneath the oak tree beside Yahweh's sanctuary. 

# Of what did Joshua say the stone would be a witness?

Joshua said the stone would be a witness against the Israelites because it had heard all the words said by Yahweh and the people of Israel. 

# How old was Joshua when he died?

Joshua was 110 years old when he died. 

# Whose bones had the people of Israel brought out of Egypt?

The people of Israel had brought the bones of Joseph out of Egypt. 

