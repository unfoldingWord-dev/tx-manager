# What kind of animal did Yahweh tell Moses to tell the people to bring as a burnt offering from the herd?

Yahweh told Moses to tell the people to bring as a burnt offering from the herd a male that was without blemish. 

# What did Yahweh tell the person to do to make the offering accepted on his behalf to make atonement for himself?

Yahweh told the person to put his hand on the head of the burnt offering to make it accepted on his behalf. 

# What were the priests to do with the blood of the bull?

The priests were to present the blood and splash it upon the altar at the front of the temple. 

# Who were the priests?

The priests were the sons of Aaron. 

# What was to be done with the inward parts and legs before placing them on the altar to be burned?

The inward parts and the legs were to be washed with water before being placed on the altar to be burned. 

# What would the burnt offering produce that would be pleasing to Yahweh?

The burnt offering would produce a sweet aroma that would be pleasing to Yahweh. 

# What animal did Yahweh tell Moses to tell the people to bring from the flock for a burnt offering?

Yahweh told the people to bring from the flock a male sheep or goat without blemish. 

# Which side of the altar must the male sheep or goat be killed?

The sheep or goat must be killed on the north side of the altar. 

# Where must Aaron's sons splash the blood of the sheep or goat?

Aaron's sons must splash the blood of the sheep or goat on all sides of the altar. 

# What kinds of birds did Yahweh say could be brought as a burnt offering?

Yahweh said that a dove or young pigeon could be brought as a burnt offering. 

# What kind of grain offering could be brought as an offering to Yahweh?

Fine flour could be brought as an offering to Yahweh. 

# What had to be done to prepare the fine flour before it was offered to Yahweh?

Oil and incense had to be added to the flour before it was offered to Yahweh. 

# To whom would the grain offering left belong?

Grain offering left after the burnt offering would belong to Aaron and his sons. 

# If the grain offering was baked with a flat iron pan, what must it be?

If the grain offering was baked with a flat iron pan, it must be of fine flour without yeast mixed with oil. 

# What substances were not to be in the grain offering?

Yeast and honey were not to be in the grain offering. 

# What substance must always be in the grain offering?

Salt must always be in the grain offering. 

# What fellowship offering could be offered from the herd?

A fellowship offering could be either male or female without blemish offered from the herd. 

# Where was the fellowship offering to be killed?

The fellowship offering was to be killed at the door of the tent of meeting. 

# What parts of the fellowship offering must be removed and placed on the altar?

The fat that connects to the inner parts, the lobe of the liver and the kidneys must be removed and placed on the altar. 

# What parts of the fellowship offering must be removed and placed on the altar?

The fat that connects to the inner parts, the lobe of the liver and the kidneys must be removed and placed on the altar. 

# Was there any difference in a fellowship offering that was taken from the flock instead of the herd?

No, there was no difference. 

# Was there any difference in a fellowship offering that was taken from the flock instead of the herd?

No, there was no difference. 

# Was there any difference in a fellowship offering that was taken from the flock instead of the herd?

No, there was no difference. 

# What different thing must be removed from the fellowship offering that comes from the flock?

The entire fat tail cut away close to the back bone must be removed if the fellowship offering comes from the flock. 

# To whom only did the fat belong?

The fat only belonged to Yahweh. 

# What did Yahweh tell the people not to eat in any place they would ever live?

Yahweh told the people not to eat fat or blood any place they would ever live. 

# About what kind of offering does the fourth chapter of Leviticus talk?

The fourth chapter of Leviticus talks about the sin offering. 

# How many times must the priest sprinkle blood from the sin offering before Yahweh, before the curtain of the most holy place?

The priest must sprinkle some blood from the sin offering seven times before Yahweh, before the curtain of the most holy place. 

# What parts of the bull were to be carried out to the place cleansed for Yahweh and poured on the ashes?

The skin of the bull and any remaining meat, with its head, legs, and inner parts, and its dung were to be carried out to the ashes. 

# If the whole assembly of Israel sinned without wanting to sin, who was to lay their hands on the sin offering?

The elders were to lay their hands on the sin offering if the whole assembly of Israel sinned without wanting to sin. 

# What would happen to the assembly of Israel if they followed the directions for the sin offering?

If the assembly if Israel followed the directions of the sin offering, they would be forgiven. 

# What was the animal to be offered if a ruler sinned?

If a ruler sinned, he was to offer a male goat without blemish. 

# What were the common people to bring as a sacrifice if they sinned?

Common persons were to bring a female goat without blemish to be a sin offering if they sinned. 

# Could a man bring a female lamb without blemish as a sacrifice for a sin offering?

Yes, a man could bring a female lamb without blemish as a sacrifice for a sin offering. 

# What is one sin of omission for which one would be held responsible?

If anyone sinned by not testifying about something he saw or heard, when he was required to testify, he would be held responsible. 

# What would one be declared who touched anything God had designated as unclean?

If anyone touched anything God had declared unclean, that person would be declared unclean and guilty. 

# What two things must the one who was guilty of a sin do?

The one who was guilty of a sin must confess whatever sin he commited and bring his guilt offering to Yahweh. 

# What two things must the one who was guilty of a sin do?

The one who was guilty of a sin must confess whatever sin he commited and bring his guilt offering to Yahweh. 

# What was the animal that should be brought to Yahweh for a guilt offering?

A female goat or sheep should be brought to Yahweh for a guilt offering. 

# If he could not afford to buy a lamb, what could he bring to Yahweh for a sin offering?

If he could not afford a lamb, he could bring to Yahweh for a sin offering two doves or two young pigeons. 

# If he could not afford two doves or two young pigeons, what could he bring for his sin offering?

If he could not afford two doves or two young pigeons, he could bring a tenth of an ephah of fine flour without any oil or incense on it. 

# What offering must be brought if anyone violated a command and sinned by failing to pay anything that was required by Yahweh?

This offering must be a ram without blemish from the flock valued in silver shekels. 

# What did one have to do if he sinned against his neighbor?

If a person sinned against his neighbor he had to restore whatever he took or the lost thing that he had found. 

# What did one have to do if he sinned against his neighbor?

If a person sinned against his neighbor he had to restore whatever he took or the lost thing that he had found. 

# What did one have to do if he sinned against his neighbor?

If a person sinned against his neighbor he had to restore whatever he took or the lost thing that he had found. 

# What did one have to do if he sinned against his neighbor?

If a person sinned against his neighbor he had to restore whatever he took or the lost thing that he had found. 

# What did one have to do who lied about any matter?

If one lied about any matter, he had to restore it in full and add one-fifth more. 

# What did someome have to bring to the priest for a guilt offering if he was guilty of the sins above?

If one was guilty of the sins above, he had to bring a ram without blemish from the flock. 

# How long did the burnt offering remain on the altar?

The burnt offering remained on the altar all night until morning. 

# What did the priest have to put on in order to remove the ashes from the altar?

The priest had to put on linen clothes and linen underclothes to take the ashes from the altar. 

# What did the priest have to do before carrying the ashes outside the camp?

The priest had to take off his linen clothes and put on other clothes before carrying the ashes away from the camp. 

# What had to be kept going at all times?

The fire on the altar had to be kept going at all times. 

# What had to be kept going at all times?

The fire on the altar had to be kept going at all times. 

# What were the priests to do with the leftover grain offering?

The priests could eat the grain offering leftover without yeast. 

# What did the sons of Aaron have to do when their sons were anointed?

The sons of Aaron had to present a grain offering of a tenth part of an epaph of fine flour, half in the morning and half in the evening. 

# How did this grain offering have to be prepared?

This grain offering had to be made with oil in a baking pan, soaked, then baked in pieces. 

# Who would offer this grain offering?

The son of Aaron who was to become the new high priest would offer this grain offering. 

# According to the law of the sin offering, what did the priest have to do to the offering?

The priest had to eat the sin offering. 

# What had to be done with the clay pot in which a bloody garment was boiled?

The clay pot in which the bloody garment was boiled had to be broken. 

# What part of the sin offering was not to be eaten?

No part of the sin offering was to be eaten from which blood was brought into the tent of meeting to make atonement in the holy place. 

# What offering was like the guilt offering?

The sin offering was like the guilt offering. 

# What could the priest keep from anyone's burnt offering?

The priest could keep the hide of that offering. 

# Which offering belonged to the priest?

The grain offering belonged to the priest. 

# Which offering belonged to the priest?

The grain offering belonged to the priest. 

# What had to be done with the meat of the sacrifice that had not been eaten by the third day?

The meat of the sacrifice that had not been eaten by the third day had to be burnt. 

# What had to be done to anyone who ate fat from an animal or blood from a bird or an animal?

Anyone who ate fat from an animal or blood from a bird or animal had to be cut off from his people. 

# What had to be done to anyone who ate fat from an animal or blood from a bird or an animal?

Anyone who ate fat from an animal or blood from a bird or animal had to be cut off from his people. 

# What had to be given to the priest after the fat had been burned on the altar?

After the fat was burned on the altar, the right thigh would be given to the priest. 

# What did Yahweh tell Moses to do with Aaron and his sons?

Yahweh told Moses to take Aaron and his sons, the garments and the anointing oil, the bull, two rams, and the basket of unleavened bread to the entrance to the tent of meeting. 

# Who did Yahweh tell Moses to call to the entrance of the tent of meeting?

Yahweh told Moses to call all the assembly at the entrance of the tent of meeting. 

# What clothing did Moses put on Aaron?

Moses clothed Aaron with a tunic, sash, and robe. 

# What did Moses place in the breastpiece?

Moses placed the Urim and the Thummim in the breastpiece. 

# What was the holy crown?

The holy crown was the golden plate. 

# What did Moses anoint with the anointing oil?

Moses anointed the tabernacle and everything in it with the anointing oil. 

# How did Moses consecrate Aaron?

Moses consecrated Aaron by anointing him with anointing oil. 

# What did Moses do with the blood of the bull that was brought for the sin offering?

Moses took the blood and put it on the horns of the altar with his finger. He then poured out the blood at the base of the altar. 

# What did Moses do with the blood of the bull that was brought for the sin offering?

Moses took the blood and put it on the horns of the altar with his finger. He then poured out the blood at the base of the altar. 

# What did Moses do with the blood from the ram used for the burnt offering?

Moses killed the ram and splashed its blood against every side of the altar. 

# What did Moses do with the blood from the ram used for the burnt offering?

Moses killed the ram and splashed its blood against every side of the altar. 

# What did Moses do with some of the blood from the second ram, the ram of consecraton?

Moses took some of the blood from the ram of consecration and placed it on the tip of Aaron's right ear, the thumb of his right hand, and the big toe on his right foot. 

# How long were the priests to remain at the entrance to the tent of meeting?

The priests were to remain at the entrance to the tent of meeting for seven days and seven nights. 

# What was Aaron and his sons' response to what Yahweh had ask them to do?

They did all the things God had commanded them through Moses. 

# On what day did Moses call Aaron and his sons and the elders of Israel?

Moses called Aaron and his sons and the elders of Israel on the eighth day. 

# What two animals did Moses ask Aaron and his sons to bring to offer to Yahweh?

Moses ask Aaron to bring a calf from the herd and a ram without blemish. 

# What animals did Moses ask Aaron to tell the people of Israel to bring to offer to Yahweh?

Moses asked Aaron to tell the people to bring a male goat, a calf, a lamb, an ox, and a ram to offer to Yahweh. 

# What animals did Moses ask Aaron to tell the people of Israel to bring to offer to Yahweh?

Moses asked Aaron to tell the people to bring a male goat, a calf, a lamb, an ox, and a ram to offer to Yahweh. 

# Why had Yahweh commanded them to do this?

Yahweh commanded them to do this that his glory might appear to them. 

# After Aaron made the offerings as Moses had said, what did Aaron do for the people?

After Aaron made the offerings, he lifted up his hands and blessed the people. 

# What happened when the glory of Yahweh appeared to the people?

When the glory of Yahweh appeared to the people, fire came out and consumed the burnt offering and fat on the altar. 

# What did the people do when the fire came from Yahweh?

When the fire came out from Yahweh, the people shouted and lay facedown. 

# Who offered unapproved fire to Yahweh?

Nadab and Abihu, sons of Aaron, offered unapproved fire to Yahweh. 

# What happened to these two men as a result of this act?

Fire came out from Yahweh and devoured them. 

# Who was called upon by Moses to carry the bodies out of the tabernacle?

Mishael and Elzaphan, the sons of Uzziel, the uncle of Aaron, were called by Moses to carry the bodies away. 

# What did Moses say to Aaron and his sons?

Moses said to them that they should not go out of the tent of meeting or they would die. 

# What did Yahweh say to Aaron and his sons about what they should not drink?

Yahweh said to Aaron and his sons they should not drink wine or strong drink before entering the house of meeting. 

# Why was Moses angry with Eleazer and Ithamar, the remaining sons of Aaron?

Moses was angry with Eleazer and Ithamar because they had let the goat for the sin offering burn up. 

# What living things that live on the earth did Yahweh tell Moses and Aaron the people of Israel could eat?

Yahweh told Moses and Aaron to tell the people of Israel they could eat any living thing that has a split hoof and that chews cud. 

# Were the people allowed to eat an animal if they only had a split hoof or if they only chewed the cud?

If an animal possessed only one of the two traits they were not allowed to eat it. 

# What animals living in the water could be eaten by the people of Israel?

Animals that live in the water which have fins and scales may be eaten by the people of Israel. 

# What kind of falcons, hawks, and ravens did Yahweh say must be detested and could not be eaten?

Yahweh said that no falcons, hawks or ravens could be eaten. They all must be detested. 

# What kind of falcons, hawks, and ravens did Yahweh say must be detested and could not be eaten?

Yahweh said that no falcons, hawks or ravens could be eaten. They all must be detested. 

# What kind of falcons, hawks, and ravens did Yahweh say must be detested and could not be eaten?

Yahweh said that no falcons, hawks or ravens could be eaten. They all must be detested. 

# What kind of falcons, hawks, and ravens did Yahweh say must be detested and could not be eaten?

Yahweh said that no falcons, hawks or ravens could be eaten. They all must be detested. 

# What kinds of insects could be eaten by the people?

Insects that walk on legs above their feet, which they use to leap on the ground, may be eaten by the people. 

# What should the people do to four-legged insects that fly?

The people should detest any four-legged insect that flies. 

# What animals that creep on the ground are considered unclean?

The weasel, the rat, every kind of large lizard, the gecko, the monitor lizard, the lizard, the skink, and the chameleon are considered unclean. 

# What animals that creep on the ground are considered unclean?

The weasel, the rat, every kind of large lizard, the gecko, the monitor lizard, the lizard, the skink, and the chameleon are considered unclean. 

# What happens to anything that an unclean animal touches?

Anything that an unclean animal touches becomes unclean. 

# What does Yahweh say about things that crawl on the ground?

All the animals that crawl upon the ground are to be detested and are unclean. 

# Why did Yahweh say that the people of Israel must be holy?

Yahweh said that the people must be holy because he is holy. 

# What did Yahweh say to Moses about women who gave birth to a male child?

Yahweh said to Moses that a woman who gave birth to a male child would be unclean for seven days and on the eighth the child would be circumcised. 

# What did Yahweh say to Moses about women who gave birth to a male child?

Yahweh said to Moses that a woman who gave birth to a male child would be unclean for seven days and on the eighth the child would be circumcised. 

# What was a woman required to do following her being unclean?

She was required to go through purification for thirty-three days and not enter the tabenacle or touch anything holy during this time. 

# What was a woman required to do diferently if she gave birth to a female child?

If a woman gave birth to female child, she was to be unclean for two weeks and go through purification for sixty-six days. 

# What was a woman required to do at the end of her purification?

At the end of her purification, a woman was required to bring to the priest a one year old lamb for a burnt offering and a pigeon or dove for a sin offering. 

# What if the woman who gave birth to a child could not afford a lamb?

If the woman could not afford a lamb, she was required to bring two young pigeons or two doves for the burnt and sin offerings. 

# What would happen to the woman after she did these things?

The woman would be clean after the priest offered the offerings for her atonement. 

# What did Yahweh say a person must do if one has on his skin a swelling, scab, or bright spot that becomes infected?

Yahweh said that anyone who has a skin infection must come to Aaron or to one of his sons, the priests. 

# What must be done if the priest determines that the swelling, scab, or bright spot may not be infectious?

If the priest cannot determine that the swelling, scab, or bright spot is infectious, the person must be isolated for one week to be examined again. 

# What if the swelling, scab, or bright spot proves not to be infectious?

If the swelling, scab, or bright spot is not infectious, the priest will pronounce him clean after he washes his clothes. 

# What are the three conditions that the swelling, scab, or bright spot may show if it is to be declared infectious?

The three conditions which the swelling, scab, or bright spot may show to be pronounced infectious are white swelling in the skin, the hair has turned white, and there is raw flesh in the swelling. 

# What are the three conditions that the swelling, scab, or bright spot may show if it is to be declared infectious?

The three conditions which the swelling, scab, or bright spot may show to be pronounced infectious are white swelling in the skin, the hair has turned white, and there is raw flesh in the swelling. 

# If the priest determines that this is a chronic skin disease, what must the priest do?

If the priest determines that this is a chronic skin disease, he must pronounce the person unclean, but the priest does not isolate him. 

# If the skin disease covers the person's entire body and raw flesh can be seen, what is the person declared to be?

If the skin disease covers the person's entire body and raw flesh can be seen, the person is declared to be unclean. 

# How may the unclean person become clean again?

The unclean person may become clean again if the raw flesh turns white and he is pronounced clean by the priest. 

# How may the unclean person become clean again?

The unclean person may become clean again if the raw flesh turns white and he is pronounced clean by the priest. 

# What must a priest do if he examines a person who had a boil but now has a swelling or bright spot that appears deeper under the skin where the boil was and the hair there has turned white?

The priest must declare that person unclean. 

# What must a priest do if he examines a person who had a boil but now has a swelling or bright spot that appears deeper under the skin where the boil was and the hair there has turned white?

The priest must declare that person unclean. 

# What kind of infectious disease may cause one to be unclean if it is found on the head or chin?

If a man or woman has an itching disease on the head or chin it may be infectious and make the person unclean. 

# What would a man who lost his hair be pronounced?

A man who lost his hair would be pronounced clean. 

# What one condition on a man's bald head would result in the man being pronounced unclean?

If the bald man's head had reddish-white sores that the priest decided was an infectious disease, he would be pronounced unclean. 

# What must the unclean person do to let others know that he is unclean?

The unclean person must wear torn clothes, loosely hung hair, cover his face up to his nose, and shout "unclean, unclean" when in the presence of others. He must also live alone away from the camp. 

# What must the unclean person do to let others know that he is unclean?

The unclean person must wear torn clothes, loosely hung hair, cover his face up to his nose, and shout "unclean, unclean" when in the presence of others. He must also live alone away from the camp. 

# What must the priest do with any garment of wool or linen or leather or anything made for leather which was found to be infected with mildew?

If any garment of wool or leather or anything made from leather was found to be infected with mildew, the priest must burn it. 

# Where must the priest examine the diseased person on the day of his cleansing?

The priest must examine the diseased person outside of the camp to see if the infection is healed. 

# What did the priest command the diseased person to bring for the pronouncement of his cleansing?

The priest commanded the diseased person bring two live clean birds, cedar wood, scarlet yarn, and hyssop. 

# After the priest sprinkled the mixture of blood, water, cedar wood and hyssop over the diseased person seven times, what did he do with the remaining bird?

After the priest sprinkled the mixture over the diseased person seven times, he released the remaining bird to fly into the fields. 

# What must the person being cleansed do after the priest has pronounced him clean?

The person being cleansed must wash his clothes, shave off all of his hair, bathe himself in water, and live outside his tent for seven days. 

# What must the person being cleansed do after the priest has pronounced him clean?

The person being cleansed must wash his clothes, shave off all of his hair, bathe himself in water, and live outside his tent for seven days. 

# On the eighth day, what animals should the person being cleansed bring to the priest if he can afford them?

On the eighth day, the person being cleansed should bring to the priest, if he can afford them, two male lambs without blemish, one female lamb a year old without blemish, and three tenths of an ephah of fine flour mixed with oil and a log of oil. 

# If the person being cleansed is poor and cannot afford these sacrifices, what may he bring instead?

If the person being cleansed is poor and cannot afford the lambs, he may bring one male lamb, one tenth of an ephah of fine flour mixed with oil, a log of oil, and two doves or young pigeons. 

# Where does the priest place the oil that is used in the cleansing?

The priest places the oil on the right ear, the right thumb, the right big toe, and the remainder on the head of the one being cleansed. 

# Where does the priest place the oil that is used in the cleansing?

The priest places the oil on the right ear, the right thumb, the right big toe, and the remainder on the head of the one being cleansed. 

# What may cause a house to be pronounced unclean by a priest?

A house may be pronounced unclean by a priest if it has mildew that cannot be stopped. 

# What could happen to the house if the mildew spreads and cannot be stopped?

The house could be destroyed if the mildew spreads and cannot be stopped. 

# How can the house be pronounced clean if the mildew is stopped?

The house may be pronounced clean by a priest by sprinkling a mixture of blood of a bird and water, cedar wood, hyssop, and scarlet yarn. 

# What did Yahweh say to Moses and Aaron was the condition of a man who has a flow of infected fluid?

Yahweh said to Moses and Aaron that any man who has a flow of infected fluid coming out of his body is unclean. 

# What happens to the person who touches the person who is unclean because of a flow of infected fluid?

Anyone who touches the unclean person will be unclean himself and will need to bathe in water, wash his clothes, and will be unclean until evening. 

# In what kind of water must the person being cleansed from an infected flow of fluid bathe?

The person being cleansed from an infected flow of fluid must bathe in running water. 

# What must the unclean man present to the priest for a sin offering and a burnt offering?

The unclean man must present to the priest two doves or two young pigeons for a sin offering and a burnt offering. 

# What is the condition of anything or any person that has contact with a man's semen?

They must be washed with water and will be unclean until evening. 

# What is the condition of anything or any person that has contact with a man's semen?

They must be washed with water and will be unclean until evening. 

# What is the condition of anything or any person that has contact with a man's semen?

They must be washed with water and will be unclean until evening. 

# How long will woman be impure after she menstruates?

She will be impure for seven days. 

# How long will a man be unclean if he sleeps with a woman who is menstruating and her flow touches him?

He will be unclean for seven days. 

# What is a woman to bring as a sacrifice on the eight day after her flow of blood stops?

She is to bring two doves or two young pigeons. 

# What did Yahweh tell Moses to warn Aaron not to do when coming into the most holy place inside the curtain?

Yahweh told Moses to warn Aaron not to come into the most holy place inside the curtain at just any time. 

# What must Aaron bring with him when he enters the most holy place?

Aaron must bring with him a young bull for a sin offering and a ram as a burnt offfering. 

# What must Aaron do before he puts on the priestly garments?

Aaron must bathe himself in water before putting on the priestly garments. 

# Who must provide Aaron two male goats and one ram?

The assembly of Israel must give Aaron two male goats and one ram. 

# Why did Aaron cast lots for the goats?

Aaron cast lots for the goats to choose which one to offer to Yahweh and which one to be the scapegoat. 

# What happens to the goat that the lot fell to be the scapegoat?

The goat that the lot fell to be the scapegoat is presented before Yahweh for atonement and then is sent away into the wilderness. 

# For whom does Aaron present the bull?

Aaron presents the bull as a sin offering for himself and his family. 

# What must cover the atonement lid which is over the covenant decrees so that Aaron will not die?

A cloud of sweet incense must cover the atonement lid so that Aaron will not die. 

# Who else must be in the tent with Aaron when he makes atonement in the most holy place?

No one else must be in the tent when Aaron makes atonement in the most holy place. 

# What must Aaron do when he places his hands on the head of the scapegoat?

Aaron must confess over the scapegoat all the wickedness of the people of Israel, all their rebellion, and all their sins. 

# What is Aaron to do with the priestly garments?

Aaron is to take off the priestly garments and leave them in the tent of meeting. 

# When did Yahweh say the day of atonement should take place?

On the tenth day of the seventh month, the atonement would be made each year. 

# If a man kills an ox, lamb, or goat without bringing it to the entrance of the tent of the assembly to offer it as a sacrifice to Yahweh, of what sin is he guilty?

The man who kills an ox, lamb, or goat without bringing it to the entrance of the tent of the assembly to offer it as a sacrifice to Yahweh is guilty of bloodshed and must be cut off from among his people. 

# If a man kills an ox, lamb, or goat without bringing it to the entrance of the tent of the assembly to offer it as a sacrifice to Yahweh, of what sin is he guilty?

The man who kills an ox, lamb, or goat without bringing it to the entrance of the tent of the assembly to offer it as a sacrifice to Yahweh is guilty of bloodshed and must be cut off from among his people. 

# What was the purpose of this command?

The purpose of this command was to get the people to offer their sacrifices to Yahweh at the entrance to the tent of meeting instead of in the open field. 

# What would this statute end?

This statute would stop the people from offering sacrifices to the goat idols. 

# What does Yahweh say makes atonement?

Yahweh says that the blood makes atonement. 

# What does Yahweh say must be done to any animal or bird that is killed to eat by any of the people of Israel or any foreigner who lives among them?

Yahweh says that any of the people of Israel or a foreigner living among them who kills an animal or bird to eat must pour the blood from it and cover the blood with earth. 

# What must a person do who has eaten an animal that has died or been torn apart by animals?

A person who has eaten an anmal that has died or has been torn apart by animals must wash his clothes and bathe himself in water and remain unclean until evening. 

# What must he do if he does not wash his clothes and bathe himself in water?

If he does not wash his clothes and bathe himself in water, then he must bear his own guilt. 

# What two places did Yahweh tell the people they could not do like the people there?

Yahweh told the people they could not do like the people of Egypt or Canaan. 

# What is one group of people that God forbid having sexual relations with?

Yahweh told the people they could not have sexual relations with any close relative. 

# Why is a man not to have sexual relations with a woman during her menstruation?

A man may not have sexual relations with a woman during her menstruation because during that time she is unclean. 

# What may the people not sacrifice to Molech?

The people may not sacrifice their children to Molech. 

# What two sexual relations do verses 22 and 23 not allow?

Verses 22 and 23 do not allow sexual relations with other men or animals. 

# What two sexual relations do verses 22 and 23 not allow?

Verses 22 and 23 do not allow sexual relations with other men or animals. 

# What happened to the people who lived there before the people of Israel?

The people who lived there before the people of Israel defiled the land and the land vomited them out. 

# What will happen to any of the people or the foreigners who live among them who do any of these detestable things?

Any of the people who do any of these detestable things will be cut off from among their people. 

# What two things did Yahweh tell the people they must do?

Yahweh told the people that they must respect their father and mother and keep his Sabbaths. 

# What two things did Yahweh tell the people they must do?

Yahweh told the people that they must respect their father and mother and keep his Sabbaths. 

# Why did Yahweh tell the people to leave the corners of their fields unharvested and to leave some of the grapes on the vine or that fell on the ground?

The unharvested grain and grapes must be left for the poor and the foreigner. 

# To whom should the people not show favoritism?

The people should not show favoritism to someone because he is poor or rich, but instead judge the neighbor righteously. 

# What are the people to do instead of taking vengeance or holding a grudge?

Instead of taking vengeance or holding a grude, the people are to love their neighbor as themselves. 

# What must the people do when planting seeds in the field?

When planting in the field, the people must not plant two kinds of seed in the same field. 

# How long must a planter of a fruit tree wait before he can eat the fruit himself?

A planter of a fruit tree must wait until the fifth year before he can eat the fruit of the tree himself. 

# What pagan habits were the people told not to follow?

The pagan habits the people were told not to follow are shaving the sides of the head and cutting off the edges of the beard. 

# Who did Yahweh tell the people to arise before and honor?

Yahweh told the people to rise before the gray-headed person and honor the old man. 

# Why did Yahweh say that the people of Israel should love the foreigner as they love themsleves?

Yahweh told the people to love the foreigner because the people of Israel were once foreigners in the land of Egypt. 

# What would happen to anyone among the people of Israel who gave their child to Molech?

Anyone who gave their child to Molech would be put to death. 

# What would Yahweh do to the man if the people did not put him to death?

If the people did not put him to death, Yahweh says he would cut him off from his people. 

# To whom did Yahweh tell the people not to turn?

Yahweh told the people not to talk with those who talk to the dead or to the spirits. 

# What was the result of a man having sexual relations with another man?

A man who had sexual relations with another man had done something detestable and both would be put to death. 

# If a man or woman had sexual relations with an animal, what would be done with them?

The man, the woman, and the animal would all be put to death. 

# If a man or woman had sexual relations with an animal, what would be done with them?

The man, the woman, and the animal would all be put to death. 

# How did Yahweh describe the land that he had given the people of Israel ?

Yahweh called the land "a land of milk and honey." 

# For the death of which person was a priest allowed to make himself unclean?

Priests were only allowed to make themselves unclean for very close relatives. 

# For the death of which person was a priest allowed to make himself unclean?

Priests were only allowed to make themselves unclean for very close relatives. 

# What restrictions were places on the priests concerning their hair and beards?

Priests were not allowed to shave their heads or the corners of their beards. 

# What would happen to a priest's daughter who defiled herself by becoming a prostitute?

A priest's daughter who defiled herself by becoming a prostitute would be burned. 

# What must a high priest avoid even if it is his father or mother?

A high priest must not go anywhere there is a dead body present, even if it is his father or mother. 

# What kind of woman must the priest not marry?

The priest must not marry a widow, a divorced woman, or a woman who is a prostitute. 

# What kind of man did Yahweh not want to approach him to perform the offerings?

Yahweh did not want any man with a bodily defect to approach him. 

# What does Yahweh say will profane his holy name?

Yahweh says that any one who is unclean for any reason and approaches the holy things will profane his holy name. 

# What does Yahweh say will profane his holy name?

Yahweh says that any one who is unclean for any reason and approaches the holy things will profane his holy name. 

# What must a priest do when he touches anything that makes him unclean?

He must bathe in water and remain unclean until evening. 

# What might happen to priests who do not follow Yahweh's instructions?

They would be guilty of sin and could die for profaning Yahweh. 

# Who are the only people who can eat anything that is holy?

The only persons who can eat anything that is holy are the priest and his family, and slaves he may have bought. 

# Who are the only people who can eat anything that is holy?

The only persons who can eat anything that is holy are the priest and his family, and slaves he may have bought. 

# Can a priest's daughter who has married someone who is not a priest eat the holy food?

No, unless she is divorced or widowed and returns to live in her father's house. 

# What must a man do who eats holy food without knowing it?

If a man eats holy food without knowing it, he must repay the priest and add one-fifth to it. 

# What kind of animal would be accepted as a sacrifice?

It must be a male animal without blemish from the cattle, sheep, or goats. 

# What is the most important requirement for any animal that is to be sacrificed to Yahweh?

Any animal sacrificed to Yahweh must be unblemished. 

# How old must a calf, sheep, or goat be to be offered as a sacrifice to Yahweh?

A calf, sheep, or goat must be at least eight days old to be offered as a sacrifice to Yahweh. 

# When must a thank offering be eaten?

It must be eaten on the same day that it is sacrificed. 

# What does Yahweh say about work and the Sabbath?

Yahweh says that people may work for six days, but the seventh day, the Sabbath, is to be a day of rest. 

# What festival is to be celebrated in the first month on the fourteenth day?

Yahweh's Passover is to be celebrated in the first month on the fourteenth day. 

# What festival follows Passover on the fifteenth day of the first month?

The Festival of Unleavened Bread follows Passover on the fifteenth day of the first month. 

# What must the people bring to the priest after the first harvest in the land that Yahweh is going to give them?

The people must bring to the priest a sheaf of firstfruits after the first harvest in the land that Yahweh is going to give them. 

# What date did Yahweh set for the Day of Atonement?

Yahweh set the tenth day of the seventh month as the Day of Atonement. 

# What must the people not do on the Day of Atonement?

The people must not do any work on the Day of Atonement. 

# What festival did Yahweh say would take place on the fifteenth day of the seventh month?

Yahweh said that the Festival of Shelters for Yahweh would take place on the fifteenth day of the seventh month. 

# What must the people use to rejoice during the Festival of Shelters for Yahweh?

The people must use the best fruit from the trees, branches of palm trees, and leafy branches of thick trees, and willows from streams to rejoice before Yahweh. 

# Where were the people of Israel to live during the Festival of Shelters for Yahweh?

The people of Israel were to live in small shelters for seven days during the Festival of Shelters for Yahweh. 

# What must Aaron do with the pure oil the people are to bring him?

Aaron must keep a lamp burning before the covenant decrees in the tent of the assembly from evening until morning every day. 

# What must the priest put in two rows of six each Sabbath?

The priest must put twelve loaves in two rows of six each Sabbath. 

# What must the priest put in two rows of six each Sabbath?

The priest must put twelve loaves in two rows of six each Sabbath. 

# Who is allowed to eat the offering of the twelve loaves?

Aaron and his sons will be eat it in the holy place. 

# What were the people of Israel told to do to the man who blasphemed Yahweh?

Yahweh told the people of Israel to take the man outside the camp, place their hands on him, and stone him to death. 

# What must happen to a man who kills another man?

He must certainly be put to death. 

# What did Yahweh say must be done to anyone who causes death or injury to another person?

Yahweh said to the people that what they have done to another should be done to them; an eye for an eye, a tooth for a tooth. 

# What did Yahweh say must be done to anyone who causes death or injury to another person?

Yahweh said to the people that what they have done to another should be done to them; an eye for an eye, a tooth for a tooth. 

# What did Yahweh say should be done after the fields and vineyards are planted, pruned, and harvested for six years?

Yahweh said that after six years of planting, pruning, and harvesting the fields and vineyards, the seventh year should be a Sabbath of rest for the fields and vineyards. 

# What must be done on the forty-ninth year, the tenth day of the seventh month?

A loud trumpet must be blown everywhere during the forty-ninth year, the tenth day of the seventh month. 

# What will the fiftieth year be called?

The fiftieth year will be called the year of jubilee. 

# What significant event will take place during the jubilee year?

During the jubilee year, property and slaves will be returned to their families. 

# What should be eaten during the jubilee year?

Only the food that grows by itself should be eaten during the jubilee year. 

# What must the people consider when buying or selling land?

People should consider how many years there are to the next jubilee year. The more years there are, the more valuable is the land. 

# What must the people consider when buying or selling land?

People should consider how many years there are to the next jubilee year. The more years there are, the more valuable is the land. 

# What must the people consider when buying or selling land?

People should consider how many years there are to the next jubilee year. The more years there are, the more valuable is the land. 

# How will Yahweh take care of his people during the seventh year, the Sabbath year, when crops are not to be grown?

Yahweh told the people that the harvest the sixth year would exceed the normal harvest by three times, so there would be food for the seventh year. 

# What did Yahweh say to the people about permanent ownership of land?

Yahweh said to not sell the land permanently to a new owner because the land belonged to him. 

# What property is not to be returned during the jubilee year?

A house bought in a walled city will become permanent property of the man who bought it after a year. 

# How are the people to treat a fellow countryman who becomes poor and can no longer provide for himself?

The people are to help him, not charge him interest or try to profit from him in any way. 

# How are the people to treat a fellow countryman who becomes poor and can no longer provide for himself?

The people are to help him, not charge him interest or try to profit from him in any way. 

# How should the people treat a fellow countryman who has sold himself as a slave?

The people should treat a fellow countryman who has sold himself as a slave as a hired-servant, not made to work like a slave. 

# What does Yahweh say to the people they should not make?

Yahweh says to the people they should not make idols. 

# What must the people do to make sure Yahweh sends rain and harvest?

Yahweh says the people must walk with his laws and keep his commandments, and obey them to receive his rain and harvest. 

# What will Yahweh do to make the people safe?

Yahweh will remove the dangerous animals and cause the sword to not pass through the land. 

# If the people do what Yahweh tells them to do, what does he promise to do for them?

If the people do what Yahweh tells them to do, he promises to walk among them, be their God, and they will be his people. 

# What kind of disease and fever did Yahweh say he would send on Israel if they did not obey his commandments?

Yahweh says he would send disease and fever that would destroy their eyes and drain away their lives if they did not obey his commandments. 

# What does Yahweh say he will do if the people do not obey his commandments and decrees?

Yahweh says if the people do not obey his commandments, they will be punished seven times as severely for their sins. 

# What did Yahweh say he would do to the weather if Israel did not obey his commandments?

Yahweh said he would make the sky over them like iron (drought). 

# What did Yahweh say he would do to the weather if Israel did not obey his commandments?

Yahweh said he would make the sky over them like iron (drought). 

# Yahweh said if Israel wouldn't listen to him, he would send dangerous animals against them. What did Yahweh say those animals would do?

Yahweh said those animals would steal their children, destroy their cattle and make them few in number. 

# Yahweh said if Israel wouldn't listen to him, he would send dangerous animals against them. What did Yahweh say those animals would do?

Yahweh said those animals would steal their children, destroy their cattle and make them few in number. 

# If the people do not obey Yahweh, have they lost all hope?

Yahweh says that if the people will confess their sins, the sins of their fathers, their treason against Yahweh, and humbly accept the punishment for their sin, he will call to mind the covenant he made with Jacob, Isaac, and Abraham. 

# If the people do not obey Yahweh, have they lost all hope?

Yahweh says that if the people will confess their sins, the sins of their fathers, their treason against Yahweh, and humbly accept the punishment for their sin, he will call to mind the covenant he made with Jacob, Isaac, and Abraham. 

# If the people do not obey Yahweh, have they lost all hope?

Yahweh says that if the people will confess their sins, the sins of their fathers, their treason against Yahweh, and humbly accept the punishment for their sin, he will call to mind the covenant he made with Jacob, Isaac, and Abraham. 

# In spite of their sin, what does Yahweh promise to do?

Yahweh promises not to reject them or detest them so as to completely destroy them and do away with the covenant he made with them, so that he may be their God. 

# What is the purpose of the standard value?

When a person is dedicated to Yahweh, he may make a special vow that requires him to use the standard value. 

# What is the standard value of a man between the ages of twenty and sixty?

A man between the ages of twenty and sixty has a standard value of fifty shekels of silver. 

# What is the standard value of a woman between the ages of twenty and sixty?

A woman between the ages of twenty and sixty has the standard value of thirty shekels. 

# What if the one making the vow is unable to afford the standard value of the person he is dedicating?

If the one making the vow is not able to afford the standard value, he may be presented to the priest and the priest will value that person by the amount the one making the vow is able to afford. 

# What other things may the priest value that are to be presented to Yahweh?

The priest may also value an animal to be presented for sacrifice, a man's house, or some of his land. 

# What other things may the priest value that are to be presented to Yahweh?

The priest may also value an animal to be presented for sacrifice, a man's house, or some of his land. 

# What other things may the priest value that are to be presented to Yahweh?

The priest may also value an animal to be presented for sacrifice, a man's house, or some of his land. 

# What must a man do with a field he has sanctified to Yahweh in the year of the jubilee?

When a man has sanctified a field to Yahweh and the year of the jubilee comes, the priest will figure the estimated value of the field up to the year of the jubilee and the man must pay its value on that day as a holy gift to Yahweh. 

# Which of the animals belongs only to Yahweh?

The firstborn of all the animals belongs only to Yahweh. 

# What part of the things dedicated to Yahweh may be sold or redeemed?

Nothing dedicated to Yahweh may be sold or redeemed. 

# If a man redeems any of his tithe, what must he add to it?

If a man redeems any of his tithe, he must add a fifth to its value. 

