# What did God tell Zephaniah he would do to the birds of the heavens, the fish of the sea and to man?

God said He would destroy them and cut them off. 

# What did God tell Zephaniah he would do to the birds of the heavens, the fish of the sea and to man?

God said He would destroy them and cut them off. 

# What is the name of the idol of which God said he would cut off every remnant?

He would cut off every remnant of Baal. 

# Who did the ones on the housetops worship?

The ones on the housetops worship the heavenly bodies. 

# What ere the people to do in the presence of Yahweh?

They were to be silent in the presence of Yahweh. 

# Who did Yahweh say he would punish on the day of sacrifice?

Yahweh will punish the princes and the king's sons, everyone dressed in foreign clothes, those who leap over the door sill, and those who fill their master's house with violence and deceit. 

# What sounds will come up from the Fish Gate and the Second Quarter in that day?

A cry of distress, and wailing will come in that day. 

# What will happen to the merchants in that day?

They will be ruined, and all those who are weighed down with silver will be cut off. 

# What did some of the men in Jerusalem say about Yahweh?

They said, "Yahweh will not do anything, either good or evil!" 

# What day will be a day of fury, a day of anguish, and a day of darkness?

The great day of Yahweh will be a day of fury, anguish, and darkness. 

# What day will be a day of fury, a day of anguish, and a day of darkness?

The great day of Yahweh will be a day of fury, anguish, and darkness. 

# Whose blood will be poured out like dust on the day of Yahweh?

Those who have sinned against God. 

# What will not be able to save them on that day?

Their silver and their gold will not be able to save them. 

# What must the people do to avoid the fierce anger of Yahweh's wrath?

The people must seek righteousness and humility to avoid Yahweh's wrath. 

# What must the people do to avoid the fierce anger of Yahweh's wrath?

The people must seek righteousness and humility to avoid Yahweh's wrath. 

# What will happen to those who will not heed the warning of Yahweh?

All peoples who will not heed the warning of Yahweh will be uprooted and destroyed. 

# What will happen to those who will not heed the warning of Yahweh?

All peoples who will not heed the warning of Yahweh will be uprooted and destroyed. 

# What cities will Moab and Ammon become like?

Moab will become like Sodom, and the people of Ammon like Gomorrah. 

# What kind of birds will nest in the top of Assyria's pillars?

Owls will nest in the tops of Assyria's pillars. 

# What will become of the exultant city?

The exultant city will become a horror, a place for beasts to lie down in. 

# What are the princes of the violent city like?

The princes of the violent city are like roaring lions. 

# When will Yahweh dispense justice?

Yahweh will dispense justice from morning to morning. 

# What did Yahweh hope the people would do?

Yahweh hoped the people would fear him and accept correction. 

# What decision has Yahweh made about the nations?

Yahweh has decided to assemble the nations and pour out his anger and wrath on them. 

# What will Yahweh then call the people to do?

Yahweh will call the people to serve him standing shoulder to shoulder. 

# How will the remnant of Israel change after this?

The remnant of Israel will no longer commit injustice and speak lies. 

# Why should Israel sing and cheer?

Israel should sing and cheer because Yahweh has taken away their punishment. 

# Why should Israel sing and cheer?

Israel should sing and cheer because Yahweh has taken away their punishment. 

# Who will Yahweh rescue from those who have mistreated Israel?

Yahweh will rescue the lame and gather together the outcast. 

# Why will all the nations respect and praise Israel?

All the nations will respect and praise Israel when they see that Yahweh has restored them. 

