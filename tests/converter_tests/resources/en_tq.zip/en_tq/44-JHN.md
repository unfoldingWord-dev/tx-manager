# What was in the beginning?

In the beginning was the word. 

# Who was the word with?

The word was with God. 

# What was the word?

The word was God. 

# Who was the word with?

The word was with God. 

# Was anything made without the word?

All things were made through him, and without him there was not one thing made that has been made. 

# What was in the word?

In him was life. 

# What was the name of the man sent from God?

His name was John. 

# What did John come to do?

He came as a witness to testify about the light, that all might believe through him. 

# Did the world know or receive the light John came to testify about?

The world did not know the light John came to testify about and that light's own people did not receive him. 

# Did the world know or receive the light John came to testify about?

The world did not know the light John came to testify about and that light's own people did not receive him. 

# What did the light do for those who believed on his name?

To those who believed on his name he gave the right to become children of God. 

# How could those who believed on his name become children of God?

They could become children of God by being born by God. 

# Is there or was there any other person like the word who came from the Father?

No! The word is the only unique person who came from the Father. 

# What have we received from the fullness of this one John testified about?

From his fullness we have all received free gift after free gift. 

# What came through Jesus Christ?

Grace and truth came through Jesus Christ. 

# Who has seen the God at any time?

No man has seen God at any time. 

# Who has made God known to us?

The one who is in the bosom of the Father has made him known to us. 

# Who did John say he was when asked by the priests and Levites from Jerusalem?

He said, "I am the voice of one crying in the wilderness: 'Make the way of the Lord straight,' just as Isaiah the prophet said." 

# Who did John say he was when asked by the priests and Levites from Jerusalem?

He said, "I am the voice of one crying in the wilderness: 'Make the way of the Lord straight,' just as Isaiah the prophet said." 

# What did John say when he saw Jesus coming to him?

He said, "Look, there is the lamb of God who takes away the sin of the world". 

# Why did John come baptizing with water?

He came baptizing with water so that Jesus, the Lamb of God who takes away the sin of the world, could be revealed to Israel. 

# What was the sign that revealed Jesus as the son of God to John?

The sign was that on whoever John saw the Spirit descending and remaining on, that one is the one who baptizes in the Holy Spirit. 

# What was the sign that revealed Jesus as the son of God to John?

The sign was that on whoever John saw the Spirit descending and remaining on, that one is the one who baptizes in the Holy Spirit. 

# What was the sign that revealed Jesus as the son of God to John?

The sign was that on whoever John saw the Spirit descending and remaining on, that one is the one who baptizes in the Holy Spirit. 

# What did two of John's disciples do when they heard John call Jesus "the lamb of God"?

They followed Jesus. 

# What is the name of one of the two who heard John speak and then followed Jesus?

The name of one of the two is Andrew. 

# What did Andrew tell his brother Simon about Jesus?

Andrew told Simon, "We have found the Messiah". 

# What did Jesus say Simon would be called?

Jesus said Simon would be called "Cephas" (which means 'Peter'). 

# What was the city of Andrew and Peter?

The city of Andrew and Peter was Bethsaida. 

# What did Nathaniel say about Jesus?

Nathaniel said, "Rabbi, you are the son of God! You are the King of Israel". 

# What did Jesus say Nathaniel would see?

Jesus told Nathaniel he would see the heavens opened, and all the angels of God ascending and descending upon the Son of Man. 

# Who was at the wedding in Cana of Galilee?

Jesus, his mother, and his disciples were at the wedding in Cana of Galilee. 

# Why did the mother of Jesus tell Jesus, "They have no wine"?

She told this to Jesus because she expected the he would do something about the situation. 

# What two things did Jesus tell the servants to do?

He first told them to fill the water pots with water. Then he told the servants to take some of the "water" to the head waiter. 

# What two things did Jesus tell the servants to do?

He first told them to fill the water pots with water. Then he told the servants to take some of the "water" to the head waiter. 

# What did the head waiter say after he tasted the water that had become wine?

The head waiter said, "Every man places first the good wine and then the cheaper wine when men are drunk. But you have kept the fine wine until now." 

# What was the response of Jesus' disciples on seeing this miraculous sign?

Jesus' disciples believed in Jesus. 

# What did Jesus find when he went to the temple in Jerusalem?

He found money changers and those that sold oxen, sheep and pigeons. 

# What did Jesus do to the sellers and money changers?

He made a whip of cords and drove all of them out from the temple, including both the sheep and the oxen. He also poured out the money changers' money and overthrew their tables. 

# What did Jesus say to the pigeon sellers?

He said, "Take these things away from here. Stop making my father's house a marketplace." 

# How did the Jewish authorities respond to Jesus' actions in the temple?

They asked Jesus, "What sign will you show us because you are doing these things?" 

# How did Jesus answer the Jewish authorities?

He answered them by saying, "Destroy this temple, and in three days I will raise it up." 

# What temple was Jesus refering to?

Jesus was speaking of the temple of his body. 

# Why did many believe in Jesus' name?

They believed because they saw all the miraculous signs he did. 

# Why wouldn't Jesus trust himself to the people?

He wouldn't trust himself to the people because he knew all people, what was in mankind, and because he didn't need anyone to testify concerning mankind. 

# Why wouldn't Jesus trust himself to the people?

He wouldn't trust himself to the people because he knew all people, what was in mankind, and because he didn't need anyone to testify concerning mankind. 

# Who was Nicodemus?

Nicodemus was a Pharisee, a member of the Jewish Council. 

# What did Nicodemus testify to Jesus?

Nicodemus told Jesus, "Rabbi, we know that you are a teacher come from God for no one can do these signs that you do unless God is with him." 

# What did Jesus tell Nicodemus that confused and perplexed Nicodemus?

Jesus told Nicodemus that one had to be born again in order to enter the kingdom of God. 

# What did Jesus tell Nicodemus that confused and perplexed Nicodemus?

Jesus told Nicodemus that one had to be born again in order to enter the kingdom of God. 

# What questions did Nicodemus ask that let us know that Jesus' statements confused and perplexed Nicodemus?

Nicodemus said, "How can a man be born when he is old? He cannot enter a second time into his mother's womb and be born, can he?" 

# How did Jesus rebuke Nicodemus?

He rebuked Nicodemus by saying, "Are you a teacher of Israel, and yet you do not understand these things?" 

# Who has ascended into heaven?

No one has ascended into heaven except he who descended from heaven, the Son of Man. 

# Why must the Son of Man be lifted up?

He must be lifted up so that all who believe in him may have everlasting life. 

# Why must the Son of Man be lifted up?

He must be lifted up so that all who believe in him may have everlasting life. 

# How did God show he loved the world?

He showed his love by giving his only unique son, that whoever believes in him should not perish but have everlasting life. 

# Did God send his son to condemn the world?

No. God sent his son so that the world should be saved through his son. 

# Why do men fall under judgment?

Men fall under judgment because light has come into the world, and men loved the darkness rather than the light because their works were evil. 

# Why won't those who do evil come into the light?

Those who do evil hate the light and won't come into it because they don't want their deeds exposed. 

# Why do those who practice the truth come into the light?

They come into the light so that their deeds may be clearly seen and to make known that their deeds have been brought about in obedience to God. 

# What did John say would happen to Jesus' ministry compared to John's ministry?

John said, "He must increase, but I must decrease". 

# What did those who accepted the testimony of the one from above, from heaven, confirm?

They confirmed that God is true. 

# What has the Father given into the hand of the Son?

He has given all things into the Son's hand. 

# What do those who believe in the Son have?

They have everlasting light. 

# What happens to those who disobey the Son?

They will not see life, but the wrath of God abides on them. 

# When did Jesus leave Judea and depart for Galilee?

Jesus left Judea and departed for Galilee after he knew the Pharisees had heard that he was making and baptizing more disciples than John . 

# When did Jesus leave Judea and depart for Galilee?

Jesus left Judea and departed for Galilee after he knew the Pharisees had heard that he was making and baptizing more disciples than John . 

# When did Jesus leave Judea and depart for Galilee?

Jesus left Judea and departed for Galilee after he knew the Pharisees had heard that he was making and baptizing more disciples than John . 

# Where did Jesus come to on his way to Galilee?

He came to a Samaritan town called Sychar. 

# Who came to Jacob's well while Jesus was there?

A Samaritan woman came there to draw water. 

# What did Jesus first say to the Samaritan Woman?

He said to her, "Give me some water to drink." 

# Where were Jesus' disciples?

They had gone away into town to buy food. 

# Why was the Samaritan woman suprised that Jesus would talk to her?

She was surprised because Jews had no dealings with the Samaritans. 

# What does Jesus say to turn the conversation to the things of God?

Jesus tells her that if she had known the gift of God and who was talking to her, she would have asked and he would have given her living water. 

# What statement does the woman make to indicate she doesn't understand the spiritual nature of Jesus' comments?

The woman replied, "Sir, you do not have a bucket, and the well is deep. Where would you get that living water?" 

# What does Jesus tell the woman about the water that he will give?

Jesus tells the woman those who drink the water he gives will never thirst again and that water will become a fountain of water springing up into eternal life. 

# Why does the woman now want this water that Jesus offers?

She wants the water so she won't get thirsty and not have to come to the well to draw water. 

# Jesus then changes the subject of conversation. What does he tell the woman?

Jesus tells her, "Go, call your husband, and come back here." 

# How does the woman answer Jesus when he tells her to call her husband?

The woman tells Jesus she has no husband. 

# What does Jesus say about the woman which he could not know by natural means?

He tells her she has had five husbands and the man she now has is not her husband. 

# What controvery does the woman bring up to Jesus concerning worship?

She bring up a controversy about where is the proper place to worship. 

# What does Jesus tell the woman about the kind of worshipers the Father seeks?

Jesus tells her God is a Spirit and true worshipers must worship God in spirit and in truth. 

# What does Jesus tell the woman about the kind of worshipers the Father seeks?

Jesus tells her God is a Spirit and true worshipers must worship God in spirit and in truth. 

# What does Jesus say to the woman when she tells Jesus that when Messiah (Christ) comes, he will declare everything to them?

Jesus tells her that he is the Messiah (Christ). 

# What does Jesus say to the woman when she tells Jesus that when Messiah (Christ) comes, he will declare everything to them?

Jesus tells her that he is the Messiah (Christ). 

# What did the woman do after her conversation with Jesus?

The woman left her water pot, went back to town, and said to the people, "Come see a man who told me all things that I ever did. This could not be the Christ, could it?' 

# What did the woman do after her conversation with Jesus?

The woman left her water pot, went back to town, and said to the people, "Come see a man who told me all things that I ever did. This could not be the Christ, could it?' 

# What did the town's people do after they heard the woman's report?

They left the town and came to Jesus. 

# What does Jesus say his food is?

Jesus said his food was to do the will of the one who sent him and to complete his work. 

# What is the benefit of harvesting?

The harvesters receive wages and gathers fruit for everlasting life, so that he who sows and he who harvests may rejoice together. 

# Why did many Samaritans in that city to believe in Jesus?

The woman's report caused many Samaritans in that city to believe in Jesus. 

# What did many of those Samaritans believe about Jesus?

They said that they now knew that Jesus was indeed the savior of the world. 

# When Jesus came into Galilee why did the Galileans welcome him?

They welcomed him because they had seen all the things that he had done in Jerusalem at the festival. 

# After Jesus left Judea and returned to Galilee, who came to Jesus and what did he want?

A certain royal official whose son was sick came to Jesus, imploring him to come down and heal his son. 

# After Jesus left Judea and returned to Galilee, who came to Jesus and what did he want?

A certain royal official whose son was sick came to Jesus, imploring him to come down and heal his son. 

# What did Jesus tell the royal official about signs and wonders?

Jesus told him people would not believe unless they saw signs and wonders 

# What did the royal official do when Jesus didn't go with him but told him, "Go; your son lives."?

The man believed the word that Jesus spoke to him, and he went his way. 

# What was the result after the father of the sick child was told that his son was living and that the fever had left him the day before at the seventh hour, at the same hour Jesus had told him, "Your son lives."?

The result was the royal official and his whole household believed. 

# What was the name of the pool in Jerusalem by the sheep gate that had five roofed porticos?

That pool was called Bethesda. 

# Who was at Bethesda?

A great number of people who were sick, blind, lame, or paralyzed were lying in the porticos of Bethesda 

# Who was at Bethesda?

A great number of people who were sick, blind, lame, or paralyzed were lying in the porticos of Bethesda 

# At Bethesda who did Jesus ask, "Do you want to be well?"

Jesus asked a certain man who had been an invalid for thirty-eight years and who had been lying there a long time 

# At Bethesda who did Jesus ask, "Do you want to be well?"

Jesus asked a certain man who had been an invalid for thirty-eight years and who had been lying there a long time 

# What was the sick man's response to Jesus' question, "Do you want to be well?"

The sick man replied, "Sir, I do not have anyone, when the water is stirred up, to put me into the pool. When I am trying, another steps down before me." 

# What happened when Jesus said to the sick man, "Get up, take up your mat, and walk."?

Immediately the man was healed, took up his bed, and walked 

# Why did it upset the Jewish leaders when they saw the sick man walking with his bed (mat)?

It upset them because it was a Sabbath and they said the man was not permitted to carry his mat on the Sabbath. 

# What did Jesus say to the sick man he had healed after Jesus found him in the temple?

Jesus told him, " See, you have become well! Do not sin any more, lest something worse happens to you." 

# What did the healed man do after Jesus told him to stop sinning?

The man went and told the Jewish leaders that it was Jeus who had made him well. 

# How did Jesus respond to the Jewish leaders who persecuted him because he was doing these things (healing) on the Sabbath?

Jesus told them, "My Father is working even now, and I, too, work." 

# Why did Jesus' statement to the Jewish leaders make them want to kill Jesus?

This happened because Jesus not only broke the Sabbath (in their minds), but also called God his own Father, making himself equal with God. 

# What did Jesus do?

He did what he saw the Father doing. 

# What would the Father do so that the Jewish leaders would be amazed?

The Father would show the Son greater things than these so the Jewish leaders would be amazed. 

# Why did the Father give all judgment to the Son?

The Father gave all judgment to the Son so that all may honor the Son even as they honor the Father. 

# Why did the Father give all judgment to the Son?

The Father gave all judgment to the Son so that all may honor the Son even as they honor the Father. 

# What happens if you don't honor the Son?

If you don't honor the Son you don't honor the Father who sent him. 

# What happens if you believe Jesus' word and believe in the Father who sent him?

If so, you have eternal life and will not be condemned but have passed out of death into life. 

# What has the Father given the Son concerning life?

The Father has given to the Son to have life in himself. 

# What will happen when all who are in the tombs hear the Father's voice?

They will come forth. Those who have done good to the resurrection of life, and those who have done evil to the resurrection of judgment. 

# What will happen when all who are in the tombs hear the Father's voice?

They will come forth. Those who have done good to the resurrection of life, and those who have done evil to the resurrection of judgment. 

# Why is Jesus' judgment righteous?

His judgment is righteous because he is not seeking his own will but the will of the Father who sent him. 

# What testimony greater than John did Jesus have to prove he was sent from the Father?

The works that Jesus did testified that he was sent from the Father. 

# Who had not heard the Father's voice nor seen his form at any time?

The Jewish leaders had neither heard his voice nor seen his form at any time. 

# Why did the Jewish leaders search the scriptures?

They searched them because they thought that in them they had eternal life. 

# Who do the scriptures testify about?

The scriptures testify concerning Jesus. 

# Who were the Jewish leaders not seeking praise from?

They were not seeking the praise that comes from the only God. 

# Who was going to accuse the Jewish leaders before the Father?

Moses was going to accuse the Jewish leaders before the Father. 

# What does Jesus say the Jewish leaders would do if they believed Moses?

He says the Jewish leaders would believe in Jesus if they believed Moses because Moses wrote concerning Jesus. 

# What does Jesus say the Jewish leaders would do if they believed Moses?

He says the Jewish leaders would believe in Jesus if they believed Moses because Moses wrote concerning Jesus. 

# What was another name for the Sea of Galilee?

The Sea of Galilee was also called the Sea of Tiberias. 

# Why was a great crowd following Jesus?

They followed him because they were seeing the signs that Jesus was doing on those who were sick. 

# What did Jesus see after he sat down on the mountainside with his disciples and looked up?

He saw a great crowd coming to him. 

# What did Jesus see after he sat down on the mountainside with his disciples and looked up?

He saw a great crowd coming to him. 

# Why did Jesus ask Philip, "Where are we going to buy bread so that these may eat?"

Jesus said this to test Philip. 

# Why did Jesus ask Philip, "Where are we going to buy bread so that these may eat?"

Jesus said this to test Philip. 

# What was Philip's response to Jesus' question, "Where are we going to buy bread so that these may eat?"

Philip said, "Two hundred denarii worth of bread would not be sufficient for each one to have even a little." 

# What was Andrew's response to Jesus' question, "Where are we going to buy bread so that these may eat?"

Andrew said, "There is a boy here who has five barley loaves and two fish, but what are these among so many?" 

# What was Andrew's response to Jesus' question, "Where are we going to buy bread so that these may eat?"

Andrew said, "There is a boy here who has five barley loaves and two fish, but what are these among so many?" 

# About how many men were there in that place?

There were about five thousand men there. 

# What did Jesus do with the loaves and the fish?

Jesus took the loaves and after giving thanks, he distributed to those who were sitting. He distributed the fish in the same way. 

# How much did the people get to eat?

They got as much as they wanted to eat. 

# How much bread was picked up after the meal?

The disciples filled twelve baskets with broken pieces from the five barley loaves—the pieces left over from those who had eaten. 

# Why did Jesus withdraw again up the mountain by himself?

Jesus withdrew because he realized the people, after seeing the sign he did (feeding of the five thousand), were about to come and seize him by force and make him king. 

# Why did Jesus withdraw again up the mountain by himself?

Jesus withdrew because he realized the people, after seeing the sign he did (feeding of the five thousand), were about to come and seize him by force and make him king. 

# What happened to the weather after the disciples got into a boat and started out for Capernaum?

A strong wind began to blow and the sea started getting rough. 

# Why did the disciples begin to be afraid?

They were afraid because they saw Jesus walking on the sea and coming near the boat. 

# What did Jesus say to the disciples that made them willing to receive him into the boat?

Jesus said to them, "It is I! Do not be afraid." 

# What did Jesus say was the reason the crowd was seeking him?

Jesus said they were seeking him not because they saw signs, but because they ate some of the loaves and were filled. 

# What did Jesus tell the crowd they should and should not work for?

Jesus told them to stop working for the food that perishes, but work for the food that endures to everlasting life. 

# How did Jesus define the work of God for the crowd?

Jesus told the crowd, "This is the work of God: that you believe in the one whom he has sent. 

# What does Jesus say is the bread of life?

Jesus says that he is the bread of life. 

# Who will come to Jesus?

All whom the Father gives to Jesus will come to him. 

# What is the will of the Father who sent Jesus?

The Father's will is that Jesus should lose none that the Father has given him and that everyone who sees the son and believes in him should have eternal life; and Jesus will raise him up on the last day. 

# What is the will of the Father who sent Jesus?

The Father's will is that Jesus should lose none that the Father has given him and that everyone who sees the son and believes in him should have eternal life; and Jesus will raise him up on the last day. 

# How can a man come to Jesus?

A man can only come to Jesus if his Father draws him. 

# Who has seen the Father?

Only he who is from God has seen the Father. 

# What is the bread that Jesus will give for the life of the world?

The bread that Jesus will give is his flesh for the life of the world. 

# What do you have to do to have life within yourself?

In order to have life within yourself you must eat the flesh of the Son of Man and drink his blood. 

# How can we remain in Jesus and Jesus remain in us?

If we eat his flesh and drink his blood we will remain in Jesus and him in us. 

# Why does Jesus live?

Jesus lives because of the Father. 

# How did many of Jesus' disciples respond after hearing Jesus teaching about eating his flesh and drinking his blood?

When the disciples heard this teaching many of them said, "This is a difficult teaching; who can accept it?" After this many of his disciples went back and walked no more with him. 

# What did Jesus know about people from the beginning?

Jesus knew from the beginning who the ones were who would not believe and who it was who would betray him. 

# When Jesus asked the twelve, "You do not want to go away also, do you?", who answered and what did he say?

Simon Peter answered him and said, "Lord, to whom shall we go? You have the words of everlasting life, and we have believed and come to know that you are the Holy One of God." 

# When Jesus asked the twelve, "You do not want to go away also, do you?", who answered and what did he say?

Simon Peter answered him and said, "Lord, to whom shall we go? You have the words of everlasting life, and we have believed and come to know that you are the Holy One of God." 

# When Jesus asked the twelve, "You do not want to go away also, do you?", who answered and what did he say?

Simon Peter answered him and said, "Lord, to whom shall we go? You have the words of everlasting life, and we have believed and come to know that you are the Holy One of God." 

# Who did Jesus mean when he said one of the twelve was a devil?

Jesus spoke of Judas, the son of Simon Iscariot, for it was he, being one of the twelve, who would betray Jesus. 

# Who did Jesus mean when he said one of the twelve was a devil?

Jesus spoke of Judas, the son of Simon Iscariot, for it was he, being one of the twelve, who would betray Jesus. 

# Why was Jesus not willing to go into Judea?

He wasn't willing to go there because the Jews wanted to kill him. 

# Why did the brothers of Jesus urge him to go to Judea to the Festival of Shelters?

They urged him to go so that Jesus' disciples could see the deeds he was doing and so that the world would know. 

# Why did the brothers of Jesus urge him to go to Judea to the Festival of Shelters?

They urged him to go so that Jesus' disciples could see the deeds he was doing and so that the world would know. 

# What reason did Jesus give for not going to the festival?

Jesus told his brothers his time had not yet come, and his time had not yet been fulfilled. 

# Why does the world hate Jesus?

Jesus said the world hated him because he testifies about the world that its deeds are evil. 

# When and how did Jesus go up to the festival?

Jesus went up after his brothers had gone up to the festival but he went in private not publicly. 

# What did the people in the crowd say about Jesus?

Some said, "He is a good man." Others said, "No, he leads the crowds astray." 

# Why did no one speak openly about Jesus?

It was for fear of the Jews that no one spoke openly about Jesus. 

# When did Jesus go up into the temple and begin teaching?

When the festival was half over, Jesus went up into the temple and began teaching 

# How did Jesus say one could know whether his teaching came from God, or whether Jesus was speaking from himself?

Jesus said if anyone wished to do the will on the person who sent Jesus, he would know about this teaching, whether it came from God or not. 

# What did Jesus say about the one who seeks the glory of the one who sent him?

Jesus said that person is true, and there is no unrighteousness in him. 

# According to Jesus, who does the law?

Jesus said none of you does the law. 

# What is Jesus' argument for healing on the Sabbath?

Jesus' argument was: You will circumcise a man on the Sabbath so that the law of Moses is not broken. Then why are you angry with me because I made a man completely well on the Sabbath. 

# How did Jesus tell the people to judge?

Jesus told them not to judge according to appearance, but to judge righteously. 

# What was one of the arguments the people made for not believing Jesus was the Christ?

The people said they knew where Jesus came from, but when Christ comes they said no one will know where he comes from. 

# Who sent officers to arrest Jesus?

The chief priests and the Pharisees sent officers to arrest Jesus. 

# Did the Jews understand what Jesus meant when he said, "Yet a little while am I still with you, and then I go to him who sent me. You will seek me but will not find me; where I go, you will not be able to come."?

By their conversation among themselves they indicated that they did not understand Jesus' statement. 

# Did the Jews understand what Jesus meant when he said, "Yet a little while am I still with you, and then I go to him who sent me. You will seek me but will not find me; where I go, you will not be able to come."?

By their conversation among themselves they indicated that they did not understand Jesus' statement. 

# What was Jesus refering to when he said, "If anyone is thirsty, let him come to me and drink. He who believes in me, as the scripture has said, from within him will flow rivers of living water."

Jesus said this about the Spirit, whom those who believed in him would receive. 

# How did the officers answer the chief priests and Pharisees who said to them, "Why did you not bring him (Jesus)?"

The officers answered, "No man has ever spoken like this before." 

# How did Nicodemus answer the Pharisees when the Pharisees asked the officers sent to arrest Jesus, "Have you also been led astray? Have any of the rulers believed in him, or any of the Pharisees?"

Nicodemus said to the Pharisees, "Does our law judge a man unless it first hears from him and knows what he does?"

# How did Nicodemus answer the Pharisees when the Pharisees asked the officers sent to arrest Jesus, "Have you also been led astray? Have any of the rulers believed in him, or any of the Pharisees?"

Nicodemus said to the Pharisees, "Does our law judge a man unless it first hears from him and knows what he does?"

# While Jesus was teaching the people in the temple what did the scribes and Pharisees do?

They brought in a woman caught in the act of adultery and placed her in their midst and asked Jesus what he had to say about her (to judge her). 

# While Jesus was teaching the people in the temple what did the scribes and Pharisees do?

They brought in a woman caught in the act of adultery and placed her in their midst and asked Jesus what he had to say about her (to judge her). 

# Why did the scribes and Pharisees really bring this woman to Jesus?

They really brought this woman to Jesus in order to trap Jesus so that they might have something to accuse him about." 

# What did Jesus say to the scribes and Pharisees after they kept asking Jesus about the woman caught in adultery?

Jesus said to them, "He who is without sin among you, let him be the first to throw a stone at her." 

# What did the people do after Jesus spoke to them about who should be the first to throw a stone at the woman caught in adultery?

After Jesus spoke they went out one by one, beginning from the eldest and ending with the last. 

# What did Jesus tell the woman (caught in adultery) to do?

Jesus told her to go her way and from then on to sin no more. 

# What was the Pharisees complaint after Jesus said, "I am the light of the world; he who follows me will not walk in the darkness but will have the light of life."

The Pharisees complained that Jesus was bearing witness about himself and that his witness was not true. 

# How did Jesus defend his witness as being true?

Jesus said that in their law it is written that the testimony of two men is true. He then states that he and the Father who sent him both bear witness about Jesus 

# How did Jesus defend his witness as being true?

Jesus said that in their law it is written that the testimony of two men is true. He then states that he and the Father who sent him both bear witness about Jesus 

# On what did Jesus base his statement about the Pharisees that they would die in their sins?

Jesus based that statement on his knowledge of them, that they were from below, he was from above. They were of this world and he was not of this world. 

# On what did Jesus base his statement about the Pharisees that they would die in their sins?

Jesus based that statement on his knowledge of them, that they were from below, he was from above. They were of this world and he was not of this world. 

# How could the Pharisee escape dying in their sins?

Jesus said they would die in their sins unless they believed that I am. 

# What things did Jesus say to the world?

Jesus said to the world the things he heard from the Father. 

# What things did Jesus say to the world?

Jesus said to the world the things he heard from the Father. 

# Why did the Father who sent Jesus stay with him and not leave him alone?

The Father was with Jesus and didn't leave him alone because Jesus always did the things that were pleasing to the Father. 

# How did Jesus say the Jews who had believed in him could know they were truly his disciples?

They could know they were truly Jesus' disciples by remaining in his word. 

# What did the Jews that believed Jesus think Jesus was refering to when he said, "...and you will know the truth and the truth will set you free."?

Those Jews thought Jesus was speaking of being slave of, or in bondage to, men. 

# What was Jesus refering to when he said, "....and you shall know the truth and the truth will set you free?

Jesus was refering to being set free from being slaves of sin. 

# What is the reason, according to Jesus, the Jews sought to kill Jesus?

They sought to kill Jesus because his word had no place in them. 

# Why did Jesus say these Jews were not Abraham's children?

Jesus said they were not Abraham's children because they did not do the works of Abraham. Instead they sought to kill Jesus. 

# Why did Jesus say these Jews were not Abraham's children?

Jesus said they were not Abraham's children because they did not do the works of Abraham. Instead they sought to kill Jesus. 

# When these Jews say they have one Father, God, how does Jesus refute them?

Jesus said to them, "If God were your Father, you would love me, for I came forth and have come from God; for neither have I come of myself, but he sent me." 

# Who does Jesus say is the father of these Jews?

Jesus says their father is the devil. 

# What did Jesus say about the devil?

Jesus said the devil was a murderer from the beginning and does not stand in the truth because there is no truth in him. When the devil speaks a lie, he speaks from his own nature because he is a liar and the father of lies. 

# Who hears the words of God?

He who is of God hears the words of God. 

# What does Jesus say will happen if anyone keeps Jesus' word?

If anyone keeps Jesus' word, he will never see death. 

# Why did the Jews say Jesus had a demon?

They said this because Jesus said, "Truly, truly, I say to you, if anyone keeps my word, he will never see death. 

# Why did the Jews think Jesus' statement about never seeing death was outlandish?

They thought this because they were thinking of the physical death of the body. Even Abraham and the prophets died (their physical bodies). 

# Why did the Jews think Jesus' statement about never seeing death was outlandish?

They thought this because they were thinking of the physical death of the body. Even Abraham and the prophets died (their physical bodies). 

# What statements does Jesus make to say that he was alive before Abraham?

Jesus said, "Truly, truly, I say to you, before Abraham was born, I AM." 

# What is the assumption made by the disciples as to why the man was born blind?

The disciples are assuming that the reason the man was born blind is because either the man or his parents sinned. 

# What does Jesus say is the reason the man was born blind?

Jesus says the man was born blind so that the works of God should be revealed in him. 

# What did Jesus do and say to the blind man?

Jesus spit on the ground, made some mud and annointed the man's eyes with the mud. Jesus then told the man to go wash in the pool of Siloam. 

# What did Jesus do and say to the blind man?

Jesus spit on the ground, made some mud and annointed the man's eyes with the mud. Jesus then told the man to go wash in the pool of Siloam. 

# What happened after the blind man washed in the pool of Siloam?

He came back seeing. 

# What did the man testify when a dispute arose as to whether or not he was the man born blind who used to sit and beg?

The man testified that he was the blind beggar. 

# What did the people do who were with the formerly blind beggar?

They took the man to the Pharisees.. 

# When did the healing take place?

The healing of the blind man took place on the Sabbath. 

# What did the Pharisees ask the formerly blind man?

They asked him how he had received his sight. 

# What was the division that arose among the Pharisees?

Some Pharisees said Jesus wasn't from God because he didn't keep the Sabbath (he healed on the Sabbath) and some of the Pharisees said how could a man that is a sinner so such signs. 

# What did the formerly blind man say about Jesus when asked?

The formerly blind man said, "He is a prophet." 

# Why did the Jews call in the parents of the blind man that had received his sight?

They called in the man's parents because they still did not believe the man was the one that had been blind. 

# What did the parents of the man testify concerning their son?

The parents testified that the man was indeed their son and that he had been born blind. 

# What did the man's parents say they didn't know?

They said they didn't know how he could now see or who opened his eyes. 

# Why did the man's parents say, "He is an adult. Ask him."

They said this because they were afraid of the Jews. For the Jews had already agreed that if anyone should confess Jesus to be the Christ, he should be put out of the synagogue. 

# What did the Pharisees say to the formerly blind man when they called him in the second time?

They said, "Give glory to God. We know this man (Jesus) is a sinner." 

# What was the formerly blind man's response to the Pharisees when they called Jesus a sinner?

He replied, "Whether he is a sinner, I do not know. One thing I do know: Once I was blind, and now I see. 

# What questions did the formerly blind man ask the Pharisees?

The formerly blind man said, "Why do you want to hear it again? You do not want to become his disciples too, do you?" 

# When the Pharisees reviled the man, what did the formerly blind man say everyone knew?

The formerly blind man said that everyone knew God does not listen to sinners 

# How did the Pharisees respond to the blind man's retort?

They told the man he was born in sin and you dare to teach us. Then they cast the man out of the synagogue. 

# What did Jesus do when he heard the formerly blind man had been cast out of the synagogue?

Jesus went looking for the man and found him. 

# What did Jesus say to the formerly blind man after Jesus found him?

Jesus asked the man if he believed in the Son of Man and then told the formerly blind man that he (Jesus) was the Son of Man. 

# What did Jesus say to the formerly blind man after Jesus found him?

Jesus asked the man if he believed in the Son of Man and then told the formerly blind man that he (Jesus) was the Son of Man. 

# How did the formerly blind man respond to this information that Jesus was the Son of Man?

The formerly blind man told Jesus he believed and he worshiped Jesus. 

# What did Jesus say about the sins of the Pharisees?

Jesus told them, "If you were blind, you would have no sin. However, now you say, 'We see.' So your sin remains." 

# According to Jesus who is a thief and a robber?

He who does not enter by the gate into the sheepfold, but climbs up some other way, that man is a thief and a robber. 

# Who enters the sheepfold by the gate?

He who enters the sheepfold by the gate is the shepherd of the sheep. 

# Why do the sheep follow the shepherd when he calls them?

They follow the shepherd because they know his voice. 

# Why do the sheep follow the shepherd when he calls them?

They follow the shepherd because they know his voice. 

# Will the sheep follow a stranger?

No. The sheep will not follow a stranger. 

# What were all those who came before Jesus?

All those who came before Jesus were thieves and robbers, and the sheep did not listen to them. 

# Jesus said he was the gate. What happens to those who enter through that gate?

Those who enter through Jesus, the gate, will be saved; they will go in and out and will find pasture. 

# What does the good shepherd, Jesus, do for his sheep?

Jesus, the good shepherd, lays down his life for the sheep. 

# Does Jesus have another sheep fold and if so what will happen to them?

Jesus said he had other sheep that were not of that fold. He said he must bring them and they would hear his voice so that there would be one flock and one shepherd. 

# Why does the Father love Jesus?

The Father loves Jesus because Jesus lays down his life that he may take it up again. 

# Does someone take Jesus' life away?

No. He lays if down of himself. 

# Where did Jesus get the authority to lay down his life and to take it again?

Jesus received this command from his Father. 

# What did the Jews say because of Jesus' words?

Many said, "He has a demon and is insane. Why do you listen to him?" Others said, "These are not the statements of one possessed with a demon. Can a demon open the eyes of the blind?" 

# What did the Jews say because of Jesus' words?

Many said, "He has a demon and is insane. Why do you listen to him?" Others said, "These are not the statements of one possessed with a demon. Can a demon open the eyes of the blind?" 

# What did the Jews say because of Jesus' words?

Many said, "He has a demon and is insane. Why do you listen to him?" Others said, "These are not the statements of one possessed with a demon. Can a demon open the eyes of the blind?" 

# What did the Jews say to Jesus when they surrounded him in the Temple in Solomon's porch?

They said, "How long will you hold us in suspense? If you are the Christ, tell us plainly." 

# How did Jesus reply to the Jews in Solomon's porch?

Jesus said he had already told them (that he was the Christ) and they did not believe him because they weren't his sheep. 

# How did Jesus reply to the Jews in Solomon's porch?

Jesus said he had already told them (that he was the Christ) and they did not believe him because they weren't his sheep. 

# What does Jesus say about his care and protection of his sheep?

Jesus said he gives his sheep eternal life, they will never perish, and no one will snatch them out of his hand. 

# Who gave the sheep to Jesus?

The Father gave the sheep to Jesus. 

# Is anyone greater than the Father?

The Father is greater than all others. 

# Why did the Jews take up stones to stone Jesus?

Because they believed Jesus was blaspheming and making himself God even though he was a man. 

# What is Jesus' defense against the charge of blasphemy?

Jesus defends himself by saying, "Is it not written in your law, 'I said, "You are gods'"? If he called them gods, to whom the word of God came (and the scripture cannot be broken), do you say about him whom the Father sanctified and sent into the world, 'You are blaspheming,' because I said, 'I am the Son of God'?. 

# What is Jesus' defense against the charge of blasphemy?

Jesus defends himself by saying, "Is it not written in your law, 'I said, "You are gods'"? If he called them gods, to whom the word of God came (and the scripture cannot be broken), do you say about him whom the Father sanctified and sent into the world, 'You are blaspheming,' because I said, 'I am the Son of God'?. 

# What is Jesus' defense against the charge of blasphemy?

Jesus defends himself by saying, "Is it not written in your law, 'I said, "You are gods'"? If he called them gods, to whom the word of God came (and the scripture cannot be broken), do you say about him whom the Father sanctified and sent into the world, 'You are blaspheming,' because I said, 'I am the Son of God'?. 

# What does Jesus tell the Jews to do in order to determine whether to believe him or not?

Jesus tell the Jews to look at his works. If Jesus isn't doing the works of his Father, don't believe him. If he is doing the works of his Father, believe him. 

# What does Jesus tell the Jews to do in order to determine whether to believe him or not?

Jesus tell the Jews to look at his works. If Jesus isn't doing the works of his Father, don't believe him. If he is doing the works of his Father, believe him. 

# What does Jesus say the Jews could know and understand if they would believe in the works that Jesus did?

Jesus said they could know and understand that the Father is in Jesus and that Jesus is in the Father. 

# What was the response of the Jews to Jesus statement about the Father being in Jesus and Jesus being in the Father?

The Jews tried again to seize Jesus. 

# Where did Jesus go after this event?

Jesus went away again beyond the Jordon to the place where John had been baptizing at first. 

# What did many people who came to Jesus say and do?

They kept saying, "John indeed did no signs, but all the things that John has said about this man are true." Many people believed in Jesus there. 

# What did many people who came to Jesus say and do?

They kept saying, "John indeed did no signs, but all the things that John has said about this man are true." Many people believed in Jesus there. 

# Who was this Lazarus?

Lazarus was a man from Bethany. His sisters were Mary and Martha. It was the same Mary who would anoint the Lord with myrrh and wipe his feet with her hair. 

# Who was this Lazarus?

Lazarus was a man from Bethany. His sisters were Mary and Martha. It was the same Mary who would anoint the Lord with myrrh and wipe his feet with her hair. 

# What did Jesus say about Lazarus and his sickness when Jesus heard he was sick?

Jesus said, "This sickness is not to end in death, but it is instead for the glory of God so that the son of God may be glorified in it." 

# What did Jesus do when he heard Lazarus was sick?

Jesus stayed two more days in the place where he was. 

# What did Jesus' disciples say when he told them, "Let us go to Judea again."?

The disciples said to Jesus, "Rabbi, the Jews were only now trying to stone you, and are you going back there again?" 

# What did Jesus say about walking in the day?

Jesus said if someone walks in the daytime he will not stumble because he sees by the daylight. 

# What did Jesus say about walking in the night?

If someone walks at night, he will stumble because the light is not in him. 

# In what way did the disciples think that Lazarus had fallen asleep?

The disciples thought Lazarus had fallen asleep to rest. 

# In what way did the disciples think that Lazarus had fallen asleep?

The disciples thought Lazarus had fallen asleep to rest. 

# What did Jesus mean when he said Lazarus had fallen asleep?

When Jesus said Lazarus had fallen asleep he was speaking of Lazarus' death. 

# Why was Jesus glad that he wasn't there when Lazarus died?

Jesus said, "I am glad for your sakes, that I was not there so that you may believe. 

# What did Thomas think would happen if they went back to Judea?

Thomas thought they would all die. 

# How long had Lazarus been in the tomb when Jesus came?

Lazarus had been in the tomb four days. 

# What did Martha do when she heard Jesus was coming?

When Martha heard Jesus was coming, she went and met him. 

# What did Martha think God would do for Jesus?

Martha said, "Even now, I know that whatever you ask from God, he will give to you. 

# When Jesus said to Martha, "Your brother will rise again", what was her response to Jesus?

She said to Jesus, " I know that he will rise again in the resurrection at the last day." 

# What did Jesus say would happen to those who believe in him?

Jesus said that whoever believes in Jesus, though he die, yet he will live; and whoever lives and believes in Jesus will never die. 

# What did Jesus say would happen to those who believe in him?

Jesus said that whoever believes in Jesus, though he die, yet he will live; and whoever lives and believes in Jesus will never die. 

# What was Martha's testimony about who Jesus is?

Martha said to Jesus, "Yes, Lord, I believe that you are the Christ, the Son of God, the one who is coming into the world." 

# Where was Mary going?

Mary was going to meet Jesus. 

# When Mary got up quickly and went out, what did the Jews who were with her think and do?

The Jews who were in the house with Mary supposed she was going to the tomb to weep there, so they followed her. 

# What seems to have prompted Jesus to groan in the spirit and be troubled and weep?

Jesus groaned in the spirit was troubled and wept after he saw Mary and the Jews with her weeping. 

# What seems to have prompted Jesus to groan in the spirit and be troubled and weep?

Jesus groaned in the spirit was troubled and wept after he saw Mary and the Jews with her weeping. 

# What seems to have prompted Jesus to groan in the spirit and be troubled and weep?

Jesus groaned in the spirit was troubled and wept after he saw Mary and the Jews with her weeping. 

# What did the Jews conclude when they saw Jesus weeping?

They concluded that Jesus loved Lazarus. 

# What was Martha's objection to Jesus' command to take away the stone from the mouth of the cave where they had laid Lazarus?

Martha said, "Lord, by this time the body will be decaying, for he has been dead four days." 

# What is Jesus' reply to Martha's objection to taking away the stone?

Jesus said to Martha, "Did I not say to you that, if you believed, you would see the glory of God." 

# What did Jesus do immediately after the stone was taken away from the cave?

Jesus lifted up his eyes and prayed aloud to his Father. 

# Why did Jesus pray aloud and say what he said to his Father?

He prayed aloud and said what he did because of the crowd that was standing around him, so that they might believe that the Father had sent him. 

# What happened when Jesus cried out with a loud voice, "Lazarus, come out!"?

The dead man came out, bound hand and foot with burial cloths, and his face was bound about with a cloth. 

# What was the response of the Jews when they saw Lazarus come out of the cave?

Many of the Jews when they saw what Jesus did believed in him, but some went to the Pharisees and told them what Jesus had done. 

# What was the response of the Jews when they saw Lazarus come out of the cave?

Many of the Jews when they saw what Jesus did believed in him, but some went to the Pharisees and told them what Jesus had done. 

# In the coucil meeting of the chief priests and Pharisees what did Caiaphas prophesy?

Caiaphas said it was expedient for them that one man should die for the people rather than that the whole nation should perish. 

# From that day onward what did the council plan?

They planned how to put Jesus to death. 

# What did Jesus do after he raised Lazarus?

Jesus no longer walked openly among the Jews, but he departed from Bethany into the country near to the wilderness into a town called Ephraim. There he stayed with his disciples. 

# What order did the chief priests and Pharisees issue?

They gave an order that if anyone knew where Jesus was, he should report it so that they might seize him. 

# When did Jesus come back to Bethany?

He came to Bethany six days before the Passover. 

# What did Mary do at the supper which had been made for Jesus?

Mary took a litra of perfume made of pure nard, very precious, anointed the feet of Jesus with it, and wiped his feet with her hair. 

# Why did Judas Iscariot, one of Jesus' disciples, complain that the perfume should have been sold and the money given to the poor?

Judas said this, not because he cared for the poor, but because he was a thief: He had charge of the money bag and would take some of what was in it for himself. 

# Why did Judas Iscariot, one of Jesus' disciples, complain that the perfume should have been sold and the money given to the poor?

Judas said this, not because he cared for the poor, but because he was a thief: He had charge of the money bag and would take some of what was in it for himself. 

# Why did Judas Iscariot, one of Jesus' disciples, complain that the perfume should have been sold and the money given to the poor?

Judas said this, not because he cared for the poor, but because he was a thief: He had charge of the money bag and would take some of what was in it for himself. 

# How did Jesus defend Mary's use of the perfume (nard)?

Jesus said, "Allow her to keep what she has for the day of my burial. The poor you will always have with you; but you will not always have me." 

# How did Jesus defend Mary's use of the perfume (nard)?

Jesus said, "Allow her to keep what she has for the day of my burial. The poor you will always have with you; but you will not always have me." 

# Why did a large crowd gather in Bethany?

They came for Jesus' sake and also to see Lazarus, whom Jesus had raised from the dead. 

# Why did the chief priests want to put Lazarus to death?

They wanted to put Lazarus to death because it was on account of him that many of the Jews went away and believed on Jesus. 

# Why did the chief priests want to put Lazarus to death?

They wanted to put Lazarus to death because it was on account of him that many of the Jews went away and believed on Jesus. 

# What did the crowd at the festival do when they heard Jesus was coming?

They took the branches of the palm trees and went out to meet him and cried out, "Hosanna! Blessed is he who comes in the name of the Lord, the king of Israel." 

# What prophecy about Jesus was fulfilled as Jesus entered the city on a donkey?

The prophecy that Zion's King would come, sitting on the young of a donkey was fulfilled. 

# What prophecy about Jesus was fulfilled as Jesus entered the city on a donkey?

The prophecy that Zion's King would come, sitting on the young of a donkey was fulfilled. 

# Why did the crowd at the festival go out to meet Jesus?

They went out to meet Jesus because they had heard from eye witnesses that Jesus had called Lazarus out of the tomb and had raised him from the dead. 

# Why did the crowd at the festival go out to meet Jesus?

They went out to meet Jesus because they had heard from eye witnesses that Jesus had called Lazarus out of the tomb and had raised him from the dead. 

# What did Jesus say initially after Andrew and Philip told Jesus some Greeks wanted to see him?

Jesus answered them and said, "The hour has come for the son of man to be glorified..." 

# What did Jesus say would happen to a grain of wheat if it fell into the earth and died?

Jesus said that if it died it would bear much fruit. 

# What did Jesus say would happen to the one who loves his life and to the one who hates his life in this world?

Jesus said the one who love his life will lose it, but the one who hates his life in this world will keep it for everlasting life. 

# What happen if anyone serves Jesus?

The Father will honor him. 

# What happened when Jesus said, " Father, glorify your name."?

A voice came out of heaven and said, "I have glorified it and will glorify it again." 

# What did Jesus say was the reason for the voice out of heaven?

Jesus said, "The voice has not come for my sake, but for your (the Jews) sakes." 

# What did Jesus say was going to happen now?

Jesus said, "Now is the judgment of this world: Now wiil the prince of this world be driven out. 

# Why did Jesus say, "And I, if I am lifted up from the earth, will draw all people to myself."

Jesus said this to signify by what manner of death he would die. 

# When the crowd asked, "How can you say, 'The son of man must be lifted up'? Who is this son of man?", did Jesus directly answer them?

No he did not answer their questions directly.. 

# What did Jesus say about the light?

Jesus said, "Yet a little longer is the light among you. Walk while you have the light..." He also said, "While you have the light, believe in the light so that you may become sons of light." 

# When the crowd asked, "How can you say, 'The son of man must be lifted up'? Who is this son of man?", did Jesus directly answer them?

No he did not answer their questions directly.. 

# What did Jesus say about the light?

Jesus said, "Yet a little longer is the light among you. Walk while you have the light..." He also said, "While you have the light, believe in the light so that you may become sons of light." 

# Why did the people not believe in Jesus?

They didn't believe so that the word of Isaiah the prophet might be fulfilled, which he said: "Lord, who has believed our report? And to whom has the arm of the Lord been revealed?" 

# Why did the people not believe in Jesus?

They didn't believe so that the word of Isaiah the prophet might be fulfilled, which he said: "Lord, who has believed our report? And to whom has the arm of the Lord been revealed?" 

# Why couldn't the people believe in Jesus?

They couldn't believe because as Isaiah said, "He has blinded their eyes, and he has hardened their hearts; otherwise they would see with their eyes and would perceive with their hearts, and would turn, and I would heal them." 

# Why couldn't the people believe in Jesus?

They couldn't believe because as Isaiah said, "He has blinded their eyes, and he has hardened their hearts; otherwise they would see with their eyes and would perceive with their hearts, and would turn, and I would heal them." 

# Why did Isaiah say these things?

He said these things because he saw Jesus' glory. 

# Why didn't the rulers who did believe in Jesus admit it?

They wouldn't admit it because they were afraid of the Pharisees and so they would not be banned from the synagogue. They loved the praise that comes from people more than the praise that comes from God. 

# Why didn't the rulers who did believe in Jesus admit it?

They wouldn't admit it because they were afraid of the Pharisees and so they would not be banned from the synagogue. They loved the praise that comes from people more than the praise that comes from God. 

# What statement does Jesus make about himself and his Father?

Jesus said, "The one who believes in me, believes not only in me but also in him who sent me, and the one who sees me sees him who sent me." 

# What statement does Jesus make about himself and his Father?

Jesus said, "The one who believes in me, believes not only in me but also in him who sent me, and the one who sees me sees him who sent me." 

# What did Jesus say he had come into the world to do?

Jesus said he came to save the world. 

# What will judge those who reject Jesus and do not receive his words?

The word that Jesus has spoken will judge those who reject him on the last day. 

# Did Jesus speak of his own accord?

No. The Father who sent Jesus commanded him about what he should say and speak. 

# Why did Jesus say to the people just as the Father had said to him?

Jesus did this because he knew his Father's command is life everlasting. 

# How long did Jesus love his own?

He loved them to the end. 

# What had the devil done to Judas Iscariot?

The devil had put it into the heart of Judas Iscariot to betray Jesus. 

# What had the Father given to Jesus?

The Father gave all things over into the hands of Jesus. 

# Where had Jesus come from and where was he going?

Jesus had come from God and was going back to God. 

# What did Jesus do when he rose from supper?

He laid aside his outer clothing, took a towel and wrapped it around himself, poured water into a basin and began to wash the disciples' feet and to wipe them with the towel. 

# What did Jesus do when he rose from supper?

He laid aside his outer clothing, took a towel and wrapped it around himself, poured water into a basin and began to wash the disciples' feet and to wipe them with the towel. 

# What did Jesus say when Peter objected to having his feet washed by Jesus?

Jesus said, "If I do not wash you, you can have no part with me." 

# Why did Jesus say to his disciples, "Not all of you are clean."?

Jesus said this for he knew who would betray him. 

# Why did Jesus wash the disciples feet?

Jesus washed the disciples feet to give the disciples an example so that they should do as he did for them. 

# Why did Jesus wash the disciples feet?

Jesus washed the disciples feet to give the disciples an example so that they should do as he did for them. 

# Is the servant greater than his master or the one sent greater than the one who sent him?

The servant is not greater than his master and the one sent is not greater than the one who sent him. 

# Who lifted up his heel against Jesus?

The one who ate Jesus' bread lifted up his heel against him. 

# Why did Jesus tell his disciples, "Not all of you are clean" and "He who eats my bread lifted up his heel against me."?

Jesus told them this before it happened so that when it did happen they might believe he is the I AM. 

# Who will you receive if you receive Jesus?

If you receive Jesus you will receive whomever he sends and you also receive the one who sent Jesus. 

# When Jesus told his disciples that one of them would betray him, what did Simon Peter do?

Simon Peter motioned to the disciple whom Jesus loved and said, "Tell us who it is of whom he is speaking." 

# How did Jesus respond when the disciple whom Jesus loved asked Jesus who was going to betray Jesus?

Jesus answered, "He it is for whom I will dip the piece of bread and give it to him." Then Jesus dipped the bread and gave it to Judas, the son of Simon Iscariot. 

# What happened to Judas and what did he do after Jesus gave Judas the bread?

After Judas took the bread, Satan entered into him and he went out immediately. 

# What happened to Judas and what did he do after Jesus gave Judas the bread?

After Judas took the bread, Satan entered into him and he went out immediately. 

# How was God going to be glorified?

God was going to be glorified in the Son of man. When the Son of man was glorified that glorified God. 

# Did Simon Peter understand where Jesus was going when Jesus told them, "Where I am going, you cannot come."?

No, Simon Peter did not understand because he asked Jesus, "Lord, where are you going?" 

# What new commandment did Jesus give his disciples?

The new commandment was that they should love one another as Jesus had loved them. 

# What did Jesus say would happen if his disciples obeyed the commandment to love one another?

Jesus said that by them obeying this commandment, all people would know that they were his disciples. 

# Did Simon Peter understand where Jesus was going when Jesus told them, "Where I am going, you cannot come."?

No, Simon Peter did not understand because he asked Jesus, "Lord, where are you going?" 

# How did Jesus answer when Simon Peter said, "I will lay down my life for you."?

Jesus answered, "Will you lay down your life for me? Truly, truly, I say to you, the rooster will not crow before you have denied me three times." 

# Why should the hearts of the disciples not be troubled?

Their hearts should not be troubled because Jesus is going to prepare a place for them and Jesus will come again to receive them to himself so that where Jesus is they may be also. 

# What is in the Father's house?

There are many dwelling places in the Father's house. 

# Why should the hearts of the disciples not be troubled?

Their hearts should not be troubled because Jesus is going to prepare a place for them and Jesus will come again to receive them to himself so that where Jesus is they may be also. 

# What was Jesus going to do for the disciples?

Jesus was going to prepare a place for them. 

# Why should the hearts of the disciples not be troubled?

Their hearts should not be troubled because Jesus is going to prepare a place for them and Jesus will come again to receive them to himself so that where Jesus is they may be also. 

# What is the only way to come to the Father?

The only way to come to the Father is through Jesus. 

# What does Philip tell Jesus to do that would be enough for the disciples?

Philip says to Jesus, "Lord show us the Father, and that will be enough for us." 

# Is Jesus speaking to the disciples of his own accord?

Jesus is not speaking of his own accord, instead, it is the Father living in him who is doing the Father's work. 

# If for no other reason, why does Jesus say the disciples should believe that Jesus is in the Father and the Father is in Jesus?

Jesus says they should believe this if for no other reason then because of Jesus' very works. 

# Why does Jesus say the disciples will be able to do even greater works than he did?

Jesus says the disciples will do even greater works because Jesus is going to the Father. 

# Why will Jesus do whatever the disciples ask in his name?

Jesus will do it so that the Father may be glorified in the Son. 

# What does Jesus say you will do if you love him?

Jesus says you will keep his commandments if you love him. 

# What does Jesus call the other comforter that the Father will give to be with the disciples forever?

Jesus calls him the Spirit of Truth. 

# Why can the world not receive the Spirit of Truth?

The world can't receive the Spirit of Truth because it does not see him or know him. 

# Where does Jesus say the Spirit of Truth will be?

Jesus said the Spirit of Truth would be in the disciples. 

# What will happen to whoever has Jesus' commandments and keeps them?

Those people will be loved by Jesus and his Father and Jesus will show himself to those people. 

# What will the Comforter, the Holy Spirit, do when the Father sends him?

The Comforter, The Holy Spirit will teach the disciples all things and bring to their remembrance all the Jesus said to them. 

# Why should the disciples have rejoiced that Jesus was going away?

Jesus said they should rejoice because Jesus was going to the Father and that the Father is greater than Jesus. 

# What reason does Jesus give for saying he will not speak much more with the disciples?

The reason Jesus gives is that the prince of this world is coming. 

# Who is the true vine?

Jesus is the true vine. 

# Who is the vine grower?

The Father is the vine grower. 

# What does the Father do with the branches who are in Christ?

The Father takes away the branches that bear no fruit and he cleans every branch that bears fruit so that it may bear more fruit. 

# Why are the disciples clean?

They are clean because of the message Jesus spoke to them. 

# Who are the branches?

We are the branches. 

# What must we do to bear fruit?

In order to bear fruit you must remain in Jesus. 

# What happens if you don't remain in Jesus?

If anyone does not remain in Jesus, he is thrown away like a branch and dries up. 

# What must we do so that what ever we ask will be done for us?

We must remain in Jesus and his word must remain in us. Then we may ask whatever we wish and it will be done for us. 

# What are two ways the Father is glorified?

The Father is glorified when we bear much fruit and when we are disciples of Jesus. 

# What must we do to remain in the love of Jesus?

We must keep his commandments. 

# What is the greatest love a person can have?

No one has greater love than this, that he should lay down his life for his friends. 

# How do we know if we are Jesus' friends or not?

We are friends of Jesus if we do the things he commanded us. 

# Why did Jesus call the disciples his friends?

He called them friends, for he made known to them all the things that he heard from his Father. 

# Why does the world hate those who follow Jesus?

The world hates those who follow Jesus because they are not of this world and because Jesus chose them out of the world. 

# What did Jesus do so that the world has no excuse for their sin?

The world has no excuse for their sin because Jesus came and did among them the works that no one else did. 

# Who will bear witness about Jesus?

The Comforter, that is the Spirit of Truth, and Jesus' disciples would bear witness about Jesus. 

# Who will bear witness about Jesus?

The Comforter, that is the Spirit of Truth, and Jesus' disciples would bear witness about Jesus. 

# Why would the disciples bear witness about Jesus?

They would bear witness about Jesus because they had been with him from the beginning. 

# Why did Jesus speak these things to the disciples?

Jesus spoke these things to them so that they should not be made to stumble. 

# Why will people put the disciples of Jesus out of the synagogues and kill some of them?

They will do this because they have not known the Father or Jesus. 

# Why did Jesus not tell the disciples about these things in the beginning?

Jesus didn't tell them in the beginning because he was with them. 

# Why is it better for Jesus to go away?

It is better for Jesus to go away because the Comforter will not come to them unless Jesus goes away; but if Jesus goes away, Jesus will send the Comforter to them. 

# Regarding what will the Comforter convict the world?

The Comforter will convict the world regarding sin, righteousness and judgment. 

# What will the Spirit of Truth do for the disciples when he comes?

He will guide the disciples into all truth; for he will not speak from himself; but whatever things he hears, he will say those things and will declare to them the things that are to come. 

# How will the Spirit of Truth glorify Jesus?

He will glorify Jesus by taking things of Jesus and declaring them to the disciples. 

# What things of Jesus will the Spirit of Truth take?

The Spirit of truth will take things of the Father. All things that the Father has also belong to Jesus. 

# What sayings of Jesus didn't the disciples understand?

They didn't understand when Jesus said, "In a little while, you will see me no more; after a little while again, you will see me." and when he said, "Because I go to the Father". 

# What sayings of Jesus didn't the disciples understand?

They didn't understand when Jesus said, "In a little while, you will see me no more; after a little while again, you will see me." and when he said, "Because I go to the Father". 

# What will happen to the disciples sorrow?

It will be turned to joy. 

# What will happen to cause the disciples to rejoice?

They will see Jesus again and their hearts will rejoice. 

# Why does Jesus tell the disciples to ask and receive?

Jesus says to do this so that their joy may be full. 

# For what reason does the Father himself love the disciples of Jesus?

The Father loves the disciples because the disciples loved Jesus and believed that he came from the Father. 

# Where did Jesus come from and where was he going?

Jesus came from the Father into the world and was going to leave the world and return to the Father. 

# What did Jesus say the disciples would do at that hour?

Jesus said the disciples would be scattered, everyone to his own possessions, and they would leave Jesus alone. 

# Who was still going to be with Jesus after the disciples left him alone?

The Father was still going to be with Jesus. 

# Why did Jesus tell the disciples to be encouraged even though in the world they would have troubles?

Jesus told them to be encouraged because he had overcome the world. 

# Why did the Father give Jesus authority over all flesh?

The Father did this so that he should give everlasting life to all whom you have given him. 

# What is everlasting life?

Everlasting life is knowing the Father, the only true God, and him whom you have sent, Jesus Christ. 

# How did Jesus glorifiy God on the earth?

He did this by accomplishing the work that the Father gave him to do. 

# What glory does Jesus want?

He wants the glory he had with the Father before the world was created. 

# To whom did Jesus reveal the Father's name?

Jesus revealed the Father's name to the people the Father gave to Jesus out of the world. 

# How did those people the Father gave to Jesus respond to Jesus' words?

They received Jesus' words and truly knew that Jesus came from the Father and they believed that the Father sent Jesus. 

# Who does Jesus say he is not praying for?

Jesus says he is not praying for the world. 

# In brief what does Jesus ask the Father to do for those the Father has given to Jesus?

Jesus asks the Father to keep them in the Father's name so they may be one, to keep them from the evil one, to consecrate them in the truth, for them to be in both Jesus and the Father and to have those the Father has given him to be with him where he is. 

# While Jesus was in the world, what did Jesus do for those the Father had given to him?

Jesus guarded them. 

# In brief what does Jesus ask the Father to do for those the Father has given to Jesus?

Jesus asks the Father to keep them in the Father's name so they may be one, to keep them from the evil one, to consecrate them in the truth, for them to be in both Jesus and the Father and to have those the Father has given him to be with him where he is. 

# Why did Jesus consecrate himself?

Jesus consecrated himself so that those the Father gave him might also be consecrated in truth. 

# For whom else does Jesus pray?

Jesus prays for those who will believe in him through the word of those who followed him at that time. 

# In brief what does Jesus ask the Father to do for those the Father has given to Jesus?

Jesus asks the Father to keep them in the Father's name so they may be one, to keep them from the evil one, to consecrate them in the truth, for them to be in both Jesus and the Father and to have those the Father has given him to be with him where he is. 

# How does the Father love those he gave to Jesus?

The Father loves them even as he loved Jesus. 

# In brief what does Jesus ask the Father to do for those the Father has given to Jesus?

Jesus asks the Father to keep them in the Father's name so they may be one, to keep them from the evil one, to consecrate them in the truth, for them to be in both Jesus and the Father and to have those the Father has given him to be with him where he is. 

# Why did and will Jesus make the Father's name known to those the Father has given to him?

Jesus did and will make it known so that the love with which the Father loved Jesus may be in them and that Jesus may be in them. 

# After Jesus spoke these words, where did he go?

He went with his disciples over the Kidron Valley to a garden and he entered it. 

# How did Judas know about the garden?

He knew about it because Jesus often went there with his disciples. 

# Who else came to the garden with lanterns, torches and weapons?

Judas, a group of soldiers and officers from the chief priests and Pharisees also came to the garden. 

# What did Jesus ask this group of people in the garden?

Jesus asked them, "For whom are you looking?" 

# What happened when the group of people said they were looking for Jesus of Nazareth and Jesus responded, "I am."?

The soldiers and others with them went backward and fell to the ground. 

# Why did Jesus say, "I told you that I am he; so if you are looking for me, let these others go."?

Jesus said this so that the word might be fulfilled that he said: "Of those whom you have given me, I lost not one." 

# Why did Jesus say, "I told you that I am he; so if you are looking for me, let these others go."?

Jesus said this so that the word might be fulfilled that he said: "Of those whom you have given me, I lost not one." 

# What did Jesus tell Peter after Peter cut off the ear of Malchus, the servant of the high priest?

Jesus said to Peter, "Put your sword back into its sheath. The cup that the Father has given me, should I not drink it?" 

# What did Jesus tell Peter after Peter cut off the ear of Malchus, the servant of the high priest?

Jesus said to Peter, "Put your sword back into its sheath. The cup that the Father has given me, should I not drink it?" 

# After the group of soldiers, their captain and the officers of the Jews seized Jesus, where did they take him?

They first took Jesus to Annas. 

# Who was Annas?

Annas was the father-in-law to Caiaphas, who was high priest that year. 

# How did Peter get into the courtyard of the high priest?

Another disciple who was known to the high priest, went out and spoke to the woman servant who was guarding the door and brought in Peter. 

# Who asked Peter if he was a disciple of Jesus or was with Jesus?

The woman guarding the door to the courtyard, the people standing around the fire of coals and one of the servants of the high priest, who was a relative of the man whose ear Peter had cut off, all asked Peter if he was with Jesus or a disciple of Jesus. 

# In brief how did Jesus answer when the high priest asked Jesus about his disciples and his teaching?

Jesus said he spoke openly to the world in public. He told the chief priest to ask those who heard him about what he said. 

# In brief how did Jesus answer when the high priest asked Jesus about his disciples and his teaching?

Jesus said he spoke openly to the world in public. He told the chief priest to ask those who heard him about what he said. 

# In brief how did Jesus answer when the high priest asked Jesus about his disciples and his teaching?

Jesus said he spoke openly to the world in public. He told the chief priest to ask those who heard him about what he said. 

# After Annas questioned Jesus where did he send Jesus?

Annas sent Jesus to Caiaphas the high priest. 

# What happened immediately after Peter denied being associated with Christ for the third time?

The rooster crowed immediately after the third time Peter denied being associated with Christ. 

# Why did those who took Jesus to the Praetorium not enter it?

They did not enter the Praetorium so that they might not be defiled and so that they might eat the passover. 

# How did Jesus' accusers answer Pilot when he asked them, "What accusation are you bringing against this man?"

They answered and said to him, "If this man were not an evil doer, we would not have delivered him up to you." 

# How did Jesus' accusers answer Pilot when he asked them, "What accusation are you bringing against this man?"

They answered and said to him, "If this man were not an evil doer, we would not have delivered him up to you." 

# Why did the Jews take Jesus to Pilate instead of punishing Jesus themselves?

The Jews wanted to kill Jesus and it wasn't lawful for them to put any man to death without permission from the Roman authorities (Pilate). 

# What did Pilate ask Jesus?

Pilate asked Jesus if he was the king of the Jews, and he also asked Jesus what he had done. 

# What did Pilate ask Jesus?

Pilate asked Jesus if he was the king of the Jews, and he also asked Jesus what he had done. 

# What did Pilate ask Jesus?

Pilate asked Jesus if he was the king of the Jews, and he also asked Jesus what he had done. 

# What did Jesus tell Pilate about Jesus' kingdom?

Jesus told Pilate that his kingdom is not part of this world and does not come from here. 

# For what purpose was Jesus born?

Jesus was born to be a king. 

# What is Pilate's judgment about Jesus after talking with him?

Pilate said to the Jews, "I find no crime in this man." 

# When Pilate offered to release Jesus, what did the Jews cry out to Pilate?

The Jews cried out again and said, "Not this man, but Barabbas." 

# When Pilate offered to release Jesus, what did the Jews cry out to Pilate?

The Jews cried out again and said, "Not this man, but Barabbas." 

# What did the soldiers do to Jesus after Pilate had Jesus whipped?

The soldiers twisted thorns together to make a crown, put it on Jesus' head, and dressed him in a purple garment. They came to him and said, "Hail, king of the Jews!" and they struck him with their hands. 

# What did the soldiers do to Jesus after Pilate had Jesus whipped?

The soldiers twisted thorns together to make a crown, put it on Jesus' head, and dressed him in a purple garment. They came to him and said, "Hail, king of the Jews!" and they struck him with their hands. 

# Why did Pilate bring Jesus out to the people again?

Pilate brought Jesus out to the people so that they would know that Pilate found no guilt in Jesus. 

# What was Jesus wearing when Pilate brought him back out to the people?

Jesus was wearing the crown of thorns and the purple garment. 

# What did the chief priests and the officers say when they saw Jesus?

They cried out and said, "Crucify him, crucify him!" 

# What did the Jews say that made Pilate even more afraid?

The Jews told Pilate, "We have a law, and by that law he ought to die because he made himself the Son of God." 

# What did the Jews say that made Pilate even more afraid?

The Jews told Pilate, "We have a law, and by that law he ought to die because he made himself the Son of God." 

# What did Jesus say when Pilate asked Jesus, "From where do you come?"

Jesus gave Pilate no answer. 

# Who did Jesus say gave Pilate power over Jesus?

Jesus said, "You would have no power against me unless it had been given you from above." 

# Although Pilate wanted to release Jesus, what did the Jews say that prevented him?

The Jews cried out saying, "If you release this man, you are not Caesar's friend: Everyone who makes himself a king speaks against Caesar." 

# What was the last thing the chief priests said before Pilate handed Jesus over to them to be crucified?

The chief priests said, "We have no king but Caesar." 

# What was the last thing the chief priests said before Pilate handed Jesus over to them to be crucified?

The chief priests said, "We have no king but Caesar." 

# Where did they crucify Jesus?

They crucified Jesus at Golgotha which means the place of a skull. 

# Where did they crucify Jesus?

They crucified Jesus at Golgotha which means the place of a skull. 

# Was Jesus the only one crucified there that day?

No. Two other men, one on each side of Jesus were crucified with him. 

# What did Pilate write on the sign that was put on the cross of Jesus?

On the sign was written, "JESUS OF NAZARETH, THE KING OF THE JEWS." 

# In what languages was the sign on Jesus' cross written?

The sign was written in Hebrew, Latin and Greek. 

# What did the soldiers do with Jesus' garments?

The soldiers divided up Jesus' garments into four parts, a part for each soldier. But the cast lots to see who would get Jesus' shirt which was without seams. 

# Why did the soldiers do what they did with Jesus' garments?

This happened so that the Scripture might be fulfilled that said, "They divided my garments among themselves, and for my clothing they threw lots." 

# What did the soldiers do with Jesus' garments?

The soldiers divided up Jesus' garments into four parts, a part for each soldier. But the cast lots to see who would get Jesus' shirt which was without seams. 

# Why did the soldiers do what they did with Jesus' garments?

This happened so that the Scripture might be fulfilled that said, "They divided my garments among themselves, and for my clothing they threw lots." 

# Who was standing near the cross of Jesus?

Jesus' mother, his mother's sister, Mary the wife of Clopas, Mary Magdalene, and the disciple whom Jesus loved were standing near the cross of Jesus. 

# Who was standing near the cross of Jesus?

Jesus' mother, his mother's sister, Mary the wife of Clopas, Mary Magdalene, and the disciple whom Jesus loved were standing near the cross of Jesus. 

# What did Jesus tell his mother when he saw his mother and the disciple he loved standing nearby?

Jesus told her, "Woman, see, here is your son!" 

# What did the disciple Jesus loved do after Jesus told him, "See, here is your mother!"?

From that hour the disciple Jesus loved took Jesus' mother to his own home. 

# Why did Jesus say, "I am thirsty."

Jesus said this in order to make the Scriptures come true. 

# What did Jesus do after he had taken the vinegar from the sponge that was held up to his mouth?

After taking the vinegar Jesus said, "It is finished." Then he bowed his head and gave up his spirit. 

# What did Jesus do after he had taken the vinegar from the sponge that was held up to his mouth?

After taking the vinegar Jesus said, "It is finished." Then he bowed his head and gave up his spirit. 

# Why did the Jews want Pilate to break the legs of the executed men?

It was the Preparation, and in order that the bodies should not remain on the cross during the Sabbath (for that Sabbath was an important day), the Jews asked Pilate that the legs of the executed men be broken and that their bodies might be taken down. 

# Why did the soldiers not break Jesus' legs?

They didn't break Jesus' legs because they saw he was already dead. 

# What did the soldiers do to Jesus after they was that he was already dead?

One of the soldiers pierced Jesus' side with a spear. 

# Why did the one who saw all these things concerning the crucifiction of Jesus bear witness to them?

That one bore withness to these events so that you also may believe 

# Why were the legs of Jesus not broken and why was Jesus pierced with a spear?

These things came about so that the scripture might be fulfilled, "Not a single bone of him will be broken." and again, "They will look on him whom they pierced." 

# Why were the legs of Jesus not broken and why was Jesus pierced with a spear?

These things came about so that the scripture might be fulfilled, "Not a single bone of him will be broken." and again, "They will look on him whom they pierced." 

# Who came and asked to take away the body of Jesus?

Joseph of Arimathea asked Pilate that he might take away the body of Jesus. 

# Who came with Joseph of Arimathea to take away the body of Jesus?

Nicodemus came with Joseph of Arimathea. 

# What did Joseph of Arimathea and Nicodemus do with the body of Jesus?

They wrapped Jesus body in linen cloths with spices. Then they laid Jesus' body in a new tomb which was in a garden. 

# What did Joseph of Arimathea and Nicodemus do with the body of Jesus?

They wrapped Jesus body in linen cloths with spices. Then they laid Jesus' body in a new tomb which was in a garden. 

# When did Mary Magdalene come to the tomb?

She came to the tomb early on the first day of the week. 

# What did Mary Magdalene see when she got to the tomb?

She saw the stone rolled away from the tomb. 

# What did Mary Magdalene say to the two disciples?

She told them, "They have taken away the Lord out of the tomb, and we do not know where they have laid him." 

# What did Simon Peter and the other disciple do after they heard what Mary Magdalene said?

They both ran together to the tomb. 

# What did Simon Peter and the other disciple do after they heard what Mary Magdalene said?

They both ran together to the tomb. 

# What did Simon Peter see in the tomb?

Peter saw the linen cloths lying there. The cloth that had been on his head was not lying with the linen cloths but was rolled up in its place by itself. 

# What did Simon Peter see in the tomb?

Peter saw the linen cloths lying there. The cloth that had been on his head was not lying with the linen cloths but was rolled up in its place by itself. 

# What was the response of the other disciple to what he saw in the tomb?

He saw and believed. 

# What did Mary see when she stooped and looked into the tomb?

She saw two angels in white sitting, one at the head, and one at the foot, where the body of Jesus had lain. 

# What did the angels say to Mary?

They asked her, "Woman, why are you weeping?" 

# When Mary turned around what did she see?

She saw Jesus standing there, but she did not know that it was Jesus. 

# Who did Mary think Jesus was?

She thought he was the gardener. 

# When did Mary recognize Jesus?

She recognized Jesus when he said her name, "Mary". 

# Why did Jesus tell Mary not to touch him?

Jesus told her not to touch him because he hadn't yet ascended to the Father. 

# What did Jesus tell Mary to say to his brothers?

Jesus told her to say to his brothers, that I will ascend to my Father and your Father, and my God and your God. 

# What happened where the disciples were on the evening of the first day of the week?

Jesus came and stood in the midst of them. 

# What did Mary Magdalene do after she saw the stone rolled away from the tomb?

She ran and came to Simon Peter and to the other disciple Jesus loved. 

# What did Jesus show the disciples?

He showed them his hands and his side. 

# What did Jesus say he was doing to the disciples?

Jesus said he was sending the disciples just as his Father had sent him. 

# What did Jesus say to his disciples after he breathed on them?

He told them, "Receive the Holy Spirit. Whoever's sins you forgive, they are forgiven for them; whoever's sins you keep back, they are kept back." 

# What did Jesus say to his disciples after he breathed on them?

He told them, "Receive the Holy Spirit. Whoever's sins you forgive, they are forgiven for them; whoever's sins you keep back, they are kept back." 

# Which one of the disciples was not present with the other disciples when they saw Jesus?

Thomas, one of the twelve, called Didymus, was not with the other disciples when Jesus came. 

# What did Thomas say it would take for him to believe that Jesus was alive?

Thomas said he would have to see the print of the nails in Jesus' hands and put his fingers into the nail prints and put his hand into Jesus' side before he would believe. 

# When did Thomas see Jesus?

Eight days later Thomas was with the other disciples when Jesus came while the doors were shut and stood among them. 

# What did Jesus tell Thomas to do?

Jesus told Thomas to reach with his finger and see Jesus' hands and reach with his hand and put it into Jesus' side. Jesus then told Thomas not to be faithless, but believe. 

# What did Thomas say to Jesus?

Thomas said, "My Lord and my God." 

# Who did Jesus say was blessed?

Jesus said, "Blessed are those who have not seen, and yet have believed." 

# Did Jesus do other signs that weren't written in the book?

Yes, Jesus did many other signs in the presence of the disciples that were not written in the book of John. 

# Why were the signs written in the book?

They were written so that you may believe that Jesus is the Christ, the Son of God, and so that as you believe, you may have life in his name. 

# Where were the disciples when Jesus showed himself to them again?

The disciples were at the Sea of Tiberias when Jesus showed himself to them again. 

# Which disciples were at the Sea of Tiberias?

Simon Peter, Thomas, called Didymus, Nathaniel from Cana in Galilee, the sons of Zebedee and two of Jesus' other disciples were at the Sea of Tiberias. 

# What were these disciples doing?

These disciples had gone fishing but had caught nothing all night. 

# What did Jesus tell the disciples to do?

Jesus told the disciples to cast their net on the right side of the boat and they would catch some fish. 

# What happened when the disciples cast their net?

They could not draw in their net because there were so many fish in it. 

# What did Simon Peter do when the disciple Jesus loved said, "It is the Lord."

He tucked up his outer garment about himself and threw himself into the sea. 

# What did the other disciples do?

The other disciples came in the boat pulling the net full of fish. 

# What did Jesus tell the disciples to do with some of the fish that they had caught?

Jesus told the disciples to bring some of the fish they had just caught. 

# How many times had Jesus now shown himself to the disciples since he had risen?

This was the third time Jesus had now shown himself to the disciples since he had risen. 

# After breakfast what was the first thing Jesus asked Simon Peter?

Jesus asked Simon Peter if Simon loved Jesus more than these. 

# How did Simon Peter answer Jesus the third time Jesus asked Peter if he loved Jesus?

The third time he was asked Peter responded, "Lord, you know all things, you know that I love you." 

# The third time Peter responds to Jesus' question, "Do you love me?" what does Jesus tell Peter to do?

The third time Jesus told him, "Feed my sheep." 

# What did Jesus tell Simon Peter was going to happen to him when Simon became old?

Jesus told Simon Peter that when he became old, he would stretch out his hands and another person would clothe him and carry him where he did not wish to go. 

# Why did Jesus tell Peter what was going to happen to Peter when he became old?

Jesus said this in order to signal by what kind of death Peter would glorify God. 

# What did Simon Peter ask Jesus concerning the disciple that Jesus loved?

Peter asked Jesus, "Lord, what will this man do?" 

# How did Jesus respond to Peter's question, "Lord, what will this man do?"

Jesus told Peter, "Follow me." 

# Who wrote this book and to what does he bear witness?

The disciple Jesus loved wrote this book and bears witness that the events described in the book are true. 

