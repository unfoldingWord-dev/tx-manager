# What did the prophet Isaiah predict would happen before the Lord came?

Isaiah predicted that God would send a messenger, a voice of someone calling out in the wilderness, to prepare the way of the Lord. 

# What did the prophet Isaiah predict would happen before the Lord came?

Isaiah predicted that God would send a messenger, a voice of someone calling out in the wilderness, to prepare the way of the Lord. 

# What did John come preaching?

John came preaching a baptism of repentance for the forgiveness of sins. 

# What did the people do as they were baptized by John?

The people confessed their sins as they were baptized by John. 

# What did John eat?

John ate locusts and wild honey. 

# With what did John say the one coming after him would baptize?

John said the one coming after him would baptize with the Holy Spirit. 

# What did Jesus see as he came up out of the water after being baptized by John?

After being baptized, Jesus saw the heavens split open and the Spirit descend on him as a dove. 

# What did the voice from heaven say after Jesus was baptized?

The voice from heaven said, "You are my beloved Son; I am very pleased with you". 

# Who drove Jesus out into the wilderness?

The Spirit drove Jesus out into the wilderness. 

# How long was Jesus in the wilderness, and what happened to him there?

Jesus was in the wilderness forty days, and he was tempted by Satan there. 

# What message did Jesus preach?

Jesus preached that the kingdom of God was near, and that people must repent and believe in the gospel. 

# What was the occupation of Simon and Andrew?

Simon and Andrew were fishermen. 

# What did Jesus say he would make Simon and Andrew?

Jesus said he would make Simon and Andrew fishers of men. 

# What was the occupation of James and John?

James and John were fishermen. 

# Why did Jesus' teaching astonish the people in the synagogue?

Jesus' teaching astonished the people because Jesus taught as one with authority. 

# What title did the unclean spirit in the synagogue give Jesus?

The unclean spirit in the synagogue gave Jesus the title of the Holy One of God. 

# What happened with the news about Jesus?

The news about Jesus went out everywhere. 

# When they went into Simon's house, who did Jesus heal?

When they went into Simon's house, Jesus healed Simon's mother-in-law. 

# What happened when it was evening?

When it was evening, the people brought all who were sick or possessed by demons, and Jesus healed them. 

# What happened when it was evening?

When it was evening, the people brought all who were sick or possessed by demons, and Jesus healed them. 

# What happened when it was evening?

When it was evening, the people brought all who were sick or possessed by demons, and Jesus healed them. 

# What did Jesus do before the sun rose?

Before the sun rose, Jesus went out to a solitary place and prayed there. 

# What did Jesus tell Simon he had come to do?

Jesus said that he had come to preach in the surrounding towns. 

# What did Jesus tell Simon he had come to do?

Jesus said that he had come to preach in the surrounding towns. 

# What attitude did Jesus have toward the leper who begged Jesus to be healed?

Jesus had pity on the leper and healed him. 

# What attitude did Jesus have toward the leper who begged Jesus to be healed?

Jesus had pity on the leper and healed him. 

# What attitude did Jesus have toward the leper who begged Jesus to be healed?

Jesus had pity on the leper and healed him. 

# What did Jesus tell the leper to do, and why?

Jesus told the leper to go offer the sacrifices according to what Moses commanded as a testimony. 

# What did the four men do who were carrying the paralyzed man?

The men removed the roof of the house and lowered the paralyzed man to Jesus. 

# What did Jesus say to the paralyzed man?

Jesus said, "Child, your sins are forgiven". 

# Why did some of the scribes object to what Jesus had said?

Some of the scribes reasoned that Jesus had blasphemed because only God can forgive sins. 

# Why did some of the scribes object to what Jesus had said?

Some of the scribes reasoned that Jesus had blasphemed because only God can forgive sins. 

# How did Jesus demonstrate that he had authority on earth to forgive sins?

Jesus told the paralyzed man to take up his bed and go to his house, and the man did. 

# How did Jesus demonstrate that he had authority on earth to forgive sins?

Jesus told the paralyzed man to take up his bed and go to his house, and the man did. 

# How did Jesus demonstrate that he had authority on earth to forgive sins?

Jesus told the paralyzed man to take up his bed and go to his house, and the man did. 

# What was Levi doing when Jesus told Levi to follow him?

Levi was sitting at the tax-collecting place when Jesus called him. 

# What was Levi doing when Jesus told Levi to follow him?

Levi was sitting at the tax-collecting place when Jesus called him. 

# At Levi's house, what was Jesus doing that offended the Pharisees?

Jesus was dining with the sinful people and tax collectors. 

# At Levi's house, what was Jesus doing that offended the Pharisees?

Jesus was dining with the sinful people and tax collectors. 

# Who did Jesus say he had come to call?

Jesus said he had come to call sinful people. 

# What question did some people ask Jesus about fasting?

They asked Jesus why his disciples did not fast when John's disciples and the Pharisees' disciples did fast. 

# How did Jesus explain why his disciples were not fasting?

Jesus said that while the bridegroom is still with the wedding attendants they cannot fast. 

# What did Jesus' disciples do in some fields on the Sabbath which offended the Pharisees?

Jesus' disciples picked heads of grain and ate them on the Sabbath. 

# What did Jesus' disciples do in some fields on the Sabbath which offended the Pharisees?

Jesus' disciples picked heads of grain and ate them on the Sabbath. 

# What example did Jesus give of someone who needed and ate bread normally forbidden for them?

Jesus gave the example of David who out of need ate the bread of the presence normally reserved for the priests. 

# What example did Jesus give of someone who needed and ate bread normally forbidden for them?

Jesus gave the example of David who out of need ate the bread of the presence normally reserved for the priests. 

# For whom did Jesus say the Sabbath was made?

Jesus said the Sabbath was made for people. 

# What authority did Jesus claim for himself?

Jesus said that he was Lord also of the Sabbath. 

# Why were they watching Jesus on the Sabbath in the synagogue?

They were watching Jesus to see if he would heal on the Sabbath, so they could accuse him. 

# Why were they watching Jesus on the Sabbath in the synagogue?

They were watching Jesus to see if he would heal on the Sabbath, so they could accuse him. 

# What question did Jesus ask the people about the Sabbath?

Jesus asked the people if it was lawful to do good or to do harm on the Sabbath. 

# How did the people respond to Jesus' question?

The people were silent. 

# What then was Jesus' attitude toward them?

Jesus became angry with them. 

# What did the Pharisees do when Jesus healed the man?

The Pharisees went out and plotted to put Jesus to death. 

# How many people followed Jesus as he went to the sea?

A great crowd followed Jesus. 

# How many people followed Jesus as he went to the sea?

A great crowd followed Jesus. 

# What did the demons cry out when they saw Jesus?

The demons cried out that Jesus was the Son of God. 

# How many men did Jesus appoint as apostles, and what were they to do?

Jesus appointed twelve apostles who were to be with him, preach, and have authority to cast out demons. 

# How many men did Jesus appoint as apostles, and what were they to do?

Jesus appointed twelve apostles who were to be with him, preach, and have authority to cast out demons. 

# Who was the apostle that would betray Jesus?

The apostle that would betray Jesus was Judas Iscariot. 

# What did Jesus' family think about the crowds and the events surrounding Jesus?

Jesus' family thought that he was out of his mind. 

# What accusation did the scribes make against Jesus?

The scribes accused Jesus of driving out demons by the ruler of demons. 

# What was Jesus' response to the scribes' accusation?

Jesus responded that no kingdom divided against itself can stand. 

# What was Jesus' response to the scribes' accusation?

Jesus responded that no kingdom divided against itself can stand. 

# What was Jesus' response to the scribes' accusation?

Jesus responded that no kingdom divided against itself can stand. 

# What sin did Jesus say cannot be forgiven?

Jesus said that blasphemy against the Holy Spirit cannot be forgiven. 

# What sin did Jesus say cannot be forgiven?

Jesus said that blasphemy against the Holy Spirit cannot be forgiven. 

# What sin did Jesus say cannot be forgiven?

Jesus said that blasphemy against the Holy Spirit cannot be forgiven. 

# Who did Jesus say were his mother and brothers?

Jesus said that his mother and brothers were those who do the will of God. 

# Who did Jesus say were his mother and brothers?

Jesus said that his mother and brothers were those who do the will of God. 

# Who did Jesus say were his mother and brothers?

Jesus said that his mother and brothers were those who do the will of God. 

# Why did Jesus get into a boat to teach?

Jesus got into a boat to teach because a very large crowd had gathered around him. 

# What happened to the seeds sown on the road?

The birds came and devoured them. 

# What happened to the seeds sown on the rocky ground when the sun rose?

They withered away because they had no root. 

# What happened to the seeds sown among thorn plants?

The thorn plants choked them. 

# What happened to the seeds sown in the good soil?

The seeds produced grain, yielding thirty, sixty, and some a hundred times what was planted. 

# What did Jesus say was given to the Twelve, but not to those outside?

Jesus said the mystery of the kingdom of God was given to the Twelve, but not to those outside. 

# In Jesus' parable, what is the seed?

The seed is the word of God. 

# What does the seed sown on the road represent?

It represents those who hear the word, but immediately Satan takes it away. 

# What does the seed sown on the rocky ground represent?

It represents those who hear the word with joy, but when persecution comes they stumble. 

# What does the seed sown on the rocky ground represent?

It represents those who hear the word with joy, but when persecution comes they stumble. 

# What does the seed sown among thorn plants represent?

It represents those who hear the word, but the cares of the world choke the word. 

# What does the seed sown among thorn plants represent?

It represents those who hear the word, but the cares of the world choke the word. 

# What does the seed sown in the good soil represent?

It represents those who hear the word, receive it, and produce fruit. 

# What did Jesus say would happen to the hidden and secret things?

Jesus said that the hidden and secret things would be brought into the light. 

# In what way is the kingdom of God like a man who casts his seed upon the ground?

The man casts the seed, and it grows, but he does not know how, then when the harvest is ripe he gathers it. 

# In what way is the kingdom of God like a man who casts his seed upon the ground?

The man casts the seed, and it grows, but he does not know how, then when the harvest is ripe he gathers it. 

# In what way is the kingdom of God like a man who casts his seed upon the ground?

The man casts the seed, and it grows, but he does not know how, then when the harvest is ripe he gathers it. 

# In what way is the kingdom of God like a man who casts his seed upon the ground?

The man casts the seed, and it grows, but he does not know how, then when the harvest is ripe he gathers it. 

# In what way is the kingdom of God like a mustard seed?

The mustard seed begins as the smallest of seeds, yet grows into a great plant where many can make their nests. 

# In what way is the kingdom of God like a mustard seed?

The mustard seed begins as the smallest of seeds, yet grows into a great plant where many can make their nests. 

# In what way is the kingdom of God like a mustard seed?

The mustard seed begins as the smallest of seeds, yet grows into a great plant where many can make their nests. 

# What happened as the disciples and Jesus crossed the lake?

A great storm began, threatening to fill the boat with water. 

# What happened as the disciples and Jesus crossed the lake?

A great storm began, threatening to fill the boat with water. 

# What happened as the disciples and Jesus crossed the lake?

A great storm began, threatening to fill the boat with water. 

# What was Jesus doing at this time in the boat?

Jesus was sleeping. 

# What question did the disciples ask Jesus?

The disciples asked Jesus if he cared that they were about to die. 

# What did Jesus then do?

Jesus rebuked the wind and calmed the sea. 

# After Jesus did this, what was the response of the disciples?

The disciples were filled with great fear and wondered who Jesus was that the wind and sea obeyed him. 

# Who met Jesus when they came to the region of the Gerasenes?

A man with an unclean spirit met Jesus. 

# Who met Jesus when they came to the region of the Gerasenes?

A man with an unclean spirit met Jesus. 

# What had happened when people tried to restrain this man with chains?

When people tried to restrain this man with chains, he tore the chains apart. 

# What title did the unclean spirit give Jesus?

The unclean spirit called Jesus the Son of the Most High God. 

# What did Jesus say to the man?

Jesus said to the man, "Come out of the man, you unclean spirit". 

# What was the name of the unclean spirit?

The unclean spirit's name was Army, because there were many. 

# What happened when Jesus cast out the unclean spirit from the man?

The spirits came out and entered a herd of pigs, who ran down a steep hill and drowned in the lake. 

# After the unclean spirit was cast out, what was the condition of the man?

The man was sitting with Jesus, clothed and in his right mind. 

# What did the people of the region ask Jesus to do?

The people asked Jesus to leave their region. 

# What did Jesus tell the man who had lived in the tombs to now do?

Jesus told the man to tell his people what the Lord had done for him. 

# What request did Jairus, the synagogue leader, make of Jesus?

Jairus asked Jesus to come with him to lay hands on his daughter who was near death. 

# What request did Jairus, the synagogue leader, make of Jesus?

Jairus asked Jesus to come with him to lay hands on his daughter who was near death. 

# What was the problem with the woman who touched Jesus' cloak?

The woman had suffered with a discharge of blood for twelve years. 

# Why did the woman touch Jesus' cloak?

The woman thought that if she just touched Jesus' clothes, she would be healed. 

# What did Jesus do when the woman touched his cloak?

Jesus knew that power had gone out from him and looked around to see who had touched him. 

# What did Jesus do when the woman touched his cloak?

Jesus knew that power had gone out from him and looked around to see who had touched him. 

# When the woman told Jesus all the truth, what did Jesus say to her?

Jesus told her that her faith had made her well, and to go in peace. 

# What was the condition of Jairus' daughter when Jesus arrived at the house?

Jairus' daughter was dead. 

# What did Jesus tell Jairus at this time?

Jesus told Jairus to not be afraid, but to just believe. 

# Which disciples went with Jesus into the room where the child was?

Peter, James, and John went with Jesus into the room. 

# What did the people in the house do when Jesus said Jairus' daughter was only sleeping?

The people laughed at Jesus when he said that Jairus' daughter was only sleeping. 

# When the child got up and walked, how did the people react?

The people were greatly overcome and astonished. 

# Why were the people of Jesus' home town shocked about him?

The people did not know from where he got his teachings, his wisdom, and his miracles. 

# Where did Jesus say a prophet is without honor?

Jesus said a prophet is without honor in his home town, among his relatives, and in his own household. 

# What amazed Jesus about the people in his home town?

Jesus was amazed by the unbelief of the people in his home town. 

# What authority did Jesus give the Twelve as he sent them out?

Jesus gave the Twelve authority over unclean spirits. 

# What did the Twelve take with them on their journey?

The Twelve took a staff, sandals, and one tunic. 

# What did the Twelve take with them on their journey?

The Twelve took a staff, sandals, and one tunic. 

# What did Jesus tell the Twelve to do if a place did not receive them?

Jesus told the Twelve to shake off the dust under their feet as a testimony against them. 

# Who did the people suppose Jesus was?

The people supposed that Jesus was John the Baptizer, or Elijah, or a prophet. 

# Who did the people suppose Jesus was?

The people supposed that Jesus was John the Baptizer, or Elijah, or a prophet. 

# What had John the Baptizer told Herod he was doing unlawfully?

John had told Herod it was unlawful for Herod to marry his brother's wife. 

# How did Herod react when he heard John preach?

Herod became upset when he heard John preach, but he was still glad to hear him. 

# What oath did Herod swear to Herodias?

Herod swore that she could have whatever she asked of him, up to half of his kingdom. 

# For what did Herodias ask?

Herodias asked for the head of John the Baptizer on a platter. 

# How did Herod react to Herodias' request?

Herod became very sorry, but did not refuse her request because of the oaths he had made in front of his guests. 

# What happened when Jesus and the apostles tried to go away by themselves to rest?

Many people recognized them and ran to arrive there before Jesus and the apostles. 

# What was Jesus' attitude toward the crowd that was waiting for them?

Jesus had compassion on them because they were like sheep without a shepherd. 

# When asked by Jesus, what did the disciples think they would have to do to feed the people?

The disciples thought they would have to go and buy two hundred denarii worth of bread. 

# What food did the disciples already have with them?

The disciples already had five loaves and two fish with them. 

# What did Jesus do as he took the loaves and fish?

As he took the loaves and fish, Jesus looked up to heaven, blessed and broke the loaves, and gave them to his disciples. 

# How much food was left after everyone ate?

There were twelve baskets of bread, and pieces of fish left after everyone ate. 

# How many men had been fed?

There were five thousand men that had been fed. 

# How did Jesus come to the disciples on the lake?

Jesus came to the disciples walking on the lake. 

# What did Jesus tell the disciples when they saw him?

Jesus told the disciples to be brave and to not be afraid. 

# Why did the disciples not understand about the miracle of the loaves?

The disciples did not understand about the miracle of the loaves because their minds were slow to understand. 

# What did the people of the region do when they recognized Jesus?

The people brought the sick on stretchers to Jesus wherever they heard he was coming. 

# What happened to those who just touched the fringe of Jesus' garment?

Those who just touched the fringe of Jesus' garment were healed. 

# What were some of Jesus' disciples doing that offended the Pharisees and scribes?

Some of the disciples were eating with unwashed hands. 

# Whose tradition was it that hands, cups, pots, copper vessels, and dining couches be washed before eating?

It was the tradition of the elders that hands, cups, pots, copper vessels, and dining couches be washed before eating. 

# Whose tradition was it that hands, cups, pots, copper vessels, and dining couches be washed before eating?

It was the tradition of the elders that hands, cups, pots, copper vessels, and dining couches be washed before eating. 

# What did Jesus say to the Pharisees and scribes about their teaching on the issue of washing?

Jesus said that the Pharisees and scribes taught the rules of men while abandoning the commandment of God. 

# What did Jesus say to the Pharisees and scribes about their teaching on the issue of washing?

Jesus said that the Pharisees and scribes taught the rules of men while abandoning the commandment of God. 

# How did the Pharisees and scribes void the commandment of God which says to honor your father and mother?

They voided God's commandment by telling people to give to them as Corban the money that would have helped their father and mother. 

# How did the Pharisees and scribes void the commandment of God which says to honor your father and mother?

They voided God's commandment by telling people to give to them as Corban the money that would have helped their father and mother. 

# How did the Pharisees and scribes void the commandment of God which says to honor your father and mother?

They voided God's commandment by telling people to give to them as Corban the money that would have helped their father and mother. 

# What did Jesus say does not defile a person?

Jesus said that nothing from outside of a person can defile him when it enters into him. 

# What did Jesus say defiles a person?

Jesus said that what comes out of a person defiles him. 

# What did Jesus say does not defile a person?

Jesus said that nothing from outside of a person can defile him when it enters into him. 

# What did Jesus say does not defile a person?

Jesus said that nothing from outside of a person can defile him when it enters into him. 

# What kinds of foods did Jesus declare to be clean?

Jesus declared all foods to be clean. 

# What did Jesus say defiles a person?

Jesus said that what comes out of a person defiles him. 

# What did Jesus say defiles a person?

Jesus said that what comes out of a person defiles him. 

# What are three things that Jesus said can come out of a person to defile him?

Jesus said that evil thoughts, sexual immorality, theft, murder, adultery, coveting, wickedness, deceit, sensuality, envy, slander, pride, and folly can come out of a person to defile him. 

# What did Jesus say defiles a person?

Jesus said that what comes out of a person defiles him. 

# What are three things that Jesus said can come out of a person to defile him?

Jesus said that evil thoughts, sexual immorality, theft, murder, adultery, coveting, wickedness, deceit, sensuality, envy, slander, pride, and folly can come out of a person to defile him. 

# What did Jesus say defiles a person?

Jesus said that what comes out of a person defiles him. 

# Was the woman whose daughter had an unclean spirit a Jew or a Greek?

The woman whose daughter had an unclean spirit was a Greek. 

# Was the woman whose daughter had an unclean spirit a Jew or a Greek?

The woman whose daughter had an unclean spirit was a Greek. 

# How did the woman respond when Jesus told her that it was not right to take the children's bread and throw it to the dogs?

The woman said that even the dogs under the table eat the children's crumbs. 

# What did Jesus do for the woman?

Jesus cast the demon out of the woman's daughter. 

# What did Jesus do for the woman?

Jesus cast the demon out of the woman's daughter. 

# When the man who was deaf and had a speech impediment was brought to Jesus, what did he do to heal him?

Jesus put his fingers in the man's ears, spit and touched his tongue, then looked to heaven and said, "Open!" 

# When the man who was deaf and had a speech impediment was brought to Jesus, what did he do to heal him?

Jesus put his fingers in the man's ears, spit and touched his tongue, then looked to heaven and said, "Open!" 

# What did the people do when Jesus told them to tell no one about his healings?

The more Jesus commanded them to be quiet, the more they talked about it. 

# What concern did Jesus state about the great crowd that had been following him?

Jesus stated that he was concerned the great crowd had nothing to eat. 

# What concern did Jesus state about the great crowd that had been following him?

Jesus stated that he was concerned the great crowd had nothing to eat. 

# How many loaves did the disciples have with them?

The disciples had seven loaves with them. 

# What did Jesus do with the disciples' loaves?

Jesus gave thanks, broke the loaves, and gave them to his disciples to serve. 

# How much food remained after everyone had eaten?

There were seven baskets of food remaining after everyone had eaten. 

# How many people ate and were satisfied?

There were about four thousand men who ate and were satisfied. 

# To test him, what did the Pharisees want Jesus to do?

The Pharisees wanted Jesus to give them a sign from heaven. 

# About what did Jesus warn his disciples concerning the Pharisees?

Jesus warned his disciples to be on guard of the yeast of the Pharisees. 

# About what did the disciples think Jesus was talking?

The disciples thought Jesus was talking about the fact that they had forgotten to bring bread. 

# Jesus reminded his disciples that what had happened when Jesus had broken five loaves?

Jesus reminded them that when he had broken five loaves, five thousand people had been fed and twelves baskets full of broken pieces had been taken up. 

# What two things did Jesus first do to the blind man in order to restore his sight?

Jesus first spat on his eyes and laid his hands upon him. 

# What third thing did Jesus do to the blind man in order to completely restore his sight?

Jesus laid his hands upon his eyes. 

# Who were the people saying that Jesus was?

The people were saying that Jesus was John the Baptizer, Elijah, or one of the prophets. 

# Who did Peter say that Jesus was?

Peter said that Jesus was the Christ. 

# About what future events did Jesus begin to teach his disciples clearly?

Jesus taught his disciples that the Son of Man must suffer, be rejected, be killed, and be raised after three days. 

# What did Jesus say when Peter began to rebuke him?

Jesus said to Peter, "Get behind me Satan! You do not care for the things of God, but for the things of people". 

# What did Jesus say anyone who wants to follow him must do?

Jesus said that anyone who wants to follow him must deny himself and take up his cross. 

# What did Jesus say about a person's desire to gain the things of the world?

Jesus said, "What does it profit a person to gain the whole world, and then forfeit his life?" 

# What did Jesus say he would do concerning those who are ashamed of him and his words?

Jesus said that at his coming he would be ashamed of those who were ashamed of him and his words. 

# Who did Jesus say would see the kingdom of God coming with power?

Jesus said that some standing there with him would not die before they saw the kingdom of God coming with power. 

# What happened to Jesus when Peter, James, and John went up a high mountain with him?

Jesus was transfigured and his garments became radiantly brilliant. 

# What happened to Jesus when Peter, James, and John went up a high mountain with him?

Jesus was transfigured and his garments became radiantly brilliant. 

# Who was talking with Jesus on the mountain?

Elijah and Moses were talking with Jesus. 

# On the mountain, what did the voice from the cloud say?

The voice said, "This is my beloved Son. Listen to him". 

# What did Jesus command the disciples about what they had seen on the mountain?

Jesus commanded them to tell no one what they had seen, until the Son of Man had risen from the dead. 

# What did Jesus say about Elijah's coming?

Jesus said that Elijah does come first to restore all things, and that Elijah had already come. 

# What did Jesus say about Elijah's coming?

Jesus said that Elijah does come first to restore all things, and that Elijah had already come. 

# What did Jesus say about Elijah's coming?

Jesus said that Elijah does come first to restore all things, and that Elijah had already come. 

# What were the disciples unable to do for the father and his son?

The disciples were unable to drive out the evil spirit from the father's son. 

# What were the disciples unable to do for the father and his son?

The disciples were unable to drive out the evil spirit from the father's son. 

# Into what did the evil spirit throw the boy to try to destroy him?

The evil spirit threw the boy into the fire or into the waters to try to destroy him. 

# How did the father respond when Jesus said all things are possible for the one who believes?

The father responded, "I believe! Help my unbelief!" 

# How did the father respond when Jesus said all things are possible for the one who believes?

The father responded, "I believe! Help my unbelief!" 

# Why were the disciples unable to cast out the mute and deaf spirit in the boy?

The disciples were unable to cast out the spirit because it could not be cast out except by prayer. 

# Why were the disciples unable to cast out the mute and deaf spirit in the boy?

The disciples were unable to cast out the spirit because it could not be cast out except by prayer. 

# What did Jesus tell his disciples would happen to him?

Jesus told them he would be put to death, then after three days he would rise again. 

# What were the disciples arguing about along the way?

The disciples were arguing about who among them was the greatest. 

# What were the disciples arguing about along the way?

The disciples were arguing about who among them was the greatest. 

# Who did Jesus say is first?

Jesus said that he is first who is servant of all. 

# When someone receives a little child in Jesus' name, who are they also receiving?

When someone receives a little child in Jesus' name, they are also receiving Jesus and the one who sent Jesus. 

# When someone receives a little child in Jesus' name, who are they also receiving?

When someone receives a little child in Jesus' name, they are also receiving Jesus and the one who sent Jesus. 

# What would be better for someone who causes a little one who believes in Jesus to stumble?

It would be better for that one if a millstone were tied around his neck and he was thrown into the sea. 

# What did Jesus say to do with your eye if it causes you to stumble?

Jesus said to tear out your eye if it causes you to stumble. 

# What did Jesus say happens in hell?

Jesus said that in hell the worm does not die, and the fire is not put out. 

# What question did the Pharisees ask Jesus in order to test him?

The Pharisees asked Jesus if it was lawful for a husband to divorce his wife. 

# What commandment had Moses given the Jews concerning divorce?

Moses had allowed a man to write a certificate of divorce and then send his wife away. 

# Why had Moses given the Jews this commandment concerning divorce?

Moses had given this commandment to the Jews because of their hard hearts. 

# To what event in history did Jesus refer when telling the Pharisees about God's original design for marriage?

Jesus referred to the creation of male and female at the beginning when telling about God's original design for marriage. 

# What did Jesus say the two people, the man and his wife, become when they are married?

Jesus said that the two become one flesh. 

# What did Jesus say the two people, the man and his wife, become when they are married?

Jesus said that the two become one flesh. 

# What did Jesus say about what God joins together in marriage?

Jesus said that what God joins together, let no man tear apart. 

# What was Jesus' reaction when the disciples rebuked those bringing little children to him?

Jesus was angry with the disciples and told them to permit the little children to come to him. 

# What was Jesus' reaction when the disciples rebuked those bringing little children to him?

Jesus was angry with the disciples and told them to permit the little children to come to him. 

# How did Jesus say the kingdom of God must be received in order to enter it?

Jesus said the kingdom of God must be received as a little child in order to enter it. 

# What did Jesus first tell the man he must do to inherit eternal life?

Jesus told the man he must not kill, not commit adultery, not steal, not testify falsely, not defraud, and must honor his father and mother. 

# What additional commandment did Jesus then give the man?

Jesus then commanded the man to sell at that he had and to follow him. 

# How did the man react when Jesus gave him this commandment, and why?

The man was sorrowful and walked away, for he had many possessions. 

# Who did Jesus say had great difficulty entering the kingdom of God?

Jesus said that the rich had great difficulty entering the kingdom of God. 

# Who did Jesus say had great difficulty entering the kingdom of God?

Jesus said that the rich had great difficulty entering the kingdom of God. 

# Who did Jesus say had great difficulty entering the kingdom of God?

Jesus said that the rich had great difficulty entering the kingdom of God. 

# How did Jesus say even a rich person could be saved?

Jesus said that with people it is impossible, but with God all things are possible. 

# How did Jesus say even a rich person could be saved?

Jesus said that with people it is impossible, but with God all things are possible. 

# What did Jesus say anyone would receive who had left house, family, and lands for Jesus' sake?

Jesus said they would receive a hundred times as much in this world, with persecutions, and eternal life in the world to come. 

# What did Jesus say anyone would receive who had left house, family, and lands for Jesus' sake?

Jesus said they would receive a hundred times as much in this world, with persecutions, and eternal life in the world to come. 

# On what road were Jesus and the disciples traveling?

Jesus and the disciples were traveling on the road going up to Jerusalem. 

# What did Jesus tell his disciples would happen to him in Jerusalem?

Jesus told his disciples that he would be condemned to death, and after three days he would rise. 

# What did Jesus tell his disciples would happen to him in Jerusalem?

Jesus told his disciples that he would be condemned to death, and after three days he would rise. 

# What request did James and John make to Jesus?

James and John requested to sit on Jesus' right and left hand with him in glory. 

# What request did James and John make to Jesus?

James and John requested to sit on Jesus' right and left hand with him in glory. 

# What request did James and John make to Jesus?

James and John requested to sit on Jesus' right and left hand with him in glory. 

# What did Jesus say that James and John would endure?

Jesus said that James and John would endure the cup Jesus would drink, and the baptism with which Jesus would be baptized. 

# Did Jesus grant the request of James and John?

No, Jesus said that the seats at his right and left hand were not his to give. 

# How did Jesus say the rulers of the Gentiles treat their subjects?

Jesus said that the rulers of the Gentiles dominate their subjects. 

# How did Jesus say those who wish to be great among the disciples must live?

Jesus said those who wish to be great among the disciples must be servant of all. 

# How did Jesus say those who wish to be great among the disciples must live?

Jesus said those who wish to be great among the disciples must be servant of all. 

# What did the blind man Bartimaeus do when many rebuked him, telling him to be quiet?

Bartimaeus cried out all the more, "Son of David, have mercy on me!" 

# What did Jesus say had healed Bartimaeus of his blindness?

Jesus said that Bartimaeus' faith had healed him. 

# What did Jesus send two of his disciples to do in the village opposite them?

Jesus sent them to bring a colt to him that had never been ridden. 

# What happened when the disciples untied the colt?

Some people asked the disciples what they were doing, so they spoke to the people as Jesus told them, and the people let them go their way. 

# What happened when the disciples untied the colt?

Some people asked the disciples what they were doing, so they spoke to the people as Jesus told them, and the people let them go their way. 

# What did the people spread on the road as Jesus rode on the colt?

The people spread their garments, and branches they had cut from the fields. 

# What coming kingdom were the people shouting about as Jesus rode toward Jerusalem?

The people were shouting that the kingdom of their father David was coming. 

# What did Jesus do when he entered the temple area?

Jesus looked around and then went out to Bethany. 

# What did Jesus do when he saw the fig tree with no fruit on it?

Jesus said to the fig tree, "No one will ever eat fruit from you". 

# What did Jesus do when he entered the temple area this time?

Jesus cast out the sellers and purchasers, and would not allow anyone to carry merchandise through the temple. 

# What did Jesus do when he entered the temple area this time?

Jesus cast out the sellers and purchasers, and would not allow anyone to carry merchandise through the temple. 

# What did Jesus say the temple was supposed to be, according to Scripture?

Jesus said that the temple was supposed to be a house of prayer for all the nations. 

# What did Jesus say the chief priests and scribes had made the temple?

Jesus said they had made the temple a den of robbers. 

# What were the chief priests and scribes trying to do to Jesus?

The chief priests and scribes were trying to kill Jesus. 

# What happened to the fig tree to which Jesus had spoken?

The fig tree to which Jesus had spoken withered away to its roots. 

# What did Jesus say about everything we ask for in prayer?

Jesus said that everything we ask for in prayer, believe that we have received it, and it will be ours. 

# What did Jesus say we must do so that the Father in heaven will also forgive you?

Jesus said we must forgive whatever we have against anyone, so that the Father will also forgive us. 

# In the temple, what did the chief priests, scribes, and elders want to know from Jesus?

They wanted to know by what authority he did the things he was doing. 

# In the temple, what did the chief priests, scribes, and elders want to know from Jesus?

They wanted to know by what authority he did the things he was doing. 

# What question did Jesus ask the chief priests, scribes, and elders?

Jesus asked them if John's baptism was from heaven or from men. 

# Why did the chief priests, scribes, and elders not want to answer that John's baptism was from heaven?

They did not want to give this answer because Jesus would ask why they didn't believe John. 

# Why did the chief priests, scribes, and elders not want to answer that John's baptism was from men?

They did not want to give this answer because they feared the people, who all believed that John was a prophet. 

# After building and leasing the vineyard, what did the owner do?

After building and leasing the vineyard, the owner went away on a journey. 

# What did the vine dressers do to the many servants that the owner sent to receive the fruit of the vineyard?

The vine dressers beat some and killed some of the many servants. 

# Who did the owner send last to the vine dressers?

The owner sent his beloved son last. 

# What did the vine dressers do with the one sent last by the owner?

The vine dressers seized him, killed him, and threw him out of the vineyard. 

# What will the owner of the vineyard do to the vine dressers?

The owner of the vineyard will come and destroy the vine dressers and give the vineyard to others. 

# In the scripture, what happens to the stone which the builders rejected?

The stone which the builders rejected has been made the cornerstone. 

# What question did the Pharisees and some of the Herodians ask Jesus?

They asked him if it was lawful to pay taxes to Caesar or not. 

# How did Jesus answer their question?

Jesus said they should give to Caesar the things that are Caesar's, and to God, the things that are God's. 

# In what did the Sadducees not believe?

The Sadducees did not believe in the resurrection. 

# In the story told by the Sadducees, how many husbands did the woman have?

The woman had seven husbands. 

# What question did the Sadducees ask Jesus about the woman?

They asked which of the men would be the woman's husband in the resurrection. 

# What reason did Jesus give the Sadducees for their error?

Jesus said that the Sadducees did not know the scriptures nor the power of God. 

# What was Jesus' answer to the Sadducees' question about the woman?

Jesus said that in the resurrection, men and women will not marry, but will be like angels. 

# How did Jesus show from the scriptures that there is a resurrection?

Jesus quoted from the book of Moses, where God says that he is the God of Abraham, Isaac, and Jacob - all who must then be still alive. 

# How did Jesus show from the scriptures that there is a resurrection?

Jesus quoted from the book of Moses, where God says that he is the God of Abraham, Isaac, and Jacob - all who must then be still alive. 

# What commandment did Jesus say is most important?

Jesus said that to love the Lord your God with all your heart, soul, mind, and strength is the most important commandment. 

# What commandment did Jesus say is most important?

Jesus said that to love the Lord your God with all your heart, soul, mind, and strength is the most important commandment. 

# What commandment did Jesus say is second?

Jesus said that to love your neighbor as yourself is the second commandment. 

# What question did Jesus ask the scribes about David?

Jesus asked how David could call the Christ Lord when the Christ is the son of David. 

# What question did Jesus ask the scribes about David?

Jesus asked how David could call the Christ Lord when the Christ is the son of David. 

# What question did Jesus ask the scribes about David?

Jesus asked how David could call the Christ Lord when the Christ is the son of David. 

# What did Jesus tell the people to beware of concerning the scribes?

Jesus said that the scribes desire to be honored by men, but they devour widows' houses, and make long prayers for people to see. 

# What did Jesus tell the people to beware of concerning the scribes?

Jesus said that the scribes desire to be honored by men, but they devour widows' houses, and make long prayers for people to see. 

# What did Jesus tell the people to beware of concerning the scribes?

Jesus said that the scribes desire to be honored by men, but they devour widows' houses, and make long prayers for people to see. 

# Why did Jesus say that the poor widow had put in more than all who contributed to the offering box?

Jesus said she had contributed more because she gave out of her poverty while the others gave out of their abundance. 

# What did Jesus say would happen to the wonderful stones and buildings of the temple?

Jesus said that not one stone would be left on another which would not be torn down. 

# What question did the disciples then ask Jesus?

The disciples asked Jesus when these things would happen and what would be the sign. 

# About what did Jesus say the disciples must be careful?

Jesus said the disciples must be careful that no one lead them astray. 

# About what did Jesus say the disciples must be careful?

Jesus said the disciples must be careful that no one lead them astray. 

# What did Jesus say would be the beginnings of birth pains?

Jesus said the beginning of birth pains would be wars, rumors of wars, earthquakes, and famines. 

# What did Jesus say would be the beginnings of birth pains?

Jesus said the beginning of birth pains would be wars, rumors of wars, earthquakes, and famines. 

# What did Jesus say would happen to the disciples?

Jesus said that the disciples would be delivered to councils, beaten in synagogues, and would stand before governors and kings as a testimony. 

# What did Jesus say must happen first?

Jesus said the gospel must be preached to all the nations first. 

# What did Jesus say would happen between family members?

Jesus said that one family member would deliver up another family member to death. 

# Who did Jesus say would be saved?

Jesus said that whoever endures to the end would be saved. 

# What did Jesus say those in Judea should do when they see the abomination of desolation?

Jesus said that those in Judea should flee to the mountains when they see the abomination of desolation. 

# What did Jesus say the Lord would do for the sake of the elect, so that they would be saved?

Jesus said the Lord would shorten the days of tribulation for the sake of the elect. 

# Who did Jesus say would arise to deceive people?

Jesus said that false Christs and false prophets would arise to deceive people. 

# What will happen to the powers in the heavens after the tribulation of those days?

The sun and moon will be darkened, the stars will fall from the sky, and the powers in the heavens will be shaken. 

# What will happen to the powers in the heavens after the tribulation of those days?

The sun and moon will be darkened, the stars will fall from the sky, and the powers in the heavens will be shaken. 

# What will the people see in the clouds?

They will see the Son of Man coming in the clouds with great power and glory. 

# What will the Son of Man do when he comes?

The Son of Man will gather his elect from the ends of the earth and the sky. 

# What did Jesus say would not pass away until all of these things occurred?

Jesus said that this generation would not pass away until all of these things occurred. 

# What did Jesus say would never pass away?

Jesus said that his words would never pass away. 

# When did Jesus say all these things would happen?

Jesus said that no one knows the day or hour, except the Father. 

# What command did Jesus give his disciples regarding his coming?

Jesus told his disciples to be alert and watch. 

# What command did Jesus give his disciples regarding his coming?

Jesus told his disciples to be alert and watch. 

# What command did Jesus give his disciples regarding his coming?

Jesus told his disciples to be alert and watch. 

# What were the chief priests and scribes considering how to do?

They were considering how to stealthily arrest Jesus and then kill him. 

# Why did the chief priests and scribes not want to act during the Feast of Unleavened Bread?

They were worried that a riot would arise among the people. 

# What did a woman do to Jesus at the house of Simon the leper?

A woman broke a vial of costly liquid and poured it on Jesus' head. 

# For what were some rebuking the woman?

Some were rebuking the woman for not selling the perfume and giving the money to the poor. 

# What did Jesus say the woman had done for him?

Jesus said the woman had anointed his body for burial. 

# What promise did Jesus make about what the woman had done?

Jesus promised that wherever the gospel was preached in the whole world, what the woman had done would be spoken of in memory of her. 

# Why did Judas Iscariot go away to the chief priests?

Judas Iscariot went away to the chief priests so that he might deliver Jesus to them. 

# How did the disciples find the place where they would all eat the Passover?

Jesus told them to go into the city and follow a man carrying a pitcher of water, and then ask him where the guest room was that they would use to eat the Passover. 

# How did the disciples find the place where they would all eat the Passover?

Jesus told them to go into the city and follow a man carrying a pitcher of water, and then ask him where the guest room was that they would use to eat the Passover. 

# How did the disciples find the place where they would all eat the Passover?

Jesus told them to go into the city and follow a man carrying a pitcher of water, and then ask him where the guest room was that they would use to eat the Passover. 

# What did Jesus say as they were reclining at the table and eating?

Jesus said that one of the disciples eating with him would betray him. 

# Which disciple did Jesus say would betray him?

Jesus said that the disciple dipping bread with him in the bowl would betray him. 

# What did Jesus say about the destiny of the disciple who betrayed him?

Jesus said that it would have been better for him if he had not been born. 

# What did Jesus say as he gave the disciples the broken bread?

Jesus said, "Take this. This is my body". 

# What did Jesus say as he gave the disciples the cup?

Jesus said, "This is my blood of the covenant, the blood that is poured out for many". 

# When did Jesus say he would again drink of this fruit of the vine?

Jesus said he would again drink of this fruit of the vine on the day when he drank it anew in the kingdom of God. 

# At the Mount of Olives, what did Jesus predict about his disciples?

Jesus predicted that his disciples would all fall away because of him. 

# What did Jesus tell Peter after Peter said he would never fall away?

Jesus told Peter that before the rooster crowed twice, Peter would deny Jesus three times. 

# What did Jesus tell his three disciples to do while he prayed?

Jesus told them to remain there and watch. 

# What did Jesus tell his three disciples to do while he prayed?

Jesus told them to remain there and watch. 

# What did Jesus tell his three disciples to do while he prayed?

Jesus told them to remain there and watch. 

# For what did Jesus pray?

Jesus prayed that this hour might pass from him. 

# What was Jesus willing to accept as an answer to his prayer to the Father?

Jesus was willing to accept whatever the Father's will was for him. 

# What did Jesus find when he returned to the three disciples?

Jesus found the three disciples sleeping. 

# What did Jesus find the second time he returned from praying?

Jesus found the three disciples sleeping. 

# What did Jesus find the third time he returned from praying?

Jesus found the three disciples sleeping. 

# What sign did Judas give to show the guards which person was Jesus?

Judas kissed Jesus to show which person was Jesus. 

# What sign did Judas give to show the guards which person was Jesus?

Judas kissed Jesus to show which person was Jesus. 

# What did Jesus say was being done in his arrest to fulfill scripture?

Jesus said that scripture was being fulfilled because they came to arrest him like a robber, with swords and clubs. 

# What did Jesus say was being done in his arrest to fulfill scripture?

Jesus said that scripture was being fulfilled because they came to arrest him like a robber, with swords and clubs. 

# What did those with Jesus do when Jesus was arrested?

Those with Jesus left him and fled. 

# What did a young man who was following Jesus do when Jesus was arrested?

The young man left his linen garment there and ran away naked. 

# What did a young man who was following Jesus do when Jesus was arrested?

The young man left his linen garment there and ran away naked. 

# Where was Peter as Jesus was taken to the high priest?

Peter sat among the guards, near a fire to keep warm. 

# Where was Peter as Jesus was taken to the high priest?

Peter sat among the guards, near a fire to keep warm. 

# What was wrong with the testimony against Jesus given to the Council?

The testimony against Jesus was false and did not agree. 

# What was wrong with the testimony against Jesus given to the Council?

The testimony against Jesus was false and did not agree. 

# What question did the high priest ask Jesus about who Jesus was?

The high priest asked Jesus if he was the Christ, the son of the Blessed. 

# What was Jesus' answer to the high priest's question?

Jesus answered that he was the Christ, the son of the Blessed. 

# Hearing Jesus' answer, of what did the high priest say Jesus was guilty?

The high priest said that Jesus was guilty of blasphemy. 

# What did they do to Jesus after condemning him as one who deserved death?

They spit on him, struck him, and beat him. 

# What was Peter's answer to the servant girl who said that Peter was with Jesus?

Peter answered that he did not know or understand about what the girl was talking. 

# What was Peter's answer to the servant girl who said that Peter was with Jesus?

Peter answered that he did not know or understand about what the girl was talking. 

# What was Peter's answer to the servant girl who said that Peter was with Jesus?

Peter answered that he did not know or understand about what the girl was talking. 

# What was Peter's response when he was asked a third time if he was one of Jesus' disciples?

Peter swore and put himself under curses that he did not know Jesus. 

# What happened after Peter answered the third time?

After Peter answered the third time, the rooster crowed a second time. 

# What did Peter do after he heard the rooster?

After he heard the rooster, Peter broke down and wept. 

# Early in the morning, what did the chief priests do with Jesus?

Early in the morning, they bound Jesus and handed him over to Pilate. 

# While the chief priests were presenting many charges against Jesus, what amazed Pilate about Jesus?

Pilate was amazed that Jesus no longer answered him. 

# What did Pilate usually do for the crowd at the time of the feast?

Pilate usually released to the crowd one prisoner they requested at the time of the feast. 

# Why did Pilate want to release Jesus to the crowd?

Pilate knew that it was because of envy that the chief priests had handed Jesus over to him. 

# Who did the crowd cry out to be released?

The crowd cried out for Barabbas to be released. 

# What did the crowd say should be done with the King of the Jews?

The crowd said that the King of the Jews should be crucified. 

# What did the crowd say should be done with the King of the Jews?

The crowd said that the King of the Jews should be crucified. 

# How did the cohort of soldiers dress Jesus?

The soldiers put a purple robe on Jesus and put on him a twisted crown of thorns. 

# Who carried Jesus' cross?

A passerby, Simon of Cyrene, was forced to carry Jesus' cross. 

# What was the name of the place where the soldiers brought Jesus to crucify him?

The name of the place was Golgotha, which means Place of a Skull. 

# What did the soldiers do with Jesus' garments?

The soldiers cast lots for Jesus' garments. 

# What charge against Jesus did the soldiers write on the sign?

The soldiers wrote "The King of the Jews" on the sign. 

# What did those who passed by challenge Jesus to do?

Those who passed by challenged Jesus to save himself and get down from the cross. 

# What did those who passed by challenge Jesus to do?

Those who passed by challenged Jesus to save himself and get down from the cross. 

# What did the chief priests say Jesus should do so they would believe?

The chief priests said that Jesus should come down from the cross so they would believe. 

# What did the chief priests say Jesus should do so they would believe?

The chief priests said that Jesus should come down from the cross so they would believe. 

# What titles did the chief priests use for Jesus as they mocked him?

The chief priests called Jesus the Christ and the King of Israel. 

# What happened at the sixth hour?

At the sixth hour, darkness came over the whole land. 

# What did Jesus cry out at the ninth hour?

Jesus cried out, "My God, my God, why have you forsaken me?" 

# What did Jesus do before he died?

Jesus cried out with a loud voice before he died. 

# What happened in the temple when Jesus died?

The curtain of the temple was split in two from top to bottom when Jesus died. 

# What did the centurion testify when he saw how Jesus died?

The centurion testified that truly this man was the Son of God. 

# On what day did Jesus die?

Jesus died on the day before the Sabbath. 

# What did Joseph of Arimathea do after Jesus died?

Joseph of Arimathea took Jesus down from the cross, wrapped him in linen cloth, and laid him in a tomb, rolling a stone against the entrance of the tomb. 

# When did the women go to Jesus' tomb to anoint his body?

The women went to the tomb on the first day of the week when the sun came up. 

# How did the women enter the tomb even though there had been a very large stone at the entrance?

Someone had rolled away the very large stone from the entrance. 

# What did the women see when they entered the tomb?

The women saw a young man dressed in a white robe sitting on the right side. 

# What did the young man say about Jesus?

The young man said that Jesus was risen and was not there. 

# Where did the young man say the disciples would meet Jesus?

The young man said the disciples would meet Jesus in Galilee. 

# To whom did Jesus first appear after his resurrection?

Jesus first appeared to Mary Magdalene. 

# How did Jesus' disciples respond when Mary told them she had seen Jesus alive?

The disciples did not believe. 

# How did Jesus' disciples respond when two other people told them they had seen Jesus alive?

The disciples did not believe. 

# When he appeared to the disciples, what did Jesus say to them about their unbelief?

Jesus rebuked the disciples for their unbelief. 

# What command did Jesus give the disciples?

Jesus commanded the disciples to go into all the world and preach the gospel. 

# Who did Jesus say would be saved?

Jesus said those who believed and were baptized would be saved. 

# Who did Jesus say would be condemned?

Jesus said those who did not believe would be condemned. 

# What signs did Jesus say would go with those who believed?

Jesus said those who believed would cast out demons, would speak in new languages, would not be hurt by anything deadly, and would heal others. 

# What signs did Jesus say would go with those who believed?

Jesus said those who believed would cast out demons, would speak in new languages, would not be hurt by anything deadly, and would heal others. 

# What happened to Jesus after he spoke to the disciples?

After he spoke to the disciples, Jesus was taken up into heaven and sat down at the right hand of God. 

# What did the disciples then do?

The disciples then left and preached everywhere. 

# What did the Lord then do?

The Lord then worked with the disciples and confirmed the word with miraculous signs. 

