# What question does Habakkuk ask Yahweh as he begins his pronouncement?

Habakkuk asks why Yahweh has not heard or saved him, even though he has cried for help. 

# What is Habakkuk being made to see?

Habakkuk is being made to see iniquity, wrongdoing, destruction, violence, strife, and contention. 

# What kind of justice is going forth?

False justice is going forth. 

# What does Yahweh tell Habakkuk that he will see in his days?

Yahweh says that Habakkuk will see the Chaldeans march through the land to seize dwellings. 

# What kind of people are the Chaldeans?

The Chaldeans are terrifying and fearsome. 

# What do the Chaldeans gather with violence?

The Chaldeans gather captives like sand with violence. 

# What is the Chaldeans' attitude toward other kings and rulers?

The Chaldeans mock other kings and rulers. 

# Who has ordained that the Chaldeans come and bring judgment?

Yahweh has ordained that the Chaldeans come and bring judgment. 

# What titles does Habakkuk use for Yahweh?

Habakkuk uses the titles "my God," "Holy One," and "Rock" for Yahweh. 

# What question or complaint does Habakkuk make to Yahweh?

Habakkuk asks Yahweh why he is silent while the wicked swallow up those more righteous. 

# About what are those who are slaughtering the nations rejoicing?

They are rejoicing as they gather and drag men away. 

# What occupation does Habakkuk say is like the gathering of men for judgment?

Habakkuk says the gathering of men for judgment is like gathering in fishnets. 

# What emotion do those who are slaughtering the nations lack?

Those slaughtering the nations lack compassion. 

# For what was Habakkuk watching carefully?

Habakkuk was watching carefully to see what Yahweh would say to him. 

# What did Yahweh tell Habakkuk to do with the vision?

Yahweh told Habakkuk to record the vision upon tablets. 

# What assurance did Yahweh give Habakkuk about this vision concerning the future?

Yahweh assured Habakkuk that this vision would speak even though it delays. 

# How did Yahweh say the righteous will live?

Yahweh said the righteous will live by his faith. 

# What three things does Yahweh say are never satisfied?

Yahweh says the arrogant young man's desire, the grave, and death are never satisfied. 

# What does Yahweh say will happen to the arrogant young man who plundered many nations?

Yahweh says the arrogant young man will be plundered by the remnant of the peoples. 

# Against whom does Yahweh declare a woe first?

Yahweh declares a woe against the one who carves out evil gains for his house. 

# What does Yahweh say will cry out because of the shame and sin?

Yahweh says the stones will cry out because of the shame and sin. 

# Against whom does Yahweh declare a woe second?

Yahweh declares a woe against the one who builds a city with blood and iniquity. 

# What does Yahweh promise will happen with the land in the future?

Yahweh promises that the land will be filled with the knowledge of the glory of Yahweh. 

# Against whom does Yahweh declare a woe third?

Yahweh declares a woe against the one making his neighbor drink poison to look on their nakedness. 

# What will come in its turn to the one making his neighbor drink poison?

The cup of Yahweh's right hand will come in its turn to the one making his neighbor drink poison. 

# In what is the maker of a carved figure placing his trust?

He is placing his trust in his own handiwork when he makes these mute gods. 

# What must be done before Yahweh, who is in his holy temple?

All must be silent before Yahweh in his holy temple. 

# Having heard Yahweh's report, what is Habakkuk's emotional response?

Having heard Yahweh's report, Habakkuk is afraid. 

# What does Habakkuk ask Yahweh to remember?

Habakkuk asks Yahweh to remember compassion in his wrath. 

# When God came, what went before and after him?

When God came, pestilence went before him and plague after him. 

# What did Yahweh do to the nations in his wrath?

Yahweh shook the nations. 

# Why did Yahweh go forth in his indignation?

Yahweh went forth in his indignation for the salvation of his people and his anointed one. 

# Who does Yahweh shatter in his indignation?

Yahweh shatters the head of the house of the wicked. 

# What did the wicked warriors do when they came to scatter Yahweh's people?

The warriors gloated over Yahweh's people. 

# For what is Habakkuk waiting quietly?

Habakkuk is waiting quietly for the day of distress to come upon the people who invaded Yahweh's people. 

# What hardships are the people of Yahweh suffering?

The fig and olive trees are not producing, the fields yield no food, and there is no livestock. 

# Despite the hardship, what will Habakkuk do?

Despite the hardship, Habakkuk will exult in Yahweh. 

# To where does Yahweh lead Habakkuk?

Yahweh leads Habakkuk to high places. 

