# By whom did the word of Yahweh come to Israel?

The word of Yahweh came by Malachi. 

# Whom did Yahweh love, and whom did he hate?

Yahweh loved Israel, Jacob, and he hated Esau. 

# Whom did Yahweh love, and whom did he hate?

Yahweh loved Israel, Jacob, and he hated Esau. 

# How would Israel respond when Yahweh would throw down the rebuilt ruins of Edom?

Israel would respond by saying, "Great is Yahweh beyond the borders of Israel". 

# How would Israel respond when Yahweh would throw down the rebuilt ruins of Edom?

Israel would respond by saying, "Great is Yahweh beyond the borders of Israel". 

# As Israel's father and master, what did Yahweh ask the priests?

Yahweh asked the priests where was the honor and reverence due his name, and why they despised his name and his table. 

# As Israel's father and master, what did Yahweh ask the priests?

Yahweh asked the priests where was the honor and reverence due his name, and why they despised his name and his table. 

# How would Yahweh respond to offerings of blind, lame, and sick animals?

Yahweh would not accept blind, lame, and sick offerings, nor show favor or graciousness to Israel for them, nor receive Israel for offering them. 

# How would Yahweh respond to offerings of blind, lame, and sick animals?

Yahweh would not accept blind, lame, and sick offerings, nor show favor or graciousness to Israel for them, nor receive Israel for offering them. 

# Why would Yahweh prefer that one of the Israelites shut the temple gates to prevent them from lighting fires on his altar in vain?

Because Yahweh's name was going to be glorified among the nations, and in every place the nations were going to offer pure offerings unlike the offerings from the hands of the Israelites. 

# Why would Yahweh prefer that one of the Israelites shut the temple gates to prevent them from lighting fires on his altar in vain?

Because Yahweh's name was going to be glorified among the nations, and in every place the nations were going to offer pure offerings unlike the offerings from the hands of the Israelites. 

# How did the priests regard the service of Yahweh?

They regarded it as tiresome, and they disdainfully snorted at it. 

# Why did the Lord curse the deceiver who vowed to sacrifice a male animal in his flock and instead gave a flawed animal?

Because Yahweh is a great King, and his name is feared among the nations. 

# By what would the priests know that Yahweh had commanded them to take it to heart to give glory to his name?

They would know by the curse of Yahweh on their blessings, and by him spreading dung on their faces. 

# By what would the priests know that Yahweh had commanded them to take it to heart to give glory to his name?

They would know by the curse of Yahweh on their blessings, and by him spreading dung on their faces. 

# Why did Levi honor Yahweh, stand in awe of Yahweh's name, have true teaching in his mouth rather than unrighteousness, walk with Yahweh in peace and uprightness, and turn many away from sin?

Because the priest should guard knowledge as the messenger of Yahweh. 

# How did the priests corrupt the covenant of Levi and not keep Yahweh's ways?

The priests did so by showing partiality in their instruction. 

# How did the priests corrupt the covenant of Levi and not keep Yahweh's ways?

The priests did so by showing partiality in their instruction. 

# Who would Yahweh cut off from the tents of Jacob?

Yahweh would cut off any man who dealt treacherously against his brother or who married the daughter of a foreign god, and then brought an offering to Yahweh. 

# Who would Yahweh cut off from the tents of Jacob?

Yahweh would cut off any man who dealt treacherously against his brother or who married the daughter of a foreign god, and then brought an offering to Yahweh. 

# Who would Yahweh cut off from the tents of Jacob?

Yahweh would cut off any man who dealt treacherously against his brother or who married the daughter of a foreign god, and then brought an offering to Yahweh. 

# Why did Yahweh not accept Israel's offerings?

Because Israel had been faithless against the wife of his youth. 

# Why did Yahweh not accept Israel's offerings?

Because Israel had been faithless against the wife of his youth. 

# Why did Yahweh command the Israelites to guard themselves in their spirit and not be faithless?

Because Yahweh had made Israel and his wife one in order to have godly offspring, and because Yahweh hated divorce and him who covers his garment with violence. 

# Why did Yahweh command the Israelites to guard themselves in their spirit and not be faithless?

Because Yahweh had made Israel and his wife one in order to have godly offspring, and because Yahweh hated divorce and him who covers his garment with violence. 

# How did the Israelites weary Yahweh with their words?

They wearied Yahweh with their words by saying that he who does evil is good in Yahweh's sight and he delights in them, and by asking where the God of justice was. 

# What would happen after Yahweh sent his messenger of the covenant who would prepare his way?

The Lord, whom Israel sought, would suddenly come to his temple. 

# When would the offering of Judah and Jerusalem be pleasing to Yahweh?

It would be pleasing after the purification of the sons of Levi, when they were refined like gold and silver. 

# After the offerings of Judah and Jerusalem were pleasing to Yahweh through the purification of Levi's sons, would would Yahweh do?

He would draw near to Israel for judgment and be a swift witness against those who did not honor him. 

# After the offerings of Judah and Jerusalem were pleasing to Yahweh through the purification of Levi's sons, would would Yahweh do?

He would draw near to Israel for judgment and be a swift witness against those who did not honor him. 

# Even though the people of Jacob had turned aside from Yahweh's ordinances, why had they not been consumed?

They had not been consumed because Yahweh does not change. 

# Even though the people of Jacob had turned aside from Yahweh's ordinances, why had they not been consumed?

They had not been consumed because Yahweh does not change. 

# How had Israel turned away from Yahweh?

They had turned away by not keeping his ordinances. 

# How had Israel robbed God?

They had robbed God in tithes and offerings. 

# What did Yahweh promise would happen if Israel brought the full tithe into the storehouse?

Yahweh promised that he would rebuke the one who devours you, and that all the nations would call Israel blessed. 

# What did Yahweh promise would happen if Israel brought the full tithe into the storehouse?

Yahweh promised that he would rebuke the one who devours you, and that all the nations would call Israel blessed. 

# What did Yahweh promise would happen if Israel brought the full tithe into the storehouse?

Yahweh promised that he would rebuke the one who devours you, and that all the nations would call Israel blessed. 

# How had the Israelites spoken against Yahweh?

They had said that serving God is pointless because the arrogant and evildoers prosper even when they tempt him. 

# How had the Israelites spoken against Yahweh?

They had said that serving God is pointless because the arrogant and evildoers prosper even when they tempt him. 

# How had the Israelites spoken against Yahweh?

They had said that serving God is pointless because the arrogant and evildoers prosper even when they tempt him. 

# Who did Yahweh say would belong to him and be spared?

Yahweh said that those who feared Yahweh and esteemed his name would belong to him and be spared. 

# On the day that Yahweh would act, what would happen?

The Israelites would again distinguish between the righteous and the wicked, and between one who worships God and one who does not worship him. 

# On the day that Yahweh would act, what would happen?

The Israelites would again distinguish between the righteous and the wicked, and between one who worships God and one who does not worship him. 

# On the day that was coming, burning like a furnace, what would happen to the proud and evildoers?

The proud and evildoers would become stubble, being burnt up. 

# On the day that was coming, burning like a furnace, what would happen to the proud and evildoers?

The proud and evildoers would become stubble, being burnt up. 

# For whom would the sun of righteousness rise?

The sun of righteousness would rise for those who feared Yahweh's name. 

# What would those who feared Yahweh's name do on the day that Yahweh acted?

They would go out leaping like calves from the stall and tread down the wicked. 

# What would those who feared Yahweh's name do on the day that Yahweh acted?

They would go out leaping like calves from the stall and tread down the wicked. 

# What did Yahweh command all Israel to do?

He commanded them to obey the law of his servant Moses. 

# What would Yahweh do before the day of Yahweh?

He would send Elijah to turn the heart of the fathers to the children, and the heart of the children to their fathers, so that Yahweh would not curse the land. 

# What would Yahweh do before the day of Yahweh?

He would send Elijah to turn the heart of the fathers to the children, and the heart of the children to their fathers, so that Yahweh would not curse the land. 

