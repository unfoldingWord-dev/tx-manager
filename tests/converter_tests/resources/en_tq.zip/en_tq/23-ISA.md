# Who was Isaiah?

Isaiah was the son of Amoz. 

# What was Isaiah's vision about?

Isaiah's vision was about Judah and Jerusalem. 

# When did Isaiah have his vision?

Isaiah had his vision in the days of Uzziah, Jotham, Ahaz, and Hezekiah, kings of Judah. 

# Why should the heavens hear and the earth listen?

The heavens should hear and the earth should listen because Yahweh has spoken. 

# What has Yahweh done?

He has nourished and brought up children 

# What have Yahweh's children done?

They have rebelled against Yahweh 

# How is the nation described?

They are described as sinners, people full of iniquity, offspring of evil doers and sons that act corruptly. 

# What has the nation done?

They have abandoned Yahweh, estranging themselves from and despising the Holy One of Israel 

# What is the condition of their country and cities?

Their country is desolate and their cities are burned 

# What has Yahweh left them?

He has left them a very small remnant. 

# What does not delight Yahweh?

He does not delight in the blood of bullocks, lambs and male goats. 

# What does Yahweh hate?

He hates their new moons and appointed feasts 

# Why will Yahweh not hear their prayers?

He will not hear because their hands are full of blood. 

# What does Yahweh tell them to do?

Yahweh tells them to stop being evil; learn to do good; seek justice, help the oppressed, give justice to the fatherless and defend the widow. 

# What does Yahweh tell them to do?

Yahweh tells them to stop being evil; learn to do good; seek justice, help the oppressed, give justice to the fatherless and defend the widow. 

# What must they do to eat the good of the land?

They must be willing and obedient. 

# What will happen if they refuse and rebel?

The sword will devour them 

# What was the faithful city like before she became a prostitute?

The faithful city was full of justice and righteousness. 

# What did the faithful city become full of?

The faithful city became full of murderers. 

# What will Yahweh do?

He will take vengeance against his adversaries. 

# What will make them ashamed and embarrassed?

They will be ashamed of the sacred oak trees they desired and embarrassed by the gardens they have chosen 

# What will happen to the strong man and his work?

They will both burn together 

# What did the word that Isaiah saw concern?

The word Isaiah saw concerned Judah and Jerusalem. 

# What will happen in the latter days?

In the latter days the mountain of Yahweh's house will be established. 

# Who will come into Yahweh's house?

All nations will flow to it. 

# Why will many people go up to the mountain of Yahweh?

They will go up to be taught some of Yahweh's ways. 

# What will Yahweh do for the nations and many peoples?

Yahweh will judge them and render decisions. 

# What will the nations not do?

They will not lift up the sword against one another or train for war. 

# What is the house of Jacob told to do?

They are told to walk in the light of Yahweh. 

# What has Yahweh done?

He has abandoned his people, the house of Jacob. 

# Why has Yahweh abandoned the house of Jacob?

He has abandoned them because they are filled with customs from the east and are omen readers like the Philistines, and they shake hands with sons of foreigners. 

# Why should the house of Jacob enter into the rocky places and hide in the dust?

They should hide because of the terror of Yahweh and the glory of his majesty. 

# What will happen to the lofty gaze and pride of men?

They will be brought low and brought down. 

# Who will be exalted on that day?

Yahweh alone will be exalted on that day. 

# What will happen to the idols?

They will completely pass away. 

# Where will men go on that day?

They will go into caves of the rocks and holes of the ground. 

# Who is the house of Jacob told to stop trusting?

They are told to stop trusting in man. 

# What is Yahweh about to take away from Jerusalem and Judah?

Yahweh is about to take away their support and staff. 

# Who will lead Judah and Jerusalem?

Youths will lead them and the young will rule over them. 

# Who will oppress the people?

The people will be oppressed by each other and everyone by his neighbor. 

# Why is Jerusalem ruined and Judah fallen?

They are ruined and fallen because their speech and actions are against Yahweh. 

# What witnesses against Judah and Jerusalem?

The look on their faces witnesses against them. 

# What will happen to the righteous?

It will be well with the righteous. 

# What will happen to the wicked?

It will go badly for the wicked. 

# Where do their leaders lead them?

Their leaders lead them astray and confuse the direction of their path. 

# What will Yahweh do to the elders and officials of his people?

Yahweh will pronounce judgment on them. 

# What will the Lord, Yahweh do to the daughters of Zion?

Yahweh will form diseased scabs on their heads and make them bald. 

# What will happen to the men?

The men will fall by the sword 

# Why will seven women take hold of one man?

They will want to take his name and remove their shame. 

# What will those survivors left in Zion and Jerusalem be called?

The survivors who are left in Zion and Jerusalem will be called holy. 

# What will the Lord do by the spirit of justice and by the spirit of burning fire?

The Lord will wash away the filth of the daughters of Zion and cleanse the blood stains from Jerusalem's midst. 

# What will Yahweh create over the whole site of Mount Zion and over her place of assembly?

He will create a cloud and smoke by day and the shining of a flaming fire by night; a canopy over all the glory 

# For whom does the singer want to sing?

The singer wants to sing for his beloved 

# What is the song of the singer about?

The song is about the vineyard of his beloved. 

# What did he do to the vineyard?

He spaded it, removed the stones, planted it with the choicest vine, and built a tower and a winepress in it. 

# What did the vineyard bring forth?

The vineyard brought forth wild grapes. 

# What are the inhabitants of Jerusalem and the men of Judah to judge?

They are to judge between the beloved and his vineyard. 

# What will the beloved do to his vineyard?

He will remove the hedge, turn the vineyard into a pasture, and break down its wall so it will be laid waste and no rain will fall on it. 

# What will the beloved do to his vineyard?

He will remove the hedge, turn the vineyard into a pasture, and break down its wall so it will be laid waste and no rain will fall on it. 

# Who is the vineyard of Yahweh of Hosts?

Yahweh's vineyard is the house of Israel. 

# What did Yahweh wait for?

Yahweh waited for justice and righteousness. 

# What did Yahweh get instead of justice and righteousness?

Yahweh got killing and a cry for help. 

# What will happen to many houses?

Many houses will be empty and without inhabitant. 

# Why have the people of Israel and Judah gone into captivity?

They went into captivity because they lacked understanding. 

# What exalts Yahweh of Hosts?

Yahweh's justice exalts him 

# How is God the Holy one recognized?

God is recognized by his righteous dealings. 

# Why will Israel's root rot, and their blossom blow away like dust?

Israel's root will rot, and their blossom will blow away like dust because they have rejected the law of Yahweh and despised the word of the Holy One of Israel. 

# How will Yahweh call a far away nation to come?

He will call them by lifting up a signal flag and whistling for them. 

# How will that far away nation come?

That far away nation will come speedily and promptly. 

# When did Isaiah see the Lord sitting on a high and elevated throne?

Isaiah saw the Lord in the year that king Uzziah died. 

# Who was above the Lord?

The seraphim were above the Lord. 

# What happened when the seraphim called to each other?

When the seraphim called to each other, the doors and thresholds shook and the house was filled with smoke. 

# What did Isaiah say when he saw all these things?

Isaiah said he was doomed because he had unclean lips and lived among people with unclean lips and because he had seen the King, Yahweh. 

# What did the seraphim say when he touched Isaiah's lips with a coal from the altar?

He said, "See, this has touched your lips; your guilt has been taken away, and your sin atoned for." 

# What did Isaiah hear the Lord ask?

The Lord said, "Whom shall I send; who will go for us?" 

# How did Isaiah respond to what the Lord asked?

Isaiah said, "Here I am; send me." 

# What did the Lord tell Isaiah to tell the people?

The Lord told Isaiah to tell the people to listen but not to understand; to see, but not to perceive. 

# How long was Isaiah supposed to tell the Lord's message to the people?

Isaiah was to tell the people the Lord's message until the cities were in ruins without inhabitants and the houses were without people and the land fell into a desolate waste, and until Yahweh sent the people far away and the solitude of the land was great. 

# How long was Isaiah supposed to tell the Lord's message to the people?

Isaiah was to tell the people the Lord's message until the cities were in ruins without inhabitants and the houses were without people and the land fell into a desolate waste, and until Yahweh sent the people far away and the solitude of the land was great. 

# Who was Ahaz?

Ahaz was the son of Jotham, the son of Uzziah, a king of Judah. 

# During the days of Ahaz, which kings went up to Jerusalem in Judah to war against it?

Rezin the king of Syria and Pekah the son of Remaliah, king of Israel went up to war against Jerusalem. 

# How did Ahaz and his people react when they heard that Syria was allied with Ephraim?

The hearts of Ahaz and his people trembled when they heard this. 

# What task did Yahweh tell Isaiah to do?

Yahweh told Isaiah to go out with his son and meet Ahaz. 

# Who did Yahweh say Ahaz shouldn't be afraid of?

Yahweh's said Ahaz should not be afraid or intimidated by Rezin and Pekah. 

# Who did Yahweh say Ahaz shouldn't be afraid of?

Yahweh's said Ahaz should not be afraid or intimidated by Rezin and Pekah. 

# What did Aram, Ephraim and the son of Remaliah plan to do?

These men planned evil against Ahaz and Judah. They planned to attack and terrify Judah, and set up the son of Tabeel as king. 

# What did Aram, Ephraim and the son of Remaliah plan to do?

These men planned evil against Ahaz and Judah. They planned to attack and terrify Judah, and set up the son of Tabeel as king. 

# What did Yahweh tell Ahaz about Ephraim?

Yahweh told Ahaz, "Within sixty-five years, Ephraim will be shattered and will no longer be a people. 

# What does Yahweh tell Ahaz will happen if his faith isn't firm?

Ahaz will not remain secure unless his faith is firm. 

# What was Ahaz's response when the Lord told him to ask for a sign from Yahweh?

Ahab said, "I will not ask, nor will I test Yahweh." 

# What did Isaiah say Ahab was doing?

Isaiah said he was not only testing the patience of the people but he was also testing the patience of God. 

# Who did Isaiah tell Ahaz that Yahweh would bring against him?

Isaiah told Ahaz that Yahweh would bring the king of Assyria against him and his people. 

# What would the king of Assyria do?

The king of Assyria would shave Ahaz's head, legs and beard. 

# What would happen to the land?

The land would be filled with briers and thorns and it would be a place where sheep and cattle graze. 

# What would happen to the land?

The land would be filled with briers and thorns and it would be a place where sheep and cattle graze. 

# What would happen to the land?

The land would be filled with briers and thorns and it would be a place where sheep and cattle graze. 

# What did Yahweh tell Isaiah to do?

He told Isaiah to take a large tablet and write on it, 'Maher-shalal-hash-baz'. 

# Who were to be Yahweh's faithful witnesses?

Yahweh's witnesses were to be Uriah the priest and Zechariah the son of Jeberekiah. 

# Why did Yahweh tell Isaiah to name his son 'Maher-shalal-hash-baz'?

He was to be named 'Maher-shalal-hash-baz' because before he knew how to cry 'My father' and 'My mother,' the king of Assyria would come and carry away the riches of Damascus and the plunder of Samaria. 

# Why did Yahweh tell Isaiah to name his son 'Maher-shalal-hash-baz'?

He was to be named 'Maher-shalal-hash-baz' because before he knew how to cry 'My father' and 'My mother,' the king of Assyria would come and carry away the riches of Damascus and the plunder of Samaria. 

# In what specific ways of the people was Isaiah warned not to walk?

Isaiah was warned not to call conspiracy anything that people called conspiracy and not to fear what they feared or be in awe of those things. 

# Who was Isaiah told to treat as holy and to fear?

Isaiah was told to fear and be in awe of Yahweh of Hosts and to treat him as holy. 

# What was Yahweh going to be to both houses of Israel and to the inhabitants of Jerusalem?

He was going to be a stone that makes people trip and a rock that makes people stumble to Israel, and a trap and snare to the inhabitants of Jerusalem. 

# What was Isaiah's testimony that was to be given to his disciples?

Isaiah's testimony was that he would wait for Yahweh and that Isaiah and his sons were given by Yahweh for signs and wonders in Israel. 

# What was Isaiah's testimony that was to be given to his disciples?

Isaiah's testimony was that he would wait for Yahweh and that Isaiah and his sons were given by Yahweh for signs and wonders in Israel. 

# What was Isaiah's testimony that was to be given to his disciples?

Isaiah's testimony was that he would wait for Yahweh and that Isaiah and his sons were given by Yahweh for signs and wonders in Israel. 

# According to Isaiah what were the people of Israel going to tell Isaiah's disciples?

They were going to tell Isaiah's disciples to consult with the mediums and magicians. 

# Who does Isaiah say the people should consult?

The people should consult their God. 

# To what does Isaiah command his disciples to pay attention?

They are commanded to pay attention to the law and the testimony. 

# What will the people of Israel do when they are greatly distressed and hungry and become angry?

They will turn their faces upward and curse their king and their God. 

# What will happen to the people of Israel?

They will be driven into a land of darkness. 

# What will happen to the one who was in anguish?

Her gloom will be dispelled. 

# What lands did God humiliate in earlier times?

God humiliated the land of Zebulun and the land of Naphtali. 

# What will God do to Zebulun and Naphtali in the later time?

He will make them glorious. 

# On whom has the light shone?

The light has shone on those who have lived in the land of the shadow of death. 

# What is the name of the one who will bear the rule on his shoulder?

His name will be called Wonderful Counselor, Mighty God, Everlasting Father, and Prince of Peace. 

# How will he rule?

He will rule with justice and with righteousness. 

# How long will he rule?

He will rule from this time onward and for evermore. 

# What did Israel say in pride and with an arrogant heart?

Israel says, "The bricks have fallen, but we will rebuild with chiseled stone; the sycamores have been cut down, but we will put cedars in their place." 

# What did Israel say in pride and with an arrogant heart?

Israel says, "The bricks have fallen, but we will rebuild with chiseled stone; the sycamores have been cut down, but we will put cedars in their place." 

# Who did Yahweh raise up against Israel?

Yahweh raised up Rezin, the Arameans and the Philistines against Israel. 

# Who did Yahweh raise up against Israel?

Yahweh raised up Rezin, the Arameans and the Philistines against Israel. 

# After all this did Yahweh's anger subside?

No, Yahweh's anger didn't subside. His hand was still stretched out to strike Israel. 

# Did the people turn to Yahweh?

The people did not turn to Yahweh or seek him. 

# Who were the "head" and "tail" that Yahweh was going to cut off in one day?

The leader and the noble man were the head; and the prophet that teaches lies was the tail. 

# Why didn't the Lord have compassion on their fatherless and widows?

He didn't have compassion on them because everyone was a godless evildoer and every mouth spoke foolish things. 

# After all this did Yahweh's anger subside?

No, Yahweh's anger didn't subside. His hand was still stretched out to strike Israel. 

# What happened as a result of Yahweh's overflowing anger?

Yahweh caused the land to be scorched and the people to become like fuel for the fire. 

# What happened to Manasseh, Ephraim and Judah?

Manasseh and Ephraim devoured each other and they both attacked Judah. 

# After all this did Yahweh's anger subside?

No, Yahweh's anger didn't subside. His hand was still stretched out to strike Israel. 

# Who was the club of Yahweh's anger and the rod by whom Yahweh wielded his fury?

The Assyrian was the club of Yahweh's anger and the rod by whom he wielded his fury. 

# What did Yahweh order the Assyrian to do?

He ordered the Assyrian to take the spoil, take the prey and to trample Israel like mud in the streets. 

# What did the Assyrian intend?

It was in the Assyrian's heart to destroy and eliminate many nations. 

# What did the Lord say he would do when he finished his work on Mt. Zion and in Jerusalem?

The Lord said he would punish the speech of the arrogant heart of the king of Assyria and his prideful looks. 

# Why did the king of Assyria think he was successful?

The king of Assyria thought he was successful because of his strength, wisdom, and understanding. 

# What was the Lord God going to do among Assyria's elite warriors?

The Lord God was going to send emaciation among them. 

# What did Yahweh say he would consume in Assyria?

Yahweh said he would consumed the glory of his forest and of his fruitful land. 

# What would the remnant of Israel rely upon after they escape?

The remnant that escaped would no longer rely on him who struck them, but would indeed depend on Yahweh. 

# Why did the Lord God tell the people who lived in Zion not to fear the Assyrian?

He told them not to fear the Assyrian because in a very short time the Lord's anger against those in Zion would end and the Lord's anger would be toward Assyria's destruction. 

# Why did the Lord God tell the people who lived in Zion not to fear the Assyrian?

He told them not to fear the Assyrian because in a very short time the Lord's anger against those in Zion would end and the Lord's anger would be toward Assyria's destruction. 

# What was to happen on the day when Yahweh would wield his whip against Assyria and on the day Yahweh would raise his rod over the sea to lift it up?

On that day the burden would be lifted from their shoulder and the yoke from off their neck. 

# What was going to come from the root of Jesse?

A shoot and a branch was to come from the root of Jesse. 

# What was going to rest on him?

The Spirit of Yahweh was to rest on him. 

# What will the Spirit of Yahweh give him?

The Spirit of Yahweh will give him wisdom and understanding, counsel and might, knowledge, and the fear of Yahweh. 

# What standard will he use to judge the poor and humble?

He will not judge by what his eyes see or his ears hear. He will judge with righteousness and decide fairly. 

# What will he do to the wicked?

He will slay them with the breath of his lips. 

# How will the animals act differently?

They will not hurt nor destroy on all his holy mountain. 

# Why will the animals not hurt or destroy?

The animals will not hurt nor destroy because the earth will be full of the knowledge of Yahweh. 

# On that day why will the Lord extend his hand?

He will extend his hand to recover the remnant of his people who remain in Assyria, Egypt, Pathros, Cush, Elam, Shinar, Hamath, and the islands of the sea. 

# What will happen to those who are hostile to Judah?

Those who are hostile to Judah will be cut off. 

# What will happen between Ephraim and Judah?

Ephraim will not envy Judah, and Judah will no longer be hostile to Ephraim. 

# What will Ephraim and Judah do together?

They will swoop down on the Philistine hills on the west and plunder the people of the east. They will also attack Edom and Moab.. 

# What will Yahweh do to the gulf of the sea of Egypt and the Euphrates River?

Yahweh will divide the gulf of the sea of Egypt and will divide the Euphrates river into seven streams. 

# Why will Yahweh divide the gulf of the sea of Egypt and divide the Euphrates river?

He will divide them so it can be crossed over in Sandals. 

# On that day, why will they give thanks to Yahweh?

They will give thanks because although Yahweh was angry with them, he turned his wrath away from them and he comforted them. 

# On that day what will people say Yahweh is to them?

The people will say Yahweh is their strength, their song, and their salvation. 

# On that day what will people say Yahweh is to them?

The people will say Yahweh is their strength, their song, and their salvation. 

# Why will people be told to sing to Yahweh?

They will be told to sing to Yahweh for he has done glorious things and so that it will be known throughout the earth. 

# What message did Isaiah receive from Yahweh?

He received a declaration about Babylon. 

# What has Yahweh called his mighty men to do?

He has called them to execute his anger. 

# From where does Yahweh's army come?

They come from a far country, from way over the horizon. 

# What are Yahweh's instruments of judgement going to do?

They are going to destroy the whole land. 

# What will the people do when the land is destroyed?

Their hands will hang limp, and their hearts will melt; they will be terrified; pangs and sorrows will seize them. They will have looks of astonishment and their faces will be aflame. 

# What will the people do when the land is destroyed?

Their hands will hang limp, and their hearts will melt; they will be terrified; pangs and sorrows will seize them. They will have looks of astonishment and their faces will be aflame. 

# What else will happen during the day of Yahweh?

The land will be made desolate and the sinners will be destroyed from it. The stars, constellations, sun and moon will not give their light; they will be darkened. 

# What else will happen during the day of Yahweh?

The land will be made desolate and the sinners will be destroyed from it. The stars, constellations, sun and moon will not give their light; they will be darkened. 

# Will there be many men left?

No! Yahweh will make men more rare than fine gold. 

# Who is Yahweh going to stir up to attack the Babylonians?

Yahweh is going to stir up the Medes to attach the Babylonians. 

# What will happen to Babylon?

God will overthrow them like Sodom and Gomorrah and they will not be inhabited or lived in from generation to generation. 

# What will happen to Babylon?

God will overthrow them like Sodom and Gomorrah and they will not be inhabited or lived in from generation to generation. 

# What will lie in Babylon?

Wild animals of the desert will lie there. 

# When will these things happen to Babylon?

Babylon's time is near and her days will not be delayed. 

# What will Yahweh do to Israel?

Yahweh will again choose Israel and restore them into their own land. 

# Will anyone else go with the Israelites back to their land?

Foreigners will join with them and attach themselves to the house of Jacob. 

# Who will bring the Israelites back to their own land?

The nations will bring them to their own place. 

# What will the house of Israel do to those nations that took Israel captive?

The house of Israel will take them as male and female servants. They will take captive those who had captured them and they will rule over their oppressors. 

# What will happen on the day that Yahweh gives Israel rest from their suffering, anguish, and hard labor?

They will sing a song taunting the king of Babylon. 

# What will happen on the day that Yahweh gives Israel rest from their suffering, anguish, and hard labor?

They will sing a song taunting the king of Babylon. 

# What has happened to the oppressor?

The oppressor has come to an end. 

# What had the king of Babylon done?

He had struck the people in wrath with unceasing blows. He had ruled the nations in anger, with an attack that was unrestrained. 

# What will the dead kings of the earth say to the king of Babylon?

They will say, "You have become as weak as us..." and "Your pomp has been brought down to Sheol...." 

# What will the dead kings of the earth say to the king of Babylon?

They will say, "You have become as weak as us..." and "Your pomp has been brought down to Sheol...." 

# What has happened to the son of the morning?

He has fallen from heaven and been cut down to the ground. 

# What did the son of the morning say in his heart?

He said he would exalt his throne above the stars of God and make himself like the Most High God. 

# What did the son of the morning say in his heart?

He said he would exalt his throne above the stars of God and make himself like the Most High God. 

# Why will the king of Babylon not join the other kings of the nations in burial?

He will not join them because he destroyed his land and killed his people. 

# What is the declaration of Yahweh of Hosts against Babylon?

He declares,"I will rise up against them" and further, "I will cut off from Babylon name, descendant, and posterity." 

# What has Yahweh of Host sworn concerning the Assyrian in Yahweh's land?

He said he would break the Assyrian in his land and on his mountains trample him under foot. 

# What was the declaration against Philistia?

It was declared that Philistia should not rejoice, for Yahweh was going to kill Philistia's root with famine that will put to death all Philistia's survivors. 

# What was the declaration against Philistia?

It was declared that Philistia should not rejoice, for Yahweh was going to kill Philistia's root with famine that will put to death all Philistia's survivors. 

# Who founded Zion?

Yahweh founded Zion. 

# What will the afflicted of Yahweh's people find in Zion?

The afflicted of Yahweh's people will find refuge in Zion. 

# Who is the declaration about?

The declaration is about Moab. 

# What will happen to Ar and Kir of Moab?

They will each be destroyed and laid waste in one night. 

# Where will Moab's fugitives go?

They will flee to Zoar and to Eglath Shelishiyah. 

# What has happened to the waters of Dimon and what will happen to Dimon?

The waters of Dimon are full of blood; but Yahweh will bring even more upon Dimon. 

# What will happen to those who escape from Moab and also those who remain in the land?

A lion will attack both those who escape from Moab and those who remain in Moab. 

# To whom are rams to be sent?

The rams are to be sent to the ruler of the land at the mount of the daugther of Zion. 

# To what are the women of Moab at the fords of the Arnon River compared?

They are like wandering birds or a scattered nest. 

# What is Judah supposed to do with the fugitives and refugees of Moab?

They are to hide and not betray the fugitives and let the refugees live among them; be a hiding place from the destroyer. 

# What is Judah supposed to do with the fugitives and refugees of Moab?

They are to hide and not betray the fugitives and let the refugees live among them; be a hiding place from the destroyer. 

# What will the one from David's tent who sits on the throne do?

He will judge as he seeks justice and does righteousness. 

# What will Moab accomplish when he enters his temple to pray?

Moab will accomplish nothing with his prayers. 

# What was going to happen to the glory of Moab?

Yahweh said the glory of Moab would disappear within three years. 

# How many from Moab will be left?

The remnant of Moab will be very few and insignificant. 

# What will happen to the city of Damascus?

It will no longer be a city, but will be a heap of ruins. 

# What will disappear from Ephraim?

Fortified cities will disappear from Ephraim. 

# What will happen to the glory of Jacob on that day?

The glory of Jacob will become thin and the fatness of his flesh will become lean on that day. 

# To whom will men look on that day?

Men will look toward their Maker and their eyes will look to the Holy One of Israel. 

# On that day what will their strong cities be like?

On that day their strong cities will be like the abandoned wooded slopes on the hill summits. 

# What will happen when the nations roar like the rushing of mighty waters?

God will rebuke the nations and they will flee away and be chased. 

# What is the portion of those who rob Israel?

Their portion will be to see terror in the evening and to be gone before the morning. 

# Where is the land of rustling wings?

The land of rustling wings is beyond the rivers of Ethiopia. 

# To whom does the land of the rustling of wings send ambassadors?

They send ambassadors to a nation tall and smooth, to a people feared, a nation strong and conquering, whose land the rivers divide. 

# When are the inhabitants of the world supposed to look and listen?

They are to look and listen when a signal is lifted up on the mountains and when the trumpet is blown. 

# What will Yahweh do before the harvest, when the blossoming is over?

Yahweh will cut off the sprigs with pruning hooks and he will cut down and take away the spreading branches. 

# What will happen when the birds summer on the branches and all the animals of the earth winter on them?

At that time tribute will be brought to Mount Zion for Yahweh from a people tall and smooth. 

# What will happen when the birds summer on the branches and all the animals of the earth winter on them?

At that time tribute will be brought to Mount Zion for Yahweh from a people tall and smooth. 

# Who is the declaration in this chapter about?

This chapter is a declaration about Egypt. 

# Who will stir up the Egyptians?

Yahweh will stir up the Egyptians. 

# Who will stir up the Egyptians?

Yahweh will stir up the Egyptians. 

# Who will the Egyptians be stirred up against?

They will be stirred up against each other. 

# Who will Yahweh cause to lead the Egyptians?

Yahweh will give the Egyptians into the hands of a harsh master, and a strong king will rule over them. 

# What will happen to the waters of Egypt?

The waters of the sea will dry up and the river will dry up and become empty. 

# What will happen to the cloth workers in Egypt?

The cloth workers will be crushed. 

# What has happened to the counsel of Pharoah's counselors?

Their counsel has become senseless. 

# Why has the counsel of Pharoah's counselors become senseless?

Their counsel has become senseless because Yahweh has mixed a spirit of distortion into Egypt's midst. 

# In that day what will the Egyptians be like?

In that day the Egyptians will be like women. They will tremble and fear. 

# In that day what will five cities in Egypt do?

They will swear alligiance to Yahweh of Hosts. 

# In that day what will be in the middle of the land of Egypt?

In that day there will be an altar to Yahweh in the middle of the land of Egypt. 

# In that day who will worship Yahweh together?

The Egyptians and the Assyrians will worship Yahweh together. 

# In that day who will be a blessing in the midst of the earth?

Israel, Egypt and Assyria will be a blessing in the midst of the earth. 

# What happened when Tartan came to Ashdod?

Tartan fought against Ashdod and took it. 

# Who sent Tartan to Ashdod?

Sargon the king of Assyria sent Tartan to Ashdod. 

# What did Yahweh tell Isaiah to do when Tartan took Ashdod?

Yahweh told Isaiah to remove his sackloth and sandals and walk naked and barefoot. 

# Why was Isaiah told to walk naked?

This was to be a sign that the captives of Egypt and the exiles of Ethiopia were going to be lead away naked and barefoot by the king of Assyria. 

# Why was Isaiah told to walk naked?

This was to be a sign that the captives of Egypt and the exiles of Ethiopia were going to be lead away naked and barefoot by the king of Assyria. 

# What will happen to those who put their hope in Ethiopia and Egypt?

They will be dismayed and ashamed. 

# What will happen to those who put their hope in Ethiopia and Egypt?

They will be dismayed and ashamed. 

# What kind of vision was given to Isaiah?

A distressing vision was given to him. 

# What is the vision about?

Isaiah's vision is about an attack on Elam and a siege of Media. 

# How did this vision affect Isaiah?

It gave Isaiah pain in his loins. He was bowed down and disturbed. His heart was pounding. He was shuddering and trembling. 

# How did this vision affect Isaiah?

It gave Isaiah pain in his loins. He was bowed down and disturbed. His heart was pounding. He was shuddering and trembling. 

# What did the Lord say to Isaiah?

The Lord told Isaiah to post a watchman and have the watchman report what he sees. 

# What is the watchman to do when he sees a chariot, horsemen in pairs and riders on donkeys and camels?

Then the watchman must pay attention and be very alert. 

# When a charioteer comes, what does he call out?

He calls out, "Babylon has fallen, fallen, and all the carved figures of its gods are broken to the ground." 

# Who spends the night in the wilderness of Arabia?

Caravans of Dedanites spend the night there. 

# What are the caravans of Dedanites told to do?

They are told to bring water for the thirsty. 

# What are the inhabitants of the land of Tema told to do?

They are told to meet the fugatives with bread. 

# What did the Lord tell Isaiah about Kedar?

The Lord told Isaiah that within a year the glory of Kedar would end and only a few archers and warriors would remain. 

# What did the Lord tell Isaiah about Kedar?

The Lord told Isaiah that within a year the glory of Kedar would end and only a few archers and warriors would remain. 

# What is the topic of chapter 22?

It is a declaration about the valley of vision. 

# What have all the people gone?

They have all gone up to the housetops. 

# What is happening in the city and town?

The city is noisy and the town full of revelry. 

# Did the dead die by the sword or in battle?

No the dead did not die by the sword or in battle. 

# What happened to their rulers?

Their rulers fled away together and were caught and captured together. 

# Why was Isaiah weeping bitterly?

He was weeping because of the destruction of the daughter of his people. 

# Who is taking up the quiver and shield against them?

Elam takes up the quiver and Kir lays the shield bare. 

# What will happen in Judah's choicest valleys?

Their valleys will be full of chariots. 

# What did God to with the protection of Jerusalem?

He took away their protection 

# What did Yahweh of Hosts call for on that day?

He called for weeping and mourning, for shaved heads and the wearing of sackcloth. 

# What did the people do instead of weeping and mourning?

The people celebrated and were glad. They killed cattle and sheep, eating meat and drinking wine. 

# What did the people do instead of weeping and mourning?

The people celebrated and were glad. They killed cattle and sheep, eating meat and drinking wine. 

# Will the Lord forgive the people for their response?

The Lord will not forgive them even when they die. 

# What did Shebna, the administrator, do for himself?

Shebna had a grave hewn for himself in the rock as a resting place. 

# What did Shebna, the administrator, do for himself?

Shebna had a grave hewn for himself in the rock as a resting place. 

# What did Yahweh say he would do to Shebna?

Yahweh said he would throw Shebna down, and remove him from his office and station. 

# What did Yahweh say he would do to Shebna?

Yahweh said he would throw Shebna down, and remove him from his office and station. 

# What did Yahweh say he would do to Shebna?

Yahweh said he would throw Shebna down, and remove him from his office and station. 

# Who was to take Shebna's place of authority?

Eliakim, the son of Hilkiah was to take Shebna's place of authority. 

# Who was to take Shebna's place of authority?

Eliakim, the son of Hilkiah was to take Shebna's place of authority. 

# On that day what will happen to the peg driven into a firm place?

The peg driven in a firm place will give way, break off and fall and the weight that was on it will be cut off. 

# About whom was the declaration in chapter 23 spoken?

The declaration in chapter 23 was about Tyre. 

# Why should the ships of Tarshish howl?

They should howl because they have neither home nor harbor. 

# What was the city of Tyre?

Tyre was the marketplace of nations. 

# What will Egypt do when they hear the report concerning Tyre?

Egypt will grieve when they hear the report about Tyre. 

# Who planned this against Tyre?

The Lord of Hosts planned this against Tyre. 

# Who planned this against Tyre?

The Lord of Hosts planned this against Tyre. 

# Why has the Lord of Hosts planned this against Tyre?

He has planned this to dishonor her pride and all her glory, to shame all her honored ones of the earth. 

# How long will Tyre be forgotten?

In that day, Tyre will be forgotten for seventy years. 

# What will happen to Tyre after being forgotten for seventy years?

Yahweh will help Tyre, and she will return to her hire and prostitute herself with all the kingdoms on earth. 

# What will happen to the Tyre's profits and earnings?

Her profits and earnings will be reserved for Yahweh. 

# What will happen to Tyre's merchandise?

It will be for those who live in Yahweh's presence, for them to eat and have lasting clothing. 

# What is Yahweh about to do?

He is about to empty the earth, to devastate it, mar its surface and scatter its inhabitants. 

# How has the earth been polluted by its inhabitants?

The earth has been polluted because its inhabitants have transgressed the laws, violated the statutes and broken the everlasting covenant. 

# What happens to the inhabitants of the earth?

They will burn up and few people will be left. 

# What image does Isaiah use to show how it will be at that time on the whole earth among the nations?

He compares conditions on the earth at that time to how it is when an olive tree is beaten or as the gleanings when the grape harvest is done. 

# In the midst of all this calamity what will "they" do?

They will lift up their voices and shout the majesty oh Yahweh and will joyfully shout from the sea. 

# What is Isaiah's response to the shouting and calls to glorify Yahweh, the God of Israel?

Isaiah responds by saying, "I have wasted away, I have wasted away, woe is me! The treacherous have dealt treacherously; yes, the treacherous have dealt very treacherously. 

# On that day who will Yahweh punish?

Yahweh will punish the host of the high ones on high and the kings of the earth on the earth. 

# What will be the punishment for the host of the high ones on high and the kings of the earth on the earth?

They will be gathered together, prisoners in a pit and will be shut up in prison and after many days they will be sentenced. 

# Why will the moon be ashamed and the sun disgraced?

This will be because Yahweh of Hosts will reign on Mount Zion and in Jerusalem, and before his elders in glory. 

# Why did Isaiah exalt and praise Yahweh?

Isaiah exalted and praised Yahweh because Yahweh had done wonderful things, things planned long ago, in perfect faithfulness. 

# What wonderful things had Yahweh done?

Yahweh made the city a heap, a fortified city a ruin and a fortress of strangers into no city. 

# What will be the response after Yahweh makes the city a heap, etc.?

A strong people will glorify Yahweh and a city of ruthless nations will fear him. 

# What will Yahweh do for and to all peoples on that mountain?

He will make a feast of fat things for all peoples and he will destroy the coverings of all peoples, the web woven over all nations. 

# What will Yahweh do for and to all peoples on that mountain?

He will make a feast of fat things for all peoples and he will destroy the coverings of all peoples, the web woven over all nations. 

# What will Yahweh swallow up, wipe away and take away from his people?

He will swallow up death, wipe away tears from all faces and he will take away the disgrace of His people. 

# What will be said on that day?

This will be said: "Look, this is our God: we have waited for him and he will save us. This is Yahweh; we have waited for him. We will be glad and rejoice in his salvation." 

# What is Moab's fate likened to?

Moab's fate is compared to straw that is trampled down in a pit filled with manure. 

# In that day where will this song be sung?

This song will be sung in the land of Judah. 

# How has God made the city strong?

He has made it strong by making salvation its walls and ramparts. 

# For whom will the gates of the city be opened?

The gates will be opened for the righteous nation that keeps faith. 

# Who should we trust in and for how long should we trust?

We should trust in Yahweh forever. 

# What will happen to those who live proudly; the fortified city?

Yahweh will lay them low; he will level the fortified city to the dust. It will be trampled down by the feet of the poor and the treading of the needy. 

# What will happen to those who live proudly; the fortified city?

Yahweh will lay them low; he will level the fortified city to the dust. It will be trampled down by the feet of the poor and the treading of the needy. 

# What is the desire of our soul?

The name and memory of Yahweh are the desire of our soul. 

# What happens when judgments come on the earth?

When judgments come the inhabitants of the world learn righteousness. 

# What will the wicked one do when he is shown favor?

He will not learn righteousness. 

# What has Yahweh done for Judah and what will he bring about for Judah?

Yahweh has accomplished all our works for us and will bring about peace for Judah. 

# What happened to the other lords who ruled over Judah?

They are dead, they will not live; they are deceased and will not rise. Yahweh came in judgment and destroyed them. 

# What happened to the other lords who ruled over Judah?

They are dead, they will not live; they are deceased and will not rise. Yahweh came in judgment and destroyed them. 

# When did Judah look to Yahweh?

They looked to Yahweh when they were in trouble; when Yahweh disciplined them. 

# Why should the dwellers in the dust awake and sing for joy?

They should awake and sing for joy because the dead, they will live, they will arise. 

# Why are the people supposed to go into their rooms and shut their doors.

They are to do this so they can hide until the indignation has passed by. 

# What is Yahweh about to do?

He is about to come out of his place to punish the inhabitants of the earth for their iniquity. 

# On that day what will Yahweh do with his sword?

Yahweh will punish Leviathan the serpent, and he will kill the monster that is in the sea. 

# In that day what will Yahweh do with a vineyard of wine?

He will protect it, water it every moment and guard it day and night. 

# In that day what will Yahweh do with a vineyard of wine?

He will protect it, water it every moment and guard it day and night. 

# What will Yahweh do if the briars and thorns don't grasp his protection and make peace with him?

Yahweh will march against them and burn them altogether. 

# What will Yahweh do if the briars and thorns don't grasp his protection and make peace with him?

Yahweh will march against them and burn them altogether. 

# What will Jacob and Israel do in the coming day?

Jacob will take root; Israel will blossom and bud; and they will fill the surface of the ground with fruit. 

# What will be the full fruit of Jacob turning away from his sin?

He will make all the altar stones as chalk and pulverized, and no Asherim or incense altars will remain standing. 

# Why will the Maker of Israel not have compassion on them?

Because they are not a people of understanding Yahweh will not have compassion on them. 

# On that day how will the people of Israel be gathered?

They will be gathered one by one. 

# Who will worship Yahweh on the holy mountain in Jerusalem?

The perishing ones in the land of Assyria and the outcasts in the land of Egypt will worship Yahweh on the holy moutain in Jerusalem. 

# How is Ephraim characterized?

Ephraim is characterized as proud and as a drunkard. 

# What is happening to Ephraim's beauty?

Epraim's beauty is fading. 

# To what is the Lord's mighty and strong one compared?

He is compared to a hail storm, a destroying storm, and a cloudburst of might and overwhelming. 

# What will the Lord's mighty and strong one do?

He will strike the earth with his hand. 

# What will the fading flower of Ephraim's glorious beauty be likened to?

It will be as the first ripe fig before the summer, that, when someone sees it, while it is yet in his hand, he gulps it down. 

# In that day what will Yahweh be for the remainder of his people?

Yahweh will be a beautiful crown and a diadem of beauty, a spirit of justice for him who sits in judgment, and strength for those who turn back their enemies at their gates. 

# In that day what will Yahweh be for the remainder of his people?

Yahweh will be a beautiful crown and a diadem of beauty, a spirit of justice for him who sits in judgment, and strength for those who turn back their enemies at their gates. 

# Who reels with wine and staggers with strong drink?

The remainder of Yahweh's people, the priest and prophet. 

# What do the priest and prophet stagger and reel in?

They stagger in vision and reel in decision. 

# How will Yahweh speak to this people?

He will speak to them with a mocking lips and a foreign tongue. 

# What happened in the past when Yahweh spoke to them?

They would not listen. 

# Now what will be the result when this people hear the word of Yahweh?

They will go and fall backward and be broken, ensnared and captured. 

# What did the rulers of the people in Jerusalem say?

They said they that they had made a covenant with death and reached an agreement with Sheol that when judgment passes through it wouldn't reach them. They said they had made a lie their refuge and had hidden in falsehood. 

# What will the Lord Yahweh lay in Zion?

He will lay a foundation stone, a tried stone, a precious cornerstone, a sure foundation. 

# What happens if they believe in this foundation stone?

If they believe in this foundation stone they will not be ashamed. 

# What will happen to the refuge of lies and the hiding place?

Hail will sweep away the refuge of lies and the floodwaters will overwhelm the hiding place. 

# What will happen the covenant with death and the agreement with Sheol that the rulers of the people in Jerusalem have made?

That covenant and agreement will be dissolved and when the raging flood passes through they will be overwhelmed by it. 

# What does Isaiah say will be the consequences for mocking?

He warns them not to mock or their bonds will be tightened. 

# What is Ariel?

Ariel is the city where David encamped. 

# What will Yahweh do to Ariel?

He will besiege Ariel and she will be brought down. 

# What will Yahweh do to Ariel?

He will besiege Ariel and she will be brought down. 

# How long will it take for Ariel to be brought down?

It will happen suddenly, in an instant. 

# Who will fight against Ariel and her stronghold?

A horde of all the nations will fight against Ariel. 

# What has Yahweh poured out on Ariel?

He has poured on them the spirit of deep sleep. 

# What does this pouring out of the spirit of deep sleep do to them?

It has closed the prophets and covered the seers. 

# What is the Lord's complaint against this people?

The Lord said, "This people draws near to me with their mouth and honor me with their lips, but their heart is far from me. Their honoring me is a commandment taught by men. 

# Since their hearts are far from the Lord and they don't honor him, what will the Lord do to them?

He will cause the wisdom of the wise men to perish and the understanding of the prudent men to disappear. 

# What is going to happen to Lebanon in just a little while?

Lebanon will be turned into a field and the field will become a forest. 

# On that day what will the deaf and blind do?

The deaf will hear the words of a book and the eyes of the blind will see out of deep darkness. 

# What will the oppressed and the poor among men do?

They will rejoice in Yahweh the Holy One of Israel. 

# What will happen to those who love to do evil?

They will be eliminated. 

# When will the house of Jacob honor Yahweh's name?

They will honor Yahweh's name when he sees his children in his midst, the work of Yahweh's hands. 

# What will happen to complainers and those who err in spirit?

The complainers will learn Knowledge and those who err in spirit will gain understanding. 

# What did Yahweh say the rebellious children do?

He said they make plans but not from him and make webs but not by his spirit, that they may add sin to sin. 

# Who do the rebellious children seek to protect them?

They seek protection from Pharaoh and take refuge in the shadow of Egypt. 

# What will Pharaoh's protection and Egypt's shade be to the rebellious children?

Pharoah's protection will be their shame and Egypt's shade will be their humiliation. 

# How valuable is Egypt's help to the rebellious children?

Egypt's help is worthless. 

# Why does Yahweh want Isaiah to write it in their presence on a tablet, and inscribe it on a scroll?

Yahweh wants it to be preserved for the time to come as a testimony. 

# What do the rebellious people not hear?

They will not hear the instruction of Yahweh. 

# What do the rebellious children want to hear?

They want to hear smooth things and deceptive prophesies. 

# How does Yahweh say the rebellious children can be strong and be saved?

Yahweh says they can be saved by returning and resting, and in quietness and trust will be their strength. 

# What was the reply of the rebellious children to Yahweh?

They said, "No, we will flee on horses." and, "We will ride on swift horses." 

# What is Yahweh's response to the rebellious children's statement about fleeing on horses and riding on swift horses?

Yahweh responds by telling the rebellious children they will flee and that those who pursue them will be swift. 

# How many did Yahweh say would flee at the threat of one?

Yahweh said one thousand would flee at the threat of one. 

# What is Yahweh waiting and ready to do?

He is waiting to be gracious to the rebellious children and to have mercy on them. 

# What happens to all those who wait for Yahweh?

They will be blessed. 

# Though Yahweh gives them the bread of adversity and the water of affliction what will their teacher not do anymore?

Their teacher will not hide himself anymore, but they will see him with their own eyes. 

# What will the rebellious children do with their carved figures and cast gold figures?

They will desecrate them and throw them away. 

# What will Yahweh do to his people after the day of the great slaughter when the towers fall?

Yahweh will bind up the breaking of his people and heal the bruises of his wounding them. 

# How will Yahweh manifest the splendor of his voice and show the motion of his arm?

He will manifest them in storming anger and flames of fire, with windstorm, rainstorm and hailstones. 

# Who will Yahweh's voice and motion of his arm be directed toward?

They will directed toward Assyria. For at the voice of Yahweh, Assyria will be shattered; he will strike them with a staff. 

# What will accompany every stroke of the appointed rod that Yahweh will lay on him?

The music of tambourines and harps will accompany every stroke as Yahweh battles and fights with Assyria. 

# What has been prepared for the king of Assyria?

A place of burning has been prepared for the king of Assyria. 

# What or who will kindle the fire prepared for the king of Assyria?

The breath of Yahweh will kindle it. 

# Why is woe pronounced on those who go down to Egypt for help?

Woe is pronounced on them because they trust in chariots and horsemen but are not concerned about the Holy One of Israel, nor do they seek Yahweh. 

# Who will Yahweh arise against?

He will arise against the evil house and against the helpers of those who commit sin. 

# What will happen to him who helps and him who is helped?

Both of them will perish together. 

# What will Yahweh do for Jerusalem?

He will protect, deliver and preserve it. 

# What does Isaiah tell the people of Israel to do?

He tells them to return to Yahweh from whom they have deeply turned away. 

# After Assyria falls by the sword, what will their young men be forced to do?

Assyria's young men will be forced to do hard labor. 

# What will a righteous king and just princes be like?

They will be like a shelter from the wind and a refuge from the storm, like streams of water in a dry place, like the shade of a great rock in a land of weariness. 

# What will the rash and the stutterer do when a king reigns in righteousness and princes rule with justice?

The rash will think carefully with understanding, and the stutterer will speak distinctly and with ease. The fool will no longer be called honorable, nor the deceiver be called principled. 

# What does the fool do?

He speaks folly, his heart plans evil godless actions and he speaks wrongly against Yahweh. 

# What does the deceiver do?

He uses evil methods. He devises wicked schemes to ruin the poor with lies. 

# What will happen to the honorable man?

The honorable man will stand because of his honorable actions. 

# Why were the women who were at ease told to listen to Isaiah's voice?

They were told to listen to Isaiah's voice because in a little more than a year their confidence would be broken, the grape harvest would fail, the ingathering would not come. 

# Why were the women who were at ease told to listen to Isaiah's voice?

They were told to listen to Isaiah's voice because in a little more than a year their confidence would be broken, the grape harvest would fail, the ingathering would not come. 

# What was going to happen to the palace and the crowded city?

The palace was going to be forsaken and the crowded city deserted. 

# How long will the devastation last?

It will last until the Spirit is poured out from on high and the wilderness becomes a fruitful field and the fruitful field is considered a forest. 

# What will be the work and result of righteousness?

The work of rightousness will be peace and the result of righteousness, quietness and confidence forever. 

# Who is it that will be blessed?

Blessed are the ones who sow beside all streams and who send out their ox and ass to graze. 

# What will happen to the destroyer and the betrayer when they stop destroying and betraying?

The destroyer will be destroyed and the betrayer will be betrayed. 

# What happens when Yahweh arises?

The nations are scattered. 

# With what will Yahweh fill Zion?

He will fill Zion with justice and righteousness. 

# What will Yahweh be in their times?

In their times he will be the stability, abundance of salvation and wisdom and knowledge. 

# Why did their envoys cry and the diplomats weep bitterly?

They cried and wept because the highways were deserted; there were no more travelers. Treaties were broken, witnesses were despised and cities were disrespected. 

# What will be the result when Yahweh arises?

Yahweh will be lifted up and exalted. 

# What happens to those in Zion who conceive chaff, and give birth to stubble?

Their breath is a fire that will consume them. The peoples will be burned to lime. 

# What happens to those in Zion who conceive chaff, and give birth to stubble?

Their breath is a fire that will consume them. The peoples will be burned to lime. 

# What is the response of the sinners in Zion?

The sinners in Zion are afraid; trembling has seized the godless ones. 

# Who among those in Zion can dwell with the devouring fire and the everlasting burnings?

The ones who can dwell with this fire and burning are the ones who walk righteously and speak honestly; who despise the gain of oppression, who refuse to take a bribe, who do not plot violent crime and do not look on evil. 

# Where will he who walks righteously and speaks honestly make his home ?

He who walks righteously and speaks honestly will make his home on the heights. 

# Where will he who walks righteously and speaks honestly make his home ?

He who walks righteously and speaks honestly will make his home on the heights. 

# Who is Yahweh and what will he do?

Yahweh is our judge, our lawgiver and our king; he will save us. 

# When the great spoil is divided who will be among those dragging it off?

Even the lame will drag off the spoil. 

# Who is supposed to come near, listen and pay attention?

The nations, the earth and all that fills it, the world and all things that come from it must come near, listen and pay attention. 

# Why must the nations, the earth and all that fills it, the world and all things that come from it come near, listen and pay attention?

They must do this because Yahweh is angry with all the nations and furious against all their armies. 

# What has Yahweh done to the nations and their armies?

He has completely destroyed them. He has delivered them to the slaughter. 

# What will happen to the stars and sky?

All the stars of the sky will fade away and the sky will be rolled up like a scroll; and all their stars will fade away. 

# What will Yahweh do after his sword has drunk its fill in heaven?

Then his sword will come down on Edom and on the people of his exclusive belonging in judgment. 

# What does Yahweh have in Bozrah and Edom?

Yahweh has a great sacrifice in Bozrah and a great slaughter in the land of Edom. 

# What will happen to the land of Edom?

Her streams will be turned to pitch and her dust into brimstone. She will become burning pitch. It will be a wasteland; no one will pass through it. 

# What will happen to the land of Edom?

Her streams will be turned to pitch and her dust into brimstone. She will become burning pitch. It will be a wasteland; no one will pass through it. 

# In general what will live in Edom?

Wild birds and animals will live in Edom. 

# How long will the birds and animals possess Edom?

They will possess it for ever; from generation to generation they will live there. 

# What will happen to the desert?

It will rejoice and blossom like the rose. 

# What will be given to the desert?

The glory of Lebanon will be given to it, the splendor of Carmel and Sharon. 

# What will the wilderness, the Arabah and the desert see?

They will see the glory of Yahweh, the splendor of our God. 

# Why should those with a fearful heart be strong and not fear?

Because their God is coming with vengeance, with the recompense of God. He will come and save them. 

# What are some of the things that will happen when their God comes?

The blind will see. The dead will hear. The lame man will leap. The mute will sing. There will be water in the Arabah and streams in the wilderness. The burning sand will become a pool and the thirsty ground springs of water. There will be reeds and rushes where jackals once lay. 

# What are some of the things that will happen when their God comes?

The blind will see. The dead will hear. The lame man will leap. The mute will sing. There will be water in the Arabah and streams in the wilderness. The burning sand will become a pool and the thirsty ground springs of water. There will be reeds and rushes where jackals once lay. 

# What are some of the things that will happen when their God comes?

The blind will see. The dead will hear. The lame man will leap. The mute will sing. There will be water in the Arabah and streams in the wilderness. The burning sand will become a pool and the thirsty ground springs of water. There will be reeds and rushes where jackals once lay. 

# What will be the name of the highway that will appear at that time?

A highway will be there called The Way of Holiness. 

# Who will and will not be on the highway?

The unclean will not travel it and no fool will go on it. No lion or ferocious beast will be on it . The highway will be for him who walks in the way of holiness. The redeemed will walk there. 

# Who will and will not be on the highway?

The unclean will not travel it and no fool will go on it. No lion or ferocious beast will be on it . The highway will be for him who walks in the way of holiness. The redeemed will walk there. 

# What will happen to the ransomed of Yahweh when they return?

Everlasting joy will be on their heads; gladness and joy will overtake them; sorrow and sighing will flee away. 

# What happened in the fourteenth year of king Hezekiah?

Sennacherib, king of Assyria, marched against all the fortified cities of Judah and captured them. 

# Who did the king of Assyria send from Lachish to Jersualem to Hezekiah?

The king of Assyria sent the Rabshakeh. 

# Where did the Rabshakeh stop?

He stopped at the conduit of the upper pool, on the highway to the washers field. 

# Who went out ot meet the Rabshakeh?

Eliakim the son of Hilkiah, Shebna the scribe and Joah the recorder, the son of Asaph went out to meet the Rabshakeh. 

# Who did the Rabshakeh say that Pharaoh, king of Egypt, was to anyone who trusted in him? 

The Rabshakeh said the Pharaoh was a splintered reed that if used as a walking stick would pierce your hand. 

# What did the Rabshakeh say the king of Assyria would do if Hezekiah would make an agreement with the king of Assyria?

The Rabshakeh said the king of Assyria would give Hezekiah two thousand horses. 

# Who did the Rabshakeh say had told him to march against Judah and destroy it?

The Rabshakeh said that Yahweh had told him to march against Judah and destroy it. 

# Why did Eliakim, Shebna and Joah ask the Rabshakeh to speak to them in Aramaic?

They did not want the people on the wall to hear and understand what was being said. 

# Why did Eliakim, Shebna and Joah ask the Rabshakeh to speak to them in Aramaic?

They did not want the people on the wall to hear and understand what was being said. 

# How did the Rabshakeh respond to the request for him to speak to Eliakim, Shebna and Joah in Aramaic?

He responded by standing and shouting in a loud voice in the Jew's language. 

# Briefly what did the Rabshakeh say were the words of the king of Assyria with regards to Hezekiah?

He said not to let Hezekiah deceive them because Hezekiah wouldn't be able to rescue them and he said not to trust in Yahweh. 

# Briefly what did the Rabshakeh say were the words of the king of Assyria with regards to Hezekiah?

He said not to let Hezekiah deceive them because Hezekiah wouldn't be able to rescue them and he said not to trust in Yahweh. 

# Briefly what did the Rabshakeh say were the words of the king of Assyria with regards to Hezekiah?

He said not to let Hezekiah deceive them because Hezekiah wouldn't be able to rescue them and he said not to trust in Yahweh. 

# What did the king of Assyria say would happen if the Jews would make peace with him and come out to him?

He said the Jews would eat from their own vine and from their own fig tree, and drink water from their own cistern, until he would come and take the Jews away to a land like their own land, a land of grain and new wine, a land of bread and vineyards. 

# What did the king of Assyria say would happen if the Jews would make peace with him and come out to him?

He said the Jews would eat from their own vine and from their own fig tree, and drink water from their own cistern, until he would come and take the Jews away to a land like their own land, a land of grain and new wine, a land of bread and vineyards. 

# What was the response to the Rabshekah's speech?

They remained silent and did not respond, for the kings order was, "Do not answer him". 

# What did Eliakim, Shebna and Joah do after the Rabshekah's speech?

They came to Hezekiah with their clothes torn and reported to Hezekiah the words of Rabshakeh. 

# What did Hezekiah do when he heard the report from Eliakim, Shebna and Joah?

Hezekiah tore his clothes, covered himself with sackcloth and went into the house of Yahweh. He also sent Eliakim, Shebna and the elders of the priests to Isaiah the prophet. 

# What did Hezekiah do when he heard the report from Eliakim, Shebna and Joah?

Hezekiah tore his clothes, covered himself with sackcloth and went into the house of Yahweh. He also sent Eliakim, Shebna and the elders of the priests to Isaiah the prophet. 

# What did Hezekiah ask Isaiah to do?

He asked Isaiah to pray to Yahweh for the remnant that was still to be found there. 

# What message did Isaiah give to Hezekiah's servants to take back to Hezekiah?

Isaiah's message to Hezekiah was to not fear the words of the king of Assyria's servant, the Rabshakeh. Yahweh was going to put a spirit in The king of Assyria, and he would hear a report and go back to his own land and would be killed by the sword there. 

# What message did Isaiah give to Hezekiah's servants to take back to Hezekiah?

Isaiah's message to Hezekiah was to not fear the words of the king of Assyria's servant, the Rabshakeh. Yahweh was going to put a spirit in The king of Assyria, and he would hear a report and go back to his own land and would be killed by the sword there. 

# After the king of Assyria heard that Tirhakah, king of Ethiopia, was coming out to fight against him, what message did the king of Assyria send to Hezekiah?

The king of Assyria told Hezekiah in a letter not to let God deceive Hezekiah by saying, Jerusalem would not be given over into the hand of the king of Assyria. 

# What did Hezekiah do after he received the letter from the king of Assyria and read it?

Hezekiah went up to the house of Yahweh and spread the letter out and prayed to Yahweh. 

# What did Hezekiah do after he received the letter from the king of Assyria and read it?

Hezekiah went up to the house of Yahweh and spread the letter out and prayed to Yahweh. 

# What did Hezekiah pray for Yahweh to do?

First, Hezekiah asked Yahweh to hear and listen and to open his eyes and see all the words in Sennacherib's letter. Second, Hezekiah asked Yahweh to save Jerusalem from Sennacherib's hand. 

# What did Hezekiah pray for Yahweh to do?

First, Hezekiah asked Yahweh to hear and listen and to open his eyes and see all the words in Sennacherib's letter. Second, Hezekiah asked Yahweh to save Jerusalem from Sennacherib's hand. 

# What reason did Hezekiah give as motivation for God to save Jerusalem from Sennacherib?

Hezekiah wanted Yahweh to save Jerusalem from Sennacheri so that all the kingdoms of the earth may know that Yahweh alone is God." 

# How did Yahweh respond to Hezekiah's prayer?

Yahweh responded by sending a message to Hezekiah through Isaiah. 

# In Yahweh's message to Hezekiah what did Yahweh say Sennacherib had done wrong?

Yahweh said Sennacherib had defied, blasphemed, exalted his voice and lifted up his eyes against the Holy one of Israel. 

# What did Yahweh determine long ago and work out in ancient times?

He determined and worked out that Sennacherib would reduce impregnable cities into heaps of ruins. 

# What else did Yahweh know about Sennacherib?

Yahweh knew when Sennacherib sat down, went out, came in, and his raging against Yahweh. 

# What was the result of Sennacherib's raging against Yahweh?

Yahweh turned Sennacherib back the way he came. 

# What did Yahweh say about the king of Assyria concerning Jerusalem?

Yahweh said the king of Assyria would not enter Jerusalem or shoot an arrow there and that he would not confront it with a shield or build siege works against it. 

# What did Yahweh say about the king of Assyria concerning Jerusalem?

Yahweh said the king of Assyria would not enter Jerusalem or shoot an arrow there and that he would not confront it with a shield or build siege works against it. 

# What reason did Yahweh give for defending and saving Jerusalem?

He said he would defend and save Jerusalem for his own sake and for the sake of David his servant. 

# What did the angel of Yahweh do?

He went out and struck down 185,000 troups in the camp of the Assyrians. 

# What happened to Sennacherib after he departed and went home to Nineveh?

While he was worshiping in the house of Nisroch his god, his sons, Adrammelech and Sharezer, struck Sennacherib with the sword. 

# In those days what happened to Hezekiah?

He became very ill and neared death. 

# What did Isaiah tell Hezekiah?

Isaiah told Hezekiah, "Yahweh says, 'Set your house in order, for you will die and not get well.'". 

# What did Hezekiah do after receiving Yahweh's message through Isaiah?

He prayed to Yahweh asking Yahweh to remember how he had faithfully walked before Yahweh with his whole heart and how he had done good in Yahweh's sight. And Hezekiah wept loudly. 

# What did Yahweh tell Isaiah to say to Hezekiah?

He said to tell Hezekiah that he had heard Hezekiah's prayer and his tears. Yahweh told Hezekiah he would add fifteen years to Hezekiah's life and in addition he would rescue Hezekiah and Jerusalem from the king of Assyria and would defend Jerusalem. 

# What did Yahweh tell Isaiah to say to Hezekiah?

He said to tell Hezekiah that he had heard Hezekiah's prayer and his tears. Yahweh told Hezekiah he would add fifteen years to Hezekiah's life and in addition he would rescue Hezekiah and Jerusalem from the king of Assyria and would defend Jerusalem. 

# What sign did Yahweh say he would give so that Hezekiah would know Yahweh would do what he had spoken?

Yahweh said he would cause the shadow on the stairs of Ahaz to go back ten steps. 

# In Hezekiah's written prayer what did Hezekiah say would happen halfway through his life?

He said he would go through the gates of Sheol. 

# At the beginning of Hezekiah's written prayer what did he say concerning Yahweh?

Hezekiah said he would no longer see Yahweh in the land of the living. 

# What did Hezekiah say to the Lord concerning his sufferings and grief?

Hezekiah said the sufferings the Lord sent were good for him and that it was for Hezekiah's benefit that he experienced such grief. 

# What did Hezekiah say to the Lord concerning his sufferings and grief?

Hezekiah said the sufferings the Lord sent were good for him and that it was for Hezekiah's benefit that he experienced such grief. 

# What did Hezekiah say the Lord had done with his sins?

Hezekiah said the Lord had thrown all of Hezekiah's sins behind his back. 

# How was Hezekiah going to celebrate Yahweh saving him?

Hezekiah said they would celebrate with music all the days of their lives in the house of Yahweh. 

# What did Isaiah say to do so that Hezekiah would recover?

He said, "Let them take a cake of figs and lay it as plaster on the boil and he will recover. 

# Who sent letters and a present to Hezekiah?

Merodach-baladan the son of Baladan, king of Babylon sent letters and a present to Hezekiah. 

# What did Hezekiah show to those who brought the letters and present from Merodach-baladan?

Hezekiah showed them his treasury—the silver, the gold, the spices, the precious oil, the storehouse of his weapons, and all that was found in his storehouses. Hezekiah showed them everything in his house and kingdom. 

# What did Isaiah ask Hezekiah?

He asked Hezekiah what the men had said to him, where they had come from, and what they had seen in Hezekiah's house. 

# What did Isaiah ask Hezekiah?

He asked Hezekiah what the men had said to him, where they had come from, and what they had seen in Hezekiah's house. 

# What things did Isaiah say to Hezekiah would be taken to Babylon?

Yahweh told Hezekiah that all he and his ancestors had stored up until that day would be carried off to Babylon. 

# What things did Isaiah say to Hezekiah would be taken to Babylon?

Yahweh told Hezekiah that all he and his ancestors had stored up until that day would be carried off to Babylon. 

# Why did Hezekiah think the word of Yahweh that Isaiah spoke was good?

He thought it was good because he thought there would be peace and stability in his days. 

# How does God say to comfort his people?

He says to comfort them by speaking tenderly to Jerusalem, telling her that her warfare has ended and her iniquity is pardoned and that she has received double from Yahweh's hand for all her sins. 

# What does a voice cry out?

It cries, "In the wilderness prepare the way of Yahweh; make straight in the Arabah a highway for our God." 

# What will happen to the land in Israel?

Every valley lifted up, every mountain and hill leveled, the rugged land made level and the rough places made into a plain. 

# To whom will the glory of Yahweh be revealed?

Yahweh's glory will be seen by all people together. 

# What will stand forever?

The word of our God will stand forever. 

# What good news was to be proclaimed to Jerusalem and the cities of Judah?

The good news was, "Here is your God!" 

# How does the Lord Yahweh come?

He comes as a victorious warrior. 

# What does Yahweh bring with him when he comes?

Yahweh brings his reward with him and his recompense goes before him. 

# What are the nations like to Yahweh?

The nations are like a drop in a bucket to Yahweh and are regarded like the dust on the scales. 

# Where does God sit?

God sits above the horizon of the earth. 

# What does God do to rulers?

God reduces rulers to nothing and makes the rulers of the earth insignificant. 

# What does Yahweh do with the stars?

He leads out their formations and calls them all by name and by the greatness of his might and the strength of his power, not one is missing. 

# Who is Yahweh, and what is he like?

Yahweh is the everlasting God, the creator of the ends of the earth. He does not get tired or weary and there is no limit to his understanding. 

# What does Yahweh do for the tired and weary?

Yahweh gives strength to the tired and renewed energy to the weary. 

# What will happen to those who wait on Yahweh?

Those who wait on Yahweh will renew their strength; they will soar with wings like eagles; they will run and not be weary; they will walk and not faint. 

# For what purpose does Yahweh say, "let us come near together"?

Yahweh says for them to come near together so that they may argue a dispute. 

# Who has called forth the generations from the beginning?

It is Yahweh who has done these things. 

# What is the response of the isles who have seen and are afraid and the ends of the earth that tremble?

Their response is to approach and come and they encourage one another to build an idol. 

# What is the response of the isles who have seen and are afraid and the ends of the earth that tremble?

Their response is to approach and come and they encourage one another to build an idol. 

# What is the response of the isles who have seen and are afraid and the ends of the earth that tremble?

Their response is to approach and come and they encourage one another to build an idol. 

# What does Yahweh call Israel?

Yahweh calls Israel his servant, the offspring of Abraham his friend and he calls Israel chosen. 

# What does Yahweh call Israel?

Yahweh calls Israel his servant, the offspring of Abraham his friend and he calls Israel chosen. 

# What does Yahweh say he is doing for Israel?

Yahweh says he is bringing back Israel from the ends of the earth. 

# What does Yahweh tell Israel not to do and why?

Yahweh tells Israel not to fear for Yahweh is with them and to not be anxious because he is their God. 

# What further does Yahweh say he will do for Israel?

Yahweh says he will strengthen and help them and will uphold them with the right hand of his deserved victory. 

# What will happen to those who are angry with and oppose Israel?

They will be ashamed and disgraced and will be as nothing and will perish. 

# What will Israel do when they winnow those who war against them and contend with them?

Israel will rejoice in Yahweh, in the Holy One of Israel. 

# What will Yahweh do when the oppressed and needy look for water?

Yahweh says he will respond to their prayers by making streams flow down the slopes and making springs in the middle of the valleys, by making the desert into a pool of water and the dry land into springs of water. He will not forsake them. 

# What will Yahweh do when the oppressed and needy look for water?

Yahweh says he will respond to their prayers by making streams flow down the slopes and making springs in the middle of the valleys, by making the desert into a pool of water and the dry land into springs of water. He will not forsake them. 

# What does Yahweh say to those who follow idols?

He says to present their case, bring forth their best arguments for their idols. 

# What evidence does Yahweh say those who follow idols should present so we can know if we can believe in them or not

For evidence Yahweh says to tell what will happen, and to tell of earlier predictions so we can reflect on them and know how they were fulfilled. 

# What is Yahweh's assessment of the idols and the people who choose them?

Yahweh says their idols are of nothing and their deeds are nothing; he who chooses them is abominable. 

# Who among those who worship idols decreed or declared that one would come from the north and would trample the rulers like mud, like a potter who is treading clay?

None of those who worship idols decreed it and no one heard them say anything. 

# Who among those who worship idols decreed or declared that one would come from the north and would trample the rulers like mud, like a potter who is treading clay?

None of those who worship idols decreed it and no one heard them say anything. 

# What did Yahweh say concerning the one he raised up from the north?

He said first to Zion, 'Look here they are;' He sent a herald to Jerusalem. 

# In this chapter what are Yahweh's final words about those who follow idols?

Here are his words: "When I look, there is no one, not one among them who can give counsel, who, when I ask, can answer a word. Look all of them are nothing, and their deeds are nothing; their cast-poured figures are wind and emptiness. 

# In this chapter what are Yahweh's final words about those who follow idols?

Here are his words: "When I look, there is no one, not one among them who can give counsel, who, when I ask, can answer a word. Look all of them are nothing, and their deeds are nothing; their cast-poured figures are wind and emptiness. 

# What does Yahweh say he has done for his servant?

Yahweh says he has chosen his servant, that he delights in him and that he has put his spirit upon him. 

# What does Yahweh's say his servant will bring to the nations?

Yahweh says his servant will faithfully bring forth justice to the nations. 

# What will Yahweh's servant not do to a crushed reed or a dimly burning wick?

Yahweh says his servant will not break a crushed reed or quench a dimly burning wick. 

# How does Yahweh describe himself?

He describes himself as the one who created the heavens and stretched them forth; who spread out the earth and gives life in it; who gives breath to the people on the earth and life to those who live on it. 

# What did Yahweh want his chosen servant to do for blind people and prisoners?

Yahweh wanted his servant to open the eyes of the blind, to release the prisoners from the dungeon, and from the house of confinement those who sit in darkness. 

# What does Yahweh say he will not share?

He says he will not share his glory with another nor his praise with carved idols. 

# How does Yahweh contrast himself with carved idols?

In contrast to carved idols, things came to pass when Yahweh declared them. 

# How does Yahweh contrast himself with carved idols?

In contrast to carved idols, things came to pass when Yahweh declared them. 

# To further declare his glory what did Yahweh say he would do?

He said he was going to delare new events. He was going to tell about them before they occurred. 

# What will Yahweh do to his enemies?

He will show them his power. 

# What will Yahweh do for the blind?

He will bring the blind by a way they do not know; in paths that they do not know he will lead them. He will turn the darkness into light before them and make the crooked places straight and he will not abandon them. 

# What will happen to those who trust in idols and say to cast metal figures, "You are our gods"?

They will be turned back and completely put to shame. 

# What are the deaf and blind commanded to do?

The deaf are commanded to listen and the blind are commanded to look that they may see. 

# Why does Yahweh command them to listen and see?

He commands them to listen and see because although they saw many things, but did not comprehend; their ears were open but no one really heard. 

# What does Yahweh say is the peoples' condition?

Yahweh said the people were robbed and plundered; they were all trapped in pits, held captive in prisons; they had become plunder with none to deliver them. 

# Who gave Jacob over to the robber, and Israel to the looters?

It was Yahweh who gave them over. 

# Why did Yahweh give Jacob over to the robber and Israel to the looters?

Yahweh gave them over because they sinned against Yahweh in whose ways they refused to walk and whose law they refused to obey. 

# Did Israel realize who had inflicted them with the devestation of war and why he had done it?

No! It blazed around them, yet they did not realize it; it burned them, but they did not take it to heart. 

# In general what did Yahweh tell Jacob, Israel, to do?

He told Jacob, Israel, not to be afraid. 

# What did Yahweh say he would do for Israel to protect them?

Yahweh said rivers would not overwhelm Israel and that they wouldn't be harmed or burned by fire or flames. 

# What has Yahweh given in ransom and exchange for Israel?

He has given Egypt as ransom and Ethiopia and Seba in exchange for Israel. 

# What did Yahweh say he would do for Israel's offspring?

Yahweh said he would bring them from the east and gather them from the west. 

# Why did Yahweh predict the gathering of his sons and daughters from the east and the west and announce to them earlier events?

Yahweh did this so that they might know him, believe in him and understand that he is God. 

# Is there any other god or savior than Yahweh?

Before Yahweh no god was formed and there will be none after him. He is Yahweh and there is no savior but him. 

# Is there any other god or savior than Yahweh?

Before Yahweh no god was formed and there will be none after him. He is Yahweh and there is no savior but him. 

# Who can deliver us out of God's hand?

No one can deliver us from God's hand. 

# For whose sake did Yahweh send to Babylon and lead them all down as fugitives, turning the Babylonian's expressions of joy into songs of lamentation?

Yahweh did this for Israel's sake. 

# What former things had Yahweh done that he tells them not to remember or consider?

Yahweh had opened a way through the sea and a path in the mighty waters. He led out the chariot and horse, the army and the mighty host. They fell down together never to rise again. They were extinguished, quenched like a burning wick. 

# What former things had Yahweh done that he tells them not to remember or consider?

Yahweh had opened a way through the sea and a path in the mighty waters. He led out the chariot and horse, the army and the mighty host. They fell down together never to rise again. They were extinguished, quenched like a burning wick. 

# What new thing does Yahweh say he was about to do in the desert and in the wilderness?

Yahweh said he would make a road in the desert and a stream of water in the wilderness. 

# What did this people, Israel, whom Yahweh formed for himself fail to do for Yahweh?

Israel failed to call on Yahweh. They did not bring him any sheep as burnt offerings and they did not honor him with their sacrifices. 

# What did this people, Israel, whom Yahweh formed for himself fail to do for Yahweh?

Israel failed to call on Yahweh. They did not bring him any sheep as burnt offerings and they did not honor him with their sacrifices. 

# What did Israel do to Yahweh?

Israel burdened Yahweh with their sins and wearied him with their evil deeds. 

# Why does Yahweh blot out Israel's offenses and not remember their sins?

Yahweh does this for his own sake. 

# Why was Yahweh going to defile the officials of the sanctuary; handing Jacob over to the destructive ban and Israel to abusive humiliation?

Yahweh was doing this because their first father sinned and their spokesmen had transgressed against Yahweh. 

# Why was Yahweh going to defile the officials of the sanctuary; handing Jacob over to the destructive ban and Israel to abusive humiliation?

Yahweh was doing this because their first father sinned and their spokesmen had transgressed against Yahweh. 

# Why did Yahweh tell Jacob he was going to pour out on Jacob's offspring?

Yahweh said he was going to pour out his spirit on their offspring. 

# How could someone prove to Yahweh that there was someone else like him; another god?

To prove that to Yahweh you would have to explain to him the events that occurred since Yahweh established his ancient people and they would have to declare the events to come. 

# What does Yahweh say concerning those who fashion idols?

Yahweh says they are nothing and that the things they delight in are worthless and they will be put to shame. 

# What will happen to the craftsmen and their associates who form a god or cast an idol?

Craftsmen and their associates who form a god or cast an idol will be put to shame. 

# How does a carpenter start to make an idol?

He cuts down cedar trees, or chooses a cyprus tree or an oak tree. 

# What does the man do with the wood from the tree he has cut down?

The man uses part of it for a fire and warms himself with it, bakes bread with it and roasts his meat over it and with part of it he makes an idol, a god, and bows down to it. 

# What does the man do with the wood from the tree he has cut down?

The man uses part of it for a fire and warms himself with it, bakes bread with it and roasts his meat over it and with part of it he makes an idol, a god, and bows down to it. 

# Because those who make and worship idols are without understanding or knowledge and their eyes are blind and their hearts are unperceiving, what two questions do they not ask themselves? 

First, they don't ask themselves if they should make the other part of the wood into something disgusting to worship. Second, they don't ask themselves if it is reasonable to bow down to a block or wood. 

# Why are Jacob and Israel told to think about Yahweh as the only God and idols as nothing ?

They are to remember these things because Yahweh formed them, they are his servants and he will not forget them. Also Yahweh has blotted out their sins and rebellious deeds. 

# Why are Jacob and Israel told to think about Yahweh as the only God and idols as nothing ?

They are to remember these things because Yahweh formed them, they are his servants and he will not forget them. Also Yahweh has blotted out their sins and rebellious deeds. 

# Why are the heavens, the mountains, the forest and every tree commanded to sing?

They are commanded to sing because Yahweh has redeemed Jacob and will show his glory in Israel. 

# What does Yahweh do to omens and to those who read them?

Yahweh frustrates the omens of the empty talkers and disgraces those who read omens. 

# What does Yahweh do for his servant and messengers?

Yahweh fulfills the declarations of his servant and brings to pass the counsel of his messengers. 

# What did Yahweh say about Jerusalem and the cities of Judah?

He said that Jerusalem would be inhabited and the cities of Judah would be built again and that he would raise up her waste places. 

# What did Yahweh say about Cyrus and what he would do?

Yahweh said of Cyrus, "He is my shepherd, he will do my every wish—he will decree about Jerusalem, 'Let her be rebuilt,' and about the temple, 'Let your foundations be laid.'" 

# In this chapter, who is the Lord's annointed?

In this chapter, Yahweh says Cyrus is his anointed. 

# Why does Yahweh hold Cyrus' hand?

Yahweh holds Cyrus' hand in order to subdue nations before him, to disarm kings, and to open the doors before him, so that gates remain open. 

# Why will Yahweh go before Cyrus and level the mountains, break in pieces the doors of bronze, cut in pieces their iron bars and give him treasures of darkness and riches hidden away?

Yahweh will do these things so that Cyrus will know that it is Yahweh the God of Israel who called him. 

# For whose sake has Yahweh called Cyrus by his name?

Yahweh has done this for Jacob his servants sake and Israel his chosen 

# Did Cyrus know Yahweh?

No, Cyrus did not know Yahweh. 

# Did Cyrus know Yahweh?

No, Cyrus did not know Yahweh. 

# Is there is any other God besides Yahweh?

No, there is no other God except Yahweh. 

# Is there is any other God besides Yahweh?

No, there is no other God except Yahweh. 

# Who formed the light and created darkness and who brings peace and creates disaster?

Yahweh is the one who does all these things. 

# Who created salvation?

Yahweh created salvation. 

# To what thing does Yahweh compare someone who argues with his maker?

He compares someone who argues with his maker to clay that says to the potter, "What are you doing?" or, 'What you were making—did you have no hands when you did it?' 

# What will Cyrus do for Yahweh?

He will build Yahweh's city; he will let Yahweh's exiled people go home and not for price nor bribe. 

# Is there is any other God besides Yahweh?

No, there is no other God except Yahweh. 

# Who will walk in humiliation?

Those who carve idols will walk in humiliation. 

# How long will Israel's salvation last?

Yahweh will save Israel with a everlasting salvation. 

# Is there is any other God besides Yahweh?

No, there is no other God except Yahweh. 

# Why did Yahweh design the earth?

He designed it to be inhabited. 

# Who has no knowledge?

Those who carry carved images and pray to gods who cannot save, have no knowledge. 

# Is there is any other God besides Yahweh?

No, there is no other God except Yahweh. 

# Is there is any other God besides Yahweh?

No, there is no other God except Yahweh. 

# Who does Yahweh swear by?

Yahweh swears by himself. 

# What will every tongue swear?

Every tongue will swear saying, "In Yahweh alone are deliverance and strength." 

# What will happen with all the descendants of Israel?

In Yahweh all the descendants of Israel will be justified; they will take pride in him. 

# What are Bel and Nebo?

They are idols. 

# Who carries Bel and Nebo?

Bel and Nebo are carried by animals. 

# Who carried the house of Jacob?

Yahweh carried the house of Jacob. 

# How long has Yahweh carried the house of Jacob and how long will he carry them?

Yahweh carried them before their birth and will carry them even until their hair is gray. 

# How long has Yahweh carried the house of Jacob and how long will he carry them?

Yahweh carried them before their birth and will carry them even until their hair is gray. 

# What do people do with gold and silver?

The people hire a metalsmith and he takes their gold and silver and make it into a god. 

# Can that god save answer them or save them?

No it cannot answer nor save anyone from his trouble. 

# To whom can Yahweh be compared? Who is like him?

Yahweh is God and there is no other. There is no one like him. 

# What sets Yahweh, God, apart from idols?

Yahweh is set apart by the fact that he announces the end from the beginning, and announces beforehand what has not yet happened. 

# What is Yahweh doing for the stubborn people, who are far from doing what is right?

Yahweh is bringing his righteousness near. He will give deliverance to Zion and his beauty to Israel. 

# What is Yahweh doing for the stubborn people, who are far from doing what is right?

Yahweh is bringing his righteousness near. He will give deliverance to Zion and his beauty to Israel. 

# Who will no longer be called dainty and delicate?

The virgin daughter of Babylon, the daughter of the Chaldeans, will no longer be called dainty and delicate. 

# What will the daughter of the Chaldeans no longer be called?

The daughter of the Chaldeans will no longer be called Queen of kingdoms. 

# Why was Yahweh upset with the Chaldeans?

Yahweh was upset with the Chaldeans because although Yahweh gave his people into the Chaldean's hands, they showed Yahweh's people no mercy and placed a very heavy yoke on the old people. 

# What will happen to the daughter of the Chaldeans in a moment in one day?

The daughter of the Chaldeans will suffer loss of children and widowhood in a moment in one day. 

# What has the daughter of the Chaldeans trusted in?

She has trusted in her wickedness. 

# What did not ward off the disaster and destruction that was coming on the daughters of the Chaldeans?

The incantations of the daughters of the Chaldeans was not able to ward off the disaster and destruction that was coming on them. 

# What will happen to those who chart the heavens and look at the stars, those who declare the new moons?

The men who chart the heavens and look at the stars and those who declare the new moons are the ones who will be like stubble. The fire will burn them up.. 

# Who would save the daughter of the Chaldeans?

There was no one to save them. 

# What is the House of Jacob called and from whom do they descend?

They are called Israel and they are descended from Judah. 

# What is Israel doing insincerely and in unrighteousness?

Israel is swearing by the name of Yahweh and invoking the God of Israel insincerely and in unrighteousness. 

# What did Yahweh do, knowing that Israel was obsinate?

He declared things from long ago and made them known, he suddenly did them and they came to pass. 

# What did Yahweh do, knowing that Israel was obsinate?

He declared things from long ago and made them known, he suddenly did them and they came to pass. 

# By declaring these things to Israel before hand what did Yahweh hope to prevent?

Yahweh wanted prevent Israel from saying, "My idol has done them," or "my carved figure, or my cast metal figure has ordained these things." 

# Why will Yahweh defer his anger and hold back from destroying Israel?

He will do this for the sake of his own name. 

# How did Yahweh purify Israel?

He purified them in the furnace of affliction. 

# Who did Yahweh summon and for what purpose?

Yahweh summoned his ally to accomplish his purpose against Babylon. 

# Who did Yahweh summon and for what purpose?

Yahweh summoned his ally to accomplish his purpose against Babylon. 

# What would have happened if Israel had obeyed Yahweh's commandments?

If they had obeyed their peace and prosperity would have flowed like a river and their deliverance like the waves of the sea. 

# What announcement is to be made to go to the ends of the earth?

The announcement is, "Yahweh has redeemed his servant Jacob". 

# Who did Yahweh say would receive no peace?

Yahweh said there was no peace for the wicked. 

# What did Yahweh do for his servant Israel?

Yahweh called him by name from birth. He made Israel's mouth like a sharp sword and hid Israel in the shadow of his hand; he made Israel into a polished arrow; in his quiver Yahweh hid him. 

# What did Yahweh do for his servant Israel?

Yahweh called him by name from birth. He made Israel's mouth like a sharp sword and hid Israel in the shadow of his hand; he made Israel into a polished arrow; in his quiver Yahweh hid him. 

# What is Yahweh going to do through Israel?

Yahweh is going to show his glory through Israel. 

# What is Israel trusting Yahweh for?

Israel says his justice is with Yahweh and his reward is with his God. 

# What is Israel's job as Yahweh's servant?

His job is to resore Jacob again to Yahweh and to gather Israel to him. 

# What is too small a thing for Yahweh's servant?

It is too small a thing to be Yahweh's servant to reestablish the tribes of Jacob, and to restore the survivors of Israel. 

# What further will Yahweh do for his servant?

He will make his servant a light to the gentiles that his servant may be Yahweh's salvation to the ends of the earth. 

# What will happen to the one who is despised, abhored by the nations, a slave of rulers?

Kings will see him and arise, and princes will see him and bow down. 

# When will Yahweh help and answer his servant?

At a time Yahweh decides to show his favor he will answer his servant, and in a day of salvation Yahweh will protect his servant. 

# For what purpose is Yahweh's servant given as a covenant for the people?

He is given as a covenant for the people to rebuild the land, to reassign the desolate inheritance. 

# Who will lead the prisoners?

He who has mercy on the prisoners will lead them. 

# Why are the heavens, earth and mountains supposed to sing and be joyful?

They are to sing and be joyful because Yahweh comforts his people, and will have compassion on his afflicted. 

# What was Yahweh's answer to Zion when they complained; "Yahweh has forsaken me, and the Lord has forgotten me."?

Yahweh's answer to Zion was, "Can a woman forget her baby, nursing at her breast, so she does not have compassion on the son she has borne? Yes, they may forget, but I will not forget you. 

# What was Yahweh's answer to Zion when they complained; "Yahweh has forsaken me, and the Lord has forgotten me."?

Yahweh's answer to Zion was, "Can a woman forget her baby, nursing at her breast, so she does not have compassion on the son she has borne? Yes, they may forget, but I will not forget you. 

# What does Yahweh offer as proof of his concern for Zion?

Yahweh states his proof as follows: "Look , I have inscribed your name on my palms; your walls are continually before me. Your children are hurrying back, while those who destroyed you are departing. Look around and see, they are all gathering and coming to you. 

# What does Yahweh offer as proof of his concern for Zion?

Yahweh states his proof as follows: "Look , I have inscribed your name on my palms; your walls are continually before me. Your children are hurrying back, while those who destroyed you are departing. Look around and see, they are all gathering and coming to you. 

# What does Yahweh offer as proof of his concern for Zion?

Yahweh states his proof as follows: "Look , I have inscribed your name on my palms; your walls are continually before me. Your children are hurrying back, while those who destroyed you are departing. Look around and see, they are all gathering and coming to you. 

# What will the children born during the time of Zion's bereavement say?

The will say, "The place is too cramped for us, make room for us, so we may live here. 

# What will Zion ask herself?

She will ask, "Who has borne these children for me?" and "Who has raised these children?" and finally, "...where did these come from?" 

# Who will bring Zion's sons and daughters back?

The peoples of the nations will bring them back. 

# Can the spoils be taken from the warrior or captives be rescued from a tyrant?

Yes, the captives will be taken away from the warrior and spoils will be rescued; for Yahweh will oppose Zion's adversary and save her children. 

# Can the spoils be taken from the warrior or captives be rescued from a tyrant?

Yes, the captives will be taken away from the warrior and spoils will be rescued; for Yahweh will oppose Zion's adversary and save her children. 

# What will Yahweh do to Zion's oppressors?

He will feed their oppressors with their own flesh. 

# What will all mankind know?

They will know that Yahweh is Zion's savior and redeemer, the mighty one of Jacob. 

# Why was Zion sold and her mother sent away?

Zion was sold because of her sins, and because of her rebellion, her mother was sent away. 

# What happens at Yahweh's rebuke?

At Yahweh's rebuke the sea dries up and he makes the rivers a desert. Yahweh clothes the sky with darkness and cover it with sackcloth. 

# What happens at Yahweh's rebuke?

At Yahweh's rebuke the sea dries up and he makes the rivers a desert. Yahweh clothes the sky with darkness and cover it with sackcloth. 

# What has Yahweh given to his servant?

He has given his servant a tongue as one of those who is taught. 

# What did Yahweh's servant do with the tongue Yahweh gave him?

Yahweh's servant spoke a sustaining word to the weary one. 

# Because he was not rebellious and did not turn away backward, what did Yahweh's servant do?

Yahweh's servant gave his back to those who beat him and his cheeks to those who plucked out his beard; He did not hide his face from acts of shame and spitting. 

# Because he was not rebellious and did not turn away backward, what did Yahweh's servant do?

Yahweh's servant gave his back to those who beat him and his cheeks to those who plucked out his beard; He did not hide his face from acts of shame and spitting. 

# Why does Yahweh's servant say he is not disgraced?

The servant says he is not disgraced because the Lord Yahweh will help him. 

# What will happen to those who accuse Yahweh's servant and declare him guilty?

His accusers will all wear out like a garment; the moth will eat them up. 

# What should the one who fears Yahweh, who obeys the voice of his servant and the one who walks in deep darkness without light, do?

He should trust in the name of Yahweh and lean on his God. 

# What will Yahweh's servant do to all who kindle a fire, who gird on flames?

Yahweh's servant will cause them to lie down in a place of pain. 

# What did Yahweh say those who pursue righteousness should look to?

Yahweh said to look at the rock from which you were chiseled and to the quarry from which you were cut. 

# What did Yahweh do to Abraham?

Yahweh called him, blessed him and made him many. 

# What will happen to the heavens, the earth and its inhabitants?

The heavens will vanish away like smoke, the earth will wear out like a garment; and its inhabitants will die like flies. 

# What will continue forever and never stop working?

Yahweh's righteousness will continue forever and his righteousness will never stop working. 

# To whom is this statement directed to: "Do not fear the insult of men, nor be disheartened by their abuse..."?

That statement is directed to those who know what is right and the people who have Yahweh's law in their heart. 

# Who crushed the sea monster, dried up the sea and made the depths of the sea into a way for the redeemed to pass through?

The arm of Yahweh did these things. 

# Who crushed the sea monster, dried up the sea and made the depths of the sea into a way for the redeemed to pass through?

The arm of Yahweh did these things. 

# What will overtake and what will flee away from the ransomed of Yahweh when they return and come to Zion?

Joy will overtake them and sorrow and mourning will flee away. 

# What will Yahweh do for the one who is bent down?

Yahweh will hurry to release him. 

# What did Jerusalem drink from the hand of Yahweh?

They drank the cup of Yahweh's anger; they drank the bowl, the cup of staggering. 

# Who among all the son's of Jerusalem has been born to guide her?

There is no one among all the sons she has born to guide her. 

# After Yahweh takes away the cup of staggering from Jerusalem who will he give it to?

He will put it into the hand of Jerusalem's tormentors. 

# What will never again happen to Jerusalem?

Never again will the uncircumcised or the unclean enter Jerusalem. 

# Who had recently oppressed Jerusalem?

Assyria had recently oppressed them. 

# In that day why will Yahweh's people know Yahweh's name?

They will know Yahweh's name because his name is slandered continually all the day. 

# In that day why will Yahweh's people know Yahweh's name?

They will know Yahweh's name because his name is slandered continually all the day. 

# Who will see Yahweh's return to Zion?

Every eye of Zion's watchmen will see Yahweh's return to Zion. 

# Why should the ruins of Jerusalem break forth into joyful singing together?

They should do this because Yahweh has comforted his people; he has redeemed Jerusalem. Yahweh has bared his holy arm in the sight of all the nations. 

# Why should the ruins of Jerusalem break forth into joyful singing together?

They should do this because Yahweh has comforted his people; he has redeemed Jerusalem. Yahweh has bared his holy arm in the sight of all the nations. 

# What are those who carry the vessels of Yahweh to do?

They are to leave, touch nothing unclean and purify themselves. 

# Why do Yahweh's people not need to be in a rush or panic when they leave?

They don't need to be in a rush or panic because Yahweh will go before them and the God of Israel will be their rearguard. 

# What will Yahweh's servant do?

He will deal wisely and be successful; he will be exalted and lifted high, and will be very exalted. 

# What happened to the appearance of Yahweh's servant?

His appearance was disfigured from human appearance. 

# What will kings do because of Yahweh's servant?

Kings will close their mouths because of him. 

# How did Yahweh's servant grow up?

He grew up before Yahweh like a sapling, and like a sprout out of parched earth. 

# What did Yahweh's servant look like?

He had no remarkable appearance or splendor; when we saw him, there was no beauty to attract us to him. 

# How was Yahweh's servant received by people?

He was despised and rejected by people and considered insignificant. 

# What did Yahweh's servant do for us?

He bore our sicknesses and carried our sorrows. 

# Why was Yahweh's servant pierced and crushed?

He was pierced for our rebellious deeds and crushed because of our sins. 

# What did the servant's punishment and wounds do for us?

His punishment brought us peace and his wounds healed us. 

# How are we like sheep?

We are like sheep because we have all gone astray; we have each turned to his own way. 

# What methods were used to condemn Yahweh's servant?

Coercion and judgment were the methods used to condemn him. 

# Why was Yahweh's servant cut off from the land of the living?

He was cut off because of the offense of his people. 

# Had Yahweh's servant done anything wrong?

No. He had done no violence nor had there been any deceit in his mouth. 

# Why was it Yahweh's will to crush his servant?

It was Yahweh's will so that Yahweh's purpose might be accomplished through him. 

# Why will Yahweh give his servant his portion among the multitudes?

Yahweh will give his servant his portion because he poured out his soul to death and was numbered with the transgressors. He bore the sins of many and made intercession for the transgressions. 

# Why does Yahweh say the barren woman should sing?

He says she should sing, for the children of the desolate one are more than the children of the married woman. 

# What will the descendants of Zion do?

They will conquer nations and resettle desolate cities. 

# Who is Zion's husband?

Yahweh of Hosts, Zion's maker, is their husband. 

# What did Yahweh do to Israel?

He abandoned her for a short time. 

# What will Yahweh do for Israel?

With great compassion Yahweh will gather them. 

# What did Yahweh swear concerning Israel?

He swore he would no longer be angry with them or rebuke them. 

# What will not be shaken and what will not depart from Israel?

Yahweh's covenant of peace with Israel will not be shaken and his convenant faithfulness will not depart from Israel. 

# What will Israel no longer experience?

Israel will no longer experience persecution. 

# What will happen to anyone who stirs up trouble for Israel?

Anyone who stirs up trouble for Israel will fall in defeat. 

# What will happen to everyone who accuses Israel?

Israel will condemn them. 

# What are those who have no money told to buy?

They are told to buy wine and milk without money and without cost. 

# What are those who thirst told to eat?

They are told to eat what is good. 

# Who has Yahweh placed as a witness to the nations and a leader and commander to the peoples?

Yahweh has placed David in that position. 

# Who has Yahweh placed as a witness to the nations and a leader and commander to the peoples?

Yahweh has placed David in that position. 

# Why will a nation that did not know Israel run to them?

They will run to Israel because Yahweh their God, the Holy One of Israel has glorified them. 

# When should Israel seek and call upon Yahweh?

They should seek him while he may be found; call upon him while he is nearby. 

# What are the wicked and the man of sin to do?

Let the wicked leave his path, and the man of sin his thoughts. 

# What will Yahweh do for the one who returns to him?

Yahweh will pity him and will abound in forgiving him. 

# Why are Yahweh's thoughts and ways not Israel's thoughts and ways?

This is so because as the heavens are higher than the earth so are Yahweh's ways higher than their ways and Yahweh's thought than Israel's thoughts. 

# Why are Yahweh's thoughts and ways not Israel's thoughts and ways?

This is so because as the heavens are higher than the earth so are Yahweh's ways higher than their ways and Yahweh's thought than Israel's thoughts. 

# What will happen to the words that go from Yahweh's mouth?

They will accomplish that which Yahweh wishes and it will succeed in that for which he sent it. 

# What is the everlasting sign that will not be cut off?

This is the sign: Israel will go out in joy and be led along peacefully. the mountains and the hills will break out in joyful shouts before them. All the trees of the fields will clap their hands. Instead of the thorn bushes, evergreens will grow and instead of the brier, the myrtle tree will grow. 

# What is the everlasting sign that will not be cut off?

This is the sign: Israel will go out in joy and be led along peacefully. the mountains and the hills will break out in joyful shouts before them. All the trees of the fields will clap their hands. Instead of the thorn bushes, evergreens will grow and instead of the brier, the myrtle tree will grow. 

# Why did Yahweh say to observe what is right and do what is just?

He said this because his deliverance is near and his vindication is about to be revealed. 

# Why did Yahweh say to observe what is right and do what is just?

He said this because his deliverance is near and his vindication is about to be revealed. 

# What shouldn the foreigner and eunuch who have become followers of Yahweh not say?

The foreigner should not say, "Yahweh will certainly exclude me from his people" and the eunuch should not say, "See, I am a dry tree." 

# What will Yahweh do for eunuchs who observe Yahweh's sabbaths, choose what pleases him, and hold fast Yahweh's covenant?

Yahweh will set up a monument doe him, in Yahweh's house and within his walls, that is better than of sons and of daughters. 

# What will Yahweh do for eunuchs who observe Yahweh's sabbaths, choose what pleases him, and hold fast Yahweh's covenant?

Yahweh will set up a monument doe him, in Yahweh's house and within his walls, that is better than of sons and of daughters. 

# What will Yahweh do for foreigners who join themselves to Yahweh to serve him, who worship him and love his name, who observe the sabbath and keeps from defiling it, and who hold fast Yahweh's covenant?

Yahweh will bring them to his holy mountain and make them joyful in his house of prayer; their burnt offerings and sacrifices will be accepted on Yahweh's altar. 

# What will Yahweh do for foreigners who join themselves to Yahweh to serve him, who worship him and love his name, who observe the sabbath and keeps from defiling it, and who hold fast Yahweh's covenant?

Yahweh will bring them to his holy mountain and make them joyful in his house of prayer; their burnt offerings and sacrifices will be accepted on Yahweh's altar. 

# Who is compared to a dumb dog?

Their watchmen are compared to dumb dogs. 

# What have their watchmen and shepherds done?

They have all turned to their own way, each one covetous for unjust gain. 

# What does no one consider or understand about the righteous when they perish?

They don't consider or understand that the righteous are gathered away from evil and enter into peace. 

# What does no one consider or understand about the righteous when they perish?

They don't consider or understand that the righteous are gathered away from evil and enter into peace. 

# Who is merrily mocking and opening the mouth and sticking out the tongue?

The sons of the sorceress, the children of the adulterer and the woman who has prostituted herself do these things. 

# Who is merrily mocking and opening the mouth and sticking out the tongue?

The sons of the sorceress, the children of the adulterer and the woman who has prostituted herself do these things. 

# What else did these who were called children of rebellion and children of deceit do?

They had sex under the oaks, under every green tree. They killed their children in the dry riverbeds, under the rocky overhangs. 

# What are the objects of their devotion?

Some of the smooth things of the river valley are the objects of their devotion. 

# What did these rebellious and deceitful ones do concerning Yahweh?

They deserted Yahweh. 

# What will Yahweh tell these wicked and rebellious ones when they cry out?

Yahweh will tell them to let their collection of idols deliver them. 

# What will happen to these wicked and rebellious ones?

The wind will carry them all away, a breath will carry them all away. 

# What will happen to the ones who take refuge in Yahweh?

They will inherit the land and take possession of Yahweh's holy mountain. 

# Who will dwell with Yahweh in the exalted and holy place?

The ones who are of a crushed and humble spirit will dwell with Yahweh there. 

# What would happen if Yahweh accused man forever?

The man's spirit would faint before Yahweh. 

# Why was Yahweh angry with man?

Yahweh was angry with man because of his violent gain. 

# Even though Yahweh has seen man's ways, what is Yahweh going to do for man?

Yahweh said he would heal him. 

# Even though Yahweh has seen man's ways, what is Yahweh going to do for man?

Yahweh said he would heal him. 

# Who has no peace?

The wicked one has no peace. 

# What did Yahweh command the house of Jacob to be confronted with?

He commanded the house of Jacob to be confronted with their rebellion and sins. 

# How did the house of Jacob seek Yahweh?

They sought him like a nation that practiced righteousness and did not abandon the law of their God. 

# What was the complaint the house of Jacob made to Yahweh concerning them humbling themselves and fasting?

Their complaint to Yahweh was that when they fasted and humbled themselves Yahweh didn't see it or notice. 

# What did Yahweh say the house of Jacob did on the day of their fast?

Yahweh said that on the day of their fast they find their own pleasure and oppress all their laborers. 

# What did Yahweh say was not the reason the house of Jacob was fasting?

Yahweh said the house of Jacob was not fasting to make their voice heard above. 

# What is the fast that Yahweh chooses?

The fast that Yahweh chooses is to release wicked bonds, to undo the ropes of the yoke, to set the crushed ones free, to break every yoke, to break their bread with the hungry, to bring the poor and homeless into their houses, to clothe the naked and to not hide themselves from their own relatives. 

# What is the fast that Yahweh chooses?

The fast that Yahweh chooses is to release wicked bonds, to undo the ropes of the yoke, to set the crushed ones free, to break every yoke, to break their bread with the hungry, to bring the poor and homeless into their houses, to clothe the naked and to not hide themselves from their own relatives. 

# What would Yahweh do if the house of Jacob took away from among themselves the yoke, the accusing finger, and the speech of wickedness, if they provided for the hungry and satisfied the need of the distressed?

If they would do these things then their light would rise in the darkness, and their darkness would be like the noonday. . 

# What would Yahweh do if the house of Jacob took away from among themselves the yoke, the accusing finger, and the speech of wickedness, if they provided for the hungry and satisfied the need of the distressed?

If they would do these things then their light would rise in the darkness, and their darkness would be like the noonday. . 

# Can Yahweh save us? Does he hear us?

Yahweh's hand is not so short that it cannot save; nor his ear so dull, that is cannot hear. 

# Why didn't Yahweh hear or save the house of Jacob?

Their sinful acts separated them from their God and their sins made Yahweh hide his face from them and from hearing them. 

# What are some of the sins the house of Jacob committed that separated them from Yahweh?

Some of the sins that separated them from Yahweh were: They stained their hands with blood. They lied and spoke maliciously. They were malicious and untruthful. They conceived trouble. 

# What are some of the sins the house of Jacob committed that separated them from Yahweh?

Some of the sins that separated them from Yahweh were: They stained their hands with blood. They lied and spoke maliciously. They were malicious and untruthful. They conceived trouble. 

# What happens to those who travel crooked paths?

Those who travel crooked paths do not know peace. 

# What happened to him who turned away from evil?

He made himself a victim. 

# What displeased Yahweh?

It displeased Yahweh when he saw there was no justice. 

# What did Yahweh do when he saw there was no one to intervene?

When Yahweh saw there was no one to intervene, his own arm brought salvation for him. 

# Then what did Yahweh do?

He put on righteousness as a breastplate and a helmet of salvation upon his head. He clothed himself with garments of vengeance and wore zeal as a mantle. He repayed them for what they had done, angry judgment to his adversaries, vengeance to his enemies, to the islands punishment as their reward. 

# Then what did Yahweh do?

He put on righteousness as a breastplate and a helmet of salvation upon his head. He clothed himself with garments of vengeance and wore zeal as a mantle. He repayed them for what they had done, angry judgment to his adversaries, vengeance to his enemies, to the islands punishment as their reward. 

# What will be the result of Yahweh repaying them for what they had done?

They will fear the name of Yahweh from the west, and his glory from the sun's rising. 

# Who will a redeemer come to?

A redeemer will come to Zion and to those who turn from their rebellious deeds in Jacob. 

# What is Yahweh's covenant with them?

This is the covenant: Yahweh's spirit who is upon you, and my words which I have put in your mouth, will not leave your mouth, or go out of the mouth of your children, or go out of the mouth of your children's children from this time and forever. 

# Though darkness will cover the earth, what will Yahweh do for Israel?

Yahweh will arise upon them and his glory will be seen on them. 

# Who will come to Israel's light?

Nations and kings will come to their light. 

# Why will Israel look and be radiant and their heart rejoice and overflow?

This will be because the abundance of the sea will be poured out to them, the wealth of the nations will come to them. 

# Who leads in bringing Israel's sons from afar?

The ships of Tarshish lead. 

# Who will rebuild the city of Yahweh and who will serve them?

Sons of foreigners will rebuild their walls and kings will serve them. 

# Why will the gates of the city remain open continually?

They will remain open so that the wealth of the nations may be brought in. 

# What will happen to those nations and kingdoms who will not serve them?

Those nations and kingdoms will perish; they will be completely destroyed. 

# What will Yahweh make the City of Yahweh to be?

He will make her to be a thing of pride forever, a joy from generation to generation. 

# What will no longer be heard in the land of Zion?

Violence will no longer be heard in their land, or devastation nor shattering within their borders. 

# What will give light to the land?

Yahweh will be their everlasting light. 

# What will give light to the land?

Yahweh will be their everlasting light. 

# For how long will Yahweh's people possess the land?

They will take possession of the land for all time. 

# How long will it take for Yahweh to accomplish these things?

Yahweh will swiftly accomplish these things when the time comes. 

# Why is the spirit of the Lord Yahweh upon him?

The spirit is upon him because Yahweh has annointed him. 

# What has Yahweh anointed him to do?

Yahweh has anointed him to proclaim good news to the humble. 

# What are the first three things Yahweh sent him to do?

Yahweh has sent him to heal the brokenhearted, to proclaim liberty to the captives, to open the prison to those who are bound. 

# What will foreigners do in Zion?

They will stand and feed the flocks of those in Zion and the sons of foreigners will work their fields and vineyards. 

# What will those in Zion be called?

They will be called priests of Yahweh; servants of God. 

# What does Yahweh love and what does he hate?

Yahweh loves justice and hates robbery and violent injustice. 

# What has Yahweh done for him?

Yahweh has clothed him with garments of salvation and with the robe of righteousness. 

# What will the Lord Yahweh cause to sprout up in front of all the nations

He will cause righteousness and praise to sprout up in front of all the nations. 

# Who will see Zion's righteousness and glory?

The nations will see Zion's righteousness and all kings will see her glory. 

# What will no longer be said of Zion and her land?

Zion will no longer be called "Abandoned" and her land will no longer be called "Desolate". 

# Why will Zion be called "My delight is in her" and Zion's land "Married"?

She will be called those things because Yahweh delights in her and her land will be married. 

# Why have watchmen been put on the walls of Jerusalem?

They are put there to keep reminding Yahweh, allowing him no rest until he reestablishes Jerusalem and makes it a praise on earth. 

# Why have watchmen been put on the walls of Jerusalem?

They are put there to keep reminding Yahweh, allowing him no rest until he reestablishes Jerusalem and makes it a praise on earth. 

# What has Yahweh sworn by his right hand and by the arm of his strength?

He has sworn that he will no longer give Jerusalem's grain as food for their enemies, and foreigners won't drink her new wine. 

# What does Yahweh announce to the ends of the earth?

This is Yahweh's announcement: "Say to the daughter of Zion, 'Look, your savior is coming! See, his reward is with him, and his reward goes before him.'". 

# What is the one who comes from Edom wearing and how does he come?

He is wearing red royal clothing and he comes marching confidently. 

# Why is the one from Edom marching so confidently?

He is marching confidently because of his great strength. 

# What does this one from Edom say about himself?

He says he speaks righteousness and that he is powerfully able to save. 

# What was this one from Edom looking forward to?

He was looking forward to the day of vengeance, and the year for his redemption had arrived. 

# Was there anyone there to help this one from Edom?

No. He looked but there was no one to help. 

# What did this one from Edom do to the peoples?

He trampled down the peoples in his anger and made them drunk in his wrath and he splashed their blood on the earth. 

# Why and how has Yahweh shown compassion to the house of Israel?

He has shown them compassion because of his mercy and with many deeds of covenant faithfulness. 

# What happened in the ancient times when Yahweh's people suffered?

When the house of Israel suffered, Yahweh suffered. 

# In the ancient times, who saved Israel?

The messenger of his presence saved them in the ancient times. 

# Why did he become their enemy?

He became their enemy because they rebelled and grieved his Holy Spirit. 

# What has been Yahweh's name from ancient times?

His name from ancient times has been "Our Redeemer". 

# What was the complaint or question of the house of Israel to Yahweh?

Their question and complaint was, "Yahweh, why do you make us wander from your ways and harden our hearts, so we do not obey you?" 

# What would happen if Yahweh's name was known by his adversaries?

The nations would tremble at his presence. 

# Since ancient times has anyone heard or perceived of any God besides Yahweh, who does things for those who wait for him?

No, no one has heard or perceived of any God who does things for those who wait for him. 

# What are all of Israel's righteous deeds like?

They are like a menstrual rag. 

# Why were there none who called on Yahweh's name, who made an effort to take hold of him?

This was so because Yahweh hid his face from them and handed them over to their sins. 

# What does the writer compare Yahweh and the people of Israel to?

Yahweh is compared to a potter and the people of Israel are compared to clay. 

# What have Yahweh's holy cities become?

Yahweh's holy cities have become a wilderness and Jerusalem a desolation. 

# What are the two questions the writer has for Yahweh?

The two questions are, "How can you still hold back, Yahweh?" and "How can you remain silent and continue to humiliate us?" 

# What did Yahweh want from those who did not ask and did not seek?

He wanted to be sought out and found by those who did not ask and did not seek. 

# What have these stubborn people walk after?

They have walked after their own thoughts and plans. 

# What are some of the ways these people have been a continual offense to Yahweh?

They are a continual offense to Yahweh because they offer sacrifices in gardens and burn incense on brick tiles. They sit among the graves and keep watch all night and eat pork with the broth of foul meat in their dishes. 

# What are some of the ways these people have been a continual offense to Yahweh?

They are a continual offense to Yahweh because they offer sacrifices in gardens and burn incense on brick tiles. They sit among the graves and keep watch all night and eat pork with the broth of foul meat in their dishes. 

# What did and what will Yahweh do to these stubborn people?

He has paid them back and will repay them for their own sins and the sins of their fathers. 

# What did and what will Yahweh do to these stubborn people?

He has paid them back and will repay them for their own sins and the sins of their fathers. 

# What will Yahweh do for his chosen ones?

They will possess the land. 

# What will Yahweh do to those who abandon Yahweh?

He will destine them for the sword and they will all bow down to the slaughter. 

# What will happen to Yahweh's servants?

They will eat, drink, rejoice and shout with joy. 

# What else will happen to those who abandon Yahweh?

They will be hungry and thirsty. They will be put to shame and cry because of the pain of the heart and wail because of the crushing of the spirit. 

# What will happen to Yahweh's servants?

They will eat, drink, rejoice and shout with joy. 

# What else will happen to those who abandon Yahweh?

They will be hungry and thirsty. They will be put to shame and cry because of the pain of the heart and wail because of the crushing of the spirit. 

# What is Yahweh going to create?

Yahweh is going to create new heavens and a new earth. 

# What will be the response of Yahweh's servants to the new heavens and new earth?

They will be glad and rejoice forever in what Yahweh is about to create. 

# What will the people do in the new Jerusalem?

They will build houses and inhabit them, and they will plant vineyards and eat their fruit. 

# How many days will the people live?

They will live long lives like unto the days of trees. 

# In the new heavens and new earth when will Yahweh hear and answer his people?

While they are still speaking Yahweh will hear them, and before they call he will answer them. 

# What will be different about the animals on all Yahweh's holy mountain?

The animals will no longer hurt or destroy one another. The wolf and the lamb will graze together, and the lion will eat straw like the ox. 

# Who made heaven and earth?

Yahweh made all these things with his own hand. 

# Of what kind of man does Yahweh approve?

Yahweh approves of men who are broken and contrite in spirit and tremble at his word. 

# What examples does Isaiah give to show man's hypocrisy?

Yahweh says a man who slaughters an ox also murders a man. One who sacrifices a lamb also breaks a dog's neck. He who offers a grain offering offers swine's blood and he who offers a memorial of incense also blessed wickedness. 

# What do the brothers of those who tremble at the word of Yahweh do to them?

Their brothers hate and exclude those who tremble at the word of Yahweh. 

# What is the sound that came from the city and the temple?

It was the sound of battle tumult coming from the city, the sound of Yahweh paying back his enemies. 

# Why should all who love Jerusalem rejoice with her and be glad for her?

We should rejoice with Jerusalem and be glad for her, for you will nurse and be satisfied; with her breasts you will be comforted; for you will drink to the full and be delighted with the abundance of her glory. 

# Why should all who love Jerusalem rejoice with her and be glad for her?

We should rejoice with Jerusalem and be glad for her, for you will nurse and be satisfied; with her breasts you will be comforted; for you will drink to the full and be delighted with the abundance of her glory. 

# What is Yahweh about to spread over Jerusalem?

Yahweh is about to spread prosperity over Jerusalem like a river, and the riches of the nations like an overflowing stream. 

# What will Yahweh use to execute judgment on mankind?

He will use fire and his sword. 

# Why will Yahweh gather all nations and languages?

Yahweh will gather all nations and languages so they may come and see his glory and so that some of those who survive can return to their nations to proclaim Yahweh's glory among the nations. 

# Why will Yahweh gather all nations and languages?

Yahweh will gather all nations and languages so they may come and see his glory and so that some of those who survive can return to their nations to proclaim Yahweh's glory among the nations. 

# Who will be given as an offering to Yahweh?

The brothers of Israel from out of all the nations will be given as an offering to Yahweh. 

# What will the people do month to month and sabbath to sabbath?

All people will come and bow down to Yahweh month to month and sabbath to sabbath. 

# What will happen to the dead bodies of the men who have rebelled against Yahweh?

Worms will eat them and fire will consume them. 

