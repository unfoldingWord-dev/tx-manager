# In the genealogy of Jesus Christ, which two ancestors are listed first, indicating their importance?

The two ancestors listed first are David and Abraham. 

# At the end of the genealogy, who is the wife that is named, and why is she listed?

Mary, the wife of Joseph is listed, because by her Jesus was born. 

# What happened to Mary before she had come together with Joseph?

Mary became pregnant by the Holy Spirit before she had come together with Joseph. 

# What kind of man was Joseph?

Joseph was a righteous man. 

# What did Joseph decide to do when he learned Mary was pregnant?

Joseph decided to end the engagement with Mary secretly. 

# What happened to Joseph that made him decide to remain engaged to Mary?

An angel told Joseph in a dream to take Mary as his wife because the baby was conceived by the Holy Spirit. 

# Why was Joseph told to give the baby the name Jesus?

Joseph was told to name the baby Jesus because he will save his people from their sins. 

# What did the Old Testament prophecy say which was fulfilled in these events?

The Old Testament prophecy said that a virgin would give birth to a son, and that they would call his name Emmanuel, which means "God with us". 

# What was Joseph careful not to do until Mary gave birth to Jesus?

Joseph was careful not to sleep with Mary until she gave birth to Jesus. 

# Where was Jesus born?

Jesus was born in Bethlehem of Judea. 

# What title did the learned men from the east give to Jesus?

The learned men from the east gave Jesus the title "King of the Jews". 

# How did the learned men know the King of the Jews had been born?

The learned men had seen the star of the King of the Jews in the east. 

# How did King Herod respond to the news from the learned men?

When King Herod heard the news from the learned men, he was troubled. 

# How did the chief priests and scribes know where the Christ would be born?

They knew the prophecy that said the Christ would be born in Bethlehem. 

# How did the chief priests and scribes know where the Christ would be born?

They knew the prophecy that said the Christ would be born in Bethlehem. 

# How did the learned men find exactly where Jesus was?

The star in the east went before them until it stood over where Jesus was. 

# How old was Jesus when the learned men came to see him?

Jesus was a young child when the learned men came to see him. 

# What gifts did the learned men give to Jesus?

The learned men gave to Jesus gifts of gold, frankincense, and myrrh. 

# By what way did the learned men return home, and why did they go this way?

The learned men returned home another way because God warned them in a dream not to return to Herod. 

# What instructions did Joseph receive in a dream?

Joseph was instructed in a dream to take Jesus and Mary and flee to Egypt, because Herod was going to try to kill Jesus. 

# What prophecy was fulfilled by Jesus' later return from Egypt?

The prophecy, "Out of Egypt I have called my son" was fulfilled when Jesus later returned from Egypt. 

# What did Herod do when the learned men did not return to him?

Herod killed all the male children in the region of Bethlehem who were two years old or younger. 

# What instructions did Joseph receive in a dream after Herod died?

Joseph was instructed in a dream to return to the land of Israel. 

# What instructions did Joseph receive in a dream after Herod died?

Joseph was instructed in a dream to return to the land of Israel. 

# Where did Joseph settle to live with Mary and Jesus?

Joseph settled to live with Mary and Jesus in Nazareth of Galilee. 

# Where did Joseph settle to live with Mary and Jesus?

Joseph settled to live with Mary and Jesus in Nazareth of Galilee. 

# What prophecy was fulfilled when Joseph moved to their new location?

The prophecy that the Christ would be called a Nazarene was fulfilled. 

# What was the message that John the Baptist preached in the wilderness?

John preached, "Repent, for the kingdom of heaven is near". 

# What did the prophecy from Isaiah say that John the Baptist would come to do?

The prophecy said that John the Baptist would make ready the way of the Lord. 

# What did the people do as they were baptized by John?

As they were baptized, the people confessed their sins. 

# What did John the Baptist tell the Pharisees and Sadducees to do?

John the Baptist told the Pharisees and Sadducees to bear fruit worthy of repentance. 

# What did John the Baptist warn the Pharisees and Sadducees not to think among themselves?

John warned the Pharisees and Sadducees not to think among themselves that they had Abraham as their father. 

# According to John, what happens to every tree that does not produce good fruit?

John says that every tree that does not bear good fruit is chopped down and thrown into the fire. 

# How would the one who was coming after John baptize?

The one who was coming after John would baptize with the Holy Spirit and fire. 

# What did Jesus say to John that convinced John to baptize Jesus?

Jesus said that it was right for John to baptize Jesus in order to fulfill all righteousness. 

# What did Jesus see when he came up from the water?

When he came up from the water, Jesus saw the Spirit of God descending as a dove and appearing on him. 

# What did the voice from heaven say after Jesus was baptized?

The voice from heaven said, "This is my beloved Son, with whom I am well pleased". 

# Who led Jesus into the wilderness to be tempted by the devil?

The Holy Spirit led Jesus into the wilderness to be tempted by the devil. 

# How long did Jesus fast in the wilderness?

Jesus fasted forty days and forty nights in the wilderness. 

# What was the first temptation that the devil presented to Jesus?

The devil tempted Jesus to turn a stone into bread. 

# What was Jesus' answer to the first temptation?

Jesus said that man shall not live by bread alone, but by every word that comes out of the mouth of God. 

# What was the second temptation that the devil presented to Jesus?

The devil tempted Jesus to throw himself down from the temple. 

# What was the second temptation that the devil presented to Jesus?

The devil tempted Jesus to throw himself down from the temple. 

# What was Jesus' answer to the second temptation?

Jesus said that you must not test the Lord your God. 

# What was the third temptation that the devil presented to Jesus?

The devil tempted Jesus to worship him in return for all the kingdoms of the world. 

# What was the third temptation that the devil presented to Jesus?

The devil tempted Jesus to worship him in return for all the kingdoms of the world. 

# What was Jesus' answer to the third temptation?

Jesus said that you must worship the Lord your God and must serve him only. 

# What was fulfilled by Jesus' move to Capernaum in Galilee?

The prophecy of Isaiah was fulfilled which said that the people in Galilee would see a great light. 

# What was fulfilled by Jesus' move to Capernaum in Galilee?

The prophecy of Isaiah was fulfilled which said that the people in Galilee would see a great light. 

# What message did Jesus then begin to preach?

Jesus preached, "Repent, for the kingdom of heaven has drawn near". 

# How did Peter and Andrew make their living?

Peter and Andrew were fisherman. 

# What did Jesus say he would make Peter and Andrew?

Jesus said that he would make Peter and Andrew fishers of men. 

# How did James and John make their living?

James and John were fisherman. 

# At this time, where did Jesus go to teach?

Jesus taught in the synagogues of Galilee. 

# What kind of people were brought to Jesus, and what did Jesus do with them?

All those who were sick and demon possessed were brought to Jesus, and Jesus healed them. 

# How many people were following Jesus at this time?

Great multitudes were following Jesus at this time. 

# Why are the poor in spirit blessed?

The poor in spirit are blessed because theirs is the kingdom of heaven. 

# Why are those who mourn blessed?

Those who mourn are blessed because they will be comforted. 

# Why are the meek blessed?

The meek are blessed because they will inherit the earth. 

# Why are those who hunger and thirst for righteousness blessed?

Those who hunger and thirst for righteousness are blessed because they will be filled. 

# Why are those who are insulted and persecuted for Jesus' sake blessed?

Those who are insulted and persecuted for Jesus' sake are blessed because great is their reward in heaven. 

# Why are those who are insulted and persecuted for Jesus' sake blessed?

Those who are insulted and persecuted for Jesus' sake are blessed because great is their reward in heaven. 

# How do believers let their light shine before people?

Believers let their light shine before people by doing good deeds. 

# How do believers let their light shine before people?

Believers let their light shine before people by doing good deeds. 

# What did Jesus come to do with the law and the prophets of the Old Testament?

Jesus came to fulfill the law and the prophets of the Old Testament. 

# Who will be called great in the kingdom of heaven?

Those who keep God's commandments and who teach them to others will be called great in the kingdom of heaven. 

# Jesus taught that not only those who murder are in danger of the judgment, but also those who do what?

Jesus taught that not only those who murder, but also those who are angry with their brother are in danger of the judgment. 

# Jesus taught that not only those who murder are in danger of the judgment, but also those who do what?

Jesus taught that not only those who murder, but also those who are angry with their brother are in danger of the judgment. 

# What did Jesus teach we should do if our brother has anything against us?

Jesus taught that we should go and be reconciled to our brother if he has anything against us. 

# What did Jesus teach we should do if our brother has anything against us?

Jesus taught that we should go and be reconciled to our brother if he has anything against us. 

# What did Jesus teach we should do with our accuser before reaching court?

Jesus taught that we should try to come to an agreement with our accuser before reaching court. 

# Jesus taught that it was not only wrong to commit adultery, but also to do what?

Jesus taught that it was not only wrong to commit adultery, but also to lust after a woman. 

# Jesus taught that it was not only wrong to commit adultery, but also to do what?

Jesus taught that it was not only wrong to commit adultery, but also to lust after a woman. 

# What did Jesus say we must do with anything that causes us to sin?

Jesus said that we must get rid of anything that causes us to sin. 

# What did Jesus say we must do with anything that causes us to sin?

Jesus said that we must get rid of anything that causes us to sin. 

# For what cause did Jesus allow divorce?

For the cause of fornication did Jesus allow divorce. 

# What does a husband cause his wife to become if he divorces her wrongly and she remarries?

A husband causes his wife to become an adulteress if he divorces her wrongly and she remarries. 

# Instead of swearing oaths to various earthly things, what does Jesus say our speech should be like?

Jesus says that instead of swearing oaths by all these things we should let our speech be, "Yes, yes," or "No, no". 

# What did Jesus teach we should do with one who is evil toward us?

Jesus taught that we should not resist one who is evil toward us. 

# What did Jesus teach we should do with one who is evil toward us?

Jesus taught that we should not resist one who is evil toward us. 

# What did Jesus teach we should do with our enemies and with those who persecute us?

Jesus taught that we should love and pray for our enemies and for those who persecute us. 

# What did Jesus teach we should do with our enemies and with those who persecute us?

Jesus taught that we should love and pray for our enemies and for those who persecute us. 

# Why did Jesus say that we must not only love those who love us, but also love our enemies?

Jesus said that if we only love those who love us, we do not receive a reward because we are only doing what the Gentiles already do. 

# Why did Jesus say that we must not only love those who love us, but also love our enemies?

Jesus said that if we only love those who love us, we do not receive a reward because we are only doing what the Gentiles already do. 

# What is the reward of those who do their acts of righteousness to be seen by people?

Those who do their acts of righteousness to be seen by people receive the praise of people as their reward. 

# How should we do our acts of righteousness in order to be rewarded by the Father?

We should do our acts of righteousness in private. 

# How should we do our acts of righteousness in order to be rewarded by the Father?

We should do our acts of righteousness in private. 

# What reward do those receive who are hypocrites praying to be seen by people?

Those who are hypocrites praying to be seen by people receive their reward from people. 

# Those who pray in private receive a reward from whom?

Those who pray in private receive a reward from the Father. 

# Why does Jesus say we should not pray with useless repetitions?

Jesus says we should not pray with useless repetitions because the Father knows what we need before we ask him. 

# Where should we ask the Father that his will be done?

We should ask the Father that his will be done on earth, as it is already done in heaven. 

# If we do not forgive others of their debts to us, what will the Father do?

If we do not forgive others of their debts to us, the Father will not forgive our debts. 

# How should we fast so that we receive a reward from the Father?

We should fast without appearing to people as fasting, and then the Father will reward us. 

# How should we fast so that we receive a reward from the Father?

We should fast without appearing to people as fasting, and then the Father will reward us. 

# How should we fast so that we receive a reward from the Father?

We should fast without appearing to people as fasting, and then the Father will reward us. 

# Where should we store up treasure, and why?

We should store up treasure in heaven, because it cannot be destroyed or stolen there. 

# Where should we store up treasure, and why?

We should store up treasure in heaven, because it cannot be destroyed or stolen there. 

# What will be where our treasure is?

Our heart will be where our treasure is. 

# Which two masters must we choose between?

We must choose between God and wealth as our masters. 

# Why should we not worry about food, drink, and clothes?

We should not worry about food, drink, and clothes because the Father even takes care of the birds, and we are of much more value than they. 

# Why should we not worry about food, drink, and clothes?

We should not worry about food, drink, and clothes because the Father even takes care of the birds, and we are of much more value than they. 

# What does Jesus remind us we cannot do by being anxious?

Jesus reminds us that we cannot add one cubit to our lifespan by being anxious. 

# What must we seek first, and all our earthly needs will then be provided?

We must seek first the kingdom and the Father's righteousness, and then all our earthly needs will be provided. 

# What must we do first before we can clearly see to help our brother?

We must first judge ourselves and remove the log from our own eye before we can help our brother. 

# What must we do first before we can clearly see to help our brother?

We must first judge ourselves and remove the log from our own eye before we can help our brother. 

# What must we do first before we can clearly see to help our brother?

We must first judge ourselves and remove the log from our own eye before we can help our brother. 

# What may happen if you give what is holy to the dogs?

If you give what is holy to the dogs, they may trample it and then turn and tear you to pieces. 

# What must we do to receive from the Father?

We must ask, seek, and knock in order to receive from the Father. 

# What does the Father give to those who ask him?

The Father gives good things to those who ask him. 

# What do the law and the prophets teach us about how to treat others?

The law and prophets teach us to do to others what we want people to do to us. 

# To what does the broad way lead?

The broad way leads to destruction. 

# To what does the narrow way lead?

The narrow way leads to life. 

# How can we recognize false prophets?

We can recognize false prophets by the fruit of their lives. 

# How can we recognize false prophets?

We can recognize false prophets by the fruit of their lives. 

# Who will enter into the kingdom of heaven?

Those who do the will of the Father will enter the kingdom of heaven. 

# What will Jesus say to many who have prophesied, driven out demons, and done miracles in Jesus' name?

Jesus will say to them, "I never knew you! Get away from me, you evil-doers"! 

# What will Jesus say to many who have prophesied, driven out demons, and done miracles in Jesus' name?

Jesus will say to them, "I never knew you! Get away from me, you evil-doers"! 

# Who is like the wise man in Jesus' parable of the two houses?

One who hears Jesus' words and obeys them is like the wise man. 

# Who is like the foolish man in Jesus' parable of the two houses?

One who hears Jesus' words and does not obey them is like the foolish man. 

# How did Jesus teach the people compared to how the scribes taught?

Jesus taught the people as one who had authority, not as the scribes taught. 

# Why did Jesus say the healed leper should go to the priest and offer the gift Moses commanded?

Jesus told the healed leper to go to the priest for a testimony to them. 

# What did Jesus say he would do when the centurion told him about his paralyzed servant?

Jesus said he would go to the centurion's house and heal the servant. 

# Why did the centurion say that Jesus didn't need to come to his house?

The centurion said that he was not worthy to have Jesus in his house, and that Jesus could just say the word and heal the servant. 

# What compliment did Jesus give the centurion?

Jesus said that not even in Israel had he found anyone with so much faith as the centurion. 

# Who did Jesus say would come and recline at table in the kingdom of heaven?

Jesus said that many would come from the east and the west and recline at table in the kingdom of heaven. 

# Who did Jesus say would be thrown into outer darkness where there is weeping and gnashing of teeth?

Jesus said that the sons of the kingdom would be thrown into outer darkness. 

# Who did Jesus heal when he entered Peter's house?

Jesus healed Peter's mother-in-law when he entered Peter's house. 

# Who did Jesus heal when he entered Peter's house?

Jesus healed Peter's mother-in-law when he entered Peter's house. 

# What prophecy from Isaiah was fulfilled as Jesus healed all who were demon-possessed and sick?

Isaiah's prophecy, "He himself took our sickness and bore our diseases," was fulfilled. 

# What did Jesus say about the way he lived when the scribe asked to follow him?

Jesus said that he had no permanent home. 

# When a disciple asked to go bury his father before following Jesus, what did Jesus say?

Jesus told the disciple to follow him, and to leave the dead to bury their own dead. 

# When a disciple asked to go bury his father before following Jesus, what did Jesus say?

Jesus told the disciple to follow him, and to leave the dead to bury their own dead. 

# What was Jesus doing in the boat when the great storm arose on the sea?

Jesus was sleeping when the great storm arose on the sea. 

# When the disciples woke Jesus up because they were afraid of dying, what did Jesus say to them?

Jesus said to the disciples, "Why are you afraid, you of little faith"? 

# Why were the disciples marveling at Jesus after there was calm?

The disciples marveled at Jesus because the winds and the sea obeyed him. 

# What kind of men met Jesus when he came to the country of the Gadarenes?

Jesus met two demon-possessed men who were very violent. 

# What was the concern of the demons speaking through the men to Jesus?

The demons were concerned that Jesus had come to torment them before the set time. 

# What happened when Jesus cast out the demons?

When Jesus cast out the demons, they entered a herd of pigs and the pigs rushed into the sea and perished. 

# What did the people beg Jesus to do when they came out of the city to meet him?

The people begged Jesus to leave their region. 

# Why did some of the scribes think that Jesus was blaspheming God?

Some of the scribes thought that Jesus was blaspheming God because Jesus told the paralyzed man that his sins were forgiven. 

# Why did some of the scribes think that Jesus was blaspheming God?

Some of the scribes thought that Jesus was blaspheming God because Jesus told the paralyzed man that his sins were forgiven. 

# Why did some of the scribes think that Jesus was blaspheming God?

Some of the scribes thought that Jesus was blaspheming God because Jesus told the paralyzed man that his sins were forgiven. 

# Why did Jesus say he had told the paralytic that his sins were forgiven, instead of telling him to get up and walk?

Jesus had told the paralytic that his sins were forgiven to demonstrate that he had authority on earth to forgive sins. 

# Why did Jesus say he had told the paralytic that his sins were forgiven, instead of telling him to get up and walk?

Jesus had told the paralytic that his sins were forgiven to demonstrate that he had authority on earth to forgive sins. 

# Why did the people praise God when they saw the paralytic man's sins forgiven and his body healed?

They were overawed and praised God, who had given such authority to men. 

# What was Matthew's occupation before he followed Jesus?

Matthew was a tax collector before he followed Jesus. 

# With whom did Jesus and his disciples eat?

Jesus and his disciples ate with tax collectors and sinful people. 

# Who did Jesus say he came to call to repentance?

Jesus said he came to call sinners to repentance. 

# Why did Jesus say his disciples were not fasting?

Jesus said his disciples were not fasting because he was still with them. 

# When did Jesus say his disciples would fast?

Jesus said his disciples would fast when he was taken away from them. 

# What did the woman with severe bleeding do, and why?

The woman with severe bleeding touched the edge of Jesus' garment thinking that if she only touched his garment, she would be made well. 

# What did the woman with severe bleeding do, and why?

The woman with severe bleeding touched the edge of Jesus' garment thinking that if she only touched his garment, she would be made well. 

# What did Jesus say had made the woman with severe bleeding well?

Jesus said that the woman with severe bleeding had been made well by her faith. 

# Why did the people laugh at Jesus when he entered the Jewish official's house?

The people laughed at Jesus because Jesus said that the girl was not dead, but sleeping. 

# What happened after Jesus raised the girl from the dead?

News about Jesus raising the girl from the dead spread into all that region. 

# What did the two blind men keep shouting at Jesus?

The two blind men kept shouting, "Have mercy on us, Son of David"! 

# Jesus healed the two blind men according to what?

Jesus healed the two blind men according to their faith. 

# After Jesus healed the mute man, what accusation did the Pharisees make against him?

The Pharisees accused Jesus of driving out demons by the ruler of demons. 

# Why did Jesus have compassion on the crowds?

Jesus had compassion on the crowds because they were worried and confused, and were like sheep without a shepherd. 

# For what did Jesus tell his disciples to pray urgently?

Jesus told his disciples to pray urgently that the Lord of the harvest send out laborers into his harvest. 

# What authority did Jesus give his twelve disciples?

Jesus gave his twelve disciples authority to drive out unclean spirits, and to heal all kinds of diseases. 

# What is the name of the disciple who would betray Jesus?

The name of the disciple who would betray Jesus was Judas Iscariot. 

# Where did Jesus send his disciples at this time?

Jesus sent his disciples only to the lost sheep of the house of Israel. 

# Were the disciples to carry any money or extra clothes with them?

No, the disciples were not to carry any money or extra clothes with them. 

# Were the disciples to carry any money or extra clothes with them?

No, the disciples were not to carry any money or extra clothes with them. 

# Where were the disciples to stay when they went from village to village?

The disciples were to find someone worthy in the village and stay there until they left. 

# What would be the judgment on the cities that did not receive the disciples or listen to their words?

The judgment on the cities that did not receive the disciples or listen to their words would be worse than the judgment on Sodom and Gomorrah. 

# What would be the judgment on the cities that did not receive the disciples or listen to their words?

The judgment on the cities that did not receive the disciples or listen to their words would be worse than the judgment on Sodom and Gomorrah. 

# What did Jesus say people would do to the disciples?

Jesus said that people would deliver the disciples up to councils, whip them, and bring them before governors and kings. 

# What did Jesus say people would do to the disciples?

Jesus said that people would deliver the disciples up to councils, whip them, and bring them before governors and kings. 

# Who would speak through the disciples when they were delivered up?

The Spirit of the Father would speak through the disciples when they were delivered up. 

# Who did Jesus say would be saved in the end?

Jesus said that those who endure to the end will be saved. 

# How would those who hated Jesus treat Jesus' disciples?

Those who hated Jesus would also hate his disciples. 

# How would those who hated Jesus treat Jesus' disciples?

Those who hated Jesus would also hate his disciples. 

# Who did Jesus say we are not to fear?

We are not to fear those who kill the body but are unable to kill the soul. 

# Who did Jesus say we are to fear?

We are to fear him who is able to destroy both soul and body in hell. 

# What will Jesus do for everyone who confesses him before men?

Jesus will confess him before the Father in heaven. 

# What will Jesus do for everyone who denies him before men?

Jesus will deny him before the Father in heaven. 

# What kind of divisions did Jesus say he came to bring?

Jesus said that he came to bring divisions even within households. 

# What kind of divisions did Jesus say he came to bring?

Jesus said that he came to bring divisions even within households. 

# What kind of divisions did Jesus say he came to bring?

Jesus said that he came to bring divisions even within households. 

# What will someone find who loses his life for Jesus' sake?

Someone who loses his life for Jesus' sake will find his life. 

# What will someone receive who gives even a cup of cold water to an unimportant disciple?

Someone who gives even a cup of cold water to an unimportant disciple will receive his reward. 

# What did Jesus finish before he departed to teach and preach in the cities?

Jesus finished instructing his twelve disciples before he departed. 

# What was the message John the Baptist sent to Jesus?

John the Baptist sent the message, "Are you the Coming One, or is there another person we should be looking for"? 

# What did Jesus say was happening as evidence that he was the Coming One?

Jesus said the sick were being healed, the dead were being raised, and the needy were being told the good news. 

# What did Jesus promise for those who found no occasion of stumbling in him?

Jesus promised a blessing for those who found no occasion of stumbling in him. 

# What did Jesus say was the role John the Baptist played in his life?

Jesus said that John the Baptist was the prophesied messenger who would prepare the way before the Coming One. 

# What did Jesus say was the role John the Baptist played in his life?

Jesus said that John the Baptist was the prophesied messenger who would prepare the way before the Coming One. 

# Who did Jesus say that John the Baptist was?

Jesus said that John the Baptist was Elijah. 

# What did that generation say about John the Baptist who came not eating bread or drinking wine?

That generation said that John the Baptist had a demon. 

# What did that generation say about Jesus who came eating and drinking?

That generation said that Jesus was a glutton and a drunkard, and a friend of tax collectors and sinners. 

# What did Jesus declare regarding the cities where his great deeds were done, yet they had not repented?

Jesus rebuked the cities where his great deeds were, yet they had not repented. 

# Jesus praised the Father for concealing the kingdom of heaven from whom?

Jesus praised the Father for concealing the kingdom of heaven from the wise and understanding. 

# Jesus praised the Father for revealing the kingdom of heaven to whom?

Jesus praised the Father for revealing the kingdom of heaven to those who were untaught, like little children. 

# Who did Jesus say knows the Father?

Jesus said that he knows the Father, and anyone to whom he desires to reveal him. 

# To whom did Jesus promise rest?

Jesus promised rest to all who labor and are heavy burdened. 

# What were Jesus' disciples doing that the Pharisees complained about to him?

The Pharisees complained that Jesus' disciples were plucking heads of grain and eating them, which they believed was unlawful to do on the Sabbath. 

# Who did Jesus say was greater than the temple?

Jesus said that he was greater than the temple. 

# What authority does the Son of Man, Jesus, have?

The Son of Man, Jesus, is Lord of the Sabbath. 

# What question did the Pharisees ask Jesus in the synagogue in front of the man with the dried up hand?

The Pharisees asked Jesus, "Is it lawful to heal on the Sabbath"? 

# What did Jesus say it was lawful to do on the Sabbath?

Jesus said it was lawful to do good on the Sabbath. 

# When the Pharisees saw Jesus heal the man with the dried up hand, what did they do?

The Pharisees went out and plotted against him and seeking how they might destroy him. 

# In Isaiah's prophecy about Jesus, who would hear God's judgment and have confidence in Jesus?

The Gentiles would hear God's judgment and have confidence in Jesus. 

# In Isaiah's prophecy about Jesus, what would Jesus not do?

Jesus would not strive, cry aloud, break a bruised reed, or quench smoking flax. 

# In Isaiah's prophecy about Jesus, what would Jesus not do?

Jesus would not strive, cry aloud, break a bruised reed, or quench smoking flax. 

# How did Jesus respond to the accusation that he cast out demons by Beelzebub?

Jesus said that if Satan drives out Satan, then how will Satan's kingdom stand? 

# What did Jesus say was happening if he was driving out demons by the Spirit of God?

Jesus said that the kingdom of God had come upon them if he was driving out demons by the Spirit of God. 

# Which sin did Jesus say will not be forgiven?

Jesus said that blasphemy against the Spirit will not be forgiven. 

# By what is a tree known?

A tree is known by its fruit. 

# By what did Jesus say the Pharisees would be justified and condemned?

Jesus said that the Pharisees would be justified and condemned by their words. 

# What sign did Jesus say he would give his generation?

Jesus said he would give his generation the sign of Jonah, being in the heart of the earth three days and three nights. 

# What sign did Jesus say he would give his generation?

Jesus said he would give his generation the sign of Jonah, being in the heart of the earth three days and three nights. 

# Who did Jesus say was greater than Jonah?

Jesus said that he was greater than Jonah. 

# Why will the men of Nineveh condemn the people of Jesus' generation?

The men of Nineveh will condemn Jesus' generation because they listened to God's word through Jonah, but Jesus' generation did not even listen to the Son of Man who is greater than Jonah. 

# Who did Jesus say was greater than Solomon?

Jesus said that he was greater than Solomon. 

# How will Jesus' generation be like a man who has an unclean spirit go away from him?

Jesus' generation will be like a man who has an unclean spirit go away from him, because the unclean spirit returns with seven other spirits and the final condition of the man becomes worse than the first. 

# How will Jesus' generation be like a man who has an unclean spirit go away from him?

Jesus' generation will be like a man who has an unclean spirit go away from him, because the unclean spirit returns with seven other spirits and the final condition of the man becomes worse than the first. 

# How will Jesus' generation be like a man who has an unclean spirit go away from him?

Jesus' generation will be like a man who has an unclean spirit go away from him, because the unclean spirit returns with seven other spirits and the final condition of the man becomes worse than the first. 

# Who did Jesus say are his brother, sister, and mother?

Jesus said that those who do the will of the Father are his brother, sister, and mother. 

# Who did Jesus say are his brother, sister, and mother?

Jesus said that those who do the will of the Father are his brother, sister, and mother. 

# Who did Jesus say are his brother, sister, and mother?

Jesus said that those who do the will of the Father are his brother, sister, and mother. 

# In Jesus' parable of the sower, what happened to the seed that fell on the wayside?

The seed that fell on the wayside was devoured by the birds. 

# In Jesus' parable of the sower, what happened to the seed that fell on rocky ground?

The seed that fell on rocky ground immediately sprang up, but was scorched by the sun and withered away. 

# In Jesus' parable of the sower, what happened to the seed that fell on rocky ground?

The seed that fell on rocky ground immediately sprang up, but was scorched by the sun and withered away. 

# In Jesus' parable of the sower, what happened to the seed that fell among the thorn plants?

The seed that fell among the thorn plants was choked by the thorn plants. 

# In Jesus' parable of the sower, what happened to the seed that fell on good soil?

The seed that fell on good soil produced grain, some one hundred times as much, some sixty, and some thirty. 

# Isaiah's prophecy said that the people would hear and see, but not what?

Isaiah's prophecy said that the people would hear, but would not understand; they would see, but in no way perceive. 

# What was wrong with the people who heard Jesus but did not understand?

The people who heard Jesus but did not understand had dull hearts, were heavy of hearing, and had closed their eyes. 

# In the parable of the sower, what kind of person is the seed sown on the wayside?

The seed sown on the wayside is the person who hears the word of the kingdom but does not understand it, then the evil one comes and snatches away what has been sown in his heart. 

# In the parable of the sower, what kind of person is the seed sown on the rocky ground?

The seed sown on the rocky ground is the person who hears the word and receives it with joy immediately, but stumbles immediately when persecution arises. 

# In the parable of the sower, what kind of person is the seed sown on the rocky ground?

The seed sown on the rocky ground is the person who hears the word and receives it with joy immediately, but stumbles immediately when persecution arises. 

# In the parable of the sower, what kind of person is the seed sown among the thorn plants?

The seed sown among the thorn plants is the person who hears the word, but the cares of the world and the deceitfulness of riches choke the word. 

# In the parable of the sower, what kind of person is the seed sown on the good soil?

The seed sown on the good soil is the person who hears the word and understands it, and then produces fruit. 

# In the parable of the weeds, who sowed the weeds in the field?

An enemy sowed the weeds in the field. 

# What instructions did the landowner give the servants about the weeds and the wheat?

The landowner told the servants to let both grow together until the harvest, and then to gather the weeds to be burned, and the wheat into the barn. 

# In Jesus' parable of the mustard seed, what happens to the tiny mustard seed?

The mustard seed becomes a tree greater than the garden plants so that the birds nest in its branches. 

# In Jesus' parable of the mustard seed, what happens to the tiny mustard seed?

The mustard seed becomes a tree greater than the garden plants so that the birds nest in its branches. 

# How did Jesus say the kingdom of heaven was like yeast?

Jesus said that the kingdom of heaven was like yeast which was mixed with three measures of flour until it rose. 

# In the parable of the weeds, who sows the good seed, what is the field, who is the good seed, who are the weeds, and who sowed the weeds?

The sower of the good seed is the Son of Man, the field is the world, the good seed are the sons of the kingdom, the weeds are the sons of the evil one, and the sower of the weeds is the devil. 

# In the parable of the weeds, who sows the good seed, what is the field, who is the good seed, who are the weeds, and who sowed the weeds?

The sower of the good seed is the Son of Man, the field is the world, the good seed are the sons of the kingdom, the weeds are the sons of the evil one, and the sower of the weeds is the devil. 

# In the parable of the weeds, who sows the good seed, what is the field, who is the good seed, who are the weeds, and who sowed the weeds?

The sower of the good seed is the Son of Man, the field is the world, the good seed are the sons of the kingdom, the weeds are the sons of the evil one, and the sower of the weeds is the devil. 

# In the parable of the weeds, who are the reapers and what does the harvest represent?

The reapers are the angels, and the harvest is the end of the world. 

# What happens at the end of the world to those who commit iniquity?

At the end of the world, those who commit iniquity are thrown into the furnace of fire. 

# What happens at the end of the world to those who are righteous?

At the end of the world, the righteous shine forth like the sun. 

# In Jesus' parable, what does the man do who finds in a field the treasure, which represents the kingdom of heaven?

The man who finds the treasure sells everything he possesses and buys the field. 

# In Jesus' parable, what does the man do who finds the one pearl of great value, which represents the kingdom of heaven?

The man who finds the one pearl of great value sells everything that he possesses and buys it. 

# In Jesus' parable, what does the man do who finds the one pearl of great value, which represents the kingdom of heaven?

The man who finds the one pearl of great value sells everything that he possesses and buys it. 

# How is the parable of the fishing net like what will happen at the end of the world?

Just as the worthless things from the net were separated from the good and thrown away, at the end of the world the wicked will be separated from the righteous and thrown into the furnace. 

# How is the parable of the fishing net like what will happen at the end of the world?

Just as the worthless things from the net were separated from the good and thrown away, at the end of the world the wicked will be separated from the righteous and thrown into the furnace. 

# What question did the people from his own region ask about Jesus when they heard Jesus teach?

The people asked, "Where does this man get his wisdom from, and these miracles"? 

# What did Jesus say happens to a prophet in his own country?

Jesus said that a prophet is without honor in his own country. 

# What happened in Jesus' own region because of the people's unbelief?

Because of the people's unbelief, Jesus did not do many miracles in his own region. 

# Who did Herod think Jesus was?

Herod thought Jesus was John the Baptist risen from the dead. 

# What was Herod doing unlawfully, about which John the Baptist told him?

Herod had married his brother's wife. 

# Why did Herod not immediately put John the Baptist to death?

Herod did not immediately put John the Baptist to death because he feared the people, who regarded John as a prophet. 

# What did Herod do after Herodias danced for him on his birthday?

Herod promised with an oath to give Herodias whatever she should ask. 

# For what did Herodias ask?

Herodias asked for the head of John the Baptist upon a platter. 

# Why did Herod give Herodias her request?

Herod gave Herodias her request because of his oath and because of all the people at dinner with him. 

# What was Jesus' reaction when he saw the large crowd following him?

Jesus had compassion on them and healed their sick. 

# What did Jesus challenge his disciples to do for the crowd?

Jesus challenged his disciples to give the crowd something to eat. 

# What did Jesus do with the five loaves and the two fish the disciples brought to him?

Jesus looked up to heaven, blessed and broke the loaves and gave them to the disciples to give to the crowd. 

# How many people ate, and how much food was left over?

About five thousand men ate plus women and children, and there were twelve baskets left over. 

# How many people ate, and how much food was left over?

About five thousand men ate plus women and children, and there were twelve baskets left over. 

# What did Jesus do after he sent the crowd away?

Jesus went up on the mountain to pray by himself. 

# What was happening with the disciples in the midst of the sea?

The disciples' boat was almost uncontrollable because of the wind and waves. 

# How did Jesus go to the disciples?

Jesus went to the disciples by walking on the water. 

# What did Jesus tell the disciples when they saw him?

Jesus told his disciples to be brave and to not be afraid. 

# What did Jesus tell Peter to come and do?

Jesus told Peter to come and walk on the water. 

# Why did Peter begin to sink into the water?

Peter began to sink into the water when he became afraid. 

# What happened when Jesus and Peter went into the boat?

When Peter and Jesus went into the boat, the wind ceased blowing. 

# What did the disciples do when they saw this?

When the disciples saw this, they worshiped Jesus and said that he was the Son of God. 

# What did the people do when Jesus and the disciples got to the other side of the sea?

When Jesus and the disciples got to the other side of the sea, the people brought to Jesus all who were sick. 

# What example did Jesus give of how did the Pharisees made void the word of God by their traditions?

The Pharisees prevented children from helping their parents by taking the money as a "gift given to God". 

# What example did Jesus give of how did the Pharisees made void the word of God by their traditions?

The Pharisees prevented children from helping their parents by taking the money as a "gift given to God". 

# What example did Jesus give of how did the Pharisees made void the word of God by their traditions?

The Pharisees prevented children from helping their parents by taking the money as a "gift given to God". 

# What did Isaiah prophecy about the Pharisees' lips and hearts?

Isaiah prophesied that the Pharisees would honor God with their lips, but their heart would be far from God. 

# What did Isaiah prophecy about the Pharisees' lips and hearts?

Isaiah prophesied that the Pharisees would honor God with their lips, but their heart would be far from God. 

# Instead of teaching the word of God, what were the Pharisees teaching as doctrine?

The Pharisees were teaching as doctrines the commands of people. 

# What did Jesus say does not defile a person?

Jesus said that what a person eats does not defile a person. 

# What did Jesus say does defile a person?

Jesus said that what comes out of a person's mouth defiles a person. 

# What did Jesus call the Pharisees, and what did he say would happen to them?

Jesus called the Pharisees blind guides, and said that they would fall into a pit. 

# What kinds of things proceed from the heart which defile a person?

From the heart proceeds evil thoughts, murder, adultery, sexual immorality, theft, false witness, and insults. 

# What did Jesus do at first when the Canaanite woman shouted out to him for mercy?

Jesus answered her not a word. 

# What was Jesus' explanation of why he was not helping the Canaanite woman?

Jesus explained that he had been sent only to the lost sheep of the house of Israel. 

# When the Canaanite woman humbled herself, what did Jesus say to her and do for her?

Jesus said that the woman had great faith, and he granted her her wish. 

# What did Jesus do for the large crowds that came to him in Galilee?

Jesus healed the mute, the crippled, the lame, and the blind. 

# What did Jesus do for the large crowds that came to him in Galilee?

Jesus healed the mute, the crippled, the lame, and the blind. 

# How many loaves and fish did the disciples have to feed the crowd?

The disciples had seven loaves, and a few small fish. 

# What did Jesus do with the loaves and fish?

Jesus took the loaves and the fish, gave thanks, broke the loaves and gave them to his disciples. 

# How much food was left over after everyone ate?

There were seven baskets full remaining after everyone ate. 

# How many people ate and were satisfied from the loaves and fish?

Four thousand men, plus women and children, ate and were satisfied. 

# What did the Pharisees and Sadducees want to see from Jesus as a test?

The Pharisees and Sadducees wanted to see a sign from heaven from Jesus. 

# What did Jesus say he would give the Pharisees and Sadducees?

Jesus said he would give the Pharisees and Sadducees the sign of Jonah. 

# Of what did Jesus tell his disciples to beware?

Jesus told his disciples to beware the yeast of the Pharisees and Sadducees. 

# About what was Jesus actually talking when he told his disciples to beware?

Jesus was telling his disciples to beware the teaching of the Pharisees and Sadducees. 

# What question did Jesus ask his disciples when they came to Caesarea Philippi?

Jesus asked his disciples, "Who do people say that the Son of Man is"? 

# Who did some people think that Jesus was?

Some people thought that Jesus was John the Baptist, or Elijah, or Jeremiah, or one of the prophets. 

# What answer did Peter give to Jesus' question?

Peter answered, "You are the Christ, the Son of the Living God". 

# How did Peter know the answer to Jesus' question?

Peter knew the answer to Jesus' question because the Father had revealed it to him. 

# What authority did Jesus give to Peter on earth?

Jesus gave to Peter the keys of the kingdom, so that he could bind and loose on earth and it would be bound or loosed in heaven. 

# At this time, what did Jesus begin to tell his disciples plainly?

Jesus began to tell his disciples that he must go to Jerusalem, suffer many things, be killed, and be raised on the third day. 

# What did Jesus tell Peter when Peter objected to what Jesus was describing would happen to him?

Jesus said to Peter, "Get behind me, Satan"! 

# What must anyone do who wants to follow Jesus?

Anyone who wants to follow Jesus must deny himself, and take up his cross. 

# What did Jesus say does not profit a man?

Jesus said that it does not profit a man to gain the whole world, but to forfeit his life. 

# How did Jesus say the Son of Man will come?

Jesus said the Son of Man would come in the glory of his Father with his angels. 

# How will the Son of Man pay every person when he comes?

The Son of Man will pay every person according to his deeds when he comes. 

# Who did Jesus say would see the Son of Man coming in his kingdom?

Jesus said that some standing there with him would see the Son of Man coming in his kingdom. 

# Who went with Jesus up on a high mountain?

Peter, James, and John went with Jesus up on a high mountain. 

# What happened to Jesus' appearance on the mountain?

Jesus was transfigured so that his face shone like the sun, and his garments were as brilliant as the light. 

# Who appeared and talked with Jesus?

Moses and Elijah appeared and talked with Jesus. 

# What did Peter offer to do?

Peter offered to make three tents for the three men. 

# What did the voice out of the cloud say?

The voice out of the cloud said, "This is my beloved Son, in whom I am well pleased; listen to him". 

# What did Jesus command the disciples as they were coming down the mountain?

Jesus commanded the disciples to report their vision to no one until the Son of Man had risen from the dead. 

# What did Jesus say about the teaching of the scribes that Elijah must come first?

Jesus said that Elijah will indeed come and restore all things. 

# Who did Jesus say was the Elijah who had already come, and what had been done to him?

Jesus said John the Baptist was the Elijah who had already come, and they had done whatever they wanted to him. 

# Who did Jesus say was the Elijah who had already come, and what had been done to him?

Jesus said John the Baptist was the Elijah who had already come, and they had done whatever they wanted to him. 

# What had the disciples been able to do for the epileptic boy?

The disciples had not been able to cure the epileptic boy. 

# What had the disciples been able to do for the epileptic boy?

The disciples had not been able to cure the epileptic boy. 

# What had the disciples been able to do for the epileptic boy?

The disciples had not been able to cure the epileptic boy. 

# What did Jesus do for the epileptic boy?

Jesus rebuked the demon, and the boy was cured from that hour. 

# Why were the disciples not able to cure the epileptic boy?

Jesus said that because of their small faith they could not cure the epileptic boy. 

# What did Jesus tell his disciples that made them very sad?

Jesus told his disciples that he would be delivered into the hands of people who would kill him, and that he would be raised up on the third day. 

# What did Jesus tell his disciples that made them very sad?

Jesus told his disciples that he would be delivered into the hands of people who would kill him, and that he would be raised up on the third day. 

# How did Peter and Jesus pay the half-shekel tax?

Jesus told Peter to go to the sea, throw in a hook, and draw in the fish that comes up first, which would have a shekel in its mouth for the tax. 

# What did Jesus say we must do to enter the kingdom of heaven?

Jesus said we must repent and become like little children to enter the kingdom of heaven. 

# Who did Jesus say is the greatest in the kingdom of heaven?

Jesus said that whoever humbles himself like a little child is greatest in the kingdom of heaven. 

# What happens to whoever causes a little one who believes in Jesus to sin?

Whoever causes a little one who believes in Jesus to sin would be better off if a millstone had been hung about his neck and he had been sunk into the sea. 

# What did Jesus say we must do with anything that causes us to stumble?

Jesus said we must throw away anything that causes us to stumble. 

# Why did Jesus say we must not despise the little ones?

We must not despise the little ones because their angels always look on the face of the Father. 

# How is the person who seeks the one lost sheep like the Father in heaven?

It is also not the will of the Father that one of the little ones should perish. 

# How is the person who seeks the one lost sheep like the Father in heaven?

It is also not the will of the Father that one of the little ones should perish. 

# How is the person who seeks the one lost sheep like the Father in heaven?

It is also not the will of the Father that one of the little ones should perish. 

# If your brother sins against you, what is the first thing you should do?

First, you should go and show him his fault between you and him alone. 

# If your brother does not listen, what is the second thing you should do?

Second, you should take with you one or two more brothers as witnesses. 

# If your brother still does not listen, what is the third thing you should do?

Third, you should tell the matter to the church. 

# If your brother still will not listen, what should be done?

Finally, if he will not listen to the church, he should be treated as a Gentile and a tax collector. 

# What did Jesus promise where two or three are gathered in his name?

Jesus promised to be in the midst of two or three gathered in his name. 

# How many times did Jesus say we should forgive our brother?

Jesus said we should forgive our brother seventy times seven times. 

# How many times did Jesus say we should forgive our brother?

Jesus said we should forgive our brother seventy times seven times. 

# What did the servant owe his master, and could he repay his master?

The servant owed his master ten thousand talents, which he could not repay. 

# What did the servant owe his master, and could he repay his master?

The servant owed his master ten thousand talents, which he could not repay. 

# Why did the master forgive the servant his debt?

The master was moved with compassion and forgave the servant his debt. 

# What did the servant do with his fellow-servant who owed him one hundred denarii?

The servant refused to be patient and threw the fellow-servant into prison. 

# What did the master tell the servant he should have done with the fellow-servant?

The master told the servant he should have had mercy on the fellow-servant. 

# What did the master then do to the servant?

The master handed the servant over to the torturers until he would pay all that was owed. 

# What did Jesus say the Father will do if we do not forgive our brother from the heart?

Jesus said the Father will do to us like the master did to the servant if we do not forgive our brother from the heart. 

# What question did the Pharisees ask Jesus to test him?

The Pharisees asked Jesus, "Is it lawful for a man to divorce his wife for any cause?" 

# What did Jesus say had been true from the beginning of creation?

Jesus said that from the beginning of creation, God had made them male and female. 

# Because of the way God had made them male and female, what did Jesus say a man should do?

Jesus said that a man should leave his father and mother and join to his wife. 

# What did Jesus say happens when the husband joins to his wife?

Jesus said that when a husband joins to his wife, the two become one flesh. 

# What did Jesus say happens when the husband joins to his wife?

Jesus said that when a husband joins to his wife, the two become one flesh. 

# What did Jesus say man should not do with what God has joined together?

Jesus said that man should not tear apart what God has joined together. 

# Why did Jesus say Moses had commanded certificates of divorce?

Jesus said that Moses had commanded certificates of divorce because of the hardness of the Jews' hearts. 

# Why did Jesus say Moses had commanded certificates of divorce?

Jesus said that Moses had commanded certificates of divorce because of the hardness of the Jews' hearts. 

# Who did Jesus say commits adultery?

Jesus said that whoever divorces his wife, except for fornication, and marries another commits adultery, and that a man who marries a divorced woman commits adultery. 

# Who did Jesus say could accept being a eunuch?

Jesus said that those who are allowed to accept it can accept being a eunuch. 

# Who did Jesus say could accept being a eunuch?

Jesus said that those who are allowed to accept it can accept being a eunuch. 

# Who did Jesus say could accept being a eunuch?

Jesus said that those who are allowed to accept it can accept being a eunuch. 

# What did the disciples do when some little children were brought to Jesus?

When some little children were brought to Jesus, the disciples rebuked them. 

# What did Jesus say when he saw the little children?

Jesus said to permit the little children to come, for to such ones belongs the kingdom of heaven. 

# What did Jesus tell the young man he must do to enter into eternal life?

Jesus told the man to keep the commandments to enter into eternal life. 

# What did Jesus tell the young man he must do to enter into eternal life?

Jesus told the man to keep the commandments to enter into eternal life. 

# When the young man said he had kept the commandments, what did Jesus tell him to do?

When the young man said he had kept the commandments, Jesus told him to sell what he had and give it to the poor. 

# When the young man said he had kept the commandments, what did Jesus tell him to do?

When the young man said he had kept the commandments, Jesus told him to sell what he had and give it to the poor. 

# How did the young man respond to Jesus' command to sell what he had?

The young man went away sorrowful because he had great possessions. 

# What did Jesus say about the possibility of a rich man entering the kingdom of heaven?

Jesus said that with people it is impossible, but that with God all things are possible. 

# What reward did Jesus promise his disciples who had followed him?

Jesus promised his disciples that in the new birth, they would sit upon twelve thrones, judging the twelve tribes of Israel. 

# What did Jesus say about those who are first now and those who are last now?

Jesus said that those who are first now will be last, and that those who are last now will be first. 

# How much did the landowner agree to pay the workers whom he hired early in the morning?

The landowner agreed to pay the workers hired early in the morning one denarius a day. 

# How much did the landowner agree to pay the workers whom he hired early in the morning?

The landowner agreed to pay the workers hired early in the morning one denarius a day. 

# How much did the landowner say he would pay the workers whom he hired the third hour?

The landowner said he would pay them whatever is right. 

# How much did the workers receive who were hired the eleventh hour?

The workers hired the eleventh hour received one denarius. 

# What complaint did the workers have who were hired early in the morning?

They complained that they had worked the whole day, but had received the same pay as those who worked one hour. 

# What complaint did the workers have who were hired early in the morning?

They complained that they had worked the whole day, but had received the same pay as those who worked one hour. 

# How did the landowner respond to the workers' complaint?

The landowner said he had done the workers no wrong and had paid them what belonged to them. 

# How did the landowner respond to the workers' complaint?

The landowner said he had done the workers no wrong and had paid them what belonged to them. 

# What events did Jesus tell his disciples about in advance as they were going up to Jerusalem?

Jesus told his disciples that he would be delivered to the chief priests and scribes, condemned to death, crucified, and on the third day raised up. 

# What events did Jesus tell his disciples about in advance as they were going up to Jerusalem?

Jesus told his disciples that he would be delivered to the chief priests and scribes, condemned to death, crucified, and on the third day raised up. 

# What events did Jesus tell his disciples about in advance as they were going up to Jerusalem?

Jesus told his disciples that he would be delivered to the chief priests and scribes, condemned to death, crucified, and on the third day raised up. 

# What request did the mother of the sons of Zebedee have for Jesus?

She wanted Jesus to command that her two sons sit at his right and left hand in his kingdom. 

# What request did the mother of the sons of Zebedee have for Jesus?

She wanted Jesus to command that her two sons sit at his right and left hand in his kingdom. 

# Who did Jesus say determined who it was who would sit at his right and left hand in his kingdom?

Jesus said that the Father prepared those places for whom he chose. 

# How did Jesus say that one could be great among his disciples?

Jesus said that whoever wishes to become great must be a servant. 

# Why did Jesus say that he came?

Jesus said that he came to serve and to give his life as a ransom for many. 

# What did the two blind men do who were sitting by the road when Jesus passed by?

The two blind men shouted out, "Lord, Son of David, have mercy on us". 

# Why did Jesus heal the two blind men?

Jesus healed the two blind men because he was moved with compassion. 

# What did Jesus say his two disciples would find in the village opposite them?

Jesus said they would find a donkey tied up, and a colt with her. 

# What had a prophet predicted about this event?

A prophet predicted that the King would come on a donkey, and on a colt. 

# What had a prophet predicted about this event?

A prophet predicted that the King would come on a donkey, and on a colt. 

# What did the crowd do to the road into Jerusalem that Jesus traveled?

The crowd spread their outer garments onto, and put tree branches onto the road. 

# What did the crowd shout as Jesus went?

The crowd shouted, "Hosanna to the son of David, blessed is he who comes in the name of the Lord, hosanna in the highest". 

# What did Jesus do when he entered the temple of God in Jerusalem?

Jesus cast out all who bought and sold in the temple, and turned over the tables of the money-changers and seats of those who sold pigeons. 

# What did Jesus say the merchants had made the temple of God?

Jesus said that the merchants had made the temple of God a den of robbers. 

# When the chief priests and scribes objected to what the children were shouting about Jesus, what did Jesus say to them?

Jesus quoted the prophet who said that out of the mouths of babes and nursing infants God had perfected praise. 

# When the chief priests and scribes objected to what the children were shouting about Jesus, what did Jesus say to them?

Jesus quoted the prophet who said that out of the mouths of babes and nursing infants God had perfected praise. 

# What did Jesus do to the fig tree, and why?

Jesus caused the fig tree to dry up because it had no fruit on it. 

# What did Jesus do to the fig tree, and why?

Jesus caused the fig tree to dry up because it had no fruit on it. 

# What did Jesus teach his disciples about prayer from the drying up of the fig tree?

Jesus taught his disciples that if they asked in prayer while believing, they would receive. 

# What did Jesus teach his disciples about prayer from the drying up of the fig tree?

Jesus taught his disciples that if they asked in prayer while believing, they would receive. 

# What did Jesus teach his disciples about prayer from the drying up of the fig tree?

Jesus taught his disciples that if they asked in prayer while believing, they would receive. 

# While Jesus was teaching, about what did the chief priests and elders question him?

The chief priests and elders wanted to know by what authority Jesus did these things. 

# What question did Jesus ask the chief priests and elders in return?

Jesus asked them if they thought John the Baptist's baptism was from heaven or from men. 

# Why did the chief priests and scribes not want to answer that John's baptism was from heaven?

They knew that Jesus would then ask them why they did not believe John. 

# Why did the chief priests and scribes not want to answer that John's baptism was from men?

They feared the crowd, who held John to be a prophet. 

# In Jesus' story of the two sons, what did the first son do when told to work in the vineyard?

The first son said he would not go, but changed his mind and went. 

# In Jesus' story of the two sons, what did the first son do when told to work in the vineyard?

The first son said he would not go, but changed his mind and went. 

# What did the second son do when told to work in the vineyard?

The second son said he would go, but then did not go. 

# Which of the two sons did the father's will?

The first son. 

# Why did Jesus say that tax collectors and prostitutes were entering the kingdom of God before the chief priests and scribes?

Jesus said they were entering the kingdom because they believed John, but the chief priests and scribes did not believe John. 

# Why did Jesus say that tax collectors and prostitutes were entering the kingdom of God before the chief priests and scribes?

Jesus said they were entering the kingdom because they believed John, but the chief priests and scribes did not believe John. 

# What did the vine growers do to the servants that the owner sent to get his grapes?

The vine growers beat, killed, and stoned the servants. 

# What did the vine growers do to the servants that the owner sent to get his grapes?

The vine growers beat, killed, and stoned the servants. 

# Who did the owner finally send to the vine growers?

The owner finally sent his own son. 

# What did the vine growers do to the person that the owner sent last?

The vine growers killed the owner's son. 

# What did the vine growers do to the person that the owner sent last?

The vine growers killed the owner's son. 

# What did the people say the owner should then do?

The people said that the owner should destroy the first vine growers and then rent to other vine growers who would pay. 

# What did the people say the owner should then do?

The people said that the owner should destroy the first vine growers and then rent to other vine growers who would pay. 

# In the scriptures that Jesus then quoted, what happens to the stone which the builders reject?

The stone which the builders reject is made the cornerstone. 

# Based on the scripture Jesus quoted, what did he say would happen?

Jesus said that the kingdom of God would be taken away from the chief priests and Pharisees, and would be given to a nation that brings forth its fruits. 

# Why did the chief priests and Pharisees not immediately lay hands on Jesus?

They were afraid of the crowd, because the people regarded Jesus as a prophet. 

# What did those invited to the marriage feast of the king's son do when the king's servants brought the invitation?

Some did not take the invitation seriously and went about their own business, and others laid hands on the king's servants and killed them. 

# What did those invited to the marriage feast of the king's son do when the king's servants brought the invitation?

Some did not take the invitation seriously and went about their own business, and others laid hands on the king's servants and killed them. 

# What did the king do to those first invited to the marriage feast?

The king sent his armies, killed those murderers, and burned their city. 

# Who did the king then invite to the marriage feast?

The king then invited as many people as his servants could find, both bad and good. 

# Who did the king then invite to the marriage feast?

The king then invited as many people as his servants could find, both bad and good. 

# What did the king do to the man who came to the feast without a wedding garment?

The king had him bound and thrown into the outer darkness. 

# What were the Pharisees trying to do to Jesus?

The Pharisees were trying to entrap Jesus in his own talk. 

# What question did the Pharisees' disciples ask Jesus?

They asked Jesus if it was lawful to pay taxes to Caesar or not. 

# How did Jesus answer the question from the Pharisees' disciples?

Jesus said to give to Caesar the things that are Caesar's, and to God the things that are God's. 

# What belief did the Sadducees have about the resurrection?

The Sadducees believed that there was no resurrection. 

# In the Sadducees' story, how many husbands did the wife have?

The woman had seven husbands. 

# In the Sadducees' story, how many husbands did the wife have?

The woman had seven husbands. 

# What two things did Jesus say the Sadducees did not know?

Jesus said the Sadducees did not know the scriptures nor the power of God. 

# What did Jesus say about marriage in the resurrection?

Jesus said that in the resurrection, there is no marriage. 

# How did Jesus show from the scriptures that there is a resurrection?

Jesus quoted the scriptures where God says that he is the God of Abraham, Isaac, and Jacob - the God of the living. 

# What question did the Pharisee lawyer ask Jesus?

The lawyer asked Jesus which is the greatest commandment in the law. 

# What did Jesus say was the great and first commandment?

Jesus said that to love the Lord your God with all your heart, soul, and mind was the great and first commandment. 

# What did Jesus say was the great and first commandment?

Jesus said that to love the Lord your God with all your heart, soul, and mind was the great and first commandment. 

# What did Jesus say was the second commandment?

Jesus said that to love your neighbor as yourself was the second commandment. 

# What question did Jesus ask the Pharisees?

Jesus asked them whose son is the Christ. 

# What answer did the Pharisees give Jesus?

The Pharisees said that the Christ was the son of David. 

# What second question did Jesus then ask the Pharisees?

Jesus then asked them how David could call his son, the Christ, Lord. 

# What answer did the Pharisees give Jesus?

The Pharisees were not able to answer Jesus a word. 

# Since the scribes and Pharisees sat in Moses' seat, what did Jesus tell the people to do with their teaching?

Jesus told the people to do and observe the things the scribes and Pharisees taught from Moses' seat. 

# Since the scribes and Pharisees sat in Moses' seat, what did Jesus tell the people to do with their teaching?

Jesus told the people to do and observe the things the scribes and Pharisees taught from Moses' seat. 

# Why did Jesus say the people should not imitate the scribes and Pharisees' deeds?

Jesus said they should not imitate their deeds because they say things but then do not do them. 

# For what purpose did the scribes and Pharisees do all their deeds?

The scribes and Pharisees did all their deeds to be seen by people. 

# Who did Jesus say is our one Father, and our one teacher?

Jesus said that our one Father is him who is in heaven, and our one teacher is the Christ. 

# Who did Jesus say is our one Father, and our one teacher?

Jesus said that our one Father is him who is in heaven, and our one teacher is the Christ. 

# Who did Jesus say is our one Father, and our one teacher?

Jesus said that our one Father is him who is in heaven, and our one teacher is the Christ. 

# What will God do to the one who exalts himself, and to the one who humbles himself?

God will humble the one who exalts himself, and will exalt the one who humbles himself. 

# What name did Jesus repeatedly call the scribes and Pharisees which described their behavior?

Jesus repeatedly called the scribes and Pharisees hypocrites. 

# What name did Jesus repeatedly call the scribes and Pharisees which described their behavior?

Jesus repeatedly called the scribes and Pharisees hypocrites. 

# When the scribes and Pharisees made a new convert, whose son was he?

When the scribes and Pharisees made a new convert, he was twice a son of hell as they were. 

# What name did Jesus repeatedly call the scribes and Pharisees which described their behavior?

Jesus repeatedly called the scribes and Pharisees hypocrites. 

# Regarding being bound by oaths, what did Jesus say about the teachings of the scribes and Pharisees?

Jesus said that the scribes and Pharisees were blind guides and blind fools. 

# Regarding being bound by oaths, what did Jesus say about the teachings of the scribes and Pharisees?

Jesus said that the scribes and Pharisees were blind guides and blind fools. 

# Even though they had tithed their mint, dill, and cumin, what had the scribes and Pharisees failed to do?

The scribes and Pharisees had failed to do the weightier matters of the law - justice, mercy, and faith. 

# What had the scribes and Pharisees failed to clean?

The scribes and Pharisees had failed to clean the inside of their cup, so the outside could be clean also. 

# What had the scribes and Pharisees failed to clean?

The scribes and Pharisees had failed to clean the inside of their cup, so the outside could be clean also. 

# Of what were the scribes and Pharisees full on the inside?

The scribes and Pharisees were full of extortion, excess, hypocrisy, and iniquity. 

# What had the fathers of the scribes and Pharisees done to God's prophets?

The fathers of the scribes and Pharisees had killed God's prophets. 

# What had the fathers of the scribes and Pharisees done to God's prophets?

The fathers of the scribes and Pharisees had killed God's prophets. 

# What had the fathers of the scribes and Pharisees done to God's prophets?

The fathers of the scribes and Pharisees had killed God's prophets. 

# What judgment were the scribes and Pharisees going to face?

The scribes and Pharisees were going to face the judgment of hell. 

# What did Jesus say the scribes and Pharisees would do to the prophets, wise men, and scribes he would send them?

Jesus said they would kill and crucify some, whip some, and chase some from city to city. 

# As a result of their behavior, what guilt would come upon the scribes and Pharisees?

The guilt of all the righteous blood shed on the earth would come upon the scribes and Pharisees. 

# To which generation did Jesus say all these things would happen?

Jesus said that to this generation all these things would happen. 

# What desire did Jesus have for the children of Jerusalem, and why was it not fulfilled?

Jesus desired to gather the children of Jerusalem together, but they would not agree. 

# How would Jerusalem's house now be left?

Jerusalem's house would now be left abandoned. 

# What did Jesus prophesy concerning the temple in Jerusalem?

Jesus prophesied that not one stone of the temple would be left on another which would not be torn down. 

# After hearing the prophesy about the temple, what did the disciples ask Jesus?

The disciples asked Jesus when these things would happen, and what would be the sign of his coming and the end of the world? 

# What kind of people did Jesus say would lead many astray?

Jesus said many would come saying they are the Christ, leading many astray. 

# What events did Jesus say would be the beginning of birth pains?

Jesus said that wars, famines, and earthquakes would be the beginning of birth pains. 

# What events did Jesus say would be the beginning of birth pains?

Jesus said that wars, famines, and earthquakes would be the beginning of birth pains. 

# What events did Jesus say would be the beginning of birth pains?

Jesus said that wars, famines, and earthquakes would be the beginning of birth pains. 

# What did Jesus say would happen among the believers at this time?

Jesus said that the believers would suffer tribulation and that some would stumble and betray one another. 

# What did Jesus say would happen among the believers at this time?

Jesus said that the believers would suffer tribulation and that some would stumble and betray one another. 

# Who did Jesus say would be saved?

Jesus said that the one who endures to the end will be saved. 

# What will happen with the gospel before the end comes?

The gospel of the kingdom will be preached in the whole world before the end comes. 

# What did Jesus say the believers should do when they see the abomination of desolation standing in the holy place? 

Jesus said the believers should flee to the mountains. 

# What did Jesus say the believers should do when they see the abomination of desolation standing in the holy place? 

Jesus said the believers should flee to the mountains. 

# What did Jesus say the believers should do when they see the abomination of desolation standing in the holy place? 

Jesus said the believers should flee to the mountains. 

# What did Jesus say the believers should do when they see the abomination of desolation standing in the holy place? 

Jesus said the believers should flee to the mountains. 

# How great will the tribulation be in those days?

In those days, the tribulation will be great, greater than any from the beginning of the world. 

# How will the false Christs and false prophets lead many astray?

The false Christs and false prophets will show great signs and wonders to lead many astray. 

# What will the coming of the Son of Man look like?

The coming of the Son of Man will look like lightning shining from east to west. 

# What will happen to the sun, moon, and stars after the tribulation of those days?

The sun and moon will be darkened, and the stars will fall from the sky. 

# What will the tribes of the earth do when they see the Son of Man coming in power and great glory?

The tribes of the earth will beat their breasts. 

# What sound will be heard as the Son of Man sends his angels to gather the elect?

The great sound of a trumpet will be heard when the angels gather the elect. 

# What did Jesus say would not pass away until all these things have occurred?

Jesus said that this generation will not pass away until all these things have occurred. 

# What did Jesus say would pass away, and what would never pass away?

Jesus said that heaven and earth will pass away, but that his words will never pass away. 

# Who knows when these events will occur?

Only the Father knows when these events will occur. 

# How will the coming of the Son of Man be like the days of Noah before the Flood?

The people will be eating and drinking, marrying and giving in marriage, knowing nothing of the coming judgment that will take them away. 

# How will the coming of the Son of Man be like the days of Noah before the Flood?

The people will be eating and drinking, marrying and giving in marriage, knowing nothing of the coming judgment that will take them away. 

# How will the coming of the Son of Man be like the days of Noah before the Flood?

The people will be eating and drinking, marrying and giving in marriage, knowing nothing of the coming judgment that will take them away. 

# What attitude did Jesus say his believers must maintain regarding his coming, and why?

Jesus said that his believers must always be ready, because they do not know what day the Lord will come. 

# What does a faithful and wise servant do while the master is away?

A faithful and wise servant takes care of the master's household while the master is away. 

# What does a faithful and wise servant do while the master is away?

A faithful and wise servant takes care of the master's household while the master is away. 

# What does the master do for the faithful and wise servant when he returns?

When he returns, the master sets the faithful and wise servant over everything that he owns. 

# What does an evil servant do while the master is away?

An evil servant beats his fellow servants and eats and drinks with drunkards while the master is away. 

# What does an evil servant do while the master is away?

An evil servant beats his fellow servants and eats and drinks with drunkards while the master is away. 

# What does the master do with the evil servant when he returns?

When he returns, the master cuts the evil servant in two and sends him to where there is weeping and grinding of teeth. 

# What did the foolish virgins not do when they went to meet the bridegroom?

The foolish virgins did not take any oil with them along with their lamps. 

# What did the wise virgins do when they went to meet the bridegroom?

The wise virgins took containers of oil along with their lamps. 

# When did the bridegroom come, and was this the expected time?

The bridegroom came at midnight, which was later than the expected time. 

# When did the bridegroom come, and was this the expected time?

The bridegroom came at midnight, which was later than the expected time. 

# What happened to the wise virgins when the bridegroom came?

The wise virgins went with the bridegroom to the marriage feast. 

# What happened to the foolish virgins when the bridegroom came?

The foolish virgins had to go buy oil, and when they returned the door to the feast was shut for them. 

# What happened to the foolish virgins when the bridegroom came?

The foolish virgins had to go buy oil, and when they returned the door to the feast was shut for them. 

# What happened to the foolish virgins when the bridegroom came?

The foolish virgins had to go buy oil, and when they returned the door to the feast was shut for them. 

# What did Jesus say he wanted the believers to learn from the parable of the virgins?

Jesus said that the believers should watch, for they do not know the day or the hour. 

# What did the servants with five and two talents do with their talents when their master went on his journey?

The servant with five talents made another five talents, and the one with two talents made another two. 

# What did the servant with one talent do with the talent when his master went on his journey?

The servant with one talent dug a hole in the ground and hid his master's money. 

# How long was the master away on his journey?

The master was away for a long time. 

# When he returned, what did the master do for the servants who had been given five and two talents?

The master said, "Well done, good and faithful servant!" and put them in charge of many things. 

# When he returned, what did the master do for the servants who had been given five and two talents?

The master said, "Well done, good and faithful servant!" and put them in charge of many things. 

# When he returned, what did the master do to the servant who had been given one talent?

The master said, "You wicked and lazy servant," took the one talent away from him, and threw him into the outer darkness. 

# What will the Son of Man do when he comes and sits on his glorious throne?

The Son of Man will gather all the nations and separate the people one from another. 

# What will the Son of Man do when he comes and sits on his glorious throne?

The Son of Man will gather all the nations and separate the people one from another. 

# What will those on the King's right hand receive?

Those on the King's right hand receive the kingdom prepared for them from the foundation of the world. 

# What did those on the King's right hand do in their lives?

Those on the King's right hand gave food to the hungry, drink to the thirsty, took in strangers, clothed the naked, cared for the sick, and visited the prisoners. 

# What did those on the King's right hand do in their lives?

Those on the King's right hand gave food to the hungry, drink to the thirsty, took in strangers, clothed the naked, cared for the sick, and visited the prisoners. 

# What will those on the King's left hand receive?

Those on the King's left hand receive the eternal fire prepared for the devil and his angels. 

# What did those on the King's left hand not do in their lives?

Those on the King's left hand did not give food to the hungry, drink to the thirsty, take in strangers, clothe the naked, care for the sick, or visit the prisoners. 

# What did those on the King's left hand not do in their lives?

Those on the King's left hand did not give food to the hungry, drink to the thirsty, take in strangers, clothe the naked, care for the sick, or visit the prisoners. 

# What Jewish feast did Jesus say was coming in two days?

Jesus said that the Passover was coming in two days. 

# What were the chief priests and elders plotting at the palace of the chief priest?

They were plotting to arrest Jesus stealthily and to kill him. 

# Of what were the chief priests and elders afraid?

They were afraid that if they killed Jesus during the feast, the people might riot. 

# What was the disciples' reaction when the woman poured the expensive ointment on Jesus' head?

The disciples were angry and wanted to know why the ointment was not sold and the money given to the poor. 

# What was the disciples' reaction when the woman poured the expensive ointment on Jesus' head?

The disciples were angry and wanted to know why the ointment was not sold and the money given to the poor. 

# What was the disciples' reaction when the woman poured the expensive ointment on Jesus' head?

The disciples were angry and wanted to know why the ointment was not sold and the money given to the poor. 

# What was the disciples' reaction when the woman poured the expensive ointment on Jesus' head?

The disciples were angry and wanted to know why the ointment was not sold and the money given to the poor. 

# Why did Jesus say the woman had poured the ointment on him?

Jesus said the woman had poured the ointment on him for his burial. 

# What was Judas Iscariot paid to deliver Jesus into the hands of the chief priests?

Judas was paid thirty pieces of silver to deliver Jesus into the hands of the chief priests. 

# What was Judas Iscariot paid to deliver Jesus into the hands of the chief priests?

Judas was paid thirty pieces of silver to deliver Jesus into the hands of the chief priests. 

# What did Jesus say at the evening meal about one of his disciples?

Jesus said that one of his disciples would betray him. 

# What did Jesus say about the future of the one who would betray him?

Jesus said that it would be better for the man who betrays him if he had never been born. 

# How did Jesus answer when Judas asked if he was the one who would betray Jesus?

Jesus answered, "You have said it yourself". 

# What did Jesus say when he took the bread, blessed it, broke it, and gave it to the disciples?

Jesus said, "Take, eat. This is my body". 

# What did Jesus say about the cup he then gave to the disciples?

Jesus said that the cup was his blood of the covenant that is poured out for many for the forgiveness of sins. 

# At the Mount of Olives, what did Jesus tell his disciples they would all do that night?

Jesus told his disciples that they would all fall away that night because of him. 

# At the Mount of Olives, what did Jesus tell his disciples they would all do that night?

Jesus told his disciples that they would all fall away that night because of him. 

# When Peter said he would never fall away, what did Jesus tell him he would do that night?

Jesus said that Peter would deny Jesus three times that night before the rooster crows. 

# When Peter said he would never fall away, what did Jesus tell him he would do that night?

Jesus said that Peter would deny Jesus three times that night before the rooster crows. 

# What did Jesus ask Peter and the two sons of Zebedee to do while he prayed?

Jesus asked them to remain there and watch with him. 

# What did Jesus ask Peter and the two sons of Zebedee to do while he prayed?

Jesus asked them to remain there and watch with him. 

# What request did Jesus make to the Father in his prayer?

Jesus requested that if it were possible, to let this cup pass from him. 

# What were the disciples doing when Jesus returned from praying?

The disciples were sleeping when Jesus returned from praying. 

# What did Jesus pray be done, no matter Jesus' own will?

Jesus prayed that the Father's will be done, no matter Jesus' own will. 

# How many times did Jesus leave the disciples to go and pray?

Jesus left the disciples three times to go and pray. 

# How many times did Jesus leave the disciples to go and pray?

Jesus left the disciples three times to go and pray. 

# How many times did Jesus leave the disciples to go and pray?

Jesus left the disciples three times to go and pray. 

# What sign did Judas give the crowd to identify Jesus as the one to seize?

Judas kissed Jesus as the sign to the crowd that Jesus was the one to seize. 

# What sign did Judas give the crowd to identify Jesus as the one to seize?

Judas kissed Jesus as the sign to the crowd that Jesus was the one to seize. 

# What did one of Jesus' disciples do when Jesus was seized?

One of Jesus' disciples drew his sword and cut off the ear of the servant of the high priest. 

# What did Jesus say he could do if he wished to defend himself?

Jesus said that he could call upon the Father, who would send twelve legions of angels. 

# What did Jesus say was being fulfilled by these events?

Jesus said that the scriptures were being fulfilled by these events. 

# What did all the disciples then do?

All the disciples then left him and fled. 

# For what were the chief priests and the whole Council looking in order to put Jesus to death?

They were looking for false testimony against Jesus in order to put Jesus to death. 

# What command did the high priest give Jesus by the living God?

The high priest commanded Jesus tell them whether or not he was the Christ, the Son of God. 

# What was Jesus' response to the high priest's command?

Jesus said, "You have said it yourself". 

# What did Jesus say the high priest would see?

Jesus said the high priest would see the Son of Man sitting at the right hand of Power, and coming on the clouds of heaven. 

# What accusation did the high priest then make against Jesus?

The high priest accused Jesus of blasphemy. 

# What did they do to Jesus after they accused him?

They spat in Jesus' face, beat him, and struck him with the palms of their hands. 

# What did Peter answer the three times that someone asked him if he was with Jesus?

Peter answered that he did not know Jesus. 

# What did Peter answer the three times that someone asked him if he was with Jesus?

Peter answered that he did not know Jesus. 

# What happened as soon as Peter answered the third time?

As soon as Peter answered the third time, a rooster crowed. 

# What did Peter answer the three times that someone asked him if he was with Jesus?

Peter answered that he did not know Jesus. 

# What did Peter remember after his third answer?

Peter remembered that Jesus had said that before the rooster crows, he would deny Jesus three times. 

# In the morning, where did the chief priests and elders take Jesus?

In the morning, they took him to Pilate the governor. 

# What did Judas Iscariot do when he saw that Jesus was condemned?

Judas repented of betraying innocent blood, returned the silver, went out, and hanged himself. 

# What did Judas Iscariot do when he saw that Jesus was condemned?

Judas repented of betraying innocent blood, returned the silver, went out, and hanged himself. 

# What did Judas Iscariot do when he saw that Jesus was condemned?

Judas repented of betraying innocent blood, returned the silver, went out, and hanged himself. 

# What did the chief priests do with the thirty pieces of silver?

They bought the Potter's Field in which to bury strangers. 

# What did the chief priests do with the thirty pieces of silver?

They bought the Potter's Field in which to bury strangers. 

# Whose prophecy did these events fulfill?

These events fulfilled the prophecy of Jeremiah. 

# Whose prophecy did these events fulfill?

These events fulfilled the prophecy of Jeremiah. 

# What question did Pilate ask Jesus, and what was Jesus' answer?

Pilate asked Jesus if he was the King of the Jews, and Jesus answered, "You say so". 

# What did Jesus answer to all the accusations of the chief priests and elders?

Jesus did not answer even one word. 

# What did Jesus answer to all the accusations of the chief priests and elders?

Jesus did not answer even one word. 

# What did Jesus answer to all the accusations of the chief priests and elders?

Jesus did not answer even one word. 

# What did Pilate wish to do for Jesus, following the custom of the feast of Passover?

Pilate wished to have Jesus released, following the custom of the feast. 

# What did Pilate wish to do for Jesus, following the custom of the feast of Passover?

Pilate wished to have Jesus released, following the custom of the feast. 

# What message did Pilate's wife send to him as he was sitting on the judgment-seat?

She told Pilate to have nothing to do with that innocent man. 

# Why was Barabbas, and not Jesus released according to the custom of the feast?

The chief priests and elders persuaded the crowd to ask for Barabbas to be released instead of Jesus. 

# What did the crowd cry out that they wanted done with Jesus?

The crowd cried out that they wanted Jesus to be crucified. 

# When Pilate saw a riot was starting, what did he do?

Pilate washed his hands, said he was innocent of this innocent man's blood, and gave Jesus over to the crowd. 

# What did the people say when Pilate handed Jesus to them?

The people said, "May his blood be on us and our children". 

# What did the soldiers of the governor put on Jesus?

The soldiers put a scarlet robe on him and a crown of thorns on his head. 

# What did the soldiers of the governor put on Jesus?

The soldiers put a scarlet robe on him and a crown of thorns on his head. 

# What did the soldiers of the governor put on Jesus?

The soldiers put a scarlet robe on him and a crown of thorns on his head. 

# What was Simon of Cyrene forced to do?

Simon was forced to carry Jesus' cross. 

# Where did they go to crucify Jesus?

They went to Golgotha, which means "The Place of a Skull". 

# What did the soldiers do after they crucified Jesus?

The soldiers cast lots to divide up Jesus' garments and then sat and watched him. 

# What did the soldiers do after they crucified Jesus?

The soldiers cast lots to divide up Jesus' garments and then sat and watched him. 

# What writing did they put above Jesus' head?

They wrote, "THIS IS JESUS THE KING OF THE JEWS". 

# Who was crucified with Jesus?

Two robbers were crucified with Jesus, one on his right and one on his left. 

# What did the people, the chief priests, the scribes, and the elders challenge Jesus to do?

They all challenged Jesus to save himself and come down from the cross. 

# What happened from the sixth to the ninth hour?

Darkness came over the whole land from the sixth to the ninth hour. 

# What did Jesus cry out at the ninth hour?

Jesus cried out, "My God, my God, why have you forsaken me?" 

# What happened after Jesus cried out again with a loud voice?

Jesus gave up his spirit. 

# What happened in the temple after Jesus died?

The curtain of the temple was split in two from the top to the bottom after Jesus died. 

# What happened at the tombs after Jesus died?

Many saints that had fallen asleep were raised and appeared to many after Jesus died. 

# What happened at the tombs after Jesus died?

Many saints that had fallen asleep were raised and appeared to many after Jesus died. 

# Seeing all these events, what was the testimony of the centurion?

The centurion testified, "Truly this was the Son of God". 

# After he was crucified, what happened to the body of Jesus?

A rich disciple of Jesus, Joseph, asked Pilate for the body, wrapped it in linen, and laid it in his own new tomb. 

# After he was crucified, what happened to the body of Jesus?

A rich disciple of Jesus, Joseph, asked Pilate for the body, wrapped it in linen, and laid it in his own new tomb. 

# What was placed across the door of the tomb where Jesus' body was laid?

A large stone was placed across the door of the tomb where Jesus' body was laid. 

# Why did the chief priests and the Pharisees gather with Pilate the next day?

The chief priests and the Pharisees wanted to make sure that Jesus' tomb was secure so that no one could steal the body. 

# Why did the chief priests and the Pharisees gather with Pilate the next day?

The chief priests and the Pharisees wanted to make sure that Jesus' tomb was secure so that no one could steal the body. 

# Why did the chief priests and the Pharisees gather with Pilate the next day?

The chief priests and the Pharisees wanted to make sure that Jesus' tomb was secure so that no one could steal the body. 

# What did Pilate permit them to do at the tomb?

Pilate permitted them to seal the stone and place a guard at the tomb. 

# What did Pilate permit them to do at the tomb?

Pilate permitted them to seal the stone and place a guard at the tomb. 

# What day and time did Mary Magdalene and the other Mary go to Jesus' tomb?

As it began to dawn toward the first day of the week, they went to Jesus' tomb. 

# How was the stone rolled away from Jesus' tomb?

An angel of the Lord descended and rolled away the stone. 

# What did the guards do when they saw the angel?

The guards shook with fear and became like dead men when they saw the angel. 

# What did the angel say to the two women about Jesus?

The angel said that Jesus had risen and was going ahead of them to Galilee. 

# What did the angel say to the two women about Jesus?

The angel said that Jesus had risen and was going ahead of them to Galilee. 

# What did the angel say to the two women about Jesus?

The angel said that Jesus had risen and was going ahead of them to Galilee. 

# What happened to the two women on their way to tell the disciples?

The women met Jesus, and they took hold of his feet and worshiped him. 

# What happened to the two women on their way to tell the disciples?

The women met Jesus, and they took hold of his feet and worshiped him. 

# When the guards told the chief priests what had happened at the tomb, what did the chief priests do?

The chief priests paid the soldiers a large amount of money and told them to say that Jesus' disciples had stolen the body. 

# When the guards told the chief priests what had happened at the tomb, what did the chief priests do?

The chief priests paid the soldiers a large amount of money and told them to say that Jesus' disciples had stolen the body. 

# When the guards told the chief priests what had happened at the tomb, what did the chief priests do?

The chief priests paid the soldiers a large amount of money and told them to say that Jesus' disciples had stolen the body. 

# What did the disciples do when they saw Jesus in Galilee?

The disciples worshiped Jesus, but some doubted. 

# What authority did Jesus say had been given to him?

Jesus said that all authority in heaven and on earth had been given to him. 

# What did Jesus command his disciples to do?

Jesus commanded his disciples to go and make disciples, and to baptize them. 

# Into what name did Jesus tell his disciples to baptize?

Jesus told his disciples to baptize in the name of the Father, of the Son, and of the Holy Spirit. 

# What did Jesus command his disciples to teach?

Jesus commanded his disciples to teach the nations to obey all the things he had commanded. 

# What final promise did Jesus give his disciples?

Jesus promised to be with them, even to the end of the world. 

