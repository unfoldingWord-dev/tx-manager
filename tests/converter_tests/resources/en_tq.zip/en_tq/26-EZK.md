# Among whom was Ezekiel living when he had visions of God?

Ezekiel was living among the captives in the land of the Chaldeans when he had visions of God. 

# Among whom was Ezekiel living when he had visions of God?

Ezekiel was living among the captives in the land of the Chaldeans when he had visions of God. 

# Among whom was Ezekiel living when he had visions of God?

Ezekiel was living among the captives in the land of the Chaldeans when he had visions of God. 

# What was in the middle of the great cloud Ezekiel saw coming from the north?

In the middle of the cloud was the likeness of four living creatures, each with four faces and four wings. 

# What was in the middle of the great cloud Ezekiel saw coming from the north?

In the middle of the cloud was the likeness of four living creatures, each with four faces and four wings. 

# What was in the middle of the great cloud Ezekiel saw coming from the north?

In the middle of the cloud was the likeness of four living creatures, each with four faces and four wings. 

# How did the creatures move?

The creatures did not turn as the went but each one went straight forward. 

# What appearances did the living creatures have on their faces?

Their faces had the appearance of a man, a lion, an ox, and an eagle. 

# What was directing the movement of the four living creatures?

The Spirit was directing the movement of the four living creatures. 

# As the four living creatures moved back and forth, what did they look like?

As they moved, the four living creatures looked like lightning. 

# What were the four wheels beside the four living creatures able to do?

The four wheels were able to go in any direction without turning. 

# Why did the wheels go wherever the living creatures went?

The wheels followed the living creatures because the spirit of the living creatures was in the wheels. 

# Why did the wheels go wherever the living creatures went?

The wheels followed the living creatures because the spirit of the living creatures was in the wheels. 

# What was over the heads of the living creatures?

An expansive dome was over the heads of the living creatures. 

# What did the living creatures do with their wings?

Each one of the creature's wings stretched out straight and touched another creature's wings and each of the living creatures also had a pair of wings to cover his own body. 

# What does Ezekiel say the creatures' wings sounded like?

The creatures' wings sounded like rushing water, like the voice of the Almighty, like a rainstorm, and like an army. 

# What was above the dome, which was over the creatures' heads?

Above the dome was a throne, and on the throne was the appearance of one who looked like a man. 

# As what did the bright figure appear to Ezekiel?

The bright figure appeared as the likeness of the glory of Yahweh. 

# What did Ezekiel do when he saw the bright figure?

When he saw the bright figure, Ezekiel fell on his face. 

# What did the Spirit do to Ezekiel as the Spirit spoke to Ezekiel?

The Spirit stood Ezekiel on his feet as he spoke to Ezekiel. 

# To whom did the Spirit send Ezekiel?

The Spirit sent Ezekiel to the people of Israel. 

# According to the Spirit, what kind of people were the descendants of Israel?

The descendants were a stubborn, hardhearted and rebellious people. 

# What was Ezekiel to say to the people of Israel?

Ezekiel was to say, "This is what the Lord Yahweh says," to the people of Israel. 

# According to the Spirit, what kind of people were the descendants of Israel?

The descendants were a stubborn, hardhearted and rebellious people. 

# What would the people of Israel know because of Ezekiel's speaking to them?

The people of Israel would know that a prophet had been among them. 

# What did the Spirit tell Ezekiel not to do as he spoke to the people of Israel?

The Spirit told Ezekiel not to be afraid of the people of Israel as he spoke to them. 

# How was Ezekiel supposed to be different than the people of Israel?

Ezekiel was not to be rebellious like the people of Israel. 

# What was spread out before Ezekiel?

A written scroll was spread out before Ezekiel. 

# What was written on the scroll?

On the scroll were written lamentations, mourning, and woe. 

# What did the Spirit give to Ezekiel and what did Ezekiel do with it?

The Spirit gave Ezekiel a scroll and Ezekiel ate it. 

# What did the Spirit give to Ezekiel and what did Ezekiel do with it?

The Spirit gave Ezekiel a scroll and Ezekiel ate it. 

# What did the Spirit give to Ezekiel and what did Ezekiel do with it?

The Spirit gave Ezekiel a scroll and Ezekiel ate it. 

# What did the Spirit tell Ezekiel to go and do?

The Spirit told Ezekiel to go and speak the Spirit's words to the house of Israel. 

# According to the Spirit, if Ezekiel had been sent to a foreign people, how would they have responded to Ezekiel's words?

If Ezekiel had been sent to a foreign people, they would have listened to Ezekiel's words. 

# According to the Spirit, how would the house of Israel respond to Ezekiel's words?

The house of Israel would not be willing to listen to Ezekiel's words. 

# How has the Spirit made Ezekiel so that he will not be fearful or discouraged?

The Spirit has made Ezekiel stubborn, and his brow like a diamond. 

# How has the Spirit made Ezekiel so that he will not be fearful or discouraged?

The Spirit has made Ezekiel stubborn, and his brow like a diamond. 

# What did the great sound behind Ezekiel say to him?

The great sound said, "Blessed be the glory of Yahweh from his place!" 

# What did Ezekiel then do for seven days, and what was his condition?

Ezekiel stayed with the captives for seven days, overwhelmed in amazement. 

# What did Yahweh say he had made Ezekiel for the house of Israel?

Yahweh said he had made Ezekiel a watchman for the house of Israel. 

# What did Yahweh say would happen to Ezekiel if he did warn the wicked about their evil deeds?

If Ezekiel did warn the wicked, then Ezekiel would rescue himself. 

# What did Yahweh say would happen to Ezekiel if he did not warn the wicked about their evil deeds?

If Ezekiel did not warn the wicked, Yahweh would require their blood from Ezekiel's hand. 

# What did Yahweh say would happen to Ezekiel if he did not warn the righteous man who turns and acts unjustly?

If Ezekiel did not warn the righteous man who turns, Yahweh would require his blood from Ezekiel's hand. 

# What did Yahweh say would happen to the righteous man who turns and acts unjustly?

Yahweh said the righteous man who turns and acts unjustly would die in his sin. 

# What did Yahweh say would happen to Ezekiel if he did warn the righteous man who turns and acts unjustly?

If Ezekiel did warn the righteous man who turns, then Ezekiel would rescue himself. 

# What did Ezekiel do when he saw the glory of Yahweh in the plain?

When Ezekiel saw the glory of Yahweh, he fell on his face. 

# What did the Spirit tell Ezekiel to go and do?

The Spirit told Ezekiel to go and shut himself up in his house. 

# What did the Spirit say Ezekiel would not be able to do by his own words?

The Spirit said Ezekiel would not be able to rebuke the house of Israel by his own words. 

# What did the Spirit say Ezekiel would be able to do when the Spirit spoke to him?

The Spirit said Ezekiel would be able to open his mouth and say, "Thus says the Lord Yahweh," when the Spirit spoke to him. 

# What did Yahweh tell Ezekiel to do with a brick?

Yahweh told Ezekiel to carve the city of Jerusalem on a brick and then lay siege against it. 

# What did Yahweh tell Ezekiel to do with a brick?

Yahweh told Ezekiel to carve the city of Jerusalem on a brick and then lay siege against it. 

# What did Yahweh tell Ezekiel to do with a brick?

Yahweh told Ezekiel to carve the city of Jerusalem on a brick and then lay siege against it. 

# Why did Yahweh tell Ezekiel to do this with a brick?

Yahweh told Ezekiel to do this as a sign to the house of Israel. 

# Why did Yahweh tell Ezekiel to lie on his left side?

Yahweh told Ezekiel to lie on his left side to carry the sin of the house of Israel. 

# Why was Ezekiel to lie on his left side for 390 days?

Ezekiel was to lie on his left side for 390 days to represent 390 years of punishment for the house of Israel. 

# Why was Ezekiel to lie on his right side?

Ezekiel was to lie on his right side to carry the sin of the house of Israel. 

# Why was Ezekiel to lie on his right side for 40 days?

Ezekiel was to lie on his right side for 40 days to represent 40 years of punishment for the house of Israel. 

# What did Yahweh tell Ezekiel to eat and drink while he lay on his side?

Yahweh told Ezekiel to eat barley cakes and to drink water. 

# What did Yahweh tell Ezekiel to eat and drink while he lay on his side?

Yahweh told Ezekiel to eat barley cakes and to drink water. 

# What did Yahweh tell Ezekiel to eat and drink while he lay on his side?

Yahweh told Ezekiel to eat barley cakes and to drink water. 

# Why did Yahweh tell Ezekiel to bake using human excrement within the sight of the house of Israel?

Ezekiel was to bake using human excrement as a sign that the food the people of Israel would eat among the nations would be unclean. 

# Why did Yahweh tell Ezekiel to bake using human excrement within the sight of the house of Israel?

Ezekiel was to bake using human excrement as a sign that the food the people of Israel would eat among the nations would be unclean. 

# Why did Yahweh then allow Ezekiel to use cow dung instead of man's dung to bake?

Yahweh allowed cow dung because Ezekiel had never eaten anything unclean in his life. 

# Why did Yahweh then allow Ezekiel to use cow dung instead of man's dung to bake?

Yahweh allowed cow dung because Ezekiel had never eaten anything unclean in his life. 

# What did Yahweh say would happen in Jerusalem regarding food and drink?

Yahweh said that bread and water would be rationed. 

# What did Yahweh say would happen to the people of Jerusalem during this time?

Yahweh said the people of Jerusalem would be dismayed and would melt away. 

# What was Ezekiel do to with each third of his hair?

Ezekiel was to burn a third in the city, strike a third with the sword around the city, and scatter a third to the wind. 

# What did Yahweh say he would do after Ezekiel was finished?

Yahweh said he would draw out a sword to chase after the people. 

# According to Yahweh, where is Jerusalem?

Jerusalem is in the midst of the nations. 

# Why does Yahweh say he has surrounded Jerusalem with other lands?

Jerusalem rejected Yahweh's decrees and did not walk in his statutes (laws). 

# What does Yahweh say he will do because of the nation of Israel's behavior?

Yahweh says he will act against the nation of Israel and execute judgments within its midst. 

# What horrible things will the people of Israel do because of Yahweh's judgment on them?

Fathers will eat their children, and sons will eat their fathers. 

# Why does Yahweh say he is not going to spare the people of Israel?

Yahweh says will not spare them because they defiled Yahweh's sanctuary. 

# What will Yahweh do with each third of the people?

A third will die by plague, a third will fall by the sword, and a third will be scattered. 

# What did Yahweh say he would do after the thirds of the people were judged?

Yahweh said he would draw out a sword to chase after the people. 

# What does Yahweh say he will do with his wrath after this judgment?

Yahweh says his wrath will be completed after this judgment. 

# What will other people say about Jerusalem after Yahweh's judgments?

Other people will condemn and mock Jerusalem after Yahweh's judgments. 

# What did Ezekiel prophesy against the high places of Israel?

Ezekiel prophesied that the Lord Yahweh would destroy the high places of Israel with a sword. 

# What did Ezekiel prophesy against the high places of Israel?

Ezekiel prophesied that the Lord Yahweh would destroy the high places of Israel with a sword. 

# What will happen before the idol altars of Israel?

The Lord Yahweh will lay the dead bodies of the people of Israel before the altars. 

# What will happen to the cities of Israel?

The cities of Israel will be laid waste. 

# As a result of all the destruction, what will the people of Israel know?

The people of Israel will know that the Lord is Yahweh. 

# What will the remnant who escapes do after they are scattered?

The remnant will remember Yahweh and will show loathing on their face for their wickedness. 

# What will the remnant who escapes do after they are scattered?

The remnant will remember Yahweh and will show loathing on their face for their wickedness. 

# Why is Yahweh bringing sword, famine, and plague to the house of Israel?

Because of all the evil wickedness of the house of Israel, Yahweh is bringing sword, famine, and plague. 

# What were the people of Israel doing on the mountain peaks and under the trees?

The people of Israel were offering soothing fragrances to all their idols. 

# What will happen to the land when Yahweh strikes?

The land will be a desolate and a waste when Yahweh strikes. 

# According to the word of Yahweh, what was coming to the land of Israel?

According to the word of Yahweh, an end was coming to the land of Israel. 

# According to the word of Yahweh, what was coming to the land of Israel?

According to the word of Yahweh, an end was coming to the land of Israel. 

# Yahweh will judge Israel according to what?

Yahweh will judge Israel according to its ways. 

# What time has come for Israel?

The time of Israel's doom and destruction has come. 

# What is Yahweh pouring out and filling up against Israel?

Yahweh is pouring out his fury and filling up his wrath against Israel. 

# What will not last in Israel?

None of the multitude, none of their wealth, and none of their importance will last. 

# Why should the buyer not rejoice and the seller not mourn in Israel?

The buyer should not rejoice and the seller not mourn because Yahweh's anger is upon the entire multitude. 

# How will those in the city die?

Those in the city will die by famine and plague. 

# To where will the survivors escape?

The survivors will escape to the mountains. 

# What will not be able to deliver the people of Israel?

Their silver and gold will not be able to deliver the people of Israel. 

# What will happen to all the jeweled ornaments of the people of Israel?

The ornaments will be given into the hands of strangers and the wicked as plunder. 

# What will happen to Yahweh's cherished place?

Bandits will enter Yahweh's cherished place and defile it. 

# What will the people of Israel seek, but not find?

The people of Israel will seek peace, but there will be none. 

# What will happen when the people seek a vision from the prophet?

When the people seek a vision, the Law and counsel will perish. 

# How will the king and the people respond when Yahweh's judgment comes?

When judgment comes, the king will mourn and the people will tremble in fear. 

# Where was Ezekiel when the hand of the Lord Yahweh fell on him?

Ezekiel was sitting in his house, with the elders of Judah sitting before him. 

# Where did the Spirit take Ezekiel, and what did he see there?

The Spirit took Ezekiel to the inner Northern Gate in Jerusalem, where he saw the idol that provokes jealousy. 

# What did the Spirit say he was being forced to do because of the great abominations (wickedness) of the house of Israel?

The Spirit said he was being forced to go far from his own sanctuary. 

# After Ezekiel dug into the wall and saw a door, what did the Spirit tell Ezekiel to do?

The Spirit to Ezekiel to, "Go and see the wicked abominations that they are doing here." 

# What were the elders saying about Yahweh as they worshiped their idols?

The elders were saying that Yahweh does not see them and that Yahweh had forsaken the land. 

# What did Ezekiel see the women doing at the gate on the north side of Yahweh's house?

The women were sitting there mourning for Tammuz. 

# What did Ezekiel see in the inner courtyard of Yahweh's house?

There were twenty-five men with their faces to the east worshiping Shamesh. 

# Because of the abominations of the house of Israel, what did the Spirit say he was going to do?

The Spirit said that he would act and not spare them, nor have compassion even though they cry with a loud voice. 

# Who did the Spirit call to come up to the city?

The Spirit called six men with weapons of destruction, and one man with a scribe's equipment. 

# Who did the Spirit call to come up to the city?

The Spirit called six men with weapons of destruction, and one man with a scribe's equipment. 

# From where did the glory of the God of Israel move, and to where did it go?

The glory of the God of Israel moved from the cherubim where it had been to the threshold of the house. 

# What did Yahweh tell the scribe to do?

Yahweh told the scribe to make a mark on the foreheads of the men who groaned and sighed about the abominations being performed in the city. 

# What did Yahweh tell the six men with weapons of destruction to do?

Yahweh told the six men to kill all of the people except those with the mark on their heads. 

# What question did Ezekiel ask Yahweh as he saw the six men striking the city?

Ezekiel asked Yahweh if all the remnant of Israel would be destroyed by Yahweh's wrath. 

# What was Yahweh's answer to Ezekiel's question?

Yahweh answered that the iniquity of the house of Israel and Judah was great, and that he would not spare them. 

# What was Yahweh's answer to Ezekiel's question?

Yahweh answered that the iniquity of the house of Israel and Judah was great, and that he would not spare them. 

# What did the scribe report?

The scribe reported that he had done all Yahweh had commanded him. 

# What did Yahweh tell the man dressed in linen to do?

Yahweh told the man dressed in linen to fill both his hands with fiery coals and to scatter them over the city. 

# What did the glory of Yahweh then do?

The glory of Yahweh then rose up and stood over the threshold of the house, filling the house with a cloud and the courtyard with brightness. 

# How did the man dressed in linen receive the fire which was among the cherubim?

The man dressed in linen went in, and a cherub lifted up the fire and placed it into the hands of the man. 

# What was the likeness of the wheels that were beside the cherubim?

The wheels that were beside the cherubim were like a wheel intersecting another wheel. 

# What covered the cherubim and the four wheels?

Eyes covered the cherubim and the four wheels. 

# What was the name given to the four wheels?

The four wheels were called "Whirling". 

# What did the wheels do as the cherubim moved?

The wheels would go beside the cherubim when the cherubim moved. 

# What did the wheels do as the cherubim moved?

The wheels would go beside the cherubim when the cherubim moved. 

# To where did the glory of Yahweh, the cherubim, and the wheels move?

The glory of Yahweh, the cherubim, and the wheels moved to the eastern entrance of Yahweh's house. 

# To where did the glory of Yahweh, the cherubim, and the wheels move?

The glory of Yahweh, the cherubim, and the wheels moved to the eastern entrance of Yahweh's house. 

# Where had Ezekiel seen the same living creatures before?

Ezekiel had seen the same living creatures before by the Chebar canal. 

# Where had Ezekiel seen the same living creatures before?

Ezekiel had seen the same living creatures before by the Chebar canal. 

# Where had Ezekiel seen the same living creatures before?

Ezekiel had seen the same living creatures before by the Chebar canal. 

# What did Ezekiel see when the Spirit brought him to the eastern gate of Yahweh's house?

Ezekiel saw twenty-five men, with the leaders of the people among them. 

# Of what did God say the twenty-five men were guilty?

God said the men were guilty of devising inquity and deciding wicked plans in the city. 

# With what had the twenty-five men filled the streets?

The twenty-five men had filled the streets with the people they had killed. 

# What did the twenty-five men fear, and what did Yahweh say he would bring?

The twenty-five men feared the sword, and Yahweh said he would bring the sword upon them. 

# Into whose hands was Yahweh going to put the twenty-five men?

Yahweh was going to put the twenty-five men into the hands of foreigners. 

# Where were the twenty-five men to be judged and because of Yahweh's judgment upon them, what would the twenty-five men know?

The twenty-five men were to be judged within the borders of Israel and because of Yahweh's judgment against them, the men would know that the Lord is Yahweh. 

# Where were the twenty-five men to be judged and because of Yahweh's judgment upon them, what would the twenty-five men know?

The twenty-five men were to be judged within the borders of Israel and because of Yahweh's judgment against them, the men would know that the Lord is Yahweh. 

# What decrees had the twenty-five men carried out?

The twenty-five men had carried out the decrees of the nations surrounding them. 

# What was Ezekiel afraid that Yahweh would do to Israel?

Ezekiel was afraid that Yahweh would completely destroy the remnant of Israel. 

# What promise did Yahweh give Israel despite his judgments upon them?

Yahweh promised to gather Israel from the peoples, and to assemble them in the land of Israel. 

# What did Yahweh promise to take from the people of Israel, and to give to them instead?

Yahweh promised to take from them their stone heart, and to give to them a heart of flesh. 

# How would the people of Israel then walk?

The people of Israel would then walk in Yahweh's statutes and decrees. 

# What did Yahweh say he would do for those who walk with affection towards their detestable things?

Yahweh said he would bring their conduct on their own heads. 

# From where did the glory of Yahweh leave and to where did the glory of Yahweh go?

The glory of Yahweh left the midst of the city and stood on the mountain east of the city. 

# What did Ezekiel do when the Spirit brought him into Chaldea?

Ezekiel declared to the exiles all the things of Yahweh he had seen. 

# Where did Yahweh say Ezekiel lived?

Yahweh said Ezekiel lived in the midst of a rebellious house. 

# What was Ezekiel to do in the sight of the people of Israel?

Ezekiel was to prepare for exile, going out in their sight to another place. 

# How did Yahweh tell Ezekiel to go out?

Yahweh told Ezekiel to dig a hole through the wall and go out through it. 

# According to Yahweh, what was the purpose of Ezekiel's exile?

Yahweh said that Ezekiel's exile was a sign to the house of Israel. 

# What question was the house of Israel asking Ezekiel as he came out of his house?

The house of Israel was asking, "What are you doing?" 

# Who did Ezekiel's prophetic action concern?

Ezekiel's prophetic action concerned the prince in Jerusalem and all the house of Israel. 

# What did Yahweh say would happen to the prince in Jerusalem?

Yahweh said that the prince in Jerusalem would go out through the wall, but would be caught and taken to Babylon where he would die without sight. 

# What did Yahweh say would happen to the prince in Jerusalem?

Yahweh said that the prince in Jerusalem would go out through the wall, but would be caught and taken to Babylon where he would die without sight. 

# What did Yahweh say would happen to the army of the prince in Jerusalem?

Yahweh said the army would be scattered, and he would send out a sword after them. 

# What two reasons did Yahweh give for sparing a few men?

Yahweh said he would spare a few men so they could record the abominations of Israel, and so they would know that the Lord is Yahweh. 

# How did Yahweh say the the people of the land of Israel would eat and drink?

Yahweh said the people would eat their bread with trembling and drink their water while shaking. 

# What did Yahweh say would happen to the cities and the land?

Yahweh said the cities would be desolate and the land would be a wasteland. 

# What did the people of Israel think about prophetic visions?

The people thought that every prophetic vision was prolonged and failed. 

# What did Yahweh say there would no longer be within the house of Israel?

Yahweh said there would no longer be any false visions or favorable divination within the house of Israel. 

# When did the house of Israel think the prophetic vision of Ezekiel would be fulfilled?

The house of Israel had said, 'The vision that he sees is for many days from now, and he prophesies of far off times.' 

# What did Yahweh say about the fulfillment of Ezekiel's vision. 

Yahweh said his words would no longer be delayed but the word that Yahweh had spoken would be done. 

# From where were the false prophets of Israel getting their prophecies?

The false prophets in Israel were getting their prophecies from their own minds and spirits. 

# From where were the false prophets of Israel getting their prophecies?

The false prophets in Israel were getting their prophecies from their own minds and spirits. 

# What had the false prophets failed to do?

The false prophets had failed to repair the breaks in the wall around the house of Israel. 

# What were the false prophets saying, even though Yahweh had not sent them?

The false prophets were saying, "Such and such is Yahweh's declaration," even though Yahweh had not sent them. 

# What were the false prophets saying, even though Yahweh had not sent them?

The false prophets were saying, "Such and such is Yahweh's declaration," even though Yahweh had not sent them. 

# What declaration did Yahweh make against the false prophets of Israel?

Yahweh declared that his hand was against the false prophets, and they would not be enrolled in the record of the house of Israel. 

# What declaration did Yahweh make against the false prophets of Israel?

Yahweh declared that his hand was against the false prophets, and they would not be enrolled in the record of the house of Israel. 

# What would the people know when Yahweh destroys the false prophets?

The people would know that the Lord is Yahweh. 

# What did Yahweh say he would do to the wall and those who whitewashed it?

Yahweh said he would annihilate the wall and those who whitewashed it. 

# What were the false prophets prophesying to the people concerning Jerusalem?

The false prophets were prophesying peace for Jerusalem. 

# What was the "son of man" told to do about the daughters of his people who prophesy out of their own minds?

The "son of man" was told to prophesy against them. 

# What were the magic charms and the veils the women made used for?

The magic charms and veils the women made were used to hunt down people. 

# What did Yahweh say he would do for his people who are trapped?

Yahweh said he would let his people who are trapped go free. 

# What did Yahweh say he would do for his people who are trapped?

Yahweh said he would let his people who are trapped go free. 

# What were the false prophets doing to the righteous and the wicked person?

The false prophets were discouraging the righteous and encouraging the wicked person. 

# What did Yahweh say the false prophets would no longer have?

Yahweh said the false prophets would no longer have false visions or continue to make false predictions. 

# Who came to Ezekiel to inquire of him?

The elders of Israel came to Ezekiel to inquire of him. 

# Why did Yahweh question if he should be inquired of by these men?

Yahweh questioned because the elders had taken their idols into their hearts. 

# How did Yahweh say he would answer those who take idols into their hearts?

Yahweh said he would answer those who take idols into their hearts according to the number of their idols. 

# What did Yahweh call the house of Israel to do?

Yahweh called the house of Israel to repent and turn away from its idols. 

# What did Yahweh say he would do to every man who worships idols and then seeks to inquire from a prophet of Yahweh?

Yahweh said he would make that man a sign and a proverb by cutting him off from the people of Israel. 

# What did Yahweh say he would do to every man who worships idols and then seeks to inquire from a prophet of Yahweh?

Yahweh said he would make that man a sign and a proverb by cutting him off from the people of Israel. 

# What did Yahweh say he would do to every deceived prophet?

Yahweh said he would deceive that prophet and destroy him. 

# What relationship did Yahweh say he wanted with the people of Israel?

Yahweh said he wanted the people to be his people, and for him to be their God. 

# When Yahweh brought judgment, what would be all that even the most righteous in the land could do?

When Yahweh brought judgment, even the most righteous in the land could only deliver their own souls. 

# Who did Yahweh use as examples of some of the most righteous men in history?

Yahweh used as examples of some of the most righteous men in history Noah, Daniel, and Job. 

# Who did Yahweh use as examples of some of the most righteous men in history?

Yahweh used as examples of some of the most righteous men in history Noah, Daniel, and Job. 

# When Yahweh brought judgment, who would the most righteous in the land not be able to deliver?

When Yahweh brought judgment, the most righteous in the land would not be able to deliver their sons or daughters. 

# Who did Yahweh use as examples of some of the most righteous men in history?

Yahweh used as examples of some of the most righteous men in history Noah, Daniel, and Job. 

# When Yahweh brought judgment, who would the most righteous in the land not be able to deliver?

When Yahweh brought judgment, the most righteous in the land would not be able to deliver their sons or daughters. 

# Who did Yahweh use as examples of some of the most righteous men in history?

Yahweh used as examples of some of the most righteous men in history Noah, Daniel, and Job. 

# When Yahweh brought judgment, who would the most righteous in the land not be able to deliver?

When Yahweh brought judgment, the most righteous in the land would not be able to deliver their sons or daughters. 

# What four punishments did Yahweh say he would send to Jerusalem?

Yahweh said he would send the four punishments of famine, sword, wild animals, and plague. 

# After Yahweh's judgment, who would be left?

After Yahweh's judgment, a remnant would be left who would go out with sons and daughters. 

# What would cause Ezekiel to be comforted?

When Ezekiel saw the ways and actions of the remnant of survivors, he would be comforted. 

# What two things in the forest does Yahweh compare?

Yahweh compares the vine to any tree with branches. 

# What did the Lord Yahweh say he had given the vine for?

The Lord Yahweh said he had given the vine as fuel for fires. 

# How does Yahweh say the inhabitants of Jerusalem are like the vine?

Yahweh says the inhabitants of Jerusalem are like the vine in that both are given as fuel for fires. 

# What will all know when Yahweh destroys the inhabitants of Jerusalem with fire?

All will know that the Lord is Yahweh. 

# Why will Yahweh make the land into an abandoned wasteland?

Yahweh will make the land into an abandoned wasteland because the inhabitants of Jerusalem have committed sin. 

# Where did Yahweh say Jerusalem had its beginning and birth?

Yahweh said Jerusalem had its beginning and birth in the land of Canaan. 

# What was done with Jerusalem on the day it was born?

Jerusalem was thrown out into the open field on the day it was born. 

# What did Yahweh do for Jerusalem after its birth?

Yahweh made Jerusalem grow like a plant in a field after its birth. 

# What did Yahweh do for Jerusalem when it reached the age of maturity?

Yahweh spread his robe over Jerusalem, and brought it into covenant with him. 

# Why did Jerusalem's fame go out among the nations?

Jerusalem's fame went out among the nations because of its beauty. 

# How did Jerusalem act after its fame went out among the nations?

Jerusalem acted like a prostitute after its fame went out among the nations. 

# How did Jerusalem act after its fame went out among the nations?

Jerusalem acted like a prostitute after its fame went out among the nations. 

# What did Jerusalem do with its sons and daughters born for Yahweh?

Jerusalem sacrificed its sons and daughters to the images. 

# What did Jerusalem make in every public place?

Jerusalem made a shrine in every public place. 

# What did Yahweh say he would cut off because of Jerusalem's prostitution?

Yahweh said he would cut off Jerusalem's food because of its prostitution. 

# What did Yahweh say is the difference between Jerusalem and every prostitute?

Yahweh said the difference is that prostitutes are paid for their acts, but Jerusalem pays its lovers and bribes them. 

# What did Yahweh say is the difference between Jerusalem and every prostitute?

Yahweh said the difference is that prostitutes are paid for their acts, but Jerusalem pays its lovers and bribes them. 

# Who did Yahweh say he would gather against Jerusalem?

Yahweh said he would gather all of Jerusalem's lovers against her on every side. 

# How will Yahweh's attitude toward Jerusalem change after it is punished?

After Jerusalem is punished, Yahweh will no longer be angry with Jerusalem. 

# Yahweh said that Jerusalem had done more evil than what other two places?

Yahweh said that Jerusalem had done more evil than Sodom and Samaria. 

# Who did Sodom refuse to help?

Sodom refused to help the poor and needy. 

# What did the people all around Jerusalem think about the city?

The people around Jerusalem despised it and made it an object of scorn. 

# Yahweh said he would treat Jerusalem as he would treat anyone who did what?

Yahweh said he would treat Jerusalem as he would treat anyone who despised their oath and broke a covenant. 

# What did Yahweh say he would call to mind and establish?

Yahweh said he would call to mind his covenant with Jerusalem and establish an everlasting covenant with it. 

# What will Jerusalem's reaction be when Yahweh forgives it for all it has done?

Jerusalem will be ashamed and will not longer speak because of its shame. 

# What did Yahweh tell Ezekiel to present and speak to the house of Israel?

Yahweh told Ezekiel to present a riddle and speak a parable to the house of Israel. 

# In the parable, where did the large eagle plant the tips of the cedar tree branches?

The large eagle planted the tips of the cedar tree branches in the land of Canaan in a city of merchants. 

# In the parable, where did the large eagle plant the tips of the cedar tree branches?

The large eagle planted the tips of the cedar tree branches in the land of Canaan in a city of merchants. 

# In the parable, where did the large eagle plant the seed of the land, and how did it grow?

The large eagle planted the seed beside a large body of water, and the vine produced branches and sent out shoots. 

# In the parable, where did the large eagle plant the seed of the land, and how did it grow?

The large eagle planted the seed beside a large body of water, and the vine produced branches and sent out shoots. 

# In the parable, what did the vine do when the other great eagle came?

The vine turned its roots towards the other great eagle. 

# What did Yahweh say would happen to the vine in the parable?

Yahweh said that the vine would completely wither away in its plot. 

# What did Yahweh say would happen to the vine in the parable?

Yahweh said that the vine would completely wither away in its plot. 

# What did the king of Babylon do with the king of Jerusalem?

The king of Babylon took the king of Jerusalem to Babylon. 

# What did the king of Babylon do with the royal descendant of the king of Jerusalem?

The king of Babylon made a covenant with the royal descendant of the king of Jerusalem. 

# How did Yahweh say the land of Israel would survive?

Yahweh said the land of Israel would survive by the king of Jerusalem keeping his covenant with the king of Babylon. 

# How did the king of Jerusalem violate the covenant he made with the king of Babylon?

The king of Jerusalem rebelled and sent ambassadors to Egypt to acquire horses and an army. 

# What did Yahweh say would happen to the king of Jerusalem?

Yahweh said the king of Jerusalem would die in the middle of Babylon. 

# According to Yahweh, whose covenant did the king of Jerusalem actually break?

According to Yahweh, the king of Jerusalem actually broke his covenant with Yahweh. 

# What did Yahweh declare would happen to the armies of the king of Jerusalem?

Yahweh declared the armies of the king of Jerusalem would fall by the sword. 

# What did Yahweh say he would do with the tender branches of the cedar tree?

Yahweh said he would plant the tender branches on a high mountain. 

# What will the tender branches that Yahweh plants become?

The tender branches Yahweh plants will become a majestic cedar where every winged bird will live. 

# What does Yahweh declare will happen to every person who sins?

Yahweh declares that every person who sins will die. 

# Who does a righteous man help?

A righteous man gives his food to the hungry and covers the naked with clothes. 

# What does a righteous man walk in and keep?

A righteous man walks in Yahweh's laws and keeps Yahweh's decrees. 

# What does Yahweh declare will happen to a righteous man?

Yahweh declares a righteous man will live. 

# If a righteous man has a son who oppresses the poor and needy, what does Yahweh declare will happen to him?

Yahweh declares the unrighteous son will not live. 

# If a righteous man has a son who oppresses the poor and needy, what does Yahweh declare will happen to him?

Yahweh declares the unrighteous son will not live. 

# If a son does not walk in his father's sins, will a son die for his father's sins?

If a son carries out Yahweh's decrees and walks according to Yahweh's statutes, then he will not die for his father's sin. 

# Why does the righteous son not bear the iniquity of his father?

The righteous son does not bear the iniquity of the father because he carries out justice and righteousness. 

# What does Yahweh declare will happen to a wicked person who turns away from all his sins?

Yahweh declares that a wicked person who turns away from all his sins will certainly live. 

# What does Yahweh declare will happen to a wicked person who turns away from all his sins?

Yahweh declares that a wicked person who turns away from all his sins will certainly live. 

# What does Yahweh declare will happen to a righteous person who turns and commits sins and practices wickedness?

Yahweh declares that a righteous person who turns and commits iniquity will die in the sins that he commits. 

# How does Yahweh say he will judge each man?

Yahweh says he will judge each man according to his ways. 

# What does Yahweh call the house of Israel to do?

Yahweh calls the house of Israel to repent and turn away from all its sins. 

# What does Yahweh call the house of Israel to make for themselves?

Yahweh calls the house of Israel to make a new heart and a new spirit for themselves. 

# What was Ezekiel told to lift up?

Ezekiel was told to lift up a lamentation against the leaders of Israel. 

# In the parable of the lions, what did one of the cubs learn to do?

One of the cubs learned to tear his victims and devour men. 

# When the nations heard about this cub, what did they do?

The nations trapped the cub and brought him to the land of Egypt. 

# After the first cub was gone, what did the second young lion learn to do?

The second young lion learned to tear his victims and devour men. 

# What did the nations do with the second young lion?

The nations trapped the young lion and brought him to the king of Babylon. 

# What was Israel's mother once like?

Israel's mother was once like a fruitful vine planted beside the water. 

# For what were her strong branches to be used?

Her strong branches were to be used for ruler's scepters. 

# What happened to the vine?

The vine was uprooted, thrown down, and dried out by an eastern wind. 

# Where is the vine?

The vine is in the wilderness. 

# What does the vine no longer have?

The vine no longer has strong branches or a scepter to rule. 

# Who came to Ezekiel and why did they come?

The elders of Israel came to Ezekiel to inquire of Yahweh. 

# What was Yahweh's response to those who came to Ezekiel?

Yahweh said that he would not be inquired of by the elders of Israel. 

# What did Yahweh swear he would do for Israel when they were in the land of Egypt?

Yahweh swore that he would bring them into a land flowing with milk and honey. 

# What command did Yahweh give the people of Israel in the land of Egypt?

Yahweh commanded the people to throw away their idols of Egypt. 

# How did the people of Israel respond to Yahweh's command?

The people rebelled against Yahweh and were unwilling to listen. 

# Why did Yahweh say he acted to bring the people of Israel out of the land of Egypt?

Yahweh said he acted for his name's sake so that it would not be profaned in the eyes of the nations. 

# What did Yahweh give the people of Israel in the wilderness?

Yahweh gave the people his statutes, decrees, and Sabbaths. 

# What did Yahweh tell the people they would be able to do if they obeyed his decrees?

Yahweh told the people they would be able to live if they obeyed his decrees. 

# What did Yahweh give the people of Israel in the wilderness?

Yahweh gave the people his statutes, decrees, and Sabbaths. 

# How did the people of Israel respond to what Yahweh gave them in the wilderness?

The people rebelled against Yahweh and rejected his decrees. 

# What did Yahweh tell the people they would be able to do if they obeyed his decrees?

Yahweh told the people they would be able to live if they obeyed his decrees. 

# What did Yahweh then swear he would not do for the people of Israel because they rejected his decrees?

Yahweh then swore he would not bring them into the land he was going to give them. 

# How did the sons and daughters of Israel respond when Yahweh commanded them to walk in his decrees?

The sons and daughters of Israel rebelled against Yahweh and did not keep his decrees. 

# What did Yahweh tell the people they would be able to do if they obeyed his decrees?

Yahweh told the people they would be able to live if they obeyed his decrees. 

# What did Yahweh then swear to do to the sons and daughters of Israel?

Yahweh then swore to scatter them among the nations. 

# How did the fathers of Israel blaspheme and betray Yahweh?

The fathers of Israel blasphemed and betrayed Yahweh by offering sacrifices to idols on the high places. 

# How did the fathers of Israel blaspheme and betray Yahweh?

The fathers of Israel blasphemed and betrayed Yahweh by offering sacrifices to idols on the high places. 

# How did the fathers of Israel blaspheme and betray Yahweh?

The fathers of Israel blasphemed and betrayed Yahweh by offering sacrifices to idols on the high places. 

# What were the people of Israel doing with their sons?

The people of Israel were causing their sons to pass through the fire. 

# What thought was in the minds of the people of Israel?

The people of Israel were thinking they wanted to be like the other nations, worshiping wood and stone. 

# What did Yahweh say he would do to the people of Israel in order to judge them face to face?

Yahweh said he would gather the people of Israel out of the countries where they were scattered into the wilderness of the peoples. 

# What did Yahweh say he would do to the people of Israel in order to judge them face to face?

Yahweh said he would gather the people of Israel out of the countries where they were scattered into the wilderness of the peoples. 

# What did Yahweh say he would purge from among the people of Israel?

Yahweh said he would purge the rebellious and transgressing ones from among the people of Israel. 

# After Yahweh gathered the house of Israel on his holy mountain, how would Israel treat Yahweh?

After Yahweh gathered the house of Israel on his holy mountain, Israel would treat Yahweh as holy in the sight of the nations. 

# After Yahweh gathered the house of Israel on his holy mountain, how would Israel treat Yahweh?

After Yahweh gathered the house of Israel on his holy mountain, Israel would treat Yahweh as holy in the sight of the nations. 

# What would the house of Israel think of themselves as they called to mind their past evil ways?

The house of Israel would hate themselves for all the evil actions they committed. 

# What declaration did Yahweh make against the forest of the Negev?

Yahweh declared that he would kindle a fire that would burn every face from south to north. 

# What declaration did Yahweh make against the forest of the Negev?

Yahweh declared that he would kindle a fire that would burn every face from south to north. 

# What were the people of Israel saying about Ezekiel?

The people of Israel were saying Ezekiel was a mere teller of parables. 

# Against whom did Yahweh tell Ezekiel to speak?

Yahweh told Ezekiel to speak against the sanctuaries; against the land of Israel. 

# Who did Yahweh say he would cut off from the land of Israel?

Yahweh said he would cut off both the righteous and wicked person from the land of Israel. 

# What did Yahweh tell Ezekiel to do before the eyes of the people?

Yahweh told Ezekiel to groan before the eyes of the people. 

# Why did Yahweh tell Ezekiel to act this way before the eyes of the people?

Yahweh told Ezekiel to act this way to show what it would be like for them when Yahweh brought the sword against them. 

# Who was the sharpened and polished sword to be given to?

The polished and sharpened sword were to be given into the hand of a killer. 

# On whom would that sword come?

That sword would come on Yahweh's people and the leaders of Israel. 

# What would come to rest after the great slaughter?

After the great slaughter, Yahweh's fury would come to rest. 

# What were the destinations of the two roads assigned for the king of Babylon?

The two destinations were Rabbah of the Ammonites, and Judah and Jerusalem. 

# How would the king of Babylon determine which road to take?

The king of Babylon would obtain a prophetic message from divination to determine which road to take. 

# Of what would the king of Babylon accuse Israel in order to attack them?

The king of Babylon would accuse Israel of violating their treaty in order to attack them. 

# What did Yahweh tell the wicked ruler of Israel to do, and why?

Yahweh told the wicked ruler of Israel to remove his turban and crown, because the crown would no longer exist. 

# What did Yahweh tell the wicked ruler of Israel to do, and why?

Yahweh told the wicked ruler of Israel to remove his turban and crown, because the crown would no longer exist. 

# What did Yahweh tell the wicked ruler of Israel to do, and why?

Yahweh told the wicked ruler of Israel to remove his turban and crown, because the crown would no longer exist. 

# When did Yahweh say he would restore the crown in Israel?

Yahweh said he would restore the crown in Israel when one came who had a right to it. 

# What do the prophets of Ammon do for the people of Ammon?

Ammon's prophets see empty visions for the people of Ammon, while they perform rituals to come up with lies for the people of Ammon. 

# What do the prophets of Ammon do for the people of Ammon?

Ammon's prophets see empty visions for the people of Ammon, while they perform rituals to come up with lies for the people of Ammon. 

# Who was the Lord Yahweh going to give the people of Ammon over to?

The Lord Yahweh was going to give the Ammonites into the hand of cruel men, craftsmen of destruction. 

# What name does Yahweh give the city of Jerusalem that he is judging?

Yahweh calls the city of Jerusalem the city of blood. 

# What name does Yahweh give the city of Jerusalem that he is judging?

Yahweh calls the city of Jerusalem the city of blood. 

# What two sins does Yahweh name that have made the city guilty?

The city is guilty of the blood it has poured out, and is made unclean by the idols it has made. 

# What reputation will the city have after Yahweh judges it?

The reputation known everywhere will be that it is a city of confusion. 

# Which three groups of people have been mistreated by the rulers of Israel?

Fathers and mothers have been dishonored, foreigners have been oppressed, and orphans and widows have been mistreated. 

# What three sexual sins are being committed by men in the city?

Men are committing sins with their neighbor's wife, are making their daughters-in-law unclean, and are abusing their sisters. 

# What does Yahweh declare he is going to do to the people because of their sins?

Yahweh declares he is going to scatter the people among the nations. 

# What does Yahweh declare he is going to do to the people because of their sins?

Yahweh declares he is going to scatter the people among the nations. 

# What will the people know after Yahweh strikes them?

The people will know the Lord is Yahweh. 

# In his parable, to what does Yahweh liken the house of Israel?

In his parable, Yahweh likens the house of Israel to dross. 

# Where does Yahweh say he will gather the dross?

Yahweh says he will gather the dross into the midst of Jerusalem. 

# What will Yahweh do to the dross as he pours out his fury?

Yahweh will pour out the dross and melt it down as he pours out his fury. 

# What will Yahweh do to the dross as he pours out his fury?

Yahweh will pour out the dross and melt it down as he pours out his fury. 

# What will Yahweh do to the dross as he pours out his fury?

Yahweh will pour out the dross and melt it down as he pours out his fury. 

# What are the priests of the land failing to distinguish and failing to teach?

The priests are failing to distinguish between holy and profane things, and failing to teach the difference between the unclean and the clean. 

# What are the prophets of the land doing?

The prophets of the land are painting with whitewash, seeing false visions and making false predictions. 

# What did Yahweh look for and not find?

Yahweh looked for a man who would build up a wall and stand before him in its breach for the land, but he did not find one. 

# In Yahweh's parable, what do the two daughters do in Egypt?

The two daughters act as prostitutes in Egypt. 

# In Yahweh's parable, what do the two daughters do in Egypt?

The two daughters act as prostitutes in Egypt. 

# What does the older daughter represent and what does the younger daughter represent?

The older daughter represents Samaria and the younger daughter represents Jerusalem. 

# What did the older daughter do even though she was Yahweh's?

The older daughter gave herself as a prostitute to Assyria's men. 

# What did the older daughter do even though she was Yahweh's?

The older daughter gave herself as a prostitute to Assyria's men. 

# What did the older daughter do even though she was Yahweh's?

The older daughter gave herself as a prostitute to Assyria's men. 

# What did the older daughter's lovers do to her when Yahweh gave her over to them?

The older daughter's lovers stripped her naked, took her sons and daughters, and killed her. 

# What did the older daughter's lovers do to her when Yahweh gave her over to them?

The older daughter's lovers stripped her naked, took her sons and daughters, and killed her. 

# What did the younger daughter do when she saw what happened to the older daughter?

The younger daughter acted like a prostitute even more than her sister. 

# Because of their prostitution, how did Yahweh's attitude change toward the two sisters?

Because of their prostitution, Yahweh turned away his soul from the two sisters. 

# What did Yahweh say he would do to the younger sister because of her prostitution?

Yahweh said he would turn her lovers against her. 

# What does Yahweh say will happen to the younger sister and her descendants?

The younger sister will have her nose and ears cut off, and her descendants will be devoured by fire. 

# What will be revealed when the younger sister is given into the hand of the ones she hates?

The naked shame of the younger sister's prostitution will be revealed. 

# Because of their prostitution, what does Yahweh put into the hands of the younger and older sister?

Because of their prostitution, Yahweh puts a cup of punishment into the hands of the younger and older sister. 

# Because of their prostitution, what does Yahweh put into the hands of the younger and older sister?

Because of their prostitution, Yahweh puts a cup of punishment into the hands of the younger and older sister. 

# What will the younger sister become to those around her?

The younger sister will become a laughingstock and a subject for moking to those around her. 

# What were the two sisters doing with their sons born for Yahweh?

The two sisters were passing their sons born for Yahweh through the fire to be consumed. 

# What did the two sisters do on the same day they slaughtered their children?

On the same day they slaughtered their children, the two sisters came to Yahweh's sanctuary to defile it. 

# What did the two sisters do on the same day they slaughtered their children?

On the same day they slaughtered their children, the two sisters came to Yahweh's sanctuary to defile it. 

# What does Yahweh say righteous men will do to the prostitutes?

Yahweh says righteous men will condemn the prostitutes to punishment for adultery. 

# What will the company do that Yahweh raises up against the prostitutes?

The company that Yahweh raises up will stone the prostitutes with stones and cut them down with their swords. 

# What will the prostitutes know when they bear the guilt of their sins with their idols?

When they bear the guilt of their sins with their idols, the prostitutes will know that the Lord is Yahweh. 

# What did Yahweh say was happening on the exact day he spoke to Ezekiel?

Yahweh said that the king of Babylon was attacking Jerusalem on that exact day. 

# In Yahweh's parable, what does Yahweh tell the people of Jerusalem to do?

Yahweh tells them to pour water into the cooking pot, fill it with the best bones, and boil it thoroughly. 

# In Yahweh's parable, what does Yahweh tell the people of Jerusalem to do?

Yahweh tells them to pour water into the cooking pot, fill it with the best bones, and boil it thoroughly. 

# In Yahweh's parable, what does Yahweh tell the people of Jerusalem to do?

Yahweh tells them to pour water into the cooking pot, fill it with the best bones, and boil it thoroughly. 

# What is wrong with the cooking pot of Jerusalem that will not come out of it?

The cooking pot of Jerusalem has rust in it that will not come out of it. 

# What has Jerusalem done to exact vengeance from Yahweh?

Jerusalem has not covered the blood that is in her midst. 

# What has Jerusalem done to exact vengeance from Yahweh?

Jerusalem has not covered the blood that is in her midst. 

# Why set the empty pot on the fire?

Set the empty pot on the fire in order to heat and scorch its bronze, so its uncleanness within it will be melted, its corrosion consumed! 

# What has not been removed from Jerusalem by the fire?

The corrosion of Jerusalem has not been removed by the fire. 

# According to Yahweh, by what will the people of Jerusalem be judged?

The people of Jerusalem will be judged by their ways and their activities. 

# What did Yahweh say he was taking from Ezekiel?

Yahweh said he was taking Ezekiel's wife from him. 

# What did Yahweh tell Ezekiel not to do?

Yahweh told Ezekiel not to mourn or weep for having lost his wife. 

# What did Yahweh say he was taking from Ezekiel?

Yahweh said he was taking Ezekiel's wife from him. 

# What did Yahweh tell Ezekiel not to do?

Yahweh told Ezekiel not to mourn or weep for having lost his wife. 

# What did Yahweh say was the meaning of the events which happened to Ezekiel?

Yahweh said that the desire of the people's eyes was defiling the sanctuary, so their sons and daughters would fall by the sword. 

# What did Yahweh say was the meaning of the events which happened to Ezekiel?

Yahweh said that the desire of the people's eyes was defiling the sanctuary, so their sons and daughters would fall by the sword. 

# What did Yahweh say was the meaning of the events which happened to Ezekiel?

Yahweh said that the desire of the people's eyes was defiling the sanctuary, so their sons and daughters would fall by the sword. 

# What would the people of Jerusalem do when they suffered their loss?

The people would do exactly as Ezekiel did, and not mourn or weep. 

# What would the people of Jerusalem do when they suffered their loss?

The people would do exactly as Ezekiel did, and not mourn or weep. 

# As what did Ezekiel serve for the people of Jerusalem?

Ezekiel served as a sign for the people of Jerusalem. 

# What did Yahweh say would happen on the day the temple was captured?

Yahweh said that on the day the temple was captured, a refugee would come to Ezekiel to give him the news. 

# What did Yahweh say would happen on the day the temple was captured?

Yahweh said that on the day the temple was captured, a refugee would come to Ezekiel to give him the news. 

# On the day the temple was captured, what would the people of Jerusalem know?

On the day the temple was captured, the people of Jerusalem would know that the Lord is Yahweh. 

# Who did Yahweh tell Ezekiel to prophesy against?

Yahweh told Ezekiel to prophesy against the people of Ammon. 

# What did the people of Ammon do when the sanctuary was profaned and the house of Judah went into exile?

When the sanctuary was profaned and the house of Judah went into exile, the people of Ammon said, "Aha!" 

# What will Yahweh do to the people of Ammon because of what they said when the house of Judah went into exile?

Yahweh will give the people of Ammon to a people in the east. 

# What will Yahweh do to Ammon that will cause them to know that Yahweh is Lord?

Yahweh will cut Ammon off from the other peoples and destroy them. 

# What did Moab and Seir say when the house of Judah went into exile?

When the house of Judah went into exile, Moab and Seir said that the house of Judah was like every other nation. 

# What will no longer be remembered among the nations?

The people of Ammon will no longer be remembered among the nations. 

# What had Edom done against the house of Judah?

Edom had exacted vengeance against the house of Judah. 

# What will Yahweh do to Edom because of what Edom did to the house of Judah?

Yahweh will destroy every person and animal in Edom. 

# What had the Philistines done against the house of Judah?

The Philistines had taken vengeance with disdain against the house of Judah. 

# What will Yahweh do to the Philistines because of what the Philistines did to the house of Judah?

Yahweh will destroy the Philistines. 

# What were the people of Tyre saying against Jerusalem?

The people of Tyre were saying they would be filled up as Jerusalem was ruined. 

# What did Yahweh say he would do to Tyre?

Yahweh said he would raise up many nations against Tyre, who would destroy its walls and towers. 

# What did Yahweh say would be done at the place Tyre once stood?

Yahweh said that nets would be dried out at the place Tyre once stood. 

# Who did Yahweh say he was bringing against Tyre?

Yahweh said he was bringing Nebuchadnezzar, the king of Babylon, against Tyre. 

# How did Yahweh say the walls of Tyre would be broken down?

Yahweh said the walls of Tyre would be broken down with Nebuchadnezzar's battering rams. 

# Where did Yahweh say the stone and wood of Tyre's houses would be laid?

Yahweh said the stone and wood of Tyre's houses would be laid in the midst of the waters. 

# What will the chiefs of the sea do when the terrible slaughter occurs in Tyre?

The chiefs of the sea will come down from their thrones, lay aside their robes, strip off their colorful clothing, and sit on the ground trembling. 

# Where do the chiefs of the sea lament that the famous city of Tyre is now?

The chiefs of the sea lament that the famous city of Tyre is now in the sea. 

# To where did Yahweh say the people of Tyre would be brought down?

Yahweh said the people of Tyre would be brought down into the pit. 

# According to Yahweh, when would Tyre be found again?

According to Yahweh, Tyre would never be found ever again. 

# For what trade were the people of Tyre famous?

The people of Tyre were famous for being merchants of peoples to many islands. 

# What had Tyre said about itself?

Tyre had said about itself that it was perfect in beauty. 

# Of what were the ship decks of Tyre made?

The ship decks of Tyre were made with cypress wood overlaid with ivory. 

# Who were the ship pilots of Tyre?

The ship pilots were the sages of Tyre. 

# What were the ships of Tyre carrying?

The ships of Tyre were carrying merchandise for trade. 

# Why was Tarshish a client of Tyre?

Tarshish was a client of Tyre because of the multitude of every kind of wealth. 

# In what was Tyre dealing with Javan, Tubal, and Meshech?

Tyre was dealing in men's lives and in items of bronze. 

# With what items did Judah and the land of Israel trade with Tyre?

Judah and the land of Israel traded with wheat, millet, honey, oil, and balsam. 

# With what items did Sheba trade with Tyre?

Sheba traded with spices, precious gems, and gold. 

# What did Yahweh say would happen to the wealth of Tyre on the day of its destruction?

Yahweh said the wealth of Tyre would fall into the depths of the sea on the day of its destruction. 

# What will the cities at the sea do when they hear the sound of their pilot's cry?

The cities at the sea will tremble at the sound of their pilot's cry. 

# What would the kings of the coasts do when they saw Tyre's destruction?

The kings of the coasts would shudder in horror and tremble when they saw Tyre's destruction. 

# When did Yahweh say Tyre would again exist?

Yahweh said Tyre would never again exist. 

# What did the ruler of Tyre say about himself?

The ruler of Tyre said about himself, "I am a god!" 

# Why was the heart of the ruler of Tyre arrogant?

The ruler's heart was arrogant because of his wealth. 

# What did Yahweh say he would do to the ruler of Tyre because of his arrogance?

Yahweh said he would bring foreigners against the ruler of Tyre. 

# How did Yahweh say the ruler of Tyre would die?

The ruler of Tyre would die the death of the uncircumcised by the hand of foreigners. 

# What did Yahweh say the king of Tyre once was?

Yahweh said the king of Tyre was once the model of perfection, full of wisdom, and perfect in beauty. 

# According to Yahweh, where was the king of Tyre when he was created?

The king of Tyre was in Eden, the garden of God. 

# Where did Yahweh place the king of Tyre, and what responsibility did the king of Tyre have?

The king of Tyre was on the holy mountain of God as the cherub anointed to guard mankind. 

# What was later found within the king of Tyre?

Injustice was later found within the king of Tyre. 

# Because of the sin of the king of Tyre, what did Yahweh do to him?

Yahweh threw the king of Tyre down as defiled from the mountain of God and destroyed him. 

# What will the ones who knew the king of Tyre do when they see his destruction?

The ones who knew the king of Tyre will shudder at him and will be horrified. 

# What did Yahweh say he was sending out to Sidon?

Yahweh said he was sending out a plague and blood in the streets of Sidon. 

# According to Yahweh, what were the peoples around Israel like for the house of Israel?

The peoples around Israel were like pricking briers and painful thorns. 

# After Yahweh executes justice on the ones who despise Israel, what will happen to Israel?

Israel will live securely, build houses, and plant vineyards in the land Yahweh will give to his servant Jacob. 

# After Yahweh executes justice on the ones who despise Israel, what will happen to Israel?

Israel will live securely, build houses, and plant vineyards in the land Yahweh will give to his servant Jacob. 

# Who did Yahweh tell Ezekiel to prophesy against?

Yahweh told Ezekiel to prophesy against Pharaoh, king of Egypt. 

# What animal does Yahweh say the king of Egypt is like?

Yahweh says the king of Egypt is like a great sea creature that lies in the midst of the river. 

# Where does Yahweh say he is going to throw the king of Egypt?

Yahweh says he is going to throw the king of Egypt down into the wilderness. 

# What plant does Yahweh say Egypt is like to the house of Israel?

Yahweh says Egypt is like a reed stalk to the house of Israel. 

# What had Egypt done when the house of Israel leaned on Egypt?

Egypt shattered Israel's legs and made their hip shake when Israel leaned on Egypt. 

# To what does Yahweh say the land of Egypt will be given over?

Yahweh says the land of Egypt will be given over to desolation and waste. 

# For how long does Yahweh say the land of Egypt will not be inhabited?

Yahweh says the land of Egypt will not be inhabited for forty years. 

# For how long does Yahweh say the land of Egypt will not be inhabited?

Yahweh says the land of Egypt will not be inhabited for forty years. 

# What does Yahweh say Egypt will be after they return from being scattered?

Yahweh says Egypt will be a lowly kingdom after they return from being scattered. 

# What wages did Nebuchadnezzar the king of Babylon receive for all the hard work he did against Tyre?

Nebuchadnezzar received no wages for all the hard work he did against Tyre. 

# What will Yahweh give Nebuchadnezzar in return for all the hard work he did against Tyre?

Yahweh will give Nebuchadnezzar the land of Egypt as the wages for all the hard work he did against Tyre. 

# What will Yahweh give Nebuchadnezzar in return for all the hard work he did against Tyre?

Yahweh will give Nebuchadnezzar the land of Egypt as the wages for all the hard work he did against Tyre. 

# On that day, what will Yahweh make Ezekiel do?

On that day, Yahweh will make Ezekiel speak in the midst of the house of Israel. 

# On that day, what will the house of Israel know?

On that day, the house of Israel will know that the Lord is Yahweh. 

# According to Yahweh, what kind of day and time is the coming day of Yahweh?

The coming day of Yahweh is a day of clouds, a time of doom for nations. 

# According to Yahweh, what kind of day and time is the coming day of Yahweh?

The coming day of Yahweh is a day of clouds, a time of doom for nations. 

# On the day of Yahweh, what will happen to Egypt, Cush, Libya, Lydia, and the people belonging to the covenant?

On the day of Yahweh, they will all fall by the sword. 

# On the day of Yahweh, what will happen to Egypt, Cush, Libya, Lydia, and the people belonging to the covenant?

On the day of Yahweh, they will all fall by the sword. 

# What will the people know when Egypt and her helpers are destroyed?

The people will know that the Lord is Yahweh. 

# Who's hand will Yahweh use to destroy the land of Egypt?

Yahweh will use the hand of Nebuchadnezzar, the king of Babylon, to destroy the land of Egypt. 

# To what will Yahweh bring an end in Memphis?

Yahweh will destroy and bring an end to the worthless idols of Memphis. 

# What will happen to the survivors in the Egyptian cities when Yahweh brings destruction?

The survivors will walk into captivity when Yahweh brings destruction. 

# What will happen to the survivors in the Egyptian cities when Yahweh brings destruction?

The survivors will walk into captivity when Yahweh brings destruction. 

# What did Yahweh say he had done to Pharaoh's arm, and what would Pharaoh now not be able to do?

Yahweh said he had broken the arm of Pharaoh, so it was not strong enough to grasp a sword. 

# After Egypt is destroyed, what will Yahweh do to Egypt among the nations?

Yahweh will scatter and disperse Egypt among the nations. 

# Whose arms will Yahweh strengthen?

Yahweh will strengthen the arms of the king of Babylon. 

# What will happen to arms of Pharoah?

Pharaoh's arms will fall. 

# To whom did Yahweh tell Ezekiel to prophesy?

Yahweh told Ezekiel to prophesy to Pharaoh, king of Egypt. 

# To what kind of plant did Yahweh liken Assyria?

Yahweh likened Assyria to a great cedar in Lebanon. 

# In Yahweh's parable of Assyria as a tree, what lived in and around the great cedar?

Every bird of the heavens nested in the cedar's branches, and every living thing of the field gave birth under its foliage. 

# What was the great cedar of Assyria greater than?

The great cedar of Assyria was greater than all the trees in the garden of God. 

# What was the great cedar of Assyria greater than?

The great cedar of Assyria was greater than all the trees in the garden of God. 

# Why did Yahweh grasp Assyria and drive it away?

Yahweh grasped Assyria and drove it away because its heart was lifted up (proud) and it was wicked. 

# Why did Yahweh grasp Assyria and drive it away?

Yahweh grasped Assyria and drove it away because its heart was lifted up (proud) and it was wicked. 

# After the cedar of Assyria was abandoned, what did Yahweh say would never happen again?

Yahweh said that no other tree would ever again grow that tall. 

# What did Yahweh bring to the earth on the day when Assyria went down to sheol?

On that day Yahweh brought mourning to the earth 

# To where did Yahweh throw the great cedar of Assyria?

Yahweh threw the great cedar of Assyria down to Sheol. 

# What happened to those nations that had lived in the shade of the great cedar of Assyria?

Those nations that had lived in the shade of Assyria also went down to Sheol. 

# Who does Yahweh declare will be brought down to the lowest parts of the earth?

Yahweh declares that Pharaoh and his servants will be brought down to the lowest parts of the earth. 

# What did Yahweh tell Ezekiel to lift up concerning Pharaoh?

Yahweh told Ezekiel to lift up a lament concerning Pharaoh. 

# What two animals did Yahweh say Pharaoh was like?

Yahweh said Pharaoh was like a young lion and like a monster in the seas. 

# When Yahweh throws the sea monster into a field, what will happen to it?

When the sea monster is thrown into a field, the birds and animals will eat it. 

# What will happen in the heavens when Yahweh puts out the lamp of Egypt?

The stars will be darkened, clouds will cover the sun, and the moon will not shine. 

# How will the people of the nations react when they see Egypt's collapse?

The people of the nations will be terrified and will shudder in horror. 

# How will the people of the nations react when they see Egypt's collapse?

The people of the nations will be terrified and will shudder in horror. 

# Who will come against Egypt and devastate it?

The king of Babylon will come against Egypt and devastate it. 

# What does Yahweh declare will happen to man and animal in Egypt?

Neither man nor animal will stir the waters of Egypt. 

# What will the people of Egypt know when they are attacked and destroyed?

The people of Egypt will know that the Lord is Yahweh. 

# To where will the servants of Egypt and the daughters of majestic nations be thrown?

They will be thrown down to the lowest earth with those who have gone down to the pit. 

# What will the warriors in Sheol declare about Egypt and her allies?

They will declare that Egypt and her allies have come down here and will lie with the uncircumcised killed by the sword. 

# What did Elam on the land of the living?

Elam brought their terrors on the land of the living. 

# What do the princes of the north and all the Sidonians who went down with the dead, carry?

They carry their own shame. 

# In Sheol, what will comfort Pharaoh?

In Sheol, Pharaoh will be comforted about all his servants who were killed by the sword. 

# What does the watchman do for the people of the land?

The watchman looks for the sword coming on the land, and blows his horn to warn the people. 

# What happens if the people do not pay attention to the watchman?

If the people do not pay attention, the sword kills the people and each one's blood is on his own head. 

# What happens to the watchman if he does not warn the people?

If the watchman does not warn the people, his blood will be required by Yahweh. 

# Who did Yahweh make a watchman for the house of Israel?

Yahweh made Ezekiel a watchman for the house of Israel. 

# In what does Yahweh say he does not delight?

Yahweh says he does not delight in the death of the wicked. 

# What does Yahweh call the wicked to do?

Yahweh calls the wicked to repent so they will live. 

# What does Yahweh say will happen to a righteous person who then commits injustice?

Yahweh says the righteous person who then commits injustice will die in the wickedness that he has committed. 

# What does Yahweh say will happen to a righteous person who then commits injustice?

Yahweh says the righteous person who then commits injustice will die in the wickedness that he has committed. 

# What does Yahweh say will happen to a wicked person who repents and does what is just and right?

Yahweh says the wicked person who repents and does what is just and right will surely live. 

# What does Yahweh say will happen to a wicked person who repents and does what is just and right?

Yahweh says the wicked person who repents and does what is just and right will surely live. 

# What does Yahweh say will happen to a wicked person who repents and does what is just and right?

Yahweh says the wicked person who repents and does what is just and right will surely live. 

# According to Yahweh, whose ways are not fair?

According to Yahweh, the ways of the people of Israel are not fair. 

# How does Yahweh say he will judge each person of the house of Israel?

Yahweh says he will judge each person according to his way. 

# What message did the fugitive bring to Ezekiel?

The fugitive brought the message that the city of Jerusalem had been captured. 

# What were the people of Israel saying about the land that Abraham inherited?

The people of Israel were saying the land that Abraham inherited was their possession. 

# Why does Yahweh question whether or not the people of Israel should really possess the land?

Yahweh questions whether or not they should possess the land because they had depended on their swords and had done disgusting things. 

# Why does Yahweh question whether or not the people of Israel should really possess the land?

Yahweh questions whether or not they should possess the land because they had depended on their swords and had done disgusting things. 

# What does Yahweh say he will do to the land because of the things the people of Israel have done?

Yahweh says he will turn the land into a desolation and a horror because of the things the people of Israel have done. 

# What does Yahweh say he will do to the land because of the things the people of Israel have done?

Yahweh says he will turn the land into a desolation and a horror because of the things the people of Israel have done. 

# What will the people of Israel do with the words of Ezekiel?

The people of Israel will listen to the words of Ezekiel, but they will not obey them. 

# What will the people of Israel do with the words of Ezekiel?

The people of Israel will listen to the words of Ezekiel, but they will not obey them. 

# What will the people of Israel know when everything comes to pass?

The people of Israel will know that a prophet has been among them when everything comes to pass. 

# What accusation does Yahweh make against the shepherds of Israel?

Yahweh accuses the shepherds of Israel of not shepherding at all, but of slaughtering the best animals of the flock. 

# What accusation does Yahweh make against the shepherds of Israel?

Yahweh accuses the shepherds of Israel of not shepherding at all, but of slaughtering the best animals of the flock. 

# How did the shepherds of Israel rule over the flock?

The shepherds of Israel ruled over the flock with strength and violence. 

# What then happened to the flock?

The flock was then scattered and became food for all the living beasts in the fields. 

# What then happened to the flock?

The flock was then scattered and became food for all the living beasts in the fields. 

# Who were the shepherds of Israel actually guarding?

The shepherds of Israel were actually guarding themselves. 

# What does Yahweh say he will do to the shepherds of Israel?

Yahweh says he will dismiss the shepherds of Israel and take away the flock from their mouths. 

# From where does Yahweh say he will gather his flock?

Yahweh says he will rescue them from all the places where they were scattered on the day of clouds and darkness. Then he will bring them out from among the peoples, he will gather them from the lands. 

# From where does Yahweh say he will gather his flock?

Yahweh says he will rescue them from all the places where they were scattered on the day of clouds and darkness. Then he will bring them out from among the peoples, he will gather them from the lands. 

# How does Yahweh say he will shepherd?

Yahweh says he will shepherd with justice. 

# Among what three groups does Yahweh say he will judge?

Yahweh says he will judge among the sheep, rams, and goats. 

# What has been done to the weak and thin sheep?

The weak and thin sheep have been pushed and gored until they have been scattered. 

# Who does Yahweh say he will raise up to shepherd the flock?

Yahweh says he will raise up his servant David to shepherd the flock. 

# Who does Yahweh say he will raise up to shepherd the flock?

Yahweh says he will raise up his servant David to shepherd the flock. 

# When Yahweh raises up his shepherd, what will Yahweh do so the sheep will live securely?

Yahweh will make a covenant of peace with the sheep and remove the evil wild animals from the land. 

# What will the nations no longer be able to do to the sheep?

The nations will no longer be able to plunder the sheep or bring insults against them. 

# What will the nations no longer be able to do to the sheep?

The nations will no longer be able to plunder the sheep or bring insults against them. 

# What will the house of Israel then know?

The house of Israel will then know that Yahweh their God is with them. 

# What does Yahweh declare to the sheep, the house of Israel?

Yahweh declares that he is the God of the house of Israel, and that they are his people. 

# Who does Yahweh tell Ezekiel to prophesy against?

Yahweh tells Ezekiel to prophesy against Mount Seir. 

# What does Yahweh say he will do to Mount Seir?

Yahweh says he will make Mount Seir a desolation and a horror. 

# What did the people of Mount Seir do that is bringing the judgment of Yahweh upon them?

The people of Mount Seir were hostile to the people of Israel, and poured them out into the hands of the sword. 

# According to Yahweh, what will pursue the people of Mount Seir, and why?

Bloodshed will pursue the people of Mount Seir because they did not hate bloodshed. 

# What will fill the mountains in the area of Mount Seir?

The mountains in the area of Mount Seir will be filled with its dead. 

# For how long will the desolation of Mount Seir last?

The desolation of Mount Seir will be a perpetual desolation. 

# What did the people of Mount Seir say about the two nations of Yahweh's people Israel?

The people of Mount Seir said that the two nations would become theirs. 

# What did Yahweh hear the people of Mount Seir saying against him?

Yahweh heard the people of Mount Seir boasting against Yahweh and saying many things against him. 

# What will the entire earth do when the people of Mount Seir are desolated?

The entire earth will rejoice when the people of Mount Seir are desolated. 

# What did the people of Mount Seir do when the people of Israel were desolated?

The people of Mount Seir rejoiced when the people of Israel were desolated. 

# What will the entire earth do when the people of Mount Seir are desolated?

The entire earth will rejoice when the people of Mount Seir are desolated. 

# Yahweh declares that all of what area will become a desolation?

Yahweh declares that Mount Seir and all of Edom will become a desolation. 

# What will the people of Mount Seir and Edom know when Yahweh judges them?

The people of Mount Seir and Edom will know that the Lord is Yahweh when Yahweh judges them. 

# To what did Yahweh tell Ezekiel to prophesy?

Yahweh told Ezekiel to prophesy to the mountains of Israel. 

# What was the enemy saying about the mountains of Israel?

The enemy was saying that the ancient high places had become their possession. 

# Against whom did Yahweh speak in the fire of his fury?

Yahweh spoke in the fire of his fury against Edom and all who took the land of Israel. 

# What did Yahweh swear concerning the nations that surrounded Israel?

Yahweh swore that the nations surrounding Israel would carry their own shame. 

# Who did Yahweh say would soon be coming back to the mountains of Israel?

Yahweh said the people of Israel would soon be coming back to the mountains of Israel. 

# What will be multiplied on the mountains of Israel?

Man and beast will be multiplied on the mountains of Israel. 

# What will be multiplied on the mountains of Israel?

Man and beast will be multiplied on the mountains of Israel. 

# What will be multiplied on the mountains of Israel?

Man and beast will be multiplied on the mountains of Israel. 

# Why had Yahweh poured out his fury against Israel?

Yahweh had poured out his fury against Israel because Israel had polluted the land by their idols. 

# What did the people of Israel do when they went to the nations?

When they went to the nations, the people of Israel profaned Yahweh's holy name. 

# Why does Yahweh say he is going to bring back the house of Israel to the mountains of Israel?

Yahweh says he is going to bring the house of Israel back for the sake of his holy name. 

# What did Yahweh say he would do to the house of Israel to enable them to walk in his statutes and keep his decrees?

Yahweh said would set his Spirit in them and enable them to walk in his statutes and keep his decrees, so they would do them. 

# After Yahweh saves the house of Israel, what will the house of Israel think of their previous wicked ways?

The house of Israel will hate themselves because of their previous wicked ways. 

# What does Yahweh say will happen to the cities and ruined places of Israel?

Yahweh says the cities will be inhabited and the ruined places will be rebuilt. 

# Like what place will the land of Israel become?

The land of Israel will become like the garden of Eden. 

# What will the other nations know when they see the inhabited cities and rebuilt ruins of Israel?

The nations will know that the Lord is Yahweh, and that Yahweh rebuilt Israel. 

# What will the other nations know when they see the inhabited cities and rebuilt ruins of Israel?

The nations will know that the Lord is Yahweh, and that Yahweh rebuilt Israel. 

# Yahweh says that the number of the people of Israel will become like what?

The number of the people of Israel will become like the flocks in Jerusalem at her appointed feasts. 

# Where did the Spirit of Yahweh set Ezekiel down, and what was there?

The Spirit of Yahweh set Ezekiel down in the midst of a valley full of bones. 

# What question did Yahweh ask Ezekiel?

Yahweh asked Ezekiel if the dry bones could live again. 

# What did Ezekiel prophesy would happen to the dry bones?

Ezekiel prophesied that the dry bones would have flesh and live again. 

# What did Ezekiel prophesy would happen to the dry bones?

Ezekiel prophesied that the dry bones would have flesh and live again. 

# What happened to the bones when Ezekiel prophesied to them the first time?

When Ezekiel prophesied to them the first time, the dry bones drew together and flesh and skin covered them. 

# What happened to the bones when Ezekiel prophesied to them the first time?

When Ezekiel prophesied to them the first time, the dry bones drew together and flesh and skin covered them. 

# What happened to the bones when Ezekiel prophesied to them the second time?

When Ezekiel prophesied to the bones the second time, the Spirit came into them and they lived. 

# What happened to the bones when Ezekiel prophesied to them the second time?

When Ezekiel prophesied to the bones the second time, the Spirit came into them and they lived. 

# According to Yahweh, who did the valley of dry bones represent?

According to Yahweh, the valley of dry bones represented the entire house of Israel. 

# What did Yahweh say he would do for Israel, which was represented by the dry bones coming back to life?

Yahweh said he would lift the people of Israel from their graves and bring them back to the land of Israel. 

# What did Yahweh tell Ezekiel to do with the two sticks?

Yahweh told Ezekiel to write a name on each stick, Judah and Joseph, and then bring both sticks together. 

# What did Yahweh tell Ezekiel to do with the two sticks?

Yahweh told Ezekiel to write a name on each stick, Judah and Joseph, and then bring both sticks together. 

# What did Yahweh say was the meaning of Ezekiel's two sticks?

Yahweh said he was joining the two branches of Joseph and Judah so that they would be one in his hand. 

# What did Yahweh say he was about to do for the people of Israel?

Yahweh said he was about to gather the people of Israel on the mountains of Israel as one nation with one king. 

# What did Yahweh say he was about to do for the people of Israel?

Yahweh said he was about to gather the people of Israel on the mountains of Israel as one nation with one king. 

# Who did Yahweh say would be king over the united nation of Israel?

Yahweh said that his servant David would be king over the united nation of Israel. 

# According to Yahweh, how long would the king of Israel be their chief?

According to Yahweh, the king of Israel would be their chief forever. 

# What did Yahweh say he would establish with Israel, and for how long?

Yahweh said he would establish a covenant of peace with Israel for eternity. 

# Where did Yahweh say he would live forever?

Yahweh said he would live forever in the midst of the people of Israel. 

# Where did Yahweh say he would live forever?

Yahweh said he would live forever in the midst of the people of Israel. 

# Against whom did Yahweh tell Ezekiel to prophesy?

Yahweh told Ezekiel to prophesy against Gog from the land of Magog. 

# With what does Yahweh say he will send out Gog?

Yahweh says he will send out Gog with all his army, horses, and horsemen. 

# Who is the commander of all the troops from Persia, Cush, Put, Gomer, and Beth Togarmah?

Gog is the commander of all these troops assembled with him. 

# To which land will Gog be called to go?

Gog will go to a land that has recovered from the sword and that has been gathered from many peoples to the mountains of Israel. 

# What will be the wicked scheme that Gog devises?

Gog will devise a scheme to capture booty and steal plunder from the quiet people living in safety. 

# What will be the wicked scheme that Gog devises?

Gog will devise a scheme to capture booty and steal plunder from the quiet people living in safety. 

# At what part of the earth are the people who have been gathered from the nations living?

The people gathered from the nations are living at the center of the earth. 

# From what direction does Gog and his great army come?

Gog and his great army come from a place far away in the north. 

# Through whom had Yahweh spoken that Gog would come against Israel?

Yahweh had spoken through the prophets of Israel that Gog would come against Israel. 

# How will Yahweh respond when Gog attacks the land of Israel?

When Gog attacks the land of Israel, Yahweh will respond with fury in his nostrils. 

# What great event does Yahweh say will happen on the day Gog attacks Israel?

Yahweh says that there will be a great earthquake on the day Gog attacks Israel. 

# What great event does Yahweh say will happen on the day Gog attacks Israel?

Yahweh says that there will be a great earthquake on the day Gog attacks Israel. 

# With what will Yahweh judge Gog and his troops on that day?

Yahweh will judge Gog and his troops on that day with plague, blood, flooding rains, hailstones of fire, and rains of brimstone. 

# In that day, what will Yahweh show in the eyes of many nations?

In that day, Yahweh will show his greatness and holiness in the eyes of many nations. 

# To where does Yahweh say he will bring Gog, chief of Meshech and Tubal?

Yahweh says he will bring Gog to the mountains of Israel. 

# Where will Gog fall dead?

Gog will fall dead on the mountains of Israel. 

# What will Yahweh do to Magog and to those living in safety on the coasts?

Yahweh will send out fire to Magog and to those living in safety on the coasts. 

# What does Yahweh say he will no longer allow?

Yahweh says he will no longer allow his holy name to be profaned. 

# Why will the ones living in the cities of Israel not need to gather wood for seven years?

They will not need to gather wood for seven years because they will burn the weapons of Gog. 

# Why will the ones living in the cities of Israel not need to gather wood for seven years?

They will not need to gather wood for seven years because they will burn the weapons of Gog. 

# Where will Gog and all his multitudes be buried?

Gog and all his multitudes will be buried in the Valley of Hamon Gog. 

# What will the house of Israel have to do in order to purify the land?

The house of Israel will have to bury Gog and all his multitudes for seven months in order to purify the land. 

# What large sacrifice is Yahweh making on the mountains of Israel?

Yahweh is making a large sacrifice of the flesh of warriors and the blood of princes of the earth on the mountains of Israel. 

# What large sacrifice is Yahweh making on the mountains of Israel?

Yahweh is making a large sacrifice of the flesh of warriors and the blood of princes of the earth on the mountains of Israel. 

# What will all the nations see when Yahweh makes his large sacrifice on the mountains of Israel?

All the nations will see Yahweh's judgment and his hand. 

# Why did the house of Israel go into captivity?

The house of Israel went into captivity because of their sins. 

# What will Yahweh do for the house of Israel when he acts in zeal for his holy name?

Yahweh will restore the fortunes of Jacob and have compassion on the house of Israel. 

# What will the house of Israel forget when they rest in their land in safety?

The house of Israel will forget their shame and all the treason in which they betrayed Yahweh. 

# What does Yahweh declare he will do when he pours out his Spirit on the house of Israel?

Yahweh declares that when he pours out his Spirit on the house of Israel he will no longer hide his face from them. 

# For how many years had Ezekiel been a captive of the Babylonians?

Ezekiel had been a captive of the Babylonians for twenty-five years. 

# How many years ago had the city of Jerusalem been captured?

The city of Jerusalem had been captured fourteen years ago. 

# To where did God bring Ezekiel in visions?

God brought Ezekiel to the land of Israel in visions. 

# What was Ezekiel told to report to the house of Israel?

Ezekiel was told to report everything that he saw to the house of Israel. 

# In Ezekiel's vision, what was surrounding the temple complex?

In Ezekiel's vision, a wall surrounded the temple complex. 

# What did the man who looked like bronze measure the width of the gateway entrance to be?

The man measured the width of the gateway entrance to be ten cubits. 

# What did Ezekiel see carved on the walls?

Ezekiel saw carvings of palm trees on the walls. 

# Where did the man who looked like bronze take Ezekiel after measuring in the area of the gate?

The man took Ezekiel to the outer courtyard of the temple. 

# Through what did a person have to go in order to enter the inner courtyard?

A person had to go through a gate in order to enter the inner courtyard. 

# How did the gates to the inner courtyard compare in size?

The gates of the inner courtyard all had the same measurements. 

# How did the gates to the inner courtyard compare in size?

The gates of the inner courtyard all had the same measurements. 

# For what were the rooms with doors by each of the inner gateways used?

The rooms with doors by each of the inner gateways were used to rinse the burnt offerings. 

# For what were the four tables on either side of each gate used?

The four tables on either side of each gate were used for slaughtering animals. 

# Whose sons were serving as priests in the temple?

The sons of Zadok were serving as priests in the temple. 

# How large was the inner courtyard?

The inner courtyard was one hundred cubits long and wide in a square. 

# What stood on either side of the sanctuary's portico?

Columns stood on either side of the sanctuary's portico. 

# To where did the man bring Ezekiel?

The man brought Ezekiel into the temple's holy place. 

# Where did the man go next?

The man went next into the very holy place. 

# How would someone get to the highest level of the house?

To get to the highest level of the house, there was a stairway that went up through the middle level. 

# What was the size of the sanctuary and the width of the front of the courtyard in front of the sanctuary?

The sanctuary and the front of the courtyard were both one hundred cubits. 

# What was the size of the sanctuary and the width of the front of the courtyard in front of the sanctuary?

The sanctuary and the front of the courtyard were both one hundred cubits. 

# What was above the entryway to the inner sanctuary?

Above the entryway to the inner sanctuary there was a measured pattern. 

# What two faces did each cherub have?

Each cherub had the face of a man and the face of a young lion. 

# What did the man say about the wooden altar in front of the holy place?

The man said that the wooden altar was the table that stood before Yahweh. 

# What was carved on the doors of the holy place?

Cherubim and palm trees were carved on the doors of the holy place. 

# To which part of the temple did the man send Ezekiel?

The man sent Ezekiel to the outer courtyard on the north side. 

# For what did the man say the northern and southern rooms in front of the outer courtyard were used?

In those rooms the priests ate the most holy food, and put the most holy things. 

# What were the most holy things of the priests?

The most holy things of the priests were the food offering, the sin offering, and the guilt offering. 

# What kind of place did the man say the northern and southern rooms were?

The man said the northern and southern rooms were holy places. 

# What did the priests have to do before going near the people?

The priests had to dress in other clothes before going near the people. 

# What was the length of each side; north, south east and west?

Each side was five hundred cubits long 

# What was the length of each side; north, south east and west?

Each side was five hundred cubits long 

# What was the length of each side; north, south east and west?

Each side was five hundred cubits long 

# What was the length of each side; north, south east and west?

Each side was five hundred cubits long 

# What two things did the east gate separate between?

The east gate separated between the holy and the not holy. 

# To which place did the man then bring Ezekiel?

The man then brought Ezekiel to the gate that opened to the east. 

# What did Ezekiel see and from what direction did it come?

Ezekiel saw the glory of the God of Israel come from the east. 

# How did Ezekiel get to the inner court?

The Spirit lifted Ezekiel up and brought him to the inner court. 

# What did Yahweh say he would do in the inner court?

Yahweh said he would place his throne there and would live in the midst of the people of Israel there forever. 

# In what way would the people of Israel no longer profane Yahweh's holy name?

The people of Israel would no longer profane Yahweh's holy name by putting the thresholds of their shrines next to Yahweh's. 

# What did Yahweh tell Ezekiel to do about the house he had seen in the vision?

Yahweh told Ezekiel to tell the house of Israel about the house he had seen in the vision. 

# What would Israel have to do in order for Ezekiel to reveal to them the design of the house?

Israel would have to be ashamed of their sins in order for Ezekiel to reveal to them the design of the house. 

# What would Israel have to do in order for Ezekiel to reveal to them the design of the house?

Israel would have to be ashamed of their sins in order for Ezekiel to reveal to them the design of the house. 

# What did Yahweh say was the regulation for the house?

Yahweh said the regulation for the house was that it would be most holy. 

# For what would the hearth on the altar be used?

The hearth on the altar would be used for the burnt offerings. 

# What things pointed upward on the hearth?

There were four horns pointing upward on the hearth. 

# What did Yahweh say would be the sin offering for the Levitical priests on the first day?

Yahweh said a bull from the cattle would be a sin offering for the Levitical priests on the first day. 

# Whose descendants would serve as the Levitical priests at this altar?

The descendants of Zadok would serve as Levitical priests at this altar. 

# What would placing the blood on the altar do for it?

Placing the blood on the altar would cleanse it and make atonement for it. 

# What did Yahweh say would be the sin offering for the Levitical priests on the second day?

Yahweh said a male goat without blemish would be a sin offering for the Levitical priests on the second day. 

# What would the priests have to do for seven days in order to atone for the altar?

The priests would have to prepare an unblemished bull and an unblemished ram as a burnt offering to atone for the altar. 

# What would the priests have to do for seven days in order to atone for the altar?

The priests would have to prepare an unblemished bull and an unblemished ram as a burnt offering to atone for the altar. 

# On the eighth day and onward, what did Yahweh declare he would do?

On the eighth day and onward, Yahweh declared he would accept them. 

# To where did the man bring Ezekiel?

The man brought Ezekiel back to the outer sanctuary gate that faced east. 

# What had been done to the east gate, and why?

The east gate had been sealed shut, because Yahweh the God of Israel had come through it. 

# What had been done to the east gate, and why?

The east gate had been sealed shut, because Yahweh the God of Israel had come through it. 

# About what was Ezekiel told to think regarding the house of Yahweh?

Ezekiel was told to think about the house of Yahweh's entrance and exits. 

# What disgusting actions had the house of Israel done to profane Yahweh's sanctuary?

The house of Israel had brought foreigners with uncircumcised hearts and flesh to the sanctuary. 

# Why did the house of Israel allow foreigners into Yahweh's sanctuary?

The house of Israel allowed foreigners into Yahweh's sanctuary because Israel gave the duty of caring for the sanctuary to them. 

# What had the Levites done who wandered away from Yahweh?

The Levites who had wandered away from Yahweh had performed sacrifices before their idols. 

# What had the Levites done who wandered away from Yahweh?

The Levites who had wandered away from Yahweh had performed sacrifices before their idols. 

# What had the Levites done who wandered away from Yahweh?

The Levites who had wandered away from Yahweh had performed sacrifices before their idols. 

# What did Yahweh say the Levites who wandered away from him would not be allowed to do?

Yahweh declared that the Levites who wandered away from him would not come near him to act as his priests or to approach any of his holy things, the most holy things. 

# Where was Yahweh going to place the Levites who wandered away from him?

Yahweh said he would place them as keepers of the work in the house, for all of its duties and everything that is done in it. 

# Why did Yahweh declare that the sons of Zadok would come near to him and would stand before him?

The sons of Zadok would come near and stand before Yahweh because they fulfilled the duties of Yahweh's sanctuary when the people of Israel wandered away. 

# What kind of clothes were the priests to wear when they came to the gates of the inner courtyard, and why?

The priests were to wear linen clothes when they came to the gates of the inner courtyard so that they did not sweat. 

# What kind of clothes were the priests to wear when they came to the gates of the inner courtyard, and why?

The priests were to wear linen clothes when they came to the gates of the inner courtyard so that they did not sweat. 

# Who was the priest allowed to marry?

The priest was allowed to marry a virgin from the line of the house of Israel, or a widow who was married to a priest. 

# Between what would the priests teach the people the difference?

The priests would teach the people the difference between the holy and the profane, the unclean from the clean. 

# What was the priest's role in a dispute between Israelites?

The priest stood to judge between the people with Yahweh's decrees, and had to be just. 

# Why did the priests not receive any property or inheritance in the land of Israel?

The priests did not receive any property or inheritance in the land of Israel because Yahweh was their inheritance and property. 

# In short what were the priest to eat?

The priests were to eat the food offerings. 

# What were the priests not to eat?

The priests were not to eat any carcass or animal torn by a beast, whether bird or beast. 

# What offering were the people to make to Yahweh when they cast lots to divide up the land?

The people were to make an offering of a holy part of the land when they cast lots to divide up the land. 

# The holy part of the land would be a place for what?

The holy part of the land would be a place for the houses and towns of the priests. 

# The holy part of the land would be a place for what?

The holy part of the land would be a place for the houses and towns of the priests. 

# To whom would the area of the city belong?

The area of the city would belong to all the house of Israel. 

# Whose land would be on both sides of the holy place and the city?

The land of the princes of Israel would be on both sides of the holy place and the city. 

# What does Yahweh tell the princes of Israel to stop doing?

Yahweh tells the princes of Israel to stop evicting Yahweh's people, and to remove violence and strife. 

# What does Yahweh say must be made accurate?

Yahweh says the balances, ephahs, and baths must be made accurate. 

# How much oil from ten baths would be the regulation offering of oil?

A tenth of a bath for every ten baths would be the regulation offering of oil. 

# To whom would the people of the land give their contributions?

The people of the land would give their contributions to the prince in Israel. 

# Who would be responsible to furnish animals for the offerings at the festivals of the house of Israel?

The prince in Israel would be responsible to furnish animals for the offerings. 

# When were the priests to offer an unblemished bull as a sin offering for the sanctuary?

The priests were to offer an unblemished bull as a sin offering on the first day of the first month. 

# When would there be a seven day festival of unleavened bread?

On the fourteenth day of the first month there would be a seven day festival of unleavened bread. 

# What offerings were to be given on the fifteenth day of the seventh month?

On the fifteenth day of the seventh month, sin offerings, burnt offerings, food offerings, and offerings of oil were to be given. 

# When did Yahweh say the east gate of the inner courtyard would be opened?

Yahweh said the east gate of the inner courtyard would be opened on the Sabbath and on the day of the new moon. 

# Where would the prince of Israel worship?

The prince of Israel would worship at the threshold of the inner gate. 

# What would be the burnt offering of the prince on the Sabbath day?

The prince would offer six unblemished lambs and an unblemished ram. 

# What did Yahweh say was the rule about how the prince must leave after he worships?

Yahweh said the rule was that the prince must leave by the same way he came in to worship. 

# What did Yahweh say was the rule about how the people must leave after they worship?

Yahweh said the rule was that the people must leave by going out straight ahead from where they came in. 

# What would the prince have to do at a festival when he gave a freewill offering?

The prince would have to open the east gate for the offering, and then go out and shut the gate after him. 

# What did Yahweh say would be given as a burnt offering every morning?

Yahweh said an unblemished lamb one year old would be given as a burnt offered every morning. 

# According to Yahweh, who would receive the inheritance of the prince?

The inheritance of the prince would be received by his sons. 

# Why did Yahweh say the prince must not take the people's inheritance away?

The people's inheritance must not be taken away so they are not scattered from their own property. 

# Why were the priests not to bring the guilt, sin, and grain offerings out to the outer courtyard?

The priests were not to bring the offerings out to the outer courtyard and so consecrate the people. 

# What would be done in the cooking hearths at the corners of the outer courtyard?

In the cooking hearths at the corners of the outer courtyard, the temple servants would boil the people's sacrifices. 

# Which direction did the temple face in Ezekiel's vision?

The temple faced east. 

# What did Ezekiel see at the gate facing east?

Ezekiel saw water flowing from the gate facing east, on its south side. 

# How deep did the water become that Ezekiel saw?

The water became a river that was too deep to pass without swimming. 

# What were on both sides of the river?

On both sides of the river, the riverbank had many trees. 

# To where did this water flow, and what did it do there?

This water flowed to the Salt Sea and would restore it to freshness. 

# What would not be made fresh at the Salt Sea?

The swamps and marshes would not be made fresh at the Salt Sea. 

# What kind of trees would grow on the riverbanks, and how would they grow?

Edible trees would grow on the riverbanks, bearing fruit each month and never withering. 

# Who would receive two portions of land among the tribes of Israel?

Joseph would receive two portions of land among the tribes of Israel. 

# The northern boundary of the land would reach to the border of what city?

The northern boundary of the land would reach to the border of Damascus. 

# The northern boundary of the land would reach to the border of what city?

The northern boundary of the land would reach to the border of Damascus. 

# What would be the eastern border of the land?

The eastern border of the land would be the Jordan River. 

# What brook would be part of the southern border of the land?

The Brook of Egypt would be part of the southern border of the land. 

# What would be the western border of the land?

The western border of the land would be the Great Sea. 

# How were the Israelites to determine the inheritances for each person in the land?

The Israelites were to throw lots to determine the inheritance for each person in the land. 

# Who were to be treated just like the native born people of Israel?

Foreigners living in the midst of the Israelites were to be treated just like the native born people of Israel. 

# Which tribe would be given the land on the northern border of Israel?

The tribe of Dan would be given the land on the northern border of Israel. 

# Which tribe would be south of the border of the tribe of Dan?

The tribe of Asher would be south of the border of Dan. 

# Which tribe would be south of the border of the tribe of Asher?

The tribe of Naphtali would be south of the border of Asher. 

# In order, which four tribes would be south of the tribe of Naphtali?

In order, the four tribes south of Naphtali would be Manasseh, Ephraim, Reuben, and Judah. 

# In order, which four tribes would be south of the tribe of Naphtali?

In order, the four tribes south of Naphtali would be Manasseh, Ephraim, Reuben, and Judah. 

# In order, which four tribes would be south of the tribe of Naphtali?

In order, the four tribes south of Naphtali would be Manasseh, Ephraim, Reuben, and Judah. 

# In order, which four tribes would be south of the tribe of Naphtali?

In order, the four tribes south of Naphtali would be Manasseh, Ephraim, Reuben, and Judah. 

# What would be in the middle of the land located along the border with Judah?

The temple would be in the middle of the land located along the border with Judah. 

# Who would live on the land surrounding the sanctuary of Yahweh?

The priests of the line of Zadok would live on the land surrounding the sanctuary of Yahweh. 

# Who would live on the land bordering the priests' land?

The Levites would live on the land bordering the priests' land. 

# For what would the remaining area of the holy offering of land be used?

The remaining area of the holy offering of land would be used to produce food for those working in the city. 

# For whom would be the land on the eastern and western borders of the holy offering of land?

The land on the eastern and western borders of the holy offering of land would be for the prince. 

# What was to be the southern boundary of Gad?

The southern boundary of Gad was to extend from Tamar to the waters of Meribah Kadesh, and farther to the brook of Egypt, and then to the Great Sea. 

# How many gates were to be on the north side of the city, and what were they to be named for?

There would be three gates on the north side of the city, with one  being named for Reuben, one for Judah, and one for Levi. 

# How many gates were to be on the north side of the city, and what were they to be named for?

There would be three gates on the north side of the city, with one  being named for Reuben, one for Judah, and one for Levi. 

# What would be the city's name?

The city's name would be "Yahweh is There". 

