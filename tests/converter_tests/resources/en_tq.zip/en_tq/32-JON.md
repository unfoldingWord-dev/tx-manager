# What did Yahweh command Jonah to go and do?

Yahweh commanded Jonah to go to Nineveh and speak out against it. 

# What did Jonah do after he heard Yahweh's command?

Jonah ran away from the presence of Yahweh to go to Tarshish. 

# What did Yahweh do to the ship which Jonah had boarded?

Yahweh sent a great wind on the sea, and it appeared that the ship would break up. 

# What did the sailors do in the midst of the storm?

The sailors became very afraid and each cried out to his own god. 

# How did the sailors determine who was the cause of the evil, and what was the result?

The sailors cast lots to determine who was the cause, and the lot indicated Jonah. 

# What did Jonah say was the cause of the evil that was happening to them?

Jonah told the men that he was running from the presence of Yahweh. 

# What did Jonah tell the men to do in order to stop the storm?

Jonah told the men to throw him into the sea in order to stop the storm. 

# What did Jonah tell the men to do in order to stop the storm?

Jonah told the men to throw him into the sea in order to stop the storm. 

# What two requests did the sailors make of Yahweh?

The asked Yahweh to not let them perish, and to not hold them guilty for Jonah's death. 

# What happened when the sailors threw Jonah into the sea?

When they threw Jonah into the sea, the sea stopped raging. 

# What happened to Jonah when they threw him into the sea?

A great fish swallowed Jonah, and he was in the belly of the fish three days and three nights. 

# What did Jonah do from the belly of the fish?

Jonah called out to Yahweh for help. 

# What did Jonah do from the belly of the fish?

Jonah called out to Yahweh for help. 

# What did Jonah think he would never be able to do again?

Jonah thought he would never be able to see Yahweh's holy temple again. 

# From where did Yahweh bring up Jonah's life?

Yahweh brought Jonah's life up from the pit. 

# What happens to those who pay attention to useless gods?

Those who pay attention to useless gods reject Yahweh's faithfulness to them. 

# What promise did Jonah make from the belly of the fish?

Jonah promised to fulfill that which he had vowed. 

# From where did Jonah say salvation comes?

Jonah said that salvation comes from Yahweh. 

# What did Yahweh tell the fish to do?

Yahweh told the fish to vomit out Jonah upon the dry land. 

# What command did Yahweh give a second time to Jonah?

Yahweh commanded Jonah to go to Nineveh and proclaim Yahweh's message. 

# What command did Yahweh give a second time to Jonah?

Yahweh commanded Jonah to go to Nineveh and proclaim Yahweh's message. 

# How did Jonah respond this time to Yahweh's command?

Jonah obeyed and went to Nineveh. 

# What message did Jonah proclaim in Nineveh?

Jonah proclaimed that in forty days Nineveh would be overthrown. 

# How did the Ninevites respond to Yahweh's message that Jonah preached?

The Ninevites fasted and put on sackcloth, turned from their evil ways, and cried out to God. 

# What hope did the king of Nineveh still have for the people and the city?

The king of Nineveh still hoped that God might relent and turn away from his fierce anger. 

# How did God respond to the Ninevites' repentance?

God changed his mind about the punishment which he had said he would do to them and he did not do it. 

# What seemed terribly wrong to Jonah?

It seemed terribly wrong to Jonah that Yahweh changed his mind and did not punish the Ninevites. 

# Why did Jonah say that he had tried to flee to Tarshish?

Jonah said he knew Yahweh was gracious, compassionate, slow to anger, abundant in loving kindness, and one who relents from sending disaster. 

# What did Jonah want Yahweh to do to him?

Jonah wanted Yahweh to take his life. 

# What question did Yahweh ask Jonah?

Yahweh asked Jonah if it was good that he was angry. 

# Why did Jonah go out of the city and sit down?

Jonah wanted to see what might become of the city. 

# What did Yahweh do to Jonah while he sat outside the city?

Yahweh first prepared a shade plant for Jonah, then had a worm kill it the next day, and then prepared a hot east wind to make Jonah faint. 

# What did Yahweh do to Jonah while he sat outside the city?

Yahweh first prepared a shade plant for Jonah, then had a worm kill it the next day, and then prepared a hot east wind to make Jonah faint. 

# What question did Yahweh then ask Jonah?

Yahweh asked Jonah if it was good that he was angry about the plant. 

# How did Jonah feel about the shade plant?

Jonah had compassion for the plant. 

# For what did Yahweh have compassion?

Yahweh had compassion for the people of Nineveh and the cattle. 

