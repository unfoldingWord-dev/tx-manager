# Who were the kings of Judah when the word of Yahweh came to Micah?

Jotham, Ahaz, and Hezekiah were kings of Judah when the word of Yahweh came to Micah. 

# On what will Yahweh come down and tread?

Yahweh will come down and tread on the pagan shrines on the earth. 

# Why will Yahweh bring this judgment?

Yahweh will bring this judgment because of the rebellion of Jacob, and because of the sins of the house of Israel. 

# How did Samaria gather carved figures, gifts, and idols?

Samaria gathered carved figures, gifts, and idols from the gifts to her prostitution. 

# How did Micah express his grief over the sin of Israel and Jacob?

Micah lamented and wailed, and went barefoot and naked. 

# Why did Beth Ezel mourn?

Beth Ezel mourned, for their protection was taken away. 

# What city was the beginning of sin for the daughter of Zion?

Lachish was the beginning of sin for the daughter of Zion. 

# Why should the Israelites shave their heads?

They should shave their heads, for their children would go into exile from them. 

# Where are people planning to do evil?

They are planning on their beds to do evil. 

# Why will the rich people have no descendants to divide up the territory?

Yahweh will change the territory of the people, and remove it from them. So the rich people will have no descendants to divide up the territory. 

# Why will the rich people have no descendants to divide up the territory?

Yahweh will change the territory of the people, and remove it from them. So the rich people will have no descendants to divide up the territory. 

# From whom do Yahweh's people strip the robe?

They strip the robe from those who pass by unsuspectingly. 

# Why should Yahweh's people get up and leave?

They should get up and leave for this was not a place where they could stay, because of its uncleanness. 

# Who will gather the remnant of Israel?

Yahweh will gather the remnant of Israel. 

# Who eats the flesh of Yahweh's people?

The leaders of Jacob eat the flesh of Yahweh's people. 

# Why will Yahweh hide his face from the leaders of Jacob?

Yahweh will hide his face from the leaders of Jacob because they have done evil deeds. 

# Why will the prophets do no divination?

It will be dark so that the prophets will do no divination. 

# For what do the leaders judge?

The leaders judge for a bribe. 

# When will the mountain of Yahweh's house be established over the other mountains?

In the last days the mountain of Yahweh's house will be established over the other mountains. 

# Why will many nations want to go to the mountain of Yahweh?

Many nations will want to go to the mountain of Yahweh, so he will teach them his ways, and they will walk in his paths. 

# In what do all the peoples walk?

All the peoples walk in the name of their god. 

# Whom will Yahweh assemble?

Yahweh will assemble the lame and gather the outcast, those whom he had afflicted. 

# Where will the daughter of Zion be rescued?

The daughter of Zion will be rescued in Babylon. 

# According to the prophet, who does not know Yahweh's thoughts?

The nations do not know Yahweh's thoughts 

# To whom will Yahweh devote many peoples' unjust wealth?

Yahweh will devote their unjust wealth to himself. 

# With what will the enemy strike the leader of Israel?

They will strike the leader of Israel with a rod on the cheek. 

# For how long will God give up the clans of Judah?

God will give them up, until the time when she who was in labor bears a child. 

# Who will shepherd his flock in the strength of Yahweh?

The child will shepherd his flock in the strength of Yahweh. 

# For what do the remnant of Jacob not wait?

The remnant of Jacob do not wait for man. 

# What will happen when the Israelites' hand will be lifted against their enemies?

When the Israelites' hand is lifted against their enemies, it will destroy them. 

# On whom will Yahweh execute vengeance?

Yahweh will execute vengeance on the nations that have not listened. 

# What will Yahweh do against Israel?

Yahweh will fight in court against Israel. 

# What did Yahweh command his people to do against him?

He commanded them to testify against him. 

# What did Yahweh require from his people?

Yahweh required his people to act justly, love kindness, and walk humbly with their God. 

# Whose tongue is deceitful?

The tongue of the inhabitants who have spoken lies is deceitful. 

# Why did Yahweh make the city a ruin?

Yahweh made the city a ruin because of his sins. 

# By whose advice did the city walk?

The city walked by the advice of Omri and Ahab. 

# Who perished from the earth?

The godly man perished from the earth. 

# Who foretold the day of the punishment of the remaining people?

The watchmen foretold the day of the punishment of the remaining people. 

# Who are a man's enemies?

A man's enemies are the people of his own house. 

# What would happen after Micah falls?

After Micah falls, he will rise. 

# For how long will Micah bear Yahweh's rage?

Micah will bear Yahweh's rage until Yahweh pleaded his cause, and executed judgment for Micah. 

# At whom will Micah's eyes look?

Micah's eyes will look at his enemy. 

# What will happen when a day comes to build the walls?

When a day comes to build the walls, the boundaries will be extended very far. 

# What will happen when a day comes to build the walls?

When a day comes to build the walls, the boundaries will be extended very far. 

# How did Micah ask Yahweh to shepherd his people?

Micah asked Yahweh to shepherd his people with his rod. 

# What will Yahweh show his people?

Yahweh will show them wonders. 

# What will the nations see and be ashamed of?

They will see and be ashamed of all their power. 

# Who will the nations come to and be afraid of?

The nations will come to Yahweh and they will be afraid because of him. 

# Why will Yahweh not keep his anger anger forever?

Yahweh will not keep his anger forever, because he loves to show his covenant faithfulness. 

# Into what will Yahweh throw all the sins of the people of Israel?

Yahweh will throw all their sins into the depths of the sea. 

