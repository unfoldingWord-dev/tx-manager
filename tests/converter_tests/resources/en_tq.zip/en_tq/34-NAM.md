# Of what is Yahweh full?

Yahweh is full of wrath. 

# On whom does Yahweh take vengeance?

Yahweh takes vengeance on his adversaries. 

# Where does Yahweh make his way?

Yahweh makes his way in the whirlwind and the storm. 

# What is happening to the flowers of Lebanon?

The flowers of Lebanon are weak. 

# What happens to the earth in Yahweh's presence?

The earth collapses in Yahweh's presence. 

# To what can we compare Yahweh in the day of trouble?

Yahweh is a stronghold in the day of trouble. 

# Into what will Yahweh pursue his enemies?

Yahweh will pursue his enemies into darkness. 

# What will Yahweh do to the people's yoke?

He will break the people's yoke from them. 

# Why will Yahweh dig graves for the people of Nineveh?

He will dig their graves, for they are wicked. 

# Where are the feet of him who brings good news?

On the mountains are the feet of him who brings good news. 

# Why should Judah celebrate the festivals and keep its vows?

Judah should celebrate its festivals and keep its vows, for the wicked one will invade them no more. 

# What is Yahweh restoring?

Yahweh is restoring the majesty of Jacob. 

# What color are the shields of his mighty men?

The shields of his mighty men are red. 

# What speeds through the streets?

The chariots speed through the streets. 

# What has been decreed?

It has been decreed: the queen is stripped and taken away; her female servants moan like doves, beating on their breasts. 

# What will the people of Nineveh do?

They will flee away like rushing water. 

# Of what were the lions afraid?

They were afraid of nothing. 

# With what did the lion fill his cave and his dens?

The lion filled his cave with victims and his dens with his prey. 

# What will Yahweh do to Nineveh?

Yahweh will burn their chariots in the smoke, devour their young lions, and cut off their prey from the land. 

# Of what is the city full?

The city is full of blood, lies and stolen property. 

# How many people will be killed by the attacking horsemen?

There will be heaps of corpses, a great pile of bodies, and no end of the bodies. 

# Why are these things happening?

This is happening because of the lustful actions of the beautiful prostitute. 

# What will Yahweh of hosts do against the prostitute because he is against her?

Yahweh will raise up her skirt over her face and show her private parts to the nations, her shame to the kingdoms. He will throw disgusting filth on her and make her vile. He will make her someone that everyone will look at. 

# What will Yahweh of hosts do against the prostitute because he is against her?

Yahweh will raise up her skirt over her face and show her private parts to the nations, her shame to the kingdoms. He will throw disgusting filth on her and make her vile. He will make her someone that everyone will look at. 

# Whose wall was the sea?

Thebe's wall was the sea. 

# Who threw lots for Thebes' honorable men?

Thebes' enemies threw lots for her honorable men. 

# If Nineveh's fortresses are shaken, what happens?

If Nineveh's fortresses are shaken, they fall into the mouth of the eater. 

# How many princes are there?

The princes are as many as the locusts. 

# What will everyone who hears the news about you do?

Everyone who hears the news about you will clap their hands in joy over you. 

