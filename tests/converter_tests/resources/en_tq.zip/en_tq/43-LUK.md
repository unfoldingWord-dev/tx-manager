# Who were the "eyewitnesses" that Luke mentions?

The "eyewitnesses" were the ones who were with Jesus from the beginning of his ministry. 

# Who were the "eyewitnesses" that Luke mentions?

The "eyewitnesses" were the ones who were with Jesus from the beginning of his ministry. 

# What did some of the eyewitnesses do after they saw what Jesus did?

They wrote down an account or story of what Jesus did. 

# Why did Luke decide to write his own account of what Jesus said and did?

He wanted Theophilus to know the truth about the things he had been taught. 

# Why did God consider Zechariah and Elizabeth to be righteous?

God considered them to be righteous because they obeyed his commandments. 

# Why did Zechariah and Elizabeth have no children?

They did not have children because Elizabeth was unable to bear a child. Now she and Zechariah were very old. 

# What work was Zechariah doing in the temple in Jerusalem?

Zechariah was serving as a priest. 

# What did Zechariah do in the temple?

He burned incense to God. 

# What did the people do while Zechariah was in the temple?

The people stayed outside in the courtyard and were praying. 

# Who appeared to Zechariah while he was in the temple?

An angel of the Lord appeared to Zechariah in the temple. 

# How did Zechariah act when he saw the angel?

When Zechariah saw the angel, he became very afraid. 

# What did the angel say to Zechariah?

The angel told Zechariah not to be afraid and that his wife Elizabeth would have a son. His son's name would be John. 

# What did the angel say John would do for the sons of Israel?

The angel said John would turn the sons of Israel back to the Lord their God. 

# All of John's deeds would make ready what kind of people?

A people prepared for the Lord would be made ready. 

# What was the angel's name and where did he normally stay?

The angel's name was Gabriel and he normally stood in the presence of God. 

# What did the angel say would happen to Zechariah because he did not believe the angel's words?

Zechariah would not be able to speak until the child was born. 

# Sixth months after Elizabeth's conception, who was Gabriel sent by God to see?

A virgin named Mary, who was engaged to Joseph, a descendant of David. 

# What did the angel say would happen to Mary?

The angel said that Mary would become pregnant. 

# What was the child to be named and what would he do?

The child was to be named Jesus and he would reign over the descendants of Jacob forever with no end to his kingdom. 

# How did the angel say this would happen since Mary was a virgin?

The angel said that the Holy Spirit would come upon Mary and the power of the Most High would overshadow her. 

# The angel said that this holy child would be whose son?

The angel said that the child would be called the Son of God. 

# What did the angel say is impossible for God?

Nothing. 

# When Mary greeted Elizabeth, what did Elizabeth's baby do?

The baby leaped in her womb for joy. 

# Who did Elizabeth say was blessed?

Elizabeth said that Mary and her baby were blessed. 

# Mary then said that these powerful acts of God would fulfill which promises made by God?

They would fulfill God's promises to Abraham and his descendants to be merciful to them and to help them. 

# On the day of circumcision, what would they normally have named Elizabeth's son?

Zechariah. 

# What did Zechariah write when asked what the name of the child should be?

Zechariah wrote "His name is John." 

# What happened to Zechariah immediately after he wrote the child's name?

Immediately after he wrote the child's name, Zechariah spoke and praised God. 

# Because of all these events what did everyone realize about the child?

They realized that the hand of the Lord was with him. 

# Zechariah praised God because God had now come to make a way for what to happen?

God had now made a way to set his people free. 

# Zechariah prophesied that his child John would help the people know what?

John would help the people know how they could be saved through the forgiveness of their sins. 

# Where did John grow up and live until he began to appear publicly?

John grew up and lived in the desert areas. 

# Where did the people go to be registered for the census?

The people went to their own town to be registered. 

# Joseph went to Bethlehem with Mary because he was a descendant of whom?

Joseph and Mary went to Bethlehem because Joseph was a descendant of David. 

# When Mary gave birth to her son, where did she place him?

When the child was born, Mary placed him in an animal feeding trough. 

# To whom did the angel appear?

The angel appeared to shepherds who were tending their flocks. 

# To whom did the angel appear?

The angel appeared to shepherds who were tending their flocks. 

# How did the shepherds react when they saw the angel?

The shepherds were very afraid. 

# What good news did the angel give to the shepherds?

The angel told the shepherds that the Savior had been born, the one who is Christ the Lord. 

# What did the shepherds do after the angels left them?

The shepherds went to Bethlehem to see the child that had been born. 

# What did the shepherds do after the angels left them?

The shepherds went to Bethlehem to see the child that had been born. 

# When was Jesus circumcised?

Jesus was circumcised on the eighth day after his birth. 

# Why did Joseph and Mary bring the baby Jesus to the temple in Jerusalem?

They brought him to the temple to present him to the Lord and to offer a sacrifice, which was commanded in the Law of Moses. 

# Why did Joseph and Mary bring the baby Jesus to the temple in Jerusalem?

They brought him to the temple to present him to the Lord and to offer a sacrifice, which was commanded in the Law of Moses. 

# Why did Joseph and Mary bring the baby Jesus to the temple in Jerusalem?

They brought him to the temple to present him to the Lord and to offer a sacrifice, which was commanded in the Law of Moses. 

# What did the Holy Spirit reveal to Simeon?

The Holy Spirit revealed to Simeon that he would not die before he saw the Lord's Christ. 

# What did Simeon say that Jesus would be?

Simeon said that Jesus would be a light for revealing truth to the Gentiles and the glory of God's people Israel. 

# What did Simeon say would happen to Mary as a result of Jesus?

Simeon said that a sword would pierce her soul. 

# What did the prophetess Anna do when she came up to Mary, Joseph, and Jesus?

Anna began to thank God and to talk about the child to everyone. 

# What happened to the child Jesus after he returned to Nazareth?

Jesus grew and became strong, increasing in wisdom, and the grace of God was upon him. 

# Why did Jesus' parents not realize he had stayed behind in Jerusalem during the Festival of the Passover?

They did not realize because they assumed that he was in the group that was traveling with them. 

# Why did Jesus' parents not realize he had stayed behind in Jerusalem during the Festival of the Passover?

They did not realize because they assumed that he was in the group that was traveling with them. 

# Where did his parents find Jesus and what was he doing?

His parents found him in the temple sitting in the middle of the teachers, listening to them and asking them questions. 

# What did Jesus answer when Mary said to him that they had been anxiously searching for him?

"Did you not know I must be in my Father's house?" 

# What was Jesus' attitude toward his parents when they returned to Nazareth?

He was obedient to them. 

# As Jesus grew up, what kind of young man was he?

He grew in wisdom and stature, and increased in favor with God and people. 

# What message did John preach throughout the region around the Jordan River?

John preached a baptism of repentance for the forgiveness of sins. 

# For whom did John say he was making ready the way?

John said he was making ready the way of the Lord. 

# John told the people not to trust in the fact that Abraham was their father, but to do what instead?

John told them to produce fruits that come from repentance. 

# What did John say happens to the tree that does not produce good fruit?

John said that it is chopped down and thrown into the fire. 

# What did John tell the tax collectors they must do to show true repentance?

John said that they must not collect more money than they are supposed to. 

# John told the people that he baptized with water, but that someone was coming who would baptize with what?

John said someone was coming who would baptize with the Holy Spirit and with fire. 

# Why did John rebuke Herod?

John rebuked Herod because Herod had married his own brother's wife, and for doing many other evil things. 

# Who put John into prison?

Herod put John into prison. 

# What happened right away after John baptized Jesus?

After John baptized Jesus, the heavens opened up and the Holy Spirit came down on him like a dove. 

# What happened right away after John baptized Jesus?

After John baptized Jesus, the heavens opened up and the Holy Spirit came down on him like a dove. 

# What did the voice from heaven say?

The voice from heaven said, "You are my beloved son. I am very pleased with you". 

# About how old was Jesus when he began to teach?

Jesus was about thirty years old when he began to teach. 

# Who led Jesus into the wilderness?

The Holy Spirit led Jesus into the wilderness. 

# How long did the devil tempt Jesus in the wilderness?

The devil tempted Jesus in the wilderness for 40 days. 

# What did the devil challenge Jesus to do with the stones on the ground?

The devil told Jesus to turn the stones into bread. 

# What was Jesus' response to the devil?

Man shall not live on bread alone. 

# What did the devil show to Jesus from a high place?

The devil showed Jesus all of the kingdoms of the world. 

# What did the devil want Jesus to do?

The devil wanted Jesus to bow down and worship him. 

# What was Jesus' response to the devil?

You must worship the Lord your God, and you must serve him only. 

# What did the devil tell Jesus to do when he took him to the highest point of the temple?

He told Jesus to jump down from there. 

# What was Jesus' response to the devil?

You must not test the Lord your God. 

# What did the devil do after Jesus refused to jump from the temple?

The devil left Jesus until another time. 

# From which book of the scriptures did Jesus read when he stood up in the synagogue?

Jesus read from the prophet Isaiah. 

# What did Jesus say was being fulfilled on that day?

Jesus said that the scripture he had just read from Isaiah was being fulfilled that day. 

# What kind of reception did Jesus say a prophet receives in his own country?

Jesus said that no prophet is accepted in his own country. 

# In Jesus' first example to the people in the synagogue, where did God send Elijah to help someone?

God sent Elijah to Zarephath, near the city of Sidon. 

# In Jesus' second example to the people in the synagogue, God had Elisha help someone from what country?

God had Elisha help Naaman the Syrian. 

# What did the people in the synagogue do when they heard these examples from Jesus?

They were filled with rage and wanted to throw him over the cliff. 

# What did the people in the synagogue do when they heard these examples from Jesus?

They were filled with rage and wanted to throw him over the cliff. 

# How did Jesus avoid being killed by the people from the synagogue?

Jesus walked right through their midst. 

# In the synagogue, what did the demon speaking through the man know about Jesus?

The demon said that he knew Jesus was the Holy One of God. 

# How did the people react after Jesus cast out the demon?

The people were amazed and kept talking about it with one another. 

# What did Jesus do for the sick who were brought to him?

Jesus laid his hands on every one of them and healed them. 

# What did the demons say as they were cast out, and why did Jesus not let them speak?

The demons said that Jesus was the Son of God, and Jesus did not let them speak because they knew he was the Christ. 

# What did Jesus say was the reason he was sent?

Jesus said he was sent to preach the good news about the kingdom of God to many other cities. 

# After using Simon's boat as a place to teach the people, what did Jesus ask Simon to do with his boat?

Take the boat out to deeper water and let his nets down into the water to catch some fish. 

# Even though Peter had caught nothing the previous night, what did he do?

He obeyed and let down the nets. 

# What happened when they let down the nets?

They gathered a very large number of fish, so much that their nets were breaking. 

# What did Simon then want Jesus to do? Why?

Simon wanted Jesus to go away from him because Simon knew that he (Simon) was a sinful man. 

# What did Jesus say to Simon about his future work?

Jesus said that from now on he would be catching men. 

# At this time, how many people were coming to hear Jesus teach and to be healed of their sicknesses?

Great crowds of people were coming to Jesus. 

# What did Jesus say to the paralyzed man whose friends let him down through the housetop?

Man, your sins are forgiven you. 

# Why did the scribes and the Pharisees think that this statement was blasphemy?

Because God alone can forgive sins. 

# Jesus healed the paralytic man in this way to demonstrate that he had authority on earth to do what?

Jesus healed the man to demonstrate that he had authority on earth to forgive sins. 

# When Jesus was eating and drinking at Levi's house, what did Jesus say that he came to do?

He came to call sinners to repentance. 

# When did Jesus say that his disciples would fast?

His disciples would fast after Jesus was taken away from them. 

# In Jesus' parable, what would happen if a new piece of cloth is used to mend an old garment?

The new cloth would tear, and would not fit the old garment. 

# In Jesus' second parable, what would happen if new wine is put into old wine skins?

The old wine skins would burst and the new wine would be spilled. 

# What did Jesus say must be done to keep new wine properly?

New wine must be put into fresh wine skins. 

# What were Jesus' disciples doing on the Sabbath that the Pharisees said was against the law?

They were picking heads of grain, rubbing them between their hands, and eating the grain. 

# What title did Jesus claim for himself that gave him the authority to say what was lawful to do on the Sabbath?

Jesus claimed the title, Lord of the Sabbath. 

# When Jesus healed the man with the shriveled hand on the Sabbath, how did the scribes and Pharisees react?

They were filled with anger, and talked about what they might do to Jesus. 

# What was the name given to the twelve men that Jesus chose on the mountain?

Jesus called them "apostles." 

# What kind of people did Jesus say were blessed?

Those who are poor, hungry, weeping, and hated for the Son of Man's sake are blessed. 

# What kind of people did Jesus say were blessed?

Those who are poor, hungry, weeping, and hated for the Son of Man's sake are blessed. 

# According to Jesus, why should such people rejoice and leap for joy?

Because they will have a great reward in heaven. 

# How did Jesus say his disciples should treat their enemies and those who hate them?

They should love their enemies and do good to those who hate them. 

# What is the Most High Father's attitude toward unthankful and evil people?

He is kind and merciful toward them. 

# What is the Most High Father's attitude toward unthankful and evil people?

He is kind and merciful toward them. 

# Before removing the speck from our brother's eye, what did Jesus say we must do first?

First, we must remove the log from our own eyes so that we are not hypocrites. 

# What comes forth from the good treasure in a good man's heart?

What comes forth from a good man's heart is good. 

# What comes forth from the evil treasure in an evil man's heart?

What comes forth from an evil man's heart is evil. 

# The man who builds a house on the solid rock does what with Jesus' words?

He hears Jesus' words and obeys them. 

# The man who builds a house without a foundation does what with Jesus' words?

He hears Jesus' words and does not obey them. 

# What did the centurion first ask Jesus to do when he sent the Jewish elders to Jesus?

He asked Jesus to come to his house and to heal his slave. 

# Why did the centurion then send friends to tell Jesus that he did not have to come to the house?

The centurion said he was not worthy that Jesus should come to his house. 

# How did the centurion then want Jesus to heal the slave?

the centurion then wanted Jesus to heal the slave by just saying a word. 

# What did Jesus say about the faith of the centurion?

Jesus said that not even in Israel had he found anyone with so much faith. 

# What was Jesus' attitude toward the widow who's only son had died?

He was deeply moved with compassion. 

# What did the people say about Jesus after he raised the widow's son from the dead?

They said that a great prophet had been raised among them, and that God had looked upon his people. 

# How did Jesus demonstrate to John's disciples that he was the Coming One?

Jesus healed the blind, lame, lepers, and deaf, and he raised the dead. 

# Who did Jesus say that John was?

Jesus said John was much more than a prophet. 

# What did the Pharisees and the experts in Jewish law do to themselves when they refused to be baptized by John?

They rejected God's counsel for themselves. 

# What accusation was made against John the Baptizer because he did not eat bread or drink wine?

They said, "He has a demon." 

# What accusation was made against Jesus because he came eating and drinking?

They said, "He is a gluttonous man and a drunkard." 

# What did the woman of the city do to Jesus in the Pharisee's house?

She wet Jesus' feet with her tears, wiped them with her hair, kissed his feet, and anointed his feet with perfume. 

# Jesus said that because she was forgiven many sins, she would do what?

She would love much. 

# How did those reclining at the table react when Jesus told the woman that her sins were forgiven?

They asked, "Who is this that even forgives sins?" 

# What did a large group of women do for Jesus and his disciples?

The women provided for them from their own material resources. 

# In Jesus' parable, what is the seed that is sown?

The seed is the word of God. 

# Who are the seeds that fall by the wayside, and what happens to them?

They are people who hear the word, but then the devil comes and takes it away, so that they may not believe and be saved. 

# Who are the seeds that fall on the rocky ground, and what happens to them?

They are people who receive the word with joy, but then stop believing during a time of testing. 

# Who are the seeds that fall among the thorns, and what happens to them?

They are people who hear the word, but then it is choked by the cares and riches and pleasures of this life, and they bring no fruit to maturity. 

# Who are the seeds that fall on the good ground, and what happens to them?

They are people who hear the word, hold onto it, and produce fruit with perseverance. 

# Who did Jesus say his mother and brothers are?

They are people who hear the word of God and obey it. 

# What did the disciples say when Jesus calmed the winds and water?

They said, "Who is this that commands even the winds and the water, and they obey him?" 

# What did the demons cause the man from the region of the Gerasenes to do?

They made him live without clothes in the tombs, they made him break chains and shackles, and they often drove him into the wilderness. 

# Where did the demons go after Jesus commanded them to leave the man?

The demons entered into a herd of pigs, which rushed into a lake and drowned. 

# What did Jesus tell the man to go and do?

Jesus told him to go to his house and recount all the great things God had done for him. 

# According to Jesus, what had caused the woman with bleeding to be healed?

She was healed because of her faith in Jesus. 

# What did Jesus do at Jairus' house?

Jesus raised Jairus' daughter from the dead. 

# What did Jesus send the twelve out to do?

Jesus sent them out to preach the kingdom of God and to heal the sick. 

# Herod heard from some people three possible explanations of who Jesus was. What were they?

Some said Jesus was John the Baptizer risen from the dead, some said Elijah had appeared, and some said an ancient prophet had risen. 

# Herod heard from some people three possible explanations of who Jesus was. What were they?

Some said Jesus was John the Baptizer risen from the dead, some said Elijah had appeared, and some said an ancient prophet had risen. 

# What food did the disciples have to feed the crowd?

They had five loaves of bread and two fish. 

# How many men were following Jesus in the crowd that was in the desert place?

About five thousand men were there. 

# What did Jesus do with the five loaves and two fish?

He looked up to heaven, blessed them, broke them into pieces, and gave them to the disciples to give to the crowd. 

# How many baskets of leftover food were there?

There were twelve baskets full of leftover food. 

# When Jesus asked the disciples who he was, what did Peter answer?

He said, "The Christ from God." 

# Jesus said that if anyone wants to come after him, he must do what?

He must deny himself, take up his cross daily, and follow Jesus. 

# What happened to Jesus' appearance on the mountain?

The appearance of his face changed and his clothing became white and dazzling. 

# Who appeared with Jesus?

Moses and Elijah appeared with Jesus. 

# What did the voice say from the cloud that overshadowed them?

The voice said, "This is my chosen son; listen to him." 

# Before Jesus cast out the demon, what did it cause the man's son to do?

The demon caused him to scream and have convulsions with foaming at the mouth. 

# What statement did Jesus make to the disciples that they did not understand?

He said, "The Son of Man will be delivered over into the hands of men." 

# Who did Jesus say is the one who is great among the disciples?

The one who is least among them is the one who is great. 

# As the days were approaching when Jesus would go up to heaven, what did he do?

He resolutely set his face to go to Jerusalem. 

# To be fit for the kingdom of God, what must a person not do once he has "put his hand to the plow?"

The person must not look back. 

# What did Jesus tell the seventy not to carry with them?

They must not carry any bag of money, any traveler's bag, or any sandals. 

# What did Jesus tell the seventy to do in each city?

He told them to heal the sick and to say to the people, "The kingdom of God has come near to you." 

# If a city did not receive those whom Jesus sent to them, what would the judgment be like for that city?

It would be worse than the judgment on Sodom. 

# When the seventy returned and reported with joy that they were able to cast out demons, what did Jesus say to them?

He said, "Rejoice even more that your names are engraved in heaven." 

# Jesus said it was well-pleasing to the Father to reveal the kingdom of God to whom?

It was well-pleasing to the Father to reveal the kingdom of God to those who are untaught, like little children. 

# According to Jesus, what does the Jewish law say a person must do to inherit eternal life?

You must love the Lord your God with all your heart, and with all your soul, and with all your strength, and with all your mind, and your neighbor as yourself. 

# In Jesus' parable, what did the Jewish priest do when he saw the half dead man on the road?

He passed by on the other side. 

# What did the Levite do when he saw the man?

He passed by on the other side. 

# What did the Samaritan do when he saw the man?

He bound up his wounds, put him on his animal, brought him to an inn, and took care of him. 

# After telling the parable, what did Jesus tell the teacher of the Jewish law to go and do?

Go and show mercy like the Samaritan in the parable. 

# What did Mary do at the same time?

She sat at Jesus' feet and listened to him. 

# What did Martha do when Jesus came to her house?

She was overly busy with preparing to serve a meal. 

# Who did Jesus say had chosen the better thing to do?

He said that Mary had chosen the better thing to do. 

# What prayer did Jesus teach his disciples to pray?

He prayed, "Father, sanctify your name. Let your kingdom come. Give us each day our daily bread and forgive us our sins, for we ourselves forgive everyone who is in debt to us. And do not lead us into temptation." 

# What prayer did Jesus teach his disciples to pray?

He prayed, "Father, sanctify your name. Let your kingdom come. Give us each day our daily bread and forgive us our sins, for we ourselves forgive everyone who is in debt to us. And do not lead us into temptation." 

# In Jesus' parable, why did the man get up and give his friend bread at midnight?

Because of the friend's shameless persistence. 

# What will the Father in heaven give to those who ask him?

He will give the Holy Spirit. 

# When they saw him drive out demons, what did some accuse Jesus of doing?

They accused him of driving out demons by Beelzebul, the ruler of demons. 

# Jesus answered that he drove out demons by what power?

He drove out demons by the finger of God. 

# If an unclean spirit leaves a man but then later returns, what will be the final condition of the man?

The final condition of the man will be worse than the first condition. 

# When the woman cried out, blessing Jesus' mother, who did Jesus say was blessed?

Those who hear the word of God and keep it. 

# Jesus said that he was greater than which two Old Testament men?

Solomon and Jonah. 

# What did Jesus say the Pharisees were filled with on the inside?

He said they were filled with greed and evil. 

# What did Jesus say the Pharisees neglected?

They neglected justice and the love of God. 

# What did Jesus say the teachers of the law were doing to other men?

They were burdening men with burdens hard to carry, but not touching those burdens themselves. 

# Jesus said this generation would be held responsible for what?

They would be held responsible for all the blood of the prophets shed since the world began. 

# What did the scribes and Pharisees do after hearing Jesus' words?

They opposed him and argued with him, trying to trap him in his own words. 

# According to Jesus, what will happen to everything you say in darkness?

It will be heard in the light. 

# Who did Jesus say that you should fear?

You should fear the one who has authority to throw you into hell. 

# What will Jesus do for everyone who confess Jesus' name before men?

Jesus will confess that person's name before the angels of God. 

# According to Jesus, our life does not consist of what?

Our life does not consist in the abundance of our possessions. 

# In Jesus' parable, what was the rich man going to do because his fields yielded abundantly?

He was going to pull down his barns and build bigger ones, and then rest easy, eat, drink, and be merry. 

# In Jesus' parable, what was the rich man going to do because his fields yielded abundantly?

He was going to pull down his barns and build bigger ones, and then rest easy, eat, drink, and be merry. 

# What did God say to the rich man?

He said, "Foolish man, tonight your soul is required of you; and the things you have prepared, whose will they be?" 

# Instead of being anxious about the things of life, what did Jesus say we should do?

We should seek the kingdom of God. 

# Where did Jesus say we should store our treasures, and why?

We should store our treasures in the heavens, because that is where no thief comes and no moth destroys. 

# According to Jesus, which servants of God are blessed?

Those are blessed who are found watching and ready when Jesus comes. 

# Do we know the hour when Jesus will come?

No. 

# What happens to the servant who abuses the other servants and is not ready for his master's return?

The master will cut him in pieces and appoint a place for him with the unfaithful. 

# What is required of those to whom much is given?

Much is required of them. 

# According to Jesus, what kinds of divisions will he bring on the earth?

There will be people in the same house divided against each other. 

# According to Jesus, what kinds of divisions will he bring on the earth?

There will be people in the same house divided against each other. 

# According to Jesus, what should we do before we go with our adversary before the magistrate?

We should make an effort to settle the matter beforehand. 

# Did the Galileans who were killed by Pilate suffer in this way because they were more sinful than the other Galileans?

No. 

# In Jesus' parable, what was done with the fig tree that did not bear fruit after three years?

It was given manure as fertilizer and one more year to bear fruit; if it did not, it would be cut down. 

# In Jesus' parable, what was done with the fig tree that did not bear fruit after three years?

It was given manure as fertilizer and one more year to bear fruit; if it did not, it would be cut down. 

# In the synagogue, what had caused the woman to be bent over for eighteen years?

An evil spirit of weakness from Satan had bound her. 

# Why was the synagogue ruler indignant when Jesus healed the woman?

Because Jesus healed her on the Sabbath. 

# How did Jesus show that the synagogue ruler was a hypocrite?

Jesus reminded him that he would untie his animal on the Sabbath, yet he was indignant when Jesus unbound the woman on the Sabbath. 

# How is the kingdom of God like a mustard seed?

Because it starts small like a seed, but then grows into something large with many places to dwell. 

# When asked if many would be saved, what did Jesus answer?

He said, "Struggle to enter through the narrow door, because many will try and will not be able to enter." 

# What will the people do who are thrown outside, and are not able to enter God's kingdom?

They will cry and grind their teeth. 

# Who will gather to relax at the dinner table in the kingdom of God?

Abraham, Isaac, Jacob, the prophets, and many from the east, west, north, and south. 

# Who will gather to relax at the dinner table in the kingdom of God?

Abraham, Isaac, Jacob, the prophets, and many from the east, west, north, and south. 

# Where did Jesus say that he must be killed?

He must be killed in Jerusalem. 

# What did Jesus desire to do with the people of Jerusalem?

He desired to gather them the way a hen gathers her brood of chicks. 

# How did the people of Jerusalem respond to Jesus' desire for them?

They rejected it. 

# Therefore, what did Jesus prophesy about Jerusalem and its people?

Their house was abandoned, and they would not see Jesus again until they said, "Blessed is he who comes in the name of the Lord." 

# With the man suffering from edema standing in front of him, what did Jesus ask the experts in the Jewish law and the Pharisees?

Is it lawful to heal on the Sabbath, or not? 

# What was the experts' and Pharisees' answer?

They kept silent. 

# After healing the man, how did Jesus show that the experts and Pharisees were hypocrites?

Jesus reminded them that they would help their own son or ox that fell into a well on the Sabbath. 

# What did Jesus say will happen to whoever exalts himself?

He will be humbled. 

# What did Jesus say will happen to whoever humbles himself?

He will be exalted. 

# According to Jesus, how will a person be rewarded who invites the poor, crippled, lame, and blind into their home?

They will be repaid at the resurrection of the just. 

# In Jesus' parable of the dinner, what did the people do who were originally invited?

They began to make excuses about why they could not come to the dinner. 

# Who did the master then invite to his dinner?

The poor, crippled, blind, and lame. 

# What did the master then say about those who were first invited to his dinner?

None of them would taste his dinner. 

# According to Jesus, what must his disciples do?

They must hate their own family and life, carry their own cross, come after him, and give up all that they have. 

# According to Jesus, what must his disciples do?

They must hate their own family and life, carry their own cross, come after him, and give up all that they have. 

# In Jesus' example about what it requires to follow him, what must a person do first who desires to build a tower?

The person must count the cost. 

# According to Jesus, what must his disciples do?

They must hate their own family and life, carry their own cross, come after him, and give up all that they have. 

# If salt loses its taste, what is done with it?

It is thrown away. 

# In Jesus' parable, what does the shepherd do who loses one of his hundred sheep?

He leaves the other ninety-nine and goes and finds the lost sheep, then brings it back, rejoicing. 

# In Jesus' parable, what does the shepherd do who loses one of his hundred sheep?

He leaves the other ninety-nine and goes and finds the lost sheep, then brings it back, rejoicing. 

# In Jesus' parable, what does the woman do who loses one of her ten silver coins?

She diligently searches until she finds it, then rejoices with her friends and neighbors. 

# In Jesus' parable, what does the woman do who loses one of her ten silver coins?

She diligently searches until she finds it, then rejoices with her friends and neighbors. 

# What happens in heaven when one sinner repents?

There is joy in the presence of the angels of God. 

# In Jesus' parable, what request did the younger son make to his father?

Give me now the property I am due to inherit. 

# What did the younger son do with his inheritance?

He wasted the money with wildly extravagant living. 

# After his money was gone, what did the younger son do in order to live?

He hired himself out to feed another man's pigs. 

# When he began to think clearly, what did the younger son decide to do?

He decided to go and confess his sin to his father, and ask to be hired as one of his servants. 

# When he began to think clearly, what did the younger son decide to do?

He decided to go and confess his sin to his father, and ask to be hired as one of his servants. 

# What did the father do when he saw the younger son coming back home?

He ran and hugged and kissed him. 

# What did the father quickly do for the younger son?

The father gave him a robe, a ring, and sandals, and arranged a feast. 

# What did the father quickly do for the younger son?

The father gave him a robe, a ring, and sandals, and arranged a feast. 

# What was the older son's reaction when he was told about the feast for the younger son?

He was angry and would not go in to the feast. 

# What was the older son's complaint to his father?

The older son complained that he had followed his father's rules, but had never been given a goat to have a feast with his friends. 

# What was the father's response to the older son?

He said, "Son, you are always with me, and all that is mine is yours." 

# Why did the father say it was proper to have a feast for the younger son?

Because the younger son was lost and has now been found. 

# What report did the rich man hear about his manager?

He heard that the manager was squandering the rich man's possessions. 

# What did the manager do just before he was forced to leave his job?

He called for each one of the rich man's debtors and reduced their debt. 

# What did the manager do just before he was forced to leave his job?

He called for each one of the rich man's debtors and reduced their debt. 

# What did the manager do just before he was forced to leave his job?

He called for each one of the rich man's debtors and reduced their debt. 

# What was the rich man's response to his manager's actions?

He commended the manager because he had acted shrewdly. 

# What did Jesus tell others to do based on this story?

He said, "Make friends for yourselves by means of worldly wealth, so that when it is gone, they may welcome you into the eternal dwellings." 

# Jesus said that a person who is faithful with a little will also be faithful with what else?

The person will also be faithful with much. 

# Which two masters did Jesus say we must choose between to serve?

We must choose between God and wealth. 

# According to Jesus, what were in effect until John the Baptizer came?

The law and the prophets were in effect. 

# According to Jesus, what is now being preached?

The gospel of the kingdom of God is now being preached. 

# According to Jesus, what kind of person is one who divorces his wife and marries another?

This person is an adulterer. 

# In Jesus' story, where did the beggar Lazarus go after he died?

The beggar Lazarus was carried by angels to Abraham's side. 

# Where did the rich man go after he died?

To torment in hades. 

# What was the first request that the rich man made to Abraham?

He said, "Please have Lazarus come and bring me a little water because I am in anguish in this flame." 

# What was Abraham's answer to the rich man?

He said, "There is a great chasm between us that no one can cross." 

# What was the second request that the rich man made to Abraham?

He said, "Please send Lazarus to warn my brothers about this place." 

# What was the second request that the rich man made to Abraham?

He said, "Please send Lazarus to warn my brothers about this place." 

# What was Abraham's answer to the rich man?

He said, "They have Moses and the prophets; let them listen to them." 

# Abraham said that if they would not listen to Moses and the prophets, what else would not persuade them?

They will not be persuaded even if someone rises from the dead. 

# What did Jesus say we must do if our brother sins against us and returns saying, "I repent?"

We must forgive him. 

# As servants, what should we say after we have done everything commanded us by our Master?

We should say, "We are unworthy servants; we have only done what we ought to do." 

# Who did Jesus meet when entering a village in the borderlands of Samaria and Galilee?

He met ten lepers. 

# What did they say to Jesus?

They said, "Jesus, Master, have mercy on us." 

# What did Jesus tell them to do?

He told them to go and show themselves to the priests. 

# What happened to the lepers as they went?

They were cleansed. 

# How many of the ten lepers returned to thank Jesus?

Only one returned. 

# Where was the leper from who returned to thank Jesus?

He was from Samaria. 

# When asked about the coming of the kingdom, where did Jesus say the kingdom of God is?

The kingdom of God is within you. 

# What did Jesus say it will be like in his day, when he appears again?

It will be like the lightning flashing from one part of the sky to another. 

# What did Jesus say must happen first?

He must suffer many things and be rejected by that generation. 

# How will the days of the Son of Man be like the days of Noah and the days of Lot?

Many will eat, drink, marry, buy, sell, plant, and build, unaware that the day of destruction has come. 

# How must we not be like Lot's wife?

We must not turn back to try to keep our earthly life on that day. 

# What picture from nature did Jesus use to answer his disciples' question, "Where, Lord?"

Where there is a body, there the vultures gather together. 

# What did Jesus want to teach his disciples about prayer from this story?

He wanted to teach them that they should always pray and not become discouraged. 

# What did the widow keep asking for from the unjust judge?

She asked for justice against her opponent. 

# After awhile, what did the unjust judge say to himself?

He said, "Because this widow causes me trouble and constantly comes to me, I will help her get justice." 

# What did Jesus want to teach his disciples about how God answers prayer?

He wanted to teach them that God will bring justice to those who cry out to him. 

# What was the Pharisee's attitude about his own righteousness and about other people?

He thought he was more righteous than other people. 

# In Jesus' story, which two men went up into the temple to pray?

A Pharisee and a tax collector went up into the temple to pray. 

# What was the Pharisee's attitude about his own righteousness and about other people?

He thought he was more righteous than other people. 

# What was the Pharisee's attitude about his own righteousness and about other people?

He thought he was more righteous than other people. 

# What was the tax collector's prayer to God in the temple?

He prayed, "God, be merciful to me, a sinner." 

# Which man went back to his house justified before God?

The tax collector was justified before God. 

# Jesus said that the kingdom of God belongs to whom?

It belongs to those who are as children. 

# Jesus said that the kingdom of God belongs to whom?

It belongs to those who are as children. 

# What one thing did Jesus ask the ruler (the one who had obeyed God's commandments from his youth) to do?

Jesus asked him to sell all that he had and to distribute it to the poor. 

# How did the ruler respond to Jesus' statement and why?

He became extremely sad, for he was very rich. 

# What did Jesus promise those who have left earthly things for the sake of the kingdom of God?

Jesus promised them much more in this world, and eternal life in the world to come. 

# According to Jesus, what had the Old Testament prophets written about the Son of Man?

That he would be given over to the Gentiles, mocked and shamefully treated, whipped, and killed, but on the third day he would rise again. 

# According to Jesus, what had the Old Testament prophets written about the Son of Man?

That he would be given over to the Gentiles, mocked and shamefully treated, whipped, and killed, but on the third day he would rise again. 

# What did the blind man by the road cry out to Jesus?

He said, "Jesus, Son of David, have mercy on me." 

# What did the blind man by the road cry out to Jesus?

He said, "Jesus, Son of David, have mercy on me." 

# How did the people respond after seeing the blind man healed?

They glorified and gave praise to God. 

# Who climbed up a tree to see Jesus, and what was his occupation and position in society?

He was Zacchaeus, a rich tax collector. 

# What complaint did everyone make when Jesus went to Zacchaeus' house?

They said, "Jesus has gone in to visit a man who is a sinner." 

# What did Jesus say about Zacchaeus after Zacchaeus announced his gifts to the poor?

He said, "Today salvation has come to this house." 

# What did the people expect would happen when Jesus reached Jerusalem?

They thought that the kingdom of God would appear immediately. 

# In Jesus' parable, where was the nobleman going to travel?

He was going to a far country to receive a kingdom, and then he would return. 

# What did the nobleman do for the servant who had been faithful and had made ten more minas?

He gave him authority over ten cities. 

# What did Jesus do for the servant who had been faithful and had made ten more minas?

He gave them authority over ten cities. 

# What did the nobleman do for the servant who had been faithful and had made five more minas?

He gave him authority over five cities. 

# What did Jesus do for the servant who had been faithful and had made five more minas?

He gave them authority over five cities. 

# What kind of man did the wicked servant think the nobleman was?

He thought the nobleman was a severe man. 

# What did the nobleman do with the wicked servant?

He took away the wicked servant's mina. 

# What did the nobleman do with those who didn't want him to reign over them?

The nobleman had them killed before him. 

# What kind of animal did Jesus ride on as he went into Jerusalem?

A colt that had never been ridden. 

# What did the crowd cry out as Jesus descended the Mount of Olives?

They said, "Blessed is the King who comes in the name of the Lord!" 

# What did Jesus say would happen if the people did not cry out rejoicing?

He said that the stones would cry out. 

# What did Jesus do as he drew near to the city?

He wept. 

# What did Jesus then prophesy would happen to the people and the city?

He said that the people would be struck down and that not one stone would be left upon another. 

# Who wanted to kill Jesus as he was teaching in the temple?

The chief priests and the scribes and the leaders of the people wanted to kill Jesus. 

# Why could they not kill him at this time?

Because the people were listening to him intently. 

# When the Jewish leaders asked Jesus by what authority he taught, what question did Jesus ask them?

He asked, "Was the baptism of John from heaven or from men?" 

# If they answered, "from heaven," what did the Jewish leaders think that Jesus would say to them?

The Jewish leaders thought that Jesus would say, "Then why did you not believe him?" 

# If they answered, "from men," what did they think that the people would do to them?

They thought that the people would stone them. 

# In Jesus' parable, what did the vine dressers do when the lord sent his servants to get the fruit of the vineyard?

They beat the servants, treated them shamefully, and sent them away empty-handed. 

# In Jesus' parable, what did the vine dressers do when the lord sent his servants to get the fruit of the vineyard?

They beat the servants, treated them shamefully, and sent them away empty-handed. 

# Finally, who did the lord send to the vine dressers?

He sent his beloved son. 

# What did the vine dressers do when the son came to the vineyard?

They threw him out of the vineyard and killed him. 

# What will the lord of the vineyard do to those vine dressers?

He will destroy those vine dressers and give the vineyard to others. 

# Who did Jesus tell this parable against?

He told this parable against the scribes and the chief priests. 

# How did Jesus answer the question about whether or not it was lawful to pay taxes to Caesar?

He said to give to Caesar the things that are Caesar's, and to God the things that are God's. 

# What event did the Sadducees not believe in?

They did not believe in the resurrection of the dead. 

# What did Jesus say about marriage in this world and in eternity?

In this world there is marriage, but there is not marriage in eternity. 

# What did Jesus say about marriage in this world and in eternity?

In this world there is marriage, but there is not marriage in eternity. 

# What Old Testament story did Jesus recall to prove the truth of the resurrection?

He recalled the story of Moses and the bush, in which Moses calls the Lord the God of Abraham and the God of Isaac and the God of Jacob. 

# Which statement of David from the Psalms did Jesus quote in his question to the scribes?

He quoted, "The Lord said to my Lord, sit at my right hand, until I make your enemies your footstool." 

# Which statement of David from the Psalms did Jesus quote in his question to the scribes?

He quoted, "The Lord said to my Lord, sit at my right hand, until I make your enemies your footstool." 

# Behind their outwardly righteous actions, what wicked things were the scribes doing?

They were devouring widows' houses, and pretentiously making long prayers. 

# How did Jesus say these scribes would be judged?

They will receive a greater condemnation. 

# Why did Jesus say that the poor widow put more into the treasury than all of the others?

Because she gave out of her poverty and the others gave out of their abundance. 

# What did Jesus say would happen to the temple in Jerusalem?

He said that it would be torn down and not one stone would be left on another. 

# What two questions did the people ask Jesus about the temple?

They asked, "When will these things happen, and what will be the sign that they are about to happen?" 

# Jesus warned that many deceivers will come. What will these deceivers say?

They will say, "I am he," and "The time is near." 

# What terrible events did Jesus say would happen before the end?

There will be wars, earthquakes, famines, plagues, and great signs from heaven. 

# What terrible events did Jesus say would happen before the end?

There will be wars, earthquakes, famines, plagues, and great signs from heaven. 

# What opportunity will the persecution of believers create?

It will create an opportunity for their testimony. 

# Who will hate Jesus' followers?

Parents, brothers, relatives, friends, and "everyone" will hate them. 

# Who will hate Jesus' followers?

Parents, brothers, relatives, friends, and "everyone" will hate them. 

# What event would indicate that Jerusalem's destruction was near?

When Jerusalem is surrounded by armies, its destruction is near. 

# What did Jesus tell people to do who saw that the destruction of Jerusalem was near?

He told them to flee to the mountains, to leave the city, and to not enter the city. 

# What did Jesus call the days of the destruction of Jerusalem?

He called them the days of vengeance, fulfilling all the things written. 

# How long will Jerusalem be trampled by the Gentiles?

Jerusalem will be trampled by the Gentiles until the times of the Gentiles are fulfilled. 

# What signs did Jesus say would precede his coming with power and great glory?

He said there would be signs in the sun, moon, and stars, and distress of the nations on the earth. 

# What example did Jesus give of how his listeners knew when a season had come?

He referred to the fig tree - when it sprouts buds they knew that summer was near. 

# What did Jesus say will pass away?

Heaven and earth will pass away. 

# What will never pass away?

Jesus' words will never pass away. 

# What did Jesus warn his listeners _not_ to do since that day will come suddenly?

He warned them to not let their hearts become burdened with debauchery, drunkenness, and the worries of life. 

# What did Jesus warn his listeners to do since that day will come suddenly?

He warned them to be alert and praying. 

# At this time, which Jewish feast was drawing near?

The feast of unleavened bread, called the Passover. 

# In what circumstances was Judas looking for an opportunity to deliver Jesus to the chief priests?

He was looking for an opportunity when Jesus was away from the crowd. 

# Where did Jesus and the disciples eat the Passover meal?

They ate it in a guest room in Jerusalem. 

# Where did Jesus and the disciples eat the Passover meal?

They ate it in a guest room in Jerusalem. 

# When did Jesus say he would eat the Passover meal again?

He would eat the Passover meal again when it is fulfilled in the kingdom of God. 

# What did Jesus say when he broke the bread and gave it to the disciples?

He said, "This is my body which is given for you. Do this in remembrance of me." 

# What did Jesus say when he gave the cup to the disciples?

He said, "This cup is the new covenant in my blood, which is poured out for you." 

# Was it God's plan that Jesus be betrayed?

Yes. 

# Did the disciples know who was about to betray Jesus?

No. 

# Who did Jesus say was the greatest among his disciples?

The greatest is the one who serves. 

# How did Jesus live among his disciples?

He lived as one who serves. 

# Where did Jesus promise his disciples they would sit?

He said they would sit on thrones, judging the twelve tribes of Israel. 

# What did Jesus predict that Peter would do?

He said that Peter would deny that he knows Jesus three times before the rooster crowed. 

# What written prediction about Jesus was being fulfilled in these events?

The prediction in scripture says, "And he was considered as one of the lawless." 

# On the Mount of Olives, for what did Jesus tell his disciples to pray?

He wanted them to pray that they would not enter into temptation. 

# On the Mount of Olives, what did Jesus pray?

He prayed, "Father, if you are willing, remove this cup from me. Nevertheless not my will, but yours be done." 

# What were the disciples doing when Jesus returned from praying?

They were sleeping. 

# How did Judas betray Jesus in front of the crowd?

He betrayed Jesus with a kiss. 

# How did Judas betray Jesus in front of the crowd?

He betrayed Jesus with a kiss. 

# What did Jesus do with the man whose ear was cut off?

He touched his ear, and healed him. 

# Where did Jesus say he was daily with the chief priests?

He was in the temple. 

# After seizing him, where did they take Jesus?

The took him to the high priest's house. 

# What did Peter say when a certain maid said that Peter had been with Jesus?

He said, "Woman, I do not know him." 

# What happened immediately after Peter denied knowing Jesus for the third time?

A rooster crowed. 

# What did Peter do after Jesus looked at him?

He went outside and wept bitterly. 

# What did the men guarding Jesus do to him?

They mocked and beat him, and blasphemed him. 

# What did the men guarding Jesus do to him?

They mocked and beat him, and blasphemed him. 

# What did the men guarding Jesus do to him?

They mocked and beat him, and blasphemed him. 

# When the council demanded that Jesus tell them if he is the Christ, Jesus said that if he told them, they would not do what?

They would not believe. 

# Why did the council say that they did not need witnesses to prove that Jesus claimed to be the Christ?

Because they had heard it from Jesus' own mouth. 

# What accusations against Jesus did the Jewish leaders make to Pilate?

They said that Jesus was perverting the nation, forbidding tribute to Caesar, and saying that he was the Christ, a king. 

# After questioning Jesus, what did Pilate say about him?

He said, "I find no fault in this man." 

# Why did Herod want to see Jesus?

Herod wanted to see Jesus do a miracle. 

# How did Jesus answer Herod's questions?

He answered him nothing. 

# When Jesus was returned to Pilate, what did Pilate say about Jesus to the crowd?

He said, "I find no fault in this man." 

# Who did the crowd want released from prison for the Passover feast?

They wanted Barabbas, a criminal. 

# What did the crowd shout should be done to Jesus?

They shouted, "Crucify him, crucify him." 

# For the third time, what did Pilate tell the crowd about Jesus?

Pilate said, "I have found nothing deserving the death penalty in him." 

# Why did Pilate finally grant the crowd's demand to crucify Jesus?

Because they were insistent with loud voices. 

# Who carried Jesus' cross, and followed behind Jesus?

Simon of Cyrene carried Jesus' cross. 

# Who did Jesus say the women of Jerusalem should weep for instead of him?

They should weep for themselves and their children. 

# Who was crucified with Jesus?

Two criminals were crucified with Jesus. 

# From the cross, what did Jesus pray for those crucifying him?

He prayed, "Father, forgive them, for they do not know what they are doing." 

# The people, the soldiers, and one of the criminals all challenged Jesus to do what, since Jesus claimed to be the Christ?

They challenged him to save himself. 

# The people, the soldiers, and one of the criminals all challenged Jesus to do what, since Jesus claimed to be the Christ?

They challenged him to save himself. 

# What was written on a sign over Jesus?

It said, "THIS IS THE KING OF THE JEWS." 

# The people, the soldiers, and one of the criminals all challenged Jesus to do what, since Jesus claimed to be the Christ?

They challenged him to save himself. 

# What request did the second criminal make to Jesus?

He said, "Remember me when you come into your kingdom." 

# What promise did Jesus make to the second criminal?

He said, "Today you will be with me in paradise." 

# What miraculous events occurred immediately before Jesus' death?

Darkness came over the land and the curtain of the temple was split down the middle. 

# What miraculous events occurred immediately before Jesus' death?

Darkness came over the land and the curtain of the temple was split down the middle. 

# What did the centurion say about Jesus after Jesus' death?

He said, "Surely this was a righteous man." 

# What did Joseph of Arimathea do after Jesus' death?

He asked Pilate for the body and laid it in a tomb. 

# What did Joseph of Arimathea do after Jesus' death?

He asked Pilate for the body and laid it in a tomb. 

# What day was about to begin when Jesus was buried?

The Sabbath Day was about to begin. 

# What did the women who had been with Jesus do on the Sabbath?

They rested, according to God's commandment. 

# When did the women come to the tomb of Jesus?

They came very early on the first day of the week. 

# What did the women find at the tomb?

They found that the stone had been rolled away and that the body of Jesus was not there. 

# What did the women find at the tomb?

They found that the stone had been rolled away and that the body of Jesus was not there. 

# What did the two men in dazzling apparel (angels) say had happened to Jesus?

They said that Jesus had risen. 

# What was the apostles' reaction when the women told of their experience at the tomb?

They dismissed the report as idle talk. 

# What did Peter see when he looked in the tomb?

He saw the linen cloths by themselves. 

# Why did the two disciples going to Emmaus not recognize Jesus when Jesus joined them?

Their eyes were restrained from recognizing him. 

# While Jesus was alive, what were the disciples hoping he would do?

They were hoping that he would free Israel from their enemies. 

# What did Jesus explain to the two men from the scriptures?

He explained what the scriptures said concerning him. 

# When did the two men finally recognize Jesus?

They recognized him when he blessed the bread, broke it, and gave it to them. 

# When did the two men finally recognize Jesus?

They recognized him when he blessed the bread, broke it, and gave it to them. 

# What did Jesus do when they recognized him?

He vanished out of their sight. 

# When did the two men finally recognize Jesus?

They recognized him when he blessed the bread, broke it, and gave it to them. 

# What did Jesus say first when he appeared to the disciples in Jerusalem?

He said, "Peace be with you." 

# How did Jesus prove that he was not just a spirit?

He invited the disciples to handle him, and he showed them his hands and feet. 

# How did Jesus prove that he was not just a spirit?

He invited the disciples to handle him, and he showed them his hands and feet. 

# How were the disciples then able to understand the scriptures?

Jesus opened their minds that they might understand. 

# What did Jesus say should be preached to all the nations?

Repentance and forgiveness of sins should be preached to all the nations. 

# For what did Jesus tell the disciples to wait?

He told them to wait until they are clothed with power from on high. 

# What happened to Jesus as he blessed the disciples near Bethany?

He was carried up into heaven. 

# Where did the disciples then spend their time, and what did they do?

They were continually in the temple, blessing God. 

