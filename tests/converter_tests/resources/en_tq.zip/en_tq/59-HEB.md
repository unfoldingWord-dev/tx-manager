# How has God spoken in the past?

God has spoken in the past through the prophets at many times and in many ways. 

# How has God spoken in these recent days?

God has spoken in these recent days through a Son. 

# Through whom was the universe made?

The universe was made through the Son of God. 

# How are all things sustained?

All things are sustained by the word of the Son of God's power. 

# How does the Son display the glory and essence of God?

The Son is the radiance of God's glory, and the character of God's essence. 

# How does the Son of God compare to the angels?

The Son of God is superior to the angels. 

# What did God command the angels to do when the Son was brought into the world?

God commanded the angels to worship the Son when the Son was brought into the world. 

# How long will the Son rule as a king?

The Son will rule as a king for ever and ever. 

# What does the Son love and what does the Son hate?

The Son loves righteousness and the Son hates lawlessness. 

# What will happen to the earth and heavens over time?

The earth and heavens will wear out like a garment and perish. 

# What will happen to the earth and heavens over time?

The earth and heavens will wear out like a garment and perish. 

# Where did God tell the Son to sit, and until what happened?

God told the Son to sit at his right hand until God made the Son's enemies a stool for the Son's feet. 

# For whom do the angels care?

The angels care for those who are about to inherit salvation. 

# Why must believers pay attention to what they have heard?

Believers must pay attention to what they have heard so that they do not drift away from it. 

# What does every transgression and disobedience receive?

Every transgression and disobedience receives just punishment. 

# How did God testify to the message of salvation announced by the Lord?

God testified to the message by signs, wonders, powerful deeds, and by the gifts of the Holy Spirit. 

# Who will not rule the world to come?

Angels will not rule the world to come. 

# Who will rule the world to come?

Man will rule the world to come. 

# Who will rule the world to come?

Man will rule the world to come. 

# Why was Jesus crowned with glory and honor?

Jesus was crowned with glory and honor because of his suffering and death. 

# For whom did Jesus taste death?

Jesus tasted death for every man. 

# Who does God plan to bring to glory?

God plans to bring many sons to glory. 

# Who both come from the one source, God?

Both the one who sanctifies and those who are sanctified come from the one source, God. 

# Who was made ineffective through Jesus' death?

The devil was made ineffective through Jesus' death. 

# From what slavery are people freed through the death of Jesus?

Through the death of Jesus, people are freed from the fear of death. 

# Why was it necessary for Jesus to be like his brothers in all ways?

It was necessary so that he might become a merciful and faithful high priest over God's things, and so he might achieve forgiveness for the people's sins. 

# Why is Jesus able to help those who are tempted?

Jesus is able to help those who are tempted because he was tempted also. 

# What two titles does the author of the book of Hebrews give Jesus?

The author gives Jesus the titles Apostle and High Priest. 

# Why has Jesus been considered worthy of greater glory than Moses?

Jesus has been considered worthy of greater glory because while Moses was faithful in all God's house, Jesus is the one who built the house. 

# Why has Jesus been considered worthy of greater glory than Moses?

Jesus has been considered worthy of greater glory because while Moses was faithful in all God's house, Jesus is the one who built the house. 

# What was Moses' role in God's house?

Moses was a servant in God's house. 

# About what did Moses give testimony?

Moses gave testimony about the things that were to be spoken of in the future. 

# What is Jesus' role in God's house?

Jesus is the Son in charge of God's house. 

# Who is God's house?

The believers are God's house if they hold fast their confidence. 

# What did the Israelites in the wilderness do when they heard God's voice?

The Israelites hardened their hearts. 

# What did the Israelites in the wilderness do when they heard God's voice?

The Israelites hardened their hearts. 

# What did God swear concerning the Israelites who went astray in their hearts?

God swore that they would not enter his rest. 

# What did God swear concerning the Israelites who went astray in their hearts?

God swore that they would not enter his rest. 

# Of what are the brothers warned to be careful?

The brothers are warned to be careful not to turn away from the living God by unbelief. 

# What are the brothers to do in order to avoid being hardened by the deceitfulness of sin?

The brothers are to encourage one another daily. 

# As partners of Christ, what must believers do?

As partners of Christ, believers must firmly hold their confidence in him from the beginning to the end. 

# With whom was God angry for forty years?

God was angry with those who sinned in the wilderness. 

# What happened to those with whom God was angry?

Their dead bodies lay in the wilderness. 

# Why were the disobedient Israelites not able to enter God's rest?

They were not able to enter God's rest because of unbelief. 

# What good news had the believers and the Israelites both heard?

The believers and the Israelites had both heard the good news about God's rest. 

# Why did the good news not benefit the Israelites?

The good news did not benefit the Israelites because they did not join faith to it. 

# Who are the ones who enter God's rest?

Those who have believed enter God's rest. 

# When did God finish his created works and then rest?

God finished his created works at the beginning of the world and then rested on the seventh day. 

# When did God finish his created works and then rest?

God finished his created works at the beginning of the world and then rested on the seventh day. 

# What did God say about the Israelites and his rest?

God said that the Israelites would not enter his rest. 

# What day has God now set for people to enter his rest?

God has set "Today" as the day for people to enter his rest. 

# What must a person do in order to enter God's rest?

A person must listen to God's voice and not harden his heart. 

# What is still reserved for God's people?

A sabbath rest is still reserved for God's people. 

# A person who enters God's rest also rests from what?

A person who enters God's rest also rests from his deeds. 

# Why should believers be eager to enter God's rest?

Believers should be eager to enter God's rest so that they do not fall as the Israelites did. 

# What is the word of God sharper than?

The word of God is sharper than any two-edged sword. 

# What is the word of God able to divide?

The word of God is able to divide soul from spirit, and joints from marrow. 

# What is the word of God able to discern?

The word of God is able to discern the thoughts and intentions of the heart. 

# Who is hidden from God's sight?

No created thing is hidden from God's sight. 

# Who serves as the great high priest for believers?

Jesus the Son of God serves as the great high priest for believers. 

# Why does Jesus feel sympathy for the weaknesses of believers?

Jesus feels sympathy for the weaknesses of believers because he was in all ways tempted. 

# How many times did Jesus sin?

Jesus was without sin. 

# In time of need, what are believers to do to receive mercy and find grace?

In time of need, believers are to come up with confidence to the throne of grace. 

# What does every high priest do on behalf of the people?

For the people, every high priest offers gifts and sacrifices for sins. 

# In addition to the people, for whom does the high priest also present sacrifices?

The high priest also presents sacrifices for his sins. 

# How does a man receive the honor of being a high priest of God?

A man must be called by God to be a high priest of God. 

# Who declared Christ to be a high priest?

God declared Christ to be a high priest. 

# For how long is Christ God's high priest?

Christ is God's high priest forever. 

# Of what order is Christ as a high priest?

Christ is a high priest of the order of Melchizedek. 

# Why was Christ heard by God when he prayed?

Christ was heard by God because he revered God. 

# How did Christ learn obedience?

Christ learned obedience from the things he suffered. 

# For whom did Christ become the cause of eternal salvation?

For everyone who obeys him, Christ became the cause of their eternal salvation. 

# What was the spiritual condition of the original readers of this letter?

The original readers were dull of hearing. 

# How does the author of the letter say that believers grow from spiritual babies into full-grown adults?

Believers grow spiritually by practicing distinguishing right from wrong, discerning both good and evil. 

# On to what does the author of Hebrews want the believers to press?

The author of Hebrews wants the believers to press on to maturity. 

# What teachings does the author list as the foundation of the message of Christ?

The foundational teachings are repentance from dead works, faith in God, baptisms, laying on of hands, the resurrection of the dead, and eternal judgment. 

# What teachings does the author list as the foundation of the message of Christ?

The foundational teachings are repentance from dead works, faith in God, baptisms, laying on of hands, the resurrection of the dead, and eternal judgment. 

# What is impossible for those who were sharers in the Holy Spirit, but then fell away, to do?

It is impossible for those who were sharers in the Holy Spirit, but then fell away, to be restored again to repentance. 

# What had these enlightened people tasted?

These enlightened people had tasted the heavenly gift, God's word, and the powers of the age to come. 

# What is impossible for those who were sharers in the Holy Spirit, but then fell away, to do?

It is impossible for those who were sharers in the Holy Spirit, but then fell away, to be restored again to repentance. 

# What had these enlightened people tasted?

These enlightened people had tasted the heavenly gift, God's word, and the powers of the age to come. 

# What is impossible for those who were sharers in the Holy Spirit, but then fell away, to do?

It is impossible for those who were sharers in the Holy Spirit, but then fell away, to be restored again to repentance. 

# Why are these people not able to be restored to repentance?

They are not able to be restored because they have crucified for themselves the very Son of God. 

# In the author's analogy, what happens to land that receives rain but bears thorns and thistles?

Land that receives rain but bears thorns and thistles has its end in burning. 

# In the author's analogy, what happens to land that receives rain but bears thorns and thistles?

Land that receives rain but bears thorns and thistles has its end in burning. 

# What is the author's expectation concerning the believers to whom he is writing?

The author expects better things concerning these believers, things that are about salvation. 

# What will God not forget about these believers?

God will not forget their work, love, and service to the saints. 

# What should the believers imitate about those who inherit the promises of God?

The believers should imitate the faith and patience of those who inherit the promises of God. 

# What did Abraham have to do in order to obtain what God promised him?

Abraham had to wait patiently to obtain what God promised him. 

# What did Abraham have to do in order to obtain what God promised him?

Abraham had to wait patiently to obtain what God promised him. 

# What did Abraham have to do in order to obtain what God promised him?

Abraham had to wait patiently to obtain what God promised him. 

# Why did God guarantee his promise with an oath?

God guaranteed his promise with an oath to show more clearly the unchangeable quality of his purpose. 

# What is it impossible for God to do?

It is impossible for God to lie. 

# What does the believer's confidence in God do for his soul?

The believer's confidence in God is a secure and reliable anchor for his soul. 

# Where did Jesus enter as the forerunner for the believers?

Jesus entered into the inner place behind the curtain as the forerunner for the believers. 

# What two titles did Melchizedek have?

Melchizedek was king of Salem and priest of God Most High. 

# What did Abraham give Melchizedek?

Abraham gave Melchizedek a tenth of everything he had captured. 

# What does the name Melchizedek mean?

The name Melchizedek means "king of righteousness" and "king of peace". 

# Who were the ancestors of Melchizedek, and when did he die?

Melchizedek was without ancestors and has no end of life. 

# From whom are the priests descended, who are priests according to the Law, and who collect tithes from the people?

The priests of the Law are descended from Levi and Abraham. 

# Who was the greater person, Abraham or Melchizedek?

Melchizedek was the greater person because he blessed Abraham 

# In what way did Levi himself also pay tithes to Melchizedek?

Levi also paid tithes to Melchizedek because Levi was in the genitals of Abraham when Abraham paid tithes to Melchizedek. 

# In what way did Levi himself also pay tithes to Melchizedek?

Levi also paid tithes to Melchizedek because Levi was in the genitals of Abraham when Abraham paid tithes to Melchizedek. 

# Why was there a need for another priest to arise after the order of Melchizedek?

There was a need for another priest to arise after the order of Melchizedek because perfection was not possible through the Levitical priesthood. 

# What must also be 3changed when the priesthood changes?

The law must be changed when the priesthood changes. 

# From which tribe did Jesus descend, and had this tribe served before at the altar as priests?

Jesus descended from the tribe of Judah, which had never served before at the altar as priests. 

# On what basis did Jesus become a priest after the order of Melchizedek?

Jesus became a priest after the order of Melchizedek based on the power of an indestructible life. 

# What has been set aside because it is weak and useless?

The former commandment, the Law, has been set aside because it is weak and useless. 

# What has been set aside because it is weak and useless?

The former commandment, the Law, has been set aside because it is weak and useless. 

# What oath did God swear concerning Jesus?

God swore that Jesus would be a priest forever. 

# Of what is Jesus the guarantee?

Jesus is the guarantee of a better covenant. 

# Why is Jesus able to completely save those who draw near to God through him?

Jesus is able to completely save those who draw near to God through him because he always lives to intercede for them. 

# What four attributes does Jesus have that make him the right priest for believers?

Jesus is sinless, blameless, pure, and separated from sinners. 

# What offering did Jesus need to make for his own sins?

Jesus did not need to make any offering for his own sins because he is sinless. 

# What offering did Jesus make for the sins of the people?

Jesus offered up himself once for the sins of the people. 

# How is Jesus different from the priests who were appointed through the Law?

The priests who were appointed through the Law were weak, but Jesus has been made perfect forever. 

# Where is the believers' high priest sitting?

The believers' high priest is sitting at the right hand of the throne of the Majesty in the heavens. 

# Where is the true tabernacle?

The true tabernacle is in the heavens. 

# What is necessary for every priest to have?

Every priest must have something to offer. 

# Where were the priests who offered gifts according to the Law?

The priests who offered gifts according to the Law were on the earth. 

# What did the priests on earth serve?

The priests on earth served a copy and shadow of the heavenly things. 

# According to what pattern was the earthly tabernacle built?

The earthly tabernacle was built according to the pattern God showed Moses on the mountain. 

# Why does Christ have a superior priestly ministry?

Christ has a superior priestly ministry because he is the mediator of a better covenant, established on better promises. 

# What did God promise when he found fault with the people under the first covenant?

God promised to make a new covenant with the house of Israel and with the house of Judah. 

# What did God say he would do in the new covenant?

God said he would put his laws into the people's minds, and write them on their hearts. 

# In the new covenant, who would know the Lord?

In the new covenant, all would know the Lord, from the least to the greatest. 

# What did God say he would do with the people's sins in the new covenant?

God said he would remember the people's sins no more. 

# In announcing a new covenant, what did God make the first covenant?

In announcing a new covenant, God made the first covenant old and ready to disappear. 

# What was the place of worship for the first covenant?

The place of worship for the first covenant was the tabernacle on earth. 

# What was the place of worship for the first covenant?

The place of worship for the first covenant was the tabernacle on earth. 

# What was located in the holy place of the earthly tabernacle?

In the holy place of the earthly tabernacle were the lampstand, the table, and the bread of the presence. 

# What was located in the most holy place of the earthly tabernacle?

In the most holy place of the earthly tabernacle were the altar for incense and the ark of the covenant. 

# How often did the high priest enter the most holy place, and what did he do before he entered?

The high priest entered the most holy place once each year, after making a blood sacrifice for himself and the people. 

# What served as an illustration in the present time for the readers of this letter?

The earthly tabernacle and the gifts and sacrifices being offered there served as an illustration in the present time. 

# What were the offerings of the earthly tabernacle not able to do?

The offerings of the earthly tabernacle were not able to perfect the worshiper's conscience. 

# Until when were the regulations of the earthly tabernacle provided?

The regulations of the earthly tabernacle were provided until the new order would be put in place. 

# What is different about the sacred tent in which Christ serves?

The sacred tent in which Christ serves is more perfect, is not made by human hands, and does not belong to this created world. 

# What offering did Christ make, by which he entered the most holy place?

Christ made an offering of his own blood by which he entered the most holy place. 

# What did Christ's offering accomplish?

Christ's offering secured everlasting redemption for everyone. 

# What does Christ's blood do for the believer?

Christ's blood cleanses the believer's conscience from dead deeds in order to serve the living God. 

# Of what is Christ the mediator?

Christ is the mediator of a new covenant. 

# What is required in order for a will to be in force?

A death is required in order for a will to be in force. 

# What death was required for the first covenant?

The death of calves and goats was required for the first covenant. 

# What death was required for the first covenant?

The death of calves and goats was required for the first covenant. 

# What cannot happen without the shedding of blood?

Without the shedding of blood there is no forgiveness of sins. 

# Where does Christ now appear on our behalf?

Christ now appears in heaven itself, in the presence of God, on our behalf. 

# How many times must Christ offer himself to put away sin by the sacrifice of himself?

Christ offers himself one time at the end of the ages to put away sin by the sacrifice of himself. 

# For every person, what happens after their death?

After every person dies, they face the judgment. 

# For what purpose will Christ appear a second time?

Christ will appear a second time for the salvation of those who wait patiently for him. 

# What is the Law compared to the realities in Christ?

The Law is only a shadow of the realities in Christ. 

# Of what do the repeated sacrifices made through the Law remind the worshipers?

The repeated sacrifices made through the Law remind the worshipers of sins committed year after year. 

# What is it impossible for the blood of bulls and goats to do?

It is impossible for the blood of bulls and goats to take away sins. 

# What did God prepare for Christ when Christ came into the world?

God prepared a body for Christ. 

# What practice did God set aside when Christ came into the world?

God set aside the first practice of the sacrifices offered according to the Law. 

# What practice did God establish when Christ came into the world?

God established the second practice of the offering of the body of Jesus Christ once for all. 

# For what is Christ waiting as he sits at the right side of God?

Christ is waiting until his enemies are humbled and made a stool for his feet. 

# For what is Christ waiting as he sits at the right side of God?

Christ is waiting until his enemies are humbled and made a stool for his feet. 

# What has Christ done for those sanctified by his one offering?

Christ has perfected forever those who are sanctified by his one offering. 

# What is no longer required where there is forgiveness of sins?

Additional offerings are no longer required where there is forgiveness of sins. 

# Into what place can believers now enter by Jesus' blood?

Believers can now enter the most holy place by Jesus' blood. 

# What has been sprinkled and what has been washed in the believer?

The believer's heart has been sprinkled clean from an evil conscience, and his body has been washed with pure water. 

# To what must believers hold tightly?

Believers must hold tightly to the confession of their confident expectation. 

# What must believers do as they see the day drawing near?

Believers must encourage one another more and more as they see the day drawing near. 

# What is the expectation of those who deliberately go on sinning after receiving the knowledge of the truth?

The expectation of those who deliberately go on sinning after receiving the knowledge of the truth is judgment and a fire that consumes God's enemies. 

# What is the expectation of those who deliberately go on sinning after receiving the knowledge of the truth?

The expectation of those who deliberately go on sinning after receiving the knowledge of the truth is judgment and a fire that consumes God's enemies. 

# What does the person deserve who treats the blood of Christ by which he was sanctified as something unholy?

The person who treats the blood of Christ by which he was sanctified as something unholy deserves punishment without mercy beyond the punishment given under the Law of Moses. 

# What does the person deserve who treats the blood of Christ by which he was sanctified as something unholy?

The person who treats the blood of Christ by which he was sanctified as something unholy deserves punishment without mercy beyond the punishment given under the Law of Moses. 

# To whom does vengeance belong?

Vengeance belongs to the Lord. 

# How had the believers who received this letter reacted to the seizure of their possessions?

The believers had accepted with joy the seizure of their possessions, knowing they had a better and everlasting possession. 

# What does the believer need so he may receive what God has promised?

The believer needs confidence and patience so he may receive what God has promised. 

# What does the believer need so he may receive what God has promised?

The believer needs confidence and patience so he may receive what God has promised. 

# How will the righteous live?

The righteous will live by faith. 

# What does God think of those who turn back?

God is not pleased with those who turn back. 

# What is the author's expectation for those who received this letter?

The author's expectation is that those who received this letter will have faith for keeping their souls. 

# What attitude does a person of faith have toward God's promises that are yet to be fulfilled?

A person of faith confidently expects and has certainty toward God's promises that are yet to be fulfilled. 

# From what were the visible things of the universe created?

The visible things of the universe were not made out of things that were visible. 

# Why did God praise Abel for being righteous?

God praised Abel because Abel by faith offered God a more appropriate sacrifice than Cain did. 

# What must one who comes to God believe about God?

One who comes to God must believe that God exists and that he rewards those who seek him. 

# How did Noah demonstrate his faith?

Noah demonstrated his faith by building a ship to save his family according to God's warning. 

# What promise did Abraham and Sarah receive by faith?

Abraham and Sarah received by faith the power to conceive even when they were too old. 

# What did the ancestors of faith see from far off?

The ancestors of faith saw and welcomed God's promises from far off. 

# What did the ancestors of faith consider themselves on the earth?

The ancestors of faith considered themselves strangers and aliens on the earth. 

# What has God prepared for those of faith?

God has prepared a heavenly city for those of faith. 

# What did Abraham believe God would be able to do even as he offered up Isaac his only son?

Abraham believed God would be able to raise up Isaac from the dead. 

# What did Abraham believe God would be able to do even as he offered up Isaac his only son?

Abraham believed God would be able to raise up Isaac from the dead. 

# What did Abraham believe God would be able to do even as he offered up Isaac his only son?

Abraham believed God would be able to raise up Isaac from the dead. 

# What did Joseph prophesy by faith when his end was near?

Joseph prophesied of the departure of the children of Israel from Egypt when his end was near. 

# What did Moses choose to do by faith when he had grown up?

Moses chose by faith to share mistreatment with God's people, considering the disgrace of following Christ as greater riches. 

# What did Moses choose to do by faith when he had grown up?

Moses chose by faith to share mistreatment with God's people, considering the disgrace of following Christ as greater riches. 

# What did Moses choose to do by faith when he had grown up?

Moses chose by faith to share mistreatment with God's people, considering the disgrace of following Christ as greater riches. 

# What did Moses observe by faith in order to save the Israelites' firstborn sons?

Moses observed the Passover and the sprinkling of the blood by faith in order to save the Israelites' firstborn sons. 

# What did Rahab do by faith which prevented her from perishing?

Rahab by faith received the spies in safety which prevented her from perishing. 

# What did some of the ancestors of faith accomplish in war?

Some of the ancestors of faith conquered kingdoms, escaped the sword, became mighty in war, and caused foreign armies to flee. 

# What did some of the ancestors of faith accomplish in war?

Some of the ancestors of faith conquered kingdoms, escaped the sword, became mighty in war, and caused foreign armies to flee. 

# What did some of the ancestors of faith suffer?

Some of the ancestors of faith suffered torture, mocking, whippings, chains, imprisonments, stoning, sawing in two, death, and destitution. 

# What did some of the ancestors of faith suffer?

Some of the ancestors of faith suffered torture, mocking, whippings, chains, imprisonments, stoning, sawing in two, death, and destitution. 

# What did some of the ancestors of faith suffer?

Some of the ancestors of faith suffered torture, mocking, whippings, chains, imprisonments, stoning, sawing in two, death, and destitution. 

# What did some of the ancestors of faith suffer?

Some of the ancestors of faith suffered torture, mocking, whippings, chains, imprisonments, stoning, sawing in two, death, and destitution. 

# Despite the faith of these ancestors, what did they not receive in their earthly lives?

Despite the faith of these ancestors, they did not receive in their earthly lives what God had promised them. 

# With whom will the ancestors of faith receive the promises of God and be perfected?

The ancestors of faith will receive the promises of God and be perfected with the new covenant believers in Christ. 

# Why should the believer throw off the sin that easily entangles him?

Since he is surrounded by such a large crowd of witnesses, the believer should throw off the sin that easily entangles him. 

# Why did Jesus endure the cross and despise its shame?

Jesus endured the cross and despised its shame for the joy that was set before him. 

# How can a believer avoid becoming weary or fainthearted?

By considering Jesus who endured hateful speech from sinners, a believer can avoid becoming weary or fainthearted. 

# What does the Lord do to those whom he loves and receives?

The Lord disciplines those whom he loves and receives. 

# What is a person who is without the Lord's discipline?

A person without the Lord's discipline is an illegitimate child and not God's child. 

# Why does God discipline his children?

God disciplines his children for their good so they can share in his holiness. 

# What does discipline produce?

Discipline produces peaceful fruit of righteousness. 

# What should believers pursue with all people?

Believers should pursue peace with all people. 

# What must not grow up and cause trouble and pollute many?

A root of bitterness must not grow up and cause trouble and pollute many. 

# What happened to Esau when he desired to inherit the blessing with tears after selling his own birthright?

Esau was rejected when he desired to inherit the blessing with tears after selling his own birthright. 

# For what did the Israelites beg at the mountain where God spoke?

The Israelites begged that not another word be spoken to them. 

# To where do believers in Christ come instead of the mountain where the Israelites heard the voice of God?

Believers in Christ come to Mount Zion and to the city of the living God. 

# To what assembly do believers in Christ come?

Believers in Christ come to the assembly of all the firstborn registered in heaven. 

# To whom do believers in Christ come?

Believer in Christ come to God the Judge of all, to the spirits of the righteous, and to Jesus. 

# To whom do believers in Christ come?

Believer in Christ come to God the Judge of all, to the spirits of the righteous, and to Jesus. 

# What will happen to those who turn away from the one who warns them from heaven?

Those who turn away will not escape from God. 

# What has God promised to shake?

God has promised to shake the earth and the heavens. 

# What will the believers receive instead of the things that can be shaken?

The believers will receive a kingdom that cannot be shaken. 

# How should believers worship God?

Believers should worship God with reverence and awe. 

# Why should believers worship God in this way?

Believers should worship God in this way because he is a consuming fire. 

# What have some done by welcoming strangers?

Some have welcomed angels without knowing it. 

# How should believers remember those in prison?

Believers should remember them as if they were in prison also, and as if their bodies were being mistreated also. 

# What must be respected by all?

Marriage must be respected by all. 

# What does God do with the sexually immoral and adulterers?

God judges the sexually immoral and adulterers. 

# How can a believer be free from the love of money?

A believer can be free from the love of money because God has said he will never leave nor forsake him. 

# Who's faith should believers imitate?

Believers should imitate the faith of those who have led them and who have spoken God's word to them. 

# About what kind of strange teachings does the author warn the believers?

The author warns the believers about strange teachings involving rules about food. 

# Where were the bodies of the animals used for sacrifice in the holy place burned?

The bodies of the animals were burned outside the camp. 

# Where did Jesus suffer?

Jesus suffered outside the city gate. 

# Where must believers go, and why?

Believers must go to Jesus outside the camp, bearing his disgrace. 

# What permanent city do believers have here on earth?

Believers have no permanent city here on earth. 

# What city do believers seek instead?

Believers seek the city that is to come instead. 

# What sacrifice should believers constantly offer up to God?

Believers should constantly offer up sacrifices of praise to God. 

# What attitude should believers have toward their leaders?

Believers should obey and submit to their leaders. 

# What does God work in the believer?

God works in the believer that which is well pleasing in God's sight. 

# With whom will the author come when he visits the believers?

The author will come with Timothy when he visits the believers. 

