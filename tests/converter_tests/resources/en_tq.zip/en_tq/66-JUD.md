# Of whom was Jude a servant?

Jude was a servant of Jesus Christ. 

# Who was the brother of Jude?

Jude was the brother of James. 

# To whom did Jude write?

He wrote to those who were called, beloved in God the Father, and kept for Jesus Christ. 

# What did Jude want multiplied to those to whom he wrote?

Jude wanted mercy, peace, and love to be multiplied. 

# What did Jude first want to write about?

Jude first wanted to write about their common salvation. 

# What did Jude actually write about?

Jude actually wrote about the need to struggle for the faith of the saints. 

# How did some condemned and ungodly men come?

Some condemned and ungodly men came stealthily. 

# What did the condemned and ungodly men do?

They changed the grace of God into sexual immorality and denied Jesus Christ. 

# From where did the Lord once save people?

The Lord saved them from the land of Egypt. 

# What did the Lord do to those people who did not believe?

The Lord destroyed those people who did not believe. 

# What did the Lord do to the angels who left their proper place?

The Lord put them in chains in darkness for judgment. 

# What did Sodom, Gomorrah, and the cities around them do?

They fornicated and pursued unnatural desires. 

# Like Sodom, Gomorrah, and the cities around them, what do the condemned and ungodly men do?

They pollute their bodies in their dreams, reject authority, and say evil things. 

# What did the archangel Michael say to the devil?

The archangel Michael said, "May the Lord rebuke you." 

# For whom do the condemned and ungodly men shamelessly care?

They shamelessly care for themselves. 

# Enoch was which place in line from Adam?

Enoch was the seventh in line from Adam. 

# Upon whom will the Lord execute judgment?

The Lord will execute judgment upon all people. 

# Who are the ungodly men who will be convicted?

Grumblers, complainers, those who go after their evil desires, loud boasters, and those who praise for personal advantage are the ungodly men who will be convicted. 

# Who spoke words in the past about mockers?

The apostles of the Lord Jesus Christ spoke words in the past about mockers. 

# What is true of the mockers who go after the own ungodly lusts, who cause divisions and are sensual?

They do not have the Holy Spirit. 

# How were the beloved building themselves up and praying?

The beloved were building themselves up in their most holy faith, and praying in the Holy Spirit. 

# What were the beloved to keep themselves in and look for?

The beloved were to keep themselves in and look for the love of God, and the mercy of the Lord Jesus Christ. 

# Who were the beloved supposed to have mercy on and save?

The beloved were supposed to have mercy on and save those who were in doubt or with a garment spotted by the flesh, and those in the fire. 

# Who were the beloved supposed to have mercy on and save?

The beloved were supposed to have mercy on and save those who were in doubt or with a garment spotted by the flesh, and those in the fire. 

# What was God their Savior, through Jesus Christ their Lord, able to do?

God was able to keep them from stumbling and place them before the presence of his glory without blemish. 

# What was God their Savior, through Jesus Christ their Lord, able to do?

God was able to keep them from stumbling and place them before the presence of his glory without blemish. 

# When did God have glory?

God had glory before all time, now, and forevermore. 

