# When did Nebuchadnezzar king of Babylon come to Jerusalem to surround the city and cut off all suppliles to it?

Nebuchadnezzar came to Jerusalem in the third year of the reign of Jehoiakim king of Judah. 

# Who gave Nebuchadnezzar victory over Jehoiakim king of Judah?

The Lord gave Nebuchadnezzar victory over Jehoiakim. 

# What did the king tell Ashpenaz to do?

The king told Ashpenaz to bring in some of the people of Israel, both of the royal family and of the nobility. 

# What kind of young men did the king want to be brought in to Babylon?

The king wanted young men without blemish, attractive in appearance, skillful in all wisdom, filled with knowledge and understanding, qualified to serve in the king's palace. 

# What were these young men to be fed?

They were to be fed a daily portion of the king's delicacies and some of the king's wine. 

# What was the name of some of these young men from Israel and what names were they given by the chief official?

The names of some of these young men and the names given to them by the chief official were: Daniel called Belteshazzer, Hananiah called Shadrach, Mishael called Meshach, and Azariah called Abednego. 

# What was the name of some of these young men from Israel and what names were they given by the chief official?

The names of some of these young men and the names given to them by the chief official were: Daniel called Belteshazzer, Hananiah called Shadrach, Mishael called Meshach, and Azariah called Abednego. 

# What did Daniel intend in his mind?

Daniel intended in his mind that he would not pollute himself with the king's delicacies or the king's wine. 

# How did the chief official respond when Daniel asked him for permission not to pollute himself with the king's delicacies and wine?

The chief official told Daniel that he was afraid of the king, that the king had commanded what food and drink Daniel should have and that the king might have the chief official's head if the king saw Daniel looking worse than the other young men of Daniel's own age. 

# What did Daniel ask of the steward who had been assigned over Daniel, Hananiah, Mishael and Azariah?

Daniel asked the steward to test them for ten days by giving them only vegetables to eat and water to drink and at the end of ten days to compare them with the other young men who ate the king's delicacies and then to treat them based of what he saw. 

# What did Daniel ask of the steward who had been assigned over Daniel, Hananiah, Mishael and Azariah?

Daniel asked the steward to test them for ten days by giving them only vegetables to eat and water to drink and at the end of ten days to compare them with the other young men who ate the king's delicacies and then to treat them based of what he saw. 

# What did Daniel ask of the steward who had been assigned over Daniel, Hananiah, Mishael and Azariah?

Daniel asked the steward to test them for ten days by giving them only vegetables to eat and water to drink and at the end of ten days to compare them with the other young men who ate the king's delicacies and then to treat them based of what he saw. 

# After the steward agreed to the test, what did he observe after ten days when he compared Daniel, Hananiah, Mishael and Azariah to the other young men?

The steward observed that the appearance of Daniel, Hananiah, Mishael and Azariah was more healthy, and that they were better nourished than all the young men who ate the king's delicacies. 

# After the steward agreed to the test, what did he observe after ten days when he compared Daniel, Hananiah, Mishael and Azariah to the other young men?

The steward observed that the appearance of Daniel, Hananiah, Mishael and Azariah was more healthy, and that they were better nourished than all the young men who ate the king's delicacies. 

# What did God give to Daniel, Hananiah, Mishael and Azariah?

God gave them knowledge and insight in all literature and wisdom, and Daniel could understand all kinds of visions and dreams. 

# What did the king find when he spoke with the whole group of young men?

The king found that there were none to compare with Daniel, Hananiah, Mishael and Azariah. In every question of wisdom and knowledge that the king asked them, he found them ten times better than all the magicians and those who claimed to speak with the dead, who were in his entire kingdom. 

# What did the king find when he spoke with the whole group of young men?

The king found that there were none to compare with Daniel, Hananiah, Mishael and Azariah. In every question of wisdom and knowledge that the king asked them, he found them ten times better than all the magicians and those who claimed to speak with the dead, who were in his entire kingdom. 

# How long was Daniel in Babylon?

He was there until the first year of King Cyrus. 

# When did Nebuchadnezzar have dreams that troubled his mind so that he could not sleep?

This occurred in the second year of his reign. 

# Why did the king summon the magicians, the sorcerers, the wise men and those who claimed to speak for the dead?

The king wanted these men to tell him about his dreams. 

# What did the king specifically want the wise men to do?

The king wanted the wise men to reveal the dream to him and also to interpret the dream for the king. 

# What did the king say would happen to the wise men if they failed to tell the king his dream and interpret it for him?

The king said if they failed, the bodies of the wise men would be torn apart and their houses made into hills of dung. 

# What did the king say he would do for the person or people who revealed the dream to him and interpreted it?

The king said he would give that person or persons gifts, a reward, and great honor. 

# Who did the wise men say could do what the king asked concerning his dream?

The wise men said that there was not a man on earth who could meet the king's demand, only the gods could do that. 

# Who did the wise men say could do what the king asked concerning his dream?

The wise men said that there was not a man on earth who could meet the king's demand, only the gods could do that. 

# After the wise men's reply to Nebuchadnezzar, what did the king decree?

The king decreed that all those known for their wisdom were to be put to death. 

# Who was Arioch?

He was the commander of the king's bodyguard, the one the king appointed to kill everyone who was wise in Babylon. 

# How did Daniel interact with Arioch, when he came to Daniel?

Daniel replied with prudence and discretion to Arioch. He asked Arioch why the king's decree was so urgent. 

# How did Daniel interact with Arioch, when he came to Daniel?

Daniel replied with prudence and discretion to Arioch. He asked Arioch why the king's decree was so urgent. 

# What did Daniel request after speaking with Arioch?

Daniel went in and requested an appointment with the king so he could present the interpretation to the king. 

# What did Daniel do after the secret was revealed to him?

Daniel praised the God of heaven. 

# For what did Daniel thank the God of his ancestors?

Daniel thanked the God of his ancestors for the wisdom and power the God of his ancestors had given him. 

# Who did Daniel go see after the secret was revealed to him?

Daniel went in to see Arioch. 

# What did Daniel tell Arioch?

Daniel told Arioch not to kill the wise men in Babylon. Daniel told Arioch to escort him before the king so Daniel could tell the king the dream's meaning. 

# When Daniel was brought in to the king, who did Daniel say could reveal the mystery the king had demanded?

Daniel said there is a God who lives in the heavens, who reveals secrets. 

# In general what did Daniel say the king's dream was about?

Daniel said the dream was about what would happen in the days to come. 

# Why was the dream revealed to Daniel?

The dream was revealed to Daniel so that the king might understand the meaning and know the thoughts deep within himself. 

# What did the statue that the king saw in his dream look like?

The statue was large and had a head of gold, breast and arms of silver, its middle and thighs were bronze, its legs of iron and its feet part iron and part clay. 

# What did the statue that the king saw in his dream look like?

The statue was large and had a head of gold, breast and arms of silver, its middle and thighs were bronze, its legs of iron and its feet part iron and part clay. 

# What happened to the statue the king saw in his dream?

The king saw a stone cut, but not by human hands. The stone struck the statue's feet and the whole statue shattered into pieces which the wind carried away. 

# What happened to the statue the king saw in his dream?

The king saw a stone cut, but not by human hands. The stone struck the statue's feet and the whole statue shattered into pieces which the wind carried away. 

# What happened to the stone that struck the statue?

The stone that struck the statue became a great mountain and filled the whole earth. 

# Who was the head of gold?

King Nebuchadnezzar was the head of gold. 

# What will the God of heaven do in the days of the kingdom that is partly iron and partly clay?

In those days the God of heaven will set up a kingdom that will never be destroyed or conquered by another people. 

# What did Nebuchadnezzar command to be done for Daniel after he finished telling the king the dream and its interpretation?

The king commanded an offering to be made and incense be offered up to Daniel. 

# What did Nebuchadnezzar say concerning Daniel's God?

Nebuchadnezzar said Daniel's God is the God of gods, the Lord of kings and the one who reveals secrets. 

# What did Nebuchadnezzar do after Daniel made a request of the king?

The king appointed Shadrach, Meshach, and Abednego to be administrators over the province of Babylon. 

# What were the dimensions of the gold statue that king Nebuchadnezzar made and set up on the Plain of Dura?

The statue was sixty cubits tall and six cubits wide. 

# Who came to the dedication of the statue that Nebuchadnezzar had made?

The provincial governors, regional governors, and local governors, together with the counselors, treasurers, judges, magistrates and all the high officials of the provinces came to the dedication. 

# What did Nebuchadnezzar want those in attendance at the dedication to do?

He wanted those in attendance to fall down and prostrate themselves to the golden statue when they heard the sound of the horns, flutes, zithers, lyres, harps, and pipes, and all kinds of music. 

# What did Nebuchadnezzar want those in attendance at the dedication to do?

He wanted those in attendance to fall down and prostrate themselves to the golden statue when they heard the sound of the horns, flutes, zithers, lyres, harps, and pipes, and all kinds of music. 

# What did the king command to happen to those who didn't fall down and worship the statue when they heard all the instruments and the music?

The king said that those who wouldn't fall down and worship, at that very moment, would be thrown into a blazing furnace. 

# Who brought accusations against Shadrach, Meshach, and Abednego?

Certain Chaldeans came and brought accusations against them. 

# Who didn't fall down and worship the statue?

Certain Jews, their names being Shadrach, Meshach, and Abednego, would not fall down and worship the statue. 

# What was the response of Shadrach, Meshach and Abednego to the king when the king repeated the command to fall down and worship the statue, and stated the consequences if they didn't follow the king's command?

Shadrach, Meshach and Abednego responded that their God could and would keep them safe and rescue them from the blazing furnace. But even if not, they would not worship Nebuchadnezzar's gods or prostrate themselves to the statue. 

# What was the response of Shadrach, Meshach and Abednego to the king when the king repeated the command to fall down and worship the statue, and stated the consequences if they didn't follow the king's command?

Shadrach, Meshach and Abednego responded that their God could and would keep them safe and rescue them from the blazing furnace. But even if not, they would not worship Nebuchadnezzar's gods or prostrate themselves to the statue. 

# What did Nebuchadnezzar command concerning Shadrach, Meshach and Abednego?

Nebuchadnezzar ordered the furnace to be heated seven times hotter than normal, and for Shadrach, Meshach and Abednego to be tied up and thrown into the furnace. 

# What did Nebuchadnezzar command concerning Shadrach, Meshach and Abednego?

Nebuchadnezzar ordered the furnace to be heated seven times hotter than normal, and for Shadrach, Meshach and Abednego to be tied up and thrown into the furnace. 

# What happened to Shadrach, Meshach, Abednego and the men who took them to put them in the furnace?

The men who took up Shadrach, Meshach and Abednego were killed by the very hot flames from the furnace and Shadrach, Meshach and Abednego fell into the furnace. 

# What happened to Shadrach, Meshach, Abednego and the men who took them to put them in the furnace?

The men who took up Shadrach, Meshach and Abednego were killed by the very hot flames from the furnace and Shadrach, Meshach and Abednego fell into the furnace. 

# What caused Nebuchadnezzar to be amazed and stand up quickly?

Nebuchadnezzar was amazed because he saw four men, not tied up, walking around in the fire and they weren't hurt and the brilliance of the fourth man was like a son of the gods. 

# What did those present observe about Shadrach, Meshack and Abednego after they came out of the fire.

Those present observed that the fire had not hurt their bodies; the hair on their heads was not singed; their robes were not harmed; and there was no smell of fire on them. 

# What decree did Nebuchadnezzar issue after the event of Shadrach, Meshach and Abednego and the blazing furnace?

Nebuchadnezzar decreed that any people, nation or language that spoke anything against the God of Shadrach, Meshach and Abednego would be torn apart, their houses would be made into hills of sewage because there was no other god who was able to save like that. 

# What did the king do for Shadrach, Meshach and Abednego?

Nebuchadnezzar, the king, promoted Shadrach, Meshach and Abednego in the province of Babylon. 

# To whom did Nebuchadnezzar send the decree?

Nebuchadnezzar sent the decree to all peoples, nations, and languages who lived on the earth. 

# Why did Nebuchadnezzar send the decree?

Nebuchadnezzar sent the decree to tell everyone about the signs and wonders the Most High had done for him. 

# What did Nebuchadnezzar say about the Most High?

Nebuchadnezzar said about the Most High, "How great are his signs, and how mighty are his wonders! His kingdom is an everlasting kingdom, and his dominion lasts from generation to generation." 

# What made Nebuchadnezzar afraid?

A dream Nebuchadnezzar made him afraid. 

# Why did Nebuchadnezzar issue a decree to bring before him all the wise men of Babylon?

Nebuchadnezzar wanted the wise men of Babylon to come and interpret his dream for him. 

# What was Daniel's Babylonian name and what was Daniel's position in Nebuchadnezzar's kingdom?

Daniel's Babylonian name was Belteshazzar and he held the position of "chief of the magicians". 

# Who did Nebuchadnezzar believe was able to tell the interpretation of his dream?

Nebuchadnezzar believed Daniel could interpret his dream for him, for Nebuchadnezzar said of Daniel, "...the spirit of the holy gods is in you and no mystery is too difficult for you." 

# What was Daniel's Babylonian name and what was Daniel's position in Nebuchadnezzar's kingdom?

Daniel's Babylonian name was Belteshazzar and he held the position of "chief of the magicians". 

# Who did Nebuchadnezzar believe was able to tell the interpretation of his dream?

Nebuchadnezzar believed Daniel could interpret his dream for him, for Nebuchadnezzar said of Daniel, "...the spirit of the holy gods is in you and no mystery is too difficult for you." 

# What did Nebuchadnezzar see in the first part of his dream?

Nebuchadnezzar saw a great, strong, beautiful tree that reached to the heavens. It provided shade for animals and an abode for the birds. It had abundant fruit that fed all living creatures. 

# What did Nebuchadnezzar see in the first part of his dream?

Nebuchadnezzar saw a great, strong, beautiful tree that reached to the heavens. It provided shade for animals and an abode for the birds. It had abundant fruit that fed all living creatures. 

# What did Nebuchadnezzar see in the first part of his dream?

Nebuchadnezzar saw a great, strong, beautiful tree that reached to the heavens. It provided shade for animals and an abode for the birds. It had abundant fruit that fed all living creatures. 

# What did the holy messenger from the heavens say to do to the tree?

The holy messenger said to chop down the tree, cut off its branches, strip off its leaves and scatter its fruit. 

# What did the holy messenger from the heavens say to do to the tree?

The holy messenger said to chop down the tree, cut off its branches, strip off its leaves and scatter its fruit. 

# What was to be done with the tree stump?

The stump was to be left in the earth bound with a band of iron and brass. Let it be wet with dew. Let it live with the animals. Let his mind be that of an animal and not of a man for seven years. 

# What was to be done with the tree stump?

The stump was to be left in the earth bound with a band of iron and brass. Let it be wet with dew. Let it live with the animals. Let his mind be that of an animal and not of a man for seven years. 

# What was the purpose of doing this to the tree in Nebuchadnezzar's dream?

The purpose was so that those who are alive would know that the Most High rules over the kingdoms of peoples and gives them to anyone he wishes to place over them. 

# Who did Daniel say the tree was in Nebuchadnezzar's dream?

Daniel said the tree was Nebuchadnezzar. 

# What was to happen to Nebuchadnezzar's until he acknowledged that the Most High rules over the kingdoms of people and that he gives them to anyone he wishes?

Nebuchadnezzar was to be driven from among men. He would live in the fields with the wild animals and eat grass like an ox and be wet with the dew from the heavens. 

# How long was it to be before Nebuchadnezzar would acknowledge that the Most High rules over the kingdoms of people and he gives them to anyone he wishes?

Seven years were to pass until Nebuchadnezzar acknowledged that the Most High rules over the kingdoms of people and he gives them to anyone he wishes. 

# After interpreting the dream for Nebuchadnezzar what was Daniel's advice for him?

Daniel advised Nebuchadnezzar to stop sinning and to do what was right. He also told Nebuchadnezzar to turn away from his sins by showing mercy to the oppressed. 

# How long was it before the interpretation of Nebuchadnezzar's dream began to happen?

All these things began to happen twelve months after his dream. 

# What happened to Nebuchadnezzar at the end of the seven years?

Nebuchadnezzar's sanity was restored to him? 

# What did Nebuchadnezzar do after his sanity was restored to him?

Nebuchadnezzar praised and honored the Most High who rules forever. 

# What happened to Nebuchadnezzar's kingdom?

The kingdom was given back to him. 

# What was Nebuchadnezzar's final statement concerning the King of heaven?

His statement was: "Now I, Nebuchadnezzar, praise, extol, and honor the King of heaven, for all his deeds are right, and his ways are just. He can humble those who walk in their own pride." 

# For whom did Belshazzar, the king, make a great feast?

He made a great feast for a thousand of his noblemen. 

# Who was this Belshazzar?

He was the son of Nebuchadnezzar. 

# What containers did they use to drink the wine from at this feast?

They used the gold containers that had been taken out of the temple, the house of God, in Jerusalem. 

# What did the people at the feast do as they drank the wine?

They praised their idols made of gold and silver, bronze, iron, wood, and stone. 

# As the people were drinking wine and praising their idols what happened?

The fingers of a human hand appeared in front of the lamp stand and wrote on the plaster wall in the king's palace. 

# What was the king's immediate response when he saw the hand?

The king's face changed and his thoughts frightened him; his limbs could not support him, and his knees were knocking together. 

# What did the king promise to the one who could explain the writing on the plaster wall and its meaning?

The king promised that the one who explained the writing and its meaning would be clothed in purple and would have a gold chain put around his neck and that he would have the authority of the third highest ruler in the kingdom. 

# According to the king what qualities did he say he had heard about Daniel?

The king told Daniel he had heard that Daniel had the spirit of the Gods in him and that Daniel possessed light and understanding and excellent wisdom . 

# What was Daniel's response when he was told of the rewards he would receive for reading the writing and explaining its meaning?

Daniel told the king, "Let your gifts be for yourself, and give your rewards to another person. Nevertheless, I will read the writing to you, king, and will tell you the meaning." 

# Why was Nebuchadnezzar brought down from his kingly throne and why was his majesty taken away from him?

Nebuchadnezzar lost his majesty and his throne because his heart became arrogant and his spirit was hardened so that he acted presumptuously. 

# What were Daniel's charges against Belshazzar?

Daniel said Belshazzar had not humbled his heart, he had lifted himself up against the Lord of Heaven and he had not honored the God who held his breath in his hand and who knew all his ways. 

# What were Daniel's charges against Belshazzar?

Daniel said Belshazzar had not humbled his heart, he had lifted himself up against the Lord of Heaven and he had not honored the God who held his breath in his hand and who knew all his ways. 

# What was the meaning of the writing on the plaster wall?

The meaning was as follows: God has numbered Belshazzar's kingdom and brought it to an end. Belshazzar is weighed in the scales and found lacking. Belshazzar's kingdom is divided and is given to the Medes and Persians. 

# What was the meaning of the writing on the plaster wall?

The meaning was as follows: God has numbered Belshazzar's kingdom and brought it to an end. Belshazzar is weighed in the scales and found lacking. Belshazzar's kingdom is divided and is given to the Medes and Persians. 

# What was the meaning of the writing on the plaster wall?

The meaning was as follows: God has numbered Belshazzar's kingdom and brought it to an end. Belshazzar is weighed in the scales and found lacking. Belshazzar's kingdom is divided and is given to the Medes and Persians. 

# What happened that night after Daniel gave his interpretation of the writing to Belshazzar?

That night Belshazzar, the Babylonian king, was killed, and Darius the Mede received the kingdom. 

# What happened that night after Daniel gave his interpretation of the writing to Belshazzar?

That night Belshazzar, the Babylonian king, was killed, and Darius the Mede received the kingdom. 

# How old was Darius the Mede when he received the kingdom?

Darius the Mede was about sixty-two years old when he received the kingdom. 

# Who did Darius appoint over the kingdom?

He appointed 120 provincial governors with three chief administrators over them. 

# Who did Darius appoint over the kingdom?

He appointed 120 provincial governors with three chief administrators over them. 

# Who was one of the three chief administrators?

Daniel was one of the three chief administrators. 

# Why were the three chief administrators appointed?

They were appointed to supervise the provincial governors, so that the king should suffer no loss. 

# Who was the king planning to put over the whole kingdom?

The king planned to put Daniel over the whole kingdom. 

# Why could the other chief administrators and provincial governors find no corruption, no failure in his duty, no mistakes and no negligence in Daniel's work for the kingdom?

They could find none of these things because Daniel was faithful. 

# What was the only area of his life that the other chief administrators and provincial governors think they might find something to complain against Daniel?

They thought they might find something against Daniel regarding the law of his God. 

# What did the provincial governors and the other chief administrators advise King Darius to do?

They advised Darius to issue a decree and enforce it that whoever made a a petition to any god or man except King Darius for thirty days, that person had to be thrown into a den of lions. 

# What did Daniel do after he learned that the decree had been issued and the document signed into law?

Daniel went into his house, got down on his knees and prayed giving thanks to God as he had done before. 

# What did the men who plotted against Daniel do when they saw Daniel make requests and seek help from God?

Those men went to the king and told him that Daniel paid no attention to the king or his decree and that Daniel prayed to God three times a day. 

# What did the king do when he heard Daniel had disobeyed the king's decree?

The king became terribly distressed and he applied his mind to rescue Daniel from his ruling. 

# After Daniel was thrown into the lion's den, what did the king do?

The king sealed the entrance to the den with his own signet ring. He then went to the palace and fasted through the night and did not sleep. 

# After Daniel was thrown into the lion's den, what did the king do?

The king sealed the entrance to the den with his own signet ring. He then went to the palace and fasted through the night and did not sleep. 

# The next day after Daniel was thrown into the lions den, when the king went to the den, what did he ask Daniel?

The king asked Daniel if the God whom Daniel served continually had been able to save him from the lions. 

# How did Daniel answer the king?

Daniel said to the king, "King, live forever! My God has sent his messenger and has shut the lion's mouths, and they have not hurt me. For I was found blameless before him and also before you, king, and I have done you no harm." 

# How did Daniel answer the king?

Daniel said to the king, "King, live forever! My God has sent his messenger and has shut the lion's mouths, and they have not hurt me. For I was found blameless before him and also before you, king, and I have done you no harm." 

# What was the first order the king gave after he found Daniel alive in the lion's den?

The first order the king gave after finding Daniel alive was that they should take Daniel up out of the den. 

# . What was the second order the king gave after he found Daniel alive in the lion's den?

The second order was to bring the men who had accused Daniel and throw them into the lion's den along with their children and their wives. 

# What did Darius say concerning God in his decree about the God of Daniel?

Darius said of the God of Daniel "...he is the living God and lives forever, and his kingdom shall not be destroyed; his dominion shall be to the end. He makes us safe and rescues us, and he does signs and wonders in heaven and in earth; he has kept Daniel safe from the power of the lions. 

# What did Darius say concerning God in his decree about the God of Daniel?

Darius said of the God of Daniel "...he is the living God and lives forever, and his kingdom shall not be destroyed; his dominion shall be to the end. He makes us safe and rescues us, and he does signs and wonders in heaven and in earth; he has kept Daniel safe from the power of the lions. 

# During whose reign did Daniel prosper?

Daniel prospered during the reign of Darius and during the reign of Cyrus the Persian. 

# When did Daniel have a dream and visions in his mind?

Daniel had a dream and visions while lying on his bed during the first year of Belshazzar king of Babylonia. 

# In Daniel's vision what was stirring up the great sea?

The four winds of heaven were stirring up the great sea. 

# What came up out of the sea?

Four large animals, each one different from the other came up out of the sea. 

# What was given to the animal that was like a lion?

The mind of a man was given to it. 

# What was the bear-like animal told to do?

It was told to get up and devour many people. 

# What was the leopard-like animal given?

It was given authority to rule. 

# What did the fourth animal do?

The fourth animal devoured, broke in pieces, and trampled underfoot what was left. 

# What did Daniel see happen to the fourth animal as he considered its horns?

Daniel saw another little horn grow up among the other ten horns. Three of the first horns were wrenched out by the roots. Daniel saw that the little horn had eyes like a man and a mouth that boasted about great things. 

# Who sat on one of the thrones that was set up?

The Ancient of Days sat upon one of the thrones. 

# What business was being conducted by the Ancient of Days?

The court was in session and the books were opened. 

# What happened to the four animals?

The animal with the horn that spoke boastful words was killed, its body destroyed and it was handed over to be burned up. The other three animals had their authority to rule taken away but their lives were prolonged for a time. 

# What happened to the four animals?

The animal with the horn that spoke boastful words was killed, its body destroyed and it was handed over to be burned up. The other three animals had their authority to rule taken away but their lives were prolonged for a time. 

# In Daniel's vision, who was presented to the Ancient of Days?

One who came with the clouds of heaven like a son of man was presented to the Ancient of Days. 

# What was given to this one who was "like a son of man"?

Everlasting authority to rule, a kingdom that will never be destroyed, and glory and royal power were given to this one who was "like a son of man". 

# What was Daniel told the four animals represented in his vision?

Daniel was told that the four animals were four kings that would arise from the earth. 

# Who will receive the kingdom and possess it forever?

The saints of the Most High will receive the kingdom and possess it forever and ever. 

# When Daniel asked one standing there about the fourth animal, what did that one say the fourth animal was and would do to the earth?

That one said the fourth animal was a fourth kingdom and that it would devour the whole earth, trample it down and break it into pieces. 

# What did the one standing there say about the ten horns?

That one standing there said that ten kings would arise out of the fourth kingdom. 

# What will the one who speaks against the most high do and what will be his end?

He will oppress the holy people of the most high. He will try to change the festivals and the law. He will rule over these things for one year, two years, and half a year but his royal power would be taken away to be consumed and destroyed at the end. 

# What will the one who speaks against the most high do and what will be his end?

He will oppress the holy people of the most high. He will try to change the festivals and the law. He will rule over these things for one year, two years, and half a year but his royal power would be taken away to be consumed and destroyed at the end. 

# To whom will the kingdom and dominion under the whole heaven be given?

It will be given to the people who belong to the Most High. 

# What was Daniel's response to this vision?

Daniel was greatly alarmed and his face changed in appearance, but he kept the vision to himself. 

# When did Daniel have his second vision?

Daniel had his second vision in the third year of the reign of king Belshazzar. 

# Where was Daniel in his vision?

Daniel was in the fortified city of Susa in the province of Elam beside the Ulai Canal. 

# What were the two animals Daniel saw in this vision?

Daniel saw a ram and a male goat in this vision. 

# What were the ram's two horns like?

One of the ram's horns was longer than the other but the shorter horn grew longer than the previously longer horn. 

# How powerful was the ram?

No animal could stand before the ram. None could be rescued from the ram's hand. He did whatever he wanted, and he became great. 

# What kind of horns did the goat have?

The goat only had one large horn between his eyes. 

# What did the goat do to the ram?

The goat hit the ram and broke off its two horns, knocked the ram down to the ground and trampled on him. 

# When the large horn of the goat was broken off, what grew in its place?

Four other large horns that pointed to the four winds of heaven grew up in place of the one that was broken off. 

# What happened to one of the goat's four horns?

Out of one of the horns grew another horn, little at first, but which became very large in the south, in the east, and in the glorious land of Israel. 

# What did this horn do when it became large?

It became so large that it engaged in war with the army of heaven. 

# Why will the army be given over to the goat's horn and the burnt offering stopped?

This will happen because of rebellion. 

# How long will these things last, this vision about the burnt offering, the sin that brings destruction, the handing over of the sanctuary, and heaven's army being trampled on?

It will last for 2,300 evenings and mornings. 

# What will happen after the 2,300 evenings and mornings?

The sanctuary will be put right. 

# Who was told to help Daniel understand the vision?

Gabriel was told to help Daniel understand the vision. 

# For when was the vision? What time did it concern?

The vision was for the time of wrath. It concerned the fixed time for the end. 

# What did the ram with two horns and the male goat represent in Daniel's vision?

The ram with the two horns are the kings of Media and Persia. The male goat is the king of Greece. 

# What did the ram with two horns and the male goat represent in Daniel's vision?

The ram with the two horns are the kings of Media and Persia. The male goat is the king of Greece. 

# What did the four horns represent, the horns that came in place of the horn that was broken off?

The four horns represent four kingdoms that will arise from the nation represented by the horn that was broken off. 

# What will this intelligent, grim-face king do?

He will cause widespread destruction and succeed in whatever he does. He will destroy powerful people, people who are holy. He will make deceit prosper under his hand. He will rise up against the king of kings. 

# What will this intelligent, grim-face king do?

He will cause widespread destruction and succeed in whatever he does. He will destroy powerful people, people who are holy. He will make deceit prosper under his hand. He will rise up against the king of kings. 

# What will finally happen to the intelligent, grim-faced king?

He will be broken, but not by human power. 

# How did this vision affect Daniel?

Daniel was overcome and lay weak for several days and he was appalled by the vision. 

# Ahasuerus was king over what realm?

He was the king over the realm of the Babylonians. 

# What did Daniel observed by studying Yahweh's word to Jeremiah the prophet?

He observed that Jerusalem's abandonment would end after seventy years. 

# How did Daniel seek the Lord God?

Daniel sought the Lord God with prayer and requests, with fasting, wearing sackcloth, and sitting in ashes. 

# What was the first thing Daniel did when he went to the Lord God in prayer?

Daniel made confession of the sins of the Israelites. 

# To whom did the prophets speak in the name of God?

The prophets spoke to the kings, the leaders, the ancestors, and to all the people of the land. 

# Why did shame belong on the faces of the Israelites?

Shame belonged on their faces because they sinned against the Lord. 

# What had been poured out on Israel because of their sin?

The curse and oath that are written in the Law of Moses, the servant of God, had been poured out on them. 

# How did Yahweh confirm the words he spoke against Israel and their rulers?

Yahweh confirmed his words by bringing on Israel and their rulers a great disaster. 

# What did Daniel say that Israel had not done to beg God for mercy?

Daniel said they had not turned away from their sins and had not paid attention to God's truth. 

# What did Daniel say was the reason the Lord God should forgive Israel?

Daniel said the Lord should forgive Israel because of the Lord's righteous deeds. 

# When did Gabriel come to Daniel?

Gabriel came to Daniel at the time of the evening sacrifice while Daniel was praying. 

# Why did Gabriel come to Daniel?

Gabriel came to give Daniel insight and understanding. 

# Why were seventy sevens of years decreed for Daniel's people and his holy city?

The seventy sevens of years were decreed to end the guilt, put an end to sin, to atone for wickedness, to bring everlasting righteousness, to carry out the vision and the prophecy, and to consecrate the most holy place. 

# How much time will elapse between the issuing of the order to restore and rebuild Jerusalem to the coming of the anointed one?

Seven sevens and sixty-two sevens will elapse between the two events.. 

# When will the anointed one be destroyed?

He will be destroyed after the sixty-two sevens of years. 

# What will a coming ruler do?

He will confirm a covenant with many for one seven. In the middle of the seven he will put an end to the sacrifice and the offering. 

# What will happen to the one who makes desolate?

A full end and destruction are decreed for that one. 

# What message was revealed to Daniel in the third year of Cyrus king of Persia?

The message was about a great war. 

# How was Daniel able to understand the message?

Daniel understood the message because he had insight from a vision. 

# Who did Daniel see in his vision?

He saw a man dressed in linen with a pure gold belt around his waist. 

# What was the man in Daniel's vision like?

The man's body was like topaz, his face like lightning, his eyes like flaming torches, his arms and feet like polished bronze, and the sound of his words like the sound of a great crown. 

# What was Daniel's response when he saw the great vision and heard the man's words?

Daniel's radiant appearance was fearfully changed, and no strength remained in him. He fell on his face in deep sleep with his face to the ground. 

# What was Daniel's response when he saw the great vision and heard the man's words?

Daniel's radiant appearance was fearfully changed, and no strength remained in him. He fell on his face in deep sleep with his face to the ground. 

# When was the angel sent to Daniel?

The angel was sent on the first day Daniel set his mind to understand and humble himself before God. 

# Why did it take the angel twenty-one days to come to Daniel?

The angel was detained by the prince of the kingdom of Persia who resisted him. 

# When will the events of the vision happen?

The vision was about the last days, the days yet to come. 

# What did Daniel say the vision had done to him?

Daniel said the vision had turned his anguish on him and the he had no strength left and no breath left in him. 

# What did Daniel say the vision had done to him?

Daniel said the vision had turned his anguish on him and the he had no strength left and no breath left in him. 

# What did the one with an appearance like a human being do to strengthen Daniel?

The one who looked like a human being touched Daniel to strengthen him. 

# What was the one who looked like a human being say he was going to do after he left Daniel?

He said he was returning to fight against the prince of Persia. 

# What did the one who looked like a human being say he was going to tell Daniel?

He said he was going to tell Daniel what was written in the book of truth. 

# How will a fourth king in Persia gain power?

He will gain power through his riches. 

# Against what kingdom did that fourth Persian king stir up everyone?

He stirred everyone up against the kingdom of Greece. 

# To whom will the kingdom of the mighty king not be given?

That kingdom will not be given to the king's own descendants. 

# Who will make an alliance?

The king of the South and one of his commanders who will become a king of the North will make an alliance. 

# Who will make an alliance?

The king of the South and one of his commanders who will become a king of the North will make an alliance. 

# Who will come to confirm the alliance between the king of the South and the king of the North?

The daughter of the king of the South will come to the king of the North to confirm the agreement. 

# What will the branch from the daughter of the king of the South do to the king of the North?

He will attack the army and enter the fortress of the king of the North and conquer them. 

# What will the sons of the king of the North do?

They will wage war and assemble a great army. They will overflow like a flood, pass through, and repeat the assault all the way to the fortress of the king of the South. 

# What will the king of the South do in response to the attack by the sons of the king of the North?

The king of the South will march out in a rage and fight against the king of the North. 

# Who won this battle between the North and the South?

The king of the South won that battle. 

# Who won this battle between the North and the South?

The king of the South won that battle. 

# After some years, what will the king of the North do?

He will raise another great army supplied with much equipment and will surely come. 

# In those times who else will rise against the king of the South?

In those times many will rise against the king of the South including the most violent among Daniel's people. 

# What will happen this time when the king of the North attacks the king of the South?

The king of the South will not be able to stand against him. The king of the North will do whatever he wants against the king of the South. 

# What will happen this time when the king of the North attacks the king of the South?

The king of the South will not be able to stand against him. The king of the North will do whatever he wants against the king of the South. 

# Why will the king of the North give a daughter in marriage to the king of the South?

The king of the North will do this in order to destroy the kingdom of the South. 

# What will happen to this king of the North?

A commander will put an end to the insolence of the king of the North and will cause his insolence to turn back upon him. He will stumble and fall; he will not be found. 

# What will happen to this king of the North?

A commander will put an end to the insolence of the king of the North and will cause his insolence to turn back upon him. He will stumble and fall; he will not be found. 

# What will the one who rises up in place of the king of the North do?

He will force taxes to be paid to provide for the splendor of the kingdom. 

# What will happen to this one who forces taxes to be paid?

After only a few days that one will be destroyed, but not in anger or in battle. 

# How will a despised person who has not been given the honor of royalty come to power?

He will come in quietly and will take over the kingdom by flattery. 

# What will this despised king do once an alliance is made with him?

From the time an alliance is made with him, he will act deceitfully. 

# What will happen when this deceitful king wages war against the king of the South?

The king of the South will not be able to stand against the deceitful king because of all the plots devised against him. 

# Why will the king of the North and the king of the South sit at the same table and lie to each other?

They will lie to each other because their hearts are set on evil against each other. 

# What will the heart of the king of the North be set against?

His heart will be set against the holy covenant. 

# How will the rage of the king of the North against the holy covenant manifest itself?

The king of the North will manifest his rage against the holy covenant by showing favor to those who forsake the holy covenant. 

# What will happen to the wise?

For days the wise will fall by the sword and flame, they will be taken as prisoners and robbed of their possessions. When they stumble they will receive a little help. 

# What will the wise do at that time?

At that time the wise will give understanding to many? 

# What will happen to the wise?

For days the wise will fall by the sword and flame, they will be taken as prisoners and robbed of their possessions. When they stumble they will receive a little help. 

# Why will some of the wise stumble?

Some of them will stumble so that they may be refined, cleansed, and made pure until the time of the end. 

# Above whom will this deceitful king of the North exalt himself?

He will exalt and magnify himself above every god; including the God of gods, the gods of his ancestors, and the god desired by women. 

# Above whom will this deceitful king of the North exalt himself?

He will exalt and magnify himself above every god; including the God of gods, the gods of his ancestors, and the god desired by women. 

# What will this deceitful king of the North do for those who acknowledge him?

He will give honor to those who acknowledge him. He will make them rulers over many people. 

# At the time of the end what will happen when the king of the North comes into the glorious land?

At that time tens of thousands of Israelites will stumble and fall. 

# Who will escape from the hand of the king of the North?

Many from Edom and Moab, and the remaining people of Ammon will escape from his hand. 

# What are some of the countries over which this king of the North will extend his power?

This king of the North will extend his power over Egypt, the Libyans, and the Ethiopians. 

# What are some of the countries over which this king of the North will extend his power?

This king of the North will extend his power over Egypt, the Libyans, and the Ethiopians. 

# What will this king of the North do when reports from the east and north alarm him?

He will go out with great rage to destroy and to devote many to destruction. 

# Where will this king of the North set up his the tents of his palace?

He will set up the tents of his palace between the seas, at the mountain of the beauty of holiness. 

# Who will help the king of the North at the end?

The king of the North will come to his end and there will be no one to help him. 

# Who is it that guards Daniel's people?

Michael, the great prince guards Daniel's people. 

# How bad will be the time of trouble written of here?

It will be a time of trouble such as never was since the beginning of any nation until that time. 

# At that time who will be saved?

At that time Daniel's people will be saved, everyone whose name is found written in the book. 

# What will happen to many of those who sleep in the dust of the earth?

Some of those who sleep in the dust of the earth will rise up to everlasting life and some will rise up to shame and everlasting contempt. 

# What will happen to those who are wise and those who turn many to righteousness?

Those who are wise will shine like the brightness of the sky above, and those who turn many to righteousness like the stars forever and ever. 

# How long was Daniel told to keep the book sealed?

He was told to keep the book sealed until the time of the end. 

# How long did the man clothed in linen say it would be until the end of these amazing events?

The man clothed in linen said it would be for a time, times, and a half. When the shattering of the power of the holy people comes to an end, all these things will be completed. 

# What did the man clothed in linen give as a reason why Daniel did not understand what the man clothed in linen was telling him?

The man clothed in linen said to Daniel, "Go your way, Daniel, for the words are shut up and sealed until the time of the end. 

# At the time of the end who will and who won't understand the words of the prophecy?

None of the wicked will understand, but those who are wise will understand. 

# How much time will elapse between the time that the regular burnt offering is taken away and the abomination that causes complete desolation is set up?

There will be 1,290 days between those two events. 

# At that time who does the man clothed in linen say will be blessed?

The man clothed in linen said, "Blessed is the one who waits until the end of the 1,335 days." 

# What did the man clothed in lined say would happen to Daniel?

He said that Daniel would rest and that he would rise in the place assigned to him at the end of days. 

