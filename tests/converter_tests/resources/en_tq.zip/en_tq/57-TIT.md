# What was Paul's purpose in his service to God?

His purpose was to establish the faith of God's elect and to establish the knowledge of the truth. 

# When did God promise everlasting life to his elect?

He promised it before all the ages of time. 

# Can God lie?

No. 

# Who did God use to make his message evident at the right time?

God used the apostle Paul. 

# What was the relationship between Titus and Paul?

Titus was Paul's true son in their common faith. 

# What must be true of an elder's family life?

He must be the husband of one wife, with faithful children who are disciplined. 

# What are some of the character traits that an elder must avoid in order to be blameless?

He must not be loud and unrestrained, not a drunkard, not argumentative, not greedy. 

# In God's household, what position and responsibility does an overseer have?

He is the household manager. 

# What good qualities should an elder have?

An elder should be hospitable, a friend of what is good, sensible, righteous, godly, and self-controlled. 

# What must an elder's attitude be toward the doctrines (teachings) of the faith?

He must hold tightly to them, and be able to use them to encourage and rebuke others. 

# What were the false teachers doing by their words?

They were deceiving people and breaking up families. 

# What were the false teachers doing by their words?

They were deceiving people and breaking up families. 

# What was motivating the false teachers?

They were motivated by shameful profit. 

# How should an elder treat undisciplined people who damage the church?

He must sharply correct them so they may be sound in the faith. 

# On what did Paul say they should not waste time?

They should not waste time on Jewish myths and commandments of men. 

# In an unbelieving man, what is polluted?

The mind and conscience are polluted. 

# Although the polluted man confesses to know God, how does he deny him?

He denies God through his actions. 

# What are some characteristics that older men in the church should display?

They should display temperance, dignity, and soundness in faith, in love, and in perseverance. 

# What are some characteristics that older women in the church should display?

They should display reverence, not gossiping; they should be sober and teach what is good. 

# What should the older women teach the younger women?

They should teach them to love and obey their husbands, to love their children, to be sensible, pure, and be good housekeepers. 

# What should the older women teach the younger women?

They should teach them to love and obey their husbands, to love their children, to be sensible, pure, and be good housekeepers. 

# What should Titus do to be a model to the believers?

He should teach, showing purity and dignity, and using healthy words that do not need to be corrected. 

# What should Titus do to be a model to the believers?

He should teach, showing purity and dignity, and using healthy words that do not need to be corrected. 

# How are slaves who are believers to behave?

They are to obey their masters, not steal from them, and should show good faith. 

# How are slaves who are believers to behave?

They are to obey their masters, not steal from them, and should show good faith. 

# When slaves behave as Paul has instructed, what effect will that have on others?

It makes the teaching about God our Savior attractive to others. 

# Who can the grace of God save?

The grace of God can save everyone. 

# What does the grace of God train us to deny?

The grace of God trains us to deny ungodliness and worldly passions. 

# What future event do believers look forward to receiving?

Believers look forward to the appearance of the glory of our great God and Savior Jesus Christ. 

# Why did Jesus give himself for us?

He gave himself in order to pay the price to set us free from lawlessness, and to make a pure people eager to do good. 

# What should the believer's attitude be toward rulers and authorities?

The believer should be submissive and obedient, being ready for every good work. 

# What leads astray and enslaves unbelievers?

Their passions and pleasures lead them astray. 

# Through what means did God save us?

He saved us through the washing of new birth and renewal by the Holy Spirit. 

# Are we saved because of good works which we have done, or because of God's mercy?

We are saved only because of God's mercy 

# After he justifies us, what does God make us?

God makes us his heirs. 

# What should believers set their minds on?

Believers should set their minds on the good works that God puts before them to do. 

# What should believers avoid?

Believers should avoid foolish debates. 

# Who must be rejected after one or two warnings?

Anyone who is causing divisions among the believers must be rejected after one or two warnings. 

# What must believers engage themselves in so that they will be fruitful?

Believers must learn to engage themselves in doing good works that meet urgent needs. 

