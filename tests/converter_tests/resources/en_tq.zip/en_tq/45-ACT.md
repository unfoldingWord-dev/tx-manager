# To whom did Luke address this book?

Luke addressed this book to Theophilus. 

# What did Jesus do for forty days after his suffering?

Jesus appeared alive to his apostles, saying things about the kingdom of God. 

# For what did Jesus command his apostles to wait?

Jesus told his apostles to wait for the promise of the Father. 

# With what would the apostles be baptized in a few days?

The apostles would be baptized with the Holy Spirit. 

# When the apostles wanted to know the timing of the restoration of the kingdom, how did Jesus answer them?

Jesus told them that it was not for them to know the time. 

# What did Jesus tell the apostles they would receive from the Holy Spirit?

Jesus said the apostles would receive power. 

# Where did Jesus say the apostles would be his witnesses?

Jesus said the apostles would be witnesses in Judea, Samaria, and to the ends of the earth. 

# How did Jesus depart from his apostles?

Jesus was raised up and a cloud hid him from their eyes. 

# How did the angels say that Jesus would return again to the earth?

The angels said that Jesus would return in the same say he went into heaven. 

# What were the apostles, the women, Mary, and Jesus' brothers doing in the upper chamber?

They were diligently praying. 

# What had been fulfilled in the life of Judas, who betrayed Jesus?

The scripture had been fulfilled by Judas. 

# What happened to Judas after he received the money for betraying Jesus?

Judas bought a field, fell head first, his body burst wide open, and all his bowels poured out. 

# In the book of Psalms, what did it say should happen with Judas' position of leadership?

The Psalms said that Judas' position of leadership should be fulfilled by someone else. 

# What were the requirements for the man who would take Judas' position of leadership?

The man taking the position must have accompanied the apostles from the time of the baptism of John, and must have witnessed the resurrection of Jesus. 

# What were the requirements for the man who would take Judas' position of leadership?

The man taking the position must have accompanied the apostles from the time of the baptism of John, and must have witnessed the resurrection of Jesus. 

# How did the apostles determine which of the two candidates should take Judas' position?

The apostles prayed that God reveal His choice, and then they cast lots. 

# How did the apostles determine which of the two candidates should take Judas' position?

The apostles prayed that God reveal His choice, and then they cast lots. 

# How did the apostles determine which of the two candidates should take Judas' position?

The apostles prayed that God reveal His choice, and then they cast lots. 

# Who was then numbered with the eleven apostles?

Matthias was then numbered with the eleven apostles. 

# On what Jewish festival day were all the disciples together?

The disciples were together on the day of Pentecost. 

# When the Holy Spirit came into the house, what did the disciples begin to do?

The disciples began to speak with other languages. 

# At this time in Jerusalem, there were godly Jews from where?

There were godly Jews from every nation under heaven. 

# Why was the multitude confused when they heard the disciples speaking?

The multitude was confused because everyone heard them speaking in his own language. 

# About what were the disciples speaking?

The disciples were telling about the mighty works of God. 

# What did some think who were mocking the disciples?

Some mocked and thought they were full of new wine. 

# What did Peter say was being fulfilled at this time?

Peter said the prophecy of Joel was being fulfilled that said God would pour out his Spirit upon all flesh. 

# What did Peter say was being fulfilled at this time?

Peter said the prophecy of Joel was being fulfilled that said God would pour out his Spirit upon all flesh. 

# In Joel's prophecy, who are the ones that are saved?

Everyone who calls on the name of the Lord are the ones that are saved. 

# How was Jesus' ministry authenticated by God?

Jesus' ministry was authenticated by the mighty works and wonders and signs which God did through him. 

# Whose plan was it that Jesus be crucified?

Jesus was crucified by God's determined plan. 

# In the Old Testament, what did King David prophecy about God's Holy One?

King David said that God would not allow his Holy One to see decay. 

# In the Old Testament, what did King David prophecy about God's Holy One?

King David said that God would not allow his Holy One to see decay. 

# What promise had God made to King David about his descendants?

God had promised King David that one of his descendants would sit upon the throne. 

# In the Old Testament, what did King David prophecy about God's Holy One?

King David said that God would not allow his Holy One to see decay. 

# Who was God's Holy One who did not see decay and would sit upon the throne?

Jesus was the prophesied Holy One and King. 

# Peter preached that God had now given Jesus what two titles?

God had made Jesus both Lord and Christ. 

# When the multitude heard Peter's preaching, what was their response?

The multitude asked what they should do. 

# What did Peter tell the multitude to do?

Peter told the multitude to repent and be baptized in the name of Jesus Christ for the forgiveness of their sins. 

# For whom did Peter say was God's promise?

Peter said God's promise was for the multitude, their children, and all who were far off. 

# How many people were baptized that day?

About three thousand people were baptized. 

# In what did the baptized people continue?

They continued in the apostles' teaching and fellowship, in the breaking of bread and in prayers. 

# What did those who believed do to help those in need?

They sold their property and possessions and distributed them to all, as anyone had need. 

# What did those who believed do to help those in need?

They sold their property and possessions and distributed them to all, as anyone had need. 

# Where were the believers meeting at this time?

The believers met in the Temple. 

# Who was adding day by day to the group of believers?

The Lord added day by day those that were being saved. 

# Who did Peter and John see on their way into the Temple?

Peter and John saw a man lame from birth who begged at the Temple door. 

# What did Peter not give to the man?

Peter did not give to the man silver and gold. 

# What did Peter do for the man?

Peter gave the man the ability to walk. 

# How did the man react to what Peter gave him?

The man entered the Temple walking, leaping, and praising God. 

# How did the people react who saw the man in the Temple?

The people were filled with wonder and amazement. 

# What did Peter remind the people they had done with Jesus?

Peter reminded the people that they had killed Jesus. 

# What did Peter say had made the man well?

Peter said that faith in Jesus' name had made the man well. 

# What did Peter tell the people to do?

Peter told the people to repent. 

# Peter said that the heavens would receive Jesus until what time?

Peter said that until the time of restoration of all things, Jesus would be received in the heavens. 

# What did Moses say about Jesus?

Moses said that the Lord God would raise up a prophet like himself to whom the people would listen. 

# What will happen to every person who does not listen to Jesus?

The person who does not listen to Jesus will be completely destroyed. 

# Of what Old Testament covenant promise did Peter remind the people?

Peter reminded the people that they were sons of the covenant God made with Abraham when God said, "In your seed shall all the families of the earth be blessed". 

# How was God desiring to bless the Jews?

God desired to bless the Jews by sending Jesus to them first to turn them from their wickedness. 

# What were Peter and John teaching the people in the Temple?

Peter and John were teaching about Jesus and his resurrection from the dead. 

# How did the rulers of the Temple, the priests, and the Sadducees react to Peter and John's teaching?

They arrested Peter and John and put them in jail. 

# How did the people react to Peter and John's teaching?

Many people believed, about five thousand. 

# By what power or in what name did Peter say he had healed the man in the Temple?

Peter said that in the name of Jesus Christ he had healed the man in the Temple. 

# What did Peter say was the only way by which we may be saved?

Peter said that there is no other name except Jesus by which we may be saved. 

# Why could the Jewish leaders say nothing against Peter and John?

The leaders could say nothing because the man who had been healed was standing with Peter and John. 

# What did the Jewish leaders command Peter and John not to do?

The Jewish leaders commanded Peter and John not to speak or teach about Jesus. 

# How did Peter and John answer the Jewish leaders?

Peter and John said that they could not help but speak about the things they had seen and heard. 

# What did the believers ask for from God in response to the warnings from the Jewish leaders?

The believers asked for boldness to speak the word, and for signs and wonders to be done in Jesus' name. 

# What did the believers ask for from God in response to the warnings from the Jewish leaders?

The believers asked for boldness to speak the word, and for signs and wonders to be done in Jesus' name. 

# What happened after the believers finished their prayer?

After the believers finished their prayer, the place they were gathered was shaken, they were filled with the Holy Spirit, and they spoke the word with boldness. 

# How were the needs of the believers provided for?

The believers had all things in common, and those who owned property sold it and gave the money to be distributed according to need. 

# How were the needs of the believers provided for?

The believers had all things in common, and those who owned property sold it and gave the money to be distributed according to need. 

# How were the needs of the believers provided for?

The believers had all things in common, and those who owned property sold it and gave the money to be distributed according to need. 

# What was the new name, meaning the "Son of Encouragement," given to the man who sold his field and gave the money to the apostles?

The man named "Son of Encouragement" was Barnabas. 

# What was the new name, meaning the "Son of Encouragement," given to the man who sold his field and gave the money to the apostles?

The man named "Son of Encouragement" was Barnabas. 

# What sin did Ananias and Sapphira commit?

Ananias and Sapphira lied, saying that they were giving the entire sale price of their property, but actually only giving a part of the sale price. 

# What sin did Ananias and Sapphira commit?

Ananias and Sapphira lied, saying that they were giving the entire sale price of their property, but actually only giving a part of the sale price. 

# To whom did Peter say Ananias and Sapphira had lied?

Peter said that Ananias and Sapphira had lied to the Holy Spirit. 

# What was God's judgment on Ananias?

God killed Ananias. 

# What was God's judgment on Sapphira?

God killed Sapphira. 

# What was the reaction of the church and all who heard about Ananias and Sapphira?

Great fear came upon the church and all who heard about Ananias and Sapphira. 

# What were some people doing to have the sick healed?

Some were carrying the sick into the streets so Peter's shadow might fall on them, and others brought the sick from other towns to Jerusalem. 

# What were some people doing to have the sick healed?

Some were carrying the sick into the streets so Peter's shadow might fall on them, and others brought the sick from other towns to Jerusalem. 

# How did the Sadducees react to all of the sick being healed in Jerusalem?

The Sadducees were filled with jealousy and put the apostles in jail. 

# How did the Sadducees react to all of the sick being healed in Jerusalem?

The Sadducees were filled with jealousy and put the apostles in jail. 

# How did the apostles get out of jail?

An angel came and opened the doors of the jail and let them out. 

# What did the officers of the high priest find when they went to the jail?

The officers found the jail securely shut, but no one inside. 

# Why did the officers bring the apostles back to the high priest and council without violence?

The officers feared that the people might stone them. 

# When questioned about why they were teaching in Jesus' name when they had been charged not to, what did the apostles say?

The apostles said, "We must obey God rather than men". 

# Who did the apostles say was responsible for killing Jesus?

The apostles said that the high priest and council members were responsible for killing Jesus. 

# How did the council members react to the statement that they were responsible for killing Jesus?

The council members were furious and wanted to kill the apostles. 

# What was Gamaliel's advice to the council?

Gamaliel advised the council to leave the apostles alone. 

# What did Gamaliel warn the council they might end up doing if they tried to overthrow the apostles?

Gamaliel warned the council that they might end up fighting against God. 

# What did the council finally do with the apostles?

The council beat them and commanded them not to speak in the name of Jesus, and let them go. 

# How did the apostles react to the treatment they received from the council?

The apostles rejoiced that they were counted worthy to suffer dishonor for Jesus' name. 

# What did the apostles do every day after their meeting with the council?

The apostles preached and taught every day that Jesus was the Christ. 

# What complaint arose from the Grecian Jews against the Hebrews?

The Grecian Jews complained that their widows were being overlooked in the daily food distribution. 

# Who chose the seven men to take care of the business of food distribution?

The disciples (brothers) chose the seven men. 

# What were the qualifications for being chosen as one of the seven men?

The seven men had to be of good reputation, full of the Spirit and of wisdom. 

# In what would the apostles continue?

The apostles would continue in prayer and in the ministry of the word. 

# What did the apostles do when the believers brought the seven men?

The apostles prayed and placed their hands upon them. 

# What was happening with the disciples in Jerusalem?

The number of disciples was greatly increasing, including a great number of the priests. 

# Who was winning the debates between the unbelieving Jews and Stephen?

The unbelieving Jews could not stand against the wisdom and Spirit with which Stephen spoke. 

# What accusation was made by false witnesses against Stephen to the council?

The false witnesses claimed that Stephen said Jesus would destroy this place and change the customs of Moses. 

# When the council looked at Stephen, what did they see?

They saw that his face was like the face of an angel. 

# Stephen began to review the history of the Jewish people beginning with God's promise to whom?

Stephen began his history by talking about God's promise to Abraham. 

# What was God's promise to Abraham?

God promised land to Abraham and his descendants. 

# Why did God's promise to Abraham seem impossible to fulfill?

God's promise seemed impossible because Abraham had no children. 

# What did God say would first happen to Abraham's descendants for four hundred years?

God said Abraham's descendants would be slaves in a foreign land for four hundred years. 

# What covenant did God give to Abraham?

God gave Abraham the covenant of circumcision. 

# How did Joseph become a slave in Egypt?

His brothers were jealous of him and sold him into Egypt. 

# How did Joseph become governor over Egypt?

God gave Joseph favor and wisdom in the presence of Pharaoh. 

# What did Jacob do when there was famine in Canaan?

Jacob sent his sons to Egypt because he heard there was grain there. 

# What did Jacob do when there was famine in Canaan?

Jacob sent his sons to Egypt because he heard there was grain there. 

# Why did Jacob and his relatives move to Egypt?

Joseph sent his brothers to tell Jacob to come to Egypt. 

# What happened to the number of Israelites in Egypt as the time promised to Abraham drew near?

The number of Israelites in Egypt grew and multiplied. 

# How did the new king of Egypt try to reduce the number of Israelites?

The new king of Egypt forced the Israelites to throw out their infants so they would not survive. 

# How did Moses survive being thrown out?

Pharaoh's daughter took Moses and raised him as her own son. 

# How was Moses educated?

Moses was educated in all the learning of the Egyptians. 

# When he was forty years old, what did Moses do when he saw an Israelite being mistreated?

Moses defended the Israelite and struck the Egyptian. 

# To where did Moses flee?

Moses fled to Midian. 

# When Moses was eighty years old, what did Moses see?

Moses saw an angel in a flame of fire in a bush. 

# Where did the Lord command Moses to go, and what was God going to do there?

The Lord commanded Moses to go to Egypt, because God was going to rescue the Israelites. 

# How long did Moses lead the Israelites in the wilderness?

Moses led the Israelites in the wilderness for forty years. 

# What did Moses prophesy to the Israelites?

Moses prophesied to the Israelites that God would raise up a prophet like him from among their brothers. 

# How did the Israelites turn their hearts back to Egypt?

The Israelites made a calf and sacrificed to the idol. 

# How did God respond to the Israelites turning away from him?

God turned from Israelites and gave them up to serve the host of heaven. 

# To where did God say he would carry away the Israelites?

God said he would carry the Israelites away to Babylon. 

# In the wilderness, what did God command the Israelites to build, which they later carried into the land?

In the wilderness, the Israelites built the tabernacle of the testimony. 

# In the wilderness, what did God command the Israelites to build, which they later carried into the land?

In the wilderness, the Israelites built the tabernacle of the testimony. 

# Who drove out the nations ahead of the Israelites?

God drove out the nations ahead of the Israelites. 

# Who asked to build a dwelling place for God?

David asked to build a dwelling place for God. 

# Who actually built God a house?

Solomon built God a house. 

# Where does the Most High have his throne?

The Most High has heaven as his throne. 

# What did Stephen accuse the people of always doing, just as their forefathers had done?

Stephen accused the people of resisting the Holy Spirit. 

# What did Stephen say the people were guilty of concerning the Righteous One?

Stephen said the people had betrayed and murdered the Righteous One. 

# How did the council members respond to Stephen's accusations?

The council members were cut to the heart and ground their teeth at Stephen. 

# What did Stephen say he saw as he looked up into heaven?

Stephen said he saw Jesus standing on the right hand of God. 

# What did Stephen say he saw as he looked up into heaven?

Stephen said he saw Jesus standing on the right hand of God. 

# What did the council members then do to Stephen?

The council members rushed upon him, threw him out of the city, and stoned him. 

# What did the council members then do to Stephen?

The council members rushed upon him, threw him out of the city, and stoned him. 

# Where did the witnesses lay down their outer clothes during the stoning of Stephen?

The witnesses laid their outer clothes at the feet of a young man named Saul. 

# What was the last thing Stephen asked for before he died?

Stephen asked God not to hold this sin to the people's responsibility. 

# What did Saul think about Stephen's stoning?

Saul was in agreement with Stephen's death. 

# What began on the day Stephen was stoned?

A great persecution against the church in Jerusalem began on the day Stephen was stoned. 

# What did the believers in Jerusalem do?

The believers in Jerusalem were scattered throughout the regions of Judea and Samaria. 

# Why did the people of Samaria pay attention to what Philip said?

The people paid attention when they saw the signs that Philip did. 

# Why had the people of Samaria paid attention to Simon?

The people had paid attention when they saw his sorceries. 

# Why had the people of Samaria paid attention to Simon?

The people had paid attention when they saw his sorceries. 

# Why had the people of Samaria paid attention to Simon?

The people had paid attention when they saw his sorceries. 

# When Simon heard Philip's message, what did he do?

Simon also believed and was baptized. 

# What happened when Peter and John laid hands on the believers in Samaria?

The believers in Samaria received the Holy Spirit. 

# What offer did Simon make to the apostles?

Simon offered the apostles money in exchange for the power to give the Holy Spirit by the laying on of hands. 

# What offer did Simon make to the apostles?

Simon offered the apostles money in exchange for the power to give the Holy Spirit by the laying on of hands. 

# After Simon made this offer to the apostles, what did Peter say was his spiritual condition?

Peter said that Simon was in the poison of bitterness and the bonds of sin. 

# What did an angel tell Philip to do?

An angel told Philip to go south to the desert road toward Gaza. 

# Who did Philip meet and what was the person doing?

Philip met a eunuch of great authority from Ethiopia who was sitting in his chariot reading the prophet Isaiah. 

# Who did Philip meet and what was the person doing?

Philip met a eunuch of great authority from Ethiopia who was sitting in his chariot reading the prophet Isaiah. 

# What question did Philip ask the man?

Philip asked the man, "Do you understand what you are reading?" 

# What did the man ask Philip to do?

The man asked Philip to come up into the chariot and explain what he was reading. 

# What happens to the person being described in the scripture from Isaiah that was being read?

The person is led as a sheep to the slaughter, but does not open his mouth. 

# What question did the man ask Philip about the scripture he was reading?

The man asked Philip if the prophet was speaking about himself or about some other person. 

# Who did Philip say was the person in the scripture from Isaiah?

Philip explained that the person in the scripture from Isaiah was Jesus. 

# What did Philip then do to the man?

Philip and the eunuch both went into the water and Philip baptized him. 

# What happened to Philip when he came out of the water?

When Philip came out of the water, the Spirit of the Lord took Philip away. 

# What did the eunuch do when he came out of the water?

When the eunuch came out of the water, he went on his way rejoicing. 

# What did Saul ask the high priest in Jerusalem permission to do?

Saul asked for letters so that he could travel to Damascus and bring back bound any who belonged to the Way. 

# What did Saul ask the high priest in Jerusalem permission to do?

Saul asked for letters so that he could travel to Damascus and bring back bound any who belonged to the Way. 

# As Saul neared Damascus, what did he see?

As Saul neared Damascus, he saw a light out of heaven. 

# What did the voice say to Saul?

The voice said, "Saul, Saul, why are you persecuting me". 

# When Saul asked who was speaking to him, what was the answer?

The answer was, "I am Jesus whom you are persecuting". 

# When Saul arose from the ground, what had happened to him?

When Saul arose, he could see nothing. 

# Where did Saul then go and what did he do?

Saul went to Damascus and did not eat or drink for three days. 

# What did the Lord tell Ananias to do?

The Lord told Ananias to go and lay hands on Saul, so that Saul would receive his sight. 

# What did the Lord tell Ananias to do?

The Lord told Ananias to go and lay hands on Saul, so that Saul would receive his sight. 

# What concern did Ananias express to the Lord?

Ananias was concerned because he knew Saul had come to Damascus to arrest everyone who called upon the Lord's name. 

# What concern did Ananias express to the Lord?

Ananias was concerned because he knew Saul had come to Damascus to arrest everyone who called upon the Lord's name. 

# What mission did the Lord say he had for Saul as his chosen instrument?

The Lord said Saul would carry the Lord's name before the Gentiles, kings, and the children of Israel. 

# Did the Lord say Saul's mission would be easy or difficult?

The Lord said that Saul would suffer greatly for the cause of the Lord's name. 

# After Ananias laid hands on Saul, what happened?

After Ananias laid hands on Saul, Saul received his sight, was baptized, and ate. 

# What did Saul immediately begin to do?

Saul immediately began to proclaim Jesus in the synagogues, saying that he is the Son of God. 

# When the Jews finally planned to kill Saul, what did he do?

When the Jews planned to kill him, Saul escaped by being let down through the wall in a basket. 

# When Saul came to Jerusalem, how did the disciples receive him?

In Jerusalem, the disciples were afraid of Saul. 

# Who then brought Saul to the apostles and explained what had happened to Saul in Damascus?

Barnabas brought Saul to the apostles and explained what had happened to Saul in Damascus. 

# What did Saul do in Jerusalem?

Saul spoke boldly in the name of the Lord Jesus. 

# After Saul was sent away to Tarsus, what was the condition of the church in Judea, Galilee, and Samaria?

The church in Judea, Galilee, and Samaria had peace and was built up, growing in numbers. 

# What happened in Lydda that caused everyone there to turn to the Lord?

In Lydda, Peter spoke to a paralyzed man who was healed by Jesus. 

# What happened in Lydda that caused everyone there to turn to the Lord?

In Lydda, Peter spoke to a paralyzed man who was healed by Jesus. 

# What happened in Lydda that caused everyone there to turn to the Lord?

In Lydda, Peter spoke to a paralyzed man who was healed by Jesus. 

# What happened in Joppa that caused many people to believe in the Lord?

Peter prayed for a dead woman named Tabitha, who was raised back to life. 

# What kind of man was Cornelius?

Cornelius was a devout man who feared God, was generous, and was always praying to God. 

# What did the angel say had caused God to be reminded about Cornelius?

The angel said that Cornelius' prayers and gifts to the poor had reminded God about Cornelius. 

# What did the angel tell Cornelius to do?

The angel told Cornelius to send men to Joppa to bring Peter. 

# On the next day, what did Peter see while he was praying and in a trance on the housetop?

Peter saw a large sheet filled with all kinds of animals, things that crawled, and birds. 

# On the next day, what did Peter see while he was praying and in a trance on the housetop?

Peter saw a large sheet filled with all kinds of animals, things that crawled, and birds. 

# As Peter saw the vision, what did a voice say to him?

A voice said to Peter, "Rise, Peter, kill and eat". 

# What was Peter's response to the voice?

Peter refused, saying he had never eaten anything defiled and unclean. 

# What did the voice say to Peter after this?

The voice said, "What God has cleansed, do not call it defiled". 

# What did the Spirit tell Peter to do when the men from Cornelius arrived at the house?

The Spirit told Peter to go down and go with them. 

# What did the men from Cornelius expect Peter to come and do in Cornelius' house?

The men from Cornelius expected Peter to come and give a message in Cornelius' house. 

# What did Peter say when Cornelius bowed down at Peter's feet?

Peter told Cornelius to stand up, for he was only a man. 

# What was Peter doing that was previously not allowed for Jews, and why was he now doing it?

Peter was associating with people from another nation, because God had shown him that he should not call any man defiled or unclean. 

# Who did Peter say is acceptable to God?

Peter said that anyone who fears God and does righteous deeds is acceptable to God. 

# What message about Jesus had the people in Cornelius' house already heard?

The people had already heard that Jesus was anointed by the Holy Spirit and with power, and that he had healed all who were oppressed, for God was with him. 

# What did Peter announce had happened to Jesus after his death, and how did Peter know this?

Peter announced that God had raised up Jesus on the third day, and that Peter had eaten with Jesus after his resurrection. 

# What did Peter announce had happened to Jesus after his death, and how did Peter know this?

Peter announced that God had raised up Jesus on the third day, and that Peter had eaten with Jesus after his resurrection. 

# What did Peter say Jesus had commanded them to preach to the people?

Jesus had commanded them to preach that Jesus had been chosen by God to be the Judge of the living and the dead. 

# What did Peter say everyone would receive who believes in Jesus?

Peter said that everyone who believes in Jesus would receive the forgiveness of sins. 

# What happened to the people who were listening to Peter while Peter was still speaking?

The Holy Spirit fell on all those who were listening to Peter. 

# Why were the believers who belonged to the circumcision group amazed?

The believers who belonged to the circumcision group were amazed because the gift of the Holy Spirit was poured out also on the Gentiles. 

# What were the people doing which demonstrated that the Holy Spirit had fallen on them?

The people were speaking in other languages and praising God which demonstrated that the Holy Spirit had fallen on them. 

# After seeing that the people had received the Holy Spirit, what did Peter command be done with them?

Peter commanded that the people be baptized in the name of Jesus Christ. 

# What news did the apostles and brothers in Judea hear?

The apostles and brothers in Judea heard that the Gentiles had also received the word of God. 

# What criticism against Peter did those of the circumcision group in Jerusalem have?

Those in the circumcision group criticized Peter for eating with the Gentiles. 

# What criticism against Peter did those of the circumcision group in Jerusalem have?

Those in the circumcision group criticized Peter for eating with the Gentiles. 

# What evidence did Peter present to demonstrate that God had accepted the Gentiles?

Peter presented the fact that the Holy Spirit had come upon the Gentiles. 

# What was the conclusion of those in the circumcision group when they heard Peter's explanation?

They praised God and concluded that God had given repentance for life to the Gentiles also. 

# What did most of the believers who were scattered after Stephen's death do?

Most of the scattered believers told the message about Jesus only to Jews. 

# What happened when some of the scattered believers preached the Lord Jesus to Greeks?

When they preached the Lord Jesus to Greeks, a great number believed. 

# What happened when some of the scattered believers preached the Lord Jesus to Greeks?

When they preached the Lord Jesus to Greeks, a great number believed. 

# What did Barnabas from Jerusalem tell the believing Greeks in Antioch?

Barnabas encouraged the Greeks to remain with the Lord with all their heart. 

# What did Barnabas from Jerusalem tell the believing Greeks in Antioch?

Barnabas encouraged the Greeks to remain with the Lord with all their heart. 

# Who spent an entire year at the church in Antioch?

Barnabas and Saul spent an entire year at the church in Antioch. 

# What name did the disciples first receive in Antioch?

The disciples were called Christians first in Antioch. 

# What did Agabus the prophet predict would happen?

Agabus predicted that a great famine would occur over all the world. 

# How did the disciples respond to Agabus' prophecy?

The disciples sent help to the brothers in Judea by the hand of Barnabas and Saul. 

# How did the disciples respond to Agabus' prophecy?

The disciples sent help to the brothers in Judea by the hand of Barnabas and Saul. 

# What did Herod the king do to James the brother of John?

Herod the king killed James the brother of John with the sword. 

# What did Herod the king do to Peter?

Herod arrested and put Peter in prison, intending to bring him to the people after the Passover. 

# What did Herod the king do to Peter?

Herod arrested and put Peter in prison, intending to bring him to the people after the Passover. 

# What was the assembly doing for Peter?

The assembly was earnestly praying for Peter. 

# How did Peter get past the first and second guard and out of the gate of the prison?

Peter followed an angel past the guards, and then the gate opened by itself. 

# How did Peter get past the first and second guard and out of the gate of the prison?

Peter followed an angel past the guards, and then the gate opened by itself. 

# When Peter arrived at the house where the believers were praying, who answered the door and what did she do?

A servant girl Rhoda answered the door and reported that Peter was standing at the door, but she did not open the door. 

# When Peter arrived at the house where the believers were praying, who answered the door and what did she do?

A servant girl Rhoda answered the door and reported that Peter was standing at the door, but she did not open the door. 

# How did the believers first react to her report?

At first they thought Rhoda was insane. 

# After telling the believers what had happened to him, what did Peter tell them to do?

Peter told them to report these things to James and the brothers. 

# What happened to the men that had been guarding Peter?

Herod questioned the guards and then had them put to death. 

# What did the people shout as Herod gave his speech?

The people shouted, "This is the voice of a god, not of a man"! 

# What happened to Herod after his speech, and why?

Because Herod did not give glory to God, an angel struck him and he was eaten by worms and died. 

# What was happening with the word of God during this time?

The word of God grew and multiplied during this time. 

# Who did Barnabas and Saul take with them?

Barnabas and Saul took John Mark with them. 

# What was the assembly in Antioch doing when the Holy Spirit spoke to them?

The assembly in Antioch was worshiping the Lord and fasting when the Holy Spirit spoke to them. 

# What did the Holy Spirit tell them to do?

The Holy Spirit told them to set apart Barnabas and Saul to do the work to which the Spirit was calling them. 

# What did the assembly do after hearing from the Holy Spirit?

The assembly fasted, prayed, laid hands on Barnabas and Saul, and sent them off. 

# When Barnabas and Saul went to Cyprus, who also was with them?

In Cyprus, John Mark was with them as their assistant. 

# Who was Bar-Jesus?

Bar-Jesus was a Jewish false prophet who associated with the proconsul. 

# Who was Bar-Jesus?

Bar-Jesus was a Jewish false prophet who associated with the proconsul. 

# Why did the proconsul summon Barnabas and Saul?

The proconsul summoned Barnabas and Saul because he wanted to hear the word of God. 

# What was another name by which Saul was known?

Saul was also known as Paul. 

# What did Paul say would happen to Bar-Jesus because he tried to turn the proconsul against the faith?

Paul told Bar-Jesus that he would be blind for a time. 

# How did the proconsul react when he saw what happened to Bar-Jesus?

The proconsul believed. 

# What did John Mark do when Paul and his friends set sail to Perga?

John Mark left Paul and his friends and returned to Jerusalem. 

# Where in Antioch of Pisidia was Paul asked to speak?

In Antioch of Pisidia, Paul was asked to speak in the Jewish synagogue. 

# In Paul's speech, who does Paul say God chose in the past?

In Paul's speech, Paul said that God chose Israel. 

# From whom did God bring Israel a Savior?

From King David God brought Israel a Savior. 

# Who did Paul say had prepared the way for the coming Savior?

Paul said that John the Baptist had prepared the way for the coming Savior. 

# Who did Paul say had prepared the way for the coming Savior?

Paul said that John the Baptist had prepared the way for the coming Savior. 

# How did the people and rulers in Jerusalem fulfill the prophets' messages?

The people and rulers in Jerusalem fulfilled the prophets' messages by condemning Jesus to death. 

# Who were now Jesus' witnesses to the people?

The people who saw Jesus after he was raised from the dead were now his witnesses. 

# How had God shown that he had kept his promises made to the Jews?

God showed that he had kept his promises to the Jews by raising up Jesus from the dead. 

# What did God promise to the Holy One in one of the psalms?

God promised that the Holy One would not see decay. 

# What did Paul proclaim for every one who believes in Jesus?

Paul proclaimed the forgiveness of sins for every one who believes in Jesus. 

# What warning did Paul also give his listeners?

Paul warned his listeners not to be like those spoken of in the prophets who hear the announcement of God's work, but do not believe it. 

# What warning did Paul also give his listeners?

Paul warned his listeners not to be like those spoken of in the prophets who hear the announcement of God's work, but do not believe it. 

# In Antioch, who came to hear the word of the Lord on the next Sabbath?

Almost the whole city came to hear the word of the Lord on the next Sabbath. 

# How did the Jews react when they saw the crowds?

The Jews were filled with jealousy and spoke against Paul's message, insulting him. 

# What did Paul say the Jews were doing with the word of God spoken to them?

Paul said that the Jews were pushing away the word of God spoken to them. 

# What was the Gentiles' reaction when they heard that Paul was turning to them?

The Gentiles were glad and praised the word of the Lord. 

# How many of the Gentiles believed?

As many as were appointed to eternal life believed. 

# What did the Jews then do to Paul and Barnabas?

The Jews stirred up a persecution against Paul and Barnabas and threw them out of the city. 

# What did Paul and Barnabas do before they went on to the city of Iconium?

Paul and Barnabas shook off the dust from their feet against those in the city of Antioch who had thrown them out. 

# What did the disbelieving Jews in Iconium do after a multitude believed Paul and Barnabas' preaching?

The disbelieving Jews stirred up the minds of the Gentiles and made them bitter against the brothers. 

# What did the disbelieving Jews in Iconium do after a multitude believed Paul and Barnabas' preaching?

The disbelieving Jews stirred up the minds of the Gentiles and made them bitter against the brothers. 

# How did God give evidence about the message of his grace?

God gave evidence about the message of his grace by granting signs and wonders to be done by the hands of Paul and Barnabas. 

# Why did Paul and Barnabas leave Iconium?

Some Gentiles and Jews attempted to persuade their leaders to mistreat and stone Paul and Barnabas. 

# Why did Paul and Barnabas leave Iconium?

Some Gentiles and Jews attempted to persuade their leaders to mistreat and stone Paul and Barnabas. 

# Why did Paul and Barnabas leave Iconium?

Some Gentiles and Jews attempted to persuade their leaders to mistreat and stone Paul and Barnabas. 

# What did Paul do that caused an uproar in Lystra?

Paul healed a man who was a cripple from birth. 

# What did Paul do that caused an uproar in Lystra?

Paul healed a man who was a cripple from birth. 

# What did Paul do that caused an uproar in Lystra?

Paul healed a man who was a cripple from birth. 

# What did the people of Lystra want to do for Paul and Barnabas?

The people wanted to offer sacrifices through the priest of Zeus to Paul and Barnabas. 

# What did the people of Lystra want to do for Paul and Barnabas?

The people wanted to offer sacrifices through the priest of Zeus to Paul and Barnabas. 

# What did the people of Lystra want to do for Paul and Barnabas?

The people wanted to offer sacrifices through the priest of Zeus to Paul and Barnabas. 

# How did Barnabas and Paul respond to what the people wanted to do for them?

Barnabas and Paul tore their clothing, went into the crowd, and cried out saying that the people should turn from these useless things to a living God. 

# How did Barnabas and Paul respond to what the people wanted to do for them?

Barnabas and Paul tore their clothing, went into the crowd, and cried out saying that the people should turn from these useless things to a living God. 

# How had God not left himself without witness in the past?

God had given the nations rain and fruitful seasons, filling their hearts with food and gladness. 

# What did the people of Lystra want to do for Paul and Barnabas?

The people wanted to offer sacrifices through the priest of Zeus to Paul and Barnabas. 

# What did the crowds at Lystra later do to Paul?

The crowds at Lystra later stoned Paul and dragged him out of the city. 

# What did Paul do as the disciples were standing around him?

Paul got up and entered the city. 

# Through what did Paul say the disciples must enter into the kingdom of God?

Through many sufferings Paul said the disciples must enter into the kingdom of God. 

# What did Paul and Barnabas do in every assembly of believers before they departed?

In every assembly, Paul and Barnabas appointed elders, prayed with fasting, and entrusted the believers to the Lord. 

# What did Paul and Barnabas do when they returned to Antioch?

When they returned to Antioch, they reported all the things that God had done with them, and how he had opened a door of faith for the Gentiles. 

# What did certain men from Judea come and teach the brothers?

Certain men from Judea taught that unless the brothers were circumcised, they could not be saved. 

# How did the brothers decide this question should be resolved?

The brothers decided that Paul, Barnabas, and certain others should go to Jerusalem to the apostles and elders. 

# Passing through Phoenicia and Samaria, what news did Paul and his companions announce?

Paul and his companions announced the conversion of the Gentiles. 

# Which group among the believers thought that the Gentiles must be circumcised and must keep the law of Moses?

The group of Pharisees believed that the Gentiles must be circumcised and must keep the law of Moses. 

# What did Peter say that God had given to and done for the Gentiles?

Peter said that God had given the Gentiles the Holy Spirit and had made their hearts clean by faith. 

# What did Peter say that God had given to and done for the Gentiles?

Peter said that God had given the Gentiles the Holy Spirit and had made their hearts clean by faith. 

# How did Peter say that both Jews and Gentiles are saved?

Peter said that both Jews and Gentiles are saved through the grace of the Lord Jesus. 

# What did Paul and Barnabas report to the assembly?

Paul and Barnabas reported the signs and wonders God had worked among the Gentiles. 

# What did the prophecy which James quoted say that God would rebuild, and who would it include?

The prophecy said that God would rebuild the fallen tent of David, and that it would include the Gentiles. 

# What did the prophecy which James quoted say that God would rebuild, and who would it include?

The prophecy said that God would rebuild the fallen tent of David, and that it would include the Gentiles. 

# What commands did James suggest be given to the Gentile converts?

James suggested that the Gentile converts be commanded to keep from idols, from fornication, from what is strangled, and from blood. 

# In the letter written to the Gentiles, who is said to be in agreement with the conclusion of giving the Gentiles only a few necessary commands?

The writers of the letter and the Holy Spirit are said to be in agreement with the conclusions. 

# What was the response of the Gentiles when they heard the letter from Jerusalem?

The Gentiles rejoiced because of the encouragement in the letter. 

# What did Paul and Barnabas do as they stayed in Antioch?

Paul and Barnabas taught and preached the word of the Lord. 

# What did Paul tell Barnabas he wanted to do?

Paul told Barnabas that he wanted to return and visit the brothers in every city they had proclaimed the word of the Lord. 

# Why did Paul and Barnabas separate and travel in different directions?

There was a sharp disagreement between them, so that they separated from each other. 

# What did Paul do with Timothy before they traveled together, and why?

Paul circumcised Timothy because the Jews in those parts knew Timothy's father was a Greek. 

# What instructions did Paul deliver to the churches on their way?

Paul delivered the instructions that had been written by the apostles and elders in Jerusalem. 

# How did Paul know God was calling him to preach the gospel in Macedonia?

Paul had a vision of a man of Macedonia calling him to come over and help them. 

# On the Sabbath, why did Paul go to the river outside the gate of Philippi?

Paul thought there would be a place of prayer there. 

# What did the Lord do for Lydia as Paul spoke?

The Lord opened Lydia's heart to pay attention to the things which were spoken by Paul. 

# Who was baptized after Paul spoke by the river?

Lydia and her household were baptized after Paul spoke. 

# How did the young woman with a spirit make money for her masters?

She made money for her masters by fortunetelling. 

# What did Paul do after the young woman had followed him for many days?

Paul turned and commanded the spirit, in the name of Jesus Christ, to come out of her. 

# What did Paul do after the young woman had followed him for many days?

Paul turned and commanded the spirit, in the name of Jesus Christ, to come out of her. 

# What accusation did the young woman's masters bring against Paul and Silas?

They accused Paul and Silas of teaching things that are not lawful for Romans to receive or observe. 

# What punishment did Paul and Silas receive from the magistrates?

They were beaten with rods, thrown into prison, and put in the stocks. 

# What punishment did Paul and Silas receive from the magistrates?

They were beaten with rods, thrown into prison, and put in the stocks. 

# What punishment did Paul and Silas receive from the magistrates?

They were beaten with rods, thrown into prison, and put in the stocks. 

# What were Paul and Silas doing around midnight in the prison?

They were praying and singing hymns to God. 

# What happened that caused the jailer to prepare to kill himself?

There was an earthquake, all the prison doors were opened, and everyone's chains were unfastened. 

# What question did the jailer ask Paul and Silas?

The jailer asked Paul and Silas, "Sirs, what must I do to be saved"? 

# What answer did Paul and Silas give the jailer?

Paul and Silas answered, "Believe on the Lord Jesus, and you shall be saved, you and your house". 

# Who was baptized that night?

The jailer and all his household were baptized that night. 

# What caused the magistrates to be afraid after they sent word to let Paul and Silas go?

The magistrates were afraid because they realized that they had publicly beaten two uncondemned Roman citizens. 

# What caused the magistrates to be afraid after they sent word to let Paul and Silas go?

The magistrates were afraid because they realized that they had publicly beaten two uncondemned Roman citizens. 

# After the magistrates asked them to leave the city, what did Paul and Silas do?

Paul and Silas went to the house of Lydia, encouraged the brothers, and then departed from Philippi. 

# Arriving in Thessalonica, where did Paul go first to speak from the Scriptures about Jesus?

Paul went to the synagogue of the Jews first to speak from the Scriptures about Jesus. 

# Arriving in Thessalonica, where did Paul go first to speak from the Scriptures about Jesus?

Paul went to the synagogue of the Jews first to speak from the Scriptures about Jesus. 

# What did Paul show was necessary from the Scriptures?

Paul showed it was necessary for the Christ to suffer and to rise again from the dead. 

# What accusation was made against Paul and Silas to the city officials?

Paul and Silas were accused of acting against the decrees of Caesar, saying that there was another king—Jesus. 

# Where did Paul and Silas go when they arrived in Berea?

Paul and Silas went into the synagogue of the Jews. 

# What did the Bereans do when they heard Paul's message?

The Bereans received the word and examined the Scriptures to see if what Paul said was so. 

# Why did Paul have to leave Berea, and where did he go?

Paul had leave Berea because the Jews of Thessalonica stirred up the crowds in Berea, so Paul went to Athens. 

# Why did Paul have to leave Berea, and where did he go?

Paul had leave Berea because the Jews of Thessalonica stirred up the crowds in Berea, so Paul went to Athens. 

# Why did Paul have to leave Berea, and where did he go?

Paul had leave Berea because the Jews of Thessalonica stirred up the crowds in Berea, so Paul went to Athens. 

# Where did Paul go when he arrived in Athens?

Paul went to the Jewish synagogue and the marketplace to reason from the Scriptures. 

# Where was Paul brought to explain his teaching further?

Paul was brought to the Areopagus to explain his teaching further. 

# Where was Paul brought to explain his teaching further?

Paul was brought to the Areopagus to explain his teaching further. 

# Which altar in Athens did Paul find, which he wanted to explain to the people?

Paul found an altar with the inscription, TO AN UNKNOWN GOD, which he wanted to explain to the people. 

# What did Paul say the God who made everything gives to people?

Paul said the God who made everything gives people life and breath and everything else. 

# From what did God make every nation of people?

From one man God made every nation of people. 

# How far did Paul say God was from anyone?

Paul said that God was not far from anyone. 

# How did Paul say we should not think of God?

Paul said that we should not think of God like gold, silver, or stones, sculptured by man. 

# What does God now call all men everywhere to do?

God now calls all men everywhere to repent. 

# For what has God set a certain day?

God has set a certain day when Jesus will judge the world in righteousness. 

# What proof has God given that Jesus has been chosen as the judge of the world?

God has proven that Jesus has been chosen as the judge of the world by raising him from the dead. 

# What did some do when they heard Paul speak about the resurrection of the dead?

Some mocked Paul when they heard him speak about the resurrection of the dead. 

# Did any believe what Paul had said?

Yes, certain men believed Paul, and others with them. 

# What work did Paul do to support himself?

Paul worked as a tentmaker to support himself. 

# What did Paul testify to the Jews in Corinth?

Paul testified to the Jews that Jesus was the Christ. 

# When the Jews rejected Paul, what did he do?

Paul told the Jews their blood was on their own head, and then he went to the Gentiles. 

# What encouragement did Paul receive from the Lord in Corinth?

The Lord told Paul to continue speaking, for no one would harm him there. 

# What encouragement did Paul receive from the Lord in Corinth?

The Lord told Paul to continue speaking, for no one would harm him there. 

# What accusation did the Jews bring to the governor against Paul?

The Jews accused Paul of teaching people to worship contrary to the law. 

# What accusation did the Jews bring to the governor against Paul?

The Jews accused Paul of teaching people to worship contrary to the law. 

# How did the governor respond to the accusations of the Jews against Paul?

The governor said that he did not wish to be a judge of matters involving the Jewish law. 

# Which husband and wife traveled with Paul to Ephesus?

Aquila and Priscilla traveled with Paul to Ephesus. 

# Which husband and wife traveled with Paul to Ephesus?

Aquila and Priscilla traveled with Paul to Ephesus. 

# What were the first two places Paul went after he left Ephesus?

After he left Ephesus, Paul traveled to Jerusalem and then to Antioch. 

# What teaching did Apollos understand accurately, and in what teaching did he need more instruction?

Apollos understood the things concerning Jesus accurately, but he knew only the baptism of John. 

# What did Priscilla and Aquila do for Apollos?

Priscilla and Aquila became friends with Apollos and explained to him the way of God more accurately. 

# What was Apollos able to do with his eloquent speech and knowledge of the Scriptures?

Apollos was able to publicly overwhelm the Jews, showing that Jesus was the Christ. 

# What had the disciples that Paul met in Ephesus not heard about when they believed?

The disciples had not heard about the Holy Spirit. 

# John's baptism was a baptism of what?

John's baptism was a baptism of repentance. 

# On whom had John told the people to believe?

John had told the people to believe on the one who would come after him. 

# In what name did Paul then baptize the disciples from Ephesus?

Paul baptized them in the name of the Lord Jesus. 

# What happened to the men after they were baptized and Paul laid hands on them?

The Holy Spirit came on them and they spoke in other languages and prophesied. 

# What did Paul do when some of the Jews in Ephesus began to speak evil of the way of Christ?

Paul withdrew with the believers and began to speak in the lecture hall of Tyrannus. 

# What special miracles did God do by the hands of Paul?

When handkerchiefs and aprons were taken from Paul, they healed the sick and drove out evil spirits. 

# What happened when seven Jewish exorcists tried to cast out an evil spirit in the name of Jesus?

The evil spirit beat up the exorcists and they fled naked and wounded. 

# In Ephesus, what did many who practiced magical arts do?

Many who practiced magical arts in Ephesus burned their books in the sight of everyone. 

# Where did Paul say he would go after he went to Jerusalem?

Paul said he would go to Rome after he went to Jerusalem. 

# What concerns did the silversmith Demetrius express to the other workmen?

Demetrius was concerned that Paul was teaching people that there are no gods that are made with hands, and that the goddess Diana might be considered worthless. 

# How did the people react to Demetrius' concerns?

The people became angry and cried out saying that Diana was great, filling the whole city with confusion. 

# How did the people react to Demetrius' concerns?

The people became angry and cried out saying that Diana was great, filling the whole city with confusion. 

# Why did Paul not address the crowd, even though he wanted to?

The disciples and some local officials did not allow Paul to speak to the crowd. 

# Why did Paul not address the crowd, even though he wanted to?

The disciples and some local officials did not allow Paul to speak to the crowd. 

# What did the town clerk tell the people to do instead of rioting?

The town clerk told the people to bring their accusations to the courts. 

# In what danger did the town clerk say the people were?

The town clerk said that the people were in danger of being accused for being disorderly, and that there was no cause for an explanation. 

# What caused Paul to change his plans and return through Macedonia instead of sailing for Syria?

Paul changed his plans because the Jews had formed a plot against him as he was about to sail for Syria. 

# On what day of the week did Paul and the believers gather to break bread?

On the first day of the week Paul and the believers gathered to break bread. 

# What happened to the young man who fell out of the window while Paul was speaking?

The young man fell from the third story and was picked up dead, but Paul stretched himself out on him and he came back to life. 

# What happened to the young man who fell out of the window while Paul was speaking?

The young man fell from the third story and was picked up dead, but Paul stretched himself out on him and he came back to life. 

# Why was Paul hurrying toward Jerusalem?

Paul was hurrying toward Jerusalem to be there for the day of Pentecost. 

# About what did Paul say he warned both Jews and Greeks since he set foot in Asia?

Paul said he warned both Jews and Greeks about repentance toward God and faith in the Lord Jesus. 

# About what did Paul say he warned both Jews and Greeks since he set foot in Asia?

Paul said he warned both Jews and Greeks about repentance toward God and faith in the Lord Jesus. 

# About what was the Holy Spirit witnessing to Paul in every city as he traveled toward Jerusalem?

The Holy Spirit was witnessing to Paul that chains and sufferings awaited him. 

# What ministry had Paul received from the Lord Jesus?

Paul's ministry was to bear witness to the gospel of the grace of God. 

# Why did Paul say he was innocent of the blood of any man?

Paul said he was innocent of their blood because he had declared to them the whole will of God. 

# What did Paul command the Ephesian elders to do carefully after his departure?

Paul commanded the elders to shepherd the flock carefully. 

# What did Paul say would happen among the Ephesian elders after his departure?

Paul said that some of the elders would say corrupt things in order to draw away disciples after themselves. 

# To whom did Paul entrust the Ephesian elders?

Paul entrusted the Ephesian elders to God. 

# What example did Paul set for the Ephesians regarding work?

Paul worked for his own needs and the needs of those with him, and helped the weak. 

# What example did Paul set for the Ephesians regarding work?

Paul worked for his own needs and the needs of those with him, and helped the weak. 

# What made the Ephesian elders sad most of all?

The Ephesian elders were sad most of all because Paul had said they would never see his face again. 

# What did the disciples in Tyre say to Paul through the Spirit?

The disciples said to Paul through the Spirit that he should not set foot in Jerusalem. 

# What do we know about Philip the preacher's children?

Philip had four virgin daughters that prophesied. 

# What did Agabus the prophet say to Paul?

Agabus told Paul that the Jews in Jerusalem would tie up Paul and hand him over to the Gentiles. 

# What did Paul say when everyone begged him not to go up to Jerusalem?

Paul said that he was ready to be tied up and to die in Jerusalem for the name of the Lord Jesus. 

# With whom did Paul meet when he arrived in Jerusalem?

Paul met with James and all the elders. 

# What accusation was being made by the Jews against Paul?

The Jews were accusing Paul of teaching the Jews who lived among the Gentiles to abandon Moses. 

# Why did James and the elders want Paul to purify himself with the four men who had made a vow?

They wanted everyone to know that Paul as a Jew also lived so as to keep the law. 

# What did James say the Gentiles who believed should do?

James said the Gentiles should keep themselves from things sacrificed to idols, from blood, from what is strangled, and from fornication. 

# What accusations did some Jews from Asia make against Paul in the temple?

The Jews accused Paul of teaching against the law and defiling the temple by bringing Greeks into it. 

# After making these accusations, what did the Jews do to Paul?

The Jews dragged Paul out of the temple and tried to kill him. 

# What did the chief captain of the guard do when he heard that Jerusalem was in an uproar?

The chief captain laid hold on Paul and had him bound with two chains, asking who he was and what he had done. 

# What was the crowd shouting as the soldiers carried Paul into the fortress?

The crowd was shouting, "Away with him!" 

# What request did Paul make to the chief captain?

Paul requested that he be allowed to speak to the people. 

# In what language did Paul speak to the people of Jerusalem?

Paul spoke in Hebrew to the people of Jerusalem. 

# When the crowd heard Paul speaking in Hebrew, what did they do?

When the crowd heard Paul speaking in Hebrew, they became quiet. 

# Where was Paul educated, and who was his teacher?

Paul was educated in Jerusalem, and Gamaliel was his teacher. 

# How had Paul treated those who were following the Way?

Paul had persecuted to death those who were following the Way, and had delivered them into prison. 

# What did the voice from heaven say to Paul as he neared Damascus?

The voice from heaven said, "Saul, Saul, why are you persecuting me?" 

# Who was Paul persecuting?

Paul was persecuting Jesus of Nazareth. 

# Why could Paul no longer see?

Paul could no longer see because of the brightness of the light that he saw as he neared Damascus. 

# How was Paul's sight restored?

A devout man named Ananias came and stood by Paul and said, "Brother Saul, receive your sight". 

# How was Paul's sight restored?

A devout man named Ananias came and stood by Paul and said, "Brother Saul, receive your sight". 

# What did Ananias tell Paul to arise and do, and why?

Ananias told Paul to arise and be baptized to wash away his sins. 

# When Jesus spoke to Paul in the temple, how did he say the Jews would react to Paul's testimony about him?

Jesus said that the Jews would not accept Paul's testimony about him. 

# To whom did Jesus then send Paul?

Jesus sent Paul to the Gentiles. 

# How did the people react when they heard Paul speaking about the Gentiles?

The people shouted and threw off their garments, throwing dust in the air. 

# What question did Paul ask the centurion just before Paul was to be scourged?

Paul asked if it was lawful for him to be scourged as an uncondemned Roman citizen. 

# How had Paul become a Roman citizen?

Paul had been born a Roman citizen. 

# What did the chief captain do when he learned that Paul was a Roman citizen?

The chief captain untied Paul's bonds, and ordered the chief priests and all the council to meet, placing Paul in their midst. 

# Why did the high priest command those who stood by Paul to strike him on the mouth?

The high priest was angry because Paul said he had lived before God in all good conscience. 

# Why did the high priest command those who stood by Paul to strike him on the mouth?

The high priest was angry because Paul said he had lived before God in all good conscience. 

# For what reason did Paul say he was being judged before the council?

Paul said he was being judged because of his confidence in the resurrection. 

# Why did an argument begin in the council when Paul gave his reason for being judged?

An argument began because the Pharisees say there is a resurrection, but the Sadducees say there is no resurrection. 

# Why did an argument begin in the council when Paul gave his reason for being judged?

An argument began because the Pharisees say there is a resurrection, but the Sadducees say there is no resurrection. 

# Why did the chief captain take Paul from the council to the fortress?

The chief captain feared that Paul would be torn to pieces by the council members. 

# What promise did the Lord give Paul the following night?

The Lord told Paul to not fear because he would bear witness in Jerusalem and in Rome. 

# What pact concerning Paul did some Jewish men make?

About forty Jewish men made a pact that they would not eat or drink until they had killed Paul. 

# What pact concerning Paul did some Jewish men make?

About forty Jewish men made a pact that they would not eat or drink until they had killed Paul. 

# What was the plan the forty Jewish men presented to the chief priests and elders?

They asked the chief priests and elders to have Paul brought to the council so they could kill Paul before he arrived. 

# What was the plan the forty Jewish men presented to the chief priests and elders?

They asked the chief priests and elders to have Paul brought to the council so they could kill Paul before he arrived. 

# How did Paul learn about the plan of the forty Jewish men?

Paul's sister's son heard of the plan and told Paul. 

# How did the chief captain respond when he learned the plan of the forty Jewish men?

The chief captain ordered a large guard to take Paul safely to Felix the governor at the third hour of the night. 

# How did the chief captain respond when he learned the plan of the forty Jewish men?

The chief captain ordered a large guard to take Paul safely to Felix the governor at the third hour of the night. 

# In his letter to Felix the governor, what did the chief captain say about the accusations against Paul?

The chief captain said Paul did not deserve death or imprisonment, but that the accusations were about questions concerning Jewish law. 

# When did Felix the governor say he would hear Paul's case?

Felix said he would hear Paul's case when Paul's accusers arrived. 

# Where was Paul kept until his trial?

Paul was kept in Herod's palace until his trial. 

# What accusations did the orator Tertullus bring against Paul?

Tertullus accused Paul of causing the Jews to rebel and desecrating the temple. 

# Of what sect did Tertullus say Paul was a leader?

Tertullus said Paul was a leader of the Nazarene sect. 

# What accusations did the orator Tertullus bring against Paul?

Tertullus accused Paul of causing the Jews to rebel and desecrating the temple. 

# What did Paul say he had done in the temple, synagogues, and city?

Paul said he had not argued with anyone and had not stirred up a crowd. 

# To what did Paul say he was faithful?

Paul said he was faithful to all that is in the law and the writings of the prophets. 

# What hope did Paul share with the Jews accusing him?

They shared the same confidence in God about the coming resurrection of the righteous and unrighteous dead. 

# Why did Paul say he had come to Jerusalem?

Paul said he had come to bring help to his nation and gifts of money. 

# What did Paul say he was doing in the temple when he was found by certain Jews from Asia?

Paul said he was in a purification ceremony when he was found. 

# About what was the governor Felix well informed?

The governnor Felix was well informed about the Way. 

# When did Felix say he would decide Paul's case?

Felix said he would decide Paul's case when Lusias the commander came from Jerusalem. 

# After some days, about what did Paul tell Felix?

Paul told Felix about faith in Christ Jesus, rigtheousness, self-control, and the coming judgment. 

# After some days, about what did Paul tell Felix?

Paul told Felix about faith in Christ Jesus, rigtheousness, self-control, and the coming judgment. 

# How did Felix react after he heard Paul?

Felix became fearful and asked Paul to go away for the present. 

# After two years, why did Felix leave Paul under guard when the new governor came?

Felix left Paul under guard because he wanted to gain favor with the Jews. 

# What favor did the chief priest and the prominent Jews ask of Festus?

They asked Festus to call Paul to Jerusalem so that they could kill Paul along the way. 

# What did Festus tell the chief priest and the prominent Jews to do?

Festus told them to go to Caesarea, where Festus was going, and that they could accuse Paul there. 

# While judging Paul's case in Caesarea, what question did Festus ask Paul?

Festus asked Paul if he wanted to go up to Jerusalem and be judged there. 

# Why did Festus ask Paul this question?

Festus asked Paul this question because he wanted to gain favor with the Jews. 

# What was Paul's response to Festus' question?

Paul said that he stood before the judgment seat of Caesar where he must be judged. 

# What did Festus decide to do with Paul's case?

Festus decided that since Paul had called upon Caesar, then he would go to Caesar. 

# What did Festus say was the legal custom with the Romans regarding people charged with crimes?

Festus said that the Romans gave the accused person an opportunity to face his accusers and to make a defense against the charges. 

# What charges did Festus say the Jews had brought against Paul?

Festus said that the charges involved certain disputes about their religion and about a certain Jesus who was dead, but Paul claimed to be alive. 

# Why did Festus bring Paul to speak before King Agrippa?

Festus wanted King Agrippa to help him write something logical about Paul's case to the Emperor. 

# What did Festus say would be unreasonable for him to do as he sent Paul to the Emperor?

Festus said it would be unreasonable for him to send Paul to the Emperor without stating the charges against him. 

# Why was Paul happy to be able to make his defense before King Agrippa?

Paul was happy to be able to make his defense before King Agrippa because Agrippa was an expert in all the Jewish customs and questions. 

# How did Paul live from his youth in Jerusalem?

Paul lived as a Pharisee, a very strict sect of Judaism. 

# What promise of God does Paul say both he and the Jews are hoping to reach?

Paul says that he and the Jews are hoping to reach the promise of the resurrection. 

# What promise of God does Paul say both he and the Jews are hoping to reach?

Paul says that he and the Jews are hoping to reach the promise of the resurrection. 

# What promise of God does Paul say both he and the Jews are hoping to reach?

Paul says that he and the Jews are hoping to reach the promise of the resurrection. 

# Before his conversion, what was Paul doing against the name of Jesus of Nazareth?

Paul was locking up many saints in prison, was approving when they were killed, and was chasing them to foreign cities. 

# Before his conversion, what was Paul doing against the name of Jesus of Nazareth?

Paul was locking up many saints in prison, was approving when they were killed, and was chasing them to foreign cities. 

# Before his conversion, what was Paul doing against the name of Jesus of Nazareth?

Paul was locking up many saints in prison, was approving when they were killed, and was chasing them to foreign cities. 

# What did Paul see on his way to Damascus?

Paul saw a light from heaven that was brighter than the sun. 

# What did Paul hear on his way to Damascus?

Paul heard a voice saying, "Saul, Saul, why do you persecute me?" 

# Who was speaking to Paul on the way to Damascus?

Jesus was speaking to Paul on the way to Damascus. 

# What did Jesus appoint Paul to be?

Jesus appointed Paul to be a servant and witness to the Gentiles. 

# What did Jesus appoint Paul to be?

Jesus appointed Paul to be a servant and witness to the Gentiles. 

# What did Jesus say he wanted the Gentiles to receive?

Jesus said he wanted the Gentiles to receive the forgiveness of sins and the inheritance from God. 

# What two things does Paul say he preached everywhere he went?

Paul says that he preached that the people should repent and turn to God, doing deeds worthy of repentance. 

# What did the prophets and Moses say would happen?

The prophets and Moses said that the Christ must suffer, be raised from the dead, and proclaim light to the Jewish people and to the Gentiles. 

# What did the prophets and Moses say would happen?

The prophets and Moses said that the Christ must suffer, be raised from the dead, and proclaim light to the Jewish people and to the Gentiles. 

# What did Festus think of Paul after he heard Paul's defense?

Festus thought that Paul was insane. 

# What did Festus think of Paul after he heard Paul's defense?

Festus thought that Paul was insane. 

# What was Paul's desire for King Agrippa?

Paul desired that King Agrippa would become a Christian. 

# What was Paul's desire for King Agrippa?

Paul desired that King Agrippa would become a Christian. 

# What conclusion did Agrippa, Festus, and Bernice reach regarding the accusations against Paul?

They agreed that Paul had done nothing worthy of death or bonds, and that he could have been freed if he had not appealed to Caesar. 

# What conclusion did Agrippa, Festus, and Bernice reach regarding the accusations against Paul?

They agreed that Paul had done nothing worthy of death or bonds, and that he could have been freed if he had not appealed to Caesar. 

# How did the centurion Julius treat Paul at the beginning of the journey to Rome?

Julius treated Paul kindly and allowed him to go to his friends and receive their care. 

# Which island did Paul's ship sail around with difficulty?

The ship sailed around the island of Crete with difficulty. 

# Which island did Paul's ship sail around with difficulty?

The ship sailed around the island of Crete with difficulty. 

# Why did Julius the centurion not follow Paul's warning about the dangers of continuing to sail?

Julius did not follow Paul's warning because he paid more attention to the owner of the ship. 

# Why did Julius the centurion not follow Paul's warning about the dangers of continuing to sail?

Julius did not follow Paul's warning because he paid more attention to the owner of the ship. 

# After a gentle start to the voyage, what wind began to beat down on the ship?

After a gentle start, a wind called The Northeaster began to beat down on the ship. 

# After many days, what hope was abandoned by the crew of the ship?

After many days, the crew abandoned any hope that they should be saved. 

# What message did an angel of God give Paul concerning the people on the voyage?

The angel told Paul that he and all the sailors would survive. 

# What message did an angel of God give Paul concerning the people on the voyage?

The angel told Paul that he and all the sailors would survive. 

# At midnight on the fourteenth night, what did the sailors think was happening to the ship?

The sailors thought the ship was approaching some land. 

# What were the sailors looking for a way to do?

The sailors were looking for a way to abandon the ship. 

# What did Paul tell the centurion and the soldiers about the sailors?

Paul told the centurion and the soldiers that unless the sailors stayed on the ship, the centurion and soldiers could not be saved. 

# When daylight was coming on, what did Paul urge everyone to do?

Paul urged everyone to take some food. 

# How did the crew decide to get the ship to the beach, and what happened?

The crew decided to get the ship to the beach by sailing directly toward the beach, but the bow of the ship became stuck on the ground and the stern began to break up. 

# How did the crew decide to get the ship to the beach, and what happened?

The crew decided to get the ship to the beach by sailing directly toward the beach, but the bow of the ship became stuck on the ground and the stern began to break up. 

# How did the crew decide to get the ship to the beach, and what happened?

The crew decided to get the ship to the beach by sailing directly toward the beach, but the bow of the ship became stuck on the ground and the stern began to break up. 

# What were the soldiers going to do with the prisoners at this time?

The soldiers were going to kill the prisoners so none of them could escape. 

# Why did the centurion stop the plan of the soldiers?

The centurion stopped the plan of the soldiers because he wanted to save Paul. 

# How did all of the people on the ship come safely to land?

Those who could swim jumped overboard first, and the rest followed on planks or other things from the ship. 

# How did the native people on the island of Malta treat Paul and the crew of the ship?

The people treated them with not just ordinary kindness. 

# What did the people think when they saw the viper hanging from Paul's hand?

The people thought that Paul was a murderer who was not being permitted to live by justice. 

# What did the people think when they saw Paul was not killed by the viper?

The people thought that Paul was a god. 

# What happened after Paul healed the father of Publius, the chief man of the island?

The rest of the people on the island who were sick also came and were healed. 

# What happened after Paul healed the father of Publius, the chief man of the island?

The rest of the people on the island who were sick also came and were healed. 

# How long did Paul and the crew remain on the island of Malta?

Paul and the crew remained on the island of Malta for three months. 

# What did Paul do when he saw the brothers from Rome who had come to meet him?

When he saw the brothers, Paul thanked God and took courage. 

# What were Paul's living arrangements in Rome as a prisoner?

Paul was allowed to live by himself with a soldier who was guarding him. 

# For what reason did Paul tell the Jewish leaders in Rome he had been chained?

Paul told the Jewish leaders in Rome he had been chained for the confidence of Israel. 

# What did the Jewish leaders in Rome know about the sect of the Christians?

The Jewish leaders in Rome knew that the sect was spoken against everywhere. 

# When the Jewish leaders came again to Paul at his dwelling place, what did Paul try to do from morning until evening?

Paul tried to persuade them about Jesus, from both the law of Moses and from the prophets. 

# What was the response of the Jewish leaders to Paul's presentation?

Some of the Jewish leaders were convinced, while others did not believe. 

# What did the final scripture quoted by Paul say about the Jewish leaders who did not believe?

The final scripture Paul quoted said that those who did not believe would not understand nor perceive what they heard and saw. 

# Where did Paul say God's message of salvation had been sent, and what would be the response?

Paul said that God's message of salvation had been sent to the Gentiles, and they would listen. 

# What did Paul do while a prisoner in Rome?

Paul preached the kingdom of God and taught about the Lord Jesus Christ with all boldness. 

# Who stopped Paul from preaching and teaching while he was a prisoner in Rome for two years?

No one stopped him. 

