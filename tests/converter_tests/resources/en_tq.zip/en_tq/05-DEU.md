# Where was Moses when he spoke to Israel?

Moses was beyond the Jordan in the wilderness, in the plain of the Jordan river valley. 

# When did Moses speak to the people of Israel, telling them all that Yahweh commanded him?

It was the fortieth year, the first day of the eleventh month, on the first day of the month. 

# To whom had Yahweh sworn to give the land?

Yahweh had sworn to Abraham, Isaac, and Jacob to give the land to them and to their descendants after them. 

# Why did Moses feel he could not carry the people alone?

God had multiplied them, made them as the stars of heaven. 

# Why did Moses feel he could not carry the people alone?

God had multiplied them, made them as the stars of heaven. 

# Who would help Moses carry the loads, burdens, and disputes of the people?

They would take wise understanding men of good repute, tribe by tribe, and make these men heads over them. 

# Who would help Moses carry the loads, burdens, and disputes of the people?

They would take wise understanding men of good repute, tribe by tribe, and make these men heads over them. 

# What did Moses command the judges to do?

He commanded them to hear the disputes between brothers, and the foreigner who is with him. 

# What did Israel travel through as they journeyed from Horeb to the hill country?

They traveled through all the great and terrible wilderness. 

# Why did the people ask Moses to send men ahead of them?

They asked Moses to send men ahead to search out the land and bring back word about how they should attack and about the cities. 

# Who did Moses choose to scout out the land in the hill country?

He chose twelve men, one man for every tribe. 

# What did the men report back about the land?

They said, "It is a good land that Yahweh our God is giving to us." 

# Why did the men say Yahweh brought them out of the land of Egypt?

They said Yahweh hated them and he brought them out of the land of Egypt to destroy them. 

# What did their brothers say about the people of the land?

They said that the people of the land were bigger and taller than the Israelites. 

# What did Moses say was there reason the people did not need to be afraid?

He told them not to be afraid, because Yahweh would go before them and would fight for them like he did in Egypt and in the wilderness. 

# What did Moses say was there reason the people did not need to be afraid?

He told them not to be afraid, because Yahweh would go before them and would fight for them like he did in Egypt and in the wilderness. 

# What did Moses say was there reason the people did not need to be afraid?

He told them not to be afraid, because Yahweh would go before them and would fight for them like he did in Egypt and in the wilderness. 

# What did Yahweh say because he was angry?

He swore and said, "Surely not one of these men of this evil generation will see the good land except Caleb." 

# What did Yahweh say because he was angry?

He swore and said, "Surely not one of these men of this evil generation will see the good land except Caleb." 

# What did Yahweh tell Moses to do for Joshua the son of Nun?

Yahweh told Moses to encourage Joshua for he will lead Israel to inherit the land. 

# Who did Yahweh say will go into the land and possess it?

He said their little children will go in and will possess it. 

# What did the people do when Yahweh told them not to attack the hill country?

They were arrogant and attacked the hill country, and the Amorites came against the men, and chased them like bees. 

# What did the people do when Yahweh told them not to attack the hill country?

They were arrogant and attacked the hill country, and the Amorites came against the men, and chased them like bees. 

# Where did Moses say they took their journey?

They took their journey into the wilderness, by way to the Red Sea. 

# What did Yehweh command the people to be careful not to do?

They were to to be careful not to fight the descendants of Esau, for Yahweh would not give them any of their land. 

# What did Yehweh command the people to be careful not to do?

They were to to be careful not to fight the descendants of Esau, for Yahweh would not give them any of their land. 

# How were they to get food and water?

They were to buy food and water from the people of Seir so they could eat and drink. 

# What did Yahweh tell them they were not to do in Moab?

They were not to trouble Moab or fight with them because Yahweh was not giving them that land. 

# How long did it take Israel to go from Kadesh Barnes to the brook Zered?

It took them 38 years to go to the brook Zered. 

# What happened to all the men who were fit for fighting?

All the men who were fit for fighting were dead and gone from among the people. 

# To whom had Yahweh given the land of the people of Ammon?

Yahweh had given that land to the descendants of Lot. 

# What will the people of the land do when they hear news about the Israelites?

They will tremble and be in anguish because of the Israelites. 

# What words of peace did Moses send to the King of Hashbon?

Moses asked that he be allowed to pass through the land on the highway, not turning to the right or left. 

# What words of peace did Moses send to the King of Hashbon?

Moses asked that he be allowed to pass through the land on the highway, not turning to the right or left. 

# What did Moses plan to get food and water for the people?

He asked the king of Hashbon to sell him food and water for money so they could eat and drink. 

# What did Moses plan to get food and water for the people?

He asked the king of Hashbon to sell him food and water for money so they could eat and drink. 

# What happened when Sihon came out against Moses?

Yahweh gave him over to Moses and they defeated him, killing him, his sons and all his people. 

# What happened when Sihon came out against Moses?

Yahweh gave him over to Moses and they defeated him, killing him, his sons and all his people. 

# What happened to all the inhabited cities?

Moses took all the king's cities and destroyed them, including women and children; none were left remaining. 

# What did Og, the king of Bashan do to Israel as they approached his land?

On the way to Bashan, the king of Bashan and all his people came and attacked Israel. 

# What did Israel do to the king of Bashan and his people?

They struck the king of Bashan dead until not one of his people remained, and took all his cities. 

# What did Israel do to the king of Bashan and his people?

They struck the king of Bashan dead until not one of his people remained, and took all his cities. 

# What did Israel do with the cattle and the spoils of the cities?

They took for themselves all the cattle and the spoil of the cities. 

# To whom did Moses give the land that they had taken possession?

He gave it to the Reubenites and the Gadites and the half tribe of Manasseh. 

# To whom did Moses give the land that they had taken possession?

He gave it to the Reubenites and the Gadites and the half tribe of Manasseh. 

# What did Moses command the men of war of the the Reubenites and the Gadites and the half tribe of Manasseh to do?

He commanded them to pass over armed before their brothers, the people of Israel. 

# When did Yahweh say the the Reubenites and the Gadites and the half tribe of Manasseh could return to their own property?

Yahweh said they could return after Yahweh gave rest to their brothers, until they also possess their land. 

# What did Moses tell Joshua not to do?

He told Joshua not to fear the enemy because Yahweh would be the one who would fight for him. 

# Where did Moses beg to go and see?

He begged Yahweh to let him go and see the good land beyond Jordan and also Lebanon. 

# How did Yahweh answer Moses' request to go and see the land?

Yahweh was angry with him because of the people and and did not listen to Moses. 

# What did Yahweh do to allow Mosses to see the land?

Yahweh told him to go up to the top of Pisgah and lift his eyes all around him for he would not go over the Jordan. 

# What did Yahweh tell Moses to do for Joshua?

He told Moses to instruct Joshua, encourage and strengthen him, bacause he would go over before the people and will cause them to inherit the land that you see. 

# What did Yahweh tell Moses to do for Joshua?

He told Moses to instruct Joshua, encourage and strengthen him, bacause he would go over before the people and will cause them to inherit the land that you see. 

# What must the people of Israel do so that they may live, and go in and possess the land that Yahweh is giving them?

They must listen and obey the laws that Moses is going to teach them so that they may possess the land. 

# What must the people not do?

They must not add to nor diminish the words that Moses commanded them so they may keep the commandments of Yahweh. 

# What men did Yahweh destroy?

Yahweh destroyed the men that followed Baal Peor. 

# Why should Israel keep the laws that Moses commanded them?

They should keep and do them so that they will have wisdom and understanding in the sight of the peoples. 

# Why should the people pay attention and guard their soul?

They should pay attention and guard their soul so they do not forget what they have seen, but keep those things in their hearts and make them known to their children and their children's children. 

# Why should the people pay attention and guard their soul?

They should pay attention and guard their soul so they do not forget what they have seen, but keep those things in their hearts and make them known to their children and their children's children. 

# What did the people hear out of the middle of the fire on the mountain?

They heard Yahweh's voice out of the middle of the fire, but saw no form. 

# What did the people hear out of the middle of the fire on the mountain?

They heard Yahweh's voice out of the middle of the fire, but saw no form. 

# What was the covenant that Yahweh commanded them to perform and on what was it written?

Yahweh commanded Moses to teach them the Ten Commandments that were written on two tablets of stone. 

# What were the people told not to do?

They were told to not corrupt themselves by making carved figures of any form, including men, women, birds, things that creep, and fish. 

# What were the people told not to do?

They were told to not corrupt themselves by making carved figures of any form, including men, women, birds, things that creep, and fish. 

# What were the people told not to do?

They were told to not corrupt themselves by making carved figures of any form, including men, women, birds, things that creep, and fish. 

# What were the people told not to do?

They were told to not corrupt themselves by making carved figures of any form, including men, women, birds, things that creep, and fish. 

# Why did Moses tell the people to be careful about the sun, moon and stars?

He told them that they should be careful to not be drawn away to worship the heavens, sun, moon, or stars. 

# Why did Yahweh bring the people out of the iron furnace, Egypt?

He brought them out of Egypt to be a people of his own inheritance. 

# What did Yahweh do to Moses because he was angry with Moses?

He would not let Moses go into the good land over Jordan, but Moses must die outside the land. 

# What did Yahweh do to Moses because he was angry with Moses?

He would not let Moses go into the good land over Jordan, but Moses must die outside the land. 

# Why did Yahweh forbidden Israel to make any carved image?

Yahweh their God is a devouring fire, a jealous God. 

# What does Moses say will happen if the people corrupt themselves and do evil in Yahweh's sight?

They will perish from the land over the Jordan, and be completely destroyed. 

# What does Moses say Yahweh will do to the people?

Yahweh will scatter the people and they will be few in number among the nations where they will serve gods made of wood and stone. 

# What does Moses say Yahweh will do to the people?

Yahweh will scatter the people and they will be few in number among the nations where they will serve gods made of wood and stone. 

# When will the people find Yahweh?

They will find him when they search after him with all their heart and all their soul. 

# What will make the people return to Yahweh their God and listen to his voice?

When they are in distress, and when all the things have come on them they will return to Yahweh. 

# What did God do for the people when they were in Egypt?

God took him a nation from the midst of another nation, by trials, signs, wonders, war, a mighty hand, a display of great power, and great terrors. 

# What did Yahweh make happen to the people so they would know he is God?

He made them hear his voice out of the heavens, and on earth he made them see his great fire. 

# What did Yahweh make happen to the people so they would know he is God?

He made them hear his voice out of the heavens, and on earth he made them see his great fire. 

# What did Yahweh do for Israel because he loved their fathers?

He chose their descendants, brought them out of Egypt with his presence and power. He gave them their land after driving out the greater nations. 

# What did Yahweh do for Israel because he loved their fathers?

He chose their descendants, brought them out of Egypt with his presence and power. He gave them their land after driving out the greater nations. 

# Where could a person flee if he killed another person accidently?

He could flee to one of the three cities that Moses had selected on the east side of the Jordan river. 

# Where could a person flee if he killed another person accidently?

He could flee to one of the three cities that Moses had selected on the east side of the Jordan river. 

# What did Moses place before the people of Israel?

He placed the law; covenant decrees, laws, and other decrees that he spoke to them when they came out of Egypt. 

# What did Moses place before the people of Israel?

He placed the law; covenant decrees, laws, and other decrees that he spoke to them when they came out of Egypt. 

# How far did the land of the two kings of the Amorites extend?

This territory went from Aroer, on the edge of the valley of the Arnon, to Mount Sion (or Mount Hermon), and included all of the plain of the Jordan River valley, eastward beyond the Jordan, to the Sea of the Arabah, to the slopes of Mount Pisgah." 

# How far did the land of the two kings of the Amorites extend?

This territory went from Aroer, on the edge of the valley of the Arnon, to Mount Sion (or Mount Hermon), and included all of the plain of the Jordan River valley, eastward beyond the Jordan, to the Sea of the Arabah, to the slopes of Mount Pisgah." 

# With whom did Yahweh make a covenant at Horeb?

Yahweh made a covenant with Israel at Horeb, not with their ancestors, but with the ones alive. 

# With whom did Yahweh make a covenant at Horeb?

Yahweh made a covenant with Israel at Horeb, not with their ancestors, but with the ones alive. 

# Why did Moses stand between Yahweh and the people when Yahweh revealed his word to them?

Because they were afraid of the fire from which God was speaking. 

# Why did Moses stand between Yahweh and the people when Yahweh revealed his word to them?

Because they were afraid of the fire from which God was speaking. 

# Who does Yahweh tell Israel he is?

He said, "I am Yahweh your God, who brought you out of the land of Egypt, out of the house of slavery." 

# What does God tell Israel not make, bow down to, or serve?

They should not make carved figures or any likeness that is in heaven, earth or in the water. 

# How will Yahweh punish the ancestors' wickedness they bow down to or serve idols?

Yahweh will punish the ancestors' wickedness by bringing punishment on their children's children. 

# What will Yahweh do for those who love him and keep his commandments?

He will show covenant faithfulness to them. 

# Who will Yahweh not hold guiltless?

He will not hold guiltless those who take his name in vain. 

# What does Yahweh say about the seventh day?

The seventh day is a Sabbath to Yahweh their God, so they must keep it holy and not do any work. 

# What does Yahweh say about the seventh day?

The seventh day is a Sabbath to Yahweh their God, so they must keep it holy and not do any work. 

# What does Yahweh say about the seventh day?

The seventh day is a Sabbath to Yahweh their God, so they must keep it holy and not do any work. 

# Why does Yahweh command them to keep the Sabbath day?

He wants them to remember that they were a servant in the land of Egypt and that God brought them out by his mighty hand his display of power. 

# What did Yahweh say would happen to the people if they honor their father and mother?

They will live a long time in the land that God gave them and it may go well with them. 

# What were they commanded not to do?

They should not murder, commit adultery, steal, or give false witness against their neighbor. 

# What were they commanded not to do?

They should not murder, commit adultery, steal, or give false witness against their neighbor. 

# What were they commanded not to do?

They should not murder, commit adultery, steal, or give false witness against their neighbor. 

# What were they commanded not to do?

They should not murder, commit adultery, steal, or give false witness against their neighbor. 

# On what did Yahweh write down his words?

He wrote them down on two tablets of stone and gave them to Moses. 

# What did the people say would happen to them if they heard the voice of Yahweh any longer?

The people would be consumed by the great fire and would die. 

# What did the people say they would do when Moses repeated to them the words of Yahweh?

They said they will listen and obey Yahweh's word. 

# How did Yahweh say about the response of the people?

He said he heard the words of the people and they were good. 

# What did Moses say would happen to the people if they kept all Yahweh's statutes and commandments that Moses was commanding them?

If they keep the commandments, they will live, and it will go well with them, so they may prolong their days in the land. 

# What will happen if the Israelites and their children keep all Yahweh's statutes and commandments all the days of your lives?

If they keep his statutes and commandments, their days will be prolonged. 

# How did Moses describe the land into which the people were going?

He said that it was a land flowing with milk and honey. 

# With what should Israel love Yahweh?

They should love Yahweh with all their heart, all their soul, and all their might. 

# When should the people diligently teach the commandments that are in their hearts to their children?

They should teach the commandments to their children when they sit in the house, walk on the road, lie down, and when they get up. 

# When should the people diligently teach the commandments that are in their hearts to their children?

They should teach the commandments to their children when they sit in the house, walk on the road, lie down, and when they get up. 

# When should Isreal not forget Yahweh?

They should not forget Yahweh when they eat and are satisfied in the land that Yahweh swore to their fathers. 

# When should Isreal not forget Yahweh?

They should not forget Yahweh when they eat and are satisfied in the land that Yahweh swore to their fathers. 

# When should Isreal not forget Yahweh?

They should not forget Yahweh when they eat and are satisfied in the land that Yahweh swore to their fathers. 

# What will happen to Israel if they serve other gods and cause Yahweh, a jealous God, to be angry?

If Yahweh's anger is kindled against them, he will destroy them from the surface of the earth. 

# What did they do at Massah that they should not repeat?

They tested Yahweh at Massah. 

# How should the people respond when their son asks about the covenant decrees, the statutes, and the other decrees that Yahweh commanded?"

They should tell their sons that they were Pharaoh's slaves when Yahweh brought them out of Egypt and gave them the land that he swore to their fathers. 

# How should the people respond when their son asks about the covenant decrees, the statutes, and the other decrees that Yahweh commanded?"

They should tell their sons that they were Pharaoh's slaves when Yahweh brought them out of Egypt and gave them the land that he swore to their fathers. 

# How should the people respond when their son asks about the covenant decrees, the statutes, and the other decrees that Yahweh commanded?"

They should tell their sons that they were Pharaoh's slaves when Yahweh brought them out of Egypt and gave them the land that he swore to their fathers. 

# How should the people respond when their son asks about the covenant decrees, the statutes, and the other decrees that Yahweh commanded?"

They should tell their sons that they were Pharaoh's slaves when Yahweh brought them out of Egypt and gave them the land that he swore to their fathers. 

# Why should the people fear Yahweh?

They should fear him for their good, so that he might keep them alive. 

# What must the people do to the people of the land that Yahweh is giving them to possess?

They must attack and utterly destroy them. 

# What must the Israelites not do with the people of those nations?

They are not to make covenant wiith them, show them mercy, or arrange any marriages with them for their sons or daughters. 

# What must the Israelites not do with the people of those nations?

They are not to make covenant wiith them, show them mercy, or arrange any marriages with them for their sons or daughters. 

# How should Isreal deal with the people of these nations?

They should break down their altars, dash their sacred stone pillars, cut down their Asherah poles, and burn their cast idols. 

# How did Yahweh keep his oath to the chosen people?

Yahweh kept his oath and redeemed them out of the house of bondage, from Pharaoh's hand. 

# What will happen to those who love Yahweh and keep his commandments?

To those that love him, God will keep his covenants and be faithful for a thousand generations. 

# In what ways will the people be blessed by Yahweh if they keep his decrees?

God will bless them by multiplying them, and the fruit of their ground, grain, wine, oil, and multiply their animals. 

# In what ways will the people be blessed by Yahweh if they keep his decrees?

God will bless them by multiplying them, and the fruit of their ground, grain, wine, oil, and multiply their animals. 

# What will God do to the nations whom Israel fears?

God will bring on them the same great sufferings and other displays of his power that they saw in Egypt. 

# What will God do to the nations whom Israel fears?

God will bring on them the same great sufferings and other displays of his power that they saw in Egypt. 

# What will God do to the nations whom Israel fears?

God will bring on them the same great sufferings and other displays of his power that they saw in Egypt. 

# How long did God send the hornet among them?

God sent the hornet until those who were left and hiding from Israel perished. 

# Why should the people not be frightened among the people?

God, who is great and fearsome, is among the Israelites. 

# Why should the people not be frightened among the people?

God, who is great and fearsome, is among the Israelites. 

# How will God give the people victory over the nations?

God will greatly confuse the nations in battle until they are destroyed. 

# What are they to do to the gods of the nations?

They are to burn the carved figures of the gods. 

# What are they to do to the gods of the nations?

They are to burn the carved figures of the gods. 

# What should the people of Israel call to mind?

They should call to mind how God humbled and tested them for forty years in the wilderness. 

# Why did Yahweh humble, make hungry, and feed the people with manna?

He did these things to make the people know that they could not live by bread alone but rather by everything that proceeds out of the mouth of Yahweh. 

# How did the people survive the forty years in the wilderness?

Their clothing did not grow old on them and their feet did not swell. 

# How did Yahweh correct the Israelites?

As a man corrects his son, so Yahweh corrected them. 

# What is in the good land into which God is bringing them?

The land will be filled with brooks of water, fountains and springs, wheat and barley, vines, fig trees, pomegrantes, olive trees, and honey. 

# What is in the good land into which God is bringing them?

The land will be filled with brooks of water, fountains and springs, wheat and barley, vines, fig trees, pomegrantes, olive trees, and honey. 

# Why will the people bless Yahweh?

They will bless him because of the good land that he has given them. 

# What were the people reminded not to do?

They were reminded not to forget Yahweh and neglect his commandments. 

# Why might the people forget Yahweh who brought them out of Egypt?

When their herds and flocks multiply, and their silver and gold increases, their hear may be lifted up and they might forget Yahweh. 

# Why might the people forget Yahweh who brought them out of Egypt?

When their herds and flocks multiply, and their silver and gold increases, their hear may be lifted up and they might forget Yahweh. 

# How did Yahweh provide water and food in the terrible wilderness for the people of Israel?

Yahweh brought water out of the rock of flint for them and provided manna for them. 

# How did Yahweh provide water and food in the terrible wilderness for the people of Israel?

Yahweh brought water out of the rock of flint for them and provided manna for them. 

# What would cause the people to perish like the nations before them?

They would perish if they forgot where their wealth came from, walk after other gods, and not listen to the voice of Yahweh. 

# What would cause the people to perish like the nations before them?

They would perish if they forgot where their wealth came from, walk after other gods, and not listen to the voice of Yahweh. 

# Where are the people of Israel preparing to go?

Israel is about to cross over the Jordan. 

# What will happen before Israel crosses Jordan?

Yahweh will go before them and will destroy the nations like a devouring fire. 

# What did Moses tell the people not to think in think in their heart after Yahweh thrust their enemies out of the land?

He told Israel not to think it was because of Israel's righteousness that Yahweh gave them possession of the land. 

# What is the reason God driving the nations out before Israel crosses the Jordan?

He is driving them out because of their wickedness, and to keep his word that he swore to Israel's ancestors, Abraham, Isaac, and Jacob. 

# Why was Yahweh angry with the people of Israel?

He was angry enough to destroy them because they provoked him and were rebellious against him. 

# Why was Yahweh angry with the people of Israel?

He was angry enough to destroy them because they provoked him and were rebellious against him. 

# What did Moses eat and drink on the mountain?

He did not eat or drink for forty days and forty nights on the mountain. 

# Why did Yahweh tell Moses to quickly go down from the mountain?

Yahweh told him the people had corrupted themselves by turning away from the path that Yahweh commanded and made themselves an idol. 

# Why did Yahweh say he would blot out Israel and make a mightier nation than they were?

Yahweh said he had seen that they were a stubborn people. 

# Why did Yahweh say he would blot out Israel and make a mightier nation than they were?

Yahweh said he had seen that they were a stubborn people. 

# What had Israel made in their sin?

They had sinned against Yahweh by molding a calf as an idol. 

# What had Israel made in their sin?

They had sinned against Yahweh by molding a calf as an idol. 

# What did Moses do after he saw that the people had done evil in the sight of Yahweh?

He threw the tablets and broke them before their eyes, he laid face down before Yahweh for forty days and nights, and did not eat or drink. 

# What did Moses do after he saw that the people had done evil in the sight of Yahweh?

He threw the tablets and broke them before their eyes, he laid face down before Yahweh for forty days and nights, and did not eat or drink. 

# Why did Moses pray for the people and Aaron?

He prayed because Yahweh was angry and displeased with the people and Aaron, enough to destroy them. 

# Why did Moses pray for the people and Aaron?

He prayed because Yahweh was angry and displeased with the people and Aaron, enough to destroy them. 

# What did Moses do to the calf that the people had made?

Moses burned it, beat it, and ground it very small and threw its dust into the stream that came down from the mountain. 

# How did the people provoke Yahweh to wrath?

They rebelled against the commandment of Yahweh and they did not believe or listen to his voice. 

# How did the people provoke Yahweh to wrath?

They rebelled against the commandment of Yahweh and they did not believe or listen to his voice. 

# How did the people provoke Yahweh to wrath?

They rebelled against the commandment of Yahweh and they did not believe or listen to his voice. 

# What was Moses' prayer as he laid face down for forty days and nights?

He prayed that Yahweh's people and inheritance would not be destroyed. 

# What was Moses' prayer as he laid face down for forty days and nights?

He prayed that Yahweh's people and inheritance would not be destroyed. 

# What did Moses ask Yahweh not to let the people of the land say?

He asks Yahweh not to let the people say that Yahweh brought Israel into the wilderness to kill them because he hated them. 

# What did Moses ask Yahweh not to let the people of the land say?

He asks Yahweh not to let the people say that Yahweh brought Israel into the wilderness to kill them because he hated them. 

# Where did Yahweh tell Moses to place two tablets of stone on which he would write Yahweh's words?

Yahweh told him he to place the two tablets of stone into the chest of wood that Moses would make. 

# What did Yahweh write on the tablets of stone when Moses went up the mountain with them?

Yahweh wrote the Ten Commandments on the tablets like the first writing. 

# Where did Moses put the two tablets when he returned from the mountain?

He put them into the chest that he had made as Yahweh commanded him. 

# What happened to Aaron in Moserah?

Aaron died and was buried in Moserah. 

# What tribe had Yahweh chosen to bear the ark of the testimony and to stand before Yahweh?

Yahweh chose the Tribe of Levi to bear the ark and to stand before him to serve him and to bless people in his name. 

# How long did Moses stay on the mountain this time?

He stayed on the mountain forty days and forty nights, as at the first time. 

# What does Moses say that Yahweh requires of Israel?

Yahweh requires Israel to fear him, walk in all his ways, love him, worship him with all their heart and soul, and to keep his commandments. 

# What does Moses say that Yahweh requires of Israel?

Yahweh requires Israel to fear him, walk in all his ways, love him, worship him with all their heart and soul, and to keep his commandments. 

# Why did Moses tell the people to circumcise?

He told them to circumcise the foreskin of their hearts. 

# Why should Israel love the foreigner?

Israel should love the foreigner because they were foreigners in the land of Egypt. 

# How has God blessed the fathers that went down into Egypt?

They went down into Egypt as seventy people and God multipled them to be as many as the stars of the heavens. 

# What four things of Yahweh does Moses tell the people to always keep?

He tells them to always keep Yahweh's instructions, his statutes, his decrees, and his commandments. 

# Who did not know or see the punishment of Yahweh and the display of his power in Egypt?

The children of the Israelites did not know or did not see Yahweh's punishment or power in Egypt. 

# What did Yahweh use to overwhelm the army of Egypt when they pursued after Israel?

Yahweh made the water of the Red Sea overwhelm the army as they pursued after Israel. 

# What have the eyes of the Israelites seen?

The eyes of the Israelites have seen all the great works that Yahweh did. 

# What will happen to the people if they keep all the commandments?

If they keep all the commandments, they will be strong, go in and possess the land, and their days will be prolonged. 

# What will happen to the people if they keep all the commandments?

If they keep all the commandments, they will be strong, go in and possess the land, and their days will be prolonged. 

# How and why is the promised land different from the land of Egypt?

The land is a land of hills and valleys, and drinks water of the rain of the heavens. 

# What would Yahweh give them if they listen to his commandments, love and serve him with their heart and soul?

Yahweh will give them the former and latter rain, that they may gather their grain, new wine, and oil. 

# What will Yahweh do if the people turn aside and worship other gods?

He will become angry and shut up the heavens so there will not be any rains. 

# When should the people of Israel teach their children the commandments of Yahweh?

They should teach their children the commandments when they sit, and walk, and lie down, and get up. 

# What should the people do so that their days and the days of their children may be multiplied?

They will write the commandments on the doorposts of their house and on their city gates. 

# If the people keep all the commandments of Yahweh and cling to him, what will he do for them?

Yahweh will drive out all the nations before them and they will dispossess larger and mightier nations than themselves. 

# If the people keep all the commandments of Yahweh and cling to him, what will he do for them?

Yahweh will drive out all the nations before them and they will dispossess larger and mightier nations than themselves. 

# Why would no man be able to stand before Israel?

Yahweh will put the fear and terror of Israel upon all that land. 

# What did Moses set before Israel that day?

He set before them a blessing and a curse. 

# Where must the people go in order to possess the land?

They must cross over the Jordan to possess and live in the land. 

# What places did Moses tell Israel to destroy?

They were to destroy all the places where the nations that Israel dispossessed had worshiped their gods. 

# What does Yahweh instruct the people of Israel do to the name of the gods of the nations?

He told Israel to destroy their name out of that place. 

# In what place were the people of Israel to go and bring their burnt offerings, their sacrifices, their tithes, and the offerings.

They were to go to the place that Yahweh their God would choose. 

# What kinds of things were the people of Israel doing?

They were doing whatever was right in their own eyes. 

# What kind of rest will Yahweh give to Israel when they go over the Jordan?

He will give them rest from all their enemies round about, so they will live in safety. 

# What animals can Israel kill and eat?

Israel can kill and eat animals within all their gates. 

# What was Israel not allowed to eat?

Israel was not allowed to eat the blood, but must pour it out on the earth like water. 

# Where was Israel told they could not eat their tithes and sacrifices?

They could not eat them within their gates. 

# Where were the people of Israel to eat their tithes and sacrifices?

They were to eat them before Yahweh their God in the place that he will choose. 

# What was Israel told not to forget?

They were told to not forget the Levite as long as they live in the land of Israel. 

# What can Israel eat when Yahweh their God enlarges their borders as he has promised them?

Israel can eat meat, as their soul desires. 

# What can Israel eat if the place that Yahweh their God chooses to put his name is too far from them?

If the place that Yahweh Israel's God chooses to put his name is too far from Israel, then Israel may kill some of their flock that Yahweh has given them. 

# What is Israel supposed to do with the blood of life?

Israel should not eat the blood of life, but should pour it out on the earth like water. 

# What is Israel supposed to do with the blood of life?

Israel should not eat the blood of life, but should pour it out on the earth like water. 

# What is Israel instructed to take and go to the place that Yahweh chooses?

Israel is to take the consecrated things that they have and the offerings of their vows to the place that Yahweh chooses. 

# Where is Israel to offer their burnt offerings, the meat and the blood, on the altar of Yahweh your God?

Israel is to go to the place that Yahweh chooses to offer their burnt offerings, the meat and the blood,on the altar of Yahweh their God. 

# What is Israel instructed to do so that it may go well with them and with their children after them forever?

Israel is to observe and listen to all the words that Yahweh commands them and do what is good and right in the eyes of Yahweh their God so that it may go well with them and with their children after them forever. 

# What does Yahweh instruct Israel to watch out for when God cuts off the nations before them and when Israel goes in to dispossess them and live in their land?

Israel is to pay attention so that they are not trapped into following or investigating the gods of those nations from before them. 

# What have the other nations done to their sons and daughters in order to worship the gods?

The other nations have even burned their sons and daughters in fire for these other gods. 

# Why should the people of Israel not listen to the words of a prophet or dreamer of dreams who gives a sign or a wonder and says "Let us go after other gods, that you have not known and let us worship them."

The people of Israel should not listen because Yahweh is testing the them to know whether they love him with all their heart and with all their soul. 

# What should the people of Israel do to the prophet or dreamer of dreams who tells them to worship other gods?

They should put to death that prophet or dreamer of dreams. 

# What have the people of Israel been instructed to do to anyone who secretly entices them and says "Let us go and worship other gods that you have not known?

They must surely kill anyone who entices them to worship other gods. 

# How should the people of Israel kill the person who tries to draw them away from Yahweh their God?

They should stone that person to death with stones. 

# What shall the people of Israel do if they hear anyone say that wicked fellows have gone out from one of their cities and said "Let us go and worship other gods?"

They should make search and investigate it thoroughly, so see if it is true. 

# What should Israel do to a city if they learn it is true that the inhabitants said to go and worship other gods?

They should attack the inhabitants of that city with the edge of the sword and destroy it completely. 

# Why must not happen to the things consigned for destruction?

Those things must not stick to Israel's hand, so that Yahweh will turn from the fierceness of his anger. 

# What does Moses instruct the people of Yahweh not to do?

They are not to cut themselves, nor shave any part of their face for the dead. 

# What are the two characteristics of the animals that the Israelites are allowed to eat?

Israel may eat any animal that parts the hoof and that also chews the cud. 

# Why is the pig not to be eaten?

The pig is unclean for the Israelites because he parts the hoof but does not chew the cud. 

# What are the characteristics of the things from the water that the Israelites are allowed to eat?

They may eat whatever has both fins and scales. 

# Are the Israelites allowed to eat winged swarming things?

All winged, swarming things are unclean for the Israelites and must not be eaten. 

# May the Israelites eat anything that dies of itself?

They may not eat anything that dies of itself, but they may give it to a foreigner. 

# Why could the Israelites not do to a young goat?

They must not boil a young goat in its mother's milk. 

# What are the Israelites to do with all the yield of their seed?

Israelites must surely tithe all the yield of their seed. 

# Where must the Israelites eat the tithe of their grain, of their new wine, and of their oil, and the firstborn of their herd and their flock?

Israel must eat the tithe of their grain, of their new wine, and of their oil, and the firstborn of their herd and their flock in the place that he will choose as his sanctuary. 

# What are the Israelites allowed to do with the tithe if the place that Yahweh will choose as his sanctuary is too far away?

They can convert the offering into money, tie up the money in their hand, and go to the place that Yahweh has chosen if the journey is too long for them so that they can not carry the tithe. 

# What are the Israelites allowed to do with the tithe if the place that Yahweh will choose as his sanctuary is too far away?

They can convert the offering into money, tie up the money in their hand, and go to the place that Yahweh has chosen if the journey is too long for them so that they can not carry the tithe. 

# Who has no inheritance with the Israelites and must not be forsaken?

The Levite who is within their gates has no inheritance and must not be forsaken. 

# What are the Israelites instructed to do at the end of every three years?

At the end of every three years the Israelites are to present all the tithe of their produce in the same year to the Levite, the foreigner, the fatherless, and the widow. 

# What are the Israelites instructed to do at the end of every three years?

At the end of every three years the Israelites are to present all the tithe of their produce in the same year to the Levite, the foreigner, the fatherless, and the widow. 

# What must the Israelites do at the end of every seven years?

At the end of every seven years the Israelites must cancel debts. 

# Why is every debt to be canceled every seven years?

Every creditor will cancel that which he has lent to his neighbor or his brother because Yahweh's cancellation of debt has been proclaimed. 

# From whom can Israelites continue to demand payment at the end of every seven years?

The Israelites can continue to demand payment of a debt from a foreigner. 

# Why will there be no poor among the Israelites?

Yahweh will surely bless them in the land that he gives to Israel as an inheritance to possess. 

# What will happen to the Israelites to demonstrate that Yahweh the God of Israel has blessed them?

Israel will lend to many nations, but will not borrow; Israel will rule over many nations, but the other nations will not rule over Israel. 

# What are the Israelites told to do if there is a poor man among them?

The Israelites are told not to harden their heart nor shut their hand from their poor brother. 

# What should the Israelites be careful to not to do when the seventh year, the year of release is near?

They should not refuse to give to a poor brother at a time when the seventh year, the year of release, is near. 

# What will Yahweh do for the Israelites in return for giving to the poor at a time when the seventh year is near?

Yahweh will bless the Israelites in all their work and everything to which they put their hand. 

# Why is Israel commanded to open their hands to their brother, to the needy and the poor in their land?

the poor will never cease to exist in the land. 

# What are Israelites instructed to give a Hebrew man or a Hebrew woman who is released to go free in the seventh year?

They must provide for them freely out of the flock, out of the threshing floor and out of the wine press just as Yahweh their God has blessed the Israelite. 

# What are the Israelites to remember as they give to the one they set free?

The Israelites are told to remember that they were slaves in the land of Egypt. 

# What is an Israelite to do to a male or female servant who says "I will not go away from you"?

the Israelite is to take an awl and thrust it through the slave's ear to a door, and he or she will be that Israelite's servant forever. 

# What is an Israelite to do to a male or female servant who says "I will not go away from you"?

the Israelite is to take an awl and thrust it through the slave's ear to a door, and he or she will be that Israelite's servant forever. 

# Why should it not seem difficult for the Israelite to let the slave go free?

It should not be difficult because he has served them for six years and given twice the value of a hired person. 

# What must the people of Israel do with the firstborn males in their herd and their flock?

They must eat the firstborn before Yahweh year by year with their household in the place that Yahweh will choose. 

# What must the people of Israel do with the firstborn males in their herd and their flock?

They must eat the firstborn before Yahweh year by year with their household in the place that Yahweh will choose. 

# What are the Israelites to do with the firstborn animal if it is lame or blind or has any blemish whatever?

They must not sacrifice it to Yahweh, but instead they should eat it within their gates. 

# What are the Israelites to do with the blood of the firstborn that is blemished?

They must pour the blood of the firstborn that is blemished on the ground like water. 

# Why are the Israelites to observe the month of Abib and keep the Passover for Yahweh their God?

Yahweh he brought Israel out of Egypt by night in the month of Abib. 

# What will the Israelites do to observe the Passover?

The Israelites will sacrifice some of the flock and the herd in the place that Yahweh will choose as his sanctuary. 

# Why are the Israelites to eat no leavened bread or have yeast among all of their borders for seven days?

They are to eat no leavened bread or have yeast because they came out of the land of Egypt in haste. 

# Why are the Israelites to eat no leavened bread or have yeast among all of their borders for seven days?

They are to eat no leavened bread or have yeast because they came out of the land of Egypt in haste. 

# What are the Israelites to do with any meat that they sacrifice in the evening on the first day?

The Israelites are to get rid of any of the meat that they sacrifice on the evening of the first day so that it does not remain until the morning. 

# Where are the Israelites to sacrifice the Passover?

They are to sacrifice at the place that Yahweh will choose as his sanctuary. 

# When will the sacrifice of the Passover be performed?

The sacrifice of the Passover is to be performed in the evening at the going down of the sun, at the time of year that you came out of Egypt. 

# What are the Israelites supposed to do on the first six days as they celebrate Passover?

The Israelites are to eat unleavened bread for six days. 

# What are the Israelites supposed to do on the seventh day as they celebrate Passover?

On the seventh day, they are to have a solemn assembly and do no work. 

# How do the Israelites determine the start of the Festival of Weeks for Yahweh?

The Israelites will count seven weeks from the time they begin to put the sickle to the standing grain. 

# How do the Israelites determine the start of the Festival of Weeks for Yahweh?

The Israelites will count seven weeks from the time they begin to put the sickle to the standing grain. 

# What contribution do the Israelites give on the Festival of Weeks?

They must give Yahweh a free will offering according as Yahweh has blessed them. 

# What must everyone in Israel, including the foreigners, call to mind during the Festival of Weeks?

They must call to mind when they were slaves in Egypt. 

# What festival are the Israelites instructed to keep for seven days after they have gathered in the harvest from the Israelite's threshing floor and from their wine press?

They are to keep the Festival of Shelters for seven days after they begin have gathered in their harvest. 

# At what the three festivals must all the males of Israel appear before Yahweh at the place that Yahweh chooses?

They must appear before him at the Festival of Unleavened Bread, the Festival of Weeks, and at the Festival of Shelters. 

# What is every male Israelite supposed to give to Yahweh instead of coming empty-handed?

Every male Israelite is to give what he is able to Yahweh. 

# Where are the Israelites to find their judges and officers?

The judges and officers will be taken from each of their tribes to judge the people with righteous judgement. 

# Why are the judges and officers not to force justice or show partiality by taking a bribe?

A bribe blinds the eyes of the wise and perverts the words of the righteous 

# What do the judges and officers gain by following justice.

They must follow after justice and justice alone, so that they may live and inherit the land that Yahweh is giving them. 

# What are the Israelites not to set up for themselves?

They are not to set up an Ashera, or any sort of pole, or any sacred stone pillar. 

# What are the Israelites not to set up for themselves?

They are not to set up an Ashera, or any sort of pole, or any sacred stone pillar. 

# Why must the Israelites not sacrifice an ox or a sheep with any blemish or anything bad to Yahweh?

It would be disgusting to Yahweh if they sacrificed an animal with a blemish or anything bad. 

# What are the Israelites told to do if they hear that a man or woman within their cities have done what is evil in the sight of Yahweh?

The Israelites are to make careful investigation to know if this is true and certain. 

# What are the Israelites to do with a man or woman who has done such a wicked thing as worshiping other gods and bowing down to them?

The Israelites are to stone them to death. 

# How many witnesses are needed to convict a person to death?

Two or three witnesses are needed to to convict a person to death. 

# Who must throw the first stones when putting a person to death?

The hand of the witnesses must be the first to throw the stones, followed by the rest of the people of Israel. 

# Why must the Israelites stone the person to death who has done this wicked thing of worshiping other gods?

This will remove the evil from among them. 

# Who is to judge if the Israelites have a matter that is too hard for them to judge?

They must go to the priests and Levites and to the judge who is serving at that time to seek the advice of the priests. 

# What man must die in order to put away the evil from Israel?

Anyone who acts arrogantly and does not listen to the priest, or does not listen to the judge, must die to put away the evil from Israel. 

# Who will the Israelites set up as a king over them at the time when they are in the land?

Israelites will select from among their brothers someone who Yahweh will choose. 

# Why must the king of Israel not multiply horses for himself, nor cause the people to return to Egypt so that the king may multiply horses?

He must not to multiply horses or cause the people to return to Egypt because Yahweh has told the Israelites to never return that way again. 

# Why is the king told not to multiply wives for himself?

He is not to multiply wives for himself so that his heart does not turn away from Yahweh. 

# What is the king instructed to keep with him and read all the days of his life, so that he may learn to honor Yahweh his God, and keep and observe all the words of this law and these statutes?

He must write for himself a copy of this law which is to stay will him and be read by him all the days of his life. 

# What is the king instructed to keep with him and read all the days of his life, so that he may learn to honor Yahweh his God, and keep and observe all the words of this law and these statutes?

He must write for himself a copy of this law which is to stay will him and be read by him all the days of his life. 

# Why is the king instructed to keep the scroll of the law with him?

He must keep the scroll with him so that his heart is not lifted up above his brothers, and so that he does not turn away from the commandments. 

# Why would the Levite priests have to eat the offerings of Yahweh as their inheritance?

The Levite priests would have to eat the offerings because they would have no inheritance among their brothers. 

# Why would the Levite priests have to eat the offerings of Yahweh as their inheritance?

The Levite priests would have to eat the offerings because they would have no inheritance among their brothers. 

# What was to be given to the priests from the sacrifices of the people?

The priests were to be given the shoulder, two cheeks, and inner parts of the oxen and sheep and the first fruits of grain, new wine, oil, and fleece of the sheep from the sacrifices of the people. 

# What was to be given to the priests from the sacrifices of the people?

The priests were to be given the shoulder, two cheeks, and inner parts of the oxen and sheep and the first fruits of grain, new wine, oil, and fleece of the sheep from the sacrifices of the people. 

# Why were the priests supposed to receive these portions from the sacrifices of the people?

They were to receive these portions because Yahweh chose them to stand to serve in the name of Yahweh. 

# When can a Levite serve in the place that Yahweh will choose as his sanctuary?

A Levite can serve in the place that Yahweh will choose as his sanctuary when he comes out of any of the city gates of Israel with the desire of his soul to serve Yahweh. 

# When can a Levite serve in the place that Yahweh will choose as his sanctuary?

A Levite can serve in the place that Yahweh will choose as his sanctuary when he comes out of any of the city gates of Israel with the desire of his soul to serve Yahweh. 

# What were some of the disgusting practices followed by the nations?

Some of the disgusting practices were making their children pass through the fire, using divination, practicing augury, using sorcery and talking with the dead or spirits. 

# What were some of the disgusting practices followed by the nations?

Some of the disgusting practices were making their children pass through the fire, using divination, practicing augury, using sorcery and talking with the dead or spirits. 

# What were some of the disgusting practices followed by the nations?

Some of the disgusting practices were making their children pass through the fire, using divination, practicing augury, using sorcery and talking with the dead or spirits. 

# Why will Yahweh drive out the nations from the land?

Yahweh will drive out the nations from the land because they listen to those who practice sorcery and divination. 

# Why will Yahweh drive out the nations from the land?

Yahweh will drive out the nations from the land because they listen to those who practice sorcery and divination. 

# Why will Yahweh drive out the nations from the land?

Yahweh will drive out the nations from the land because they listen to those who practice sorcery and divination. 

# Who did Yahweh promise to raise up from among the people?

Yahweh promised he would raise up a prophet like Moses in the future from Israel. 

# What would cause a prophet to die?

A prophet will die if he speaks a word arrogantly in Yahweh's name, a word that Yahweh has not commanded him to speak, or he speaks in the name of other gods. 

# What does it mean if a prophecy spoken in Yahweh's name does not happen?

If a prophecy does not happen, then the prophecy is something that Yahweh has not spoken. 

# Why did Yahweh instruct the people to select three cities in the middle of the land?

He instructed the people to select three cities so that everyone who kills another person could flee there. 

# Why did Yahweh instruct the people to select three cities in the middle of the land?

He instructed the people to select three cities so that everyone who kills another person could flee there. 

# Why did Yahweh instruct the people to select three cities in the middle of the land?

He instructed the people to select three cities so that everyone who kills another person could flee there. 

# What provision does Yahweh make for the person who kills his neighbor unawares, and did not previously hate him?

Yahweh provided three cities of refuge to which the man could flee and live. 

# What provision does Yahweh make for the person who kills his neighbor unawares, and did not previously hate him?

Yahweh provided three cities of refuge to which the man could flee and live. 

# Why should the one who kills another flee to a city of refuge?

He should flee so that the deceased relative does not pursue in anger, catch, and kill him. 

# Why should the one who kills another flee to a city of refuge?

He should flee so that the deceased relative does not pursue in anger, catch, and kill him. 

# What would be the conditions for adding three more cities of refuge?

If Yahweh enlarged their borders, then they must add three more cities of refuge. 

# What would be the conditions for adding three more cities of refuge?

If Yahweh enlarged their borders, then they must add three more cities of refuge. 

# What should happen if a person hates his neighbor, lies in wait for him, mortally wounds him, and then flees to one of the cities of refuge?

The elders of this man's city must bring him back and turn him over to the responsible relative so that he may die as punishment for the blood guilt from Israel. 

# What should happen if a person hates his neighbor, lies in wait for him, mortally wounds him, and then flees to one of the cities of refuge?

The elders of this man's city must bring him back and turn him over to the responsible relative so that he may die as punishment for the blood guilt from Israel. 

# What should happen if a person hates his neighbor, lies in wait for him, mortally wounds him, and then flees to one of the cities of refuge?

The elders of this man's city must bring him back and turn him over to the responsible relative so that he may die as punishment for the blood guilt from Israel. 

# How many witnesses are needed for a matter to be confirmed?

It is necessary for two or three witnesses to speak for a matter to be confirmed. 

# What should be done when controversy exists between two men?

Then both men, the ones between whom the controversy exists, must stand before Yahweh, before the priests and the judges who serve in those days. The judges must make diligent inquiries; see, if the witness is a false witness and has testified falsely against his brother. 

# What should be done when controversy exists between two men?

Then both men, the ones between whom the controversy exists, must stand before Yahweh, before the priests and the judges who serve in those days. The judges must make diligent inquiries; see, if the witness is a false witness and has testified falsely against his brother. 

# What must be done if the testimony of a witness is found to be false?

If the testimony of a witness is found to be false, then they must do to him as he had wished to do to his brother. 

# Why must the people of Israel not be afraid when they march out to battle against their enemies?

The people of Israel must not be afraid because Yahweh their God, who brought them out of the land of Egypt, will be with them. 

# What must happen when the people of Israel draw near to the battle?

The priest must speak to the people and tell them not to be afraid, but Yahweh is with them to fight for them. 

# What must happen when the people of Israel draw near to the battle?

The priest must speak to the people and tell them not to be afraid, but Yahweh is with them to fight for them. 

# What must happen when the people of Israel draw near to the battle?

The priest must speak to the people and tell them not to be afraid, but Yahweh is with them to fight for them. 

# What should a man do if he as built a new house and not yet dedicated it?

He should return to his house so he does not die in battle and another man dedicate it. 

# What should a man do if he is engaged to a woman and not yet married her?

He should return and marry her so he does not die in battle and another man marry her. 

# What will happen if the people in a faraway city accept an offer of peace when Israel attacks it?

All the people in the city must become forced labor and serve Israel. 

# What will happen if the people in a faraway city accept an offer of peace when Israel attacks it?

All the people in the city must become forced labor and serve Israel. 

# What must happen if the city does not accept the offer of peace, but instead makes war against Israel?

Israel must attack it and when Yahweh gives Israel victory they must kill every man in the town. 

# What must happen if the city does not accept the offer of peace, but instead makes war against Israel?

Israel must attack it and when Yahweh gives Israel victory they must kill every man in the town. 

# Why must the people of Israel utterly destroy everything that breathes in the cities of the land which Yahweh will give them as an inheritance?

They must destroy everything so that the people of the land do not teach them to act in any of disgusting ways and sin against Yahweh. 

# Why must the people of Israel utterly destroy everything that breathes in the cities of the land which Yahweh will give them as an inheritance?

They must destroy everything so that the people of the land do not teach them to act in any of disgusting ways and sin against Yahweh. 

# Why must the people of Israel utterly destroy everything that breathes in the cities of the land which Yahweh will give them as an inheritance?

They must destroy everything so that the people of the land do not teach them to act in any of disgusting ways and sin against Yahweh. 

# What should Israel do with the trees in the cities which they have attacked?

Israel should not cut down the trees that are used for food, but they can cut down the trees that are not used for food to build bulwarks against a city. 

# What should Israel do with the trees in the cities which they have attacked?

Israel should not cut down the trees that are used for food, but they can cut down the trees that are not used for food to build bulwarks against a city. 

# What should happen if someone who has been killed is found lying in a field and it is not known who attacked him?

The elders and judges should measure to determine the nearest city to the killed man. 

# What should happen if someone who has been killed is found lying in a field and it is not known who attacked him?

The elders and judges should measure to determine the nearest city to the killed man. 

# How did Yahweh want the people of Israel to respond to the words of his priests?

Yahweh wanted them to accept the advice of his priests as the verdict in every dispute and in cases of assault. 

# What ritual must the elders of the city nearest to the killed man perform so that this bloodshed will be forgiven?

The elders of the city must wash their hands over the heifer whose neck was broken and say, "Our hands have not shed this blood nor have our eyes seen it." 

# What ritual must the elders of the city nearest to the killed man perform so that this bloodshed will be forgiven?

The elders of the city must wash their hands over the heifer whose neck was broken and say, "Our hands have not shed this blood nor have our eyes seen it." 

# What did Moses tell the people of Israel to do when they went out to battle against their enemies and Yahweh gave them victory?

They were told to take their enemies away as captives. 

# How was an Israelite man to respond to the women who were taken captive?

If a man saw a beautiful woman who he wanted to take for his wife, then he was to bring her home where she would shave her head and cut her nails. 

# How was an Israelite man to respond to the women who were taken captive?

If a man saw a beautiful woman who he wanted to take for his wife, then he was to bring her home where she would shave her head and cut her nails. 

# How long was the captive woman allowed to mourn for her mother and father?

She would remain in mourning for her father and mother for a month before she would become the wife of the man. 

# How was an Israelite man to treat a captive that he had taken as a wife if he did not delight in her?

He must let her go rather than sell her for money. 

# If a man has two wives, and he hates the one who has borne him his firstborn son, how must he distribute what he owns to his heirs?

This man must acknowledge the firstborn son of the hated wife by giving him a double portion of all that he possesses. 

# If a man has two wives, and he hates the one who has borne him his firstborn son, how must he distribute what he owns to his heirs?

This man must acknowledge the firstborn son of the hated wife by giving him a double portion of all that he possesses. 

# If a man has two wives, and he hates the one who has borne him his firstborn son, how must he distribute what he owns to his heirs?

This man must acknowledge the firstborn son of the hated wife by giving him a double portion of all that he possesses. 

# Who must a man take his stubborn and rebellious son to if the son will not obey the voice of his father or mother?

The man and his wife must bring the son to the elders at the gate of the city. 

# What must the father and mother of the rebellious son say to the elders of his city?

The father and mother of the rebellious son must tell the elders, "This son of ours is stubborn and rebellious, a glutton and a drunkard and will not obey our voice". 

# Why must the elders of the city respond by stoning the son to death?

They must stone the son to death to eradicate the evil from within them, and cause all Israel to hear of it and fear. 

# What must happen if a man commits a sin worthy of death and is hanged on a tree?

The man's body must not remain all night on the tree, but must be buried the same day so the land will not be defiled. 

# What must happen if a man commits a sin worthy of death and is hanged on a tree?

The man's body must not remain all night on the tree, but must be buried the same day so the land will not be defiled. 

# What did Moses tell the people of Israel to do when they would see an animal of a fellow Israelite go astray?

They must not bring the animal to their own house, but return it to their fellow Israelite. 

# What did Moses tell the people of Israel to do when they would see an animal of a fellow Israelite fallen down in the road?

They must help their fellow Israelite lift it up again. 

# What behavior does Yahweh find disgusting?

Yahweh is disgusted when a woman wears men's clothing or a man puts on women's clothing. 

# What should the people of Israel do if they find a mother in a bird's nest with her young or sitting on the eggs?

They must let the mother go, but the young they may take for themselves. 

# What should the people of Israel do if they find a mother in a bird's nest with her young or sitting on the eggs?

They must let the mother go, but the young they may take for themselves. 

# What was required when an Israelite would build a house?

It was required that he would make a railing for the roof so he would not bring blood on his house if anyone would fall from there. 

# Why were the Israelites instructed to not plant their vineyards with two kinds of seeds?

The Israelites were not to plant with two kinds of seeds so that the whole harvest would not be confiscated by the sanctuary. 

# What must you put on the foul corners of the cloak with which you clothe yourself?

You must make yourself fringes on the four corners of the cloak with which you clothe yourself. 

# What must happen if a man has made a false accusation against his wife?

The elders of the city must punish him by fining him one hundred shekels of silver which would be given to the father of the wife and the man could never send his wife away. 

# What must happen if a man has made a false accusation against his wife?

The elders of the city must punish him by fining him one hundred shekels of silver which would be given to the father of the wife and the man could never send his wife away. 

# What should happen if the proof of the wife's virginity is not found?

If the proof of her virginity is not found, then she must be brought out and stoned to death because she has committed a disgraceful action. 

# What should happen if the proof of the wife's virginity is not found?

If the proof of her virginity is not found, then she must be brought out and stoned to death because she has committed a disgraceful action. 

# What must happen if a man is found lying with a woman married to another man?

Both the man and the woman must be stoned to death to erase the evil. 

# Why are the people of Israel instructed to stone to death both a girl who is a virgin engaged to a man and another man if they are found lying together?

They are instructed to stone both of them because the girl did not cry out when she was in the city and the man humiliated the wife of a fellow Israelite. 

# Why are the people of Israel instructed to stone to death both a girl who is a virgin engaged to a man and another man if they are found lying together?

They are instructed to stone both of them because the girl did not cry out when she was in the city and the man humiliated the wife of a fellow Israelite. 

# What must happen if the man would force the girl to lie with him when they are out in a field?

If this happens out in a field, then the man must die, but nothing must be done to the girl because he found her out in the field and there was no one there to save her. 

# What must happen if the man would force the girl to lie with him when they are out in a field?

If this happens out in a field, then the man must die, but nothing must be done to the girl because he found her out in the field and there was no one there to save her. 

# What must happen if the man would force the girl to lie with him when they are out in a field?

If this happens out in a field, then the man must die, but nothing must be done to the girl because he found her out in the field and there was no one there to save her. 

# What must happen if a man lies with a girl who is a virgin, but who is not engaged and they are discovered?

Then the man must give fiifty shekels of silver to the girl's father and take the girl as his wife rather than sending her away. 

# What must happen if a man lies with a girl who is a virgin, but who is not engaged and they are discovered?

Then the man must give fiifty shekels of silver to the girl's father and take the girl as his wife rather than sending her away. 

# Why must a man not take his father's wife as his own?

A man must not take his father's wife as his own because he would be taking away his father's marriage rights. 

# Who would not be allowed to enter into the assembly of Yahweh?

Any male whose private parts have been crushed or cut off, or the illegitimate child is not allowed to enter into the assembly of Yahweh. 

# Who would not be allowed to enter into the assembly of Yahweh?

Any male whose private parts have been crushed or cut off, or the illegitimate child is not allowed to enter into the assembly of Yahweh. 

# Why must neither an Ammonite nor a Moabite enter into the assembly of Yahweh?

They can enter into the assembly because they did not meet the Israelites with bread and water on the road when they came out of Egypt and they hired Balaam to curse them. 

# Why must neither an Ammonite nor a Moabite enter into the assembly of Yahweh?

They can enter into the assembly because they did not meet the Israelites with bread and water on the road when they came out of Egypt and they hired Balaam to curse them. 

# What evidence showed that Yahweh did not listen to Balaam?

Yahweh turned the curse of Balaam into a blessing for Israel. 

# Why were Edomites and Egyptians allowed to enter into the assembly of Yahweh?

An Edomite was allowed to be in the assembly because he was a fellow Israelite and an Egyptian was allowed in the assembly since Israel was once a foreigner in his land. 

# Why were Edomites and Egyptians allowed to enter into the assembly of Yahweh?

An Edomite was allowed to be in the assembly because he was a fellow Israelite and an Egyptian was allowed in the assembly since Israel was once a foreigner in his land. 

# How could a man in the Israelite army who had become unclean because of what had happened to him at night became clean again so he could come back inside the camp?

He could bathe himself in water in the evening and then be allowed to come back inside the camp. 

# How could a man in the Israelite army who had become unclean because of what had happened to him at night became clean again so he could come back inside the camp?

He could bathe himself in water in the evening and then be allowed to come back inside the camp. 

# How could a man in the Israelite army who had become unclean because of what had happened to him at night became clean again so he could come back inside the camp?

He could bathe himself in water in the evening and then be allowed to come back inside the camp. 

# Why did Yahweh give instructions to the people of Israel about where and how to relieve themselves?

Yahweh was walking in the midst of their camp, so the camp must be holy in order that Yahweh would not see any unclean thing and turn away from them. 

# Why did Yahweh give instructions to the people of Israel about where and how to relieve themselves?

Yahweh was walking in the midst of their camp, so the camp must be holy in order that Yahweh would not see any unclean thing and turn away from them. 

# Why did Yahweh give instructions to the people of Israel about where and how to relieve themselves?

Yahweh was walking in the midst of their camp, so the camp must be holy in order that Yahweh would not see any unclean thing and turn away from them. 

# How were the instructions Yahweh gave about slaves unusual?

A slave who escaped from his master was not to be returned, but allowed to live with them in whatever town he chose. 

# How were the instructions Yahweh gave about slaves unusual?

A slave who escaped from his master was not to be returned, but allowed to live with them in whatever town he chose. 

# Why did Yahweh not allow any prostitutes or sodomites among the Israelites nor allow their wages to be used as a vow in his house?

Yahweh was disgusted with anything connected with the evil behavior of the prostitutes or sodomites. 

# Why did Yahweh not allow any prostitutes or sodomites among the Israelites nor allow their wages to be used as a vow in his house?

Yahweh was disgusted with anything connected with the evil behavior of the prostitutes or sodomites. 

# How was the policy of lending money different when it involved foreigners instead of fellow Israelites?

They were never to lend on interest to their fellow Israelites, but they were allowed to lend on interest to foreigners. 

# How was the policy of lending money different when it involved foreigners instead of fellow Israelites?

They were never to lend on interest to their fellow Israelites, but they were allowed to lend on interest to foreigners. 

# How important was it for an Israelite to fulfill a vow he made to Yahweh?

An Israelite was not to be slow in fulfilling a vow he made to Yahweh, but he was to observe what he freely promised with his mouth so that he would not be sinning against Yahweh. 

# How important was it for an Israelite to fulfill a vow he made to Yahweh?

An Israelite was not to be slow in fulfilling a vow he made to Yahweh, but he was to observe what he freely promised with his mouth so that he would not be sinning against Yahweh. 

# How important was it for an Israelite to fulfill a vow he made to Yahweh?

An Israelite was not to be slow in fulfilling a vow he made to Yahweh, but he was to observe what he freely promised with his mouth so that he would not be sinning against Yahweh. 

# How generous were the instructions from Yahweh about what the Israelites could eat from their neighbor's vineyard and fields?

They could eat their fill of grapes from their neighbor's vineyard as long as they did not put any in containers and they could pluck the ears of grain from their neighbor's field as long as they did not use a sickle. 

# How generous were the instructions from Yahweh about what the Israelites could eat from their neighbor's vineyard and fields?

They could eat their fill of grapes from their neighbor's vineyard as long as they did not put any in containers and they could pluck the ears of grain from their neighbor's field as long as they did not use a sickle. 

# How does Yahweh make it possible for a man to divorce his wife?

If a man has found some unsuitable thing in his wife, he can write her a bill of divorcement, put it in her hand, and send her out of his house where she can go and become another man's wife. 

# How does Yahweh make it possible for a man to divorce his wife?

If a man has found some unsuitable thing in his wife, he can write her a bill of divorcement, put it in her hand, and send her out of his house where she can go and become another man's wife. 

# What does Yahweh not allow if the second husband writes her a bill of divorce and sends her out of the house or if he dies?

Yahweh does not allow for the first husband who sent her away to take her again to be his wife. 

# What does Yahweh not allow if the second husband writes her a bill of divorce and sends her out of the house or if he dies?

Yahweh does not allow for the first husband who sent her away to take her again to be his wife. 

# What are the benefits for a man who has taken a new wife?

He does not have to go to war or be commanded to go on forced duty, but he can stay home for one year to make his new wife happy. 

# Why was no man allowed to take a mill or an upper millstone as a pledge?

No man was allowed to take them, for he would be taking a man's livelihood as a pledge. 

# What are the circumstances when a man would be declared a thief and must die?

A man would be declared a thief who must die if he would kidnap any of his Israelite brothers and treat him as a slave or sell him. 

# What word of caution from Yahweh about leprosy did Moses pass on to the people of Israel?

Moses told the people of Israel to carefully observe and follow every instruction which Yahweh gave to the priests and Levites regarding any plague of leprosy. 

# What word of caution from Yahweh about leprosy did Moses pass on to the people of Israel?

Moses told the people of Israel to carefully observe and follow every instruction which Yahweh gave to the priests and Levites regarding any plague of leprosy. 

# What restrictions were given when a loan was made to a neighbor?

When a loan was made to a neighbor, they were not to go into the house to get the pledge, but stand outside and wait for the man who received the loan to bring out the pledge. 

# What restrictions were given when a loan was made to a neighbor?

When a loan was made to a neighbor, they were not to go into the house to get the pledge, but stand outside and wait for the man who received the loan to bring out the pledge. 

# What must happen if the man who gives the pledge is a poor man?

If the man is a poor man, the man who gives him the loan must not sleep with the pledge in his possession, but restore him the pledge by the time the sun goes down so he may sleep in his cloak. 

# What must happen if the man who gives the pledge is a poor man?

If the man is a poor man, the man who gives him the loan must not sleep with the pledge in his possession, but restore him the pledge by the time the sun goes down so he may sleep in his cloak. 

# What must the people of Israel do to not oppress a hired servant who is poor and needy?

They must give him his wages every day because he is poor and is counting on it. 

# What must the people of Israel do to not oppress a hired servant who is poor and needy?

They must give him his wages every day because he is poor and is counting on it. 

# How did Yahweh make it clear that everyone was responsible for their own sins?

Yahweh told the people of Israel that the parents must not be put to death for the sins of their children and the children must not be put to death for the sins of their parents. 

# Why were the people of Israel reminded about their time of slavery in Egypt and how Yahweh rescued them from there?

They were reminded so they would not force away the justice due the foreigner or the fatherless, nor take the widow's cloak as a pledge. 

# Why were the people of Israel reminded about their time of slavery in Egypt and how Yahweh rescued them from there?

They were reminded so they would not force away the justice due the foreigner or the fatherless, nor take the widow's cloak as a pledge. 

# What were the people of Israel commanded to do when they harvested their field or shook their olive tree?

When the people of Israel harvested their field they were not to go back for a forgotten sheaf in the field or to shake their olive tree a second time, but to leave them for the foreigner, the fatherless, and the widow.  

# What were the people of Israel commanded to do when they harvested their field or shook their olive tree?

When the people of Israel harvested their field they were not to go back for a forgotten sheaf in the field or to shake their olive tree a second time, but to leave them for the foreigner, the fatherless, and the widow.  

# How will a judge resolve a dispute between two men in court?

He will acquit the righteous and condemn the wicked to be beaten in his presence. 

# Why will a judge limit number of blows a wicked man will receive?

He will order number of blows to not exceed forty blows so the wicked will not be humiliated. 

# What safeguard did Yahweh institute so that the name of a man would not perish from Israel?

If a brother died without having a son, his brother must take the dead man's widow as his wife so that the firstborn she bears will succeed in the name of that man's dead brother. 

# What safeguard did Yahweh institute so that the name of a man would not perish from Israel?

If a brother died without having a son, his brother must take the dead man's widow as his wife so that the firstborn she bears will succeed in the name of that man's dead brother. 

# What punishment did Yahweh give to the people of Israel if the man's brother did not wish to take his brother's wife?

The brother's wife will in the presence of the elders take off his sandal, spit in his face, and tell him that this is what is done when a man does not build up his brother's house. 

# What punishment did Yahweh give to the people of Israel if the man's brother did not wish to take his brother's wife?

The brother's wife will in the presence of the elders take off his sandal, spit in his face, and tell him that this is what is done when a man does not build up his brother's house. 

# What would cause a wife to have one of her hands cut off?

If two men were fighting and the wife of one of the men grabs the private part of the other man in an attempt to rescue her husband, then her hand must be cut off. 

# What would cause a wife to have one of her hands cut off?

If two men were fighting and the wife of one of the men grabs the private part of the other man in an attempt to rescue her husband, then her hand must be cut off. 

# What kind of unrighteous act is disgusting to Yahweh?

It is disgusting to Yahweh when a man has a large and a small weight to measure rather than a perfect and just weight. 

# What kind of unrighteous act is disgusting to Yahweh?

It is disgusting to Yahweh when a man has a large and a small weight to measure rather than a perfect and just weight. 

# Why must the people of Israel blot out the remembrance of Amalek from under heaven?

Amalek did not honor God when Amalek met Israel on the road and attacked those who were faint and weary at the rear as they came out of Egypt. 

# Why must the people of Israel blot out the remembrance of Amalek from under heaven?

Amalek did not honor God when Amalek met Israel on the road and attacked those who were faint and weary at the rear as they came out of Egypt. 

# Why must the people of Israel blot out the remembrance of Amalek from under heaven?

Amalek did not honor God when Amalek met Israel on the road and attacked those who were faint and weary at the rear as they came out of Egypt. 

# What must the people of Israel do when they possess the land which Yahweh has given them?

The people of Israel must take some of the first of all the harvest of the land in a basket and go to the place Yahweh has chosen as his sanctuary. 

# What must the people of Israel do when they possess the land which Yahweh has given them?

The people of Israel must take some of the first of all the harvest of the land in a basket and go to the place Yahweh has chosen as his sanctuary. 

# What must the people of Israel say to the priest when they give him the basket?

The people of Israel must say to him, "I acknowledge today to Yahweh that I have come to the land that he swore to give to our ancestors." 

# What must the people of Israel say was their father?

The people of Israel must say their father was a wandering Aramean. 

# How did the Egyptians treat the Israelites when they were in Egypt?

They treated the Israelites badly and afflicted them, making them do the work of slaves. 

# How did Yahweh bring Israel out of Egypt?

He brought them out with a mighty hand, with a display of his power, with great fearsome power, with signs, and with wonders. 

# How did Yahweh bring Israel out of Egypt?

He brought them out with a mighty hand, with a display of his power, with great fearsome power, with signs, and with wonders. 

# What is the purpose for setting down the basket before Yahweh?

The purpose is to worship Yahweh and rejoice in all the good that he has done for Israel, their house, the Levite, and the foreigner among them. 

# What is the purpose for setting down the basket before Yahweh?

The purpose is to worship Yahweh and rejoice in all the good that he has done for Israel, their house, the Levite, and the foreigner among them. 

# What must the people of Israel do after they have finished giving all the tithe from their harvest?

The people of Israel must give it to the Levite, to the foreigner, to the fatherless, and to the widow so they may eat and be filled. 

# What do the people of Israel want Yahweh to do for them?

The people of Israel want Yahweh to look down from heaven and bless them in the land which he has given to them. 

# What is Yahweh commanding the people of Israel to do?

He is commanding the people of Israel to obey his statues and decrees with all their heart and soul. 

# What have the people of Israel acknowledged before Yahweh?

They have acknowledged that Yahweh is their God and that they will walk in his ways, keep his commandments, and listen to his voice. 

# What has Yahweh acknowledged to the people of Israel?

Yahweh has acknowledged that Israel is his own possession and he will set them high above all the other nations in respect to praise, reputation, and honor so they will be a people that is holy to him. 

# What has Yahweh acknowledged to the people of Israel?

Yahweh has acknowledged that Israel is his own possession and he will set them high above all the other nations in respect to praise, reputation, and honor so they will be a people that is holy to him. 

# What did Moses and the elders of Israel command the people of Israel to keep?

Moses and the elders of Israel told the people to keep all the commandments that Moses commanded them that day. 

# What must the people of Israel do after they pass over the Jordan to the land which Yahweh would give them?

They must set up some large stones with plaster and write on them all the words of the law. 

# What must the people of Israel build on Mount Ebal?

The people of Israel must build an altar of stone to Yahweh without using iron tools to offer burned offerings to him. 

# What were the people of Israel to write on the stones they had plastered?

They were to write on the stones very plainly all the words of the law. 

# Why was it important for the people of Israel to hear the voice of Yahweh and obey his commandments that day?

It was important because on that day they became the people of Yahweh. 

# Why was it important for the people of Israel to hear the voice of Yahweh and obey his commandments that day?

It was important because on that day they became the people of Yahweh. 

# Why were six of the tribes of Israel commanded to stand on Mount Gerizim?

Moses told the people that six of the tribes of Israel must stand on Mount Gerizim to bless the people. 

# Why were six of the tribes of Israel commanded to stand on Mount Gerizim?

Moses told the people that six of the tribes of Israel must stand on Mount Gerizim to bless the people. 

# Why were six of the tribes of Israel commanded to stand on Mount Ebal?

Six of the tribes of Israel were commanded to stand on Mount Ebal to pronounce curses. 

# What is one thing that is disgusting to Yahweh?

One thing that is disgusting to Yahweh is a carved or cast figure made by a craftsman who sets it up in secret. 

# Why is a man cursed if he lies with his father's wife?

A man is cursed if he sleeps with his father's wife, because he has taken away his father's rights. 

# What did the Levites say would happen to the man who secretly kills his neighbor or takes a bribe to kill an innocent person?

That the man would be cursed. 

# What did the Levites say would happen to the man who secretly kills his neighbor or takes a bribe to kill an innocent person?

That the man would be cursed. 

# Why did the Levites say a man should confirm the words of this law by obeying them?

A man should obey the words of this law so he would not be cursed. 

# What did the people of Israel have to do in order to be blessed by Yahweh and to be set above all the other nations of the earth?

The people of Israel needed to listen carefully to the voice of Yahweh and keep all his commandments. 

# What did the people of Israel have to do in order to be blessed by Yahweh and to be set above all the other nations of the earth?

The people of Israel needed to listen carefully to the voice of Yahweh and keep all his commandments. 

# What will Yahweh do for the people of Israel if they will obey his commandments?

Yahweh will cause their enemies to be struck down before them. 

# What will Yahweh make the people of Israel become if they will obey his commandments?

He will establish them as a people holy to himself. 

# What will Yahweh open for the people of Israel if they will obey his commandments?

Yahweh will open to them his storehouse of the heavens to give the rain for their land at the right time, and to bless all the work of their hand. 

# What will happen to the people of Israel if they will not listen to the voice of Yahweh and keep all his commandments?

All the curses will come upon them and overtake them. 

# What will the skies and the earth become to the Israelites if they do not obey the commandments?

The skies will be bronze and the earth will be iron. 

# What will happen Israel when they fight their enemies if they do not obey the commandments?

They will be struck down before their enemies, and flee seven ways before them. 

# With what will Yahweh attack the people of Israel if they are disobedient?

He will attack them with boils, ulcers, scurvy, and itch, and also with madness, blindness, and mental confusion. 

# With what will Yahweh attack the people of Israel if they are disobedient?

He will attack them with boils, ulcers, scurvy, and itch, and also with madness, blindness, and mental confusion. 

# What will happen if am Israelite is engaged to a woman, or builds a house or vineyard?

He will not sleep with the woman, or live in the house, or enjoy the fruit of the vineyard. 

# What will happen to the sons and daughters of the Israelites?

Their sons and daughters will be given to other peoples, and they will look for them but not find them. 

# What will the people of Israel become among all the peoples?

They will become a source of horror, a proverb, and a byword, among all the peoples. 

# How will the disobedience of the people of Israel affect the crops which they plant?

They will plant much seed, and vineyards, but they will not enjoy the fruit of their labors because the worms and the locusts will take over. 

# How will the disobedience of the people of Israel affect the crops which they plant?

They will plant much seed, and vineyards, but they will not enjoy the fruit of their labors because the worms and the locusts will take over. 

# How will the foreigner be more important than the people of Israel?

The foreigner will lend to them and become the head while the people of Israel will not be able to lend and become the tail. 

# How will the foreigner be more important than the people of Israel?

The foreigner will lend to them and become the head while the people of Israel will not be able to lend and become the tail. 

# What will happen because the people of Israel did not listen to the voice of Yahweh and keep his commandments?

All the curses will come on them and overtake them until they are destroyed. 

# What will happen because the people of Israel did not listen to the voice of Yahweh and keep his commandments?

All the curses will come on them and overtake them until they are destroyed. 

# Why will the people of Israel serve the enemies of Yahweh?

They will serve the enemies of Yahweh because they did not worship Yahweh with joyfulness and gladness of heart when they were in prosperity. 

# Why will the people of Israel serve the enemies of Yahweh?

They will serve the enemies of Yahweh because they did not worship Yahweh with joyfulness and gladness of heart when they were in prosperity. 

# What did Moses prophesy about the people of Israel?

Yahweh would bring a nation from far away to attack them with no respect for the aged or young, as well as taking all the food from them and their cattle. 

# What did Moses prophesy about the people of Israel?

Yahweh would bring a nation from far away to attack them with no respect for the aged or young, as well as taking all the food from them and their cattle. 

# What did Moses prophesy about the people of Israel?

Yahweh would bring a nation from far away to attack them with no respect for the aged or young, as well as taking all the food from them and their cattle. 

# During the siege of the city what will the man who is tender and delicate among them not give to his brother or his own dear wife or whatever children he has left?

He will not give to any of them the flesh of his own children that he is going to eat. 

# During the siege of the city what will the man who is tender and delicate among them not give to his brother or his own dear wife or whatever children he has left?

He will not give to any of them the flesh of his own children that he is going to eat. 

# During the siege of the city what will a woman do with her own newborn and the children whom she will bear?

During the siege of the city a woman will eat her own newborn and the children whom she will bear. 

# During the siege of the city what will a woman do with her own newborn and the children whom she will bear?

During the siege of the city a woman will eat her own newborn and the children whom she will bear. 

# What will happen if the people of Israel do not honor the name of Yahweh by keeping the words in the book of the law?

They will experience terrible plagues and severe diseases. 

# How many of the few people of Israel will be left after Yahweh punishes them?

They will be few in number and will be scattered from one end of the earth to the other end. 

# Will the people of Israel find rest when they are scattered among the nations?

They will find no ease, and there will be no rest for the bottoms of their feet. 

# With whom did Yahweh make a covenant?

Yahweh made a covenant with Israel in the land of Moab. 

# What previous covenant had Yahweh made with the people of Israel?

Yahweh previously made a covenant with Israel at Horeb. 

# Of what did Moses remind all the people of Israel?

Moses reminded all the people of Israel of everything that Yahweh had done before their eyes in the land of Egypt to Pharaoh, to all his servants, and to all his land. 

# Why did Moses say that the people of Israel needed to be reminded of the great sufferings that their eyes had seen, the signs and those great wonders?

Moses said that until today Yahweh had not given then a heart to know, eyes to see, or ears to hear about those things. 

# Why did Yahweh lead Israel for forty years in the wilderness where their clothes and sandals did wear out and they did not eat any bread or drink any wine or alcoholic drinks?

He did those things so that they might know that he is Yahweh their God. 

# Why did Yahweh lead Israel for forty years in the wilderness where their clothes and sandals did wear out and they did not eat any bread or drink any wine or alcoholic drinks?

He did those things so that they might know that he is Yahweh their God. 

# Why did Israel need to do in order to prosper in everything?

They needed to keep the words of this covenant and do them and so that they might prosper in everything that they did. 

# Before whom were all of the Israelites standing?

All of the Israelites were standing before Yahweh their God. 

# Before whom were all of the Israelites standing?

All of the Israelites were standing before Yahweh their God. 

# Why were the Israelites standing before Yahweh their God?

They were standing before Yahweh in order to enter into the covenant of Yahweh and into the oath that Yahweh was making with them on that day. 

# What did Yahweh want to do for the people of Israel through this covenant?

He wanted to make the people of Israel into a people for himself. 

# What people were included in the covenant and oath that Yahweh was making with Israel that day in Moab?

Everyone standing that day in Moab and also those who were not there with them were included in the covenant and oath that Yahweh was making with Israel. 

# What people were included in the covenant and oath that Yahweh was making with Israel that day in Moab?

Everyone standing that day in Moab and also those who were not there with them were included in the covenant and oath that Yahweh was making with Israel. 

# About what were the people of Israel being reminded again?

They were being reminded how they had lived in the land of Egypt and how they had come through the midst of the nations through which they had passed. 

# Why were the people being reminded of the disgusting things they had seen when they left Egypt?

They were being reminded of the disgusting things they had seen so that there would not be any among them whose heart would turn away from Yahweh, worship the gods of those nations and so that there would not be any root producing gall and wormwood among them. 

# Why were the people being reminded of the disgusting things they had seen when they left Egypt?

They were being reminded of the disgusting things they had seen so that there would not be any among them whose heart would turn away from Yahweh, worship the gods of those nations and so that there would not be any root producing gall and wormwood among them. 

# What should the person who hears the words of the curse not say in his heart?

The person who hears the words of the curse should not say that he will have peace though he walks in the stubbornness of his heart. 

# What would happen to the man who says that he will have peace though he walks in the stubbornness of his heart?

Yahweh will not pardon him, Yahweh's anger and jealousy will smolder against him, all the curses written in the book will come on him and Yahweh will blot out his name from under heaven. 

# What will the generation to come ask when they see the plagues on this land and the diseases with which Yahweh has made it sick?

They will ask why Yahweh did this to this land and what does the heat of this great anger mean. 

# What will the generation to come ask when they see the plagues on this land and the diseases with which Yahweh has made it sick?

They will ask why Yahweh did this to this land and what does the heat of this great anger mean. 

# How will people reply when the generation to come ask why Yahweh did this to the land?

The people will say that it is because they abandoned the covenant of Yahweh and because they went and worshiped other gods and bowed down to them, gods that they had not known and that he had not given to them. 

# How will people reply when the generation to come ask why Yahweh did this to the land?

The people will say that it is because they abandoned the covenant of Yahweh and because they went and worshiped other gods and bowed down to them, gods that they had not known and that he had not given to them. 

# What will the people say was kindled against this land?

The people will say that the anger of Yahweh was kindled against this land. 

# What will the people say that Yahweh will do with those who he has uprooted from their land in anger?

The people will say that Yahweh, in anger, wrath and great fury has thrown them into another land. 

# To whom do the secret matters belong?

The secret matters belong to Yahweh alone. 

# To whom do things that are revealed belong?

the things that are revealed belong forever to the people of Israel and to their descendants so that they may do all the words of the law. 

# What must the people of Israel do so that Yahweh will reverse their captivity and have compassion on them and return and gather them from all the peoples where Yahweh had scattered them?

They must return to Yahweh and obey his voice, follow all that he has commanded them with all their heart and with all their soul. 

# What must the people of Israel do so that Yahweh will reverse their captivity and have compassion on them and return and gather them from all the peoples where Yahweh had scattered them?

They must return to Yahweh and obey his voice, follow all that he has commanded them with all their heart and with all their soul. 

# From where will Yahweh gather Israel's exiled people?

Yahweh will gather Israel's exiled people from the farthest places under the heavens. 

# To what place will Yahweh bring the exiled Israelites?

Yahweh will bring them into the land that their forefathers possessed. 

# Why will Yahweh circumcise the hearts of the Israelites and their descendants?

Yahweh will circumcise their hearts so that they will love Yahweh their God with all their heart and with all of their soul and so that they could live. 

# On whom will Yahweh put the curses that had been on the people of Israel?

Yahweh will put the curses on their enemies and on those who hate the people of Israel and have persecuted them. 

# What will happen when the people of Israel return to Yahweh?

They will obey the voice of Yahweh and will do all his commandments that Moses commanded them. 

# What will Yahweh do when he makes the people of Israel abundant in all the work of their hand, in the fruit of their body, in the fruit of their cattle and in the fruit of their ground, for prosperity?

Yahweh will rejoice over the people of Israel as he rejoiced over their fathers. 

# What do the people of Israel need to do so that Yahweh will rejoice over them?

The people of Israel need to obey the voice of Yahweh their God, keep his commandments and statures that were written in the book of the law and turn to Yahweh with all their heart and all their soul. 

# What does Moses say is not too hard for the people or too far for them to reach?

Moses says that the commandment that he is commanding to the people of Israel is not too hard for them or too far for them to reach. 

# Where is the word located?

The word is very near to you, in your mouth and your heart, so that you may do it. 

# What has Moses placed before the people of Israel?

Moses has placed life and good, death and evil before the people of Israel. 

# What will happen if the people of Israel obey the decrees of Yahweh their God which Moses commanded them?

They will live and multiply and Yahweh will bless them in the land where they were going. 

# What will happen to the people if their heart turns away and they do not listen, but instead their heart is drawn away, and if it bows down to other gods and worships them?

They will surely perish and they will not prolong their days in the land. 

# What will happen to the people if their heart turns away and they do not listen, but instead their heart is drawn away, and if it bows down to other gods and worships them?

They will surely perish and they will not prolong their days in the land. 

# What is Moses asking the people of Israel to choose as he calls heaven and earth to witness?

Moses is asking the people to choose life so that they and their descendants could live. 

# Why should the people choose life?

They should choose life so as to love Yahweh their God, to obey his voice and to cling to him because he is their life and the length of their days. 

# What did Moses tell all Israel about his advancing age?

He told them that he was now one hundred twenty years old and that he could no more go out and come in. 

# What did Moses tell all Israel about his advancing age?

He told them that he was now one hundred twenty years old and that he could no more go out and come in. 

# What did Yahweh tell Moses about going over the Jordan?

He told Moses that he would not be going over Jordan but God would go over Jordan ahead of Moses and would destroy the nations from before Israel. 

# What did Yahweh tell Moses about going over the Jordan?

He told Moses that he would not be going over Jordan but God would go over Jordan ahead of Moses and would destroy the nations from before Israel. 

# Who did Yahweh say would go over Jordan instead of Moses?

Yahweh told Moses that Joshua would go over the Jordan before Israel. 

# What had Yahweh done to Sihon and to Og, the kings of the Amorites?

Yahweh had destroyed them and their land. 

# What does Yahweh say he will do for Israel when they meet the nations in battle?

Yahweh says that he will give Israel victory over them when Israel meets them in battle. 

# What instruction does Moses give to the Israelites?

Moses tells them to be strong, of good courage, not to fear and not to be afraid of the nations because Yahweh will go with them and will not fail or forsake them. 

# What did Moses say to Joshua in the sight of all Israel?

Moses told Joshua to be strong and of good courage for Joshua would go with the people of Israel into the land that Yahweh swore to their ancestors to give to them and Yahweh will cause them to inherit the land. 

# What did Moses tell Joshua that Yahweh would do for him?

Moses told Joshua that Yahweh would go before Joshua, be with him and Yahweh would not fail or abandon Joshua so Joshua should not be afraid or discouraged. 

# To whom did Moses give the law after he wrote it?

Moses gave this law to the priests, the sons of Levi, who carried the ark and he also gave copies of it to all the elders of Israel. 

# How often did Moses command the priests to read the law that Moses gave to them?

Moses commanded the priests to read the law at the end of every seven years, during the Festival of Shelters, in the hearing of all Israel. 

# How often did Moses command the priests to read the law that Moses gave to them?

Moses commanded the priests to read the law at the end of every seven years, during the Festival of Shelters, in the hearing of all Israel. 

# Why did Moses tell the priests to assemble the men, women, little ones and foreigners.

Moses told the priests to assemble all the people so that they could hear and learn, and honor Yahweh their God and keep all the words of the law and so that their children could hear and learn to honor Yahweh. 

# Why did Moses tell the priests to assemble the men, women, little ones and foreigners.

Moses told the priests to assemble all the people so that they could hear and learn, and honor Yahweh their God and keep all the words of the law and so that their children could hear and learn to honor Yahweh. 

# For how long should the priests read the law to the people of Israel?

The priests should read the law to the people for as long as they live in the land that they were going over the Jordan to possess it. 

# Why did Yahweh tell Moses to call Joshua and present themselves in the tent of meeting?

Yahweh told Moses to call Joshua to the tent of meeting because the day was coming when Moses must die. 

# What happen when Moses and Joshua presented themselves in the tent of meeting?

When Moses and Joshua presented themselves in the tent of meeting, Yahweh appeared in the tent in a pillar of cloud which stood over the door of the tent. 

# What happen when Moses and Joshua presented themselves in the tent of meeting?

When Moses and Joshua presented themselves in the tent of meeting, Yahweh appeared in the tent in a pillar of cloud which stood over the door of the tent. 

# How did Yahweh tell Moses the people would act after Moses went to sleep with his fathers?

Yahweh told Moses that the people would rise up, act like prostitutes going after the strange gods of the land and that they would forgot Yahweh and break Yahweh's covenant that he had made with them. 

# What did Yahweh tell Moses he would do when the people forgot Yahweh's covenant?

Yahweh told Moses that on the day the people forsook his covenant, his anger would be kindled against them, he would abandon them, and he would hide his face from them. 

# What did Yahweh tell Moses would happen to the people when Yahweh hid his face from them?

Yahweh told Moses that many disasters and troubles would find the people and he would hide his face from them because they turned to other gods. 

# What did Yahweh tell Moses would happen to the people when Yahweh hid his face from them?

Yahweh told Moses that many disasters and troubles would find the people and he would hide his face from them because they turned to other gods. 

# Why did Yahweh tell Moses to write a song and teach it to the people of Israel and put it in their mouths?

Yahweh told Moses to write a song and teach it to the people so that the song could be a witness for Yahweh against the people of Israel. 

# What did Yahweh tell Moses the people would do when they were in the land that Yahweh swore to give to their ancestors?

Yahweh told Moses the people of Israel would turn to other gods, worship them, despise Yahweh and break his covenant. 

# What did Yahweh tell Moses the song would do when many evils and troubles found the people of Israel?

Yahweh told Moses that the song would testify before Israel as a witness and it would not be forgotten out of the mouths of their descendants. 

# What did Yahweh say he knew about the people even before he brought them into the land that he had sworn?

Yahweh said that he knew the plans that the people were forming today. 

# How long did Moses wait before he wrote the song that Yahweh told him to write?

Moses wrote the song on the same day that Yahweh told him to write it and then he taught it to the people of Israel on that same day. 

# What command did Yahweh give to Joshua, the son of Nun?

Yahweh commanded Joshua to be strong and of good courage. 

# Why did Yahweh command Joshua to be strong and of good courage?

Yahweh told Joshua to be strong and of good courage because Joshua would bring the people of Israel into the land that Yahweh had sworn to them and Yahweh told Joshua that he would be with Joshua. 

# To whom did Moses give the words of the law in a book when he had finished writing?

Moses gave the words of the law to the Levites who carried the ark of the testimony of Yahweh. 

# To whom did Moses give the words of the law in a book when he had finished writing?

Moses gave the words of the law to the Levites who carried the ark of the testimony of Yahweh. 

# What did Moses tell the Levites that they should do with the book of the law when he finished writing it?

Moses told the Levites to take the book of the law and put is by the side of the ark of the testimony of Yahweh their God so that it would be there as a witness against them. 

# What did Moses tell the Levites that they should do with the book of the law when he finished writing it?

Moses told the Levites to take the book of the law and put is by the side of the ark of the testimony of Yahweh their God so that it would be there as a witness against them. 

# What did Moses tell the Levites he knew about them even today, while he was still alive?

Moses told the Levites that he knew about their rebellion and how they had been rebellious against Yahweh. 

# Why does Moses tell the Levites to assemble before him all the elders of their tribes and their officers?

Moses tells the Levites to assemble the elders and officers so that he could speak his words in their ears and call heaven and earth to witness against them. 

# What does Moses say that he knows will happen after his death?

Moses says that after his death the people will utterly corrupt themselves and turn away from the path that Moses had commanded them. 

# What does Moses say will happen when the people turn away from the path that Moses had commanded them?

Moses says that disaster will come on the people in the following days after they turn away from the path that Moses had commanded them. 

# Why does Moses say disaster will come to the people?

Moses says disaster will come because they will do what is evil in the sight of Yahweh, so as to make him angry through the work of their hands. 

# What did Moses sing in the ears of all the assembly of Israel?

Moses sang all the words of the song he had written. 

# What is Moses asking the heavens and the earth to do?

Moses is asking the heavens to give ear and let him speak and he is asking the earth to listen to the words of his mouth. 

# To what does Moses compare his teaching and his speech?

Moses compares his teaching to rain and his speech to dew. 

# To whom name does Moses proclaim and ascribe greatness?

Moses proclaims the name of Yahweh and ascribes greatness to God. 

# Whose works are perfect and paths are just?

The work of the Rock is perfect and his paths are just. 

# Who has no iniquity and is just and upright?

God is faithful, has no iniquity and is just and upright. 

# What does Moses call the people who have acted wickedly against Yahweh?

Moses calls them a wicked and crooked generation and foolish and senseless people. 

# What does Moses call the people who have acted wickedly against Yahweh?

Moses calls them a wicked and crooked generation and foolish and senseless people. 

# Who does Moses say made and established the people of Israel?

Moses says that Yahweh made and established the people of Israel. 

# Of what does Moses say the fathers and elders will be able to remind the Israelites?

Moses says that the fathers and elders will be able to remind the Israelites about the days of ancient times and the years of many ages past. 

# What does Moses say the fathers and elders can tell the people about when the Most High gave the nations their inheritance?

Moses said the the Most High divided all of mankind, and set the boundaries of the peoples according to the number of the sons of Israel. 

# What is Yahweh's portion and who is his apportioned inheritance?

Yahweh's portion is his people and Jacob is his apportioned inheritance. 

# Where did Yahweh find Jacob (his people)?

Yahweh found Jacob (his people) in a desert land. 

# What did Yahweh do for his people?

Yahweh shielded them, cared for them and guarded them as the apple of his eye. 

# To what does Moses compare the way that Yahweh took care of his people?

Moses compares the way that Yahweh took care of his people to an eagle who guards her nest and flutters over her young. 

# Who alone led the people of Israel?

Yahweh alone led the people of Israel. 

# What happened when Jeshurun (Israel) grew fat?

When Jeshurun (Israel) grew fat and satisfied they abandoned and rejected Yahweh and made him jealous by their strange gods and angered him with their detestable idols. 

# What happened when Jeshurun (Israel) grew fat?

When Jeshurun (Israel) grew fat and satisfied they abandoned and rejected Yahweh and made him jealous by their strange gods and angered him with their detestable idols. 

# Who did God's people forget when they continued to rebel?

They forgot the God who gave them birth. 

# Who did God's people forget when they continued to rebel?

They forgot the God who gave them birth. 

# What did Yahweh do because his people provoked him?

Yahweh rejected his people because they provoked him. 

# What did Yahweh do because his people provoked him?

Yahweh rejected his people because they provoked him. 

# Who will Yahweh use to make Israel envious and angry?

Yahweh will make them envious by those who are not a people, and will make them angry by a nation that has no understanding. 

# What did Yahweh say he would heap on Israel?

Yahweh said he would heap disasters on them. 

# What would keep Yahweh from doing all that he threatened to his people?

Yahweh would keep from doing all that he threatened to his people because their enemies would judge mistakenly and say, "Our hand is exalted." 

# Of what was Israel lacking as a nation?

Israel was lacking wisdom and there was no understanding in them. 

# What does Moses want for Israel to consider?

Moses wants Israel to consider their coming fate. 

# How is it that Israel can put their enemies to flight have victory over their enemies?

Israel can have victory because Yahweh has given them victory and the rock of their enemies is not like the Rock of the Israelites. 

# How is it that Israel can put their enemies to flight have victory over their enemies?

Israel can have victory because Yahweh has given them victory and the rock of their enemies is not like the Rock of the Israelites. 

# From where does the vine of the enemy come and what are how are the grapes described?

Their vine comes from Sodom and Gomorrah and their grapes are poisonous and bitter. 

# How is the wine from the grapes of Sodom and Gomorrah described?

The wine is described as the poison of serpents and the venom of a snake. 

# From where does the vine of the enemy come and what are how are the grapes described?

Their vine comes from Sodom and Gomorrah and their grapes are poisonous and bitter. 

# How is the plan of Yahweh kept?

Yahweh's plan is kept by him and sealed up among his treasures. 

# To whom does vengeance and recompense belong?

Vengeance and recompense belongs to Yahweh. 

# How soon may the day of disaster and the things that are to come happen?

Disaster is near and the things to come will hurry to happen. 

# Who will make decisions for his people and have pity on his servants?

Yahweh will decide for his people and he will pity his servants. 

# From whom does help and protection not come for the people of Israel?

Protection and help does not come from the gods, the rock in whom they took refuge and who ate their sacrifices and drank their drink offerings. 

# From whom does help and protection not come for the people of Israel?

Protection and help does not come from the gods, the rock in whom they took refuge and who ate their sacrifices and drank their drink offerings. 

# Who does God say is a god besides him and what does God alone say that he can do?

God says that there is no god besides him and he alone will kill and make alive, wound and heal. 

# What does God, who alone is God promise as he lifts up his hand to heaven?

As he lifts his hand to heaven he promises that as he lives forever, he will act. 

# On whom will God bring justice and render vengeance?

God will bring justice and render vengeance on his enemies and those who hate him. 

# From whom does God say that his arrows be drunk with blood and his sword devour flesh?

God's arrows will be drunk with the blood of the killed and captives and his sword will devour flesh from the heads of the leaders of the enemy? 

# Who will rejoice with God's people when he avenges the blood of his servants and brings vengeance on his enemies?

The nations will rejoice with God's people. 

# For whom will God make atonement for his land?

God will make atonement for his land, for his people. 

# Who sang all the words of this song in the ears of the people?

Moses and Joshua sang this song in the ears of the people. 

# Why are the people of Israel to fix their minds on the words that Moses has witnessed to them?

The people are to fix their minds on Moses' words so they could command their children to keep all the words of this law. 

# Why did Yahweh tell Moses to go up into the mountains opposite Jericho?

Yahweh told Moses to go up to the mountains so that he could look at the land of Canaan which Yahweh was giving to the people of Israel as their possession. 

# Why did Yahweh tell Moses to go up into the mountains opposite Jericho?

Yahweh told Moses to go up to the mountains so that he could look at the land of Canaan which Yahweh was giving to the people of Israel as their possession. 

# What does Yahweh say will happen to Moses on the mountain?

Yahweh says that Moses will die on the mountain as Aaron had died on Mount Hor and was gathered to his people. 

# Why did Yahweh say that Moses was going to die on the mountain?

Moses was going to die on the mountain because he was unfaithful to Yahweh at the waters of Meribah in Kadesh and because Moses did not treat Yahweh with honor and respect among the people of Israel. 

# Why did Yahweh say that Moses was going to die on the mountain?

Moses was going to die on the mountain because he was unfaithful to Yahweh at the waters of Meribah in Kadesh and because Moses did not treat Yahweh with honor and respect among the people of Israel. 

# What did Yahweh say that Moses would see before his death?

Yahweh said that Moses would see the land that Yahweh was giving to the people of Israel but he would not go there. 

# When did Moses give this blessing to the people of Israel?

Moses gave this blessing to the people of Israel before his death. 

# How does Moses describe Yahweh?

Moses describes Yahweh as one who shone out from Mout Paran, came with ten thousands of holy ones, and in his right hand there were flashes of lightning. 

# How does Yahweh feel about the people of Israel?

Yahweh loves the people the people of Israel. 

# How do the holy people of Israel respond to the love of Yahweh?

The holy people of Israel bow down at Yahweh's feet and receive Yahweh's words. 

# What does Moses say about the law that he commanded to the people?

Moses calls the law an inheritance for the assembly of Jacob. 

# What did Yahweh become when the heads of the people and all the tribes of Israel had gathered?

Yahweh became king in Jeshurun (Israel). 

# What did Moses say would happen to Reuben?

Moses said that Reuben would live and not die but his men would be few. 

# What is the blessing that Moses gives to Judah?

Moses asks Yahweh to bless Judah by listening to the voice of Judah, bringing him to his people and fighting for him. 

# What does Moses tell the Levites to do in his blessing to them?

Moses tells the Levites to teach Yahweh's decrees, put incense and burnt offerings on Yahweh's altar, to bless Yahweh and accept the work of his hands and to shatter the loins of those who rise up against Yahweh. 

# What does Moses tell the Levites to do in his blessing to them?

Moses tells the Levites to teach Yahweh's decrees, put incense and burnt offerings on Yahweh's altar, to bless Yahweh and accept the work of his hands and to shatter the loins of those who rise up against Yahweh. 

# What does Moses tell the Levites to do in his blessing to them?

Moses tells the Levites to teach Yahweh's decrees, put incense and burnt offerings on Yahweh's altar, to bless Yahweh and accept the work of his hands and to shatter the loins of those who rise up against Yahweh. 

# What does Moses say about Benjamin's blessing?

Yahweh says that Benjamin is the one loved by Yahweh, Yahweh shields him all day long and he lives between Yahweh's arms. 

# Who was prince over his brothers?

Joseph was prince over his brothers. 

# What will the ten thousands of Ephraim and the thousands of Manasseh do?

They will push the peoples, all of them, to the ends of the earth. 

# From where does Moses say the blessings of Zebulun and Issachar will come?

The blessings of Zebulun and Issachar will come from the mountains, the abundance of the seas and from the sand hidden in the seashore. 

# From where does Moses say the blessings of Zebulun and Issachar will come?

The blessings of Zebulun and Issachar will come from the mountains, the abundance of the seas and from the sand hidden in the seashore. 

# How does Moses say Gad will live as his territory is enlarged?

Gad will live there like a lioness and tear off an arm or a head. 

# What did Gad carry out for Yahweh?

Gad carried out the justice of Yahweh and his decrees with Israel. 

# How did Moses describe Dan?

Moses described Dan as a lion cub that leaps out from Bashan. 

# What land did Moses say Naphtali will take?

Naphtali will take possession of the land to the west and south. 

# What does Moses say about the blessing for Asher?

Moses says that Asher will be more blessed than the other sons, that he might dip his foot in olive oil and that he will be secure for all his day. 

# What does Moses say about the blessing for Asher?

Moses says that Asher will be more blessed than the other sons, that he might dip his foot in olive oil and that he will be secure for all his day. 

# What did Moses say God will do to Jeshurun's (Israel's) enemies?

Moses said God would thrust out Jeshurun's (Israel's) enemies from before them and that God will say, "Destroy!" 

# How will Jacob's descendants live?

Jacob's descendants will live safely and securely in a land of grain and new wine. 

# How does Moses describing Israel?

Moses describes Israel as blessed and a people saved by Yahweh, whose enemies will come trembling to them. 

# From where was Moses shown all the lands that the tribes of Israel would possess?

Moses was shown all the land that the tribes of Israel would posses from the top of Pisgah. 

# From where was Moses shown all the lands that the tribes of Israel would possess?

Moses was shown all the land that the tribes of Israel would posses from the top of Pisgah. 

# From where was Moses shown all the lands that the tribes of Israel would possess?

Moses was shown all the land that the tribes of Israel would posses from the top of Pisgah. 

# What did Yahweh allow Moses to see before he died?

Yahweh allowed Moses to see the land that Yahweh swore to Abraham, Isaac and Jacob. 

# Where did Moses die and where did Yahweh bury Moses?

Moses died in the land of Moab and Yahweh buried him in the valley in the land of Moab opposite Beth Peor. 

# What was Moses physical condition when he died at one hundred twenty years of age?

When Moses died he was still strong and could see well. 

# How long did the people of Israel mourn for Moses?

The people mourned for Moses for thirty days. 

# Why did the people of Israel listen to Joshua and do what Yahweh had commanded Moses?

The people of Israel listened to Joshua because Joshua was full of the spirit of wisdom, and Moses had laid his hands on him. 

# How was Moses known by Yahweh?

Yahweh knew Moses face to face. 

# Has there ever been a prophet like Moses in Israel?

There has never been any prophet like Moses in all of Israel. 

# Has there ever been a prophet like Moses in Israel?

There has never been any prophet like Moses in all of Israel. 

# Has there ever been a prophet like Moses in Israel?

There has never been any prophet like Moses in all of Israel. 

