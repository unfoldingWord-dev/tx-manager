# For what purpose did Yahweh send an ambassador among the nations?

Yahweh sent an ambassador among the nations to cause the nations to rise up for battle against Edom. 

# What was one of the sins of the Edomites?

The Edomites had pride in their heart and believed that they could not be brought down to the ground. 

# Who will deceive and prevail against Edom?

The men who had an alliance of peace with Edom will deceive and betray Edom. 

# Why will Edom be covered with shame and cut off forever?

Edom will be covered with shame and cut off forever because of the violence Edom did to her brother Jacob. 

# What happened on the day that Edom stood aloof from Jacob?

On that day, strangers entered the gates of Jerusalem and carried away its wealth. 

# What did Yahweh tell Edom not to do regarding Judah in the day of Judah's distress?

Yahweh told Edom not to gloat, rejoice, or loot Judah's wealth in the day of Judah's distress. 

# What did Yahweh tell Edom not to do regarding Judah in the day of Judah's distress?

Yahweh told Edom not to gloat, rejoice, or loot Judah's wealth in the day of Judah's distress. 

# What did Yahweh say would return on Edom's head?

Yahweh said that Edom's own deeds would return on Edom's head. 

# What would some in Mount Zion be able to do despite the distress of Judah?

Some in Mount Zion would be able to escape despite the distress of Judah. 

# How many of Edom would escape the judgment of Yahweh?

There would be no survivors in Edom after Yahweh's judgment. 

# Who would then possess the mount of Esau?

Those from the Negev would then possess the mount of Esau. 

# From where would the mount of Esau then be judged?

The mount of Esau would then be judged from mount Zion. 

