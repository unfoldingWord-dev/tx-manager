# Whose word came to Joel?

The word of Yahweh came to Joel. 

# To whom were the elder to tell the word of Yahweh?

They were to tell their children, and their children were to tell their children. 

# What happened to what the great locusts have left?

The grasshopper has eaten what the great locusts have left. 

# Why will drinkers of wine wail?

They will wail because the sweet wine has been cut off. 

# Into what has the enemy made the vineyard?

He has made the vineyard into a terrifying place. 

# For what reason does the virgin mourn?

The virgin mourns for the death of her young husband. 

# What has happened to the grain?

The grain had been destroyed. 

# What has been withheld from the house of God?

The grain offering and the drink offering have been withheld from the house of God. 

# When will the day of Yahweh be here?

The day of Yahweh is almost here. 

# What has been broken down?

The barns have been broken down. 

# Why are the herds of cattle suffering?

The herds of cattle are suffering because they have no pasture. 

# To whom does Joel call?

Joel calls to Yahweh. 

# For whom do the animals of the field pant?

The animals of the field pant for Yahweh 

# Why should all the inhabitants of the land tremble in fear?

They should tremble in fear, for the day of Yahweh is coming. 

# When has there been an army like this one?

There has never been an army like this one, and there never will be again. 

# What is the land like behind the army?

The land behind the army is a ruined wilderness. 

# What does the army look like and act like?

The army looks like horses and runs like horsemen. 

# How does the army enter the city?

They rush on the city, they run on the wall, they climb in houses, and they go through windows like thieves. 

# Whose army is this?

This is Yahweh's army. 

# What two things should the people tear?

They should tear their hearts and their garments. 

# Why should the people return to Yahweh?

He is gracious and merciful, slow to anger and abundant in love, and he would like to turn from inflicting punishment. 

# Why should the people blow a trumpet in Zion?

They should blow a trumpet to consecrate a fast, and to call a sacred assembly. 

# What had Yahweh's people been among the nations?

Yahweh's people had been a disgrace among the nations. 

# Why should the land not fear?

The land should not fear for Yahweh has done great things. 

# Who sent the mighty army?

Yahweh sent the mighty army. 

# Will Yahweh ever bring shame on his people again?

No, he will never bring shame on his people again. 

# Will Yahweh ever bring shame on his people again?

No, he will never bring shame on his people again. 

# What will happen when Yahweh pours out his Spirit?

Their sons and your daughters will prophesy, their old men will dream dreams, and their young men will see visions. 

# What will happen when Yahweh pours out his Spirit?

Their sons and your daughters will prophesy, their old men will dream dreams, and their young men will see visions. 

# What will Yahweh show in heavens and on the earth?

Yahweh show wonders in heavens and on the earth. 

# Into what will the sun turn?

The sun will turn into darkness. 

# Who will be saved at that time?

Everyone who calls on the name of Yahweh will be saved. 

# Who will Yahweh bring to the Valley of Jehoshphat?

Yahweh will bring the nations to the Valley of Jehoshphat. 

# Who did the nations scatter?

The nations scattered Yahweh's people. 

# At whom are Tyre, Sidon and all the regions of Philistia angry?

Tyre, Sidon and all the regions of Philistia are angry at Yahweh. 

# What did Tyre, Sidon, and Philistia do with Yahweh's treasures?

They brought his treasures into their temples. 

# What did Tyre, Sidon, and Philistia do to the people of Judah and Jerusalem?

They sold the people to the Greeks in order to remove them far from their territory. 

# What will Yahweh do to the sons and daughters of Tyre, Sidon, and Philistia?

Yahweh will sell their sons and daughters to the Sabeans by the hand of the people of Judah. 

# Into what should the nations beat their plowshares?

They should beat their plowshares into swords. 

# What will Yahweh do to all surrounding nations?

Yahweh will sit to judge all surrounding nations. 

# What will happen to the sun, moon, and stars?

The sun and the moon will become dark, and the stars will keep back their brightness. 

# What two things will Yahweh be for his people?

Yahweh be a shelter and a fortress for his people. 

# Who lives in Zion?

Yahweh theirs God lives in Zion. 

# With what will the hills flow?

The hills will flow with milk. 

# Who will be abandoned because of the violence they did to the people of Judah?

Egypt and Edom will be abandoned. 

