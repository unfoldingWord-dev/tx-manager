# Who did Yahweh appoint to build for him a house in Jerusalem in Judea?

Yahweh appointed Cyrus to build for him a house in Jerusalem in Judea. 

# Who would provide the survivors of the land with silver and gold?

People of any part of the kingdom where survivors of that land are living would provide them with silver and gold. 

# Where had Nebuchadnezzar put the objects belonging to Yahweh's house?

Nebuchadnezzar had put the objects belonging to Yahweh's house in his own gods' houses. 

# How many gold and silver items did Sheshbazzar bring when the exiles went from Babylon to Jerusalem?

Sheshbazzar brought 5,400 gold and silver items when the exiles went from Babylon to Jerusalem. 

# Who had exiled the people in Babylon?

King Nebuchadnezzar had exiled the people in Babylon. 

# Why could some of the priests' descendents not find their geneology in the register?

The priests' descendents could not find their geneology in the register since they had defiled their priesthood. 

# When could the priests' descendants eat some of the holy sacrifices?

The priests' descendants could eat some of the holy sacrifices after a priest with Urim and Thummim approved. 

# Where were all the people in Israel?

All the people in Israel were in their cities. 

# Why did Jeshua son of Jozadak and his brothers the priests, and Zerubbabel son of Shealtiel and his brothers rise up and build the altar of the God of Israel?

They rose up and built the altar to offer burnt offerings as commanded in the Law of Moses. 

# How often did Jeshua and his brothers the priests and Zerubbabel and his brothers offer burnt offerings to Yahweh?

They offered burnt offerings to Yahweh at dawn and evening. 

# Who authorized cedar trees to be sent from Lebanon to Joppa by sea?

Cyrus, king of Persia authorized cedar trees to be sent from Lebanon to Joppa by sea. 

# When did the work begin?

The work began in the second month of the second year after the Israelites came to the house of God in Jerusalem. 

# How did the people respond because the temple's foundations had been laid?

All the people cried out with a great shout of joy in praise of Yahweh because the temple's foundations had been laid. 

# How did those who had seen the first house respond when this house's foundations were laid before their eyes?

Those who had seen the first house wept loudly when this house's foundations were laid before their eyes. But many had shouts of joy with gladness and an excited sound. 

# What did some enemies of Judah and Benjamin hear that the people who had been exiled were doing?

Some enemies of Judah and Benjamin heard that the people who had been exiled were now building a temple for Yahweh, the God of Israel. 

# For how long did the enemies say they had sacrificed to Yahweh?

The enemies said they had sacrificed to Yahweh since the days when they were brought to that place. 

# For how long did the enemies make the Judeans' hands weak?

They made the Judeans' hands weak during all of Cyrus' days and into the reign of Darius, king of Persia. 

# For how long did the enemies make the Judeans' hands weak?

They made the Judeans' hands weak during all of Cyrus' days and into the reign of Darius, king of Persia. 

# What did the enemies write at the beginning of Ahasuerus' reign?

At the beginning of Ahasuerus' reign, the enemies wrote an accusation against the inhabitants of Judah and Jerusalem. 

# What did the enemies tell the king about the Jews' city?

The enemies told king that the Jews were building a rebellious city. 

# Why was it not fitting for the enemies to see any dishonor happen to the king?

It was not fitting for them to see any dishonor happen to the king because they had eaten the palace salt. 

# After the letter that the enemies sent to the king was translated and read to him, what did he do?

After the letter that the enemies sent to the king was translated and read to him, he ordered an investigation. 

# After the letter that the enemies sent to the king was translated and read to him, what did he do?

After the letter that the enemies sent to the king was translated and read to him, he ordered an investigation. 

# For how long did the work on the house of God in Jerusalem stop?

The work on the house of God in Jerusalem stopped until the second year of the reign of Darius, king of Persia. 

# For what were the Jewish elders waiting?

The Jewish elders were waiting for a decree to come from Darius. 

# How did Tattenai, Shethar Bozenai, and their fellow officials describe the work on the house of God?

They wrote that the work was being done thoroughly and was going forward well in Jews' hands. 

# Why did the God of heaven give the Jews into the hand of Nebuchadnezzar king of Babylon?

The God of heaven gave the Jews into the hand of Nebuchadnezzar king of Babylon when their ancestors enraged him. 

# What items did King Cyrus return to Sheshbazzar?

King Cyrus returned the gold and silver objects belonging to the house of God. 

# What did the Jews request that the king do?

They requested that the king investigate in the house of archives in Babylon if a judgment from King Cyrus exists there to build the house of God in Jerusalem. 

# What was found when King Darius ordered an investigation in the house of archives in Babylon?

During the investigation that King Darius ordered a scroll was found in the fortified city of Ecbatana in Media. 

# What was found when King Darius ordered an investigation in the house of archives in Babylon?

During the investigation that King Darius ordered a scroll was found in the fortified city of Ecbatana in Media. 

# Who was to pay for the house for sacrifice mentioned in King Cyrus' decree?

The cost for the house of sacrifice was to be borne by the king's house. 

# According to King Cyrus' decree what was to be brought back to the house of God?

According to King Cyrus' decree the gold and silver objects belonging to the house of God that Nebuchadnezzar brought from the temple in Jerusalem to the temple in Babylon were to be brought back to the house of God in Jerusalem. 

# Who did Cyrus say would build the house of God?

Cyrus said the governor and Jewish elders would build the house of God. 

# Why did Cyrus want to give the Jews whatever they needed to build the house of God?

Cyrus wanted to give the Jews whatever they needed to build the house of God so they would bring the offering in to the God of Heaven and pray for him and his sons. 

# Why did Cyrus want to give the Jews whatever they needed to build the house of God?

Cyrus wanted to give the Jews whatever they needed to build the house of God so they would bring the offering in to the God of Heaven and pray for him and his sons. 

# What must happen if anyone violates the decree about helping the Jews?

If anyone violates the decree, a beam must be pulled from his house and he must be impaled on it. His house must then be turned into a garbage heap because of this. 

# How did Haggai and Zechariah instruct the Jewish elders to build?

Haggai and Zechariah instructed the Jewish elders to build by prophesying. 

# For whom did the priests and Levites slaughter the Passover sacrifices?

The priests and Levites slaughtered the Passover sacrifices for all those who had been in exile, including themselves. 

# Why did the Jews joyfully celebrate the Festival of Unleavened Bread?

The Jews joyfully celebrated the Festival of Unleavened Bread, for Yahweh had brought them joy and turned the heart of Assyria's king to strengthen their hands in the work of his house. 

# What was Ezra's occupation?

He was a skilled scribe in the Law of Moses. 

# Why did Ezra arrive in Jerusalem on the first day of the fifth month?

On the first day of the fifth month he arrived in Jerusalem, since the good hand of God was with him. 

# Who was allowed to go to Jerusalem with Ezra?

Anyone from Israel in Artaxerxes' kingdom, along with their priests and Levites, who desired to go to Jerusalem, could go with Ezra. 

# Why did the king and his seven counselors send the Israelites back to Israel?

The king and his seven counselors sent them out to inquire concerning Judah and Jerusalem according to God's Law that he understood, and to bring the silver and gold that they have freely offered to the God of Israel to Jerusalem, his home. 

# Why did the king and his seven counselors send the Israelites back to Israel?

The king and his seven counselors sent them out to inquire concerning Judah and Jerusalem according to God's Law that he understood, and to bring the silver and gold that they have freely offered to the God of Israel to Jerusalem, his home. 

# From where should the Jews take anything else that they needed for the house of their God?

The Jews should take anything else that they needed for the house of their God from Artaxerses' treasury. 

# Why should the treasurers do anything that came from the decree of the God of Heaven with devotion for his house?

They should do anything that came from the decree of the God of Heaven with devotion for his house so that his wrath will not come on Artaxerses' and his sons' kingdom. 

# How could Ezra punish anyone who did not fully obey God's law or the king's law?

Ezra could punish anyone who did not fully obey God's law or the king's law by killing them, banishing them, confiscating their wealth, or by imprisoning them. 

# How was Ezra strengthened?

Ezra was strengthened by the hand of Yahweh his God. 

# When Ezra examined the people and priests, what could he not find?

When Ezra examined the people and priests, he could not find any descendants of Levi there. 

# What was the occupation of Iddo and his relatives?

Iddo and his relatives were temple servants. 

# What kind of man was Sherebiah?

Sherebiah was a prudent man. 

# Why did Ezra not ask the king for an army or horsemen to protect them against enemies?

Ezra not ask the king for an army or horsemen to protect them against enemies because he was embarrassed. 

# How long were the twelve men to watch over the gold and silver?

The twelve men were to watch over the gold and silver until they weighed them out before the priestly officials, Levites, and leaders of the ancestors' clans of Israel in Jerusalem in the rooms of God's house. 

# In what way was the hand of God on Ezra and the twelve?

The hand of God was on them in that he protected them from the hand of the enemy and the ones who wished to ambush them along the road. 

# To whom did the ones who came back from captivity give the king's decrees?

The ones who came back from captivity gave the king's decrees to the king's high officials and the governors beyond the River. 

# To whom did the ones who came back from captivity give the king's decrees?

The ones who came back from captivity gave the king's decrees to the king's high officials and the governors beyond the River. 

# In what way did the people of Israel not separate themselves from the people of other lands?

The people of Israel did not separate themselves from the people of other lands, for they took some of their daughters and sons. 

# In what way did the people of Israel not separate themselves from the people of other lands?

The people of Israel did not separate themselves from the people of other lands, for they took some of their daughters and sons. 

# How did Ezra respond to the people's unfaithfulness?

Ezra ripped his clothing and robe and tore the hair from his head and beard. Then he sat ashamed. 

# Why was Ezra ashamed and too humiliated to raise his face to Yahweh?

Ezra was ashamed and too humiliated to raise his face to Yahweh , for his people's iniquities increased over their head, and their guilt grew to the heavens. 

# Why did Yahweh extend covenant faithfulness to Ezra's people?

Yahweh extended covenant faithfulness to Ezra's people in order to give the people new strength so they could rebuild God's house and raise its ruins. He did that so that he could give them a wall of safety in Judah and Jerusalem. 

# How was the land contaminated?

The land was contaminated by the people of the lands with their abominations that they filled from one end to the other with their uncleanness. 

# What did God hold back?

God held back what the people's iniquities deserved. 

# What did Ezra do as he prayed and confessed?

As Ezra prayed and confessed, he wept and threw himself down before God's house. 

# What covenant did Shekaniah say the Israelites should make?

He said they should make a covenant with their God to send out all the foreign women and their children. 

# Why did Ezra not eat any bread or drink any water?

Ezra did not eat any bread or drink any water, since he was mourning concerning the faithlessness of those who had been in captivity. 

# What happened to anyone who did not come in three days according to the instructions from the officials and elders?

Anyone who did not come in three days according to the instructions from the officials and elders forfeited all of his possessions and would be excluded from the great assembly of the people come back from exile. 

# Why did all the people who stood in the square before God's house tremble?

All the people stood in the square before God's house and trembled because of the word and the rain. 

# Why did the Israelites want more time to send away the foreign women?

They wanted more time because there were many people, and it was the rainy season. They had no strength to stand outside. They had greatly transgressed in this matter. 

# By what time did the leaders finish discovering which men had lived with foreign women?

By the first day of the first month they had finished discovering which men had lived with foreign women. 

# What did the guilty men offer?

The guilty men offered a ram from the flock for their guilt. 

