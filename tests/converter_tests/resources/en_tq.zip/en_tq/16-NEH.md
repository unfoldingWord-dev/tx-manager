# Who wrote the book of Nehemiah?

Nehemiah the son of Hacaliah wrote the book of Nehemiah. 

# When did Nehemiah ask Hanani and some people from Judah about the Jews who had escaped, the remnant of the Jews who were there, and about Jerusalem?

He asked them in the month Kislev, in the twentieth year. 

# When did Nehemiah ask Hanani and some people from Judah about the Jews who had escaped, the remnant of the Jews who were there, and about Jerusalem?

He asked them in the month Kislev, in the twentieth year. 

# What did Hanani and some people from Judah reply?

They replied that those who remained in the province were in great trouble and disgrace because Jerusalem's wall and gates were broken and burnt. 

# What did Nehemiah do when he heard about the condition of Jerusalem?

He sat down and wept, and for days he continued grieving and fasting and praying. 

# What did Nehemiah request while praying before the God of heaven?

He requested that Yahweh would listen to his prayer; that Yahweh would call to mind the word he commanded Moses, promising to gather the scattered Israelites if they returned to him and followed and did his commandments, and that Yahweh would give success and grant mercy to him. 

# What did Nehemiah confess while praying before the God of heaven?

Nehemiah confessed the sins of the people of Israel and his own sins and the sins of his family. Nehemiah said they had acted very wickedly against Yahweh and had not kept the commandments, the laws, and the decrees Yahweh commanded Moses. 

# What did Nehemiah confess while praying before the God of heaven?

Nehemiah confessed the sins of the people of Israel and his own sins and the sins of his family. Nehemiah said they had acted very wickedly against Yahweh and had not kept the commandments, the laws, and the decrees Yahweh commanded Moses. 

# What did Nehemiah request while praying before the God of heaven?

He requested that Yahweh would listen to his prayer; that Yahweh would call to mind the word he commanded Moses, promising to gather the scattered Israelites if they returned to him and followed and did his commandments, and that Yahweh would give success and grant mercy to him. 

# What did Nehemiah request while praying before the God of heaven?

He requested that Yahweh would listen to his prayer; that Yahweh would call to mind the word he commanded Moses, promising to gather the scattered Israelites if they returned to him and followed and did his commandments, and that Yahweh would give success and grant mercy to him. 

# What did Nehemiah request while praying before the God of heaven?

He requested that Yahweh would listen to his prayer; that Yahweh would call to mind the word he commanded Moses, promising to gather the scattered Israelites if they returned to him and followed and did his commandments, and that Yahweh would give success and grant mercy to him. 

# What did Nehemiah request while praying before the God of heaven?

He requested that Yahweh would listen to his prayer; that Yahweh would call to mind the word he commanded Moses, promising to gather the scattered Israelites if they returned to him and followed and did his commandments, and that Yahweh would give success and grant mercy to him. 

# To whom did Nehemiah serve as cupbearer?

Nehemiah served as cupbearer to the king. 

# At what date did Nehemiah, when he was sad, give wine to the king?

He gave it to king in the month of Nisan, in the twentieth year of Artaxerxes. 

# Why was Nehemiah sad?

He was sad because the city was in ruins and its gates destroyed. 

# When the king asked what Nehemiah wanted him to do, what did Nehemiah do?

Nehemiah prayed to the God of heaven. 

# What did Nehemiah want the king to give him permission to do?

Nehemiah wanted permission from the king to go to Judah to rebuild the city. 

# What did Nehemiah want the king to give him permission to do?

Nehemiah wanted permission from the king to go to Judah to rebuild the city. 

# When the king sent Nehemiah with officers of the army and horsemen, why were Sanballat and Tobiah displeased?

They were displeased that someone had come who was seeking to help the people of Israel. 

# When the king sent Nehemiah with officers of the army and horsemen, why were Sanballat and Tobiah displeased?

They were displeased that someone had come who was seeking to help the people of Israel. 

# When Nehemiah arose in the night, who did he tell what God had put into his heart to do for Jerusalem?

Nehemiah had not told anyone what his God had put into his heart to do for Jerusalem. 

# When Nehemiah told the rulers, the Jews, the priests, the nobles, the rest who did the work that the good hand of his God was on him and about the words the king had spoken to him, what did they say and do?

They said that they would rise and build, and they strengthened their hands for the good work. 

# When Nehemiah told the rulers, the Jews, the priests, the nobles, the rest who did the work that the good hand of his God was on him and about the words the king had spoken to him, what did they say and do?

They said that they would rise and build, and they strengthened their hands for the good work. 

# How did Nehemiah respond to Sanballat, Tobiah, and Geshem when they heard about the work, and mocked and ridiculed the workers?

Nehemiah responded by saying that God would give them success, that they were God's servants, and that Sanballat, Tobiah, and Geshem had no share, no right, and no historic claim in Jerusalem. 

# How did Nehemiah respond to Sanballat, Tobiah, and Geshem when they heard about the work, and mocked and ridiculed the workers?

Nehemiah responded by saying that God would give them success, that they were God's servants, and that Sanballat, Tobiah, and Geshem had no share, no right, and no historic claim in Jerusalem. 

# Who built and consecrated the Sheep Gate?

Eliashib with his brother priests built the Sheep Gate. 

# Who built the Fish Gate?

The sons of Hassenaah built the Fish Gate. 

# Whose leaders refused to do the work ordered by their supervisors?

The leaders of the Tekoites refused to do the work. 

# Who repaired the Old Gate?

Joiada and Meshullam repaired the Old Gate. 

# Who repaired Jerusalem as far as the Broad Wall?

Uzziel and Hananiah repaired that portion of Jerusalem. 

# Who repaired another section along with the Tower of Ovens?

Malchijah son of Harim and Hasshub repaired another section and the Tower of Ovens. 

# Who helped Shallum repair the walls?

His daughters helped him. 

# Who repaired the Valley Gate as far as the Dung Gate?

Hanun and the inhabitants of Zanoah repaired from the Valley Gate to the Dung Gate. 

# Who repaired the Dung Gate?

Malchijah son of Rechab repaired the Dung Gate. 

# Who repaired the Fountain Gate and the wall of the Pool of Siloam?

Shallun repaired the Fountain Gate and the wall of the Pool of Siloam. 

# Who repaired from the place across from the tombs of David to the house of the mighty men?

Nehemiah, the son of Azbuk, repaired that section. 

# Who energetically repaired from the buttress to the door of the house of Elisahib the high priest?

Baruch energetically repaired it. 

# Which section of the wall did Benjamin and Hasshub repair?

They repaired the section opposite their own house. 

# Who did the repairs on the section above the Horse Gate?

The priests repaired that section, each opposite his own house. 

# Who repaired the wall between the upper changes of the corner and the Sheep Gate?

The goldsmiths and the merchants repaired that section. 

# Who mocked the Jews when they heard the Jews were building the wall?

Sanballat and Tobiah mocked the Jews. 

# Who mocked the Jews when they heard the Jews were building the wall?

Sanballat and Tobiah mocked the Jews. 

# Who mocked the Jews when they heard the Jews were building the wall?

Sanballat and Tobiah mocked the Jews. 

# Why did Nehemiah ask God not to cover over the iniquity of Sanballat and Tobiah?

Nehemiah asked God not to cover their iniquity because they despised the Jews and provoked the builders to anger. 

# Why did Nehemiah ask God not to cover over the iniquity of Sanballat and Tobiah?

Nehemiah asked God not to cover their iniquity because they despised the Jews and provoked the builders to anger. 

# Why did Nehemiah ask God not to cover over the iniquity of Sanballat and Tobiah?

Nehemiah asked God not to cover their iniquity because they despised the Jews and provoked the builders to anger. 

# When Sanballat, Tobiah, the Arabians, the Ammonites, and the Ashdodites came to fight against Jerusalem, what did the builders and people do?

They prayed to their God and set a guard as protection. 

# When Sanballat, Tobiah, the Arabians, the Ammonites, and the Ashdodites came to fight against Jerusalem, what did the builders and people do?

They prayed to their God and set a guard as protection. 

# When Sanballat, Tobiah, the Arabians, the Ammonites, and the Ashdodites came to fight against Jerusalem, what did the builders and people do?

They prayed to their God and set a guard as protection. 

# What did Nehemiah do after the Jews warned him of the schemes being made against them?

After the Nehemiah learned of the schemes against them, he positioned people in the lowest parts of the wall in the exposed areas. He positioned each family with their weapons. Nehemiah told the people to not be afraid of their enemies, remember the great and awesome Lord, and to fight for their families and homes. 

# What did Nehemiah do after the Jews warned him of the schemes being made against them?

After the Nehemiah learned of the schemes against them, he positioned people in the lowest parts of the wall in the exposed areas. He positioned each family with their weapons. Nehemiah told the people to not be afraid of their enemies, remember the great and awesome Lord, and to fight for their families and homes. 

# What did Nehemiah do after the Jews warned him of the schemes being made against them?

After the Nehemiah learned of the schemes against them, he positioned people in the lowest parts of the wall in the exposed areas. He positioned each family with their weapons. Nehemiah told the people to not be afraid of their enemies, remember the great and awesome Lord, and to fight for their families and homes. 

# Why did the plans of the enemies become known to the workers?

The plans became known because God had frustrated their plans. 

# What did Nehemiah have his servants do?

Nehemiah had half his servants work on rebuilding the wall and he had the other half held their weapons and wore armor. 

# Why did Nehemiah tell the people that they must rush to the place where they heard the trumpet sound and assemble there?

Nehemiah told the people that because the workers were separated on the wall, far from one another. 

# Why did Nehemiah tell the people that they must rush to the place where they heard the trumpet sound and assemble there?

Nehemiah told the people that because the workers were separated on the wall, far from one another. 

# Why did the people not go to their homes to sleep or change their clothes?

They did not go to their homes or change their clothes so that they could spend the night in the middle of Jerusalem, being a guard during the night and a worker in the day. 

# Why did the people not go to their homes to sleep or change their clothes?

They did not go to their homes or change their clothes so that they could spend the night in the middle of Jerusalem, being a guard during the night and a worker in the day. 

# Why did the people not go to their homes to sleep or change their clothes?

They did not go to their homes or change their clothes so that they could spend the night in the middle of Jerusalem, being a guard during the night and a worker in the day. 

# Why did the men and women raise a great outcry against their fellow Jews?

They raised an outcry because they had to mortgage their property and sell their children for food, yet the nobles and officials were exacting interest from them. 

# Why did the men and women raise a great outcry against their fellow Jews?

They raised an outcry because they had to mortgage their property and sell their children for food, yet the nobles and officials were exacting interest from them. 

# Why did the men and women raise a great outcry against their fellow Jews?

They raised an outcry because they had to mortgage their property and sell their children for food, yet the nobles and officials were exacting interest from them. 

# Why did the men and women raise a great outcry against their fellow Jews?

They raised an outcry because they had to mortgage their property and sell their children for food, yet the nobles and officials were exacting interest from them. 

# Why did the men and women raise a great outcry against their fellow Jews?

They raised an outcry because they had to mortgage their property and sell their children for food, yet the nobles and officials were exacting interest from them. 

# Why did the men and women raise a great outcry against their fellow Jews?

They raised an outcry because they had to mortgage their property and sell their children for food, yet the nobles and officials were exacting interest from them. 

# Although the men and women were buying back from slavery their Jewish brothers who had been sold to the nations, what were the nobles and officials doing?

They were selling their brothers and sisters, that they might be sold back to the other Jewish men and women. 

# Why did Nehemiah command the nobles, officials, and priests to return the things they exacted from the people?

He commanded them to do that because what they were doing was not good, and they were causing the nations that were their enemies to taunt them. 

# Why did Nehemiah command the nobles, officials, and priests to return the things they exacted from the people?

He commanded them to do that because what they were doing was not good, and they were causing the nations that were their enemies to taunt them. 

# Why did Nehemiah command the nobles, officials, and priests to return the things they exacted from the people?

He commanded them to do that because what they were doing was not good, and they were causing the nations that were their enemies to taunt them. 

# How did the nobles, officials, and priests respond to Nehemiah's command?

They said they would do as he commanded, said "Amen," and praised Yahweh. 

# How did the nobles, officials, and priests respond to Nehemiah's command?

They said they would do as he commanded, said "Amen," and praised Yahweh. 

# Why did neither Nehemiah nor his brothers take the food provided for the governor during the 12 years he was Judah's governor?

He did not do so because the former governors had laid heavy burdens on the people, but he feared God. 

# Why did neither Nehemiah nor his brothers take the food provided for the governor during the 12 years he was Judah's governor?

He did not do so because the former governors had laid heavy burdens on the people, but he feared God. 

# Who ate at Nehemiah's table?

Those who ate at Nehemiah's table were the Jews and the officials, 150 men, and also those who came to Nehemiah from among the nations who were around them. 

# Why did Nehemiah ask God to call him to mind for good?

He asked God to do this because of all that Nehemiah had done for the people. 

# When Sanballat, Tobiah, and Geshem asked Nehemiah to meet with them in the plain of Ono, what was their intention?

Sanballat, Tobiah, and Geshem intended to harm Nehemiah? 

# How did Nehemiah respond to the requests of their enemies?

Nehemiah sent messengers to them saying, "I am doing a great work and I cannot come down. Why should the work stop while I leave it and come down to you?" 

# What did Sanballat say in his fifth message?

He said that all the nations had reported that Nehemiah and the Jews were planning to rebel, and the king would certainly hear these reports. 

# How did Nehemiah respond to Sanballat's fifth message?

Nehemiah responded by saying Sanballat had invented the reports in his heart. 

# What did Sanballat say in his fifth message?

He said that all the nations had reported that Nehemiah and the Jews were planning to rebel, and the king would certainly hear these reports. 

# How did Nehemiah respond to Sanballat's fifth message?

Nehemiah responded by saying Sanballat had invented the reports in his heart. 

# What did Nehemiah pray when he realized that Sanballat and Jews' enemies were trying to make the work stop and the Jews afraid?

Nehemiah prayed that God would strengthen his hands. 

# What did Nehemiah pray when he realized that Sanballat and Jews' enemies were trying to make the work stop and the Jews afraid?

Nehemiah prayed that God would strengthen his hands. 

# Why did Nehemiah refuse to meet Shemaiah, the son of Delaiah, the son of Mehetabel, in the temple?

Nehemiah refused because he thought a man like himself should not run away to save his own life. 

# Why did Nehemiah refuse to meet Shemaiah, the son of Delaiah, the son of Mehetabel, in the temple?

Nehemiah refused because he thought a man like himself should not run away to save his own life. 

# What would have happened if Nehemiah had gone into the temple?

He would have sinned, and then Tobiah and Sanballat would have given Nehemiah a bad name in order to humiliate him. 

# What did Nehemiah pray the second time?

He prayed God would call to mind Tobiah, Sanballat, the prophetess Noadiah, and the rest of the prophets who tried to make him afraid. 

# Why did Nehemiah's enemies become afraid and fall in their own esteem when the wall was finished?

They became afraid because they knew the work was done with the help of the Jews' God. 

# Why did Nehemiah's enemies become afraid and fall in their own esteem when the wall was finished?

They became afraid because they knew the work was done with the help of the Jews' God. 

# When did Nehemiah give his brother Hanani charge over Jerusalem?

Nehemiah gave Hanani charge after he had finished the wall, set up the doors, and appointed the gatekeepers, singers, and Levites. 

# When did Nehemiah give his brother Hanani charge over Jerusalem?

Nehemiah gave Hanani charge after he had finished the wall, set up the doors, and appointed the gatekeepers, singers, and Levites. 

# Why did Nehemiah appoint Hanani?

Nehemiah did so because Hanani was a faithful man and feared God more than many. 

# When were the gates of Jerusalem supposed to be open?

The gates were supposed to be open when the sun was hot. 

# Although the city was wide and large, were there people and houses within it?

There were few people within the city, and no houses. 

# What did God put into Nehemiah's heart to do?

God put into Nehemiah's heart to enroll the nobles, the officials, and the people by their families. 

# What was done concerning the priests who could not find their genealogical records and what did the governor restrict them from doing?

The priests who could not find their genealogical records were excluded from the priesthood and the governor said they should not be allowed to eat the priest's share of food from the sacrifices. 

# What was done concerning the priests who could not find their genealogical records and what did the governor restrict them from doing?

The priests who could not find their genealogical records were excluded from the priesthood and the governor said they should not be allowed to eat the priest's share of food from the sacrifices. 

# When would the priests who could not prove their genealogy be included in the priesthood again?

They would be included when there rose up a priest with Urim and Thummim. 

# How many people were counted in the enrollment of the assembly?

The whole assembly was counted to be 42,360 people. 

# Who gave gifts for the work?

Some of the heads of ancestors' families gave gifts, as did the rest of the people. 

# Who gave gifts for the work?

Some of the heads of ancestors' families gave gifts, as did the rest of the people. 

# Who gave gifts for the work?

Some of the heads of ancestors' families gave gifts, as did the rest of the people. 

# When did the priests, Levites, gatekeepers, singers, temple servants, and people live in their cities?

They lived in their cities by the seventh month. 

# Why did the people gather together from the first day of the seventh month throughout the end of the month?

The people gathered together to listen to the book of the law. 

# Why did the people gather together from the first day of the seventh month throughout the end of the month?

The people gathered together to listen to the book of the law. 

# Who gathered together to listen to the book of the law?

Men and women, and any who could understand, gathered to listen to it. 

# Why did the people gather together from the first day of the seventh month throughout the end of the month?

The people gathered together to listen to the book of the law. 

# Who gathered together to listen to the book of the law?

Men and women, and any who could understand, gathered to listen to it. 

# Who read in the book of the law of God?

Ezra, others beside him, and the Levites read in it. 

# Who read in the book of the law of God?

Ezra, others beside him, and the Levites read in it. 

# Why did Ezra, the others beside him, and the Levites have to interpret and give the meaning of the book?

They had to interpret and give the meaning so the people could understand the reading. 

# Who read in the book of the law of God?

Ezra, others beside him, and the Levites read in it. 

# Why did Ezra, the others beside him, and the Levites have to interpret and give the meaning of the book?

They had to interpret and give the meaning so the people could understand the reading. 

# Why were all of the people commanded by Nehemiah, Ezra, and the Levites to celebrate with great joy and not to mourn or weep?

They were commanded to celebrate rather than mourn or weep because the day was holy to Yahweh their God and that the Joy of Yahweh was their strength. 

# Why were all of the people commanded by Nehemiah, Ezra, and the Levites to celebrate with great joy and not to mourn or weep?

They were commanded to celebrate rather than mourn or weep because the day was holy to Yahweh their God and that the Joy of Yahweh was their strength. 

# What insight did the leaders of the ancestors' families, the priests, and the Levites gain when they came together to learn from Ezra?

They learned that Yahweh had commanded the people of Israel to live in tents during the festival of the seventh month. 

# What insight did the leaders of the ancestors' families, the priests, and the Levites gain when they came together to learn from Ezra?

They learned that Yahweh had commanded the people of Israel to live in tents during the festival of the seventh month. 

# Where did the people make their tents to celebrate the festival?

The people made their tents on their own roofs, in their courtyards, in the courts of the house of God, in the open place by the water Gate, and in the square at the Gate of Ephraim. 

# Where did the people make their tents to celebrate the festival?

The people made their tents on their own roofs, in their courtyards, in the courts of the house of God, in the open place by the water Gate, and in the square at the Gate of Ephraim. 

# When was the last time the people of Israel had obeyed the command of Yahweh to celebrate the festival?

The last time the festival had been celebrated was in the days of Joshua the son of Nun. 

# Why did the people gather together from the first day of the seventh month throughout the end of the month?

The people gathered together to listen to the book of the law. 

# In general, what were the people of Israel doing as they gathered together on the twenty-fourth day of the same month?

The people of Israel were fasting, wearing sackcloth, and they put dust on their heads. The Israelites separated themselves from all the foreigners, and they stood and confessed their own sins and the sins of their ancestors. 

# In general, what were the people of Israel doing as they gathered together on the twenty-fourth day of the same month?

The people of Israel were fasting, wearing sackcloth, and they put dust on their heads. The Israelites separated themselves from all the foreigners, and they stood and confessed their own sins and the sins of their ancestors. 

# What did the people say about Yahweh?

The people said he was Yahweh alone, and he had made heaven, the earth, the seas, and all that was in them, and gave them life. 

# What did the people say about Yahweh?

The people said he was Yahweh alone, and he had made heaven, the earth, the seas, and all that was in them, and gave them life. 

# What else did the people say of Yahweh concerning Abram?

The people said that Yahweh had chosen Abram, changed his name to Abraham, found his heart faithful, and made the covenant with him to give his descendants the land. 

# What else did the people say of Yahweh concerning Abram?

The people said that Yahweh had chosen Abram, changed his name to Abraham, found his heart faithful, and made the covenant with him to give his descendants the land. 

# How did the people say that Yahweh kept his promise to them?

The people told how Yahweh brought their forefathers out of Egypt, showed signs and wonders against Pharaoh and his people, and saved their forefathers at the Red Sea. 

# How did the people say that Yahweh kept his promise to them?

The people told how Yahweh brought their forefathers out of Egypt, showed signs and wonders against Pharaoh and his people, and saved their forefathers at the Red Sea. 

# What did the people say that Yahweh did for the Israelites at the Red Sea?

Yahweh parted the sea so they could pass through on dry ground, and then he brought the sea back onto those that were pursuing them. 

# What other ways did they say Yahweh took care of the Israelites?

Yahweh led them by a pillar of cloud during the day, a pillar of fire during the night, and at Mount Sinai, he gave them his commandments. 

# What other ways did they say Yahweh took care of the Israelites?

Yahweh led them by a pillar of cloud during the day, a pillar of fire during the night, and at Mount Sinai, he gave them his commandments. 

# What else did the people say Yahweh provided to their forefathers?

Yahweh made his holy Sabbath known to them, gave them bread from heaven, water from a rock, and told them to possess the land he had promised them. 

# What else did the people say Yahweh provided to their forefathers?

Yahweh made his holy Sabbath known to them, gave them bread from heaven, water from a rock, and told them to possess the land he had promised them. 

# How did the Israelites and their ancestors act toward God?

The Israelites were disrespectful, stubborn, refused to listen, rebelled, and appointed a leader to return them to their slavery. 

# Why did God not abandon the Israelites when they were disrespectful, stubborn, rebellious, and disobedient?

God did not abandon the Israelites because he is a God who is full of forgiveness, gracious and compassionate, slow to anger, and abounding in steadfast love. 

# How did the Israelites and their ancestors act toward God?

The Israelites were disrespectful, stubborn, refused to listen, rebelled, and appointed a leader to return them to their slavery. 

# Why did God not abandon the Israelites when they were disrespectful, stubborn, rebellious, and disobedient?

God did not abandon the Israelites because he is a God who is full of forgiveness, gracious and compassionate, slow to anger, and abounding in steadfast love. 

# How did the people say God provided for their forefathers for forty years in the wilderness?

Yahweh gave his Spirit to instruct them, food and water; their clothes did not wear out, and their feet did not swell. 

# How did the people say God provided for their forefathers for forty years in the wilderness?

Yahweh gave his Spirit to instruct them, food and water; their clothes did not wear out, and their feet did not swell. 

# What did the people say happened after their forefathers were in the wilderness?

The people said that Yahweh multiplied their families, told them to go in and possess the land he had promised them, and subdued the Canaanites. 

# What did the people say happened after their forefathers were in the wilderness?

The people said that Yahweh multiplied their families, told them to go in and possess the land he had promised them, and subdued the Canaanites. 

# How did the Israelites live after taking possession of the land God had promised them?

The Israelites took the land and all that was there for themselves and delighted in God's goodness. 

# What did the people say Yahweh did to their forefathers and ancestors after they became disobedient and rebelled against him?

Yahweh handed them over to their enemies, who made them suffer. 

# What did the people say Yahweh did to their forefathers and ancestors after they became disobedient and rebelled against him?

Yahweh handed them over to their enemies, who made them suffer. 

# When the Israelites cried out to God, what did God do for them because of his great mercies?

God rescued them from their enemies many times. 

# Why did the rich yield from the Israelite's land go to the kings God had set over them?

The rich yield of the land went to their kings because of the Israelite's sins. 

# Why were the Israelites in great distress?

The Israelites were in great distress because their kings ruled over their bodies and their livestock as the kings pleased. 

# What did the Israelites do because of their great distress?

The Israelites made a firm covenant in writing with Yahweh. 

# Whose names were written on the sealed covenant?

The names of the Israelite's princes, Levites, and priests were written on the sealed covenant." 

# Who pledged themselves to the law of God that was given to Moses?

Those that pledged themselves were the rest of the people that were priests, Levites, gatekeepers, singers, temple servants, and all the others that bound themselves to God's law. 

# Who pledged themselves to the law of God that was given to Moses?

Those that pledged themselves were the rest of the people that were priests, Levites, gatekeepers, singers, temple servants, and all the others that bound themselves to God's law. 

# What promises did they make to God?

They promised not to give their daughters to or let their sons take daughters from the people from whom they had separated; they would not buy any goods on the Sabbath or any holy day, and they would let their fields rest every seventh year. 

# What promises did they make to God?

They promised not to give their daughters to or let their sons take daughters from the people from whom they had separated; they would not buy any goods on the Sabbath or any holy day, and they would let their fields rest every seventh year. 

# What commands did they accept?

They would give money, bread, grain, and provide for all the offerings and feasts each year for the service of the house of God. 

# What commands did they accept?

They would give money, bread, grain, and provide for all the offerings and feasts each year for the service of the house of God. 

# Why did the priests, the Levites, and the people cast lots for the wood offering?

This would select which family would bring the wood into the house of God at selected times each year. 

# What did they promise to bring to the house of Yahweh?

They promised to bring the firstfruits of their harvests, the firstborn of their sons and their animals. 

# What did they promise to bring to the house of Yahweh?

They promised to bring the firstfruits of their harvests, the firstborn of their sons and their animals. 

# Who had to be with the Levites when the Levites received the tithes?

A priest, a descendant of Aaron, had to be with the Levites. 

# Where did the people of Israel and descendants of Levi bring the contributions of the harvest?

They were to bring the contributions to the storerooms where the articles of the sanctuary were kept and the priests that serve, the gatekeepers, and the singers stayed. 

# Who lived in the holy city of Jerusalem?

The leaders of the people lived in Jerusalem, and the rest of the people cast lots to see who the one in ten would be to live there. 

# Where were the remainder of Israel, the priests, and the Levites living?

They were living in all the towns of Judah on their own inherited property. 

# In what book were the descendants of Levi and their leaders of families recorded?

They were recorded in the book of the annals up to the days of Johanan. 

# Why did the people seek out the Levites at the dedication of the wall of Jerusalem?

The people brought the Levites to Jerusalem to celebrate the dedication. 

# What did the priests and Levites do for the celebration?

The priests and Levites purified themselves, and then purified the people, the gates, and the wall. 

# Where did the leaders of Judah go on the day of celebration?

The leaders went up to the top of the wall. 

# What were the two large choirs, that Nehemiah appointed, supposed to do?

The two large choirs were supposed to give thanks. 

# Where did the first choir go?

One choir went to the right on the wall toward the Dung Gate. 

# Who directed the singers?

The singers sang with Jezrahiah as director. 

# Why did they offer great sacrifices that day, and rejoice?

They offered great sacrifices that day, and rejoiced, for God had made them rejoice with great joy. 

# Who was assigned to work the fields near the towns?

The men who were appointed to be in charge of the storerooms were assigned to work the fields near the towns. 

# When did all Israel give the daily portions for the singers and the gatekeepers?

In the days of Zerubbabel and in the days of Nehemiah, all Israel gave the daily portions for the singers and the gatekeepers. 

# Why should an Ammonite and a Moabite not come into the assembly of God, forever?

An Ammonite and a Moabite should not come into the assembly of God, forever, because they had not come to the people of Israel with bread and water, but had hired Balaam to curse Israel. 

# Why should an Ammonite and a Moabite not come into the assembly of God, forever?

An Ammonite and a Moabite should not come into the assembly of God, forever, because they had not come to the people of Israel with bread and water, but had hired Balaam to curse Israel. 

# What did Eliashib prepare for Tobiah?

Eliashib prepared for Tobiah a large storeroom. 

# Where did Nehemiah go in the thirty-second year of Artaxerxes?

In the thirty-second year of Artaxerxes, Nehemiah went to the king. 

# What did Nehemiah do because he was angry?

Because he was angry, Nehemiah threw all the household articles of Tobiah out of the storeroom. 

# Why did the Levites and singers hurry to leave the temple?

Because the portions assigned to give the Levites had not been distributed to them, they hurried to leave the temple, as the singers who did the work also had done. 

# Who was counted as trustworthy?

Shelemiah the priest, Zadok the scribe, Pedaiah, and Hanan were counted as trustworthy. 

# When were people in Judah treading winepresses?

People in Judah were treading winepresses on the Sabbath. 

# What did men from Tyre do on the Sabbath?

Men from Tyre brought in fish and all kinds of goods, and they sold them on the Sabbath to the people of Judah and in the city! 

# How did Nehemiah prevent people from coming into Jerusalem on the Sabbath?

As soon as it became dark, at the gates of Jerusalem before the Sabbath, Nehemiah commanded that the doors be shut and that they should not be opened until after the Sabbath. He stationed some of his servants at the gates so no load could be brought in on the Sabbath day. 

# Who came and guarded the gates, to sanctify the Sabbath day?

The Levites came and guarded the gates, to sanctify the Sabbath day. 

# What did half the children speak?

Half the children spoke the language of Ashdod, but they could not speak the language of Judah, but only the language of one of the other peoples. 

# How did Nehemiah confront the Jews who married women of Ashdod, Ammon, and Moab?

Nehemiah confronted them, and he cursed them, and he hit some of them and pulled out their hair. 

# How did Nehemiah want God to call him to mind?

Nehemiah wanted God to call him to mind for good. 

