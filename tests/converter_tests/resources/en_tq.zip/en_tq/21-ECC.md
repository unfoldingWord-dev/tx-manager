# Of whom was the Teacher a descendant?

The Teacher was a descendant of David, king in Jerusalem. 

# What remains forever?

The earth remains forever. 

# By what is the eye not satisfied?

The eye is not satisfied by what it sees. 

# What will be done?

Whatever has been done is what will be done. 

# To what did the Teacher apply his mind?

The Teacher applied his mind to study and to search out by wisdom everything that is done under heaven. 

# To what do all the deeds that are done under the sun amount?

All the deeds that are done under the sun amount to vapor and an attempt to shepherd the wind. 

# Where is there much frustration?

In the abundance of wisdom there is much frustration. 

# What was just a temporary breeze?

Pleasure was just a temporary breeze. 

# What did the Teacher want to find out?

The Teacher wanted to find out what was good for people to do under heaven during the days of their lives. 

# Why did the Teacher create pools of water?

The Teacher created pools of water to water a forest where trees were grown. 

# How did the Teacher do things that would bring pleasure to any man on earth?

By means of numerous wives and concubines, he did things that would bring pleasure to any man on earth. 

# In what did the Teacher's heart rejoice?

The Teacher's heart rejoiced in all his labor. 

# Where was there no profit?

There was no profit under the sun. 

# What is in store for everyone?

The same destiny is in store for everyone. 

# Who is not remembered for very long?

The wise man, like the fool, is not remembered for very long. 

# Why did the Teacher hate all his accomplishments?

The Teacher hated all his accomplishments because he had to leave them behind to the man who came after him. 

# How did the Teacher's heart feel about his work?

The Teacher's heart began to despair over all the work that he did. 

# Why does the soul of the hard worker not find rest at night?

Every day his work is painful and stressful, so at night his soul does not find rest. 

# What is there nothing better than for anyone?

There is nothing better for anyone than to simply eat and drink and be satisfied with what is good in his work. 

# What does God give to the sinner?

To the sinner, God gives the work of gathering and storing up so that he may give it away to someone who pleases God. 

# For what things is there a season?

There is a season for every purpose under heaven. 

# What did the Teacher see?

The Teacher saw the work that God gave to human beings to complete. 

# What did God place in people's hearts?

God placed eternity in their hearts. 

# What is a gift from God?

The good that comes from one's work is a gift from God. 

# Why can nothing be added to or taken away from whatever God does?

Nothing can be added to it or taken away from it, because it is God who has done it. 

# What is often found in place of righteousness?

In place of righteousness wickedness is often found. 

# How are people like animals?

Like animals, people all die. They all must breathe the same air. Everything comes from the dust, and everything returns to the dust. 

# How are people like animals?

Like animals, people all die. They all must breathe the same air. Everything comes from the dust, and everything returns to the dust. 

# What is the assignment for each person?

The assignment for each person is to take pleasure in his work. 

# For what is there no comforter?

There is no comforter for the tears of the oppressed. 

# Who is more fortunate than both the living and the dead?

More fortunate than both the living and the dead is the one who has not yet lived. 

# What is better than two handfuls with the work that tries to shepherd the wind?

Better is a handful of profit with quiet work than two handfuls with the work that tries to shepherd the wind. 

# Why are two people better than one in the case that one falls?

Two people are better than one because if one falls, the other can lift up his friend. 

# Why are two people better than one in the case that one falls?

Two people are better than one because if one falls, the other can lift up his friend. 

# What is not quickly broken?

A three-strand rope is not quickly broken. 

# What is better than to be an old and foolish king?

It is better to be a poor but wise youth than an old and foolish king. 

# What do people want to do to the new king?

People want to obey the new king. 

# Why should people go to the house of God?

People should go to the house of God to listen. 

# Why should people let their words be few?

God is in heaven, but people are on earth, so they should let their words be few. 

# What is better for a person to do than to make a vow that he does not carry out?

It is better for a person not to make a vow than to make a vow that he does not carry out. 

# When someone sees the poor being oppressed and robbed of just and right treatment, why should no one be astonished as if no one knows?

When someone sees the poor being oppressed and robbed of just and right treatment, he should not be astonished because there are men in power who watch those under them, and there are even higher ones over them. 

# What happens as prosperity increases?

As prosperity increases, so also do the people who consume it. 

# What does not allow a rich person to sleep well?

The wealth of a rich person does not allow him to sleep well. 

# What happens when the rich man loses his wealth through bad luck?

When the rich man loses his wealth through bad luck, his own son, one whom he has fathered, is left with nothing in his hands. 

# How is a man born and how will he leave this life?

A man is born naked from his mother's womb, so also he will leave this life naked. 

# Why does a person not call to mind very often the days of his life?

A person does not call to mind very often the days of his life, because God makes him keep busy with the things that he enjoys doing. 

# What evil did the Teacher see?

The Teacher saw that God might give riches, wealth, and honor to a man so that he lacks nothing that he desires for himself, but then God gives him no ability to enjoy it. Instead, someone else uses his things. 

# What evil did the Teacher see?

The Teacher saw that God might give riches, wealth, and honor to a man so that he lacks nothing that he desires for himself, but then God gives him no ability to enjoy it. Instead, someone else uses his things. 

# If a man's heart is not satisfied with good and he is not buried with honor, who is better off than he is?

If a man's heart is not satisfied with good and he is not buried with honor, then a baby that is born dead is better off than he is. 

# Even if a man should live for two thousand years but does not learn to enjoy good things, where does he go?

Even if a man should live for two thousand years but does not learn to enjoy good things, he goes to the same place as everyone else. 

# Though all a man's work is to fill his mouth, what happens?

Though all a man's work is to fill his mouth, yet his appetite is not filled. 

# What happens the more words that are spoken?

The more words that are spoken, the more futility increases. 

# Why is it better to go to a house of mourning than to a house of feasting?

It is better to go to a house of mourning than to a house of feasting, for mourning comes to all people at the end of life. 

# Where is the heart of the wise?

The heart of the wise is in the house of mourning. 

# What is the laughter of fools like?

Like the crackling of thorns burning under a pot, so also is the laughter of fools. 

# What makes a wise man foolish?

Extortion makes a wise man foolish. 

# Why should people not be quick to anger in their spirit?

People should not be quick to anger in their spirit, for anger resides in the hearts of fools. 

# How is wisdom better than money?

Wisdom provides protection as money can provide protection, but the advantage of knowledge is that wisdom gives life to whoever has it. 

# When times are good, how should people live?

When times are good, people should live happily in that good. 

# What happened to wicked people whom the Teacher saw?

The Teacher saw wicked people who live a long life in spite of their evil. 

# What will happen for the person who fears God?

The person who fears God will meet all his obligations. 

# Why should people not listen to every word that is spoken?

People should not listen to every word that is spoken because they might hear their servant curse them. 

# Where is wisdom?

Wisdom is far off. 

# By whom will the sinner be taken?

The sinner will be taken by a woman whose heart is full of snares and nets, and whose hands are chains. 

# Although the Teacher found one righteous man among a thousand, what did he not find?

Although the Teacher found one righteous man among a thousand, a woman among all those he did not find. 

# What is a wise man?

A wise man is someone who knows what the events in life mean. 

# Why should people not hurry out of the king's presence, and should not stand in support of something wrong?

People should not hurry out of the king's presence, and should not stand in support of something wrong, for the king does whatever he desires. 

# Who avoids harm?

Whoever keeps the king's commands avoids harm. 

# Over what does no one have power?

No one has power over the breath of life to stop breathing, and no one has power over the day of his death. 

# By whom were the wicked praised?

The wicked were praised by people in the city where they had done their wicked deeds. 

# Even if a sinner does evil a hundred times and still lives for a long time, what will happen to those who respect God?

Even if a sinner does evil a hundred times and still lives for a long time, it will be well with those who respect God, who honor his presence with them. 

# Why does the Teacher recommend happiness?

The Teacher recommends happiness, because a man has no better thing under the sun than to eat and drink and to be happy. 

# What can man not understand?

Man cannot understand the work that is done under the sun. 

# Who is in God's hands?

The righteous and wise people are all in God's hands. 

# What is the same for everyone?

Everyone has the same fate. 

# Of what are the hearts of human beings full?

The hearts of human beings are full of evil. 

# Why do the dead no longer have any reward?

They no longer have any reward because their memory is forgotten. 

# What vanished long ago?

The dead people's love, hatred, and envy vanished long ago. 

# What should people do with whatever their hand finds to do?

Whatever their hand finds to do, they should work at it with their strength. 

# In what are human beings imprisoned?

Human beings are imprisoned in evil times that suddenly fall on them. 

# What happened to the poor, wise man, who by his wisdom saved the city?

No one remembered the poor, wise man, who by his wisdom saved the city. 

# What is better than weapons of war?

Wisdom is better than weapons of war. 

# What proves to everyone that a man is a fool?

When a man's thinking is deficient, this proves to everyone that he is a fool. 

# What did the Teacher see slaves doing?

The Teacher saw slaves riding horses. 

# What can happen whenever someone breaks down a wall?

Whenever someone breaks down a wall, a snake can bite him. 

# What happens if a man does not sharpen a dull iron blade?

If a man does not sharpen a dull iron blade, then he must use more strength. 

# At the end, with what does a fool's mouth flow?

At the end, a fool's mouth flows with wicked madness. 

# When is there trouble in the land?

There is trouble in the land if the king is young, and the leaders begin feasting in the morning! 

# Why does the house leak?

Because of idle hands the house leaks. 

# Why should people not curse the king?

People should not curse the king, for a bird of the sky might carry their words. 

# Why should people share bread with seven, even eight people?

People should share it with seven, even eight people, for they do not know what disasters are coming on the earth. 

# What can people not comprehend?

People cannot comprehend the work of God. 

# For how long should people plant seed?

People should plant seed in the morning until the evening. 

# What should people drive away from their heart?

People should drive anger away from their heart. 

# When should people call to mind their Creator?

People should call to mind their Creator in the days of their youth. 

# Why will women who grind cease?

The women who grind will cease because they are few. 

# At what will men be startled?

Men will be startled at the voice of a bird. 

# Where will the dust return?

The dust will return to the earth from where it came. 

# What did the Teacher teach people?

The Teacher taught the people knowledge. 

# Like what are the words of the wise?

The words of the wise are like goads. 

# What does much study bring?

Much study brings weariness to the body. 

# What is the end of the matter?

The end of the matter is that people must fear God and keep his commandments. 

