# Who would lead the people of Israel when they went up against the Canaanites to fight against them?

Judah would lead the people of Israel against the Canaanites to fight against them. 

# Against whom did the men of Judah fight?

The men of Judah fought against Adoni Bezek. 

# Against whom did the men of Judah fight?

The men of Judah fought against Adoni Bezek. 

# Who gathered their food from under Adoni Bezek's table?

Seventy kings, who had their thumbs and their big toes cut off, gathered their food from under Adoni Bezek's table. 

# What was the previous name of Hebron?

The name of Hebron was previously Kiriath Arba. 

# What did Caleb give to Othniel?

Caleb gave Achsah, his daughter, to be Othniel's wife. 

# What did Caleb give to Othniel?

Caleb gave Achsah, his daughter, to be Othniel's wife. 

# Since Achsah was in Negev, what did she want her father to give her?

Since Achsah was in Negev, she wanted him to give her springs of water. 

# Where is the wilderness of Judah?

The wilderness of Judah is in the Negev. 

# Why could the people of Judah not drive out the inhabitants of the plains?

They could not drive out the inhabitants of the plains because the inhabitants had iron chariots. 

# Why did the Jebusites live with the people of Benjamin in Jerusalem?

Because the people of Benjamin did not drive out the Jebusites who inhabited Jerusalem, the Jebusites lived with the people of Benjamin in Jerusalem. 

# What happened to the man who showed the spies from the house of Joseph how to get into Bethel?

The spies let the man and his family get away and the man went to the land of the Hittites and built a city and called it Luz. 

# What happened to the man who showed the spies from the house of Joseph how to get into Bethel?

The spies let the man and his family get away and the man went to the land of the Hittites and built a city and called it Luz. 

# When Israel became strong, what did they do to the Canaanites?

When Israel became strong, they forced the Canaanites to serve them with hard labor, but they never drove them out completely. 

# Why did the tribe of Asher live among the Canaanites?

The tribe of Asher lived among the Canaanites, because Asher did not drive them out. 

# Who conquered the Amorites at Mount Heres, in Aijalon, and in Shaalbim?

The house of Joseph conquered them. 

# Who conquered the Amorites at Mount Heres, in Aijalon, and in Shaalbim?

The house of Joseph conquered them. 

# Where did the angel of Yahweh bring the people of Israel?

The angel of Yahweh brought them to the land he swore to give to their fathers. 

# When the angel said he would not drive the Canaanites out before the people of Israel, what did they do?

When the angel said he would not drive the Canaanites out before the people of Israel, they shouted and wept. 

# When the angel said he would not drive the Canaanites out before the people of Israel, what did they do?

When the angel said he would not drive the Canaanites out before the people of Israel, they shouted and wept. 

# How long did the people serve Yahweh?

The people served Yahweh during the lifetime of Joshua and of the elders who outlived him. 

# What gods did the people of Israel go after?

The people of Israel went after the very gods of the peoples who were around them. 

# What had Yahweh sworn to Israel?

Yahweh had sworn that wherever Israel went out to fight, Yahweh's hand would be against them to defeat them. 

# What did the judges do?

The judges saved the people of Israel from the power of those who were stealing their possessions. 

# What happened when the judge died?

When the judge died, the people of Israel would turn away and do things that were even more corrupt than their fathers had done. 

# Why would Yahweh not drive out from Israel any of the nations that Joshua left when he died?

Yahweh would not drive out from Israel any of the nations that Joshua left when he died, so that Yahweh could test Israel, whether or not they would keep the way of Yahweh and walk in it, as their fathers kept it. 

# Why would Yahweh not drive out from Israel any of the nations that Joshua left when he died?

Yahweh would not drive out from Israel any of the nations that Joshua left when he died, so that Yahweh could test Israel, whether or not they would keep the way of Yahweh and walk in it, as their fathers kept it. 

# Why did Yahweh leave nations to test Israel?

Yahweh left nations to test Israel to teach warfare to the new generation of the Israelites who had not known it before. 

# What would Yahweh do by means of the remaining nations?

Yahweh would test Israel by means of the remaining nations, to confirm whether they would obey the commands he gave their ancestors through Moses. 

# What did the people of Israel worship?

They worshiped the Baals and the Asherahs. 

# Who did Yahweh first raise up, who would come to help the people of Israel?

Yahweh first raised up Othniel the son of Kenaz, Caleb's younger brother. 

# Who gave strength to Eglon the king of Moab?

Yahweh gave strength to Eglon the king of Moab. 

# When did Yahweh raise up Ehud to help the people of Israel?

Yahweh raised up Ehud to help the people of Israel when they called out to him. 

# Where did Ehud strap on the sword he made?

He strapped it on under his clothing on his right thigh. 

# Who was with Ehud and the king when Ehud told him the message?

Only Ehud and the king were there. 

# Who was with Ehud and the king when Ehud told him the message?

Only Ehud and the king were there. 

# Why did fat close over the blade?

Fat closed over the blade, for Ehud did not draw the sword out of the king's body. 

# When the king's servants saw that the doors of the upper room were locked, what did they think?

When the king's servants saw that the doors of the upper room were locked, they thought he was relieving himself in the coolness of the upper room. 

# When did Ehud escape?

While the servants were waiting, wondering what they should do, Ehud escaped. 

# How did the people of Israel prevent the Moabites from crossing the river?

The people of Israel captured the fords of the Jordan across from the Moabites. 

# With what did Shamgar kill 600 Philistines?

Shamgar killed the Philistines with a stick used to goad the cattle. 

# Why did the people of Israel call out to Yahweh for help?

The people of Israel called out to Yahweh for help, because Sisera had nine hundred iron chariots and he oppressed the people of Israel with force for twenty years. 

# Why did the people of Israel come to Deborah?

The people of Israel came to Deborah to settle their disputes. 

# Where would Yahweh cause Sisera to meet Barak?

Yahweh would cause Sisera to meet Barak by the river Kishon. 

# Why would Yahweh make a woman defeat Sisera?

Yahweh would make a woman defeat Sisera because Barak did not go without Deborah. 

# Why would Yahweh make a woman defeat Sisera?

Yahweh would make a woman defeat Sisera because Barak did not go without Deborah. 

# From whom did the Kenites descend?

The Kenites descended from Hobab, Moses' father-in-law. 

# How many of the army of Sisera survived?

None of the army of Sisera survived. 

# Why did Sisera go to the tent of Jael?

Sisera went to the tent of Jael, for there was peace between Jabin the king of Hazor, and the house of Heber, Jael's husband. 

# When Sisera asked for water, what did Jael give him?

When Sisera asked for water, Jael gave him milk. 

# How did Jael kill Sisera?

Jael hammered the tent peg into the side of his head and it pierced through him and went down into the ground. 

# When did the earth shake?

The earth shook when Yahweh went out from Seir, when he marched from Edom. 

# What paths did those who walked use?

Those who walked used the winding paths. 

# What was not seen among forty thousand in Israel?

Neither shields nor spears were seen among forty thousand in Israel. 

# What things were used as saddles on the white donkeys?

Rugs were used as saddles on the white donkeys . 

# To whom did the people of Yahweh come down?

The people of Yahweh came down to Deborah among the warriors. 

# What was Issachar doing with Barak?

Issachar was rushing after Barak into the valley under his command. 

# What would Zebulun risk?

Zebulun would risk their lives to the point of death. 

# What fought against Sisera from their paths across the heavens?

The stars fought against Sisera from their paths across the heavens. 

# Why did the angel of Yahweh curse Meroz?

The angel of Yahweh cursed Meroz because they did not come to help Yahweh. 

# To what did Jael put her hand?

She put her hand to the tent peg, and her right hand to the workman's hammer. 

# Where did the mother of Sisera look out?

The mother of Sisera looked out of a window, through the lattice. 

# Like what should those who love Yahweh be?

Those who love Yahweh should be like the sun when it rises in its might. 

# What did the people of Israel do because of Midian?

Because of Midian, the people of Israel made shelters for themselves from the dens in the hills, the caves, and the strongholds. 

# What happened any time the Israelites planted their crops?

Any time the Israelites planted their crops, the Midianites, and the Amalekites, and the people from the east would attack the Israelites. 

# How many Midianites and Amalekites would attack?

It was impossible to count them. 

# In whose land were the people of Israel living?

They were living in the land of the Amorites. 

# Why was Gideon separating out the wheat by beating it on the floor, in the winepress?

Gideon was separating out the wheat by beating it on the floor, in the winepress to hide it from the Midianites. 

# What did Gideon think Yahweh had done to the people of Israel?

Gideon thought Yahweh had abandoned them and had given them over to the power of Midian. 

# Why did Gideon think he could not deliver Israel?

Gideon thought he could not deliver Israel because his family was the weakest in Manasseh, and he was the least important in his father's house. 

# Why did Yahweh wait for Gideon?

Yahweh waited for Gideon to bring him a gift. 

# Where did the angel of God tell Gideon to put the meat and unleavened bread?

The angel of God told Gideon to put the meat and unleavened bread on a rock. 

# What happened when the angel of Yahweh reached out with the end of the staff in his hand?

When the angel of Yahweh reached out with the end of the staff in his hand, he touched the flesh and the unleavened bread; a fire went up out of the rock and consumed the meat and the unleavened bread. 

# Why was Gideon afraid when he understood that he had seen the angel of Yahweh?

Gideon was afraid when he understood that he had seen the angel of Yahweh because he thought he would die. 

# Why was Gideon afraid when he understood that he had seen the angel of Yahweh?

Gideon was afraid when he understood that he had seen the angel of Yahweh because he thought he would die. 

# What did Yahweh tell Gideon to build on the top of the place of refuge?

Yahweh told him to build an altar to Yahweh on the top of the place of refuge. 

# Why did Gideon do what Yahweh told him to do at night?

Gideon did what Yahweh told him to do at night because he was too afraid of his father's household and the men of the town to do it during the day. 

# Why did the men of the town want to put Gideon to death?

The men wanted to put Gideon to death, because he pulled apart the altar of Baal, and because he cut down the Asherah beside it. 

# Why was Gideon given the name, "Jerub Baal"?

Gideon was given the name, "Jerub Baal," because he said, "Let Baal defend himself against him," because Gideon pulled apart his altar. 

# What did Gideon do to find out if Yahweh intended to use him to save Israel?

Gideon put a woolen fleece on the threshing floor. He said that if there was dew only on the fleece, and it was dry on all the ground, then he would know that Yahweh would use him to save Israel. 

# What did Gideon do to find out if Yahweh intended to use him to save Israel?

Gideon put a woolen fleece on the threshing floor. He said that if there was dew only on the fleece, and it was dry on all the ground, then he would know that Yahweh would use him to save Israel. 

# When Gideon pressed the fleece together, and wrung out the dew from the fleece, how much water was there?

When Gideon pressed the fleece together, and wrung out the dew from the fleece, there was enough water to fill a bowl. 

# What was Gideon's second test for God?

Gideon's second test was for God to make the fleece dry, and let there be dew on all the ground around it. 

# Why did Yahweh have the fearful soldiers return?

Yahweh had the fearful soldiers return so that Israel could not boast against Yahweh saying, "Our own power has saved us." 

# Why did Yahweh have the fearful soldiers return?

Yahweh had the fearful soldiers return so that Israel could not boast against Yahweh saying, "Our own power has saved us." 

# Why did Yahweh tell Gideon to take the soldiers down to the water?

Yahweh wanted to make the number of soldiers smaller by telling Gideon which ones would go with him. 

# How did Yahweh tell Gideon to separate the soldiers?

Yahweh told Gideon to separate everyone who lapped up the water, as a dog laps. 

# How many soldiers did Gideon keep?

Gideon kept three hundred soldiers and sent the rest home. 

# How many soldiers did Gideon keep?

Gideon kept three hundred soldiers and sent the rest home. 

# If Gideon was afraid, what would strengthen Gideon's courage?

If Gideon was afraid, he was told to go down to the camp, and listen to what they were saying, and his courage would be strengthened to attack the camp. 

# If Gideon was afraid, what would strengthen Gideon's courage?

If Gideon was afraid, he was told to go down to the camp, and listen to what they were saying, and his courage would be strengthened to attack the camp. 

# When one man was telling a dream to his companion, who did the companion say the dream was about?

When one man was telling a dream to his companion, the companion said the dream was about Gideon. God had given him victory over Midian and all their army. 

# When one man was telling a dream to his companion, who did the companion say the dream was about?

When one man was telling a dream to his companion, the companion said the dream was about Gideon. God had given him victory over Midian and all their army. 

# What did Gideon give his three hundred soldiers?

Gideon gave them all trumpets and empty jars, with torches inside each jar. 

# When did Gideon's soldiers blow the trumpets and break the jars that were in their hands?

Just as the Midianites were changing the guard, Gideon's soldiers blew the trumpets and broke the jars that were in their hands. 

# When the soldiers blew the three hundred trumpets, what did Yahweh do?

When they blew the three hundred trumpets, Yahweh set every Midianite man's sword against his comrads and against all their army. 

# How far did the men of Ephraim gather together and take control of the waters?

The men of Ephraim gathered together and took control of the waters, as far as Beth Barah and the Jordan River. 

# Why did the men of Ephraim argue with Gideon?

The men of Ephraim argued with Gideon because he had not called them when he went to fight against Midian. 

# For what did Gideon ask the men of Succoth?

Gideon asked the men of Succoth for loaves of bread for the people who followed him. 

# Why did Gideon tell the men of Penuel that he would pull down the tower?

Gideon told the men of Penuel that he would pull down the tower because they would not give his army bread, just as the men of Succoth refused. 

# Why did Gideon tell the men of Penuel that he would pull down the tower?

Gideon told the men of Penuel that he would pull down the tower because they would not give his army bread, just as the men of Succoth refused. 

# Why did Gideon tell the men of Penuel that he would pull down the tower?

Gideon told the men of Penuel that he would pull down the tower because they would not give his army bread, just as the men of Succoth refused. 

# Why did Gideon defeat the enemy army past Nobah and Jogbehah?

Gideon defeated the enemy army, because they were not expecting an attack. 

# Who did Gideon show to the men of Succoth before he punished them?

Gideon showed Zebah and Zalmunna to the men of Succoth before he punished them. 

# Who did Gideon show to the men of Succoth before he punished them?

Gideon showed Zebah and Zalmunna to the men of Succoth before he punished them. 

# What kind of men did Zebah and Zalmunna kill at Tabor?

Zebah and Zalmunna killed Gideon's brothers. 

# What kind of men did Zebah and Zalmunna kill at Tabor?

Zebah and Zalmunna killed Gideon's brothers. 

# Why did Jether not draw his sword?

Jether did not draw his sword for he was afraid, because he was still a young boy. 

# Who did Gideon say would rule over the men of Israel?

Gideon said Yahweh would rule over the men of Israel. 

# For what did Gideon ask the men of Israel?

Gideon asked them for the earrings of their plunder. 

# What did Gideon make out of the earrings?

Gideon made an ephod out of the earrings. 

# What did Israel do to the golden ephod?

Israel prostituted themselves by worshiping it. 

# What happened as soon as Gideon was dead?

As soon as Gideon was dead, the people of Israel turned again and prostituted themselves by worshiping the Baals. 

# Who was Abimelech's father?

Abimelech's father was Jerub Baal. 

# Why did Abimelech's mother's relatives agree to follow him?

They agreed to follow Abimelech, for they said, "He is our brother." 

# For what did Abimelech use the seventy pieces of silver?

Abimelech used the seventy pieces of silver to hire men of lawless and reckless character. 

# Why was Jotham not murdered?

Jotham was not murdered, for he hid himself. 

# On what day did Jotham address the leaders of Shechem?

Jotham addressed them on the same day they had risen up against his father's house and killed his sons, seventy persons, upon one stone. 

# On what day did Jotham address the leaders of Shechem?

Jotham addressed them on the same day they had risen up against his father's house and killed his sons, seventy persons, upon one stone. 

# If the people acted with honesty and integrity with Jerub Baal and his house, what should happen?

If the people acted with honesty and integrity with Jerub Baal and his house, fire should come out from Abimelech and burn up the men of Shechem and the house of Millo. Fire should come out from the men of Shechem and Beth Millo, to burn up Abimelech. 

# What was the curse of Jotham?

The curse of Jotham was for fire to come out from Abimelech and burn up the men of Shechem and the house of Millo, for fire to come out from the men of Shechem and Beth Millo, to burn up Abimelech. 

# Why did God send an evil spirit between Abimelech and the leaders of Shechem?

God sent an evil spirit between Abimelech and the leaders of Shechem so the violence done to the seventy sons of Jerub Baal might be avenged. 

# Why did God send an evil spirit between Abimelech and the leaders of Shechem?

God sent an evil spirit between Abimelech and the leaders of Shechem so the violence done to the seventy sons of Jerub Baal might be avenged. 

# Who did the leaders of Shechem hope to ambush?

The leaders of Shechem hoped to ambush Abimelech. 

# Who wished to command the people?

Gaal wished to command the people. 

# Who wished to command the people?

Gaal wished to command the people. 

# Why was Zebul's anger kindled?

When Zebul heard the words of Gaal (the son of Ebed), his anger was kindled. 

# Why did Zebul send messengers to Abimelech?

He sent messengers to Abimelech in order to deceive him. 

# How did Zebul describe the men on the hilltops?

Zebul said they were shadows on the hills. 

# What did Zebul tell Gaal to do?

Zebul told Gaal to go out and fight against Abimelech. 

# What happened when Gaal fought Abimelech?

Abimelech chased Gaal and Gall fled before Abimelech and many fell with deadly wounds before the entrance to the city gate. 

# What did Abimelech do after he captured the city?

Abimelech tore down the city walls and spread salt over it. 

# Where did the leaders of the tower of Shechem enter?

The leaders of the tower of Shechem entered the stronghold of the house of El Berith. 

# How did Abimelech kill all the leaders and people in the tower of Shechem?

Abimelech went up to Mount Zalmon, piled branches on top of the underground chamber, and set it on fire above it. 

# How did Abimelech kill all the leaders and people in the tower of Shechem?

Abimelech went up to Mount Zalmon, piled branches on top of the underground chamber, and set it on fire above it. 

# When Abimelech came near the door of the tower of Thebez, what happened to him?

When Abimelech came near the door of the tower of Thebez, a woman dropped an upper millstone on his head and it cracked his skull. 

# When Abimelech came near the door of the tower of Thebez, what happened to him?

When Abimelech came near the door of the tower of Thebez, a woman dropped an upper millstone on his head and it cracked his skull. 

# Why did Abimelech tell his armor-bearer to draw his sword and kill him?

Abimelech told his armor-bearer to draw his sword and kill him, so no one would say a women killed Abimelech. 

# What was the curse of Jotham?

The curse of Jotham was for fire to come out from Abimelech and burn up the men of Shechem and the house of Millo, for fire to come out from the men of Shechem and Beth Millo, to burn up Abimelech. 

# Where was Shamir?

Shamir was in the hill country of Ephraim. 

# Why did Yahweh burn with anger toward the people of Israel?

The people of Israel abandoned Yahweh and no longer worshiped him, so he burned with anger toward Israel. 

# Why did Yahweh burn with anger toward the people of Israel?

The people of Israel abandoned Yahweh and no longer worshiped him, so he burned with anger toward Israel. 

# Why was Israel greatly distressed?

Ammonites crossed over the Jordan to fight against Judah, against Benjamin, and against the house of Ephraim, so that Israel was greatly distressed. 

# To whom did Yahweh tell the people of Israel to call out for help?

Yahweh told the people to call out to the gods that they had worshiped. 

# Why did Yahweh become impatient over the misery of Israel?

Israel turned away from the foreign gods they owned and they worshiped Yahweh, so he became impatient over the misery. 

# Of whom was Jephthah the son?

Jephthah was the son of a prostitute. 

# Why did the elders of Gilead go to bring Jephthah back from the land of Tob?

The elders of Gilead went to bring Jephthah back from the land of Tob so he would be their leader. 

# Why did the elders of Gilead go to bring Jephthah back from the land of Tob?

The elders of Gilead went to bring Jephthah back from the land of Tob so he would be their leader. 

# Why were the elders of Gildead turning to Jephthah?

The elders of Gildead were turning to Jephthah because they were in trouble. 

# Why were the elders of Gildead turning to Jephthah?

The elders of Gildead were turning to Jephthah because they were in trouble. 

# If the elders of Gildeon brought Jephthah home again to fight against the soldiers of Ammon, and if Yahweh gave them victory over them, what would happen to Jephthah?

If the elders of Gildeon brought Jephthah home again to fight against the soldiers of Ammon, and if Yahweh gave them victory over them, Jephthah would be their leader. 

# Why did the people of Ammon come with force to take the land of Israel?

The people of Ammon came with force to take the land of Israel because when Israel came up out of Egypt, they seized the land of Ammon. 

# Why did the people of Ammon come with force to take the land of Israel?

The people of Ammon came with force to take the land of Israel because when Israel came up out of Egypt, they seized the land of Ammon. 

# Who was not willing to let Israel pass?

The king of Edom and the king of Moab were not willing to let Israel pass. 

# Why did Israel not go into the territory of Moab?

They did not go into the territory of Moab, for the Arnon was Moab's border. 

# Who gave Israel victory over Sihon?

Yahweh, the God of Israel, gave Israel victory over Sihon. 

# For how long did Israel live in Heshbon and its villages, and in Aroer and its villages, and in all the cities that are along the banks of the Arnon?

Israel lived for three hundred years in Heshbon and its villages, and in Aroer and its villages, and in all the cities that are along the banks of the Arnon. 

# If Yahweh gave Jephthah victory over the people of Ammon, what would Jephthah do?

If Yahweh gave Jephthah victory over the people of Ammon, Jephthah would offer up as a burnt offering whatever came out of the doors of his house to meet him. 

# When Jephthah passed through to the people of Ammon to fight against them, who gave him the victory?

When Jephthah passed through to the people of Ammon to fight against them, Yahweh gave him victory. 

# How many children did Jephthah have?

Jephthah had only one child. 

# What did Jephthah's daughter want to do before he did everything he had promised?

She wanted him to leave her alone for two months, that she could leave and go down to the hills and grieve over her virginity. 

# What did Jephthah's daughter want to do before he did everything he had promised?

She wanted him to leave her alone for two months, that she could leave and go down to the hills and grieve over her virginity. 

# What did Jephthah do with his daughter?

He did with her according to the promise of the vow he had made. 

# What did the men of Ephraim want to do to Jephthah's house because he did not call them to go with him?

Ephraim wanted to burn Jephthah's house down over him because he did not call them to go with him to fight against the people of Ammon. 

# Why did the men of Gilead attack the men of Ephraim?

The men of Gilead attacked the men of Ephraim because they said, "You Gileadites are fugitives from Ephraim—from within Ephraim and Manasseh." 

# How did the men of Gilead test if a man was from Ephraim?

They would tell him to say "Shibboleth." And if he said, "Sibboleth," (for he could not pronounce the word correctly), the Gileadites would seize him and kill him at the fords of the Jordan. 

# How did the men of Gilead test if a man was from Ephraim?

They would tell him to say "Shibboleth." And if he said, "Sibboleth," (for he could not pronounce the word correctly), the Gileadites would seize him and kill him at the fords of the Jordan. 

# Why had Manoah's wife not given birth?

Manoah's wife was not able to become pregnant and so she had not given birth. 

# Why was no razor to come onto the child's head?

No razor was to come onto his head, for the child was to be a Nazirite to God. 

# Like what did the man of God look?

The man of God looked like an angel of God. 

# When the angel of God came a second time, who was there?

When the angel of God came a second time, only Manoah's wife was there. 

# About what did Manoah ask the angel?

Manoah asked the angel about the rules for the child and what his work would be. 

# If Manoah prepared a burnt offering, to whom was he to offer it?

If Manoah prepared a burnt offering, he was to offer it to Yahweh. 

# What marvelous thing did Yahweh do while Manoah and his wife were watching?

While Manoah and his wife were watching, the angel of Yahweh went up in the flame of the altar. 

# What marvelous thing did Yahweh do while Manoah and his wife were watching?

While Manoah and his wife were watching, the angel of Yahweh went up in the flame of the altar. 

# Where did Yahweh's Spirit begin to stir Samson?

Yahweh's Spirit began to stir Samson in Mahaneh Dan. 

# Who did Samson want his parents to get for him to be his wife?

Samson wanted his parents to get a woman in Timnah, one of the daughters of the Philistines, for him to be his wife. 

# Why did Samson want his parents to get him the woman in Timnah as his wife?

He wanted his parents to get him the woman in Timnah as his wife, for when he looked at her, she pleased him. 

# How was Samson able to tear the lion apart?

Yahweh's Spirit suddenly came on him, and he tore the lion apart. 

# What was in the carcass of the lion?

There was a swarm of bees and honey in the carcass of the lion. 

# What would Samson get if the thirty friends could not answer his riddle?

Samson would get thirty linen robes and thirty sets of clothes if the thirty friends could not answer his riddle. 

# What would happen to Samson's wife if she did not trick her husband and get the answer to the riddle?

If Samson's wife did not trick her husband and get the answer to the riddle, the thirty friends would burn up her and her father's houses. 

# For how long did Samson's wife cry in order to get the answer to the riddle?

She cried during the seven days that their feast lasted. 

# How did Samson get thirty sets of clothing?

Samson went down to Ashkelon and killed thirty men among those people and took their sets of clothing. 

# When Samson went to visit his wife, why did her father not allow him to go in?

The father thought Samson hated his wife, so the father gave her to Samson's friend. 

# How did Samson try to be innocent in regard to the Philistines when he hurt them?

Samson tried to be innocent in regard to the Philistines when he hurt them by catching three hundred foxes, tying torches to them, and letting them go in the Philistines' grain. 

# How did Samson try to be innocent in regard to the Philistines when he hurt them?

Samson tried to be innocent in regard to the Philistines when he hurt them by catching three hundred foxes, tying torches to them, and letting them go in the Philistines' grain. 

# When the Philistines were told that Samson burned their fields, what did they do?

When the Philistines were told that Samson burned their fields, they burned his wife and her father. 

# Why did Samson cut the Philistines to pieces, hip and thigh, with a great slaughter?

Samson cut the Philistines to pieces, hip and thigh, with a great slaughter to get revenge on them for killing his wife and her father. 

# Why did Samson cut the Philistines to pieces, hip and thigh, with a great slaughter?

Samson cut the Philistines to pieces, hip and thigh, with a great slaughter to get revenge on them for killing his wife and her father. 

# Why did the Philistines come up to attack Judah?

The Philistines came up to attack Judah so they could capture Samson, and so they could do to him as he did to them. 

# Why did the Philistines come up to attack Judah?

The Philistines came up to attack Judah so they could capture Samson, and so they could do to him as he did to them. 

# When the men of Judah came to tie Samson up, what did he make them swear?

When the men of Judah came to tie Samson up, he made them swear that they would not kill him themselves. 

# With what did Samson kill a thousand men?

Samson killed a thousand men with a fresh jawbone of a donkey. 

# After Samson killed a thousand men with a fresh jawbone of a donkey, how did he think he would die?

After Samson killed a thousand men with a fresh jawbone of a donkey, he thought he would die of thirst. 

# How did Samson get water?

God split open the hollow place at Lehi, and water came out. 

# When did the Gazites plan to kill Samson?

The Gazites planned to kill Samson at daylight. 

# How did Samson escape Gaza?

Samson took hold of the city gate and its two posts, and he pulled them up out of the ground, bar and all. 

# If Delilah tricked Samson, what would the rulers of the Philistines give her?

If Delilah tricked Samson, each of the rulers of the Philistines would give her 1,100 pieces of silver. 

# When Delilah told Samson the Philistines were on him, what did he do to the bowstrings with which he was tied?

When Delilah told Samson the Philistines were on him, he broke the bowstrings. 

# When Samson tore off the ropes from his arms, where were the men lying in wait?

When Samson tore off the ropes from his arms, the men lying in wait were in the inner room. 

# How much did Delilah pressure Samson?

She so pressured him that he wished he would die. 

# Why had Samson never had a razor cut the hair on his head?

Samson had never had a razor cut the hair on his head, for he had been a Nazirite for God from his mother's womb. 

# How was Delilah able to begin to subdue Samson?

Delilah began to subdue him when the locks of his head were shaven off, for his strength left him. 

# What work did the Philistines make Samson do?

The Philistines made Samson turn the millstone at the prison house. 

# Why did the rulers of the Philistines gather together to offer a great sacrifice to Dagon their god?

The rulers of the Philistines gathered together to offer a great sacrifice to Dagon their god, for they said, "Our god has conquered Samson." 

# Who helped Samson touch the pillars on which the building rested?

The boy who held Samson's hand helped Samson touch the pillars on which the building rested. 

# Why did Samson want God to strengthen him?

Samson wanted God to strengthen him so that he could have revenge in one blow on the Philistines for taking his two eyes. 

# How many people did Samson kill when the building fell?

Samson killed more than those he killed during his life. 

# What did Micah steal?

Micah stole the 1,100 pieces of silver that were taken from his mother. 

# For what did Micah's mother set apart the silver?

She set apart the silver to Yahweh, for her son to make a carved wooden figure and a cast metal figure. 

# To what did Micah dedicate one of his sons?

He dedicated one of his sons to become his priest. 

# Why did the Levite leave Bethlehem?

The Levite left Bethlehem to go and find a place to live. 

# What did Micah ask the Levite to be to him?

Micah asked the Levite to live with him and be an adviser and a priest to him. 

# Why did Micah think Yahweh would do good for him?

Micah thought Yahweh would do good for him, because a Levite became his priest. 

# Why was the tribe of the descendants of Dan looking for a territory on which to live?

The tribe of the descendants of Dan waslooking for a territory to live on, for up to that day they had not received any inheritance from among the tribes of Israel. 

# What did the people of Dan want the Levite to seek?

The people of Dan wanted the Levite to seek the advice of God. 

# What did the five men from Dan want to do with the land of Laish?

The five men from Dan wanted to conquer the land. 

# What did the five men say was in the houses of Laish?

The five men said that in the houses of Laish there were an ephod, household gods, a carved figure, and a cast metal figure. 

# Who took the carved figure?

The five men who had gone to scout out the land went there and they took the carved figure. 

# Why was Micah angry?

Micah was angry because the Danites stole the gods he made, they took the priest, and they were leaving. 

# When did Micah turn and go back to his house?

When Micah saw that they were too strong for him, he turned and went back to his house. 

# Why was there no one to rescue the people of Laish?

There was no one to rescue the people because it was a long way from Sidon, and they had no dealings with anyone. 

# Who were the priests for the tribe of the Danites?

Jonathan the son of Gershom (the son of Moses), he and his sons were priests for the tribe of the Danites until the day of the land's captivity. 

# Where was the Levite living?

The Levite was living for a while in the most remote area of the hill country of Ephraim. 

# Where did the Levite's concubine bring him?

The concubine brought the Levite into the house of her father. 

# Although the Levite intended to go home, what did his father-in-law want him to do?

His father-in-law wanted him to stay and spend the night. 

# Although the Levite intended to go home, what did his father-in-law want him to do?

His father-in-law wanted him to stay and spend the night. 

# What did the Levite do about his plan to leave early and go home?

He changed his plan and spent the night with his father-in-law. 

# What did the Levite's father-in-law ask him to do again on the fifth day?

His father-in-law asked him to stay another night and have a good time. 

# Why did the Levite not want to spend the night in Jebus?

The Levite did not want to turn aside into a city of foreigners. 

# Why did the Levite and his servant sit down in the city square?

They sat down in the city square, for no one took them into his house for the night. 

# From what tribe were the men living in Gibeah?

The men living in Gibeah were Benjamites. 

# What did the old man warn the Levite not to do?

The old man warned the Levite not to spend the night in the square. 

# Why did the wicked men of the city want the old man to bring out the man who came into his house?

The wicked men of the city wanted the old man to bring out the man who came into his house, so they could have sex with him. 

# Who did the old man offer to the wicked men in place of the Levite?

The old man offered them his virgin daughter and the Levite's concubine. 

# What happened at dawn?

At dawn the wicked men let the concubine go. She came and she fell down at the door of the man's house where her master was, and she lay there until it was light. 

# What happened at dawn?

At dawn the wicked men let the concubine go. She came and she fell down at the door of the man's house where her master was, and she lay there until it was light. 

# What did the Levite do when his concubine did not answer him?

When the Levite's concubine did not answer him, he put her on the donkey, and the man set out for home. 

# What did the Levite do to his concubine's body?

The Levite cut her up, limb by limb, into twelve pieces, and sent the pieces everywhere throughout Israel. 

# Who assembled together before Yahweh at Mizpah?

All the people from Dan to Beersheba, including the land of Gilead, assembled together before Yahweh at Mizpah. 

# What did the Levite say the relatives of Gibeah did to him?

The Levite said the relatives of Gibeah attacked him, surrounding the house and intending to kill him. 

# How would the people attack Gibeah?

They would attack Gibeah as the lot directed them. 

# Why did the tribes of Israel tell Benjamin to give them those wicked men of Gibeah?

The tribes of Israel told Benjamin to give them those wicked men of Gibeah, so the tribes might put them to death, and so they would completely remove this evil from Israel. 

# Why did the people of Benjamin come together out of the cities to Gibeah?

The people of Benjamin came together out of the cities to Gibeah to get ready to fight against the people of Israel. 

# What was special about the seven hundred chosen men?

The seven hundred chosen men were left-handed; each of them could sling a stone at a hair and not miss. 

# Why did Judah attack Benjamin first?

The people asked for advice from God, and Yahweh said, "Judah will attack first." 

# After Benjamin killed many soldiers of Israel, what did the soldiers of Israel do?

After Benjamin killed many soldiers of Israel, the soldiers of Israel wept and fasted before Yahweh until evening. They also offered burnt offerings and peace offering before Yahweh. 

# How did the people of Israel ask Yahweh?

The people of Israel asked Yahweh by using the ark of the covenant of God, which was there in those days. 

# When the soldiers of Israel drew away from the city to the roads, what did the people of Benjamin think?

When the soldiers of Israel drew away from the city to the roads, the people of Benjamin thought they were running away. 

# Why had the men of Israel given ground to Benjamin?

The men of Israel had given ground to Benjamin because they were counting on the men they had placed in hidden positions outside Gibeah. 

# What was the signal between the soldiers of Israel and the men hiding in secret?

The arranged signal between the soldiers of Israel and the men hiding in secret was that a great cloud of smoke would rise up out of the city. 

# Why could the men of Benjamin not escape?

The men of Benjamin ran away from the soldiers of Israel escaping on the way to the wilderness, but the fighting overtook them. 

# How many soldiers of Benjamin turned and fled to the wilderness?

Six hundred men turned and fled to the wilderness. 

# Why did the men of Israel worry that one of their tribes should be missing?

The men of Israel worried that one of their tribes should be missing because they had promised to not give their daughters to marry a Benjamite. 

# Why did the men of Israel worry that one of their tribes should be missing?

The men of Israel worried that one of their tribes should be missing because they had promised to not give their daughters to marry a Benjamite. 

# Who would certainly be put to death?

Anyone who did not come up to Yahweh at Mizpah would certainly be put to death. 

# Which of the tribes of Israel did not come up to Yahweh at Mizpah?

Jabesh Gilead did not come up to Yahweh at Mizpah. 

# Who did the men take from those living in Jabesh Gilead?

The men took four hundred young women who had never slept with a man from those living in Jabesh Gilead. 

# What was the problem when the Benjaminites returned at that time and they were given the women of Jabesh Gilead?

When the Benjaminites returned at that time and they were given the women of Jabesh Gilead, there were not enough women for all of them. 

# Where was Shiloh?

Shiloh was north of Bethel, east of the road that went up from Bethel to Shechem, and south of Lebonah. 

# When were the Benjaminites to each rush out of the vineyards and grab a wife from the girls of Shiloh?

When the girls from Shiloh came out to dance, they each were to rush out of the vineyards and grab a wife from the girls of Shiloh. 

# What excuse would the men of Israel tell the men of Shiloh about the girls?

The men of Israel would tell the men of Shiloh to let the girls remain because the men of Israel did not get wives during the war. 

# How did everyone live?

Everyone did what was right in his own eyes. 

