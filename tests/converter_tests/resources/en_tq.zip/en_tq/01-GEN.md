#  What did God create in the beginning?

God created the heavens and the earth.

#  What was the Spirit of God doing in the beginning?

The Spirit of God was moving above the surface of the waters.

# How did God create light?

God said, "Let there be light". 

# What did God make on the second day?

God made the sky between the expanses of water. 

# What did God make on the second day?

God made the sky between the expanses of water. 

# What did God call the dry land and the gathered waters?

God called the dry land "earth," and the gathered waters he called "seas." 

# What living things did God make on the third day?

God made plants, fruit trees, and vegetation on the third day. 

# What living things did God make on the third day?

God made plants, fruit trees, and vegetation on the third day. 

# What is the purpose of the lights in the sky?

They are to divide the day from the night, and as signs for seasons, for days and years. 

# What did God make on the fourth day?

God made the two great lights and the stars. 

# What did God make on the fifth day?

God made the living creatures of the water, and birds. 

# What command did God give the sea creatures and birds?

Be fruitful, and multiply. 

# What did God make in his image?

God made man in his image. 

# Over what things was man given dominion?

God gave man dominion over the fish of the sea, over the birds of the sky, over the livestock, over all the earth, and over every creeping thing that creeps upon the earth. 

# What was different about how God made man?

God created man in his own image. 

# What command did God give man?

Be fruitful and multiply, fill the earth and subdue it. 

# What did God give man to eat?

God gave them every herb yielding seed and every tree with fruit. 

# When God saw everything that he had made, what did he think about it?

God thought it was very good. 

# What did God do on the seventh day?

He rested from all his work, and he blessed and sanctified the day. 

# What did God do on the seventh day?

He rested from all his work, and he blessed and sanctified the day. 

# Before Yahweh caused it to rain, how was the earth watered?

A mist went up from the earth. 

# How did Yahweh make man?

Yahweh formed man from the dust of the ground and breathed the breath of life into him. 

# Where did Yahweh first put the man?

In the garden in Eden. 

# What two trees were in the midst of the garden?

The tree of life and the tree of the knowledge of good and evil. 

# What was the man to do in the garden?

He was to work and maintain the garden. 

# What command did Yahweh give the man about what to eat?

You may freely eat from every tree in the garden, except the tree of the knowledge of good and evil. 

# What command did Yahweh give the man about what to eat?

You may freely eat from every tree in the garden, except the tree of the knowledge of good and evil. 

# What did Yahweh say would happen if the man violated this command?

In the day when the man violated the command, he would surely die. 

# What did Yahweh say was not good?

He said it was not good that the man was alone. 

# What did Yahweh have the man do with every living creature?

The man gave every living creature a name. 

# What was not found among all the living creatures?

A helper for the man corresponding to him. 

# How did Yahweh make the woman?

Yahweh caused the man to sleep and took one of the man's ribs, and made the woman from the rib. 

# Why did the man call her "woman"?

Because she was taken out of the man. 

# How do a man and woman become one flesh?

The man is united to the woman as his wife. 

# Were the man and his wife ashamed of being naked?

No. 

# What was the first question that the serpent asked the woman?

The serpent asked the woman, "Has God really said, 'You must not eat from any tree of the garden'"? 

# When the woman said God told them they would die if they ate from the tree in the middle of the garden, what did the serpent say?

The serpent said, "You will surely not die". 

# What did the serpent say would happen to the man and woman if they ate of the fruit?

The serpent said they would be like God, knowing good and evil. 

# What attracted the woman to the fruit of the tree?

She saw it was good for food, a delight to the eyes, and desirable to make one wise. 

# Who ate of the fruit?

The woman ate, and gave some to her husband who also ate. 

# What happened to them when they ate of the fruit?

When they ate, their eyes were opened and they knew that they were naked. 

# What did the man and woman do when God came into the garden?

They hid themselves from God. 

# Why did the man hide himself from God when he came into the garden?

The man hid himself from God because he was naked and therefor afraid. 

# Who did the man say was responsible for giving him the fruit?

The man said the woman was responsible. 

# Who did the woman say was responsible for giving her the fruit?

The woman said that the serpent was responsible. 

# What kind of relationship did God say he would cause to exist between the serpent and the woman?

God said he would cause them to hate each other. 

# What curse did God give the woman regarding childbirth?

God greatly multiplied the woman's pain in childbirth. 

# What curse did God give the man regarding his work?

God cursed the ground so that only by painful toil would the man eat from it. 

# What name did the man give the woman, and why?

The man called the woman Eve, because she was the mother of all living things. 

# What did God make for Adam and Eve, and why?

God made them garments of skins in order to clothe them. 

# Why did God say that now Adam must not eat of the tree of life?

God said that since Adam now knew good and evil he must not eat of the tree of life, because he would then live forever. 

# What did God do to prevent Adam from eating from the tree of life?

God drove the man out of the garden and placed cherubim there to guard the way to the tree of life. 

# What work did Cain and Abel do?

Cain worked the soil, and Abel was a shepherd. 

# What offering did Cain bring to Yahweh?

Cain brought some of the fruit of the ground. 

# What offering did Abel bring to Yahweh?

Abel brought some of the firstborn of his flock and some of the fat. 

# How did Yahweh respond to the offerings of Cain and Abel?

Yahweh accepted Abel's offering, but did not accept Cain's offering. 

# How did Yahweh respond to the offerings of Cain and Abel?

Yahweh accepted Abel's offering, but did not accept Cain's offering. 

# How did Cain react?

Cain was very angry, and his face looked dejected. 

# What did Yahweh tell Cain he needed to do in order to be accepted?

Yahweh told Cain to do what is right and he would be accepted. 

# Later, what happened with Cain and Abel in the field?

Cain rose up and killed Abel. 

# When Yahweh asked Cain where his brother was, what did Cain say?

Cain said, "I do not know. Am I my brother's keeper"? 

# What was God's curse on Cain?

Cain's curse was that the earth would not yield its strength to him, and he would be a fugitive and wanderer. 

# What did Yahweh do to make sure no one killed Cain?

Yahweh put a mark on Cain. 

# Where did Cain go to live?

Cain lived in the land of Nod, east of Eden. 

# Cain's descendant Lamech had how many wives?

Lamech had two wives. 

# What did Lamech tell his wives he had done?

Lamech told his wives that he had killed a man. 

# What was the name of another son born to Adam and Eve?

Another son of Adam and Eve was named Seth. 

# What did people begin to do in the days of Seth's son Enosh?

People began to call upon the name of Yahweh. 

# Of what is chapter five of Genesis a record?

Chapter five of Genesis is a record of the descendants of Adam. 

# In whose likeness was mankind made?

Mankind was made in God's likeness. 

# What genders of mankind did God create?

God created mankind male and female. 

# How long did Adam live?

Adam lived 930 years. 

# How long did Seth live?

Seth lived 912 years. 

# How long did Kenan live?

Kenan lived 910 years. 

# How long did Jared live?

Jared lived 962 years. 

# What was Enoch's relationship with God, and what happened to him?

Enoch walked with God, and God took him. 

# What did Lamech say about his son Noah?

Lamech said that Noah would give mankind rest from the work and the toil caused by the ground that Yahweh had cursed. 

# Who were the sons of Noah?

The sons of Noah were Shem, Ham, and Japheth. 

# When mankind multiplied on the earth, what did the sons of God do?

The sons of God took for themselves wives from the daughters of mankind. 

# What did God now say about the length of life for mankind?

God said that mankind would live 120 years. 

# Who were the mighty men of old, the men of renown?

The mighty men of old were giants born from the marriage of the sons of God with the daughters of men. 

# What did Yahweh see in the hearts of mankind in those days?

Yahweh saw that the wickedness of mankind was great, and that their every thought was evil. 

# What did Yahweh decide to do with mankind?

Yahweh decided to wipe away mankind from the earth. 

# But who found favor with Yahweh?

Noah found favor with Yahweh. 

# What kind of person was Noah?

Noah was a righteous man, blameless, and a man who walked with God. 

# What did God tell Noah to do before God destroyed mankind?

God told Noah to build a boat. 

# How did God say he was going to destroy all flesh that has the breath of life in it?

God said that he was going to bring the flood of waters upon the earth. 

# But with whom did God establish his covenant?

God established his covenant with Noah. 

# Who did God tell Noah to bring on the boat?

God told Noah to bring his wife, his three sons, and his sons' wives. 

# What animals were to be brought on the boat to be kept alive?

Two of every kind of living creature, male and female, were to be brought on the boat. 

# How did Noah respond to God's commands?

Noah did all that God commanded him. 

# Seven males and females of which kinds of animals were to go on the boat?

Seven males and females of every clean animal and the birds were to go on the boat. 

# How long did God say the rain would continue on the earth?

God said that the rain would continue for forty days and forty nights. 

# How old was Noah when the flood came upon the earth?

Noah was six hundred years old when the flood came upon the earth. 

# How did Noah bring the animals into the boat?

The animals came to Noah and went into the boat. 

# From which two sources did the waters of the flood come?

The waters came from deep underground, and from the sky. 

# Once all the people and animals were in the boat, who closed the door?

Yahweh shut the door after them. 

# How high did the water on the earth get?

The water rose fifteen cubits above the tops of the mountains. 

# Because of the flood, what died upon the earth?

All creatures that moved upon the earth, and all mankind, died. 

# Who were the only persons left alive on the earth?

Only Noah and those with him in the ark were left alive. 

# How did God make the waters recede?

God made a wind blow, the fountains of the deep were closed, and the rain stopped. 

# How did God make the waters recede?

God made a wind blow, the fountains of the deep were closed, and the rain stopped. 

# Where did the ark come to rest on the ground?

The ark came to rest upon the mountains of Ararat. 

# What happened the first time Noah sent out a dove from the ark?

The first time, the dove found no place to rest her foot, and she returned to Noah in the ark. 

# What happened the second time Noah sent out a dove from the ark?

The second time, the dove returned with a freshly plucked olive leaf. 

# What happened the third time Noah sent out a dove from the ark?

The third time, the dove did not return to Noah. 

# What did Noah see when he removed the covering of the ark and looked out?

Noah saw that the surface of the ground was dry. 

# What did God want all the creatures on the ark to go and do as they left the ark?

God wanted all the living creatures to be fruitful and multiply on the earth. 

# What did Noah do when he left the ark?

Noah built an alter to Yahweh and offering burnt offerings on the altar. 

# What two promises did God make to mankind at this time?

God promised to not again curse the ground, and to not again destroy every living thing. 

# What did God say was man's inclination from childhood?

God said that man's inclination from childhood was evil. 

# What did God tell Noah and his sons to do after they left the ark?

God told Noah and his sons to be fruitful, multiply, and fill the earth. 

# What did God give Noah and his sons now as food?

God gave Noah and his sons both the green plants and every moving thing that lived as food. 

# How did God command that meat not be eaten?

God commanded that meat not be eaten with the blood in it. 

# What did God say was in the blood?

God said that the life was in the blood. 

# What did God declare was the penalty for shedding a man's blood?

God declared that the one who shed a man's blood must have his blood shed. 

# What did God declare was the penalty for shedding a man's blood?

God declared that the one who shed a man's blood must have his blood shed. 

# In whose image did God make man?

God made man in God's image. 

# What covenant promise did God make with everything that lives on the earth?

God made a covenant promise that never again will all flesh be destroyed by a flood. 

# What covenant promise did God make with everything that lives on the earth?

God made a covenant promise that never again will all flesh be destroyed by a flood. 

# What covenant promise did God make with everything that lives on the earth?

God made a covenant promise that never again will all flesh be destroyed by a flood. 

# What sign did God give of the covenant that he made with the earth?

God placed the rainbow in the clouds as the sign of the covenant he made with the earth. 

# What covenant promise did God make with everything that lives on the earth?

God made a covenant promise that never again will all flesh be destroyed by a flood. 

# What sign did God give of the covenant that he made with the earth?

God placed the rainbow in the clouds as the sign of the covenant he made with the earth. 

# What sign did God give of the covenant that he made with the earth?

God placed the rainbow in the clouds as the sign of the covenant he made with the earth. 

# What were the names of the three sons of Noah?

The names of the three sons of Noah were Shem, Ham, and Japheth. 

# What happened to Noah after he planted a vineyard?

After he planted a vineyard, Noah drank some of the wine and became drunk. 

# What happened to Noah after he planted a vineyard?

After he planted a vineyard, Noah drank some of the wine and became drunk. 

# How did Shem and Japheth cover the nakedness of their father?

Shem and Japheth walked backwards with a garment, while turned the other way, in order to cover the nakedness of their father. 

# What was the curse Noah put on Ham?

Noah cursed Ham and said, "Cursed be Canaan. May he be a servant to his brothers' servants."  

# Who did Noah bless?

Noah blessed both Shem and Japheth. 

# Who did Noah bless?

Noah blessed both Shem and Japheth. 

# After the flood, the descendants of Noah eventually spread out on the earth in clans, and when they spread out, each clan had its own what?

When the clans eventually spread out, each clan had its own language. 

# For what was Nimrod, descendant of Ham, known?

Nimrod was known as a mighty hunter before Yahweh. 

# What was the first of Nimrod's primary cities in the land of Shinar?

The first of Nimrod's primary cities was Babel. 

# In addition to the land of Shinar, what other area did Nimrod develop with cities?

Nimrod also built cities in Assyria. 

# Canaan was a descendant of which son of Noah?

Canaan was a descendant of Ham. 

# After the flood, the descendants of Noah eventually spread out on the earth in clans, and when they spread out, each clan had its own what?

When the clans eventually spread out, each clan had its own language. 

# What happened in the days of Peleg, descendant of Shem?

In the days of Peleg, the earth was divided. 

# After the flood, the descendants of Noah eventually spread out on the earth in clans, and when they spread out, each clan had its own what?

When the clans eventually spread out, each clan had its own language. 

# From where did the nations come that spread over the earth after the flood?

The nations came from the clans of the sons of Noah. 

# Immediately after the flood, how many languages were there on the whole earth?

Immediately after the flood, there was one language on the whole earth. 

# Where did the people build their city and tower?

The people built their city and tower in the land of Shinar. 

# What did the people decide to do instead of spreading across the whole earth as God had commanded?

Instead of spreading across the whole earth as God had commanded, the people decided to build a city and a tower. 

# What did the people want to make for themselves?

The people wanted to make a name for themselves. 

# What did Yahweh come down and do to the people?

Yahweh came down and confused the people's languages. 

# Why did God do this?

God confused their languages so they would not understand each other. 

# What did God cause the people then to do?

God caused the people to scatter across the face of all the earth, as he had commanded. 

# What was the name of the city the people tried to build?

The name of the city was Babel. 

# The descendants of which son of Noah are given in this chapter?

The descendants of Shem, son of Noah, are given in this chapter. 

# Who was the father of Abram?

The father of Abram was Terah. 

# Terah's son Haran had a son with what name?

Terah's son Haran had a son named Lot. 

# Where did Terah live?

Terah lived in Ur of the Chaldeans. 

# What was the name of Abram's wife?

Abram's wife's name was Sarai. 

# What problem did Abram's wife have?

Abram's wife's Sarai was barren and had no children. 

# To where did Terah move with Abram, Sarai, and Lot?

Terah moved to the land of Canaan with Abram, Sarai, and Lot. 

# While Abram was living in Haran, what did Yahweh tell Abram to do?

Yahweh told Abram to leave his father's household and go to the land that he would show Abram. 

# What promise did Yahweh make to Abram?

Yahweh promised that he would bless Abram, make him a great nation, and bless all the families of the earth through him. 

# What promise did Yahweh make to Abram?

Yahweh promised that he would bless Abram, make him a great nation, and bless all the families of the earth through him. 

# Who traveled with Abram?

Abram traveled with Sarai, his wife, and Lot, his brother's son. 

# To which land did Abram travel?

Abram traveled to the land of Canaan. 

# When Yahweh appeared to Abram, what promise did he make to Abram?

Yahweh promised that Abram's descendant's would live in Canaan. 

# How did Abram worship Yahweh?

Abram built an altar to Yahweh and called upon Yahweh's name. 

# Leaving Canaan, to where did Abram travel?

Leaving Canaan, Abram traveled to Egypt. 

# What was Abram concerned about as he entered Egypt?

Abram was concerned the Egyptians would kill him and take his wife Sarai because she was beautiful. 

# What did Abram ask Sarai to tell the Egyptians about herself?

Abram asked Sarai to tell the Egyptians that she was Abram's sister. 

# What happened to Sarai when they entered Egypt?

Pharaoh took Sarai into his household. 

# What happened to Pharaoh at this time?

Yahweh afflicted Pharaoh and his house with great plagues. 

# What question did Pharaoh ask Abram?

Pharaoh asked Abram why he had told him that Sarai was his sister instead of his wife. 

# What question did Pharaoh ask Abram?

Pharaoh asked Abram why he had told him that Sarai was his sister instead of his wife. 

# What did Pharaoh do with Abram and Sarai?

Pharaoh sent Abram and Sarai away. 

# To where did Abram travel after leaving Egypt?

Abram traveled to the Negev. 

# What did Abram carry with him?

Abram carried with him many animals, and much silver and gold. 

# Why was there a dispute between Abram's and Lot's herdsmen?

There was a dispute because the land could not support Abram and Lot living close together with all their possessions. 

# Why was there a dispute between Abram's and Lot's herdsmen?

There was a dispute because the land could not support Abram and Lot living close together with all their possessions. 

# What offer did Abram make to Lot?

Abram offered that Lot choose where to live, and then Abram would find his place to live separated from Lot. 

# Where did Lot choose to live and why?

Lot chose to move east and to live in the plain of the Jordan because it was well watered. 

# Where did Lot choose to live and why?

Lot chose to move east and to live in the plain of the Jordan because it was well watered. 

# Where did Abram then live?

Abram lived in the land of Canaan. 

# What kind of people lived in Sodom?

The people of Sodom were wicked sinners against Yahweh. 

# At this time, what did Yahweh say he would give to Abram?

Yahweh promised that all the land Abram could see from where he was standing would be given to him. 

# At this time, what did Yahweh say he would give to Abram?

Yahweh promised that all the land Abram could see from where he was standing would be given to him. 

# How many descendants did Yahweh say Abram would have?

Yahweh told Abram he would have more descendants than he could count, "abundant as the dust of the earth." 

# Near what city did Abram then move?

Abram moved near the city of Hebron. 

# What happened at Sodom as a result of the battle of the kings in the valley of Siddim?

All the goods of Sodom were taken away, and Lot and all his possessions were also taken. 

# What happened at Sodom as a result of the battle of the kings in the valley of Siddim?

All the goods of Sodom were taken away, and Lot and all his possessions were also taken. 

# What did Abram do when he was told Lot had been taken away?

Abram gathered his 318 trained men to pursue them. 

# Near what large city did Abram fight the kings, and what was the result of the battle?

Abram fought the kings north of Damascus, and he brought back the possessions, Lot, and the other people. 

# Near what large city did Abram fight the kings, and what was the result of the battle?

Abram fought the kings north of Damascus, and he brought back the possessions, Lot, and the other people. 

# Which two kings met Abram when he returned?

The king of Sodom and Melchizedek, the king of Salem, met Abram when he returned. 

# Which two kings met Abram when he returned?

The king of Sodom and Melchizedek, the king of Salem, met Abram when he returned. 

# What was Melchizedek's relationship to God?

Melchizedek was priest of God Most High. 

# What did Melchizedek bring with him when he met Abram?

Melchizedek brought bread and wine with him when he met Abram. 

# What did Melchizedek say to Abram?

Melchizedek blessed Abram, and blessed God Most High. 

# What did Melchizedek say to Abram?

Melchizedek blessed Abram, and blessed God Most High. 

# What did Abram do after Melchizedek spoke to him?

Abram gave Melchizedek a tenth of everything. 

# What offer did the king of Sodom make to Abram?

The king of Sodom offered to let Abram keep all the goods, if Abram gave the people to the king. 

# Why did Abram not want any of the possessions?

Abram had lifted up his hand to Yahweh, God Most High, and did not want the king of Sodom to be able to say that he had made Abram rich. 

# How did Abram respond to the king of Sodom's offer?

Abram said that he did not want any of the possessions, except what the young men had eaten and the share for the men that went with him. 

# Why did Abram not want any of the possessions?

Abram had lifted up his hand to Yahweh, God Most High, and did not want the king of Sodom to be able to say that he had made Abram rich. 

# How did Abram respond to the king of Sodom's offer?

Abram said that he did not want any of the possessions, except what the young men had eaten and the share for the men that went with him. 

# When Yahweh appeared to Abram, what encouragement did Yahweh give Abram?

Yahweh told Abram not to fear, and that he was Abram's shield and very great reward. 

# About what was Abram worried?

Abram was worried because he was still childless, and his steward was his heir. 

# About what was Abram worried?

Abram was worried because he was still childless, and his steward was his heir. 

# Who did Yahweh say would be Abram's heir?

Yahweh said that one coming from Abram's own body would be his heir. 

# How many descendants did Yahweh say Abram would have?

Yahweh said that Abram would have descendants as numerous as the stars. 

# How did Abram respond to Yahweh's promise, and what did Yahweh then do?

Abram believed Yahweh, and Yahweh counted it to Abram as righteousness. 

# What question did Abram ask Yahweh about the land?

Abram asked Yahweh, "How will I know that I will inherit it"? 

# What did Abram then do with the animals he was told to bring?

Abram cut the animals in two and placed each half opposite the other. 

# What happened to Abram when the sun was going down?

When the sun was going down Abram fell sound asleep and a deep and terrifying darkness overwhelmed him. 

# For how long did Yahweh say Abram's descendants would be enslaved and oppressed?

Yahweh told Abram his descendants would be enslaved and oppressed for four hundred years. 

# What did Yahweh say would happen to the nation that enslaved Abram's descendants?

Yahweh said that he would judge that nation. 

# How did Yahweh say Abram's life would end?

Yahweh said that Abram would die in peace at a good old age. 

# What would reach its limit before Abram's descendants returned to the land promised them?

The sin of the Amorites would reach its limit before Abram's descendants returned. 

# That night, what happened amongst the pieces of the animals Abram had prepared?

A smoking fire pot and flaming torch passed between the pieces of the animals. 

# What covenant did Yahweh make with Abram that day?

Yahweh made a covenant with Abram that he would give this land to Abram's descendants. 

# What covenant did Yahweh make with Abram that day?

Yahweh made a covenant with Abram that he would give this land to Abram's descendants. 

# What covenant did Yahweh make with Abram that day?

Yahweh made a covenant with Abram that he would give this land to Abram's descendants. 

# What covenant did Yahweh make with Abram that day?

Yahweh made a covenant with Abram that he would give this land to Abram's descendants. 

# What idea did Sarai have for giving Abram a descendant?

Sarai told Abram to sleep with her servant, Hagar, in order to have children by her. 

# What idea did Sarai have for giving Abram a descendant?

Sarai told Abram to sleep with her servant, Hagar, in order to have children by her. 

# What happened between Hagar and Sarai when Hagar conceived a child with Abram?

After Hagar conceived, Hagar looked with contempt on Sarai. 

# What complaint did Sarai bring to Abram, and how did Abram respond?

Sarai complained that it was Abram's fault that Hagar despised her, and Abram told Sarai to do what she thought best with Hagar. 

# What complaint did Sarai bring to Abram, and how did Abram respond?

Sarai complained that it was Abram's fault that Hagar despised her, and Abram told Sarai to do what she thought best with Hagar. 

# How did Sarai treat Hagar after Hagar conceived, and what did Hagar do?

Sarai treated Hagar harshly, and Hagar fled. 

# In the wilderness, what did the angel of Yahweh tell Hagar to do?

The angel of Yahweh told Hagar to return to Sarai and submit to her authority. 

# What promise did the angel of Yahweh make to Hagar?

The angel of Yahweh promised Hagar that her descendants would be too numerous to count. 

# Why was Hagar told to name her son Ishmael?

Hagar was told to name her son Ishmael because Yahweh had heard her affliction. 

# How will Ishmael treat other people?

Ishmael will be hostile against every man, and will live apart from all his brothers. 

# What name did Hagar give Yahweh?

Hagar gave Yahweh the name, "The God who sees me". 

# How old was Abram when Ishmael was born?

Abram was eighty-six years old when Ishmael was born. 

# How old was Abram when Yahweh appeared again to him to confirm his covenant with Abram?

Abram was ninety-nine years old when Yahweh again appeared to Abram. 

# What command did Yahweh give Abram concerning Abram's way of life?

Yahweh commanded Abram to walk before him blamelessly. 

# To what did Yahweh change Abram's name, and what does the name mean?

Yahweh changed Abram's name to Abraham, which means "father of a multitude of nations". 

# What did Yahweh give to Abraham's descendants as part of the covenant?

Yahweh gave Abraham's descendants all the land of Canaan as part of the covenant. 

# What did Yahweh say would be the relationship between Abraham's descendants and Yahweh?

Yahweh said that he would be God to Abraham's descendants. 

# What did Yahweh command be done as a sign of the covenant between Abraham and Yahweh?

Yahweh commanded that every male be circumcised as a sign of the covenant between Abraham and Yahweh. 

# What did Yahweh command be done as a sign of the covenant between Abraham and Yahweh?

Yahweh commanded that every male be circumcised as a sign of the covenant between Abraham and Yahweh. 

# At what age was a baby to be circumcised?

A baby was to be circumcised after eight days. 

# What was to be done with foreigners who joined a household that was in covenant with Yahweh?

Foreigners who joined a household in covenant with Yahweh were also to be circumcised. 

# What was to be done with foreigners who joined a household that was in covenant with Yahweh?

Foreigners who joined a household in covenant with Yahweh were also to be circumcised. 

# What happened to any male who was not circumcised?

Any male who was not circumcised was cut off from his people because he had broken the covenant. 

# To what did Yahweh change Sarai's name?

Yahweh changed Sarai's name to Sarah. 

# What did Yahweh promise would come by Sarah?

Yahweh promised that Abraham's son would come by Sarah. 

# How did Abraham respond to Yahweh's promise concerning Sarah?

Abraham laughed and asked how a child could be born to a man and woman who were so old. 

# What did God say Abraham must name the son that would come by Sarah?

God said that Abraham must name the son Isaac. 

# What did God say he would establish with Isaac?

God said that he would establish his covenant with Isaac. 

# What promise did God make concerning Ishmael?

God promised to bless Ishmael, to make him fruitful, and to make him a great nation. 

# What did God say he would establish with Isaac?

God said that he would establish his covenant with Isaac. 

# After God left Abraham, what did Abraham do on that same day?

On that same day, Abraham circumcised all the males of his household. 

# After God left Abraham, what did Abraham do on that same day?

On that same day, Abraham circumcised all the males of his household. 

# How old was Ishmael when he was circumcised?

Ishmael was thirteen years old when he was circumcised. 

# After God left Abraham, what did Abraham do on that same day?

On that same day, Abraham circumcised all the males of his household. 

# After God left Abraham, what did Abraham do on that same day?

On that same day, Abraham circumcised all the males of his household. 

# As Abraham was sitting at his tent door, what did he see when he looked up?

Abraham saw three men standing across from him. 

# What did Abraham offer the men?

Abraham offered the men some water to wash, and some food. 

# What did Abraham offer the men?

Abraham offered the men some water to wash, and some food. 

# Where was Sarah when the visitor gave his prediction?

Sarah was in the tent. 

# What prediction did the one visitor give concerning Sarah?

The one visitor said that when he returned, Sarah would have a son. 

# How did Sarah respond to the visitor's prediction?

Sarah laughed to herself when she heard the visitor's prediction. 

# What did Yahweh, the visitor, say about Sarah's response?

Yahweh asked why Sarah laughed, and said "Is anything too hard for Yahweh"? 

# When the men left Abraham's home, toward where did they go?

The men left Abraham's home and went toward Sodom. 

# What question did Yahweh ask as they walked?

Yahweh said, "Shall I hide from Abraham what I am about to do"? 

# What did Yahweh say Abraham must do so that Yahweh might fulfill the promises given to Abraham?

Yahweh said that Abraham must instruct his children and his household to do righteousness and justice. 

# Why were the men going toward Sodom?

The men were going toward Sodom because the cries against Sodom and Gomorrah were great, and they wanted to see if the cities were as wicked as the outcry suggested. 

# Why were the men going toward Sodom?

The men were going toward Sodom because the cries against Sodom and Gomorrah were great, and they wanted to see if the cities were as wicked as the outcry suggested. 

# As Abraham stood with Yahweh, what question did he ask Yahweh?

Abraham asked, "Will you sweep away the righteous with the wicked"? 

# What did Yahweh say he would do if there were fifty righteous within the city?

Yahweh said he would spare the whole place for their sake. 

# What did Yahweh say he would do if there were forty-five righteous within the city?

Yahweh said he would spare the whole place for their sake. 

# What did Yahweh say he would do if there were forty righteous within the city?

Yahweh said he would spare the whole place for their sake. 

# What did Yahweh say he would do if there were thirty righteous within the city?

Yahweh said he would spare the whole place for their sake. 

# What did Yahweh say he would do if there were twenty righteous within the city?

Yahweh said he would spare the whole place for their sake. 

# What did Yahweh say he would do if there were ten righteous within the city?

Yahweh said he would spare the whole place for their sake. 

# When Lot saw the two angels coming into Sodom, what did he offer them?

Lot offered that they stay at his home for the night, and then leave in the morning. 

# What was the angels' response to Lot?

The angels said that they would spend the night in the town square. 

# At Lot's urging, where did the angels finally decide to spend the night?

Finally, the angels went with Lot to his home for the night. 

# What did the men of the city who surrounded Lot's house want Lot to do?

The men wanted Lot to bring out the two men visiting him, so they could sleep with them. 

# What did Lot offer the men of the city instead?

Lot offered the men of the city his two daughters instead of the two visitors. 

# How did the men respond to Lot's offer?

The men told Lot to stand back and almost broke down the door. 

# What did the angels then do?

The angels pulled Lot back into the house and struck the men outside with blindness. 

# What did the angels say they had been sent to do by Yahweh?

The angels said they had been sent to destroy the city. 

# How did Lot's sons-in-law respond when Lot told them to hurry and leave Sodom because it was about to be destroyed?

Lot's sons-in-law thought Lot was joking. 

# When morning dawned, what did the angels tell Lot to do?

The angels told Lot to take his wife and daughters and get out of the city. 

# Why, despite Lot's lingering, did the angels bring Lot and his family by their hands out of the city?

The angels set them outside the city because Yahweh was merciful to them. 

# What instructions did the angels give Lot when they were outside the city?

The angels told Lot and his family to flee for their lives and to not look back. 

# Where did the angel allow Lot and his family to flee?

Lot and his family were allowed to flee to a small city called Zoar. 

# What did Yahweh do when Lot reached Zoar?

Yahweh rained down sulfur and fire from the sky on Sodom and Gomorrah. 

# What did Lot's wife do and what happened to her?

Lot's wife looked back, and she became a pillar of salt. 

# What did Abraham see early in the morning as he looked down at all the land of the plain?

Abraham saw smoke rising from the land like the smoke of a furnace. 

# To where did Lot then move and why?

Lot then moved to the mountains because he was afraid to live in Zoar. 

# What plan did Lot's daughters make involving their father?

Lot's daughters planned to make their father drunk, then lie with him so that they could have children. 

# What plan did Lot's daughters make involving their father?

Lot's daughters planned to make their father drunk, then lie with him so that they could have children. 

# Which two people groups came from the daughters of Lot?

The Moabite and Ammonite people groups came from the daughters of Lot. 

# Which two people groups came from the daughters of Lot?

The Moabite and Ammonite people groups came from the daughters of Lot. 

# What did Abraham say about Sarah while he was living at Gerar?

Abraham said that Sarah was his sister. 

# What did Abraham say about Sarah while he was living at Gerar?

Abraham said that Sarah was his sister. 

# What did God say to Abimelech after he took Sarah?

God came to Abimelech in a dream and told him that he was a dead man because he had taken a man's wife. 

# What did Abimelech say to God he had been told by Abraham and Sarah?

Abimelech said to God that Abraham had told him Sarah was his sister, and Sarah had told him Abraham was his brother. 

# What did God tell Abimelech to do, and what did God say would happen if he did not do it?

God told Abimelech to return Sarah to Abraham; otherwise, he and all his people would die. 

# How did Abimelech's men respond when they heard what God had told Abimelech?

Abimelech's men were very afraid when they heard what God had told him. 

# Why did Abraham say he had told Abimelech that Sarah was his sister?

Abraham said that he was afraid Abimelech would kill him because of Sarah. 

# In what way was Sarah actually Abraham's sister?

Sarah was the daughter of Abraham's father, but not of his mother. 

# What animals and people did Abimelech give Abraham?

Abimelech gave Abraham sheep and oxen, male and female slaves. 

# What reason did Abimelech give Sarah as to why he gave her brother a thousand pieces of silver?

Abimelech told Sarah he had given a thousand pieces of silver to her brother to cover any offense against Sarah in the eyes of all that were with Sarah, and before everyone. 

# What happened when Abraham prayed to God for Abimelech and his people?

God healed Abimelech, his wife, and his female slaves so they were able to have children. 

# What did Yahweh do for Sarah?

Yahweh visited Sarah and she bore a son to Abraham at the promised time. 

# When Isaac was eight days old, what did Abraham do?

When Isaac was eight days old, Abraham circumcised him. 

# What did Sarah say God had made her do?

Sarah said that God had made her laugh. 

# On the day Isaac was weaned, what did Sarah see?

Sarah saw the son of Hagar mocking. 

# What did Sarah tell Abraham to do with Hagar and her son, and why?

Sarah told Abraham to drive out Hagar and her son, because Hagar's son would not be heir with Isaac. 

# What was Abraham's reaction to Sarah's demand?

Abraham was grieved by Sarah's demand. 

# What did God tell Abraham to do?

God told Abraham to listen to Sarah. 

# Where did Hagar and her son go after Abraham sent them out?

Hagar and her son went into the wilderness. 

# What did God tell Hagar he would do for her son?

God said he would make the son of Hagar into a great nation. 

# How did Hagar and her son survive?

God opened Hagar's eyes and she saw a well of water. 

# What happened to Hagar's son as he grew up?

Hagar's son became and archer and his mother got a wife for him from Egypt. 

# What happened to Hagar's son as he grew up?

Hagar's son became and archer and his mother got a wife for him from Egypt. 

# What did Abimelech want Abraham to swear to do for him?

Abimelech wanted Abraham to swear that he would not deal falsely with Abimelech, or with his children, or with his descendants. Abimelech asked Abraham to show to him the same covenant faithfulness that Abimelech had shown to Abraham. 

# What did Abraham complain about to Abimelech?

Abraham complained to Abimelech about a well of water that Abimelech's servants had seized from him. 

# Why did Abraham send seven female lambs to Abimelech?

Abraham sent seven female lambs to Abimelech as a witness that he had dug the disputed well. 

# Why did Abraham send seven female lambs to Abimelech?

Abraham sent seven female lambs to Abimelech as a witness that he had dug the disputed well. 

# Why did Abraham send seven female lambs to Abimelech?

Abraham sent seven female lambs to Abimelech as a witness that he had dug the disputed well. 

# Into what land did Abimelech return?

Abimelech returned into the land of the Philistines. 

# What did Abraham do at the tamarisk tree in Beer-sheba?

Abraham worshiped Yahweh, the eternal God. 

# Where did Abraham live for many days?

Abraham lived in the land of the Philistines for many days. 

# What test did God give Abraham?

God told Abraham to go the land of Moriah and offer Isaac as a burnt offering. 

# What test did God give Abraham?

God told Abraham to go the land of Moriah and offer Isaac as a burnt offering. 

# How did Abraham respond to God's command?

Abraham rose early in the morning and set out on his journey to the place God had told him about. 

# What did Abraham tell his two young men that he and Isaac were going to do?

Abraham told his two young men that he and Isaac were going to worship and then would return. 

# What question did Isaac ask Abraham as they were walking together?

Isaac asked Abraham, "Where is the lamb for the burnt offering"? 

# How did Abraham answer Isaac's question?

Abraham said that God would himself provide the lamb for the burnt offering. 

# When they reached the place, what did Abraham prepare as the burnt offering and how did he do it?

Abraham prepared Isaac as the burnt offering by binding him and laying him on the altar. 

# When Abraham took the knife in his hand, what did the angel of Yahweh tell Abraham?

The angel of Yahweh told Abraham to not harm Isaac. 

# What did the angel say he now knew about Abraham?

The angel said that he now knew that Abraham feared God. 

# How did God then provide the burnt offering for Abraham?

There was a ram caught in the bushes behind Abraham, which Abraham used as the burnt offering. 

# What did Abraham call the place of the burnt offering?

Abraham called the place, "Yahweh will provide". 

# What reason did the angel of Yahweh give for blessing Abraham?

The angel of Yahweh said he would bless Abraham because Abraham had not withheld his only son. 

# What reason did the angel of Yahweh give for blessing Abraham?

The angel of Yahweh said he would bless Abraham because Abraham had not withheld his only son. 

# Through who and why were all nations of the earth to be blessed?

Through Abraham's offspring all the nations of the earth were to be blessed, because Abraham had obeyed the angel of Yahweh's voice. 

# What did Abraham first do when Sarah died?

When Sarah died, Abraham first mourned for her and wept for her. 

# What request did Abraham make to the sons of Heth?

Abraham asked for a property to use as a burying-place. 

# What request did Abraham make to the sons of Heth?

Abraham asked for a property to use as a burying-place. 

# How did the sons of Heth respond to Abraham's request?

The sons of Heth offered the choicest of their tombs to Abraham. 

# How did the sons of Heth respond to Abraham's request?

The sons of Heth offered the choicest of their tombs to Abraham. 

# When Abraham asked for Ephron the Hittite's cave as a tomb, how did Ephron respond?

Ephron offered to give Abraham the cave and the field next to it. 

# When Abraham asked for Ephron the Hittite's cave as a tomb, how did Ephron respond?

Ephron offered to give Abraham the cave and the field next to it. 

# How did Abraham respond to Ephron's offer?

Abraham offered to pay for the field and the cave. 

# How did Abraham respond to Ephron's offer?

Abraham offered to pay for the field and the cave. 

# How did Ephron respond to Abraham's offer?

Ephron asked for four hundred shekels of silver for the field and the cave. 

# How did the conversation between Abraham and Ephron end?

Abraham paid four hundred shekels of silver to Ephron for the piece of land. 

# How did Ephron respond to Abraham's offer?

Ephron asked for four hundred shekels of silver for the field and the cave. 

# How did the conversation between Abraham and Ephron end?

Abraham paid four hundred shekels of silver to Ephron for the piece of land. 

# How did the conversation between Abraham and Ephron end?

Abraham paid four hundred shekels of silver to Ephron for the piece of land. 

# What was included in the purchase of the field of Ephron which was in Machpelah?

The field, the cave that was in it, and all the trees that were in the field and all around its border were included in Abraham's purchase of the field of Ephron. 

# What was included in the purchase of the field of Ephron which was in Machpelah?

The field, the cave that was in it, and all the trees that were in the field and all around its border were included in Abraham's purchase of the field of Ephron. 

# What did Abraham then do with the cave?

Abraham then buried Sarah in the cave. 

# What did Abraham make his oldest servant swear to do?

Abraham made his oldest servant swear that he would get a wife for Isaac from Abraham's relatives. 

# What did Abraham make his oldest servant swear to do?

Abraham made his oldest servant swear that he would get a wife for Isaac from Abraham's relatives. 

# What did Abraham make his oldest servant swear to do?

Abraham made his oldest servant swear that he would get a wife for Isaac from Abraham's relatives. 

# What did Abraham insist that the servant not do with Isaac?

Abraham insisted that the servant not take Isaac back to the land from which Abraham came. 

# What did Abraham insist that the servant not do with Isaac?

Abraham insisted that the servant not take Isaac back to the land from which Abraham came. 

# What did Abraham's servant ask God to do in order to show him which woman God had chosen for Isaac?

The servant asked that the woman whom he asked to lower her pitcher to get a drink would do so and offer to water his camels also. 

# What did Abraham's servant ask God to do in order to show him which woman God had chosen for Isaac?

The servant asked that the woman whom he asked to lower her pitcher to get a drink would do so and offer to water his camels also. 

# What did Abraham's servant ask God to do in order to show him which woman God had chosen for Isaac?

The servant asked that the woman whom he asked to lower her pitcher to get a drink would do so and offer to water his camels also. 

# What relation was Rebekah to Abraham?

Rebekah was the granddaughter of Nahor, Abraham's brother. 

# What did Rebekah do when Abraham's servant asked for a drink of water?

Rebekah gave the servant a drink. 

# What did Rebekah do when Abraham's servant asked for a drink of water?

Rebekah gave the servant a drink. 

# What did Rebekah say after she had finished giving the servant a drink?

After Rebekah finished giving the servant a drink she said, "I will draw water for your camels also, until they have finished drinking." 

# What did the servant do when he heard that Rebekah was related to Abraham and that he could spend the night with her family?

The servant worshipped Yahweh and blessed him. 

# What did the servant do when he heard that Rebekah was related to Abraham and that he could spend the night with her family?

The servant worshipped Yahweh and blessed him. 

# Who was Rebekah's brother?

Laban was Rebekah's brother. 

# What did Laban do when he met Abraham's servant?

Laban invited Abraham's servant to stay at his house. 

# What did Abraham's servant insist on doing before he ate?

Abraham's servant insisted on saying why he had come before he ate. 

# How had Abraham said that Yahweh would prosper the servant's way?

Abraham had said that Yahweh would send his angel with the servant to prosper his way. 

# What had the servant given Rebekah when he heard she was related to Abraham?

Abraham's servant had given Rebekah a gold ring for her nose and bracelets for her arms. 

# How did Laban and Bethuel answer Abraham's servant when he asked them what they wanted to do regarding Rebekah?

Laban and Bethuel answered that the servant should take Rebekah and go, so that Rebekah could be the wife of Abraham's son. 

# How did Laban and Bethuel answer Abraham's servant when he asked them what they wanted to do regarding Rebekah?

Laban and Bethuel answered that the servant should take Rebekah and go, so that Rebekah could be the wife of Abraham's son. 

# What did Abraham's servant do when he heard the answer from Laban and Bethuel?

The servant bowed down to Yahweh and gave gifts to Rebekah and to her brother and mother. 

# What did Abraham's servant do when he heard the answer from Laban and Bethuel?

The servant bowed down to Yahweh and gave gifts to Rebekah and to her brother and mother. 

# When they arose the next morning, what did Rebekah's brother and mother want the servant to do?

When they arose the next morning, they wanted Abraham's servant to stay with them for at least ten more days. 

# When they arose the next morning, what did Rebekah's brother and mother want the servant to do?

When they arose the next morning, they wanted Abraham's servant to stay with them for at least ten more days. 

# When Abraham's servant said that he wanted to go immediately, what did Rebekah say that she wanted to do?

Rebekah said that she wanted to go with the servant. 

# When Abraham's servant said that he wanted to go immediately, what did Rebekah say that she wanted to do?

Rebekah said that she wanted to go with the servant. 

# When Abraham's servant said that he wanted to go immediately, what did Rebekah say that she wanted to do?

Rebekah said that she wanted to go with the servant. 

# What blessing did Rebekah's family give her as she left with Abraham's servant?

Rebekah's family blessed her that she might be the mother of thousands and ten thousands, and that her descendants might possess the gate of those who hate them. 

# What was Isaac doing when Rebekah arrived at his home?

Isaac was out in the field meditating. 

# What did Rebekah do when she saw Isaac?

When she saw Isaac, Rebekah jumped down from the camel and covered herself with her veil. 

# What did Rebekah do when she saw Isaac?

When she saw Isaac, Rebekah jumped down from the camel and covered herself with her veil. 

# What did Isaac do after Abraham's servant recounted all the things that he had done?

Isaac brought Rebekah into his mother Sarah's tent and took Rebekah as his wife. 

# What did Abraham do after his wife Sarah died?

Abraham took another wife named Keturah. 

# How did Abraham distribute his wealth?

Abraham gave gifts to the sons of his concubines, and gave all that he owned to Isaac. 

# How did Abraham distribute his wealth?

Abraham gave gifts to the sons of his concubines, and gave all that he owned to Isaac. 

# How many years did Abraham live?

Abraham lived one hundred seventy-five years. 

# Who buried Abraham?

Both Isaac and Ishmael buried Abraham. 

# How did the twelve sons of Ishmael live with each other?

The twelve sons of Ishmael lived with each other in hostility. 

# What did Isaac do because Rebekah was childless?

Isaac prayed to Yahweh for his wife, and Yahweh answered his prayer, and Rebekah conceived. 

# What did Yahweh say concerning the two children struggling within Rebekah's womb?

Yahweh said that there were two nations in her womb, one people stronger than the other, and that the older would serve the younger. 

# Who was born first, and what did he look like?

Esau was born first, and he was red all over like a hairy garment. 

# Who was born second, and what was he doing as he was born?

Jacob was born second, and he was grasping Esau's heel as he was born. 

# What kind of man was Esau?

Esau was a skillful hunter and a man of the field. 

# What kind of man was Jacob?

Jacob was a quiet man who spent his time in the tents. 

# Who did Isaac love, and who did Rebekah love?

Isaac loved Esau, and Rebekah loved Jacob. 

# What was another name for Esau?

Edom was another name for Esau. 

# For what did Jacob ask in return for the red stew that Esau wanted to eat because he was starving?

Jacob asked for Esau's birthright in return for the red stew. 

# What was Esau's response to Jacob's offer?

Esau swore an oath and sold his birthright to Jacob. 

# How was Esau treating his birthright when he responded in this way to Jacob's offer?

Esau was despising his birthright when he responded to Jacob's offer in this way. 

# Why did Isaac move to the city of Gerar where Abimelech was the king of the Philistines?

Isaac moved to Gerar because there was a famine in the land. 

# What had Yahweh told Isaac before Isaac moved to Gerar?

Yahweh had told Isaac not to move to Egypt, and to stay in the land about which he would tell Isaac. 

# What did Yahweh tell Isaac about the oath Yahweh had sworn to his father Abraham?

Yahweh told Isaac that he would fulfill the oath which Yahweh had sworn to Abraham. 

# Why did Yahweh say he was going to do this?

Yahweh said he was going to do this because Abraham had obeyed his voice and kept his instructions, commandments, statutes, and laws. 

# What did Isaac say to the men of Gerar about Rebekah, his wife?

Isaac told the men of Gerar that Rebekah was his sister. 

# According to Abimelech, what could have brought guilt upon the people because of Isaac's lie?

Because of Isaac's lie, someone could have had sexual relations with Rebekah and brought guilt upon the people. 

# According to Abimelech, what could have brought guilt upon the people because of Isaac's lie?

Because of Isaac's lie, someone could have had sexual relations with Rebekah and brought guilt upon the people. 

# What command did Abimelech give regarding Rebekah?

Abimelech commanded that anyone who touched Rebekah would be put to death. 

# What reason did Abimelech give for asking Isaac to move away from the Philistines?

Abimelech asked Isaac to move away from the Philistines because he said, "...for you are mightier than we." 

# Why did Isaac have to dig out the wells of water which they had dug in the days of Abraham?

Isaac had to dig out the wells of water which they had dug in the days of Abraham because the Philistines had stopped them up after Abraham's death. 

# What did Isaac name the well over which the herdsmen of Gerar did not quarrel with him?

Isaac named the well, over which the herdsmen of Gerar did not quarrel with him, Rehoboth. 

# What did Yahweh reaffirm to Isaac when he appeared to Isaac at Beersheba?

Yahweh reaffirmed that he would bless Isaac and multiply his descendants. 

# What did Yahweh reaffirm to Isaac when he appeared to Isaac at Beersheba?

Yahweh reaffirmed that he would bless Isaac and multiply his descendants. 

# What covenant did Abimelech want to make with Isaac, and why?

Abimelech wanted to make a covenant that neither side would harm the other, because he saw that Yahweh was with Isaac. 

# What covenant did Abimelech want to make with Isaac, and why?

Abimelech wanted to make a covenant that neither side would harm the other, because he saw that Yahweh was with Isaac. 

# How did Isaac respond to Abimelech's request for a covenant between them?

Isaac made a feast, and they swore an oath with each other. 

# How did Isaac respond to Abimelech's request for a covenant between them?

Isaac made a feast, and they swore an oath with each other. 

# From what people group were the two wives of Esau?

The two wives of Esau were from the Hittites. 

# How was the relationship between Esau's wives and Isaac and Rebekah?

Esau's wives brought sorrow to Isaac and Rebekah. 

# As Isaac grew old, what was he no longer able to do?

As Isaac grew old, he was no longer able to see. 

# What did Isaac ask Esau to do, and why?

Isaac asked Esau to go hunt and make the sort of food that he loved, so that he could eat it and bless Esau. 

# What did Isaac ask Esau to do, and why?

Isaac asked Esau to go hunt and make the sort of food that he loved, so that he could eat it and bless Esau. 

# What was Rebekah's plan for providing the food for Isaac, and why?

Rebekah told Jacob to go get two goats and she would make the food that Isaac loved, so that Jacob could take it to Isaac and receive the blessing. 

# What was Rebekah's plan for providing the food for Isaac, and why?

Rebekah told Jacob to go get two goats and she would make the food that Isaac loved, so that Jacob could take it to Isaac and receive the blessing. 

# What was Rebekah's plan for providing the food for Isaac, and why?

Rebekah told Jacob to go get two goats and she would make the food that Isaac loved, so that Jacob could take it to Isaac and receive the blessing. 

# About what was Jacob concerned in bringing the food to Isaac?

Jacob was concerned that Esau was a hairy man and he was a smooth man, and that Isaac would touch him and find out that Jacob was a deceiver and curse him. 

# About what was Jacob concerned in bringing the food to Isaac?

Jacob was concerned that Esau was a hairy man and he was a smooth man, and that Isaac would touch him and find out that Jacob was a deceiver and curse him. 

# How did Rebekah solve the problem of Esau being a hairy man, and Jacob a smooth man?

Rebekah put Esau's clothes on Jacob and put goatskins upon his hands and neck. 

# How did Rebekah solve the problem of Esau being a hairy man, and Jacob a smooth man?

Rebekah put Esau's clothes on Jacob and put goatskins upon his hands and neck. 

# When Isaac asked, how did Jacob say he had found the game so quickly?

Jacob said that Yahweh, Isaac's God, had brought the game to him. 

# Because he was not sure, how did Isaac try to determine who was giving him the food?

Isaac touched Jacob on the hands and felt the hairy goatskins. 

# Because he was not sure, how did Isaac try to determine who was giving him the food?

Isaac touched Jacob on the hands and felt the hairy goatskins. 

# What did Jacob say when Isaac asked, "Are you really my son Esau"?

Jacob said, "I am". 

# What finally convinced Isaac that the person bringing the food was Esau?

When Jacob came near Isaac to kiss him, Isaac smelled Esau's clothes. 

# What finally convinced Isaac that the person bringing the food was Esau?

When Jacob came near Isaac to kiss him, Isaac smelled Esau's clothes. 

# Who did Isaac say would bow down to Jacob?

Isaac said nations would bow down to Jacob and that Jacob's mother's sons would bow down to him. 

# What did Esau do soon after Jacob left Isaac's tent?

Esau came in from hunting, prepared the food, and brought it to Isaac. 

# What did Esau do soon after Jacob left Isaac's tent?

Esau came in from hunting, prepared the food, and brought it to Isaac. 

# What did Isaac say when Esau asked for Isaac's blessing?

Isaac said that Jacob had deceitfully taken away Esau's blessing. 

# What did Isaac say when Esau asked for Isaac's blessing?

Isaac said that Jacob had deceitfully taken away Esau's blessing. 

# In what two ways did Esau say Jacob had cheated him?

Esau said that Jacob had cheated him from his birthright and from his blessing. 

# What was the "blessing" that Isaac gave Esau?

Isaac said that Esau would live away from the fatness of the earth, that he would serve his brother, but would eventually rebel against him and shake off Jacob's yoke. 

# What was the "blessing" that Isaac gave Esau?

Isaac said that Esau would live away from the fatness of the earth, that he would serve his brother, but would eventually rebel against him and shake off Jacob's yoke. 

# What did Esau decide to do after Isaac's death?

Esau decided to kill Jacob after Isaac's death. 

# What did Rebekah do after hearing Esau's plans?

Rebekah sent Jacob to Laban, her brother, in Haran. 

# What command did Isaac give Jacob before he left?

Isaac commanded Jacob not to take a Canaanite wife. 

# Where did Isaac tell Jacob to get a wife?

Isaac told Jacob to get a wife from the daughters of Laban, Rebekah's brother. 

# Whose blessing did Isaac ask God to give Jacob?

Isaac asked God to give Jacob the blessing of Abraham. 

# From where did Esau get one of his wives when he saw that the women of Canaan did not please Isaac?

Esau took a wife from the daughters of Ishmael, Abraham's son. 

# From where did Esau get one of his wives when he saw that the women of Canaan did not please Isaac?

Esau took a wife from the daughters of Ishmael, Abraham's son. 

# What did Jacob see in his dream while on the way to Haran?

Jacob saw a ladder from earth to heaven with angels ascending and descending on it, and Yahweh standing above it. 

# What did Jacob see in his dream while on the way to Haran?

Jacob saw a ladder from earth to heaven with angels ascending and descending on it, and Yahweh standing above it. 

# What did Yahweh say about the land Jacob was lying on?

Yahweh said that the land Jacob was lying on would be given to him and his descendants. 

# Whose blessing did Yahweh give to Jacob?

Yahweh gave Jacob the blessing of Abraham. 

# What did Jacob say about the place where he had the dream?

Jacob said the place was the house of God and the gate of heaven. 

# What name did Jacob give the place where he had the dream?

Jacob named the place Beth-el. 

# What did Jacob say Yahweh must do in order for Yahweh to be his God?

Jacob said that Yahweh must be with him and protect him on his journey so that he returned safely to his father's house. 

# What did Jacob say Yahweh must do in order for Yahweh to be his God?

Jacob said that Yahweh must be with him and protect him on his journey so that he returned safely to his father's house. 

# What did Jacob promise to give Yahweh if Yahweh did these things for him?

Jacob promised to give back to Yahweh a tenth of everything Yahweh gave Jacob. 

# From where were the men that Jacob talked to?

The men were from Haran. 

# Who also came to the well with a flock of sheep?

Rachel, daughter of Laban, also came to the well with a flock of sheep. 

# What did Jacob do for Laban's sheep?

Jacob rolled the stone from the well's mouth and watered the sheep. 

# What did Jacob tell Rachel, and then what did she do?

Jacob told Rachel that he was her father's relative, and then Rachel ran and told her father. 

# How did Laban react when he heard about Jacob's arrival?

Laban ran to meet Jacob, embraced him, kissed him, and brought him to his house. 

# Describe the two daughters of Laban.

Leah was the older daughter and she had tender eyes, while Rachel was the younger and was beautiful in form and appearance. 

# Describe the two daughters of Laban.

Leah was the older daughter and she had tender eyes, while Rachel was the younger and was beautiful in form and appearance. 

# What arrangement did Laban and Jacob make concerning Jacob's labor?

They agreed that Jacob would serve Laban seven years in return for Rachel. 

# Why did the seven years of labor only seem like a few days to Jacob?

The seven years of labor seemed only like a few days because of the love Jacob had for Rachel. 

# How did Laban trick Jacob?

Laban gave Leah to Jacob, instead of Rachel, the night of the wedding. 

# How did Laban trick Jacob?

Laban gave Leah to Jacob, instead of Rachel, the night of the wedding. 

# Who did Laban give to Leah, to be her servant?

Laban gave his female servant Zilpah to his daughter Leah, to be her servant. 

# How did Laban trick Jacob?

Laban gave Leah to Jacob, instead of Rachel, the night of the wedding. 

# Why did Laban say he had tricked Jacob?

Laban said it was not their custom to give the younger daughter in marriage before the first-born. 

# What arrangement did Laban and Jacob then make concerning Jacob's labor?

They agreed that Jacob would serve Laban seven more years in return for Rachel. 

# Who did Laban give to Rachel, to be her servant?

Laban gave Bilhah to his daughter Rachel, to be her servant. 

# What did Yahweh do when he saw that Jacob did not love Leah?

Yahweh caused Leah to become pregnant, but Rachel was childless. 

# What did Leah hope would happen if she bore sons for Jacob?

Leah hoped that Jacob would love her if she bore sons for him. 

# What was the name of Leah's first son?

The name of Leah's first son was Reuben. 

# What did Leah say after she bore Judah?

After she bore Judah Leah said, "This time I will praise Yahweh." 

# According to Jacob, why did Rachel have no children?

According to Jacob, God had kept Rachel from having children. 

# What did Rachel do in order to have children?

Rachel gave Jacob Bilhah her servant so she could have children on Rachel's behalf. 

# Why did Rachel say that she had prevailed against her sister Leah?

Rachel said that she had prevailed because Bilhah her servant bore two sons for Jacob. 

# Why did Rachel say that she had prevailed against her sister Leah?

Rachel said that she had prevailed because Bilhah her servant bore two sons for Jacob. 

# What did Leah do when she saw that she had stopped bearing children?

Leah gave Jacob Zilpah her servant so she could have children on Leah's behalf. 

# What caused Leah to say, "This is fortunate."? 

Leah said, "This is fortunate." because Zilpah her servant bore Jacob a son. 

# What caused Leah to say, "This is fortunate."? 

Leah said, "This is fortunate." because Zilpah her servant bore Jacob a son. 

# What did Rachel offer Leah in exchange for her son's mandrakes?

In exchange for Reuben's mandrakes, Rachel offered to let Leah sleep with Jacob that night 

# What did Rachel offer Leah in exchange for her son's mandrakes?

In exchange for Reuben's mandrakes, Rachel offered to let Leah sleep with Jacob that night 

# How many sons did Leah bear for Jacob?

Leah bore six sons for Jacob. 

# What caused Rachel to say that her shame had been taken away?

When Rachel bore a son for Jacob, she said that her shame had been taken away. 

# What request did Jacob make to Laban after Joseph was born?

Jacob requested that Laban let Jacob go with his family back to his own home and country. 

# What request did Jacob make to Laban after Joseph was born?

Jacob requested that Laban let Jacob go with his family back to his own home and country. 

# Why did Laban not want to let Jacob go away?

Laban had divined that Yahweh had blessed him for Jacob's sake. 

# What wages did Jacob receive for his work for Laban?

Jacob took the speckled, spotted, and black sheep, and the speckled and spotted goats from Laban's flock that he tended. 

# How did Laban cheat Jacob concerning Jacob's wages?

Laban first removed the animals that Jacob would have taken, before he gave the flock to Jacob to tend. 

# How did Laban cheat Jacob concerning Jacob's wages?

Laban first removed the animals that Jacob would have taken, before he gave the flock to Jacob to tend. 

# What kind of sticks did Jacob peel white streaks into?

Jacob peeled white streaks into branches of fresh poplar, almond, and plane trees. 

# What did Jacob do with the peeled sticks?

Jacob put the sticks that he had peeled in front of the flocks, in front of the watering troughs where they came to drink. 

# What happened when the flocks bred in front of the sticks?

When the flocks bred in front of the sticks they produced striped, speckled, and spotted young. 

# What was the result of Jacob's breeding of the animals?

The result was that Laban's flock was feebler, and Jacob's flock was stronger. 

# From where did Laban and his sons believe Jacob had gotten all his wealth?

Laban and his sons believed that Jacob had gotten all his wealth from Laban's possessions. 

# From where did Laban and his sons believe Jacob had gotten all his wealth?

Laban and his sons believed that Jacob had gotten all his wealth from Laban's possessions. 

# What instructions did Yahweh give Jacob?

Yahweh instructed Jacob to return to the land of his fathers and to his relatives. 

# How had God taken away the cattle of Laban and given them to Jacob?

God had caused the animals to bear speckled, and striped young which were Jacob's wages. 

# How had God taken away the cattle of Laban and given them to Jacob?

God had caused the animals to bear speckled, and striped young which were Jacob's wages. 

# What attitude did Rachel and Leah have toward their father Laban?

Rachel and Leah said that Laban treated them as foreigners and had devoured their money. 

# What attitude did Rachel and Leah have toward their father Laban?

Rachel and Leah said that Laban treated them as foreigners and had devoured their money. 

# What did Rachel do before leaving with Jacob?

Rachel stole her father's household gods. 

# How did Jacob deceive Laban at this time?

Jacob deceived Laban by not telling Laban that he was leaving. 

# What did Laban do when he was told that Jacob had fled?

Laban took his relatives with him and pursued Jacob, overtaking him after seven days. 

# What did Laban do when he was told that Jacob had fled?

Laban took his relatives with him and pursued Jacob, overtaking him after seven days. 

# What did God tell Laban in a dream?

God told Laban to speak neither good or bad to Jacob. 

# Why did Jacob say that he had fled from Laban secretly?

Jacob said that he fled secretly because he was afraid that Laban would take his daughters from him by force. 

# What did Jacob say when Laban accused him of stealing his household gods?

Jacob said that whoever stole Laban's household gods would not continue to live. 

# Why did Laban not find his household gods among Jacob's possessions?

Laban did not find his household gods because Rachel sat on them and then said that she could not stand up since she was having her period. 

# Why did Laban not find his household gods among Jacob's possessions?

Laban did not find his household gods because Rachel sat on them and then said that she could not stand up since she was having her period. 

# How long had Jacob worked for Laban, and how many times had Laban changed his wages?

Jacob had worked for Laban twenty years, and Laban had changed his wages ten times. 

# How did Laban show that he still thought of Jacob's possessions as his own?

Laban said that all that he saw of Jacob's possessions was his. 

# How did Jacob and Laban mark the place of their covenant?

Jacob and Laban marked the place of their covenant by making a pile of stones there. 

# Who was declared as witness between Jacob and Laban to ensure the covenant would be kept?

God was declared as witness between Jacob and Laban to ensure the covenant would be kept. 

# Who was declared as witness between Jacob and Laban to ensure the covenant would be kept?

God was declared as witness between Jacob and Laban to ensure the covenant would be kept. 

# What were the pile and the pillar for?

The pile and pillar were both witnesses to the covenant which said neither Laban nor Jacob would pass the pile or pillar to do one another harm. 

# What covenant did Jacob and Laban make?

Jacob and Laban each agreed to not pass beyond the pile of stones to do the other harm. 

# What were the pile and the pillar for?

The pile and pillar were both witnesses to the covenant which said neither Laban nor Jacob would pass the pile or pillar to do one another harm. 

# What did Jacob do to show that he agreed to the covenant?

To show that he agreed with Laban about the covenant Jacob swore by God, who his father Isaac feared. 

# What did Laban do the next morning?

Laban rose, kissed his grandsons and daughters, blessed them, and returned home. 

# To whom did Jacob send a message on his way toward Canaan?

Jacob sent a message to his brother Esau on his way toward Canaan. 

# For what purpose did Jacob send this message?

Jacob desired to find favor in Esau's sight. 

# What was Jacob's reaction when he heard Esau was coming with four hundred men, and what did he do?

Jacob was afraid, so he divided his people into two groups so that if Esau attacked one group, the other could escape. 

# What was Jacob's reaction when he heard Esau was coming with four hundred men, and what did he do?

Jacob was afraid, so he divided his people into two groups so that if Esau attacked one group, the other could escape. 

# What was Jacob's request to Yahweh?

Jacob asked Yahweh to deliver him from the hand of Esau. 

# Of what promise did Jacob remind Yahweh?

Jacob reminded Yahweh that he had promised to prosper Jacob, and to make is descendants like the sand of the sea. 

# What did Jacob think he could accomplish by sending gifts to his brother Esau?

Jacob thought that perhaps he could appease Esau with the gifts that he sent to Esau so that later, when Jacob saw him, Esau would receive him. 

# How did Jacob end up being alone that night?

He took his wives, servant women, and children across the ford of the Jabbok. 

# What did Jacob do that night until daybreak?

Jacob wrestled with a man until daybreak. 

# What did the man do when he could not defeat Jacob?

The man struck Jacob's hip and dislocated it. 

# What did Jacob demand before he would let the man go?

Jacob demanded that the man bless him. 

# What did the man say Jacob would there after be called?

The man said that Jacob's name would now be Israel. 

# Who did Jacob say he had seen face to face that night?

Jacob said he had seen God face to face that night. 

# What physical problem did Jacob continue to have after that night?

Jacob limped because of his hip after that night. 

# As Esau was coming to Jacob, in what order did Jacob put his wives behind him?

Jacob put his female servants first, then Leah, and then Rachel. 

# As Esau was coming to Jacob, in what order did Jacob put his wives behind him?

Jacob put his female servants first, then Leah, and then Rachel. 

# What did Jacob do as he came near his brother?

Jacob bowed toward the ground seven times as he came near his brother. 

# What did Esau do when he came to his brother?

Esau ran to meet Jacob, embraced him, hugged his neck, and kissed him. 

# What did Esau tell Jacob to do with the gifts he had sent ahead to Esau?

Esau told Jacob to keep them for himself, since he had enough. 

# What two reasons did Jacob give Esau to accept his gifts?

Jacob said that because God had dealt graciously with him, and because he had enough, Esau should accept his gifts. 

# Why did Jacob say he wanted Esau to go ahead, while he traveled more slowly?

Jacob said he wanted Esau to go ahead because the flocks would die if they were driven too fast. 

# Why did Jacob say he wanted Esau to go ahead, while he traveled more slowly?

Jacob said he wanted Esau to go ahead because the flocks would die if they were driven too fast. 

# Why did Jacob say he wanted Esau to go ahead, while he traveled more slowly?

Jacob said he wanted Esau to go ahead because the flocks would die if they were driven too fast. 

# Where did Jacob say he was going to bring his family and his flocks?

Jacob said he was going to bring his family and flocks to Esau in Seir. 

# To where did Jacob travel, where he built himself a house?

Jacob traveled to Succoth, where he built himself a house. 

# To where did Jacob travel, where he bought a piece of ground?

Jacob traveled to Shechem, where he bought a piece of ground. 

# To where did Jacob travel, where he bought a piece of ground?

Jacob traveled to Shechem, where he bought a piece of ground. 

# What did Shechem, the son of Hamor, do when he saw Dinah, Leah's daughter?

Shechem grabbed Dinah, assaulted her, and forced himself on her. 

# What did Jacob do at first when he heard about what happened to Dinah?

Jacob held his peace until his sons came in from the field. 

# What was the reaction of Jacob's sons when they heard what Shechem had done to Dinah?

Jacob's sons were very angry. 

# What did Hamor, the father of Shechem, want Jacob to do?

Hamor wanted Jacob to give Dinah to Shechem as his wife, and to allow Jacob's family to intermarry with Hamor's family. 

# What did Hamor, the father of Shechem, want Jacob to do?

Hamor wanted Jacob to give Dinah to Shechem as his wife, and to allow Jacob's family to intermarry with Hamor's family. 

# What did Shechem say he was willing to do to have Dinah as his wife?

Shechem said he would pay as great a bride price as Jacob would name. 

# In what way did the sons of Jacob answer Shechem, and why?

The sons of Jacob answered Shechem deceitfully, because Shechem had defiled Dinah. 

# What requirement did the sons of Jacob make to Hamor before they would agree to intermarry with Hamor's family?

The sons of Jacob required that all the males in Hamor's family be circumcised. 

# When speaking to the men of their city, what did Hamor and Shechem say would be theirs if they intermarried with Jacob's family?

They said that all of Jacob's livestock, property, and animals would be theirs if they intermarried with Jacob's family. 

# How did the men of Hamor's city respond when asked if they were willing to be circumcised?

The men of Hamor's city listened to Hamor and Shechem and every male was circumcised. 

# What did Simeon and Levi do on the third day after the males from Hamor's family had been circumcised?

Simeon and Levi killed all the males in Hamor's city. 

# What then did all of the sons of Jacob do?

All of the sons of Jacob looted the city, took all the wealth, and captured the children and wives. 

# What then did all of the sons of Jacob do?

All of the sons of Jacob looted the city, took all the wealth, and captured the children and wives. 

# What then did all of the sons of Jacob do?

All of the sons of Jacob looted the city, took all the wealth, and captured the children and wives. 

# How did Jacob respond when he learned about what Simeon and Levi had done?

Jacob said that Simeon and Levi had brought trouble on him because the inhabitants of the land might now destroy him and his household. 

# Why did Simeon and Levi say they had done it?

Simeon and Levi said they had done it because Shechem had treated their sister Dinah like a prostitute. 

# What did God tell Jacob to go and do?

God told Jacob to go to Bethel and to build an altar to God. 

# What did Jacob then tell the people of his household to do?

Jacob told them to put away their foreign gods, to purify themselves, and to change their clothes. 

# As they traveled, why did the people of the cities around Jacob and his household not pursue them?

The people of the cities around them did not pursue them because they were afraid of God. 

# Why did Jacob call the place they came to "Elbethel"?

Jacob called it "Elbethel" because it was the place God had revealed himself to Jacob when Jacob was fleeing from Esau. 

# What new name did God give Jacob?

God gave Jacob the new name Israel. 

# What promise did God reaffirm to Jacob?

God reaffirmed the promise that Jacob would become a company of nations with kings among his descendants, and that the land God had promised to Abraham and Isaac would be given to him and his descendants. 

# What happened to Rachel during her labor with Benjamin?

Rachel died during her labor with Benjamin. 

# What happened to Rachel during her labor with Benjamin?

Rachel died during her labor with Benjamin. 

# Israel heard about what thing that Reuben had done?

Israel heard that Reuben had slept with Bilhah, Israel's concubine. 

# How many sons did Jacob have?

Jacob had twelve sons. 

# Which sons of Jacob were born from Rachel?

Joseph and Benjamin were born from Rachel. 

# How many years did Isaac live?

Isaac lived one hundred eighty years. 

# Who buried Isaac?

Esau and Jacob buried Isaac. 

# By what other name are the descendants of Esau called?

The descendants of Esau are also called Edom. 

# From where did Esau get his wives?

Esau took his wives from the Canaanites. 

# Why did Esau move away from his brother Jacob?

Esau moved away from his brother Jacob because the land could not support both of them as their possessions were too many. 

# Why did Esau move away from his brother Jacob?

Esau moved away from his brother Jacob because the land could not support both of them as their possessions were too many. 

# Where did Esau settle?

Esau settled in the hill country of Seir. 

# What was the name of the son born by Timna, a concubine of Esau's firstborn son Eliphaz?

The name of the son born by Timna was Amalek. 

# What was the name of the son born by Timna, a concubine of Esau's firstborn son Eliphaz?

The name of the son born by Timna was Amalek. 

# What was the name of the son born by Timna, a concubine of Esau's firstborn son Eliphaz?

The name of the son born by Timna was Amalek. 

# Who was the father of the inhabitants of the land in which Edom lived?

Seir the Horite was the father of the inhabitants of the land in which Edom lived. 

# What did the people of Edom have before Israel had them?

The people of Edom had kings before any king reigned over the Israelites. 

# Who was the father of the Edomites?

Esau was the father of the Edomites. 

# Where did Jacob settle to live?

Jacob lived in the land of Canaan. 

# What did Joseph bring to his father Jacob while guarding the flock with his brothers?

Joseph brought to his father an unfavorable report about his brothers. 

# How did Israel show that he loved Joseph more than his other sons?

Israel made Joseph a luxurious tunic. 

# What did Joseph's brothers think about Joseph?

Joseph's brothers hated him and would not speak to him cordially. 

# What did Joseph see in his first dream?

Joseph saw his sheaf stand upright while his brothers' sheaves bowed down to his sheaf. 

# What did Joseph's brothers think about Joseph after he told them about his first dream?

Joseph's brothers hated him even more. 

# What did Joseph see in his second dream?

Joseph saw the sun, moon, and eleven stars bow down to him. 

# In Joseph's second dream, what did the sun, moon, and stars represent?

The sun, moon, and stars represented Joseph's father, mother, and brothers. 

# What did Jacob send Joseph out of the valley of Hebron to do?

Jacob sent Joseph out of the valley of Hebron to see if it was well with his brothers, and to bring Jacob word. 

# What did Joseph's brothers plan to do when they saw Joseph coming?

Joseph's brothers planned to kill Joseph and cast him into one of the pits. 

# What suggestion did Reuben make to his brothers, and why?

Reuben suggested that the brothers only throw Joseph into a pit, so that he could rescue Joseph later. 

# Who did Joseph's brothers sell Joseph to and for how much?

Joseph's brothers sold Joseph to the Ishmaelites for twenty pieces of silver.

# To where was Joseph taken?

Joseph was taken to Egypt. 

# How did Joseph's brothers make it appear that Joseph was dead?

Joseph's brothers killed a goat and dipped Joseph's coat in the blood, then gave the coat to Jacob. 

# How did Joseph's brothers make it appear that Joseph was dead?

Joseph's brothers killed a goat and dipped Joseph's coat in the blood, then gave the coat to Jacob. 

# What did Jacob do after he concluded Joseph was dead?

Jacob tore his garments, wore sackcloth, and mourned his son for many days. 

# To whom was Joseph sold in Egypt?

Joseph was sold to Potiphar, an officer of Pharaoh, in Egypt. 

# From whom did Judah take a wife?

Judah took a wife from a Canaanite man. 

# What did Yahweh do with Judah's first son Er, and why?

Yahweh killed Er because he was wicked. 

# How did Judah's second son Onan not fulfill the duty of a brother-in-law to raise up a child for Er?

Onan would spill his semen on the ground when he made love to Tamar. 

# What did Yahweh do with Judah's second son Onan, and why?

Yahweh killed Onan because what he did was evil. 

# What promise did Judah then make to Tamar?

Judah promised Tamar his third son Shelah as a husband when Shelah grew up. 

# After a long time, why did Judah need to be comforted?

Judah was comforted because his wife died. 

# What did Tamar do when she heard that Judah was going to Timnah?

Tamar took off her clothing of widowhood, put on a veil and wrapped herself, and sat by the road to Timnah. 

# Why did Tamar do this?

Tamar did this because Judah's third son Shelah had grown up, but she had not been given to him as a wife. 

# What did Tamar obtain as a pledge for payment before Judah made love to her?

Judah gave Tamar his seal, cord, and staff as a pledge of payment. 

# When Judah tried to retrieve his pledge by paying the prostitute with a young goat, what did he learn?

Judah learned that there was no temple prostitute in that area. 

# What did Judah want to do when he learned that Tamar was pregnant?

Judah wanted to burn Tamar because she had become pregnant as a prostitute. 

# What did Tamar do when she was brought out to Judah?

She said that she was pregnant by the man who owned the seal, cord, and staff she had. 

# How did Judah respond when he saw his seal, cord, and staff?

Judah said that Tamar was more right than he was, because he had not given Tamar to Shelah as a wife. 

# How many children did Tamar bear?

Tamar had twin sons. 

# What did the midwife do when one of Tamar's twins put his hand out from Tamar's womb?

When one of Tamar's twins put his hand out from Tamar's womb The midwife took a scarlet thread and tied it on his hand and said, "This one came out first." 

# What were the names of the two brothers that Tamar birthed?

The names of the two brothers that Tamar birthed were Perez and Zerah. 

# What were the names of the two brothers that Tamar birthed?

The names of the two brothers that Tamar birthed were Perez and Zerah. 

# Who bought Joseph in Egypt?

Potiphar, an official of Pharaoh, bought Joseph in Egypt. 

# Why was Joseph prosperous in Egypt?

Joseph was prosperous because Yahweh was with him. 

# Why was Joseph prosperous in Egypt?

Joseph was prosperous because Yahweh was with him. 

# What did Potiphar put under Joseph's care?

Potiphar put everything he had under Joseph's care. 

# What did Potiphar's wife ask Joseph to do?

Potiphar's wife asked Joseph to make love to her. 

# How did Joseph respond to Potiphar's wife's request?

Joseph refused and said he could not commit this great wickedness and sin against God. 

# How did Joseph respond to Potiphar's wife's request?

Joseph refused and said he could not commit this great wickedness and sin against God. 

# What did Joseph do when Potiphar's wife caught him by his clothes?

Joseph left his clothing in her hand and fled outside. 

# What accusation did Potiphar's wife make against Joseph?

She accused him of trying to make love to her against her will. 

# What accusation did Potiphar's wife make against Joseph?

She accused him of trying to make love to her against her will. 

# What did Potiphar do when he heard the accusation against Joseph?

Potiphar became very angry and put Joseph in prison. 

# What did Potiphar do when he heard the accusation against Joseph?

Potiphar became very angry and put Joseph in prison. 

# At this time, what did Yahweh show to Joseph?

Yahweh showed covenant faithfulness to Joseph at this time. 

# What did the prison warden put under Joseph's care?

The prison warden put all the prisoners under Joseph's care. 

# What was the result of everything Joseph did, and why?

Everything Joseph did, Yahweh prospered. 

# Why did the king of Egypt put his cupbearer and his baker in prison?

He put them in prison because they offended him. 

# What happened to the cupbearer and the baker on the same night?

The cupbearer and the baker each dreamed a dream the same night. 

# Why were the cupbearer and baker both sad the next morning?

They were both sad because no one could interpret their dreams. 

# Why were the cupbearer and baker both sad the next morning?

They were both sad because no one could interpret their dreams. 

# Who did Joseph say could give the interpretation of the dreams?

Joseph said that God could give the interpretation of the dreams. 

# What did Joseph say was the interpretation of the cupbearer's dream?

Joseph said that the dream meant that within three days Pharaoh would restore the cupbearer to his office. 

# What did Joseph say was the interpretation of the cupbearer's dream?

Joseph said that the dream meant that within three days Pharaoh would restore the cupbearer to his office. 

# What request did Joseph make to the cupbearer after giving the interpretation of his dream?

Joseph requested that the cupbearer remember him, mention him to Pharaoh, and bring him out of the prison. 

# What did Joseph say was the interpretation of the baker's dream?

Joseph said that the dream meant that within three days Pharoah would hang the baker on a tree. 

# What did Joseph say was the interpretation of the baker's dream?

Joseph said that the dream meant that within three days Pharoah would hang the baker on a tree. 

# What special event occurred three days later?

Pharaoh's birthday was three days later. 

# What did Pharaoh do with the cupbearer and the baker on that day?

Pharaoh restored the cupbearer, but he hanged the baker, just as Joseph had interpreted to them. 

# What did Pharaoh do with the cupbearer and the baker on that day?

Pharaoh restored the cupbearer, but he hanged the baker, just as Joseph had interpreted to them. 

# Did the cupbearer remember Joseph's request to him?

No, the cupbearer did not remember to help Joseph, but forgot about him. 

# In Pharaoh's first dream, what did the seven thin cows do to the seven fat cows?

The seven thin cows ate the seven fat cows. 

# In Pharaoh's second dream, what did the seven thin ears of grain do to the seven full ears?

The seven thin ears swallowed up the seven full ears. 

# How did the magicians and wise men of Pharaoh interpret his dreams?

The magicians and wise men of Pharaoh could not interpret Pharaoh's dreams. 

# What did the chief cupbearer tell Pharaoh about Joseph?

The chief cupbearer told Pharaoh that a young Hebrew man had correctly interpreted his dream and the dream of another fellow when they were in custody. 

# What did the chief cupbearer tell Pharaoh about Joseph?

The chief cupbearer told Pharaoh that a young Hebrew man had correctly interpreted his dream and the dream of another fellow when they were in custody. 

# Who did Joseph say would interpret Pharaoh's dream?

Joseph said that God would answer Pharaoh's dream with favor. 

# What did Joseph say God was declaring to Pharaoh?

Joseph said that God was declaring to Pharaoh what God was about to do. 

# What did the seven good cows and the seven good heads in the dreams represent?

The seven good cows and heads represented seven years of abundance. 

# What did the seven thin cows and the seven thin heads in the dreams represent?

The seven thin cows and heads represented seven years of famine. 

# According to Joseph, why was Pharaoh given two dreams?

Pharaoh was given two dreams because the matter had been established by God, and God would soon do it. 

# What fraction of the crops of Egypt did Joseph advise Pharaoh to take in the seven abundant years

Joseph advised Pharaoh appoint a man to take a fifth of the crops in the seven abundant years. 

# What did Pharaoh say was in Joseph?

Pharaoh said that the Spirit of God was in Joseph. 

# What position of authority did Pharaoh give Joseph?

Pharaoh gave Joseph authority over Pharaoh's house and over all the land of Egypt, second only to Pharaoh. 

# What position of authority did Pharaoh give Joseph?

Pharaoh gave Joseph authority over Pharaoh's house and over all the land of Egypt, second only to Pharaoh. 

# How much grain did Joseph store up in the seven years of abundance?

Joseph stored up grain like the sand of the sea, an amount beyond counting. 

# How much grain did Joseph store up in the seven years of abundance?

Joseph stored up grain like the sand of the sea, an amount beyond counting. 

# What were the names of Joseph's two sons born before the famine?

Joseph's sons were named Manasseh and Ephraim. 

# What were the names of Joseph's two sons born before the famine?

Joseph's sons were named Manasseh and Ephraim. 

# What were the names of Joseph's two sons born before the famine?

Joseph's sons were named Manasseh and Ephraim. 

# How widespread was the seven years of famine?

The seven years of famine was in all lands. 

# What did Joseph do when the people of Egypt cried to Pharaoh for food?

Joseph opened all the storehouses and sold food to the Egyptians. 

# What did Joseph do when the people of Egypt cried to Pharaoh for food?

Joseph opened all the storehouses and sold food to the Egyptians. 

# Who came to Egypt to buy grain from Joseph?

All the earth came to Egypt to buy grain from Joseph. 

# Who did Jacob send down to Egypt to buy grain?

Joseph's ten brothers, without Benjamin, went down to Egypt to buy grain. 

# Who did Jacob send down to Egypt to buy grain?

Joseph's ten brothers, without Benjamin, went down to Egypt to buy grain. 

# Who did Jacob send down to Egypt to buy grain?

Joseph's ten brothers, without Benjamin, went down to Egypt to buy grain. 

# Who did Jacob send down to Egypt to buy grain?

Joseph's ten brothers, without Benjamin, went down to Egypt to buy grain. 

# What did Joseph's brothers do when they came to Joseph to buy grain?

Joseph's brothers bowed down to him with their faces to the ground. 

# What did Joseph do when he recognized his brothers?

Joseph disguised himself and spoke harshly with his brothers. 

# What accusation did Joseph make against his brothers?

Joseph accused his brothers of being spies. 

# Where did Joseph's brothers say their youngest brother was?

Joseph's brothers said their youngest brother was with his father in the land of Canaan. 

# Where did Joseph's brothers say their other missing brother was?

Joseph's brothers said their other missing brother was no longer alive. 

# What test did Joseph give his brothers to demonstrate they were not spies?

Joseph said the brothers would not leave Egypt, unless their youngest brother came to Egypt. 

# Where did Joseph put the brothers and for how long?

Joseph put the brothers in custody for three days. 

# What did Joseph tell the brothers to do in order to live?

Joseph told them to let one of the brothers be confined in prison, while the others carried grain to Canaan and brought back the youngest brother. 

# What did Joseph tell the brothers to do in order to live?

Joseph told them to let one of the brothers be confined in prison, while the others carried grain to Canaan and brought back the youngest brother. 

# What did Joseph tell the brothers to do in order to live?

Joseph told them to let one of the brothers be confined in prison, while the others carried grain to Canaan and brought back the youngest brother. 

# Why did Joseph's brothers believe this trouble had come upon them?

They believed that the blood of Joseph was being required of them for what they had done to Joseph. 

# Why did Joseph's brothers believe this trouble had come upon them?

They believed that the blood of Joseph was being required of them for what they had done to Joseph. 

# What did Joseph do when he heard his brothers talk about what they had done to him?

When Joseph heard his brothers talking about what they had done to him, Joseph turned from them and wept. 

# What did Joseph have put back in each brother's sack?

Joseph had each brother's money put back in his sack. 

# How did the brothers react when they learned that one brother's sack had his money in it?

Their hearts sank and they spoke trembling to one another. 

# Who did the brothers blame for their current problems?

The brothers blamed God, asking why God had done this to them. 

# What did the brothers and Jacob learn when they emptied all the sacks?

They learned that every man's money was in his sack. 

# What was Jacob afraid would happen because of their situation?

Jacob was afraid that Simeon and Benjamin would be taken away from him. 

# What oath did Reuben make to Jacob?

Reuben swore to bring Benjamin back to Jacob from Egypt; otherwise, Reuben's two sons could be killed. 

# Did Jacob allow Reuben to take Benjamin to Egypt?

No, Jacob did not allow Reuben to take Benjamin to Egypt. 

# What did Jacob say would happen to him if Benjamin died?

Jacob said he would go down with sorrow to Sheol if Benjamin died. 

# Why did Israel tell his sons to go again and buy some food in Egypt?

The famine was severe and they had eaten the grain they had brought from Egypt on the first journey. 

# Why did Israel tell his sons to go again and buy some food in Egypt?

The famine was severe and they had eaten the grain they had brought from Egypt on the first journey. 

# What did Judah say they must have in order to go down to Egypt again?

Judah said they must have their brother Benjamin in order to go down to Egypt. 

# What did Judah say they must have in order to go down to Egypt again?

Judah said they must have their brother Benjamin in order to go down to Egypt. 

# What did Judah say they must have in order to go down to Egypt again?

Judah said they must have their brother Benjamin in order to go down to Egypt. 

# What oath did Judah make to Israel his father?

Judah said that if he did not bring Benjamin back, he would bear the blame forever. 

# What did Israel tell the brothers to take with them to Egypt?

Israel told the brothers to take some of the best products of the land, and to take double the money. 

# What did Israel tell the brothers to take with them to Egypt?

Israel told the brothers to take some of the best products of the land, and to take double the money. 

# For what did Israel ask God regarding the journey?

Israel asked God to give the brothers mercy in Egypt, so that all the brothers would be released. 

# How did the brothers respond when they were brought to Joseph's house, and why?

The brothers were afraid they would be arrested and taken as slaves because of the money left in their bags on the first journey. 

# What did the brothers tell the steward of Joseph's house?

The brothers told the steward they had brought back the money left in their sacks, and money to buy food. 

# What did the brothers tell the steward of Joseph's house?

The brothers told the steward they had brought back the money left in their sacks, and money to buy food. 

# From where did the steward say the money left in their sacks had come?

The steward said the money left in their sacks had come from their God. 

# What did the brothers do when Joseph came home?

The brothers brought the gifts into the house, and bowed down before Joseph to the ground. 

# About whom did Joseph ask the brothers?

Joseph asked the brothers about the welfare of their father. 

# Why did Joseph hurry to go out of the room, and what did he do after he left?

Joseph hurried out of the room because he was deeply moved about Benjamin, and he went to his room and wept. 

# Why did the Egyptians and the Hebrews eat separately?

It was detestable to the Egyptians to eat with the Hebrews. 

# How were the brothers arranged at the table?

The brothers were arranged at the table according to their birthright and age. 

# What was unusual about the portions of food the brothers received?

Benjamin's portion was five times as much as any of his brothers. 

# What did Joseph tell his steward to do with the brothers' sacks before they left?

Joseph told his steward to fill the brothers' sacks with food, to put their money in the sacks, and to put his silver cup in the youngest's sack. 

# What did Joseph tell his steward to do with the brothers' sacks before they left?

Joseph told his steward to fill the brothers' sacks with food, to put their money in the sacks, and to put his silver cup in the youngest's sack. 

# Basically what did Joseph tell the steward say to the brothers when he overtook them outside the city?

Joseph told the steward to ask them why they had returned evil for good and accused them of stealing Joseph's cup. 

# Basically what did Joseph tell the steward say to the brothers when he overtook them outside the city?

Joseph told the steward to ask them why they had returned evil for good and accused them of stealing Joseph's cup. 

# What did the brothers swear they would do if any one of them had stolen Joseph's cup?

The brothers said the one found with the cup would die, and the others would become slaves. 

# What punishment did the steward say he would require if the cup was stolen?

The steward said that the one with whom the cup was found would be his slave, and the others would be innocent. 

# What did the steward find, and how did the brothers react?

The steward found the cup in Benjamin's sack, and the brothers tore their clothes. 

# What did the steward find, and how did the brothers react?

The steward found the cup in Benjamin's sack, and the brothers tore their clothes. 

# What did the brothers do when they came back to Joseph in his house?

The brothers bowed before Joseph to the ground. 

# Who did Judah say had found out the iniquity of the brothers?

Judah said that God had found out their iniquity. 

# What did Judah say all the brothers would now become?

Judah said all the brothers would now become Joseph's slaves. 

# What punishment did Joseph say he would require of the brothers?

Joseph said that the man in whose hand the cup was found would be his slave, and the rest could go in peace. 

# What reasons did Judah give for why his father loved the youngest brother?

Judah said that the youngest brother was the child of his father's old age, and the only child left of his mother. 

# What did the brothers worry would happen to their father if the youngest left him?

The brothers worried their father would die if the youngest left him. 

# Why did Judah say the brothers were forced to bring Benjamin with them to Egypt?

Judah said they were forced to bring Benjamin because Joseph had said that unless the youngest brother comes, they would not see Joseph's face. 

# Why did Judah say the brothers were forced to bring Benjamin with them to Egypt?

Judah said they were forced to bring Benjamin because Joseph had said that unless the youngest brother comes, they would not see Joseph's face. 

# What did Israel think had happened to Joseph?

Israel thought that surely Joseph had been torn in pieces. 

# What did Israel say would happen to him if Benjamin were taken from him?

Israel said that the brothers would bring his gray hair with sorrow to Sheol. 

# What did Judah say would happen to his father if they returned without Benjamin?

Judah said that his father would die. 

# What guarantee for Benjamin did Judah say he had become?

Judah said that if he did not return Benjamin to his father, he would bear the guilt forever. 

# What did Judah ask Joseph to do so that Benjamin could return to his father?

Judah asked Joseph to make him Joseph's slave, so that Benjamin could return to his father. 

# What did Joseph do as he made himself known to his brothers, which the Egyptians heard?

Joseph wept loudly as he made himself known to his brothers. 

# What did Joseph do as he made himself known to his brothers, which the Egyptians heard?

Joseph wept loudly as he made himself known to his brothers. 

# How did the brothers react when Joseph revealed himself to them?

The brothers could not answer Joseph for they were shocked. 

# According to Joseph, why did God sent Joseph to Egypt?

God sent Joseph to Egypt to preserve life, and to preserve his family as a remnant in the earth. 

# What had God made Joseph in the land of Egypt?

God had made Joseph father to Pharaoh, lord of all Pharaoh's house, and ruler over all the land of Egypt. 

# How did Joseph plan to take care of his family?

Joseph told his family to come and live in the land of Goshen where he would provide for them. 

# How did Joseph plan to take care of his family?

Joseph told his family to come and live in the land of Goshen where he would provide for them. 

# How did Joseph plan to take care of his family?

Joseph told his family to come and live in the land of Goshen where he would provide for them. 

# What did Joseph tell his brothers to hurry and do?

Joseph told his brothers to hurry and bring his father to Egypt. 

# How did Pharaoh react when he heard that Joseph's brothers had come to Egypt?

Pharaoh was very pleased, and he told Joseph to tell his brothers to bring their father and their households to live in the good of the land of Egypt. 

# How did Pharaoh react when he heard that Joseph's brothers had come to Egypt?

Pharaoh was very pleased, and he told Joseph to tell his brothers to bring their father and their households to live in the good of the land of Egypt. 

# How did Pharaoh react when he heard that Joseph's brothers had come to Egypt?

Pharaoh was very pleased, and he told Joseph to tell his brothers to bring their father and their households to live in the good of the land of Egypt. 

# Who received extra gifts and provisions for the trip?

Benjamin received three hundred pieces of silver and five changes of clothing, and Israel received twenty loaded donkeys. 

# Who received extra gifts and provisions for the trip?

Benjamin received three hundred pieces of silver and five changes of clothing, and Israel received twenty loaded donkeys. 

# Who received extra gifts and provisions for the trip?

Benjamin received three hundred pieces of silver and five changes of clothing, and Israel received twenty loaded donkeys. 

# How did Israel react when he heard that Joseph was alive and ruler over all the land of Egypt?

Israel's heart was astonished, for he did not believe the brothers when they told him. 

# What did Israel say he wanted to do before he died?

Israel said he wanted to see Joseph before he died. 

# What did Israel do in Beersheba?

Israel offered sacrifices to the God of his father Isaac. 

# What promises did God make to Israel in Beersheba?

God promised to make Israel a great nation, to go with Israel to Egypt, to bring Israel up again from Egypt, and to have Joseph close his eyes. 

# What promises did God make to Israel in Beersheba?

God promised to make Israel a great nation, to go with Israel to Egypt, to bring Israel up again from Egypt, and to have Joseph close his eyes. 

# Who went to Egypt with Israel?

Israel and all his descendants with him went to Egypt. 

# Who went to Egypt with Israel?

Israel and all his descendants with him went to Egypt. 

# Who went to Egypt with Israel?

Israel and all his descendants with him went to Egypt. 

# Which two sons of Judah died in the land of Canaan?

Er and Onan died in the land of Canaan. 

# How many persons of the house of Jacob came to Egypt?

Seventy persons of the house of Jacob came to Egypt. 

# What did Joseph do to meet his father?

Joseph went up with his chariot and met his father Israel in Goshen. 

# What did Joseph do when he saw his father?

Joseph hugged his father's neck and wept a long time. 

# What did Joseph tell the brothers to say to Pharaoh concerning their occupation?

The brothers were to tell Pharaoh that they were keepers of cattle from their youth. 

# What did the five brothers of Joseph tell Pharaoh their occupation was?

The five brothers told Pharaoh their occupation was shepherding. 

# What kind of residents did the brothers say they were in the land of Egypt?

The brothers said they were temporary residents in the land of Egypt. 

# What did Pharaoh tell Joseph to do with Joseph's family?

Pharaoh told Joseph to settle Joseph's family in the best region, the land of Goshen. 

# What did Jacob do for Pharaoh when he met him and when he went out from his presence?

Jacob blessed Pharaoh when he met him and when he went out from his presence. 

# How long had Jacob lived when he met Pharaoh?

Jacob had lived one hundred and thirty years. 

# How long did Jacob say his life was compared to his ancestors?

Jacob said his life was not as long as his ancestors' lives. 

# What did Jacob do for Pharaoh when he met him and when he went out from his presence?

Jacob blessed Pharaoh when he met him and when he went out from his presence. 

# What was Joseph able to do by selling grain?

Joseph was able to gather up all the money in the land of Egypt and in the land of Canaan. 

# What was Joseph then able to do by exchanging food with the Egyptians?

Joseph was able to exchange food for all the livestock of the Egyptians. 

# What was Joseph then able to do by exchanging food with the Egyptians?

Joseph was able to exchange food for all the livestock of the Egyptians. 

# After the money and livestock were all given to Pharaoh in exchange for food what did the people of Egypt offer Pharaoh in exchange for more food?

The people of Egypt offered their land and themselves as servants of Pharaoh in exchange for more food. 

# After the money and livestock were all given to Pharaoh in exchange for food what did the people of Egypt offer Pharaoh in exchange for more food?

The people of Egypt offered their land and themselves as servants of Pharaoh in exchange for more food. 

# What part of the whole harvest did Joseph require to be given to Pharaoh?

Joseph required one fifth of the harvest to be given to Pharaoh. 

# In what ways did the people of Israel prosper in the land of Egypt?

The people of Israel gained possessions in the land of Egypt, and they were fruitful and multiplied rapidly. 

# At what age did Jacob die?

Jacob died at the age of one hundred forty-seven. 

# What did Israel ask Joseph to swear he would do?

Israel asked Joseph to swear he would bury Israel in his forefathers' burial place. 

# What message did Joseph hear about his father, and what did he then do?

Joseph heard that his father was sick, so he took with him his two sons. 

# What promises from God did Jacob recall to Joseph?

Jacob recalled that God promised him he would be fruitful and multiply, he would be made an assembly of nations, and the land of Canaan would be an everlasting possession of his descendants. 

# How did Jacob say he would consider the two sons of Joseph in the inheritance?

Jacob said he would consider the two sons of Joseph as his own. 

# How did Jacob say he would consider the two sons of Joseph in the inheritance?

Jacob said he would consider the two sons of Joseph as his own. 

# Why did Israel not recognize Joseph's two sons?

Israel did not recognize Joseph's two sons because his eyes were failing because of his age. 

# Why did Israel not recognize Joseph's two sons?

Israel did not recognize Joseph's two sons because his eyes were failing because of his age. 

# Why did Israel not recognize Joseph's two sons?

Israel did not recognize Joseph's two sons because his eyes were failing because of his age. 

# Who was the first-born of Joseph's sons?

Manasseh was the first-born of Joseph's sons. 

# Upon whom did Israel put his right hand, and upon whom his left hand?

Israel put his right hand on Ephraim, and his left hand on Manasseh. 

# Why did Joseph try to exchange the position of Israel's hands?

Joseph expected Israel's right hand to be on Manasseh because he was the first-born. 

# Why did Joseph try to exchange the position of Israel's hands?

Joseph expected Israel's right hand to be on Manasseh because he was the first-born. 

# Why did Israel refuse to exchange the position of his hands on the two sons of Joseph?

Israel refused because the younger brother would be greater than the first-born. 

# What blessing did Israel say the people of Israel would pronounce?

Israel said the people of Israel would pronounce the blessing, "May God make you like Ephraim and like Manasseh". 

# What did Israel say would happen to Joseph?

Israel said that Joseph would be brought back to the land of his fathers. 

# For what reason did Jacob gather his sons together?

Jacob gathered his sons together to tell them what would happen to them and their descendants in the future. 

# What positive attributes did Reuben have?

Reuben was outstanding in dignity and power. 

# Why would Reuben not have the pre-eminence even though he was the firstborn?

Reuben would not have the pre-eminence because he defiled his father's bed. 

# What did Jacob curse about Simeon and Levi?

Jacob cursed the fierce and cruel anger of Simeon and Levi. 

# What did Jacob say his other sons would do before Judah?

Jacob said his others sons would bow down before Judah. 

# What promises about the future were made to Judah?

Judah was promised that the sceptre would not depart from him until Shiloh came, and that the nations would obey him. 

# Where did Jacob say the descendants of Zebulun would live?

Jacob said the descendants of Zebulun would live by the shore of the sea. 

# What animal did Jacob say Dan would be like?

Jacob said Dan would be like a poisonous snake. 

# For what did Jacob say Asher would be known?

Jacob said Asher would be known for providing royal delicacies. 

# What kind of plant did Jacob say Joseph would be like?

Jacob said Joseph would be like a fruitful bough whose branches climb over a wall. 

# Who did Jacob say would keep Joseph's bow steady and his hands skillful?

Jacob said the hands of the mighty one of Jacob, the Rock of Israel would keep Joseph's bow steady and his hands skillful. 

# Who was already buried in the place where Jacob wished to be buried?

Abraham, Sarah, Isaac, Rebekah, and Leah were already buried there. 

# What did Jacob do after he gave his blessings and instructions to his sons?

Jacob breathed his last and went to his people. 

# What did Joseph do with Israel's body after Israel died?

Joseph had Israel's body embalmed. 

# What did Joseph do with Israel's body after Israel died?

Joseph had Israel's body embalmed. 

# What request did Joseph make to Pharaoh about the burial of his father, and why did he make this request?

Joseph requested to be able to go to the land of Canaan to bury his father, as his father had made him swear. 

# What request did Joseph make to Pharaoh about the burial of his father, and why did he make this request?

Joseph requested to be able to go to the land of Canaan to bury his father, as his father had made him swear. 

# What request did Joseph make to Pharaoh about the burial of his father, and why did he make this request?

Joseph requested to be able to go to the land of Canaan to bury his father, as his father had made him swear. 

# Who went with Joseph to bury Israel?

All the officials of Pharaoh, the courtiers of his household, the senior officials of Egypt, Joseph's household, Joseph's brothers, his father's household, and chariots and horsemen all went with Joseph. 

# Who went with Joseph to bury Israel?

All the officials of Pharaoh, the courtiers of his household, the senior officials of Egypt, Joseph's household, Joseph's brothers, his father's household, and chariots and horsemen all went with Joseph. 

# Who went with Joseph to bury Israel?

All the officials of Pharaoh, the courtiers of his household, the senior officials of Egypt, Joseph's household, Joseph's brothers, his father's household, and chariots and horsemen all went with Joseph. 

# What did the Canaanites say when they saw Joseph and those with him?

The Canaanites said that this was a very sad occasion for the Egyptians. 

# Where did Joseph and his brothers go after burying their father?

Joseph and his brothers returned into Egypt. 

# About what were Joseph's brothers worried after Israel died?

Joseph's brothers were worried that Joseph would repay them for all the evil the brothers had done to Joseph. 

# What did the brothers ask Joseph to do regarding the wrongs they had committed against Joseph?

The brothers asked Joseph to forgive them for the wrongs they had committed against Joseph. 

# What did Joseph's brothers do when they came to Joseph?

When they came to Joseph, Joseph's brothers fell down before him. 

# What good did Joseph say God had worked through the evil deeds of his brothers?

Joseph said God had worked the good of preserving the lives of many people. 

# How long did Joseph live?

Joseph lived one hundred and ten years. 

# What did Joseph say was about to happen to him?

Joseph said that he was about to die. 

# What promise did Joseph say God would fulfill for Israel's descendants?

Joseph said God would come to the people and lead them up to the land God promised to Abraham, Isaac, and Jacob. 

# What did Joseph make the people of Israel swear they would do?

Joseph made them swear they would carry Joseph's bones from Egypt when they left Egypt. 

# What happened to Joseph's body after he died?

Joseph's body was embalmed and put in a coffin in Egypt. 

