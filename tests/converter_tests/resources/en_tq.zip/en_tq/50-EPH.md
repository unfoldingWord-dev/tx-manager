# How does Paul describe the people he is writing to in this letter?

Paul describes the people he is writing to as set apart for God, and as faithfully trusting in Christ Jesus. 

# With what has God the Father blessed believers?

God the Father has blessed believers with every spiritual blessing in the heavenly places in Christ. 

# When did God the Father choose those who believe in Christ?

God the Father chose those who believe in Christ before the creation of the world. 

# For what purpose did God the Father choose the believers?

God the Father chose the believers so they could be holy and blameless in his sight. 

# Why did God destine the believers in advance for adoption?

God destined the believers in advance because he was pleased to do it, and so that he would be praised for his glorious grace. 

# Why did God destine the believers in advance for adoption?

God destined the believers in advance because he was pleased to do it, and so that he would be praised for his glorious grace. 

# What do believers receive through the blood of Christ, God's beloved one?

Believers receive redemption through the blood Christ, the forgiveness of sins. 

# What will God do when the times for the completion of his plan come?

God will bring together everything in heaven and on the earth under Christ. 

# What seal did the believers receive when they heard the word of truth?

The believers received the seal of the promised Holy Spirit. 

# Of what is the Spirit a guarantee?

The Spirit is a guarantee of the inheritance of believers. 

# What does Paul pray the Ephesians will be enlightened to understand?

Paul prays that the Ephesians will be enlightened to understand the confidence of their calling. 

# What did the same power that now works in the believers do in Christ?

The same power raised Christ from the dead and seated him at God's right hand in the heavenly places. 

# What has God put under Christ's feet?

God has put all things under Christ's feet. 

# What is Christ's position of authority in the Church?

Christ is the head over all things in the Church. 

# What is the Church?

The Church is Christ's body. 

# What is the spiritual condition of all unbelievers?

All unbelievers are dead in their trespasses and sins. 

# Who is working in the sons of disobedience?

The spirit of the ruler of the authorities of the air is working in the sons of disobedience. 

# By nature, what are all unbelievers?

All unbelievers are by nature children of wrath. 

# Why did God bring some unbelievers to new life with Christ?

God brought some unbelievers to new life in Christ because of his rich mercy and great love. 

# Why did God bring some unbelievers to new life with Christ?

God brought some unbelievers to new life in Christ because of his rich mercy and great love. 

# By what have believers been saved?

Believers have been saved by God's grace. 

# Where are believers seated?

Believers are seated in the heavenly places with Christ Jesus. 

# For what purpose has God saved and raised up believers?

God has saved and raised up believers so that in the ages to come he might show them the great riches of his grace. 

# In what may no believer boast, and why?

No believer may boast in his works, because he is saved by grace as God's gift. 

# In what may no believer boast, and why?

No believer may boast in his works, because he is saved by grace as God's gift. 

# For what purpose has God created believers in Christ Jesus?

God's purpose is for believers in Christ Jesus to walk in good works. 

# What is the spiritual condition of unbelieving Gentiles?

Unbelieving Gentiles are separated from Christ, alienated from Israel, strangers to the covenants, without hope and without God. 

# What has brought some Gentile unbelievers near to God?

Some Gentile unbelievers have been brought near to God by the blood of Christ. 

# How did Christ change the relationship between Gentiles and Jews?

By his body, Christ made Gentiles and Jews one people, destroying the hostility that divided them. 

# What did Christ abolish in order to make peace between Jews and Gentiles?

Christ abolished the law of commandments and regulations in order to make peace between Jews and Gentiles. 

# What did Christ abolish in order to make peace between Jews and Gentiles?

Christ abolished the law of commandments and regulations in order to make peace between Jews and Gentiles. 

# By what means do all believers have access to the Father?

All believers have access to the Father by means of the Holy Spirit. 

# On what foundation is God's family built?

God's family is built on the foundation of the apostles and prophets, Christ Jesus being the cornerstone. 

# What does the power of Jesus do with the whole building of his family?

The power of Jesus fits together and increases the whole building of his family. 

# What kind of building is the building of God's family?

The building of God's family is a temple set apart for the Lord. 

# Where does God dwell in the Spirit?

God dwells in the Spirit within the believer. 

# For whose benefit did God give Paul his gift?

God gave Paul his gift for the benefit of the Gentiles. 

# For whose benefit did God give Paul his gift?

God gave Paul his gift for the benefit of the Gentiles. 

# What was not made known to the human race in other generations?

The hidden truth about Christ was not made known in other generations. 

# What was not made known to the human race in other generations?

The hidden truth about Christ was not made known in other generations. 

# What was not made known to the human race in other generations?

The hidden truth about Christ was not made known in other generations. 

# To whom has God revealed what was not made known to the human race in other generations?

God revealed the hidden truth about Christ to his apostles and prophets. 

# What hidden truth has been revealed?

The hidden truth revealed is that the Gentiles are fellow heirs and fellow members of the body, and fellow sharers in the promise in Christ Jesus. 

# What gift was given to Paul?

The gift of God's grace was given to Paul. 

# About what was Paul sent to help the Gentiles understand?

Paul was sent to help the Gentiles understand about God's plan. 

# Through what will the complex wisdom of God be made known?

Through the Church the complex wisdom of God will be made known. 

# What does Paul say believers have because of faith in Christ?

Paul says believers have boldness and access with confidence because of faith in Christ. 

# What is named and created after the Father?

Every family in heaven and on earth is named and created after the Father. 

# What is named and created after the Father?

Every family in heaven and on earth is named and created after the Father. 

# How does Paul pray the believers be strengthened?

Paul prays the believers be strengthened with power through God's Spirit. 

# What does Paul pray the believers will be able to understand?

Paul prays the believers will be able to understand how wide and long and high and deep is the love of Christ. 

# What does Paul pray will be given to the Father to all generations?

Paul prays that the glory in the Church and in Christ Jesus will be given to the Father to all generations. 

# How does Paul urge believers to live?

Paul urges believers to live with humility, gentleness, and patience, accepting each other in love. 

# How does Paul urge believers to live?

Paul urges believers to live with humility, gentleness, and patience, accepting each other in love. 

# What does Paul name in his list of things of which there is only one?

Paul says there is one body, Spirit, confident expectation, Lord, faith, baptism, and God the Father. 

# What does Paul name in his list of things of which there is only one?

Paul says there is one body, Spirit, confident expectation, Lord, faith, baptism, and God the Father. 

# What does Paul name in his list of things of which there is only one?

Paul says there is one body, Spirit, confident expectation, Lord, faith, baptism, and God the Father. 

# What did Christ give to each believer after his ascension?

Christ gave each believer a gift according to the measure of the gift of Christ. 

# What did Christ give to each believer after his ascension?

Christ gave each believer a gift according to the measure of the gift of Christ. 

# What five gifts of Christ to the body does Paul name?

Christ gave to the body the gifts of apostles, prophets, evangelists, pastors, and teachers. 

# For what purpose are these five gifts to the body supposed to work?

The five gifts to the body are supposed to equip the believers for the work of service, for the building up of the body. 

# How does Paul say believers can be like children?

Believers can be like children by being tossed around and carried away by people's trickery and erring deceit. 

# How does Paul say the body of believers is constructed?

The body of believers fits together, held together by each joint, each part working in the body's growth, for the building up of each one in love. 

# How does Paul say the Gentiles walk?

The Gentiles are darkened in thought, separated from God, and given over to impure actions. 

# How does Paul say the Gentiles walk?

The Gentiles are darkened in thought, separated from God, and given over to impure actions. 

# How does Paul say the Gentiles walk?

The Gentiles are darkened in thought, separated from God, and given over to impure actions. 

# What does Paul say believers must put off and put on?

Believers must put off the old man, and put on the new man. 

# What does Paul say believers must put off and put on?

Believers must put off the old man, and put on the new man. 

# How can a believer give opportunity to the devil?

A believer can give opportunity to the devil by letting the sun go down upon his anger. 

# How can a believer give opportunity to the devil?

A believer can give opportunity to the devil by letting the sun go down upon his anger. 

# What must believers do instead of steal?

Believers must labor so that they may be able to share with the person who has need. 

# What kind of speech does Paul say must come out of the believer's mouth?

No corrupt speech must come out of the believer's mouth, but instead words that build up others. 

# Who must a believer not grieve?

A believer must not grieve the Holy Spirit. 

# What is a believer to do because God in Christ forgave him?

A believer must forgive others because God in Christ forgave him. 

# Who should believers imitate?

Believers should imitate God the Father as his children. 

# What did Christ do which was a pleasing aroma to God?

Christ gave himself up for the believers as an offering and sacrifice to God. 

# What must not be suggested among believers?

Sexual immorality, impurity, and greed must not be suggested among believers. 

# What attitude should instead be seen among believers?

Believers should instead have an attitude of thankfulness. 

# Who has no inheritance in the kingdom of Christ and God?

The sexually immoral, impure, and greedy have no inheritance in the kingdom of Christ and God. 

# What is coming upon the children of disobedience?

The anger of God is coming upon the children of disobedience. 

# What fruit of the light is pleasing to the Lord?

The fruit of goodness, righteousness, and truth is pleasing to the Lord. 

# What are believers to do with the works of the darkness?

Believers are not to participate with, but instead expose the works of darkness. 

# What is revealed by the light?

Everything is revealed by the light. 

# What should believers do since the days are evil?

Believers should redeem the time since the days are evil. 

# What leads to ruin?

Getting drunk with wine leads to ruin. 

# With what should believers speak to each other?

Believers should speak to each other with psalms, hymns, and spiritual songs. 

# In what way should wives be subject to their husbands?

Wives should be subject to their husbands as to the Lord. 

# Of what is the husband the head, and of what is Christ the head?

The husband is head of the wife, and Christ is head of the Church. 

# How does Christ make the Church holy?

Christ makes the Church holy by the washing of water by the word. 

# How does Christ make the Church holy?

Christ makes the Church holy by the washing of water by the word. 

# How should husbands love their wives?

Husbands should love their wives as their own bodies. 

# How does a person treat his own body?

A person nourishes and loves his own body. 

# What happens when a man is joined to his wife?

When a man is joined to his wife they become one flesh. 

# What hidden truth is demonstrated by the joining of a man and his wife?

The hidden truth about Christ and his Church is demonstrated by the joining of a man and his wife. 

# How should Christian children treat their parents?

Christian children should obey and honor their parents. 

# How should Christian children treat their parents?

Christian children should obey and honor their parents. 

# What are Christian fathers to do for their children?

Christian fathers are to raise their children in the discipline and instruction of the Lord. 

# With what attitude should Christian slaves obey their masters?

Christian slaves should obey their masters in the honesty of their heart, serving cheerfully as for the Lord. 

# With what attitude should Christian slaves obey their masters?

Christian slaves should obey their masters in the honesty of their heart, serving cheerfully as for the Lord. 

# With what attitude should Christian slaves obey their masters?

Christian slaves should obey their masters in the honesty of their heart, serving cheerfully as for the Lord. 

# What should a believer remember about whatever good deed he does?

A believer should remember that whatever good deed he does, he will receive a reward from the Lord. 

# What should a Christian master remember about his Master?

A Christian master should remember that his and his servant's Master is in heaven, and that there is no favoritism with him. 

# Why must a believer put on the whole armor of God?

A believer must put on the whole armor of God to stand against the wicked plans of the devil. 

# Against whom does a believer battle?

A believer battles against governments and spiritual authorities and rulers of the realm of evil darkness. 

# Why must a believer put on the whole armor of God?

A believer must put on the whole armor of God to stand against the wicked plans of the devil. 

# Why must a believer put on the whole armor of God?

A believer must put on the whole armor of God to stand against the wicked plans of the devil. 

# Which piece of the armor of God puts out the flaming arrows of the evil one?

The shield of faith puts out the flaming arrows of the evil one. 

# What is the sword of the Spirit?

The sword of the Spirit is the word of God. 

# What attitude must believers have in prayer?

Believers must pray at all times, persevering and watching for God's answer. 

# What does Paul wish to have through the prayers of the Ephesians?

Paul wishes to have the word given to him with boldness when he speaks the gospel. 

# What does Paul wish to have through the prayers of the Ephesians?

Paul wishes to have the word given to him with boldness when he speaks the gospel. 

# Where is Paul as he writes this letter?

Paul is in prison as he writes this letter. 

# What three things does Paul ask that God the Father and the Lord Jesus Christ give the believers?

Paul asks that God will give peace, love with faith, and grace to the believers. 

# What three things does Paul ask that God the Father and the Lord Jesus Christ give the believers?

Paul asks that God will give peace, love with faith, and grace to the believers. 

