# How did Paul become an apostle?

Paul became an apostle through Jesus Christ and God the Father. 

# From what have believers in Jesus Christ been delivered?

Believers in Jesus Christ have been delivered from this present evil age. 

# With what is Paul amazed with the church in Galatia?

Paul is amazed that they have turned so quickly to a different gospel. 

# How many true gospels are there?

There is only one true gospel, the gospel of Christ. 

# What does Paul say should happen to anyone proclaiming a different gospel than the gospel of Christ?

Paul says anyone proclaiming a different gospel should be cursed. 

# What does Paul say should happen to anyone proclaiming a different gospel than the gospel of Christ?

Paul says anyone proclaiming a different gospel should be cursed. 

# Servants of Christ must seek the approval of whom first?

Servants of Christ must seek the approval of God first. 

# How did Paul receive the knowledge of the gospel of Christ?

Paul received the gospel of Christ by revelation from Jesus Christ directly to himself. 

# What was Paul doing in his life before he received the revelation of the gospel of Christ?

Paul was following Judaism zealously, persecuting the church of God. 

# What was Paul doing in his life before he received the revelation of the gospel of Christ?

Paul was following Judaism zealously, persecuting the church of God. 

# When did God choose Paul to be his apostle?

God was pleased to choose Paul from his mother's womb to be his apostle. 

# For what purpose did God choose Paul as his apostle?

God chose Paul as his apostle so that Paul would proclaim Christ among the Gentiles. 

# Where did Paul finally meet some of the other apostles?

Finally, Paul went to Jerusalem and met the apostles Cephas and James. 

# What were the churches in Judea hearing about Paul?

The churches in Judea were hearing that Paul, who once persecuted the church, was now proclaiming the faith. 

# What were the churches in Judea hearing about Paul?

The churches in Judea were hearing that Paul, who once persecuted the church, was now proclaiming the faith. 

# What did Paul do when he went up to Jerusalem after fourteen years?

Paul spoke privately to the leaders of the church, explaining to them the gospel that he was proclaiming. 

# What was Titus, a Gentile, not required to do?

Titus was not required to be circumcised. 

# What did the false brothers desire to do?

The false brothers desired to make Paul and his companions slaves to the law. 

# Did the leaders of the church in Jerusalem change Paul's message?

No, they contributed nothing to Paul's message. 

# To whom was Paul primarily sent to proclaim the gospel?

Paul was primarily sent to the uncircumcised to proclaim the gospel. 

# To whom was Peter primarily sent to proclaim the gospel?

Peter was primarily sent to the circumcised to proclaim the gospel. 

# To whom was Paul primarily sent to proclaim the gospel?

Paul was primarily sent to the uncircumcised to proclaim the gospel. 

# To whom was Peter primarily sent to proclaim the gospel?

Peter was primarily sent to the circumcised to proclaim the gospel. 

# How did the leaders in Jerusalem show their approval of Paul's ministry?

The leaders in Jerusalem gave Paul and Barnabus the right hand of fellowship to show their approval. 

# What error did Peter make when he came to Antioch?

Peter stopped eating with the Gentiles because he feared the men who had been circumcised. 

# What error did Peter make when he came to Antioch?

Peter stopped eating with the Gentiles because he feared the men who had been circumcised. 

# What did Paul ask Cephas in front of everyone?

Paul asked Cephas how he could force Gentiles to live like Jews when Cephas was living like a Gentile. 

# Paul said that no one is justified by what?

Paul said that no one is justified by the works of the law. 

# How is a person justified before God?

A person is justified before God by faith in Christ Jesus. 

# If someone returns to trying to follow the law after having faith in Christ, what does Paul say he has actually become?

Paul says he shows himself actually to be a law breaker. 

# Who did Paul say now lived in him?

Paul said that Christ now lived in him. 

# What does Paul say the Son of God did for him?

Paul says the Son of God loved him and gave himself for Paul. 

# How was Abraham considered righteous before God?

Abraham believed God and it was credited to him as righteousness. 

# Who are the sons of Abraham?

Those who believe God are the sons of Abraham. 

# The scripture foresaw that the Gentiles would be justified in what way?

The scripture foresaw that the Gentiles would be justified by faith. 

# Those who rely on the works of the law to be justified are under what?

Those who rely on the works of the law to be justified are under a curse. 

# How many people have been justified by God through the works of the law?

No one has been justified through the works of the law. 

# Why did Christ redeem us by becoming a curse for us?

Christ redeemed us by becoming a curse for us so that the blessing upon Abraham might come to the Gentiles. 

# Who was the "descendant" that was spoken of in the promise to Abraham?

The "descendant" spoken of in the promise to Abraham was Christ. 

# Did the coming of the Jewish law 430 years after Abraham void the promise God made to Abraham?

No, the law did not void the promise made to Abraham. 

# Why then was there the law?

The law came because of transgressions until Abraham's descendant came. 

# What did the law in scripture imprison everyone under?

The law in scripture imprisoned everyone under sin. 

# How are we released from the imprisonment of the law?

We are released from the imprisonment of the law by faith in Christ Jesus. 

# How are we released from the imprisonment of the law?

We are released from the imprisonment of the law by faith in Christ Jesus. 

# How are we released from the imprisonment of the law?

We are released from the imprisonment of the law by faith in Christ Jesus. 

# How are we released from the imprisonment of the law?

We are released from the imprisonment of the law by faith in Christ Jesus. 

# Who has been clothed in Christ?

All who have been baptized into Christ have been clothed in Christ. 

# What different kinds of persons are made one in Christ Jesus?

Jews, Greeks, slaves, free, male, and female are all made one in Christ Jesus. 

# How does the heir of an estate live while he is a child?

The heir lives under guardians and trustees until the time set by his father. 

# How does the heir of an estate live while he is a child?

The heir lives under guardians and trustees until the time set by his father. 

# What did God do at the right time in history?

God, at the right time, sent forth his Son to redeem those under the law. 

# What did God do at the right time in history?

God, at the right time, sent forth his Son to redeem those under the law. 

# How did God bring children who were under the law into his family?

God adopted as sons the children who were under the law. 

# What does God send forth into the hearts of his children?

God sends forth the Spirit of his Son into the hearts of his children. 

# Before we know God, to whom are we slaves?

Before we know God, we are slaves to the spirits that rule the world, who are not gods at all. 

# Paul was perplexed that the Galatians were returning to what?

Paul was perplexed that the Galatians were returning again to the ruling spirits of the world. 

# As he sees the Galatians turning back, what does Paul fear for them?

Paul fears that the Galatians will become slaves again, and that he has labored in vain over them. 

# When Paul first came to the Galatians, what problem did he have?

When Paul first came to the Galatians, he had a physical illness. 

# Despite Paul's problem, how did the Galatians receive him?

Despite Paul's problem, the Galatians received Paul as an angel of God, as Christ Jesus. 

# Who are the false teachers in Galatia trying to separate?

The false teachers are trying to separate the Galatians from Paul. 

# Under what are the false teachers trying to put the Galatians?

The false teachers are trying to put the Galatians back under the law. 

# From which two kinds of women did Abraham have two sons?

Abraham had two sons, one from a slave woman and one from a free woman. 

# Who is the symbolic mother of Paul and the believing Galatians?

The Jerusalem above, the free woman, is the symbolic mother of Paul and the believing Galatians. 

# Are believers in Christ children of the flesh or children of the promise?

Believers in Christ are children of the promise. 

# Who persecutes the children of the promise?

The children of the flesh persecute the children of the promise. 

# What do the children of the slave woman inherit?

The children of the slave woman do not inherit along with the children of the free woman. 

# Are believers in Christ children of the slave woman or children of the free woman?

Believers in Christ are children of the free woman. 

# For what purpose has Christ set us free?

For freedom Christ has set us free. 

# What did Paul warn the Galatians would happen if they became circumcised?

Paul said that if the Galatians became circumcised, Christ would not benefit them in any way. 

# What did Paul warn would happen to all the Galatians who would seek to be justified by following the law?

Paul warned that all the Galatians who would seek to be justified by following the law would be alienated from Christ and would fall away from grace. 

# As opposed to circumcision and uncircumcised, what is the only thing that means anything in Christ Jesus?

In Christ Jesus, only faith working through love means anything. 

# Of what is Paul confident regarding the one who has confused the Galatians about the gospel?

Paul is confident that the one who has confused the Galatians about the gospel will bear God's judgment. 

# Paul says that proclaiming circumcision does what?

Paul says that proclaiming circumcision the stumbling block of the cross would be destroyed. 

# How are believers not to use their freedom in Christ?

Believers are to not use their freedom in Christ as an opportunity for the flesh. 

# How are believers to use their freedom in Christ?

Believers are to use their freedom in Christ to serve one another in love. 

# The whole law is fulfilled in what one commandment?

The whole law is fulfilled in the commandment, "You must love your neighbor as yourself". 

# How can believers not fulfill the lust of the flesh?

Believers can live by the Spirit and not fulfill the lust of the flesh. 

# What two things are opposed to each other within the believer?

The Spirit and the flesh are opposed to each other within the believer. 

# What are three examples of works of the flesh?

Three examples of works of the flesh are any three of the following list: sexual immorality, impurity, lustfulness, idolatry, sorcery, hostility, strife, jealousy, outbursts of anger, rivalry, dissension, sectarian division, envy, drunkenness, and drunken riots. 

# What are three examples of works of the flesh?

Three examples of works of the flesh are any three of the following list: sexual immorality, impurity, lustfulness, idolatry, sorcery, hostility, strife, jealousy, outbursts of anger, rivalry, dissension, sectarian division, envy, drunkenness, and drunken riots. 

# What will those who practice the works of the flesh not receive?

Those who practice the works of the flesh will not inherit the kingdom of God. 

# What is the fruit of the Spirit?

The fruit of the Spirit is love, joy, peace, patience, kindness, goodness, faith, gentleness, and self-control. 

# What is the fruit of the Spirit?

The fruit of the Spirit is love, joy, peace, patience, kindness, goodness, faith, gentleness, and self-control. 

# Those who belong to Christ Jesus have done what with the flesh and its passions?

Those who belong to Christ Jesus have crucified the flesh and its passions. 

# What should those who are spiritual do if a man is caught in some transgression?

Those who are spiritual should restore that man in a spirit of gentleness. 

# For what danger must those who are spiritual watch out?

Those who are spiritual must watch out that they are not also tempted. 

# How do believers fulfill the law of Christ?

Believers fulfill the law of Christ by carrying one another's burdens. 

# How can a person have something in himself to be proud of regarding his work?

A person can have something in himself to be proud of by examining his own work, without comparing himself to anyone else. 

# What must one who is taught the word do with his teacher?

One who is taught the word must share all good things with his teacher. 

# What happens to whatever a man spiritually plants?

Whatever a man spiritually plants he will harvest. 

# What does a man harvest who plants to his own flesh?

A man who plants to his own flesh harvests corruption out of his flesh. 

# What does a man harvest who plants to the Spirit?

A man who plants to the Spirit harvests out of the Spirit eternal life. 

# If a believer does not give up and continues doing good, what will he receive?

A believer who continues doing good will reap a harvest. 

# To whom should believers especially do good?

Believers should especially do good to those of the household of faith. 

# What is the motivation of those who want to compel the believers to be circumcised?

Those who want to compel the believers to be circumcised do not want to be persecuted for the cross of Christ. 

# Of what did Paul say he was proud?

Paul said that he was proud of the cross of our Lord Jesus Christ. 

# Instead of circumcision or uncircumcision, what is important?

What is important is a new creation. 

# Upon whom does Paul wish peace and mercy?

Paul wishes peace and mercy upon those who live by the rule of the new creation, and upon the Israel of God. 

# What did Paul carry on his body?

Paul carried the marks of Jesus on his body. 

