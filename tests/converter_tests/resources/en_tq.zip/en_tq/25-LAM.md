# What has the city of Jerusalem become like even though she was once a mighty nation?

The city has become like a widow. 

# What can Judah not find even though she lives among the nations?

Judah can find no rest even though she lives among the nations. 

# Why has Yahweh afflicted the city of Jerusalem?

Yahweh has afflicted the city of Jerusalem because of her many sins. 

# What has left the daughter of Zion?

Beauty has left the daughter of Zion. 

# What did Jerusalem have in former days that she now calls to mind?

Jerusalem recalls all her precious treasures that she had in former days. 

# Because Jerusalem sinned greatly, what has she become like?

Jerusalem has become like a menstrual rag. 

# What has Jerusalem seen enter her sanctuary even though Yahweh had commanded that they must not enter?

Jerusalem has seen the nations enter her sanctuary. 

# What do the people do as they search for bread?

The people groan as they search for bread. 

# What has Yahweh spread before the feet of Jerusalem to turn her back?

Yahweh has spread a net before the feet of Jerusalem. 

# What has failed because of the yoke of Jerusalem's transgressions that are knit together and placed on her neck?

Jerusalem's strength has failed because of the yoke of her transgressions placed on her neck. 

# Like what has the Lord trampled the virgin daughter of Judah?

The Lord has trampled the virgin daughter of Judah like grapes in a wine press. 

# Why are Jerusalem's children desolate?

Jerusalem's children are desolate because the enemy has triumphed. 

# Who have gone into captivity because Jerusalem rebelled against Yahweh's commandment?

Jerusalem's virgins and vigorous men have gone into captivity. 

# Who perished in the city while they sought food to restore their lives?

Jerusalem's priests and elders perished in the city. 

# What is turned within Jerusalem because she grievously rebelled?

Jerusalem's heart is turned within her. 

# What do the enemies of Jerusalem do when they hear of her adversity?

The enemies of Jerusalem rejoice. 

# What does Jerusalem request Yahweh to do to her enemies as they come before Yahweh?

Jerusalem asks that Yahweh would torment her enemies as Yahweh has tormented her for all her transgressions. 

# How does the Lord express his anger because of Jeremiah's rebellion?

He has taken away the beauty of Israel, has no compassion for the towns of Jacob, and has struck down the fortified cities of Judah. 

# How does the Lord express his anger because of Jeremiah's rebellion?

He has taken away the beauty of Israel, has no compassion for the towns of Jacob, and has struck down the fortified cities of Judah. 

# How does his anger affect Israel and Zion?

The Lord has removed all of Israel's strength and poured his wrath on Zion. 

# How does his anger affect Israel and Zion?

The Lord has removed all of Israel's strength and poured his wrath on Zion. 

# How is the Lord's anger shown?

The Lord has become like an enemy, he destroyed the palace and the tabernacle, and has despised both king and priest. 

# How is the Lord's anger shown?

The Lord has become like an enemy, he destroyed the palace and the tabernacle, and has despised both king and priest. 

# Why does the enemy feel victorious?

They feel victorious because the Lord rejected his altar and has given the walls of the palace over to them. 

# What has happened to the gates and bars of Zion?

Her gates have sunk into the ground, and Yahweh has destroyed and broken her gate bars. 

# How do the elders and virgins show they are grieving?

The elders sit on the ground, sprinkle their heads with dust while dressed in sackcloth. The virgins lower their heads to the ground. 

# Why is Jeremiah lamenting?

Because there is nothing for his people to eat or drink. 

# Why is Jeremiah lamenting?

Because there is nothing for his people to eat or drink. 

# What do the mockers do as they pass through the city?

They clap their hands, hiss and shake their heads, they whistle and grind their teeth. 

# What do the mockers do as they pass through the city?

They clap their hands, hiss and shake their heads, they whistle and grind their teeth. 

# How do the people show their remorse?

They cry out to the Lord and lift their hands to him for the sake of their children. 

# How do the people show their remorse?

They cry out to the Lord and lift their hands to him for the sake of their children. 

# Why are the people begging for Yahweh's mercy?

Because he has dealt with them so severely, they are hungry, and they are concerned about their priests being slaughtered. 

# How does Jeremiah describe the day of Yahweh's wrath?

On the day of Yahweh's wrath, Yahweh killed young and old, no one survived, and he showed no compassion. 

# How does Jeremiah describe the day of Yahweh's wrath?

On the day of Yahweh's wrath, Yahweh killed young and old, no one survived, and he showed no compassion. 

# What does the writer say that Yahweh has turned against him all the day?

Yahweh's hand is turned against him all the day. 

# What does the writer say that Yahweh has built around him so that he cannot escape?

Yahweh has built a wall around him. 

# To what animal does the writer compare Yahweh and say that it is waiting to ambush him?

The writer describes Yahweh as a bear that is waiting to ambush him. 

# What has the writer become to all his people?

The writer has become a laughingstock to all his people. 

# What can the writer no longer remember since Yahweh has removed peace from his life?

The writer can no longer remember any happiness. 

# What is the writer's mood as he calls to mind his affliction?

The writer's mood is one of despair within himself as he calls to mind his affliction. 

# What is the writer's mood as he calls to mind his affliction?

The writer's mood is one of despair within himself as he calls to mind his affliction. 

# What does the writer say occurs afresh every morning?

The writer says that Yahweh's merciful actions occur afresh every morning. 

# What is Yahweh like toward the one who waits for him and to whose who wait in silence for the salvation of Yahweh?

Yahweh is good to those who wait for him, and wait in silence for Yahweh's salvation. 

# What is Yahweh like toward the one who waits for him and to whose who wait in silence for the salvation of Yahweh?

Yahweh is good to those who wait for him, and wait in silence for Yahweh's salvation. 

# How should a person sit because Yahweh has laid it upon him?

A person should sit alone and silent because Yahweh has laid it upon him. 

# How should a person sit because Yahweh has laid it upon him?

A person should sit alone and silent because Yahweh has laid it upon him. 

# How should a person sit because Yahweh has laid it upon him?

A person should sit alone and silent because Yahweh has laid it upon him. 

# What does Yahweh show, even though he brings grief?

Yahweh shows compassion even though he brings grief. 

# From where does Yahweh not oppress or torment the sons of men?

Yahweh does not oppress from his heart or torment the sons of men. 

# What two things come out of the mouth of the Most High?

Calamity and success come out of the mouth of the Most High. 

# What should the people lift up to God in the heavens when they test and examine their ways and turn back to Yahweh?

The people should lift up their hearts and their hands to God in the heavens. 

# What should the people lift up to God in the heavens when they test and examine their ways and turn back to Yahweh?

The people should lift up their hearts and their hands to God in the heavens. 

# What should the people admit that they have done against Yahweh as they pray?

They should admit that they have sinned and rebelled against Yahweh. 

# What does the writer say that Yahweh has made them to be among the peoples?

Yahweh has made them to be castoffs and refuse among the peoples. 

# How does the writer describe the tears that flow from his eyes?

His tears are streams of water that flow out from his eyes. 

# How does the writer describe the tears that flow from his eyes?

His tears are streams of water that flow out from his eyes. 

# What does the writer say as his enemies hunt him and destroy his life in a well and place a stone over him?

He says, "I have been cut off!" 

# What does the writer say as his enemies hunt him and destroy his life in a well and place a stone over him?

He says, "I have been cut off!" 

# What does the writer say as his enemies hunt him and destroy his life in a well and place a stone over him?

He says, "I have been cut off!" 

# What did Yahweh tell the writer when he called on Yahweh's name and asked Yahweh to hear his cry for help?

Yahweh told him, "Do not fear!" 

# What did Yahweh tell the writer when he called on Yahweh's name and asked Yahweh to hear his cry for help?

Yahweh told him, "Do not fear!" 

# What did Yahweh tell the writer when he called on Yahweh's name and asked Yahweh to hear his cry for help?

Yahweh told him, "Do not fear!" 

# How does the writer ask Yahweh to judge his case?

He asks Yahweh to judge his case justly. 

# Of what is the writer the object from his enemies, whether in their sitting or their rising up?

He is the object of their mocking song. 

# What does the writer ask Yahweh to do to his enemies?

He asks Yahweh to pay back to them as much harm as what their hands have done. 

# What does the writer ask Yahweh to do to his enemies?

he asks Yahweh to pursue his enemies in his anger and destroy them everywhere under the heavens. 

# What has become of the gold and the holy stones?

The gold has become completely tarnished, the purest gold has changed and the holy stones have been poured out at the head of every street. 

# What were the sons of Zion, and how are they now valued?

The sons of Zion were precious, valued greater than pure gold, but now they are regarded as clay jars made by potter's hands. 

# How do the daughters of his people act?

They are as cruel as the ostrich in the desert. 

# What happens to the tongue of the nursing baby and what are the children asking for?

The tongue of the nursing baby sticks to the roof of his mouth with thirst and the children are asking for bread but there is nothing for them. 

# What has happened to the ones who used to eat expensive food and those who wore scarlet clothing?

The ones who used to eat expensive food are now abandoned and starving, and the ones who wore scarlet clothing are now on top of the garbage heaps. 

# How great is the iniquity of the daughter of his people?

The iniquity of the daughter is greater than the sin of Sodom. 

# What were her leaders like before, and how are they now?

Her leaders were like snow that shines, they were as white as milk, their bodies were more ruddy than coral, and their form like sapphire. Now darkness has blackened their appearance, they are unrecognizable, and their skin clings to their withered bones. 

# What were her leaders like before, and how are they now?

Her leaders were like snow that shines, they were as white as milk, their bodies were more ruddy than coral, and their form like sapphire. Now darkness has blackened their appearance, they are unrecognizable, and their skin clings to their withered bones. 

# What does Jeremiah say about those who have been killed by hunger compared to those killed by the sword?

Jeremiah says that those killed by the sword are better off than those killed by hunger. 

# What did the compassionate women do with their children?

They boiled their own children and the children became their food. 

# How did Yahweh satisfy his rage?

Yahweh satisfied his rage when he poured out his burning anger, kindled a fire in Zion, and devoured her foundations. 

# What did the kings and the inhabitants of the world not believe could happen to Jerusalem?

They did not believe that an enemy could enter the gates of Jerusalem. 

# What did the enemy do because of the sins of the prophets and the iniquities of the priests?

The enemy entered the gates of Jerusalem. 

# What happened to those prophets and priests?

They wandered like blind men in the streets and were defiled by that blood so no one was able to touch their clothes. 

# What did the prophets and priests cry out?

The prophets and the priests cried out and said to flee and to not touch them. 

# Where did the prophets and the priests go?

They wandered to other lands where the Gentiles said they could not live there any longer. 

# What did Yahweh do to the prophets and the priests?

Yahweh scattered the prophets and priests and does not look on them with favor any longer. 

# How are the priests received and how are the elders received?

The priests are not respected anymore and the elders are not shown any concern. 

# What failed to find worthless help?

Their eyes failed to find help. 

# What did the enemy do to them?

They hunted their steps going through their streets. 

# What did the people say about their end?

They said their end was near, their days were finished, and their end had come. 

# How did the people describe the pursuers, and what did the pursuers do to them?

The pursuers were swifter than the eagles and chased them to the mountains and lay in wait for them in the wilderness. 

# What happened to their king?

Their king was captured in the enemy's pits. 

# Why is the daughter of Edom told to rejoice and be glad?

She is told to rejoice and be glad for the cup will pass to her and she will be drunk and strip naked. 

# What is the daughter of Zion told?

She is told her guilt is ended and Yahweh will no longer keep her in exile. 

# What is the daughter of Edom told?

The daughter of Edom is told Yahweh will punish her guilt and will uncover her sins. 

# What does Jeremiah ask Yahweh to do?

Jeremiah asks Yahweh to call to mind what has happened to them and to see their shame. 

# What does Jeremiah tell Yahweh has happened to their inheritance?

Jeremiah tells Yahweh that their inheritance has been turned over to strangers, and their houses to foreigners. 

# How does Jeremiah describe what is happening to them?

Their enemies run after them, they are weary, and they have reached out to the Egyptians and Assyrians for food. 

# How does Jeremiah describe what is happening to them?

Their enemies run after them, they are weary, and they have reached out to the Egyptians and Assyrians for food. 

# What are the people saying about sin?

They are saying their fathers sinned and they bear their fathers' sins. 

# What are the people saying about the slaves?

The people are saying the slaves rule over them and there is no one to rescue them. 

# How do they describe themselves when they go out to get bread?

They risk their lives to get bread in the face of the sword in the wilderness. 

# How do they describe their skin?

Their skin is like an oven and burnt up from the fever of famine. 

# What happened to the women and virgins?

The women of Zion and the virgins of the cities of Judah were raped. 

# What happened to the princes and the elders?

The princes were hung by their hands and the elders were not honored. 

# What happened to the vigorous men and youthful men?

The vigorous men were brought up to the grinding house and the youthful men staggered beneath logs. 

# What happened to the elders and the vigorous men?

The elders were removed from the city gate and the vigorous men from their music. 

# How do they describe the joy of their heart, their dances, and their crown?

Their joy has ceased, their dances have changed into mourning, and the crown has fallen from their head. 

# How do they describe the joy of their heart, their dances, and their crown?

Their joy has ceased, their dances have changed into mourning, and the crown has fallen from their head. 

# What do they say about their hearts and eyes?

Their hearts have become sick and their eyes have grown dim. 

# What do they say about Yahweh's reign and throne?

Yahweh reigns forever and his throne is from generation to generation. 

# What do they ask Yahweh?

They ask Yahweh whether he is forgetting them forever, and if he will turn them back to him. 

# What do they ask Yahweh?

They ask Yahweh whether he is forgetting them forever, and if he will turn them back to him. 

