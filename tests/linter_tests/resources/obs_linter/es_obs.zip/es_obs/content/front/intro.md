

__unfoldingWord | HISTORIAS BÍBLICAS LIBRES__

__una mini Biblia visual sin restricciones en cualquier idioma__

[http://openbiblestories.com](http://openbiblestories.com)

Historias Bíblicas Libres, v. 3.1

Creadas por Distant Shores Media ([http://distantshores.org](http://distantshores.org)) y la comunidad de misiones mundial Door43 ([http://door43.org](http://door43.org)).

__Licencia:__

Esta obra está puesta bajo una licencia internacional de Creative Commons Attribution-ShareAlike 4.0 ([http://creativecommons.org/licenses/by-sa/4.0/](http://creativecommons.org/licenses/by-sa/4.0/)).

Usted es libre de:

* __Compartir__ — copiar y redistribuir el material en cualquier medio o formato
* __Adaptar__ — mezclar, transformar, y construir sobre el material para cualquier propósito, incluso comercialmente.

Bajo las siguientes condiciones:

* __Atribución__ — Debe atribuir la obra como sigue: "La obra original está disponible en http://openbiblestories.com."Lasdeclaraciones de atribución en obras derivadas no sugerirán en ninguna manera que le avalamos a usted o su uso de esta obra.
* __Compartir en Igualdad__ — Si mezcla, transforma, o construye sobre el material, debe distribuir sus contribuciones bajo la misma licencia que el original.

Uso de marcas: __unfoldingWord__ es una marca de Distant Shores Media y no puede ser incluida en cualquier obra derivada creada a partir de este contenido. El contenido sin alterar de [http://openbiblestories.com](http://openbiblestories.com) debe incluir el logo de __unfoldingWord__ cuando sea distribuido a otros. Pero si usted altera el contenido de alguna manera, debe quitar el logo de __unfoldingWord__ antes de dsitribuir su obra.

Atribución de las obras de arte: Todas las imágenes usadas en estas historias son © Sweet Publishing ([www.sweetpublishing.com](http://www.sweetpublishing.com)) y están puestas bajo Licencia Creative Commons Attribution-Share Alike License ([http://creativecommons.org/licenses/by-sa/3.0](http://creativecommons.org/licenses/by-sa/3.0)).

A nuestros hermanos y hermanas en Cristo en todo el mundo - la iglesia global. Es nuestra oración que Dios use este panorama visual de su Palabra para bendecir, fortalecer y animar.

