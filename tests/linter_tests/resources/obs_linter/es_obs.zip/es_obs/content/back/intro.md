### ¡Involúcrese! ###

Queremos que esta mini-Biblia visual esté disponible en _cualquier idioma del mundo_ y ¡usted puede ayudar! No es imposible— creemos que puede suceder si todo el cuerpo de Cristo trabaja junto para traducir y distribuir este recurso.
### Comparta con libertad ###

Regale tantas copias de este libro como quiera, sin restricción. Todas las versiones digitales son gratis online, y debido a la licencia abierta que usamos, puede hacer nuevas ediciones de las Historias Bíblicas Libres en cualquier lugar del mundo ¡sin pagar derechos de autor! Descubra más en [http://openbiblestories.com](http://openbiblestories.com).

### ¡Amplíe! ###

Consiga las Historias Bíblicas Libres en forma de videos y aplicaciones para teléfono movil en otros idiomas en [http://openbiblestories.com](http://openbiblestories.com). En el sitio web, también puede ayudar a traducir las Historias Bíblicas Libres en _su_ idioma.
