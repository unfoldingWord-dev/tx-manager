# lust #

## Definition: ##

Lust is a very strong desire, usually in the context of wanting something sinful or immoral. To lust is to have lust.

* In the Bible, "lust" usually referred to sexual desire for someone other than one's own spouse.
* Sometimes this term was used in a figurative sense to refer to worshiping idols.
* Depending on the context, "lust" could be translated as "wrong desire" or "strong desire" or "wrongful sexual desire" or "strong immoral desire" or "to strongly desire to sin."
* The phrase "to lust after" could be translated as "to wrongly desire" or "to think immorally about" or "to immorally desire."

 (See also: [adultery](../kt/adultery.md), [idol](../other/idol.md)) 

## Bible References: ##

* [1 John 02:15-17](rc://en/tn/help/1jn/02/15)
* [2 Timothy 02:22-23](rc://en/tn/help/2ti/02/22)
* [Galatians 05:16-18](rc://en/tn/help/gal/05/16)
* [Galatians 05:19-21](rc://en/tn/help/gal/05/19)
* [Genesis 39:7-9](rc://en/tn/help/gen/39/07)
* [Matthew 05:27-28](rc://en/tn/help/mat/05/27)

## Word Data:##

* Strong's: H183, H185, H310, H1730, H2181, H2183, H2530, H5178, H5375, H5689, H5691, H5869, H7843, H8307, H8378, G766, G1937, G1938, G1939, G1971, G2237, G3715, G3806
