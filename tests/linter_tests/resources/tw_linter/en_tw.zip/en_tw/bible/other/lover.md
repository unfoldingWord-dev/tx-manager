# lover #

## Definition: ##

The term "lover" literally means "person who loves." Usually this refers to people who are in a sexual relationship with each other.

* When the term "lover" is used in the Bible, it usually refers to a person who is involved in a sexual relationship with someone he or she is not married to.
* This wrong sexual relationship is often used in the Bible to refer to Israel's disobedience to God in worshiping idols. So the term "lovers" is also used in a figurative way to refer to the idols that the people of Israel worshiped. In these contexts, this term could possibly be translated by "immoral partners" or "partners in adultery" or "idols." [See  Metaphor]
* A "lover" of money is someone who puts too much importance on getting money and being rich.
* In the Old Testament book Song of Songs, the term "lover" is used in a positive way.
 
(See also: [adultery](../kt/adultery.md), [false god](../kt/falsegod.md), [idol](../other/idol.md), [love](../kt/love.md))

## Bible References: ##

* [Hosea 02:4-5](rc://en/tn/help/hos/02/04)
* [Jeremiah 03:1-2](rc://en/tn/help/jer/03/01)
* [Lamentations 01:1-2](rc://en/tn/help/lam/01/01)
* [Luke 16:14-15](rc://en/tn/help/luk/16/14)

## Word Data:##

* Strong's: H157, H158, H868, H5689, H7453, H8566, G865, G866, G5358, G5366, G5367, G5369, G5377, G5381, G5382
