# Nahum #

## Facts: ##

Nahum was a prophet who preached during the time when the evil King Manasseh was ruling over Judah.

* Nahum was from the town of Elkosh, which was about 20 miles from Jerusalem. 
* The Old Testament book of Nahum records his prophecies about the destruction of the Assyrian city of Nineveh.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Assyria](../names/assyria.md), [Manasseh](../names/manasseh.md), [prophet](../kt/prophet.md), [Nineveh](../names/nineveh.md))

## Bible References: ##

* [Nahum 01:1](rc://en/tn/help/nam/01/01)

## Word Data:##

* Strong's: H5151, G3486
