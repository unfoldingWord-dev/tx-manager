# Gerar #

## Facts: ##

​Gerar was a city and region in the land of Canaan, located southwest of Hebron and northwest of Beersheba.

* King Abimelech was the ruler of Gerar when Abraham and Sarah settled there.
* The Philistines dominated the region of Gerar during the time that the Israelites were living in Canaan.

(Translation suggestions: [How to Translate Names](rc://en/ta/man/translate/translate-names))

(See also: [Abimelech](../names/abimelech.md), [Beersheba](../names/beersheba.md), [Hebron](../names/hebron.md), [Philistines](../names/philistines.md))

## Bible References: ##

* [2 Chronicles 14:12-13](rc://en/tn/help/2ch/14/12)
* [Genesis 20:1-3](rc://en/tn/help/gen/20/01)
* [Genesis 26:1](rc://en/tn/help/gen/26/01)
* [Genesis 26:6-8](rc://en/tn/help/gen/26/06)

## Word Data:##

* Strong's: H1642
