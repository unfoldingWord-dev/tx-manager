# 1 Timothy 06 General Notes #

#### Special concepts in this chapter ####

##### Slavery #####

This passage does not condone slavery as an acceptable practice. Paul's teaching on slavery would have been rather radical at this time because masters were not expected to treat their slaves in such a pleasant way. Overall, Paul's focus is on living in a way that pleases God despite the circumstances of one's life.

## Links: ##

* __[1 Timothy 06:01 Notes](./01.md)__

__[<<](../05/intro.md) | __
