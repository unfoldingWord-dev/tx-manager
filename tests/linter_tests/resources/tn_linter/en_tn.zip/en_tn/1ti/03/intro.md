# 1 Timothy 03 General Notes #

#### Structure and formatting ####

[1 Timothy 3:16](./16.md) was probably a song, poem, or creed the early church used to list important doctrines believers all shared.

#### Special concepts in this chapter ####

##### Overseer and Deacons #####
There is some disagreement over the different titles used for church leaders. Some titles include: overseer, elder, pastor, and bishop.

#### Other possible translation difficulties in this chapter ####

##### Character qualities #####
This chapter lists several qualities that a man must have if he is to be an overseer in the church.  (See: [[rc://en/ta/man/translate/figs-abstractnouns]]) 

## Links: ##

* __[1 Timothy 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__
